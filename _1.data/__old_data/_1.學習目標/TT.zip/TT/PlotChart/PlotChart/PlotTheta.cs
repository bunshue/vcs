﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;
using System.IO;
using System.Runtime.InteropServices;

namespace Plot
{
    public partial class PlotTheta : Form
    {
        public PlotTheta()
        {
            InitializeComponent();
        }
        public String RcdFilePath{ get; set; }
        public int X_Max{ get; set; }
        public int X_Min{ get; set; }
        public int Y_Max{ get; set; }
        public int Y_Min{ get; set; }
        public int Y2_Max { get; set; }
        public int Y2_Min { get; set; }
        public String[] AxisName = new String[] { "Time(10 ms)", "Rotational Speed(0.1 RPS) ", "Current Is(0.1A)" };
        
     
        private void ChartThta_Show()
        {
            OpenFileDialog oFD = new OpenFileDialog();
            TextFileToIntArry textToIntArr = new TextFileToIntArry();
            //string filePathString = Path.Combine(Directory.GetCurrentDirectory(), "IntArray_Theta.txt");
           // string filePathString = ThetaRcdFilePath;

            //----------------------------------------------------------------------
            // If the file of data does not existed, then return (Not draw the plot)
            // Prevent program shutting down if there is not data to draw the plot
            //----------------------------------------------------------------------
            if (File.Exists(RcdFilePath) == false) return;

            textToIntArr.FilePath = RcdFilePath;
            textToIntArr.seperator = new Char[] { ' ', ',', ':', '\t' };
            textToIntArr.ReadTextToIntArray();
           
            int[][] DataGroupArray = new int[textToIntArr.ArrayCol][];
            DataGroupArray = textToIntArr.IntArrayTranspose();
         
        //    double[] test = textToIntArr.IntArrayAverage(3, 2);

            if(X_Max == 0) X_Max = DataGroupArray[0].Max(); //Andy 2015.02.06
            if(X_Min == 0) X_Min = DataGroupArray[0].Min();//Andy 2015.02.06
            if(Y_Max == 0) Y_Max = DataGroupArray[1].Max();
            if(Y_Min == 0) Y_Min = DataGroupArray[1].Min();



            //ChartAreas, Series, Legends基本設定--------------------------------------------
            // Chart chart1 = new Chart();   //目前測試會error
            chart.ChartAreas.Add("area");//圖表區域集合
            chart.Series.Add("Theta"); //數據序列集合(Phase)
            chart.Legends.Add("Legends1"); //圖例集合


            //設定Chart    ---------------------------------------------------------------------------
            //chartTheta.Width = 630;
            //chartTheta.Height = 460;
          
           
            Title title = new Title();
            title.Text = Path.GetFileName(this.RcdFilePath);
            title.Alignment = ContentAlignment.MiddleCenter;
            title.Font = new System.Drawing.Font("Times New Roman ", 14F, FontStyle.Bold);
            chart.Titles.Add(title);


            //設定 ChartArea--------------------------------------------------------------------------
            //chart2.ChartAreas["area"].BackColor = Color.White; //設定背景顏色
           chart.ChartAreas["area"].AxisX.Minimum = X_Min;
           chart.ChartAreas["area"].AxisX.Maximum = X_Max;
           if (X_Min == X_Max)
               chart.ChartAreas["area"].AxisX.Interval = 1;

           chart.ChartAreas["area"].AxisY.Minimum = Y_Min;
           chart.ChartAreas["area"].AxisY.Maximum = Y_Max;
           if (Y_Min == Y_Max)
               chart.ChartAreas["area"].AxisY.Interval = 1;
            //chart2.ChartAreas["area"].AxisY2.Minimum = Y2_Min;
            //chart2.ChartAreas["area"].AxisY2.Maximum = Y2_Max;
            //chart2.ChartAreas["area"].AxisY2.Interval = 2;

            chart.ChartAreas["area"].AxisX.MajorGrid.LineColor = Color.Black; //X軸線的顏色
            chart.ChartAreas["area"].AxisY.MajorGrid.LineColor = Color.Black;//Y軸線的顏色
      

            chart.ChartAreas["area"].AxisX.Title = "Time(1 ms)";//X軸文字說明
            chart.ChartAreas["area"].AxisY.Title = "Theta(Degree)";//Y1軸文字說明
          

            chart.ChartAreas["area"].AxisX.TitleFont = new System.Drawing.Font("Times New Roman ", 10F, System.Drawing.FontStyle.Regular);
            chart.ChartAreas["area"].AxisY.TitleFont = new System.Drawing.Font("Times New Roman ", 10F, System.Drawing.FontStyle.Regular);
          

            //設定 Legends--------------------------------------------------------------------------
            chart.Legends["Legends1"].DockedToChartArea = "area";  ////顯示在圖表內
            chart.Legends["Legends1"].Docking = Docking.Left; //自訂顯示位置
            chart.Legends["Legends1"].BackColor = Color.WhiteSmoke;
            chart.Legends["Legends1"].BackHatchStyle = ChartHatchStyle.DarkDownwardDiagonal; //背景採用斜線

            //chart2.Legends["Legends1"].BorderWidth = 1; //設定Legends的邊框
            //chart2.Legends["Legends1"].BorderColor = Color.FromArgb(200, 200, 200);/設定Legends邊框的顏色


            //設定 Series--------------------------------------------------------------------------
            chart.Series["Theta"].ChartType = SeriesChartType.Line; 
            chart.Series["Theta"].Color = Color.Blue;

            chart.Series["Theta"].YAxisType = AxisType.Primary;

            chart.Series["Theta"].Legend = "Legends1";

            chart.Series["Theta"].LegendText = "Theta"; //設定折線圖的名字
          

            //畫出XY座標
            for (int i = 0; i < DataGroupArray[0].Length; i++)
                chart.Series["Theta"].Points.AddXY(DataGroupArray[0][i], DataGroupArray[1][i]);//Theta

           
            
        }
       
        private void Form1_Load(object sender, EventArgs e)
        {
            //ThetaRcdFilePath = Path.Combine(Directory.GetCurrentDirectory(), "IntArray_Theta.txt");
            ChartThta_Show();
        }

      
        [DllImport("user32")]
        public static extern int SetParent(int hWndChild, int hWndNewParent);
        public bool StartupFormShow_Flag = true;    
        

        public bool ThetaFormShow_Flag = true;      
        private void butn_Setting_theta_Click(object sender, EventArgs e)
        {
            
            SubForm_Theta_SettingAxis ChildFormTheta = new SubForm_Theta_SettingAxis();
            ChildFormTheta.Owner = this;
            if (ThetaFormShow_Flag)
            {
                ChildFormTheta.Show();
                ThetaFormShow_Flag = false;
            }
            
            ChildFormTheta.BringToFront();
            SetParent((int)ChildFormTheta.Handle, (int)this.Handle);
        }

        private void button_SavePic_Click(object sender, EventArgs e)
        {
            SavePic();
        }   
        public void SavePic()
        { 
            string picNamePath = Path.ChangeExtension(this.RcdFilePath, ".jpeg");
            this.chart.SaveImage(picNamePath, ChartImageFormat.Jpeg);
        }
 
    }
}

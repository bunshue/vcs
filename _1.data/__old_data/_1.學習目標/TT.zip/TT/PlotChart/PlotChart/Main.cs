﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Plot
{
    public partial class Main : Form
    {
        public Main()
        {
            InitializeComponent();
        }
 
        private void Startup_Click(object sender, EventArgs e)
        {
            PlotStartup startup = new PlotStartup();
            startup.RcdFilePath = Path.Combine(Directory.GetCurrentDirectory(), "IntArray.txt");
           
            startup.Show();
        }

       

        private void butn_theta_Click(object sender, EventArgs e)
        {
            PlotTheta theta = new PlotTheta();
            theta.RcdFilePath = Path.Combine(Directory.GetCurrentDirectory(), "IntArray_Theta.txt");
            theta.Show();
        }
    }
}

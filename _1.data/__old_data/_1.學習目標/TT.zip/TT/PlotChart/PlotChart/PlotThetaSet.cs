﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace Plot
{
    public partial class SubForm_Theta_SettingAxis : Form
    {
        private bool Theta_GridFlag1 = true;
        private bool Theta_GridFlag2 = true;

        public SubForm_Theta_SettingAxis()
        {
            InitializeComponent();
        }
        private void TB_Theta_AxisX_Name_KeyDown(object sender, KeyEventArgs e)
        {
        
            PlotTheta myForm = (PlotTheta)this.Owner;//宣告一個myForm參考主視窗
            if (e.KeyCode == Keys.Enter)
            {
                try
                {
                    myForm.chart.ChartAreas["area"].AxisX.Title = TB_Theta_AxisX_Name.Text;

                    //TB_Theta_AxisX_Name.Text  = " ";
                }
                catch
                {
                    MessageBox.Show("Please input correct number.");
                    TB_Theta_AxisX_Name.Text = " ";
                }
            }
        }
        private void TB_Theta_AxisX_Min_KeyDown(object sender, KeyEventArgs e)
        {

            PlotTheta myForm = (PlotTheta)this.Owner;//宣告一個myForm參考主視窗
            if (e.KeyCode == Keys.Enter)
            {
                try
                {
                    myForm.chart.ChartAreas["area"].AxisX.Minimum = Convert.ToDouble(TB_Theta_AxisX_Min.Text);
                    //TB_Theta_AxisX_Min.Text = " ";
                }
                catch
                {
                    MessageBox.Show("Please input correct number.");
                    TB_Theta_AxisX_Min.Text = " ";
                }
            }
        }
        private void TB_Theta_AxisX_Max_KeyDown(object sender, KeyEventArgs e)
        {
            PlotTheta myForm = (PlotTheta)this.Owner;//宣告一個myForm參考主視窗
            if (e.KeyCode == Keys.Enter)
            {
                try
                {

                    myForm.chart.ChartAreas["area"].AxisX.Maximum = Convert.ToDouble(TB_Theta_AxisX_Max.Text);
                    //TB_Theta_AxisX_Max.Text = " ";
                }
                catch
                {
                    MessageBox.Show("Please input correct number.");
                    TB_Theta_AxisX_Max.Text = " ";
                }
            }
        }
        private void SubFormTheta_but_axisX_send_Click(object sender, EventArgs e)
        {
           
            PlotTheta myForm = (PlotTheta)this.Owner;//宣告一個myForm參考主視窗
            myForm.chart.ChartAreas["area"].AxisX.Title = "Time(1ms)";//X軸文字說明

            int Num_X_Max = (((myForm.X_Max) / 1000) + 1) * 1000;
            myForm.chart.ChartAreas["area"].AxisX.Minimum = 0;
            myForm.chart.ChartAreas["area"].AxisX.Maximum = Num_X_Max;
            myForm.chart.ChartAreas["area"].AxisX.Interval = 500;

            TB_Theta_AxisX_Max.Text = Convert.ToString(myForm.chart.ChartAreas["area"].AxisX.Maximum);
            TB_Theta_AxisX_Min.Text = Convert.ToString(myForm.chart.ChartAreas["area"].AxisX.Minimum);
            TB_Theta_AxisX_Name.Text = myForm.chart.ChartAreas["area"].AxisX.Title;
        }

        private void TB_Theta_AxisY_Name_KeyDown(object sender, KeyEventArgs e)
        {
            PlotTheta myForm = (PlotTheta)this.Owner;//宣告一個myForm參考主視窗
            if (e.KeyCode == Keys.Enter)
            {
                try
                {
                    myForm.chart.ChartAreas["area"].AxisY.Title = TB_Theta_AxisY_Name.Text;

                    //TB_Theta_AxisY_Name.Text = " ";
                }
                catch
                {
                    MessageBox.Show("Please input correct number.");
                    TB_Theta_AxisY_Name.Text = " ";
                }
            }
        }
        private void TB_Theta_AxisY_Min_KeyDown(object sender, KeyEventArgs e)
        {
            PlotTheta myForm = (PlotTheta)this.Owner;//宣告一個myForm參考主視窗
            if (e.KeyCode == Keys.Enter)
            {
                try
                {
                    myForm.chart.ChartAreas["area"].AxisY.Minimum = Convert.ToDouble(TB_Theta_AxisY_Min.Text);
                    //TB_Theta_AxisY_Min.Text = " ";
                }
                catch
                {
                    MessageBox.Show("Please input correct number.");
                    TB_Theta_AxisY_Min.Text = " ";
                }
            }
        }
        private void TB_Theta_AxisY_Max_KeyDown(object sender, KeyEventArgs e)
        {
            PlotTheta myForm = (PlotTheta)this.Owner;//宣告一個myForm參考主視窗
            if (e.KeyCode == Keys.Enter)
            {
                try
                {

                    myForm.chart.ChartAreas["area"].AxisY.Maximum = Convert.ToDouble(TB_Theta_AxisY_Max.Text);
                   // TB_Theta_AxisY_Max.Text = " ";
                }
                catch
                {
                    MessageBox.Show("Please input correct number.");
                    TB_Theta_AxisY_Max.Text = " ";
                    
                }
            }
        }

        private void SubFormTheta_but_axisY_send_Click(object sender, EventArgs e)
        {
   
            PlotTheta myForm = (PlotTheta)this.Owner;//宣告一個myForm參考主視窗
            int Num_Y_Max = (((myForm.Y_Max) / 100) + 1) * 100;
            myForm.chart.ChartAreas["area"].AxisY.Title = "Theta(Degree)";//X軸文字說明
            myForm.chart.ChartAreas["area"].AxisY.Minimum = 0;
            myForm.chart.ChartAreas["area"].AxisY.Maximum = Num_Y_Max;
            myForm.chart.ChartAreas["area"].AxisY.Interval = 100;

            TB_Theta_AxisY_Max.Text = Convert.ToString(myForm.chart.ChartAreas["area"].AxisY.Maximum);
            TB_Theta_AxisY_Min.Text = Convert.ToString(myForm.chart.ChartAreas["area"].AxisY.Minimum);
            TB_Theta_AxisY_Name.Text = myForm.chart.ChartAreas["area"].AxisY.Title;
          
        }

        
        private void SubFormTheta_FormClosing(object sender, FormClosingEventArgs e)
        {
           // Form1_Chart myForm = (Form1_Chart)this.Owner;//宣告一個myForm參考主視窗
           // myForm.
            PlotTheta myForm = (PlotTheta)this.Owner;//宣告一個myForm參考主視窗
            myForm.ThetaFormShow_Flag = true;       
        }

        private void CB_Theta_MajorGridX_checkedchange(object sender, EventArgs e)
        {
            PlotTheta myForm = (PlotTheta)this.Owner;//宣告一個myForm參考主視窗
            if (Theta_GridFlag1)
            {
                Theta_GridFlag1 = false;
                myForm.chart.ChartAreas["area"].AxisX.MajorGrid.LineWidth = 0;
            }
            else
            {
                Theta_GridFlag1 = true;
                myForm.chart.ChartAreas["area"].AxisX.MajorGrid.LineWidth = 1;
            }
        }

        private void CB_Theta_MajorGridY_checkedchanged(object sender, EventArgs e)
        {
            PlotTheta myForm = (PlotTheta)this.Owner;//宣告一個myForm參考主視窗
            if (Theta_GridFlag2)
            {
                Theta_GridFlag2 = false;
                myForm.chart.ChartAreas["area"].AxisY.MajorGrid.LineWidth = 0;
            }
            else
            {
                Theta_GridFlag2 = true;
                myForm.chart.ChartAreas["area"].AxisY.MajorGrid.LineWidth = 1;
            }
        }

        private void SubForm_Theta_SettingAxis_Load(object sender, EventArgs e)
        {
            PlotTheta myForm = (PlotTheta)this.Owner;//宣告一個myForm參考主視窗
            TB_Theta_AxisY_Max.Text = Convert.ToString(myForm.chart.ChartAreas["area"].AxisY.Maximum);
            TB_Theta_AxisY_Min.Text = Convert.ToString(myForm.chart.ChartAreas["area"].AxisY.Minimum);
            TB_Theta_AxisY_Name.Text = myForm.chart.ChartAreas["area"].AxisY.Title;

            TB_Theta_AxisX_Max.Text = Convert.ToString(myForm.chart.ChartAreas["area"].AxisX.Maximum);
            TB_Theta_AxisX_Min.Text = Convert.ToString(myForm.chart.ChartAreas["area"].AxisX.Minimum);
            TB_Theta_AxisX_Name.Text = myForm.chart.ChartAreas["area"].AxisX.Title;

        }

        
    }
}

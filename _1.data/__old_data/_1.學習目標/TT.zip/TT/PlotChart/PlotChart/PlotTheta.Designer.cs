﻿namespace Plot
{
    partial class PlotTheta
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器
        /// 修改這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.chart = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.butn_Setting_theta = new System.Windows.Forms.Button();
            this.button_SavePic = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.chart)).BeginInit();
            this.SuspendLayout();
            // 
            // chartTheta
            // 
            this.chart.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.chart.Location = new System.Drawing.Point(12, 12);
            this.chart.Name = "chartTheta";
            this.chart.Size = new System.Drawing.Size(731, 531);
            this.chart.TabIndex = 4;
            this.chart.Text = "chartTheta";
            // 
            // butn_Setting_theta
            // 
            this.butn_Setting_theta.Location = new System.Drawing.Point(12, 549);
            this.butn_Setting_theta.Name = "butn_Setting_theta";
            this.butn_Setting_theta.Size = new System.Drawing.Size(149, 23);
            this.butn_Setting_theta.TabIndex = 2;
            this.butn_Setting_theta.Text = "Setting Chart_Theta";
            this.butn_Setting_theta.UseCompatibleTextRendering = true;
            this.butn_Setting_theta.UseVisualStyleBackColor = true;
            this.butn_Setting_theta.Click += new System.EventHandler(this.butn_Setting_theta_Click);
            // 
            // button_SavePic
            // 
            this.button_SavePic.Location = new System.Drawing.Point(167, 549);
            this.button_SavePic.Name = "button_SavePic";
            this.button_SavePic.Size = new System.Drawing.Size(110, 23);
            this.button_SavePic.TabIndex = 6;
            this.button_SavePic.Text = "Save Picture";
            this.button_SavePic.UseVisualStyleBackColor = true;
            this.button_SavePic.Click += new System.EventHandler(this.button_SavePic_Click);
            // 
            // PlotTheta
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(755, 574);
            this.Controls.Add(this.button_SavePic);
            this.Controls.Add(this.butn_Setting_theta);
            this.Controls.Add(this.chart);
            this.IsMdiContainer = true;
            this.MaximizeBox = false;
            this.Name = "PlotTheta";
            this.Text = "Chart";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.chart)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button butn_Setting_theta;
        public System.Windows.Forms.DataVisualization.Charting.Chart chart;
        private System.Windows.Forms.Button button_SavePic;
    }
}


﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
namespace Plot
{
    class TextFileToIntArry
    {
        // Set the path of text file
        public string FilePath { get; set; }
        public int ArrayRow { get; private set; }
        public int ArrayCol { get; private set; }
        public int ArrayTranRow { get; private set; }
        public int ArrayTranCol { get; private set; }
        public char[] seperator { get;  set; }
        public int[][] IntArray { get; private set; }
        public int[][] IntArrayTran { get; private set; }
        public double[]IntArrayAverage(int period,int dataCol)//移動平均
        {
            if (IntArray != null)
            {
                double[]arrayAverage = new double[IntArrayTran[dataCol].Length];
                for (int i = 0; i < ArrayTranCol; i++)
                {
                    if (i < period - 1)
                    {
                        arrayAverage[i] = 0;//int.MaxValue;
                    }
                    else
                    {
                        double AvgTemp = 0;
                        
                       try
                        {
                            for (int j = i - period + 1; j <= i; j++)
                            {
                                AvgTemp += (double)IntArrayTran[dataCol][j];

                            }
                            if (period > 1)
                                AvgTemp /= (double)period;

                            arrayAverage[i] = AvgTemp;
                        }
                        catch
                        {
                            arrayAverage[i] = 0;
                        }
                    
                    }

      
                }
           
                return arrayAverage;
            }
            else
                return null;
        }

        public int[][] IntArrayTranspose()
        {

            if (IntArray != null)
            {
                int[][] arrayTranpose = new int[ArrayCol][];
                for (int i = 0; i < ArrayCol; i++)
                {
                    arrayTranpose[i] = new int[ArrayRow];
                    for (int j = 0; j < ArrayRow; j++)
                        arrayTranpose[i][j] = IntArray[j][i];
                }
                ArrayTranCol = ArrayRow;
                ArrayTranRow = ArrayCol;
                IntArrayTran = new int[ArrayCol][];
                IntArrayTran = arrayTranpose;
                return arrayTranpose;
            }
            else
                return null;

        }
        public string[] StringArray { get; private set; }
        private int[] stringArrToIntArr(string inputString)
        {
            if (seperator == null) seperator = new Char[] { ' ', ',', ':', '\t' };
            string[] tmpStrSplit = inputString.Split(seperator);
            int[] tempIntArray = new int[tmpStrSplit.Length];
            for (int i = 0; i < tmpStrSplit.Length; i++)
            {
               
                try
                {
                    tempIntArray[i] = (int)Convert.ToDouble(tmpStrSplit[i]);
                }
                catch (Exception err)
                {
                    Console.WriteLine(err.Message);
                }
            }
            return tempIntArray;
        }
      
        //True: Success to Read a File and turn into int array
        public bool ReadTextToIntArray()
        {
            if (File.Exists(FilePath))
            {
                Queue<string> stringArrQ = new Queue<string>();

                using (StreamReader sr = new StreamReader(FilePath))
                {
                    while (sr.Peek() > 0)
                    {
                        string stringRead = sr.ReadLine();
                        if (string.IsNullOrEmpty(stringRead) == false)                            
                            stringArrQ.Enqueue(stringRead);
                    }
                }

                StringArray = new string[stringArrQ.Count];
                for (int i = 0; i < StringArray.Length; i++)
                    StringArray[i] = stringArrQ.Dequeue();

                IntArray = new int[StringArray.Length][];
                for (int i = 0; i < StringArray.Length; i++)
                    IntArray[i] = stringArrToIntArr(StringArray[i]);
                int maxCol = 0;
                for (int i = 0; i < IntArray.Length; i++)
                    if (IntArray[i].Length > maxCol) maxCol = IntArray[i].Length;

                ArrayCol = maxCol;

                for (int i = 0; i < IntArray.Length; i++ )
                    if (IntArray[i].Length < maxCol)
                    {
                        int[] tempIntArray = new int[IntArray[i].Length];
                        tempIntArray = IntArray[i];
                        int[] intArrayReplace = new int[maxCol];
                        for (int j = 0; j < tempIntArray.Length; j++)
                            intArrayReplace[j] = tempIntArray[j];
                        IntArray[i] = intArrayReplace;
                    }
                    ArrayRow = IntArray.Length;
                return true;
            }
            else
            {
                ArrayCol = 0;
                ArrayRow = 0;
                return false;
            }


        }
    }
}

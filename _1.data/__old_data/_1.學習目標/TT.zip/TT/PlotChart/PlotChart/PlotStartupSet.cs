﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;
namespace Plot
{
    public partial class SubForm_Startup_SettingAxis : Form
    {
        private bool Startup_GridFlag1 = true;
        private bool Startup_GridFlag2 = true;
        private bool Startup_GridFlag3 = true;
    
        public SubForm_Startup_SettingAxis()
        {
            InitializeComponent();
           
        }

        private void CB_MajorGridX_CheckedChanged(object sender, EventArgs e)
        {
            PlotStartup myForm = (PlotStartup)this.Owner;//宣告一個myForm參考主視窗
            if (Startup_GridFlag1)
            {
                Startup_GridFlag1 = false;
                myForm.chart_Startup.ChartAreas["area"].AxisX.MajorGrid.LineWidth = 0;
            }
            else
            {
                Startup_GridFlag1 = true;
                myForm.chart_Startup.ChartAreas["area"].AxisX.MajorGrid.LineWidth = 1;
            }
        }
        private void CB_MajorGridY1_CheckedChanged(object sender, EventArgs e)
        {
            PlotStartup myForm = (PlotStartup)this.Owner;//宣告一個myForm參考主視窗
            if (Startup_GridFlag2)
            {
                Startup_GridFlag2 = false;
                myForm.chart_Startup.ChartAreas["area"].AxisY.MajorGrid.LineWidth = 0;
            }
            else
            {
                Startup_GridFlag2 = true;
                myForm.chart_Startup.ChartAreas["area"].AxisY.MajorGrid.LineWidth = 1;
            }
        }
        private void CB_MajorGridY2_CheckedChanged(object sender, EventArgs e)
        {
            PlotStartup myForm = (PlotStartup)this.Owner;//宣告一個myForm參考主視窗
            if (Startup_GridFlag3)
            {
                Startup_GridFlag3 = false;
                myForm.chart_Startup.ChartAreas["area"].AxisY2.MajorGrid.LineWidth = 0;
            }
            else
            {
                Startup_GridFlag3 = true;
                myForm.chart_Startup.ChartAreas["area"].AxisY2.MajorGrid.LineWidth = 1;
            }
        }

        private void KeyDown_TB_AxisX_Name(object sender, KeyEventArgs e)
        {  
            PlotStartup myForm = (PlotStartup)this.Owner;//宣告一個myForm參考主視窗
            if (e.KeyCode == Keys.Enter)
            {
                 try
                {
                    myForm.chart_Startup.ChartAreas["area"].AxisX.Title = Form2_TB_AxisX_Name.Text;
                   // Form2_TB_AxisX_Name.Text = " ";
                }
                catch
                {
                    MessageBox.Show("Please input correct number.");
                    Form2_TB_AxisX_Name.Text = " ";
                }
            }
        }
        private void KeyDown_TB_AxisY1_Name(object sender, KeyEventArgs e)
        {
            PlotStartup myForm = (PlotStartup)this.Owner;//宣告一個myForm參考主視窗
            if (e.KeyCode == Keys.Enter)
            {
                try
                {
                    myForm.chart_Startup.ChartAreas["area"].AxisY.Title = Form2_TB_AxisY1_Name.Text;
                  //  Form2_TB_AxisY1_Name.Text = " ";
                }
                catch
                {
                    MessageBox.Show("Please input correct number.");
                    Form2_TB_AxisY1_Name.Text = " ";
                }
            }

        }
        private void KeyDown_TB_AxisY2_Name(object sender, KeyEventArgs e)
        {
            PlotStartup myForm = (PlotStartup)this.Owner;//宣告一個myForm參考主視窗
            if (e.KeyCode == Keys.Enter)
            {
                try
                {
                    myForm.chart_Startup.ChartAreas["area"].AxisY2.Title = Form2_TB_AxisY2_Name.Text;
                   // Form2_TB_AxisY2_Name.Text = " ";
                }
                catch
                {
                    MessageBox.Show("Please input correct number.");
                    Form2_TB_AxisY2_Name.Text = " ";
                }
            }
        }

        private void KeyDown_TB_AxisX_Min(object sender, KeyEventArgs e)
        {
           PlotStartup myForm = (PlotStartup)this.Owner;//宣告一個myForm參考主視窗
           if (e.KeyCode == Keys.Enter)
           {
               try
               {
                   myForm.chart_Startup.ChartAreas["area"].AxisX.Minimum = Convert.ToDouble(Form2_TB_AxisX_Min.Text);
                  // Form2_TB_AxisX_Min.Text = " ";
               }
               catch
               {
                   MessageBox.Show("Please input correct number.");
                   Form2_TB_AxisX_Min.Text = " ";
               }
           }
        }
        private void KeyDown_TB_AxisX_Max(object sender, KeyEventArgs e)
        {
            PlotStartup myForm = (PlotStartup)this.Owner;//宣告一個myForm參考主視窗
            if (e.KeyCode == Keys.Enter)
            {
                try
                {
                    myForm.chart_Startup.ChartAreas["area"].AxisX.Maximum = Convert.ToDouble(Form2_TB_AxisX_Max.Text);
                    // Form2_TB_AxisX_Max.Text = " ";
                }
                catch
                {
                    MessageBox.Show("Please input correct number.");
                    Form2_TB_AxisX_Max.Text = " ";
                }
            }
        }

        private void KeyDown_TB_AxisY_Max(object sender, KeyEventArgs e)
        {
            PlotStartup myForm = (PlotStartup)this.Owner;//宣告一個myForm參考主視窗
            if (e.KeyCode == Keys.Enter)
            {
                try
                {
                    myForm.chart_Startup.ChartAreas["area"].AxisY.Maximum = Convert.ToDouble(Form2_TB_AxisY_Max.Text);
                   // Form2_TB_AxisY_Max.Text = " ";
                }
                catch
                {
                    MessageBox.Show("Please input correct number.");
                    Form2_TB_AxisY_Max.Text = " ";
                }
                
            }
        }
        private void KeyDown_TB_AxisY_Min(object sender, KeyEventArgs e)
        {
            PlotStartup myForm = (PlotStartup)this.Owner;//宣告一個myForm參考主視窗
            if (e.KeyCode == Keys.Enter)
            {
                try
                {
                    myForm.chart_Startup.ChartAreas["area"].AxisY.Minimum = Convert.ToDouble(Form2_TB_AxisY_Min.Text);
                    //Form2_TB_AxisY_Min.Text = " ";
                }
                catch
                {
                    MessageBox.Show("Please input correct number.");
                    Form2_TB_AxisY_Min.Text = " ";
                }

            }
        }

        private void KeyDown_TB_AxisY2_Min(object sender, KeyEventArgs e)
        {

    
            if (e.KeyCode == Keys.Enter)
            {
                PlotStartup myForm = (PlotStartup)this.Owner;//宣告一個myForm參考主視窗
                try
                {
                    myForm.chart_Startup.ChartAreas["area"].AxisY2.Minimum = Convert.ToDouble(Form2_TB_AxisY2_Min.Text);
                   // Form2_TB_AxisY2_Min.Text = " ";
                    
                }
                catch
                {
                    MessageBox.Show("Please input correct number.");
                    Form2_TB_AxisY2_Min.Text = " ";
                }
            }
        }
        private void KeyDown_TB_AxisY2_Max(object sender, KeyEventArgs e)
        {  
            PlotStartup myForm = (PlotStartup)this.Owner;//宣告一個myForm參考主視窗
            if (e.KeyCode == Keys.Enter)
            {
                try
                {
                    myForm.chart_Startup.ChartAreas["area"].AxisY2.Maximum = Convert.ToDouble(Form2_TB_AxisY2_Max.Text);
                   // Form2_TB_AxisY2_Max.Text = " ";
                }
                catch
                {
                    MessageBox.Show("Please input correct number.");
                    Form2_TB_AxisY2_Max.Text = " ";
                }
            }
        }
        #region Initialize Axis Button
        private void but_axisX_send_Click(object sender, EventArgs e)
        {
            PlotStartup myForm = (PlotStartup)this.Owner;//宣告一個myForm參考主視窗
            myForm.chart_Startup.ChartAreas["area"].AxisX.Title = myForm.AxisName[0];//X軸文字說明
            int Num_XMax = (((myForm.X_Max) / 1000) + 1) * 1000;

            myForm.chart_Startup.ChartAreas["area"].AxisX.Minimum = 0;
            myForm.chart_Startup.ChartAreas["area"].AxisX.Maximum = Num_XMax;
            myForm.chart_Startup.ChartAreas["area"].AxisX.Interval = 100;

            Form2_TB_AxisX_Max.Text = Convert.ToString(myForm.chart_Startup.ChartAreas["area"].AxisX.Maximum);
            Form2_TB_AxisX_Min.Text = Convert.ToString(myForm.chart_Startup.ChartAreas["area"].AxisX.Minimum);
            Form2_TB_AxisX_Name.Text = myForm.chart_Startup.ChartAreas["area"].AxisX.Title;

        }
        private void but_axisY_send_Click(object sender, EventArgs e)
        {
            PlotStartup myForm = (PlotStartup)this.Owner;//宣告一個myForm參考主視窗
            myForm.chart_Startup.ChartAreas["area"].AxisY.Title = myForm.AxisName[1];//Y1軸文字說明
            int Num_YMax = (((myForm.Y_Max) / 10) + 1) * 10;

            myForm.chart_Startup.ChartAreas["area"].AxisY.Minimum = 0;
            myForm.chart_Startup.ChartAreas["area"].AxisY.Maximum = Num_YMax;

            Form2_TB_AxisY_Max.Text = Convert.ToString(myForm.chart_Startup.ChartAreas["area"].AxisY.Maximum);
            Form2_TB_AxisY_Min.Text = Convert.ToString(myForm.chart_Startup.ChartAreas["area"].AxisY.Minimum);
            Form2_TB_AxisY1_Name.Text = myForm.chart_Startup.ChartAreas["area"].AxisY.Title;

        }
        private void but_axisY2_send_Click(object sender, EventArgs e)
        {
            PlotStartup myForm = (PlotStartup)this.Owner;//宣告一個myForm參考主視窗
            myForm.chart_Startup.ChartAreas["area"].AxisY2.Title = myForm.AxisName[2];//Y2軸文字說明
            int Num_Y2Max = (((myForm.Y2_Max) / 10) + 1) * 10;

            myForm.chart_Startup.ChartAreas["area"].AxisY2.Minimum = 0;
            myForm.chart_Startup.ChartAreas["area"].AxisY2.Maximum = Num_Y2Max;

            Form2_TB_AxisY2_Max.Text = Convert.ToString(myForm.chart_Startup.ChartAreas["area"].AxisY2.Maximum);
            Form2_TB_AxisY2_Min.Text = Convert.ToString(myForm.chart_Startup.ChartAreas["area"].AxisY2.Minimum);
            Form2_TB_AxisY2_Name.Text = myForm.chart_Startup.ChartAreas["area"].AxisY2.Title;

        }
        #endregion

        private void SubFormStartup_FormClosing(object sender, FormClosedEventArgs e)
        {
            PlotStartup myForm = (PlotStartup)this.Owner;//宣告一個myForm參考主視窗
            myForm.StartupFormShow_Flag = true;       
        }

        private void SubForm_Startup_SettingAxis_Load(object sender, EventArgs e)
        {
            PlotStartup myForm = (PlotStartup)this.Owner;//宣告一個myForm參考主視窗
            Form2_TB_AxisY2_Max.Text = Convert.ToString(myForm.chart_Startup.ChartAreas["area"].AxisY2.Maximum);
            Form2_TB_AxisY2_Min.Text = Convert.ToString(myForm.chart_Startup.ChartAreas["area"].AxisY2.Minimum);
            Form2_TB_AxisY2_Name.Text = myForm.chart_Startup.ChartAreas["area"].AxisY2.Title;

            Form2_TB_AxisY_Max.Text = Convert.ToString(myForm.chart_Startup.ChartAreas["area"].AxisY.Maximum);
            Form2_TB_AxisY_Min.Text = Convert.ToString(myForm.chart_Startup.ChartAreas["area"].AxisY.Minimum);
            Form2_TB_AxisY1_Name.Text = myForm.chart_Startup.ChartAreas["area"].AxisY.Title;

            Form2_TB_AxisX_Max.Text = Convert.ToString(myForm.chart_Startup.ChartAreas["area"].AxisX.Maximum);
            Form2_TB_AxisX_Min.Text = Convert.ToString(myForm.chart_Startup.ChartAreas["area"].AxisX.Minimum);
            Form2_TB_AxisX_Name.Text = myForm.chart_Startup.ChartAreas["area"].AxisX.Title;
        }
    }
}

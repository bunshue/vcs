﻿namespace Plot
{
    partial class SubForm_Theta_SettingAxis
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.SubFormTheta_but_axisY_send = new System.Windows.Forms.Button();
            this.TB_Theta_AxisY_Max = new System.Windows.Forms.TextBox();
            this.TB_Theta_AxisY_Min = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.TB_Theta_AxisY_Name = new System.Windows.Forms.TextBox();
            this.CB_Theta_MajorGridY = new System.Windows.Forms.CheckBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.SubFormTheta_but_axisX_send = new System.Windows.Forms.Button();
            this.TB_Theta_AxisX_Max = new System.Windows.Forms.TextBox();
            this.CB_Theta_MajorGridX = new System.Windows.Forms.CheckBox();
            this.TB_Theta_AxisX_Min = new System.Windows.Forms.TextBox();
            this.TB_Theta_AxisX_Name = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.Lab_AxisX = new System.Windows.Forms.Label();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.SubFormTheta_but_axisY_send);
            this.groupBox2.Controls.Add(this.TB_Theta_AxisY_Max);
            this.groupBox2.Controls.Add(this.TB_Theta_AxisY_Min);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.TB_Theta_AxisY_Name);
            this.groupBox2.Controls.Add(this.CB_Theta_MajorGridY);
            this.groupBox2.Location = new System.Drawing.Point(219, 12);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(201, 147);
            this.groupBox2.TabIndex = 3;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Y  Setting";
            // 
            // SubFormTheta_but_axisY_send
            // 
            this.SubFormTheta_but_axisY_send.Location = new System.Drawing.Point(111, 114);
            this.SubFormTheta_but_axisY_send.Name = "SubFormTheta_but_axisY_send";
            this.SubFormTheta_but_axisY_send.Size = new System.Drawing.Size(75, 23);
            this.SubFormTheta_but_axisY_send.TabIndex = 4;
            this.SubFormTheta_but_axisY_send.Text = "Initialize";
            this.SubFormTheta_but_axisY_send.UseVisualStyleBackColor = true;
            this.SubFormTheta_but_axisY_send.Click += new System.EventHandler(this.SubFormTheta_but_axisY_send_Click);
            // 
            // TB_Theta_AxisY_Max
            // 
            this.TB_Theta_AxisY_Max.Location = new System.Drawing.Point(96, 80);
            this.TB_Theta_AxisY_Max.Name = "TB_Theta_AxisY_Max";
            this.TB_Theta_AxisY_Max.Size = new System.Drawing.Size(90, 22);
            this.TB_Theta_AxisY_Max.TabIndex = 3;
            this.TB_Theta_AxisY_Max.KeyDown += new System.Windows.Forms.KeyEventHandler(this.TB_Theta_AxisY_Max_KeyDown);
            // 
            // TB_Theta_AxisY_Min
            // 
            this.TB_Theta_AxisY_Min.Location = new System.Drawing.Point(96, 52);
            this.TB_Theta_AxisY_Min.Name = "TB_Theta_AxisY_Min";
            this.TB_Theta_AxisY_Min.Size = new System.Drawing.Size(90, 22);
            this.TB_Theta_AxisY_Min.TabIndex = 1;
            this.TB_Theta_AxisY_Min.KeyDown += new System.Windows.Forms.KeyEventHandler(this.TB_Theta_AxisY_Min_KeyDown);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 62);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(84, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "Range Minimum";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 90);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(86, 12);
            this.label2.TabIndex = 0;
            this.label2.Text = "Range Maximum";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(31, 37);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(32, 12);
            this.label3.TabIndex = 0;
            this.label3.Text = "Name";
            // 
            // TB_Theta_AxisY_Name
            // 
            this.TB_Theta_AxisY_Name.Location = new System.Drawing.Point(95, 24);
            this.TB_Theta_AxisY_Name.Name = "TB_Theta_AxisY_Name";
            this.TB_Theta_AxisY_Name.Size = new System.Drawing.Size(91, 22);
            this.TB_Theta_AxisY_Name.TabIndex = 1;
            this.TB_Theta_AxisY_Name.KeyDown += new System.Windows.Forms.KeyEventHandler(this.TB_Theta_AxisY_Name_KeyDown);
            // 
            // CB_Theta_MajorGridY
            // 
            this.CB_Theta_MajorGridY.AutoSize = true;
            this.CB_Theta_MajorGridY.Checked = true;
            this.CB_Theta_MajorGridY.CheckState = System.Windows.Forms.CheckState.Checked;
            this.CB_Theta_MajorGridY.Location = new System.Drawing.Point(8, 114);
            this.CB_Theta_MajorGridY.Name = "CB_Theta_MajorGridY";
            this.CB_Theta_MajorGridY.Size = new System.Drawing.Size(45, 16);
            this.CB_Theta_MajorGridY.TabIndex = 2;
            this.CB_Theta_MajorGridY.Text = "Grid";
            this.CB_Theta_MajorGridY.UseVisualStyleBackColor = true;
            this.CB_Theta_MajorGridY.CheckedChanged += new System.EventHandler(this.CB_Theta_MajorGridY_checkedchanged);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.SubFormTheta_but_axisX_send);
            this.groupBox1.Controls.Add(this.TB_Theta_AxisX_Max);
            this.groupBox1.Controls.Add(this.CB_Theta_MajorGridX);
            this.groupBox1.Controls.Add(this.TB_Theta_AxisX_Min);
            this.groupBox1.Controls.Add(this.TB_Theta_AxisX_Name);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.Lab_AxisX);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(201, 147);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "X  Setting";
            // 
            // SubFormTheta_but_axisX_send
            // 
            this.SubFormTheta_but_axisX_send.Location = new System.Drawing.Point(111, 114);
            this.SubFormTheta_but_axisX_send.Name = "SubFormTheta_but_axisX_send";
            this.SubFormTheta_but_axisX_send.Size = new System.Drawing.Size(75, 23);
            this.SubFormTheta_but_axisX_send.TabIndex = 4;
            this.SubFormTheta_but_axisX_send.Text = "Initialize";
            this.SubFormTheta_but_axisX_send.UseVisualStyleBackColor = true;
            this.SubFormTheta_but_axisX_send.Click += new System.EventHandler(this.SubFormTheta_but_axisX_send_Click);
            // 
            // TB_Theta_AxisX_Max
            // 
            this.TB_Theta_AxisX_Max.Location = new System.Drawing.Point(96, 80);
            this.TB_Theta_AxisX_Max.Name = "TB_Theta_AxisX_Max";
            this.TB_Theta_AxisX_Max.Size = new System.Drawing.Size(90, 22);
            this.TB_Theta_AxisX_Max.TabIndex = 3;
            this.TB_Theta_AxisX_Max.KeyDown += new System.Windows.Forms.KeyEventHandler(this.TB_Theta_AxisX_Max_KeyDown);
            // 
            // CB_Theta_MajorGridX
            // 
            this.CB_Theta_MajorGridX.Checked = true;
            this.CB_Theta_MajorGridX.CheckState = System.Windows.Forms.CheckState.Checked;
            this.CB_Theta_MajorGridX.Location = new System.Drawing.Point(8, 118);
            this.CB_Theta_MajorGridX.Name = "CB_Theta_MajorGridX";
            this.CB_Theta_MajorGridX.Size = new System.Drawing.Size(45, 16);
            this.CB_Theta_MajorGridX.TabIndex = 2;
            this.CB_Theta_MajorGridX.Text = "Grid";
            this.CB_Theta_MajorGridX.UseVisualStyleBackColor = true;
            this.CB_Theta_MajorGridX.CheckedChanged += new System.EventHandler(this.CB_Theta_MajorGridX_checkedchange);
            // 
            // TB_Theta_AxisX_Min
            // 
            this.TB_Theta_AxisX_Min.Location = new System.Drawing.Point(96, 52);
            this.TB_Theta_AxisX_Min.Name = "TB_Theta_AxisX_Min";
            this.TB_Theta_AxisX_Min.Size = new System.Drawing.Size(90, 22);
            this.TB_Theta_AxisX_Min.TabIndex = 1;
       
            this.TB_Theta_AxisX_Min.KeyDown += new System.Windows.Forms.KeyEventHandler(this.TB_Theta_AxisX_Min_KeyDown);
            // 
            // TB_Theta_AxisX_Name
            // 
            this.TB_Theta_AxisX_Name.Location = new System.Drawing.Point(96, 27);
            this.TB_Theta_AxisX_Name.Name = "TB_Theta_AxisX_Name";
            this.TB_Theta_AxisX_Name.Size = new System.Drawing.Size(90, 22);
            this.TB_Theta_AxisX_Name.TabIndex = 1;
            this.TB_Theta_AxisX_Name.KeyDown += new System.Windows.Forms.KeyEventHandler(this.TB_Theta_AxisX_Name_KeyDown);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(6, 62);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(84, 12);
            this.label8.TabIndex = 0;
            this.label8.Text = "Range Minimum";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(6, 90);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(86, 12);
            this.label5.TabIndex = 0;
            this.label5.Text = "Range Maximum";
            // 
            // Lab_AxisX
            // 
            this.Lab_AxisX.AutoSize = true;
            this.Lab_AxisX.Location = new System.Drawing.Point(31, 37);
            this.Lab_AxisX.Name = "Lab_AxisX";
            this.Lab_AxisX.Size = new System.Drawing.Size(32, 12);
            this.Lab_AxisX.TabIndex = 0;
            this.Lab_AxisX.Text = "Name";
            // 
            // SubForm_Theta_SettingAxis
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(427, 161);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "SubForm_Theta_SettingAxis";
            this.Text = "SubFormTheta_SettingAxis";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.SubFormTheta_FormClosing);
            this.Load += new System.EventHandler(this.SubForm_Theta_SettingAxis_Load);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button SubFormTheta_but_axisY_send;
        private System.Windows.Forms.TextBox TB_Theta_AxisY_Max;
        private System.Windows.Forms.TextBox TB_Theta_AxisY_Min;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox TB_Theta_AxisY_Name;
        private System.Windows.Forms.CheckBox CB_Theta_MajorGridY;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button SubFormTheta_but_axisX_send;
        private System.Windows.Forms.TextBox TB_Theta_AxisX_Max;
        private System.Windows.Forms.CheckBox CB_Theta_MajorGridX;
        private System.Windows.Forms.TextBox TB_Theta_AxisX_Min;
        private System.Windows.Forms.TextBox TB_Theta_AxisX_Name;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label Lab_AxisX;
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
namespace Plot
{
    class TextFileToIntArry
    {
        // Set the path of text file
        public string FilePath { get; set; }
        public int ArrayRow { get; private set; }
        public int ArrayCol { get; private set; }
        public int ArrayTranRow { get; private set; }
        public int ArrayTranCol { get; private set; }
        public char[] seperator { get;  set; }
        public int[][] IntArray { get; private set; }
        public int[][] IntArrayTran { get; private set; }
        public double[]IntArrayAverage(int period,int dataCol)//移動平均
        {
            
          //  int index = 0;
            if (IntArray != null)
            {
                double[]arrayAverage = new double[IntArrayTran[dataCol].Length];

                //for (int i = 0; i < ArrayTranRow; i++)
                //{
                //    arrayAverage[i] = new int[ArrayTranCol];
                //}


                for (int i = 0; i < ArrayTranCol; i++)
                {
                    if (i < period - 1)
                    {
                        arrayAverage[i] = 0;//int.MaxValue;
                    }
                    else
                    {
                        double AvgTemp = 0;
                        for (int j = i - period + 1; j <= i; j++)
                        {
                            AvgTemp += (double)IntArrayTran[dataCol][j];
                           // Console.WriteLine("i=" + i);
                         //   Console.WriteLine("dataCol=" + dataCol + " j=" + j + " AvgTemp="+ AvgTemp);
                        }
                        if (period > 1)
                          AvgTemp /= (double) period;

                   //  Console.WriteLine(i.ToString()+" "+ AvgTemp.ToString());
                        arrayAverage[i] = AvgTemp;
                    }

                    int k = 0;

                    /*for (int j = (i+period); j > (j-period); j--)
                      {
                          if (j > ArrayRow)
                              break;
                          AvgTemp = AvgTemp + IntArray[dataCol][j];
                          index = j;
                      }
                     * */
                    //  arrayAverage[dataCol][index] = AvgTemp;
                }
            //   * */
                return arrayAverage;
            }
            else
                return null;
        }

        public int[][] IntArrayTranspose()
        {

            if (IntArray != null)
            {
                int[][] arrayTranpose = new int[ArrayCol][];
                for (int i = 0; i < ArrayCol; i++)
                {
                    arrayTranpose[i] = new int[ArrayRow];
                    for (int j = 0; j < ArrayRow; j++)
                        arrayTranpose[i][j] = IntArray[j][i];
                }
                ArrayTranCol = ArrayRow;
                ArrayTranRow = ArrayCol;
                IntArrayTran = new int[ArrayCol][];
                IntArrayTran = arrayTranpose;
                return arrayTranpose;
            }
            else
                return null;

        }
        public string[] StringArray { get; private set; }
        private int[] stringArrToIntArr(string inputString)
        {
            if (seperator == null) seperator = new Char[] { ' ', ',', ':', '\t' };
            string[] tmpStrSplit = inputString.Split(seperator);
            int[] tempIntArray = new int[tmpStrSplit.Length];
            for (int i = 0; i < tmpStrSplit.Length; i++)
            {
                try
                {
                    tempIntArray[i] = (int)Convert.ToDouble(tmpStrSplit[i]);
                }
                catch (Exception err)
                {
                    Console.WriteLine(err.Message);
                }
            }
            return tempIntArray;
        }
        private double[] stringArrToDoubleArr(string inputString)
        {
            if (seperator == null) seperator = new Char[] { ' ', ',', ':', '\t' };
            string[] tmpStrSplit = inputString.Split(seperator);
            double[] tempIntArray = new double[tmpStrSplit.Length];
            for (int i = 0; i < tmpStrSplit.Length; i++)
            {
                try
                {
                    tempIntArray[i] = Convert.ToDouble(tmpStrSplit[i]);
                }
                catch (Exception err)
                {
                    Console.WriteLine(err.Message);
                }
            }
            return tempIntArray;
        }
        //True: Success to Read a File and turn into int array
        public bool ReadTextToIntArray()
        {
            if (File.Exists(FilePath))
            {
                Queue<string> stringArrQ = new Queue<string>();

                using (StreamReader sr = new StreamReader(FilePath))
                {
                    while (sr.Peek() > 0)
                    {
                        string stringRead = sr.ReadLine();
                        if (string.IsNullOrEmpty(stringRead))
                            continue;
                        else
                            stringArrQ.Enqueue(stringRead);
                    }
                }

                StringArray = new string[stringArrQ.Count];
                for (int i = 0; i < StringArray.Length; i++)
                    StringArray[i] = stringArrQ.Dequeue();

                IntArray = new int[StringArray.Length][];
                for (int i = 0; i < StringArray.Length; i++)
                    IntArray[i] = stringArrToIntArr(StringArray[i]);

                ArrayCol = IntArray[0].Length;
                ArrayRow = IntArray.Length;
                return true;
            }
            else
            {
                ArrayCol = 0;
                ArrayRow = 0;
                return false;
            }


        }
    }
}

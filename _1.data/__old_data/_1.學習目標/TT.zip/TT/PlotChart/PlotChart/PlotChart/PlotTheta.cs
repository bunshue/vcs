﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;
using System.IO;
using System.Runtime.InteropServices;

namespace Plot
{
    public partial class PlotTheta : Form
    {
        public PlotTheta()
        {
            InitializeComponent();
        }
        public String ThetaRcdFilePath { get; set; }
        public String[] AxisName = new String[] { "Time(10 ms)", "Rotational Speed(0.1 RPS) ", "Current Is(0.1A)" };
        public int ChartThta_X_Max, ChartThta_X_Min, ChartThta_Y_Max, ChartThta_Y_Min;
        public int ChartStartup_X_Max, ChartStartup_X_Min, ChartStartup_Y_Max, ChartStartup_Y_Min, ChartStartup_Y2_Max, ChartStartup_Y2_Min;
        private void ChartThta_Show()
        {
            OpenFileDialog oFD = new OpenFileDialog();
            TextFileToIntArry textToIntArr = new TextFileToIntArry();
            //string filePathString = Path.Combine(Directory.GetCurrentDirectory(), "IntArray_Theta.txt");
           // string filePathString = ThetaRcdFilePath;
            textToIntArr.FilePath = ThetaRcdFilePath;
            textToIntArr.seperator = new Char[] { ' ', ',', ':', '\t' };
            textToIntArr.ReadTextToIntArray();
           
            int[][] DataGroupArray = new int[textToIntArr.ArrayCol][];
            DataGroupArray = textToIntArr.IntArrayTranspose();
         
        //    double[] test = textToIntArr.IntArrayAverage(3, 2);


            ChartThta_X_Max = DataGroupArray[0].Max();
            ChartThta_X_Min = DataGroupArray[0].Min();

            ChartThta_Y_Max = DataGroupArray[1].Max();
            ChartThta_Y_Min = DataGroupArray[1].Min();



            //ChartAreas, Series, Legends基本設定--------------------------------------------
            // Chart chart1 = new Chart();   //目前測試會error
            chartTheta.ChartAreas.Add("area");//圖表區域集合
            chartTheta.Series.Add("Theta"); //數據序列集合(Phase)
            chartTheta.Legends.Add("Legends1"); //圖例集合


            //設定Chart    ---------------------------------------------------------------------------
            //chartTheta.Width = 630;
            //chartTheta.Height = 460;
            Title title = new Title();
            title.Text = "Theta  Analytics";
            title.Alignment = ContentAlignment.MiddleCenter;
            title.Font = new System.Drawing.Font("Times New Roman ", 14F, FontStyle.Bold);
            chartTheta.Titles.Add(title);


            //設定 ChartArea--------------------------------------------------------------------------
            //chart2.ChartAreas["area"].BackColor = Color.White; //設定背景顏色
           chartTheta.ChartAreas["area"].AxisX.Minimum = ChartThta_X_Min;
         // chartTheta.ChartAreas["area"].AxisX.Maximum = X_Max;
            chartTheta.ChartAreas["area"].AxisX.Interval = 500;

            //chart2.ChartAreas["area"].AxisY.Minimum = Y_Min;
            //chart2.ChartAreas["area"].AxisY.Maximum = Y_Max;
            //chart2.ChartAreas["area"].AxisY.Interval = 100;

            //chart2.ChartAreas["area"].AxisY2.Minimum = Y2_Min;
            //chart2.ChartAreas["area"].AxisY2.Maximum = Y2_Max;
            //chart2.ChartAreas["area"].AxisY2.Interval = 2;

            chartTheta.ChartAreas["area"].AxisX.MajorGrid.LineColor = Color.Black; //X軸線的顏色
            chartTheta.ChartAreas["area"].AxisY.MajorGrid.LineColor = Color.Black;//Y軸線的顏色
      

            chartTheta.ChartAreas["area"].AxisX.Title = "Time(1 ms)";//X軸文字說明
            chartTheta.ChartAreas["area"].AxisY.Title = "Theta(Degree)";//Y1軸文字說明
          

            chartTheta.ChartAreas["area"].AxisX.TitleFont = new System.Drawing.Font("Times New Roman ", 10F, System.Drawing.FontStyle.Regular);
            chartTheta.ChartAreas["area"].AxisY.TitleFont = new System.Drawing.Font("Times New Roman ", 10F, System.Drawing.FontStyle.Regular);
          

            //設定 Legends--------------------------------------------------------------------------
            chartTheta.Legends["Legends1"].DockedToChartArea = "area";  ////顯示在圖表內
            chartTheta.Legends["Legends1"].Docking = Docking.Left; //自訂顯示位置
            chartTheta.Legends["Legends1"].BackColor = Color.WhiteSmoke;
            chartTheta.Legends["Legends1"].BackHatchStyle = ChartHatchStyle.DarkDownwardDiagonal; //背景採用斜線

            //chart2.Legends["Legends1"].BorderWidth = 1; //設定Legends的邊框
            //chart2.Legends["Legends1"].BorderColor = Color.FromArgb(200, 200, 200);/設定Legends邊框的顏色


            //設定 Series--------------------------------------------------------------------------
            chartTheta.Series["Theta"].ChartType = SeriesChartType.Line; 
            chartTheta.Series["Theta"].Color = Color.Blue;

            chartTheta.Series["Theta"].YAxisType = AxisType.Primary;

            chartTheta.Series["Theta"].Legend = "Legends1";

            chartTheta.Series["Theta"].LegendText = "Theta"; //設定折線圖的名字
          

            //畫出XY座標
            for (int i = 0; i < DataGroupArray[0].Length; i++)
            {
                chartTheta.Series["Theta"].Points.AddXY(DataGroupArray[0][i], DataGroupArray[1][i]);//Theta
              
            }  
        }
       
        private void Form1_Load(object sender, EventArgs e)
        {
            ThetaRcdFilePath = Path.Combine(Directory.GetCurrentDirectory(), "IntArray_Theta.txt");
            ChartThta_Show();
        }

      
        [DllImport("user32")]
        public static extern int SetParent(int hWndChild, int hWndNewParent);
 

        

        public bool StartupFormShow_Flag = true;    
        

        public bool ThetaFormShow_Flag = true;      
        private void butn_Setting_theta_Click(object sender, EventArgs e)
        {
            
            SubForm_Theta_SettingAxis ChildFormTheta = new SubForm_Theta_SettingAxis();
            ChildFormTheta.Owner = this;
            if (ThetaFormShow_Flag)
            {
                ChildFormTheta.Show();
                ThetaFormShow_Flag = false;
            }
            
            ChildFormTheta.BringToFront();
            SetParent((int)ChildFormTheta.Handle, (int)this.Handle);
        }  
 
    }
}

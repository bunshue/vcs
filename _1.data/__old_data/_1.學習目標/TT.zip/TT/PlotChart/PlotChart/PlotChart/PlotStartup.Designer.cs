﻿namespace Plot
{
    partial class PlotStartup
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器
        /// 修改這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.butn_setting_Startup = new System.Windows.Forms.Button();
            this.chart_Startup = new System.Windows.Forms.DataVisualization.Charting.Chart();
            ((System.ComponentModel.ISupportInitialize)(this.chart_Startup)).BeginInit();
            this.SuspendLayout();
            // 
            // butn_setting_Startup
            // 
            this.butn_setting_Startup.Location = new System.Drawing.Point(12, 549);
            this.butn_setting_Startup.Name = "butn_setting_Startup";
            this.butn_setting_Startup.Size = new System.Drawing.Size(149, 23);
            this.butn_setting_Startup.TabIndex = 2;
            this.butn_setting_Startup.Text = "Setting Chart_startup";
            this.butn_setting_Startup.UseVisualStyleBackColor = true;
            this.butn_setting_Startup.Click += new System.EventHandler(this.butn_setting_Startup_Click);
            // 
            // chart_Startup
            // 
            this.chart_Startup.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.chart_Startup.Location = new System.Drawing.Point(12, 12);
            this.chart_Startup.Name = "chart_Startup";
            this.chart_Startup.Size = new System.Drawing.Size(731, 531);
            this.chart_Startup.TabIndex = 0;
            this.chart_Startup.Text = "chart_Startup";
            // 
            // Form_Chart_Startup
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(755, 574);
            this.Controls.Add(this.butn_setting_Startup);
            this.Controls.Add(this.chart_Startup);
            this.IsMdiContainer = true;
            this.MaximizeBox = false;
            this.Name = "Form_Chart_Startup";
            this.Text = "Chart";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.chart_Startup)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button butn_setting_Startup;
        public System.Windows.Forms.DataVisualization.Charting.Chart chart_Startup;
    }
}


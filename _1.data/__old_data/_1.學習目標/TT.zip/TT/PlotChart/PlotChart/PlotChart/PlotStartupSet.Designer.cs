﻿namespace Plot
{
    partial class SubForm_Startup_SettingAxis
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.but_axisX_send = new System.Windows.Forms.Button();
            this.Form2_TB_AxisX_Max = new System.Windows.Forms.TextBox();
            this.CB_MajorGridX = new System.Windows.Forms.CheckBox();
            this.Form2_TB_AxisX_Min = new System.Windows.Forms.TextBox();
            this.Form2_TB_AxisX_Name = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.Lab_AxisX = new System.Windows.Forms.Label();
            this.CB_MajorGridY2 = new System.Windows.Forms.CheckBox();
            this.CB_MajorGridY1 = new System.Windows.Forms.CheckBox();
            this.Form2_TB_AxisY2_Name = new System.Windows.Forms.TextBox();
            this.Form2_TB_AxisY1_Name = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.but_axisY_send = new System.Windows.Forms.Button();
            this.Form2_TB_AxisY_Max = new System.Windows.Forms.TextBox();
            this.Form2_TB_AxisY_Min = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.button2 = new System.Windows.Forms.Button();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.but_axisY2_send = new System.Windows.Forms.Button();
            this.Form2_TB_AxisY2_Max = new System.Windows.Forms.TextBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.Form2_TB_AxisY2_Min = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.but_axisX_send);
            this.groupBox1.Controls.Add(this.Form2_TB_AxisX_Max);
            this.groupBox1.Controls.Add(this.CB_MajorGridX);
            this.groupBox1.Controls.Add(this.Form2_TB_AxisX_Min);
            this.groupBox1.Controls.Add(this.Form2_TB_AxisX_Name);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.Lab_AxisX);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(288, 147);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "X  Setting";
            // 
            // but_axisX_send
            // 
            this.but_axisX_send.Location = new System.Drawing.Point(111, 114);
            this.but_axisX_send.Name = "but_axisX_send";
            this.but_axisX_send.Size = new System.Drawing.Size(75, 23);
            this.but_axisX_send.TabIndex = 4;
            this.but_axisX_send.Text = "Initialize";
            this.but_axisX_send.UseVisualStyleBackColor = true;
            this.but_axisX_send.Click += new System.EventHandler(this.but_axisX_send_Click);
            // 
            // Form2_TB_AxisX_Max
            // 
            this.Form2_TB_AxisX_Max.Location = new System.Drawing.Point(96, 80);
            this.Form2_TB_AxisX_Max.Name = "Form2_TB_AxisX_Max";
            this.Form2_TB_AxisX_Max.Size = new System.Drawing.Size(177, 22);
            this.Form2_TB_AxisX_Max.TabIndex = 3;
            this.Form2_TB_AxisX_Max.KeyDown += new System.Windows.Forms.KeyEventHandler(this.KeyDown_TB_AxisX_Max);
            // 
            // CB_MajorGridX
            // 
            this.CB_MajorGridX.Checked = true;
            this.CB_MajorGridX.CheckState = System.Windows.Forms.CheckState.Checked;
            this.CB_MajorGridX.Location = new System.Drawing.Point(8, 118);
            this.CB_MajorGridX.Name = "CB_MajorGridX";
            this.CB_MajorGridX.Size = new System.Drawing.Size(45, 16);
            this.CB_MajorGridX.TabIndex = 2;
            this.CB_MajorGridX.Text = "Grid";
            this.CB_MajorGridX.UseVisualStyleBackColor = true;
            this.CB_MajorGridX.CheckedChanged += new System.EventHandler(this.CB_MajorGridX_CheckedChanged);
            // 
            // Form2_TB_AxisX_Min
            // 
            this.Form2_TB_AxisX_Min.Location = new System.Drawing.Point(96, 52);
            this.Form2_TB_AxisX_Min.Name = "Form2_TB_AxisX_Min";
            this.Form2_TB_AxisX_Min.Size = new System.Drawing.Size(177, 22);
            this.Form2_TB_AxisX_Min.TabIndex = 1;
            this.Form2_TB_AxisX_Min.KeyDown += new System.Windows.Forms.KeyEventHandler(this.KeyDown_TB_AxisX_Min);
            // 
            // Form2_TB_AxisX_Name
            // 
            this.Form2_TB_AxisX_Name.Location = new System.Drawing.Point(96, 27);
            this.Form2_TB_AxisX_Name.Name = "Form2_TB_AxisX_Name";
            this.Form2_TB_AxisX_Name.Size = new System.Drawing.Size(177, 22);
            this.Form2_TB_AxisX_Name.TabIndex = 1;
            this.Form2_TB_AxisX_Name.KeyDown += new System.Windows.Forms.KeyEventHandler(this.KeyDown_TB_AxisX_Name);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(6, 62);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(84, 12);
            this.label8.TabIndex = 0;
            this.label8.Text = "Range Minimum";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(6, 90);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(86, 12);
            this.label5.TabIndex = 0;
            this.label5.Text = "Range Maximum";
            // 
            // Lab_AxisX
            // 
            this.Lab_AxisX.AutoSize = true;
            this.Lab_AxisX.Location = new System.Drawing.Point(31, 37);
            this.Lab_AxisX.Name = "Lab_AxisX";
            this.Lab_AxisX.Size = new System.Drawing.Size(32, 12);
            this.Lab_AxisX.TabIndex = 0;
            this.Lab_AxisX.Text = "Name";
            // 
            // CB_MajorGridY2
            // 
            this.CB_MajorGridY2.AutoSize = true;
            this.CB_MajorGridY2.Checked = true;
            this.CB_MajorGridY2.CheckState = System.Windows.Forms.CheckState.Checked;
            this.CB_MajorGridY2.Location = new System.Drawing.Point(8, 118);
            this.CB_MajorGridY2.Name = "CB_MajorGridY2";
            this.CB_MajorGridY2.Size = new System.Drawing.Size(45, 16);
            this.CB_MajorGridY2.TabIndex = 2;
            this.CB_MajorGridY2.Text = "Grid";
            this.CB_MajorGridY2.UseVisualStyleBackColor = true;
            this.CB_MajorGridY2.CheckedChanged += new System.EventHandler(this.CB_MajorGridY2_CheckedChanged);
            // 
            // CB_MajorGridY1
            // 
            this.CB_MajorGridY1.AutoSize = true;
            this.CB_MajorGridY1.Checked = true;
            this.CB_MajorGridY1.CheckState = System.Windows.Forms.CheckState.Checked;
            this.CB_MajorGridY1.Location = new System.Drawing.Point(8, 114);
            this.CB_MajorGridY1.Name = "CB_MajorGridY1";
            this.CB_MajorGridY1.Size = new System.Drawing.Size(45, 16);
            this.CB_MajorGridY1.TabIndex = 2;
            this.CB_MajorGridY1.Text = "Grid";
            this.CB_MajorGridY1.UseVisualStyleBackColor = true;
            this.CB_MajorGridY1.CheckedChanged += new System.EventHandler(this.CB_MajorGridY1_CheckedChanged);
            // 
            // Form2_TB_AxisY2_Name
            // 
            this.Form2_TB_AxisY2_Name.Location = new System.Drawing.Point(95, 24);
            this.Form2_TB_AxisY2_Name.Name = "Form2_TB_AxisY2_Name";
            this.Form2_TB_AxisY2_Name.Size = new System.Drawing.Size(168, 22);
            this.Form2_TB_AxisY2_Name.TabIndex = 1;
            this.Form2_TB_AxisY2_Name.KeyDown += new System.Windows.Forms.KeyEventHandler(this.KeyDown_TB_AxisY2_Name);
            // 
            // Form2_TB_AxisY1_Name
            // 
            this.Form2_TB_AxisY1_Name.Location = new System.Drawing.Point(95, 24);
            this.Form2_TB_AxisY1_Name.Name = "Form2_TB_AxisY1_Name";
            this.Form2_TB_AxisY1_Name.Size = new System.Drawing.Size(178, 22);
            this.Form2_TB_AxisY1_Name.TabIndex = 1;
            this.Form2_TB_AxisY1_Name.KeyDown += new System.Windows.Forms.KeyEventHandler(this.KeyDown_TB_AxisY1_Name);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.but_axisY_send);
            this.groupBox2.Controls.Add(this.Form2_TB_AxisY_Max);
            this.groupBox2.Controls.Add(this.Form2_TB_AxisY_Min);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.Form2_TB_AxisY1_Name);
            this.groupBox2.Controls.Add(this.CB_MajorGridY1);
            this.groupBox2.Location = new System.Drawing.Point(12, 165);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(288, 147);
            this.groupBox2.TabIndex = 2;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Y  Setting";
            // 
            // but_axisY_send
            // 
            this.but_axisY_send.Location = new System.Drawing.Point(111, 114);
            this.but_axisY_send.Name = "but_axisY_send";
            this.but_axisY_send.Size = new System.Drawing.Size(75, 23);
            this.but_axisY_send.TabIndex = 4;
            this.but_axisY_send.Text = "Initialize";
            this.but_axisY_send.UseVisualStyleBackColor = true;
            this.but_axisY_send.Click += new System.EventHandler(this.but_axisY_send_Click);
            // 
            // Form2_TB_AxisY_Max
            // 
            this.Form2_TB_AxisY_Max.Location = new System.Drawing.Point(96, 80);
            this.Form2_TB_AxisY_Max.Name = "Form2_TB_AxisY_Max";
            this.Form2_TB_AxisY_Max.Size = new System.Drawing.Size(177, 22);
            this.Form2_TB_AxisY_Max.TabIndex = 3;
            this.Form2_TB_AxisY_Max.KeyDown += new System.Windows.Forms.KeyEventHandler(this.KeyDown_TB_AxisY_Max);
            // 
            // Form2_TB_AxisY_Min
            // 
            this.Form2_TB_AxisY_Min.Location = new System.Drawing.Point(96, 52);
            this.Form2_TB_AxisY_Min.Name = "Form2_TB_AxisY_Min";
            this.Form2_TB_AxisY_Min.Size = new System.Drawing.Size(177, 22);
            this.Form2_TB_AxisY_Min.TabIndex = 1;
            this.Form2_TB_AxisY_Min.KeyDown += new System.Windows.Forms.KeyEventHandler(this.KeyDown_TB_AxisY_Min);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 62);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(84, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "Range Minimum";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 90);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(86, 12);
            this.label2.TabIndex = 0;
            this.label2.Text = "Range Maximum";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(31, 37);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(32, 12);
            this.label3.TabIndex = 0;
            this.label3.Text = "Name";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.groupBox5);
            this.groupBox3.Controls.Add(this.but_axisY2_send);
            this.groupBox3.Controls.Add(this.Form2_TB_AxisY2_Max);
            this.groupBox3.Controls.Add(this.groupBox4);
            this.groupBox3.Controls.Add(this.Form2_TB_AxisY2_Min);
            this.groupBox3.Controls.Add(this.label10);
            this.groupBox3.Controls.Add(this.label11);
            this.groupBox3.Controls.Add(this.label12);
            this.groupBox3.Controls.Add(this.Form2_TB_AxisY2_Name);
            this.groupBox3.Controls.Add(this.CB_MajorGridY2);
            this.groupBox3.Location = new System.Drawing.Point(12, 318);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(286, 147);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Y1  Setting";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.button2);
            this.groupBox5.Controls.Add(this.textBox4);
            this.groupBox5.Controls.Add(this.textBox5);
            this.groupBox5.Controls.Add(this.label9);
            this.groupBox5.Controls.Add(this.label13);
            this.groupBox5.Controls.Add(this.label14);
            this.groupBox5.Controls.Add(this.textBox6);
            this.groupBox5.Controls.Add(this.checkBox2);
            this.groupBox5.Location = new System.Drawing.Point(-207, 0);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(201, 147);
            this.groupBox5.TabIndex = 2;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Y  Setting";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(111, 114);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 4;
            this.button2.Text = "Initialize";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.but_axisY_send_Click);
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(96, 80);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(90, 22);
            this.textBox4.TabIndex = 3;
            this.textBox4.KeyDown += new System.Windows.Forms.KeyEventHandler(this.KeyDown_TB_AxisY_Max);
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(96, 52);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(90, 22);
            this.textBox5.TabIndex = 1;
            this.textBox5.KeyDown += new System.Windows.Forms.KeyEventHandler(this.KeyDown_TB_AxisY_Min);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(6, 62);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(84, 12);
            this.label9.TabIndex = 0;
            this.label9.Text = "Range Minimum";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(6, 90);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(86, 12);
            this.label13.TabIndex = 0;
            this.label13.Text = "Range Maximum";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(31, 37);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(32, 12);
            this.label14.TabIndex = 0;
            this.label14.Text = "Name";
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(95, 24);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(91, 22);
            this.textBox6.TabIndex = 1;
            this.textBox6.KeyDown += new System.Windows.Forms.KeyEventHandler(this.KeyDown_TB_AxisY1_Name);
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Checked = true;
            this.checkBox2.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox2.Location = new System.Drawing.Point(8, 114);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(45, 16);
            this.checkBox2.TabIndex = 2;
            this.checkBox2.Text = "Grid";
            this.checkBox2.UseVisualStyleBackColor = true;
            this.checkBox2.CheckedChanged += new System.EventHandler(this.CB_MajorGridY1_CheckedChanged);
            // 
            // but_axisY2_send
            // 
            this.but_axisY2_send.Location = new System.Drawing.Point(111, 114);
            this.but_axisY2_send.Name = "but_axisY2_send";
            this.but_axisY2_send.Size = new System.Drawing.Size(75, 23);
            this.but_axisY2_send.TabIndex = 4;
            this.but_axisY2_send.Text = "Initialize";
            this.but_axisY2_send.UseVisualStyleBackColor = true;
            this.but_axisY2_send.Click += new System.EventHandler(this.but_axisY2_send_Click);
            // 
            // Form2_TB_AxisY2_Max
            // 
            this.Form2_TB_AxisY2_Max.Location = new System.Drawing.Point(96, 80);
            this.Form2_TB_AxisY2_Max.Name = "Form2_TB_AxisY2_Max";
            this.Form2_TB_AxisY2_Max.Size = new System.Drawing.Size(167, 22);
            this.Form2_TB_AxisY2_Max.TabIndex = 3;
            this.Form2_TB_AxisY2_Max.KeyDown += new System.Windows.Forms.KeyEventHandler(this.KeyDown_TB_AxisY2_Max);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.button1);
            this.groupBox4.Controls.Add(this.textBox1);
            this.groupBox4.Controls.Add(this.checkBox1);
            this.groupBox4.Controls.Add(this.textBox2);
            this.groupBox4.Controls.Add(this.textBox3);
            this.groupBox4.Controls.Add(this.label4);
            this.groupBox4.Controls.Add(this.label6);
            this.groupBox4.Controls.Add(this.label7);
            this.groupBox4.Location = new System.Drawing.Point(-414, 0);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(201, 147);
            this.groupBox4.TabIndex = 2;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "X  Setting";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(111, 114);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 4;
            this.button1.Text = "Initialize";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.but_axisX_send_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(96, 80);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(90, 22);
            this.textBox1.TabIndex = 3;
            this.textBox1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.KeyDown_TB_AxisX_Max);
            // 
            // checkBox1
            // 
            this.checkBox1.Checked = true;
            this.checkBox1.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox1.Location = new System.Drawing.Point(8, 118);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(45, 16);
            this.checkBox1.TabIndex = 2;
            this.checkBox1.Text = "Grid";
            this.checkBox1.UseVisualStyleBackColor = true;
            this.checkBox1.CheckedChanged += new System.EventHandler(this.CB_MajorGridX_CheckedChanged);
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(96, 52);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(90, 22);
            this.textBox2.TabIndex = 1;
            this.textBox2.KeyDown += new System.Windows.Forms.KeyEventHandler(this.KeyDown_TB_AxisX_Min);
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(96, 27);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(90, 22);
            this.textBox3.TabIndex = 1;
            this.textBox3.KeyDown += new System.Windows.Forms.KeyEventHandler(this.KeyDown_TB_AxisX_Name);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 62);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(84, 12);
            this.label4.TabIndex = 0;
            this.label4.Text = "Range Minimum";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(6, 90);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(86, 12);
            this.label6.TabIndex = 0;
            this.label6.Text = "Range Maximum";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(31, 37);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(32, 12);
            this.label7.TabIndex = 0;
            this.label7.Text = "Name";
            // 
            // Form2_TB_AxisY2_Min
            // 
            this.Form2_TB_AxisY2_Min.Location = new System.Drawing.Point(96, 52);
            this.Form2_TB_AxisY2_Min.Name = "Form2_TB_AxisY2_Min";
            this.Form2_TB_AxisY2_Min.Size = new System.Drawing.Size(167, 22);
            this.Form2_TB_AxisY2_Min.TabIndex = 1;
            this.Form2_TB_AxisY2_Min.KeyDown += new System.Windows.Forms.KeyEventHandler(this.KeyDown_TB_AxisY2_Min);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(6, 62);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(84, 12);
            this.label10.TabIndex = 0;
            this.label10.Text = "Range Minimum";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(6, 90);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(86, 12);
            this.label11.TabIndex = 0;
            this.label11.Text = "Range Maximum";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(31, 37);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(32, 12);
            this.label12.TabIndex = 0;
            this.label12.Text = "Name";
            // 
            // SubForm_Startup_SettingAxis
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(312, 473);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "SubForm_Startup_SettingAxis";
            this.Text = "Startup Axis Setting";
            this.TopMost = true;
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.SubFormStartup_FormClosing);
            this.Load += new System.EventHandler(this.SubForm_Startup_SettingAxis_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.CheckBox CB_MajorGridY2;
        private System.Windows.Forms.CheckBox CB_MajorGridY1;
        private System.Windows.Forms.CheckBox CB_MajorGridX;
        private System.Windows.Forms.TextBox Form2_TB_AxisX_Name;
        private System.Windows.Forms.TextBox Form2_TB_AxisY2_Name;
        private System.Windows.Forms.TextBox Form2_TB_AxisY1_Name;
        private System.Windows.Forms.Label Lab_AxisX;
        private System.Windows.Forms.TextBox Form2_TB_AxisX_Max;
        private System.Windows.Forms.TextBox Form2_TB_AxisX_Min;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button but_axisX_send;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button but_axisY_send;
        private System.Windows.Forms.TextBox Form2_TB_AxisY_Max;
        private System.Windows.Forms.TextBox Form2_TB_AxisY_Min;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button but_axisY2_send;
        private System.Windows.Forms.TextBox Form2_TB_AxisY2_Max;
        private System.Windows.Forms.TextBox Form2_TB_AxisY2_Min;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
    }
}
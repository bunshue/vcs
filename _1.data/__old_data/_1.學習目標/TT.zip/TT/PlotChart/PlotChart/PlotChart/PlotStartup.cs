﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;
using System.IO;
using System.Runtime.InteropServices;

namespace Plot
{
    public partial class PlotStartup : Form
    {
        public PlotStartup()
        {
            InitializeComponent();
        }
        public string startUpRcdFilePath { get; set; }
        public String[] AxisName = new String[] { "Time(10 ms)", "Rotational Speed(0.1 RPS) ", "Current Is(0.1A)" };
        public int ChartThta_X_Max, ChartThta_X_Min, ChartThta_Y_Max, ChartThta_Y_Min;
        public int ChartStartup_X_Max, ChartStartup_X_Min, ChartStartup_Y_Max, ChartStartup_Y_Min, ChartStartup_Y2_Max, ChartStartup_Y2_Min;
      
        public void ChartStartup_Show()
        {
            OpenFileDialog oFD = new OpenFileDialog();
            TextFileToIntArry textToIntArr = new TextFileToIntArry();
            //string filePathString = Path.Combine(Directory.GetCurrentDirectory(), "IntArray.txt");
            //string filePathString = startUpRcdFilePath;
            textToIntArr.FilePath = startUpRcdFilePath;
            textToIntArr.ReadTextToIntArray();

            int[][] DataGroupArray = new int[textToIntArr.ArrayCol][];
            DataGroupArray = textToIntArr.IntArrayTranspose();

            double[] test = textToIntArr.IntArrayAverage(10, 3);


             ChartStartup_X_Max = DataGroupArray[0].Max();
             ChartStartup_X_Min = DataGroupArray[0].Min();

             ChartStartup_Y_Max = DataGroupArray[2].Max();
             ChartStartup_Y_Min = DataGroupArray[2].Min();

             ChartStartup_Y2_Max = DataGroupArray[3].Max();
             ChartStartup_Y2_Min = DataGroupArray[3].Min();
        
            //ChartAreas, Series, Legends基本設定--------------------------------------------
            // Chart chart1 = new Chart();   //目前測試會error
            chart_Startup.ChartAreas.Add("area");//圖表區域集合
            chart_Startup.Series.Add("Phase"); //數據序列集合(Phase)
            chart_Startup.Series.Add("Speed(RPS)");//數據序列集合(Speed(RPS))
            chart_Startup.Series.Add("Current(A)");//數據序列集合(Current(A))
            chart_Startup.Legends.Add("Legends1"); //圖例集合
            

            //設定Chart    ---------------------------------------------------------------------------
            //chart_Startup.Width = 630; 
            //chart_Startup.Height = 460;
            Title title = new Title();
            title.Text = "Start Up Analytics";
            title.Alignment = ContentAlignment.MiddleCenter;
            title.Font = new System.Drawing.Font("Times New Roman ", 14F, FontStyle.Bold);
            chart_Startup.Titles.Add(title);


            //設定 ChartArea--------------------------------------------------------------------------
            //chart1.ChartAreas["area"].BackColor = Color.White; //設定背景顏色
            chart_Startup.ChartAreas["area"].AxisX.Minimum = ChartStartup_X_Min;
            chart_Startup.ChartAreas["area"].AxisX.Maximum = ChartStartup_X_Max;
            chart_Startup.ChartAreas["area"].AxisX.Interval = 100;

            //chart1.ChartAreas["area"].AxisY.Minimum = Y_Min;
            //chart1.ChartAreas["area"].AxisY.Maximum = Y_Max;
            //chart1.ChartAreas["area"].AxisY.Interval = 100;

            //chart1.ChartAreas["area"].AxisY2.Minimum = Y2_Min;
            //chart1.ChartAreas["area"].AxisY2.Maximum = Y2_Max;
            //chart1.ChartAreas["area"].AxisY2.Interval = 2;

            chart_Startup.ChartAreas["area"].AxisX.MajorGrid.LineColor = Color.Black; //X軸線的顏色
            chart_Startup.ChartAreas["area"].AxisY.MajorGrid.LineColor = Color.Black;//Y軸線的顏色
            chart_Startup.ChartAreas["area"].AxisY2.MajorGrid.LineColor = Color.Black;//Y2軸線的顏色

           chart_Startup.ChartAreas["area"].AxisX.Title = AxisName[0];//X軸文字說明
           chart_Startup.ChartAreas["area"].AxisY.Title = AxisName[1];//Y1軸文字說明
           chart_Startup.ChartAreas["area"].AxisY2.Title = AxisName[2];//Y2軸文字說明

            chart_Startup.ChartAreas["area"].AxisX.TitleFont = new System.Drawing.Font("Times New Roman ", 10F, System.Drawing.FontStyle.Regular);
            chart_Startup.ChartAreas["area"].AxisY.TitleFont = new System.Drawing.Font("Times New Roman ", 10F, System.Drawing.FontStyle.Regular);
            chart_Startup.ChartAreas["area"].AxisY2.TitleFont = new System.Drawing.Font("Times New Roman ", 10F, System.Drawing.FontStyle.Regular);

            //設定 Legends--------------------------------------------------------------------------
            chart_Startup.Legends["Legends1"].DockedToChartArea = "area";  ////顯示在圖表內
            chart_Startup.Legends["Legends1"].Docking = Docking.Left; //自訂顯示位置
            chart_Startup.Legends["Legends1"].BackColor = Color.WhiteSmoke;

            chart_Startup.Legends["Legends1"].BackHatchStyle = ChartHatchStyle.DarkDownwardDiagonal; //背景採用斜線
    
            //chart1.Legends["Legends1"].BorderWidth = 1; //設定Legends的邊框
            //chart1.Legends["Legends1"].BorderColor = Color.FromArgb(200, 200, 200);/設定Legends邊框的顏色


            //設定 Series--------------------------------------------------------------------------
            chart_Startup.Series["Phase"].ChartType = SeriesChartType.Point; //點狀圖
            chart_Startup.Series["Speed(RPS)"].ChartType = SeriesChartType.Line; //折線圖
            chart_Startup.Series["Current(A)"].ChartType = SeriesChartType.Line;
            
            chart_Startup.Series["Phase"].Color = Color.Blue;
            chart_Startup.Series["Speed(RPS)"].Color = Color.OrangeRed;
            chart_Startup.Series["Current(A)"].Color = Color.Green;

            chart_Startup.Series["Phase"].YAxisType = AxisType.Secondary;
            chart_Startup.Series["Speed(RPS)"].YAxisType = AxisType.Primary;
            chart_Startup.Series["Current(A)"].YAxisType = AxisType.Secondary;

 
            chart_Startup.Series["Phase"].Legend = "Legends1";
            chart_Startup.Series["Speed(RPS)"].Legend = "Legends1";
            chart_Startup.Series["Current(A)"].Legend  = "Legends1";
            chart_Startup.Series["Phase"].LegendText = "Phase"; //設定折線圖的名字
            chart_Startup.Series["Speed(RPS)"].LegendText = "Speed(RPS)"; //設定折線圖的名字
            chart_Startup.Series["Current(A)"].LegendText = "Current(A)"; //設定折線圖的名字

  
           //畫出XY座標
            for (int i = 0; i < DataGroupArray[0].Length; i++)
            {
                chart_Startup.Series["Phase"].Points.AddXY(DataGroupArray[0][i], DataGroupArray[1][i]);//Is
                chart_Startup.Series["Speed(RPS)"].Points.AddXY(DataGroupArray[0][i], DataGroupArray[2][i]); //State
                chart_Startup.Series["Current(A)"].Points.AddXY(DataGroupArray[0][i], test[i]); //Speed
            }  
        }

        public void char1name(string name)
        {
            chart_Startup.ChartAreas["area"].AxisX.Title =name;
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            startUpRcdFilePath = Path.Combine(Directory.GetCurrentDirectory(), "IntArray.txt");
            ChartStartup_Show();
           
          //  chart1.ChartAreas["area"].AxisX.Title = AxisX_Name;

        }

      
        [DllImport("user32")]
        public static extern int SetParent(int hWndChild, int hWndNewParent);
 

        private void ToolStripMenuItem_Axis_Click(object sender, EventArgs e)
        {
            SubForm_Startup_SettingAxis ChildForm = new SubForm_Startup_SettingAxis();
            ChildForm.MdiParent = this;
            ChildForm.Show();
           
        }

        public bool StartupFormShow_Flag = true;    
        
        private void butn_setting_Startup_Click(object sender, EventArgs e)
        {
            SubForm_Startup_SettingAxis ChildFormStartup = new SubForm_Startup_SettingAxis();
            ChildFormStartup.Owner = this;
            if (StartupFormShow_Flag)
            {
                ChildFormStartup.Show();
               StartupFormShow_Flag = false;
            }
            ChildFormStartup.BringToFront();
            SetParent((int)ChildFormStartup.Handle, (int)this.Handle);               
     
        }

        public bool ThetaFormShow_Flag = true;      
        
 
    }
}

﻿namespace Plot
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Startup = new System.Windows.Forms.Button();
            this.butn_theta = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Startup
            // 
            this.Startup.Location = new System.Drawing.Point(61, 38);
            this.Startup.Name = "Startup";
            this.Startup.Size = new System.Drawing.Size(169, 35);
            this.Startup.TabIndex = 0;
            this.Startup.Text = "Plot Startup";
            this.Startup.UseVisualStyleBackColor = true;
            this.Startup.Click += new System.EventHandler(this.Startup_Click);
            // 
            // butn_theta
            // 
            this.butn_theta.Location = new System.Drawing.Point(61, 112);
            this.butn_theta.Name = "butn_theta";
            this.butn_theta.Size = new System.Drawing.Size(169, 35);
            this.butn_theta.TabIndex = 0;
            this.butn_theta.Text = "Plot Theta ";
            this.butn_theta.UseVisualStyleBackColor = true;
            this.butn_theta.Click += new System.EventHandler(this.butn_theta_Click);
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 262);
            this.Controls.Add(this.butn_theta);
            this.Controls.Add(this.Startup);
            this.Name = "Main";
            this.Text = "Main";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button Startup;
        private System.Windows.Forms.Button butn_theta;
    }
}
﻿namespace TT_Monitor
{
    partial class Tatung_Record
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器
        /// 修改這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.TimerOneSecond = new System.Windows.Forms.Timer(this.components);
            this.serialPort1 = new System.IO.Ports.SerialPort(this.components);
            this.button_2MCU_RX = new System.Windows.Forms.Button();
            this.button_COM_Switch = new System.Windows.Forms.Button();
            this.Command_Data_Send = new System.Windows.Forms.RichTextBox();
            this.ComboBox_COM_Port = new System.Windows.Forms.ComboBox();
            this.ComboBox_Baud_Rate = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.richText_Display = new System.Windows.Forms.RichTextBox();
            this.button_TextBoxClr = new System.Windows.Forms.Button();
            this.button_2MCU_TX = new System.Windows.Forms.Button();
            this.button_SendCMD = new System.Windows.Forms.Button();
            this.File_Name = new System.Windows.Forms.TextBox();
            this.button_CmprStartUp = new System.Windows.Forms.Button();
            this.button_CmprStop = new System.Windows.Forms.Button();
            this.AutoTest_Run_But = new System.Windows.Forms.Button();
            this.AutoTest_ElapsedTime_Lebel = new System.Windows.Forms.Label();
            this.TabControl_Page = new System.Windows.Forms.TabControl();
            this.Command_TagPage = new System.Windows.Forms.TabPage();
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.button_StartUpFolderOpen = new System.Windows.Forms.Button();
            this.button_ThetaSave = new System.Windows.Forms.Button();
            this.button_SpeedPrt = new System.Windows.Forms.Button();
            this.button_SpeedSave = new System.Windows.Forms.Button();
            this.button_ThetaPrt = new System.Windows.Forms.Button();
            this.button_RcdClr = new System.Windows.Forms.Button();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.button_SPD_Set = new System.Windows.Forms.Button();
            this.label24 = new System.Windows.Forms.Label();
            this.SPD_NumUpDown = new System.Windows.Forms.NumericUpDown();
            this.Char_Cmd_CheckBox = new System.Windows.Forms.CheckBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.PFC_Menu = new System.Windows.Forms.GroupBox();
            this.button_PFC_Off = new System.Windows.Forms.Button();
            this.button_PFC_On = new System.Windows.Forms.Button();
            this.button_PFC_AutoOn = new System.Windows.Forms.Button();
            this.button_PFC_AutoOff = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.ControMenu_Group = new System.Windows.Forms.GroupBox();
            this.button_Auto = new System.Windows.Forms.Button();
            this.button_Manual = new System.Windows.Forms.Button();
            this.AutoTest_Tagpage = new System.Windows.Forms.TabPage();
            this.AutoTest_Reset_But = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.AutoTest_ThisPeriod_Lebel = new System.Windows.Forms.Label();
            this.AutoTest_NumOfTimes_Lebel = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.AutoTest_Polling_ChkBox8 = new System.Windows.Forms.CheckBox();
            this.AutoTest_Polling_ChkBox7 = new System.Windows.Forms.CheckBox();
            this.AutoTest_Polling_ChkBox6 = new System.Windows.Forms.CheckBox();
            this.AutoTest_Polling_ChkBox5 = new System.Windows.Forms.CheckBox();
            this.AutoTest_Polling_ChkBox4 = new System.Windows.Forms.CheckBox();
            this.AutoTest_Polling_ChkBox3 = new System.Windows.Forms.CheckBox();
            this.AutoTest_Polling_ChkBox2 = new System.Windows.Forms.CheckBox();
            this.AutoTest_Polling_ChkBox10 = new System.Windows.Forms.CheckBox();
            this.AutoTest_Polling_ChkBox9 = new System.Windows.Forms.CheckBox();
            this.AutoTest_Polling_ChkBox1 = new System.Windows.Forms.CheckBox();
            this.label21 = new System.Windows.Forms.Label();
            this.AutoTest_Cmd_textBox10 = new System.Windows.Forms.TextBox();
            this.AutoTest_Enable_ChkBox10 = new System.Windows.Forms.CheckBox();
            this.label23 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.AutoTest_Cmd_textBox1 = new System.Windows.Forms.TextBox();
            this.AutoTest_Cmd_textBox4 = new System.Windows.Forms.TextBox();
            this.AutoTest_Cmd_textBox2 = new System.Windows.Forms.TextBox();
            this.AutoTest_Cmd_textBox3 = new System.Windows.Forms.TextBox();
            this.AutoTest_Cmd_textBox6 = new System.Windows.Forms.TextBox();
            this.AutoTest_Cmd_textBox5 = new System.Windows.Forms.TextBox();
            this.AutoTest_Cmd_textBox7 = new System.Windows.Forms.TextBox();
            this.AutoTest_Cmd_textBox9 = new System.Windows.Forms.TextBox();
            this.AutoTest_Cmd_textBox8 = new System.Windows.Forms.TextBox();
            this.AutoTest_Enable_ChkBox2 = new System.Windows.Forms.CheckBox();
            this.label5 = new System.Windows.Forms.Label();
            this.AutoTest_Level1 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.AutoTest_Enable_ChkBox1 = new System.Windows.Forms.CheckBox();
            this.AutoTest_Enable_ChkBox3 = new System.Windows.Forms.CheckBox();
            this.AutoTest_Enable_ChkBox4 = new System.Windows.Forms.CheckBox();
            this.AutoTest_Enable_ChkBox5 = new System.Windows.Forms.CheckBox();
            this.AutoTest_Enable_ChkBox6 = new System.Windows.Forms.CheckBox();
            this.AutoTest_Enable_ChkBox7 = new System.Windows.Forms.CheckBox();
            this.AutoTest_Enable_ChkBox8 = new System.Windows.Forms.CheckBox();
            this.AutoTest_Enable_ChkBox9 = new System.Windows.Forms.CheckBox();
            this.label7 = new System.Windows.Forms.Label();
            this.AutoTest_Time_TextBox1 = new System.Windows.Forms.TextBox();
            this.AutoTest_Time_TextBox2 = new System.Windows.Forms.TextBox();
            this.AutoTest_Time_TextBox3 = new System.Windows.Forms.TextBox();
            this.AutoTest_Time_TextBox4 = new System.Windows.Forms.TextBox();
            this.AutoTest_Time_TextBox5 = new System.Windows.Forms.TextBox();
            this.AutoTest_Time_TextBox6 = new System.Windows.Forms.TextBox();
            this.AutoTest_Time_TextBox7 = new System.Windows.Forms.TextBox();
            this.AutoTest_Time_TextBox8 = new System.Windows.Forms.TextBox();
            this.AutoTest_Time_TextBox9 = new System.Windows.Forms.TextBox();
            this.AutoTest_Time_TextBox10 = new System.Windows.Forms.TextBox();
            this.AutoTest_Enable_ChkBox11 = new System.Windows.Forms.CheckBox();
            this.AutoTest_Enable_ChkBox12 = new System.Windows.Forms.CheckBox();
            this.AutoTest_Time_TextBox11 = new System.Windows.Forms.TextBox();
            this.AutoTest_Time_TextBox12 = new System.Windows.Forms.TextBox();
            this.AutoTest_Cmd_textBox11 = new System.Windows.Forms.TextBox();
            this.AutoTest_Cmd_textBox12 = new System.Windows.Forms.TextBox();
            this.AutoTest_CmdUpadte_But = new System.Windows.Forms.Button();
            this.AutoTest_Period_TextBox = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.COM2MCU_TagePage = new System.Windows.Forms.TabPage();
            this.button_OpenFile = new System.Windows.Forms.Button();
            this.button_OpenFolder = new System.Windows.Forms.Button();
            this.button_Save = new System.Windows.Forms.Button();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.COM2MCU_Level_TX_Tin = new System.Windows.Forms.Label();
            this.COM2MCU_Level_TX_ErrCode = new System.Windows.Forms.Label();
            this.COM2MCU_Level_TX_ClrErr = new System.Windows.Forms.Label();
            this.COM2MCU_Level_TX_InputCur = new System.Windows.Forms.Label();
            this.COM2MCU_Level_TX_RealFre = new System.Windows.Forms.Label();
            this.COM2MCU_Level_TX_TarFre = new System.Windows.Forms.Label();
            this.COM2MCU_Level_TX_DC4 = new System.Windows.Forms.Label();
            this.COM2MCU_Level_TX_DC3 = new System.Windows.Forms.Label();
            this.COM2MCU_Level_TX_DC2 = new System.Windows.Forms.Label();
            this.COM2MCU_Level_TX_DC1 = new System.Windows.Forms.Label();
            this.COM2MCU_Level_TX_Cmd = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.COM2MCU_Level_Inf3_b2 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.COM2MCU_Level_Inf3_b5 = new System.Windows.Forms.Label();
            this.COM2MCU_Level_Inf3_b7 = new System.Windows.Forms.Label();
            this.COM2MCU_Level_Inf2_b5 = new System.Windows.Forms.Label();
            this.COM2MCU_Level_Inf2_b4 = new System.Windows.Forms.Label();
            this.COM2MCU_Level_Inf2_b1 = new System.Windows.Forms.Label();
            this.COM2MCU_Level_Inf2_b0 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.COM2MCU_Level_Inf1_b0 = new System.Windows.Forms.Label();
            this.COM2MCU_Level_Inf1_b1 = new System.Windows.Forms.Label();
            this.COM2MCU_Level_Inf1_b3 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this.label61 = new System.Windows.Forms.Label();
            this.label62 = new System.Windows.Forms.Label();
            this.label63 = new System.Windows.Forms.Label();
            this.label64 = new System.Windows.Forms.Label();
            this.COM2MCU_Level_Inf1_b2 = new System.Windows.Forms.Label();
            this.COM2MCU_Level_Inf1_b4 = new System.Windows.Forms.Label();
            this.COM2MCU_Level_Inf1_b5 = new System.Windows.Forms.Label();
            this.COM2MCU_Level_Inf1_b6 = new System.Windows.Forms.Label();
            this.COM2MCU_Level_Inf1_b7 = new System.Windows.Forms.Label();
            this.COM2MCU_Level_Inf2_b3 = new System.Windows.Forms.Label();
            this.COM2MCU_Level_Inf2_b2 = new System.Windows.Forms.Label();
            this.COM2MCU_Level_Inf2_b6 = new System.Windows.Forms.Label();
            this.COM2MCU_Level_Inf2_b7 = new System.Windows.Forms.Label();
            this.COM2MCU_Level_Inf3_b0 = new System.Windows.Forms.Label();
            this.COM2MCU_Level_Inf3_b1 = new System.Windows.Forms.Label();
            this.COM2MCU_Level_Inf3_b3 = new System.Windows.Forms.Label();
            this.COM2MCU_Level_Inf3_b4 = new System.Windows.Forms.Label();
            this.COM2MCU_Level_Inf3_b6 = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.COM2MCU_Level_RX_ClrErr = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.COM2MCU_Level_RX_Cmd = new System.Windows.Forms.Label();
            this.COM2MCU_Level_RX_FC1 = new System.Windows.Forms.Label();
            this.COM2MCU_Level_RX_FC2 = new System.Windows.Forms.Label();
            this.COM2MCU_Level_RX_FC3 = new System.Windows.Forms.Label();
            this.COM2MCU_Level_RX_FC4 = new System.Windows.Forms.Label();
            this.COM2MCU_Level_RX_TarFre = new System.Windows.Forms.Label();
            this.COM2MCU_Level_RX_FreChange = new System.Windows.Forms.Label();
            this.COM2MCU_Level_RX_CurRel = new System.Windows.Forms.Label();
            this.Tab_ParaTuning = new System.Windows.Forms.TabPage();
            this.button_PaTu_SaveFile = new System.Windows.Forms.Button();
            this.button_PaTu_OpenFile = new System.Windows.Forms.Button();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.button_PaTu_Update_MotoPara = new System.Windows.Forms.Button();
            this.button_PaTu_Download = new System.Windows.Forms.Button();
            this.button_PaTu_Upload = new System.Windows.Forms.Button();
            this.button_PaTu_eFlashRead = new System.Windows.Forms.Button();
            this.button_PaTu_eFlashWrite = new System.Windows.Forms.Button();
            this.ListView_ParaTuning = new System.Windows.Forms.ListView();
            this.Monitor = new System.Windows.Forms.TabPage();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel10 = new System.Windows.Forms.TableLayoutPanel();
            this.Label_SpyMon_Pro_Tcon = new System.Windows.Forms.Label();
            this.Label_SpyMon_Pro_CompHot = new System.Windows.Forms.Label();
            this.Label_SpyMon_Pro_Tamb = new System.Windows.Forms.Label();
            this.Label_SpyMon_Pro_IPM_Hot = new System.Windows.Forms.Label();
            this.Label_SpyMon_Pro_Tsuc = new System.Windows.Forms.Label();
            this.Label_SpyMon_Pro_Tdis = new System.Windows.Forms.Label();
            this.Label_SpyMon_Pro_T_IPM = new System.Windows.Forms.Label();
            this.Label_SpyMon_Pro_SucHot = new System.Windows.Forms.Label();
            this.Label_SpyMon_Pro_ConHot = new System.Windows.Forms.Label();
            this.tableLayoutPanel9 = new System.Windows.Forms.TableLayoutPanel();
            this.Label_SpyMon_Pro_VacHigh = new System.Windows.Forms.Label();
            this.Label_SpyMon_Pro_VbusHigh = new System.Windows.Forms.Label();
            this.Label_SpyMon_Pro_VbusLow = new System.Windows.Forms.Label();
            this.Label_SpyMon_Pro_VacLow = new System.Windows.Forms.Label();
            this.Label_SpyMon_Pro_IacLow = new System.Windows.Forms.Label();
            this.Label_SpyMon_Pro_IacOver = new System.Windows.Forms.Label();
            this.Label_SpyMon_Pro_DC_Fan = new System.Windows.Forms.Label();
            this.Label_SpyMon_Pro_Motor3MinStop = new System.Windows.Forms.Label();
            this.tableLayoutPanel8 = new System.Windows.Forms.TableLayoutPanel();
            this.Label_SpyMon_Pro_UVW = new System.Windows.Forms.Label();
            this.Label_SpyMon_Pro_LoseSPD = new System.Windows.Forms.Label();
            this.Label_SpyMon_Pro_AmbientHot = new System.Windows.Forms.Label();
            this.Label_SpyMon_Pro_ZeroSPD = new System.Windows.Forms.Label();
            this.Label_SpyMon_Pro_FBK_Err = new System.Windows.Forms.Label();
            this.Label_SpyMon_Pro_StartUp = new System.Windows.Forms.Label();
            this.Label_SpyMon_Pro_IPM_Fault = new System.Windows.Forms.Label();
            this.Label_SpyMon_Pro_COM_Fail = new System.Windows.Forms.Label();
            this.Label_SpyMon_Pro_CurSenErr = new System.Windows.Forms.Label();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel7 = new System.Windows.Forms.TableLayoutPanel();
            this.textBox_SpyMon_WS_MS = new System.Windows.Forms.TextBox();
            this.Label_SpyMon_WS_MS = new System.Windows.Forms.Label();
            this.Label_SpyMon_WS_Cmd = new System.Windows.Forms.Label();
            this.textBox_SpyMon_WS_Cmd = new System.Windows.Forms.TextBox();
            this.textBox_SpyMon_WS_WM = new System.Windows.Forms.TextBox();
            this.Label_SpyMon_WS_WM = new System.Windows.Forms.Label();
            this.Label_SpyMon_WS_WS = new System.Windows.Forms.Label();
            this.textBox_SpyMon_WS_WS = new System.Windows.Forms.TextBox();
            this.Label_SpyMon_RstTime = new System.Windows.Forms.Label();
            this.Label_SpyMon_WS_FS = new System.Windows.Forms.Label();
            this.Label_SpyMon_WS_SS = new System.Windows.Forms.Label();
            this.textBox_SpyMon_RstTime = new System.Windows.Forms.TextBox();
            this.textBox_SpyMon_WS_FS = new System.Windows.Forms.TextBox();
            this.textBox_SpyMon_WS_SS = new System.Windows.Forms.TextBox();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel6 = new System.Windows.Forms.TableLayoutPanel();
            this.textBox_SpyMon_T_Suc = new System.Windows.Forms.TextBox();
            this.textBox_SpyMon_T_OutdoorEx = new System.Windows.Forms.TextBox();
            this.textBox_SpyMon_T_Outdoor = new System.Windows.Forms.TextBox();
            this.textBox_SpyMon_T_Set = new System.Windows.Forms.TextBox();
            this.textBox_SpyMon_T_IndoorEx = new System.Windows.Forms.TextBox();
            this.Label_SpyMon_T_Set = new System.Windows.Forms.Label();
            this.Label_SpyMon_T_IndoorEx = new System.Windows.Forms.Label();
            this.Label_SpyMon_T_Indoor = new System.Windows.Forms.Label();
            this.Label_SpyMon_T_Outdoor = new System.Windows.Forms.Label();
            this.Label_SpyMon_T_OutdoorEx = new System.Windows.Forms.Label();
            this.Label_SpyMon_T_Suc = new System.Windows.Forms.Label();
            this.textBox_SpyMon_T_Indoor = new System.Windows.Forms.TextBox();
            this.Label_SpyMon_T_Dis = new System.Windows.Forms.Label();
            this.textBox_SpyMon_T_Dis = new System.Windows.Forms.TextBox();
            this.textBox_SpyMon_T_IPM = new System.Windows.Forms.TextBox();
            this.Label_SpyMon_T_IPM = new System.Windows.Forms.Label();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel5 = new System.Windows.Forms.TableLayoutPanel();
            this.textBox_SpyMon_ApparentW = new System.Windows.Forms.TextBox();
            this.textBox_SpyMon_Vac = new System.Windows.Forms.TextBox();
            this.textBox_SpyMon_Iac = new System.Windows.Forms.TextBox();
            this.textBox_SpyMon_VBus = new System.Windows.Forms.TextBox();
            this.textBox_SpyMon_RealFre = new System.Windows.Forms.TextBox();
            this.Label_SpyMon_VBus = new System.Windows.Forms.Label();
            this.Label_SpyMon_RealFre = new System.Windows.Forms.Label();
            this.Label_SpyMon_SetFre = new System.Windows.Forms.Label();
            this.Label_SpyMon_Iac = new System.Windows.Forms.Label();
            this.Label_SpyMon_Vac = new System.Windows.Forms.Label();
            this.Label_SpyMon_ApparentW = new System.Windows.Forms.Label();
            this.textBox_SpyMon_SetFre = new System.Windows.Forms.TextBox();
            this.Label_SpyMon_PFC_State = new System.Windows.Forms.Label();
            this.textBox_SpyMon_PFC_State = new System.Windows.Forms.TextBox();
            this.textBox_SpyMon_RelayState = new System.Windows.Forms.TextBox();
            this.Label_SpyMon_RelayState = new System.Windows.Forms.Label();
            this.button_COM_Scan = new System.Windows.Forms.Button();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.Label_COM_Port_State = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripProgressBar = new System.Windows.Forms.ToolStripProgressBar();
            this.SerialPortTimer100ms = new System.Windows.Forms.Timer(this.components);
            this.timer_AutoSave = new System.Windows.Forms.Timer(this.components);
            this.TabControl_Page.SuspendLayout();
            this.Command_TagPage.SuspendLayout();
            this.groupBox13.SuspendLayout();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.SPD_NumUpDown)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.PFC_Menu.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.ControMenu_Group.SuspendLayout();
            this.AutoTest_Tagpage.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.COM2MCU_TagePage.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.Tab_ParaTuning.SuspendLayout();
            this.groupBox12.SuspendLayout();
            this.Monitor.SuspendLayout();
            this.groupBox11.SuspendLayout();
            this.tableLayoutPanel10.SuspendLayout();
            this.tableLayoutPanel9.SuspendLayout();
            this.tableLayoutPanel8.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.tableLayoutPanel7.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.tableLayoutPanel6.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.tableLayoutPanel5.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // TimerOneSecond
            // 
            this.TimerOneSecond.Interval = 1000;
            this.TimerOneSecond.Tick += new System.EventHandler(this.OneSecondTimer_Tick);
            // 
            // serialPort1
            // 
            this.serialPort1.BaudRate = 115200;
            this.serialPort1.PortName = "COM2";
            this.serialPort1.ReadBufferSize = 6000;
            this.serialPort1.ReceivedBytesThreshold = 6000;
            this.serialPort1.WriteBufferSize = 6000;
            // 
            // button_2MCU_RX
            // 
            this.button_2MCU_RX.Location = new System.Drawing.Point(15, 21);
            this.button_2MCU_RX.Name = "button_2MCU_RX";
            this.button_2MCU_RX.Size = new System.Drawing.Size(56, 23);
            this.button_2MCU_RX.TabIndex = 0;
            this.button_2MCU_RX.Text = "RX_En";
            this.button_2MCU_RX.UseVisualStyleBackColor = true;
            this.button_2MCU_RX.Click += new System.EventHandler(this.button_2MCU_RX_Click);
            // 
            // button_COM_Switch
            // 
            this.button_COM_Switch.Font = new System.Drawing.Font("PMingLiU", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button_COM_Switch.Location = new System.Drawing.Point(907, 120);
            this.button_COM_Switch.Name = "button_COM_Switch";
            this.button_COM_Switch.Size = new System.Drawing.Size(80, 30);
            this.button_COM_Switch.TabIndex = 1;
            this.button_COM_Switch.Text = "Open Port";
            this.button_COM_Switch.UseVisualStyleBackColor = true;
            this.button_COM_Switch.Click += new System.EventHandler(this.button_COM_Switch_Click);
            // 
            // Command_Data_Send
            // 
            this.Command_Data_Send.Location = new System.Drawing.Point(7, 543);
            this.Command_Data_Send.Name = "Command_Data_Send";
            this.Command_Data_Send.Size = new System.Drawing.Size(186, 23);
            this.Command_Data_Send.TabIndex = 2;
            this.Command_Data_Send.Text = "04 01";
            // 
            // ComboBox_COM_Port
            // 
            this.ComboBox_COM_Port.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ComboBox_COM_Port.FormattingEnabled = true;
            this.ComboBox_COM_Port.Location = new System.Drawing.Point(906, 38);
            this.ComboBox_COM_Port.Name = "ComboBox_COM_Port";
            this.ComboBox_COM_Port.Size = new System.Drawing.Size(82, 20);
            this.ComboBox_COM_Port.Sorted = true;
            this.ComboBox_COM_Port.TabIndex = 3;
            // 
            // ComboBox_Baud_Rate
            // 
            this.ComboBox_Baud_Rate.FormattingEnabled = true;
            this.ComboBox_Baud_Rate.Items.AddRange(new object[] {
            "9600",
            "19200",
            "115200"});
            this.ComboBox_Baud_Rate.Location = new System.Drawing.Point(906, 85);
            this.ComboBox_Baud_Rate.Name = "ComboBox_Baud_Rate";
            this.ComboBox_Baud_Rate.Size = new System.Drawing.Size(82, 20);
            this.ComboBox_Baud_Rate.TabIndex = 4;
            this.ComboBox_Baud_Rate.Text = "115200";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(908, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(57, 12);
            this.label1.TabIndex = 5;
            this.label1.Text = "COM Ports";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(911, 70);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(54, 12);
            this.label2.TabIndex = 6;
            this.label2.Text = "Baud Rate";
            // 
            // richText_Display
            // 
            this.richText_Display.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)));
            this.richText_Display.EnableAutoDragDrop = true;
            this.richText_Display.Location = new System.Drawing.Point(6, 28);
            this.richText_Display.MaxLength = 10;
            this.richText_Display.Name = "richText_Display";
            this.richText_Display.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.ForcedVertical;
            this.richText_Display.Size = new System.Drawing.Size(434, 509);
            this.richText_Display.TabIndex = 8;
            this.richText_Display.Text = "";
            this.richText_Display.TextChanged += new System.EventHandler(this.richText_Display_TextChanged);
            // 
            // button_TextBoxClr
            // 
            this.button_TextBoxClr.Location = new System.Drawing.Point(399, 2);
            this.button_TextBoxClr.Name = "button_TextBoxClr";
            this.button_TextBoxClr.Size = new System.Drawing.Size(41, 23);
            this.button_TextBoxClr.TabIndex = 11;
            this.button_TextBoxClr.Text = "Clear";
            this.button_TextBoxClr.UseVisualStyleBackColor = true;
            this.button_TextBoxClr.Click += new System.EventHandler(this.button_TextBoxClr_Click);
            // 
            // button_2MCU_TX
            // 
            this.button_2MCU_TX.Location = new System.Drawing.Point(83, 21);
            this.button_2MCU_TX.Name = "button_2MCU_TX";
            this.button_2MCU_TX.Size = new System.Drawing.Size(55, 23);
            this.button_2MCU_TX.TabIndex = 12;
            this.button_2MCU_TX.Text = "TX_En";
            this.button_2MCU_TX.UseVisualStyleBackColor = true;
            this.button_2MCU_TX.Click += new System.EventHandler(this.button_2MCU_TX_Click);
            // 
            // button_SendCMD
            // 
            this.button_SendCMD.Location = new System.Drawing.Point(211, 543);
            this.button_SendCMD.Name = "button_SendCMD";
            this.button_SendCMD.Size = new System.Drawing.Size(45, 23);
            this.button_SendCMD.TabIndex = 13;
            this.button_SendCMD.Text = "Send";
            this.button_SendCMD.UseVisualStyleBackColor = true;
            this.button_SendCMD.Click += new System.EventHandler(this.button_SendCMD_Click);
            // 
            // File_Name
            // 
            this.File_Name.Location = new System.Drawing.Point(659, 513);
            this.File_Name.Name = "File_Name";
            this.File_Name.Size = new System.Drawing.Size(142, 22);
            this.File_Name.TabIndex = 15;
            this.File_Name.TextChanged += new System.EventHandler(this.File_Name_TextChanged);
            // 
            // button_CmprStartUp
            // 
            this.button_CmprStartUp.Font = new System.Drawing.Font("Arial", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button_CmprStartUp.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.button_CmprStartUp.Location = new System.Drawing.Point(15, 21);
            this.button_CmprStartUp.Name = "button_CmprStartUp";
            this.button_CmprStartUp.Size = new System.Drawing.Size(120, 30);
            this.button_CmprStartUp.TabIndex = 17;
            this.button_CmprStartUp.Text = "Startup";
            this.button_CmprStartUp.UseVisualStyleBackColor = true;
            this.button_CmprStartUp.Click += new System.EventHandler(this.button_CmprStartUp_Click);
            // 
            // button_CmprStop
            // 
            this.button_CmprStop.Font = new System.Drawing.Font("Arial", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button_CmprStop.ForeColor = System.Drawing.Color.Red;
            this.button_CmprStop.Location = new System.Drawing.Point(15, 57);
            this.button_CmprStop.Name = "button_CmprStop";
            this.button_CmprStop.Size = new System.Drawing.Size(120, 30);
            this.button_CmprStop.TabIndex = 18;
            this.button_CmprStop.Text = "Stop";
            this.button_CmprStop.UseVisualStyleBackColor = true;
            this.button_CmprStop.Click += new System.EventHandler(this.button_CmprStop_Click);
            // 
            // AutoTest_Run_But
            // 
            this.AutoTest_Run_But.FlatAppearance.BorderSize = 0;
            this.AutoTest_Run_But.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.AutoTest_Run_But.ForeColor = System.Drawing.Color.Blue;
            this.AutoTest_Run_But.Location = new System.Drawing.Point(727, 393);
            this.AutoTest_Run_But.Name = "AutoTest_Run_But";
            this.AutoTest_Run_But.Size = new System.Drawing.Size(86, 37);
            this.AutoTest_Run_But.TabIndex = 19;
            this.AutoTest_Run_But.Text = "Run";
            this.AutoTest_Run_But.UseVisualStyleBackColor = true;
            this.AutoTest_Run_But.Click += new System.EventHandler(this.AutoTest_Run_But_Click);
            // 
            // AutoTest_ElapsedTime_Lebel
            // 
            this.AutoTest_ElapsedTime_Lebel.AutoSize = true;
            this.AutoTest_ElapsedTime_Lebel.Font = new System.Drawing.Font("Arial", 8.999999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AutoTest_ElapsedTime_Lebel.Location = new System.Drawing.Point(131, 18);
            this.AutoTest_ElapsedTime_Lebel.Name = "AutoTest_ElapsedTime_Lebel";
            this.AutoTest_ElapsedTime_Lebel.Size = new System.Drawing.Size(55, 15);
            this.AutoTest_ElapsedTime_Lebel.TabIndex = 20;
            this.AutoTest_ElapsedTime_Lebel.Text = "00:00:00";
            // 
            // TabControl_Page
            // 
            this.TabControl_Page.Appearance = System.Windows.Forms.TabAppearance.FlatButtons;
            this.TabControl_Page.Controls.Add(this.Command_TagPage);
            this.TabControl_Page.Controls.Add(this.AutoTest_Tagpage);
            this.TabControl_Page.Controls.Add(this.COM2MCU_TagePage);
            this.TabControl_Page.Controls.Add(this.Tab_ParaTuning);
            this.TabControl_Page.Controls.Add(this.Monitor);
            this.TabControl_Page.Location = new System.Drawing.Point(12, 14);
            this.TabControl_Page.Name = "TabControl_Page";
            this.TabControl_Page.SelectedIndex = 0;
            this.TabControl_Page.Size = new System.Drawing.Size(893, 597);
            this.TabControl_Page.TabIndex = 23;
            this.TabControl_Page.SelectedIndexChanged += new System.EventHandler(this.TabControl_Selected);
            // 
            // Command_TagPage
            // 
            this.Command_TagPage.BackColor = System.Drawing.SystemColors.Control;
            this.Command_TagPage.Controls.Add(this.groupBox13);
            this.Command_TagPage.Controls.Add(this.groupBox4);
            this.Command_TagPage.Controls.Add(this.Char_Cmd_CheckBox);
            this.Command_TagPage.Controls.Add(this.groupBox2);
            this.Command_TagPage.Controls.Add(this.PFC_Menu);
            this.Command_TagPage.Controls.Add(this.groupBox1);
            this.Command_TagPage.Controls.Add(this.richText_Display);
            this.Command_TagPage.Controls.Add(this.ControMenu_Group);
            this.Command_TagPage.Controls.Add(this.Command_Data_Send);
            this.Command_TagPage.Controls.Add(this.button_SendCMD);
            this.Command_TagPage.Controls.Add(this.button_TextBoxClr);
            this.Command_TagPage.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.Command_TagPage.Location = new System.Drawing.Point(4, 24);
            this.Command_TagPage.Margin = new System.Windows.Forms.Padding(3, 3, 3, 1);
            this.Command_TagPage.Name = "Command_TagPage";
            this.Command_TagPage.Padding = new System.Windows.Forms.Padding(3);
            this.Command_TagPage.Size = new System.Drawing.Size(885, 569);
            this.Command_TagPage.TabIndex = 0;
            this.Command_TagPage.Text = "Command";
            // 
            // groupBox13
            // 
            this.groupBox13.Controls.Add(this.button_StartUpFolderOpen);
            this.groupBox13.Controls.Add(this.button_ThetaSave);
            this.groupBox13.Controls.Add(this.button_SpeedPrt);
            this.groupBox13.Controls.Add(this.button_SpeedSave);
            this.groupBox13.Controls.Add(this.button_ThetaPrt);
            this.groupBox13.Controls.Add(this.button_RcdClr);
            this.groupBox13.Location = new System.Drawing.Point(618, 293);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.Size = new System.Drawing.Size(242, 148);
            this.groupBox13.TabIndex = 34;
            this.groupBox13.TabStop = false;
            this.groupBox13.Text = "Starup Record";
            // 
            // button_StartUpFolderOpen
            // 
            this.button_StartUpFolderOpen.Font = new System.Drawing.Font("PMingLiU", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button_StartUpFolderOpen.ForeColor = System.Drawing.Color.Green;
            this.button_StartUpFolderOpen.Location = new System.Drawing.Point(6, 109);
            this.button_StartUpFolderOpen.Name = "button_StartUpFolderOpen";
            this.button_StartUpFolderOpen.Size = new System.Drawing.Size(114, 29);
            this.button_StartUpFolderOpen.TabIndex = 36;
            this.button_StartUpFolderOpen.Text = "Open Folder";
            this.button_StartUpFolderOpen.UseVisualStyleBackColor = true;
            this.button_StartUpFolderOpen.Click += new System.EventHandler(this.button_StartUpFolderOpen_Click);
            // 
            // button_ThetaSave
            // 
            this.button_ThetaSave.Font = new System.Drawing.Font("PMingLiU", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button_ThetaSave.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.button_ThetaSave.Location = new System.Drawing.Point(126, 64);
            this.button_ThetaSave.Name = "button_ThetaSave";
            this.button_ThetaSave.Size = new System.Drawing.Size(114, 37);
            this.button_ThetaSave.TabIndex = 35;
            this.button_ThetaSave.Text = "Theta Save";
            this.button_ThetaSave.UseVisualStyleBackColor = true;
            this.button_ThetaSave.Click += new System.EventHandler(this.button_ThetaSave_Click);
            // 
            // button_SpeedPrt
            // 
            this.button_SpeedPrt.Location = new System.Drawing.Point(6, 21);
            this.button_SpeedPrt.Name = "button_SpeedPrt";
            this.button_SpeedPrt.Size = new System.Drawing.Size(114, 37);
            this.button_SpeedPrt.TabIndex = 28;
            this.button_SpeedPrt.Text = "Stage/Speed/Is Print";
            this.button_SpeedPrt.UseVisualStyleBackColor = true;
            this.button_SpeedPrt.Click += new System.EventHandler(this.button_SpeedPrt_Click);
            // 
            // button_SpeedSave
            // 
            this.button_SpeedSave.Font = new System.Drawing.Font("PMingLiU", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button_SpeedSave.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.button_SpeedSave.Location = new System.Drawing.Point(126, 20);
            this.button_SpeedSave.Name = "button_SpeedSave";
            this.button_SpeedSave.Size = new System.Drawing.Size(114, 37);
            this.button_SpeedSave.TabIndex = 33;
            this.button_SpeedSave.Text = "Stage/Speed/Is Save";
            this.button_SpeedSave.UseVisualStyleBackColor = true;
            this.button_SpeedSave.Click += new System.EventHandler(this.button_SpeedSave_Click);
            // 
            // button_ThetaPrt
            // 
            this.button_ThetaPrt.Location = new System.Drawing.Point(6, 64);
            this.button_ThetaPrt.Name = "button_ThetaPrt";
            this.button_ThetaPrt.Size = new System.Drawing.Size(113, 37);
            this.button_ThetaPrt.TabIndex = 31;
            this.button_ThetaPrt.Text = "Theta Print";
            this.button_ThetaPrt.UseVisualStyleBackColor = true;
            this.button_ThetaPrt.Click += new System.EventHandler(this.button_ThetaPrt_Click);
            // 
            // button_RcdClr
            // 
            this.button_RcdClr.Font = new System.Drawing.Font("PMingLiU", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button_RcdClr.ForeColor = System.Drawing.Color.Green;
            this.button_RcdClr.Location = new System.Drawing.Point(126, 109);
            this.button_RcdClr.Name = "button_RcdClr";
            this.button_RcdClr.Size = new System.Drawing.Size(113, 29);
            this.button_RcdClr.TabIndex = 32;
            this.button_RcdClr.Text = "Record Clear";
            this.button_RcdClr.UseVisualStyleBackColor = true;
            this.button_RcdClr.Click += new System.EventHandler(this.button_RcdClr_Click);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.button_SPD_Set);
            this.groupBox4.Controls.Add(this.label24);
            this.groupBox4.Controls.Add(this.SPD_NumUpDown);
            this.groupBox4.Location = new System.Drawing.Point(461, 130);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(181, 123);
            this.groupBox4.TabIndex = 30;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Speed Control";
            // 
            // button_SPD_Set
            // 
            this.button_SPD_Set.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button_SPD_Set.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.button_SPD_Set.Location = new System.Drawing.Point(15, 71);
            this.button_SPD_Set.Name = "button_SPD_Set";
            this.button_SPD_Set.Size = new System.Drawing.Size(82, 42);
            this.button_SPD_Set.TabIndex = 28;
            this.button_SPD_Set.Text = "SET";
            this.button_SPD_Set.UseVisualStyleBackColor = true;
            this.button_SPD_Set.Click += new System.EventHandler(this.button_SPD_Set_Click);
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Arial Black", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label24.ForeColor = System.Drawing.Color.Black;
            this.label24.Location = new System.Drawing.Point(119, 39);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(44, 19);
            this.label24.TabIndex = 28;
            this.label24.Text = "RPS";
            // 
            // SPD_NumUpDown
            // 
            this.SPD_NumUpDown.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.SPD_NumUpDown.Location = new System.Drawing.Point(15, 32);
            this.SPD_NumUpDown.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.SPD_NumUpDown.Name = "SPD_NumUpDown";
            this.SPD_NumUpDown.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.SPD_NumUpDown.Size = new System.Drawing.Size(82, 26);
            this.SPD_NumUpDown.TabIndex = 1;
            this.SPD_NumUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.SPD_NumUpDown.Value = new decimal(new int[] {
            30,
            0,
            0,
            0});
            // 
            // Char_Cmd_CheckBox
            // 
            this.Char_Cmd_CheckBox.AutoSize = true;
            this.Char_Cmd_CheckBox.ForeColor = System.Drawing.Color.Black;
            this.Char_Cmd_CheckBox.Location = new System.Drawing.Point(7, 6);
            this.Char_Cmd_CheckBox.Name = "Char_Cmd_CheckBox";
            this.Char_Cmd_CheckBox.Size = new System.Drawing.Size(63, 16);
            this.Char_Cmd_CheckBox.TabIndex = 29;
            this.Char_Cmd_CheckBox.Text = "Heximal";
            this.Char_Cmd_CheckBox.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.button_CmprStartUp);
            this.groupBox2.Controls.Add(this.button_CmprStop);
            this.groupBox2.Location = new System.Drawing.Point(461, 293);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(154, 93);
            this.groupBox2.TabIndex = 28;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Compressor Control";
            // 
            // PFC_Menu
            // 
            this.PFC_Menu.Controls.Add(this.button_PFC_Off);
            this.PFC_Menu.Controls.Add(this.button_PFC_On);
            this.PFC_Menu.Controls.Add(this.button_PFC_AutoOn);
            this.PFC_Menu.Controls.Add(this.button_PFC_AutoOff);
            this.PFC_Menu.Location = new System.Drawing.Point(679, 33);
            this.PFC_Menu.Name = "PFC_Menu";
            this.PFC_Menu.Size = new System.Drawing.Size(181, 88);
            this.PFC_Menu.TabIndex = 27;
            this.PFC_Menu.TabStop = false;
            this.PFC_Menu.Text = "PFC Control";
            // 
            // button_PFC_Off
            // 
            this.button_PFC_Off.Font = new System.Drawing.Font("PMingLiU", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button_PFC_Off.Location = new System.Drawing.Point(98, 53);
            this.button_PFC_Off.Name = "button_PFC_Off";
            this.button_PFC_Off.Size = new System.Drawing.Size(77, 23);
            this.button_PFC_Off.TabIndex = 28;
            this.button_PFC_Off.Text = "PFC Stop";
            this.button_PFC_Off.UseVisualStyleBackColor = true;
            this.button_PFC_Off.Click += new System.EventHandler(this.button_PFC_Off_Click);
            // 
            // button_PFC_On
            // 
            this.button_PFC_On.Font = new System.Drawing.Font("PMingLiU", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button_PFC_On.Location = new System.Drawing.Point(15, 50);
            this.button_PFC_On.Name = "button_PFC_On";
            this.button_PFC_On.Size = new System.Drawing.Size(74, 23);
            this.button_PFC_On.TabIndex = 27;
            this.button_PFC_On.Text = "PFC On";
            this.button_PFC_On.UseVisualStyleBackColor = true;
            this.button_PFC_On.Click += new System.EventHandler(this.button_PFC_On_Click);
            // 
            // button_PFC_AutoOn
            // 
            this.button_PFC_AutoOn.Font = new System.Drawing.Font("PMingLiU", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button_PFC_AutoOn.Location = new System.Drawing.Point(15, 21);
            this.button_PFC_AutoOn.Name = "button_PFC_AutoOn";
            this.button_PFC_AutoOn.Size = new System.Drawing.Size(74, 23);
            this.button_PFC_AutoOn.TabIndex = 26;
            this.button_PFC_AutoOn.Text = "Auto On";
            this.button_PFC_AutoOn.UseVisualStyleBackColor = true;
            this.button_PFC_AutoOn.Click += new System.EventHandler(this.button_PFC_AutoOn_Click);
            // 
            // button_PFC_AutoOff
            // 
            this.button_PFC_AutoOff.Font = new System.Drawing.Font("PMingLiU", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button_PFC_AutoOff.Location = new System.Drawing.Point(98, 21);
            this.button_PFC_AutoOff.Name = "button_PFC_AutoOff";
            this.button_PFC_AutoOff.Size = new System.Drawing.Size(77, 23);
            this.button_PFC_AutoOff.TabIndex = 25;
            this.button_PFC_AutoOff.Text = "Auto Off";
            this.button_PFC_AutoOff.UseVisualStyleBackColor = true;
            this.button_PFC_AutoOff.Click += new System.EventHandler(this.button_PFC_AutoOff_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.button_2MCU_TX);
            this.groupBox1.Controls.Add(this.button_2MCU_RX);
            this.groupBox1.Location = new System.Drawing.Point(679, 180);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(155, 55);
            this.groupBox1.TabIndex = 24;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "COM2 MCU";
            // 
            // ControMenu_Group
            // 
            this.ControMenu_Group.Controls.Add(this.button_Auto);
            this.ControMenu_Group.Controls.Add(this.button_Manual);
            this.ControMenu_Group.Location = new System.Drawing.Point(461, 28);
            this.ControMenu_Group.Name = "ControMenu_Group";
            this.ControMenu_Group.Size = new System.Drawing.Size(154, 60);
            this.ControMenu_Group.TabIndex = 23;
            this.ControMenu_Group.TabStop = false;
            this.ControMenu_Group.Text = "Control Mode";
            // 
            // button_Auto
            // 
            this.button_Auto.Font = new System.Drawing.Font("PMingLiU", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button_Auto.Location = new System.Drawing.Point(15, 21);
            this.button_Auto.Name = "button_Auto";
            this.button_Auto.Size = new System.Drawing.Size(56, 23);
            this.button_Auto.TabIndex = 26;
            this.button_Auto.Text = "Auto";
            this.button_Auto.UseVisualStyleBackColor = true;
            this.button_Auto.Click += new System.EventHandler(this.button_Auto_Click);
            // 
            // button_Manual
            // 
            this.button_Manual.Font = new System.Drawing.Font("PMingLiU", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button_Manual.Location = new System.Drawing.Point(79, 21);
            this.button_Manual.Name = "button_Manual";
            this.button_Manual.Size = new System.Drawing.Size(56, 23);
            this.button_Manual.TabIndex = 25;
            this.button_Manual.Text = "Manual";
            this.button_Manual.UseVisualStyleBackColor = true;
            this.button_Manual.Click += new System.EventHandler(this.button_Manual_Click);
            // 
            // AutoTest_Tagpage
            // 
            this.AutoTest_Tagpage.BackColor = System.Drawing.Color.Transparent;
            this.AutoTest_Tagpage.Controls.Add(this.AutoTest_Reset_But);
            this.AutoTest_Tagpage.Controls.Add(this.groupBox3);
            this.AutoTest_Tagpage.Controls.Add(this.tableLayoutPanel1);
            this.AutoTest_Tagpage.Controls.Add(this.AutoTest_CmdUpadte_But);
            this.AutoTest_Tagpage.Controls.Add(this.AutoTest_Period_TextBox);
            this.AutoTest_Tagpage.Controls.Add(this.label19);
            this.AutoTest_Tagpage.Controls.Add(this.AutoTest_Run_But);
            this.AutoTest_Tagpage.Location = new System.Drawing.Point(4, 24);
            this.AutoTest_Tagpage.Name = "AutoTest_Tagpage";
            this.AutoTest_Tagpage.Padding = new System.Windows.Forms.Padding(3);
            this.AutoTest_Tagpage.Size = new System.Drawing.Size(885, 569);
            this.AutoTest_Tagpage.TabIndex = 1;
            this.AutoTest_Tagpage.Text = "Auto Test";
            // 
            // AutoTest_Reset_But
            // 
            this.AutoTest_Reset_But.FlatAppearance.BorderSize = 0;
            this.AutoTest_Reset_But.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.AutoTest_Reset_But.ForeColor = System.Drawing.Color.Blue;
            this.AutoTest_Reset_But.Location = new System.Drawing.Point(727, 448);
            this.AutoTest_Reset_But.Name = "AutoTest_Reset_But";
            this.AutoTest_Reset_But.Size = new System.Drawing.Size(86, 37);
            this.AutoTest_Reset_But.TabIndex = 41;
            this.AutoTest_Reset_But.Text = "Reset";
            this.AutoTest_Reset_But.UseVisualStyleBackColor = true;
            this.AutoTest_Reset_But.Click += new System.EventHandler(this.AutoTest_Reset_But_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label20);
            this.groupBox3.Controls.Add(this.label18);
            this.groupBox3.Controls.Add(this.AutoTest_ThisPeriod_Lebel);
            this.groupBox3.Controls.Add(this.AutoTest_ElapsedTime_Lebel);
            this.groupBox3.Controls.Add(this.AutoTest_NumOfTimes_Lebel);
            this.groupBox3.Controls.Add(this.label9);
            this.groupBox3.Location = new System.Drawing.Point(459, 386);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(248, 99);
            this.groupBox3.TabIndex = 40;
            this.groupBox3.TabStop = false;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label20.Location = new System.Drawing.Point(6, 75);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(105, 16);
            this.label20.TabIndex = 43;
            this.label20.Text = "This Period : ";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label18.Location = new System.Drawing.Point(6, 17);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(120, 16);
            this.label18.TabIndex = 42;
            this.label18.Text = "Elasped Time : ";
            // 
            // AutoTest_ThisPeriod_Lebel
            // 
            this.AutoTest_ThisPeriod_Lebel.AutoSize = true;
            this.AutoTest_ThisPeriod_Lebel.Font = new System.Drawing.Font("Arial", 8.999999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AutoTest_ThisPeriod_Lebel.Location = new System.Drawing.Point(117, 76);
            this.AutoTest_ThisPeriod_Lebel.Name = "AutoTest_ThisPeriod_Lebel";
            this.AutoTest_ThisPeriod_Lebel.Size = new System.Drawing.Size(116, 15);
            this.AutoTest_ThisPeriod_Lebel.TabIndex = 41;
            this.AutoTest_ThisPeriod_Lebel.Text = "00:00:00 ~ 00:00:00";
            // 
            // AutoTest_NumOfTimes_Lebel
            // 
            this.AutoTest_NumOfTimes_Lebel.AutoSize = true;
            this.AutoTest_NumOfTimes_Lebel.Font = new System.Drawing.Font("Arial", 8.999999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AutoTest_NumOfTimes_Lebel.Location = new System.Drawing.Point(160, 48);
            this.AutoTest_NumOfTimes_Lebel.Name = "AutoTest_NumOfTimes_Lebel";
            this.AutoTest_NumOfTimes_Lebel.Size = new System.Drawing.Size(14, 15);
            this.AutoTest_NumOfTimes_Lebel.TabIndex = 39;
            this.AutoTest_NumOfTimes_Lebel.Text = "0";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label9.Location = new System.Drawing.Point(6, 46);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(148, 16);
            this.label9.TabIndex = 38;
            this.label9.Text = "Number of Times : ";
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel1.ColumnCount = 5;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 55F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 60F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 60F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 503F));
            this.tableLayoutPanel1.Controls.Add(this.AutoTest_Polling_ChkBox8, 2, 8);
            this.tableLayoutPanel1.Controls.Add(this.AutoTest_Polling_ChkBox7, 2, 7);
            this.tableLayoutPanel1.Controls.Add(this.AutoTest_Polling_ChkBox6, 2, 6);
            this.tableLayoutPanel1.Controls.Add(this.AutoTest_Polling_ChkBox5, 2, 5);
            this.tableLayoutPanel1.Controls.Add(this.AutoTest_Polling_ChkBox4, 2, 4);
            this.tableLayoutPanel1.Controls.Add(this.AutoTest_Polling_ChkBox3, 2, 3);
            this.tableLayoutPanel1.Controls.Add(this.AutoTest_Polling_ChkBox2, 2, 2);
            this.tableLayoutPanel1.Controls.Add(this.AutoTest_Polling_ChkBox10, 2, 10);
            this.tableLayoutPanel1.Controls.Add(this.AutoTest_Polling_ChkBox9, 2, 9);
            this.tableLayoutPanel1.Controls.Add(this.AutoTest_Polling_ChkBox1, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.label21, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.AutoTest_Cmd_textBox10, 4, 10);
            this.tableLayoutPanel1.Controls.Add(this.AutoTest_Enable_ChkBox10, 1, 10);
            this.tableLayoutPanel1.Controls.Add(this.label23, 0, 10);
            this.tableLayoutPanel1.Controls.Add(this.label8, 4, 0);
            this.tableLayoutPanel1.Controls.Add(this.AutoTest_Cmd_textBox1, 4, 1);
            this.tableLayoutPanel1.Controls.Add(this.AutoTest_Cmd_textBox4, 4, 4);
            this.tableLayoutPanel1.Controls.Add(this.AutoTest_Cmd_textBox2, 4, 2);
            this.tableLayoutPanel1.Controls.Add(this.AutoTest_Cmd_textBox3, 4, 3);
            this.tableLayoutPanel1.Controls.Add(this.AutoTest_Cmd_textBox6, 4, 6);
            this.tableLayoutPanel1.Controls.Add(this.AutoTest_Cmd_textBox5, 4, 5);
            this.tableLayoutPanel1.Controls.Add(this.AutoTest_Cmd_textBox7, 4, 7);
            this.tableLayoutPanel1.Controls.Add(this.AutoTest_Cmd_textBox9, 4, 9);
            this.tableLayoutPanel1.Controls.Add(this.AutoTest_Cmd_textBox8, 4, 8);
            this.tableLayoutPanel1.Controls.Add(this.AutoTest_Enable_ChkBox2, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.label5, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.AutoTest_Level1, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.label6, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.label10, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.label11, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.label12, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.label13, 0, 5);
            this.tableLayoutPanel1.Controls.Add(this.label14, 0, 6);
            this.tableLayoutPanel1.Controls.Add(this.label15, 0, 7);
            this.tableLayoutPanel1.Controls.Add(this.label16, 0, 8);
            this.tableLayoutPanel1.Controls.Add(this.label17, 0, 9);
            this.tableLayoutPanel1.Controls.Add(this.AutoTest_Enable_ChkBox1, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.AutoTest_Enable_ChkBox3, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.AutoTest_Enable_ChkBox4, 1, 4);
            this.tableLayoutPanel1.Controls.Add(this.AutoTest_Enable_ChkBox5, 1, 5);
            this.tableLayoutPanel1.Controls.Add(this.AutoTest_Enable_ChkBox6, 1, 6);
            this.tableLayoutPanel1.Controls.Add(this.AutoTest_Enable_ChkBox7, 1, 7);
            this.tableLayoutPanel1.Controls.Add(this.AutoTest_Enable_ChkBox8, 1, 8);
            this.tableLayoutPanel1.Controls.Add(this.AutoTest_Enable_ChkBox9, 1, 9);
            this.tableLayoutPanel1.Controls.Add(this.label7, 3, 0);
            this.tableLayoutPanel1.Controls.Add(this.AutoTest_Time_TextBox1, 3, 1);
            this.tableLayoutPanel1.Controls.Add(this.AutoTest_Time_TextBox2, 3, 2);
            this.tableLayoutPanel1.Controls.Add(this.AutoTest_Time_TextBox3, 3, 3);
            this.tableLayoutPanel1.Controls.Add(this.AutoTest_Time_TextBox4, 3, 4);
            this.tableLayoutPanel1.Controls.Add(this.AutoTest_Time_TextBox5, 3, 5);
            this.tableLayoutPanel1.Controls.Add(this.AutoTest_Time_TextBox6, 3, 6);
            this.tableLayoutPanel1.Controls.Add(this.AutoTest_Time_TextBox7, 3, 7);
            this.tableLayoutPanel1.Controls.Add(this.AutoTest_Time_TextBox8, 3, 8);
            this.tableLayoutPanel1.Controls.Add(this.AutoTest_Time_TextBox9, 3, 9);
            this.tableLayoutPanel1.Controls.Add(this.AutoTest_Time_TextBox10, 3, 10);
            this.tableLayoutPanel1.Controls.Add(this.AutoTest_Enable_ChkBox11, 1, 11);
            this.tableLayoutPanel1.Controls.Add(this.AutoTest_Enable_ChkBox12, 1, 12);
            this.tableLayoutPanel1.Controls.Add(this.AutoTest_Time_TextBox11, 3, 11);
            this.tableLayoutPanel1.Controls.Add(this.AutoTest_Time_TextBox12, 3, 12);
            this.tableLayoutPanel1.Controls.Add(this.AutoTest_Cmd_textBox11, 4, 11);
            this.tableLayoutPanel1.Controls.Add(this.AutoTest_Cmd_textBox12, 4, 12);
            this.tableLayoutPanel1.Font = new System.Drawing.Font("PMingLiU", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.tableLayoutPanel1.Location = new System.Drawing.Point(459, 55);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 13;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(420, 272);
            this.tableLayoutPanel1.TabIndex = 33;
            // 
            // AutoTest_Polling_ChkBox8
            // 
            this.AutoTest_Polling_ChkBox8.AutoSize = true;
            this.AutoTest_Polling_ChkBox8.ForeColor = System.Drawing.Color.Black;
            this.AutoTest_Polling_ChkBox8.Location = new System.Drawing.Point(111, 172);
            this.AutoTest_Polling_ChkBox8.Name = "AutoTest_Polling_ChkBox8";
            this.AutoTest_Polling_ChkBox8.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.AutoTest_Polling_ChkBox8.Size = new System.Drawing.Size(35, 14);
            this.AutoTest_Polling_ChkBox8.TabIndex = 130;
            this.AutoTest_Polling_ChkBox8.UseVisualStyleBackColor = true;
            // 
            // AutoTest_Polling_ChkBox7
            // 
            this.AutoTest_Polling_ChkBox7.AutoSize = true;
            this.AutoTest_Polling_ChkBox7.ForeColor = System.Drawing.Color.Black;
            this.AutoTest_Polling_ChkBox7.Location = new System.Drawing.Point(111, 151);
            this.AutoTest_Polling_ChkBox7.Name = "AutoTest_Polling_ChkBox7";
            this.AutoTest_Polling_ChkBox7.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.AutoTest_Polling_ChkBox7.Size = new System.Drawing.Size(35, 14);
            this.AutoTest_Polling_ChkBox7.TabIndex = 129;
            this.AutoTest_Polling_ChkBox7.UseVisualStyleBackColor = true;
            // 
            // AutoTest_Polling_ChkBox6
            // 
            this.AutoTest_Polling_ChkBox6.AutoSize = true;
            this.AutoTest_Polling_ChkBox6.ForeColor = System.Drawing.Color.Black;
            this.AutoTest_Polling_ChkBox6.Location = new System.Drawing.Point(111, 130);
            this.AutoTest_Polling_ChkBox6.Name = "AutoTest_Polling_ChkBox6";
            this.AutoTest_Polling_ChkBox6.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.AutoTest_Polling_ChkBox6.Size = new System.Drawing.Size(35, 14);
            this.AutoTest_Polling_ChkBox6.TabIndex = 128;
            this.AutoTest_Polling_ChkBox6.UseVisualStyleBackColor = true;
            // 
            // AutoTest_Polling_ChkBox5
            // 
            this.AutoTest_Polling_ChkBox5.AutoSize = true;
            this.AutoTest_Polling_ChkBox5.ForeColor = System.Drawing.Color.Black;
            this.AutoTest_Polling_ChkBox5.Location = new System.Drawing.Point(111, 109);
            this.AutoTest_Polling_ChkBox5.Name = "AutoTest_Polling_ChkBox5";
            this.AutoTest_Polling_ChkBox5.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.AutoTest_Polling_ChkBox5.Size = new System.Drawing.Size(35, 14);
            this.AutoTest_Polling_ChkBox5.TabIndex = 127;
            this.AutoTest_Polling_ChkBox5.UseVisualStyleBackColor = true;
            // 
            // AutoTest_Polling_ChkBox4
            // 
            this.AutoTest_Polling_ChkBox4.AutoSize = true;
            this.AutoTest_Polling_ChkBox4.ForeColor = System.Drawing.Color.Black;
            this.AutoTest_Polling_ChkBox4.Location = new System.Drawing.Point(111, 88);
            this.AutoTest_Polling_ChkBox4.Name = "AutoTest_Polling_ChkBox4";
            this.AutoTest_Polling_ChkBox4.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.AutoTest_Polling_ChkBox4.Size = new System.Drawing.Size(35, 14);
            this.AutoTest_Polling_ChkBox4.TabIndex = 126;
            this.AutoTest_Polling_ChkBox4.UseVisualStyleBackColor = true;
            // 
            // AutoTest_Polling_ChkBox3
            // 
            this.AutoTest_Polling_ChkBox3.AutoSize = true;
            this.AutoTest_Polling_ChkBox3.ForeColor = System.Drawing.Color.Black;
            this.AutoTest_Polling_ChkBox3.Location = new System.Drawing.Point(111, 67);
            this.AutoTest_Polling_ChkBox3.Name = "AutoTest_Polling_ChkBox3";
            this.AutoTest_Polling_ChkBox3.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.AutoTest_Polling_ChkBox3.Size = new System.Drawing.Size(35, 14);
            this.AutoTest_Polling_ChkBox3.TabIndex = 125;
            this.AutoTest_Polling_ChkBox3.UseVisualStyleBackColor = true;
            // 
            // AutoTest_Polling_ChkBox2
            // 
            this.AutoTest_Polling_ChkBox2.AutoSize = true;
            this.AutoTest_Polling_ChkBox2.ForeColor = System.Drawing.Color.Black;
            this.AutoTest_Polling_ChkBox2.Location = new System.Drawing.Point(111, 46);
            this.AutoTest_Polling_ChkBox2.Name = "AutoTest_Polling_ChkBox2";
            this.AutoTest_Polling_ChkBox2.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.AutoTest_Polling_ChkBox2.Size = new System.Drawing.Size(35, 14);
            this.AutoTest_Polling_ChkBox2.TabIndex = 124;
            this.AutoTest_Polling_ChkBox2.UseVisualStyleBackColor = true;
            // 
            // AutoTest_Polling_ChkBox10
            // 
            this.AutoTest_Polling_ChkBox10.AutoSize = true;
            this.AutoTest_Polling_ChkBox10.ForeColor = System.Drawing.Color.Black;
            this.AutoTest_Polling_ChkBox10.Location = new System.Drawing.Point(111, 214);
            this.AutoTest_Polling_ChkBox10.Name = "AutoTest_Polling_ChkBox10";
            this.AutoTest_Polling_ChkBox10.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.AutoTest_Polling_ChkBox10.Size = new System.Drawing.Size(35, 14);
            this.AutoTest_Polling_ChkBox10.TabIndex = 124;
            this.AutoTest_Polling_ChkBox10.UseVisualStyleBackColor = true;
            // 
            // AutoTest_Polling_ChkBox9
            // 
            this.AutoTest_Polling_ChkBox9.AutoSize = true;
            this.AutoTest_Polling_ChkBox9.ForeColor = System.Drawing.Color.Black;
            this.AutoTest_Polling_ChkBox9.Location = new System.Drawing.Point(111, 193);
            this.AutoTest_Polling_ChkBox9.Name = "AutoTest_Polling_ChkBox9";
            this.AutoTest_Polling_ChkBox9.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.AutoTest_Polling_ChkBox9.Size = new System.Drawing.Size(35, 14);
            this.AutoTest_Polling_ChkBox9.TabIndex = 123;
            this.AutoTest_Polling_ChkBox9.UseVisualStyleBackColor = true;
            // 
            // AutoTest_Polling_ChkBox1
            // 
            this.AutoTest_Polling_ChkBox1.AutoSize = true;
            this.AutoTest_Polling_ChkBox1.ForeColor = System.Drawing.Color.Black;
            this.AutoTest_Polling_ChkBox1.Location = new System.Drawing.Point(111, 25);
            this.AutoTest_Polling_ChkBox1.Name = "AutoTest_Polling_ChkBox1";
            this.AutoTest_Polling_ChkBox1.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.AutoTest_Polling_ChkBox1.Size = new System.Drawing.Size(35, 14);
            this.AutoTest_Polling_ChkBox1.TabIndex = 115;
            this.AutoTest_Polling_ChkBox1.UseVisualStyleBackColor = true;
            // 
            // label21
            // 
            this.label21.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label21.ForeColor = System.Drawing.Color.Blue;
            this.label21.Location = new System.Drawing.Point(109, 2);
            this.label21.Margin = new System.Windows.Forms.Padding(1);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(58, 16);
            this.label21.TabIndex = 42;
            this.label21.Tag = "";
            this.label21.Text = "Polling";
            this.label21.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // AutoTest_Cmd_textBox10
            // 
            this.AutoTest_Cmd_textBox10.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.AutoTest_Cmd_textBox10.Font = new System.Drawing.Font("Arial Unicode MS", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AutoTest_Cmd_textBox10.Location = new System.Drawing.Point(232, 213);
            this.AutoTest_Cmd_textBox10.Margin = new System.Windows.Forms.Padding(2);
            this.AutoTest_Cmd_textBox10.Name = "AutoTest_Cmd_textBox10";
            this.AutoTest_Cmd_textBox10.Size = new System.Drawing.Size(187, 18);
            this.AutoTest_Cmd_textBox10.TabIndex = 114;
            this.AutoTest_Cmd_textBox10.TabStop = false;
            this.AutoTest_Cmd_textBox10.Text = "02 03 00 00 00 00 00 00 00 FB";
            // 
            // AutoTest_Enable_ChkBox10
            // 
            this.AutoTest_Enable_ChkBox10.AutoSize = true;
            this.AutoTest_Enable_ChkBox10.Checked = true;
            this.AutoTest_Enable_ChkBox10.CheckState = System.Windows.Forms.CheckState.Checked;
            this.AutoTest_Enable_ChkBox10.ForeColor = System.Drawing.Color.Black;
            this.AutoTest_Enable_ChkBox10.Location = new System.Drawing.Point(55, 214);
            this.AutoTest_Enable_ChkBox10.Name = "AutoTest_Enable_ChkBox10";
            this.AutoTest_Enable_ChkBox10.Padding = new System.Windows.Forms.Padding(17, 0, 0, 0);
            this.AutoTest_Enable_ChkBox10.Size = new System.Drawing.Size(32, 14);
            this.AutoTest_Enable_ChkBox10.TabIndex = 112;
            this.AutoTest_Enable_ChkBox10.UseVisualStyleBackColor = true;
            // 
            // label23
            // 
            this.label23.Location = new System.Drawing.Point(2, 212);
            this.label23.Margin = new System.Windows.Forms.Padding(1);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(48, 18);
            this.label23.TabIndex = 46;
            this.label23.Tag = "";
            this.label23.Text = "End";
            this.label23.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label8
            // 
            this.label8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label8.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label8.ForeColor = System.Drawing.Color.Blue;
            this.label8.Location = new System.Drawing.Point(231, 2);
            this.label8.Margin = new System.Windows.Forms.Padding(1);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(188, 18);
            this.label8.TabIndex = 36;
            this.label8.Tag = "";
            this.label8.Text = "Command Code";
            this.label8.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // AutoTest_Cmd_textBox1
            // 
            this.AutoTest_Cmd_textBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.AutoTest_Cmd_textBox1.Font = new System.Drawing.Font("Arial Unicode MS", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AutoTest_Cmd_textBox1.Location = new System.Drawing.Point(232, 24);
            this.AutoTest_Cmd_textBox1.Margin = new System.Windows.Forms.Padding(2);
            this.AutoTest_Cmd_textBox1.Name = "AutoTest_Cmd_textBox1";
            this.AutoTest_Cmd_textBox1.Size = new System.Drawing.Size(187, 18);
            this.AutoTest_Cmd_textBox1.TabIndex = 83;
            this.AutoTest_Cmd_textBox1.TabStop = false;
            this.AutoTest_Cmd_textBox1.Text = "02 01 00 00 00 00 00 00 00 FD";
            // 
            // AutoTest_Cmd_textBox4
            // 
            this.AutoTest_Cmd_textBox4.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.AutoTest_Cmd_textBox4.Font = new System.Drawing.Font("Arial Unicode MS", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AutoTest_Cmd_textBox4.Location = new System.Drawing.Point(232, 87);
            this.AutoTest_Cmd_textBox4.Margin = new System.Windows.Forms.Padding(2);
            this.AutoTest_Cmd_textBox4.Name = "AutoTest_Cmd_textBox4";
            this.AutoTest_Cmd_textBox4.Size = new System.Drawing.Size(187, 18);
            this.AutoTest_Cmd_textBox4.TabIndex = 86;
            this.AutoTest_Cmd_textBox4.TabStop = false;
            this.AutoTest_Cmd_textBox4.Text = "00 00 00 00 00 00 00 00 00 00";
            // 
            // AutoTest_Cmd_textBox2
            // 
            this.AutoTest_Cmd_textBox2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.AutoTest_Cmd_textBox2.Font = new System.Drawing.Font("Arial Unicode MS", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AutoTest_Cmd_textBox2.Location = new System.Drawing.Point(232, 45);
            this.AutoTest_Cmd_textBox2.Margin = new System.Windows.Forms.Padding(2);
            this.AutoTest_Cmd_textBox2.Name = "AutoTest_Cmd_textBox2";
            this.AutoTest_Cmd_textBox2.Size = new System.Drawing.Size(187, 18);
            this.AutoTest_Cmd_textBox2.TabIndex = 84;
            this.AutoTest_Cmd_textBox2.TabStop = false;
            this.AutoTest_Cmd_textBox2.Text = "06 31 3C 00 00 00 00 00 00 8D";
            // 
            // AutoTest_Cmd_textBox3
            // 
            this.AutoTest_Cmd_textBox3.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.AutoTest_Cmd_textBox3.Font = new System.Drawing.Font("Arial Unicode MS", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AutoTest_Cmd_textBox3.Location = new System.Drawing.Point(232, 66);
            this.AutoTest_Cmd_textBox3.Margin = new System.Windows.Forms.Padding(2);
            this.AutoTest_Cmd_textBox3.Name = "AutoTest_Cmd_textBox3";
            this.AutoTest_Cmd_textBox3.Size = new System.Drawing.Size(187, 18);
            this.AutoTest_Cmd_textBox3.TabIndex = 85;
            this.AutoTest_Cmd_textBox3.TabStop = false;
            this.AutoTest_Cmd_textBox3.Text = "04 01 02 00 00 00 00 00 00 F9 ";
            // 
            // AutoTest_Cmd_textBox6
            // 
            this.AutoTest_Cmd_textBox6.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.AutoTest_Cmd_textBox6.Font = new System.Drawing.Font("Arial Unicode MS", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AutoTest_Cmd_textBox6.Location = new System.Drawing.Point(232, 129);
            this.AutoTest_Cmd_textBox6.Margin = new System.Windows.Forms.Padding(2);
            this.AutoTest_Cmd_textBox6.Name = "AutoTest_Cmd_textBox6";
            this.AutoTest_Cmd_textBox6.Size = new System.Drawing.Size(187, 18);
            this.AutoTest_Cmd_textBox6.TabIndex = 88;
            this.AutoTest_Cmd_textBox6.TabStop = false;
            this.AutoTest_Cmd_textBox6.Text = "00 00 00 00 00 00 00 00 00 00";
            // 
            // AutoTest_Cmd_textBox5
            // 
            this.AutoTest_Cmd_textBox5.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.AutoTest_Cmd_textBox5.Font = new System.Drawing.Font("Arial Unicode MS", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AutoTest_Cmd_textBox5.Location = new System.Drawing.Point(232, 108);
            this.AutoTest_Cmd_textBox5.Margin = new System.Windows.Forms.Padding(2);
            this.AutoTest_Cmd_textBox5.Name = "AutoTest_Cmd_textBox5";
            this.AutoTest_Cmd_textBox5.Size = new System.Drawing.Size(187, 18);
            this.AutoTest_Cmd_textBox5.TabIndex = 87;
            this.AutoTest_Cmd_textBox5.TabStop = false;
            this.AutoTest_Cmd_textBox5.Text = "00 00 00 00 00 00 00 00 00 00";
            // 
            // AutoTest_Cmd_textBox7
            // 
            this.AutoTest_Cmd_textBox7.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.AutoTest_Cmd_textBox7.Font = new System.Drawing.Font("Arial Unicode MS", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AutoTest_Cmd_textBox7.Location = new System.Drawing.Point(232, 150);
            this.AutoTest_Cmd_textBox7.Margin = new System.Windows.Forms.Padding(2);
            this.AutoTest_Cmd_textBox7.Name = "AutoTest_Cmd_textBox7";
            this.AutoTest_Cmd_textBox7.Size = new System.Drawing.Size(187, 18);
            this.AutoTest_Cmd_textBox7.TabIndex = 89;
            this.AutoTest_Cmd_textBox7.TabStop = false;
            this.AutoTest_Cmd_textBox7.Text = "00 00 00 00 00 00 00 00 00 00";
            // 
            // AutoTest_Cmd_textBox9
            // 
            this.AutoTest_Cmd_textBox9.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.AutoTest_Cmd_textBox9.Font = new System.Drawing.Font("Arial Unicode MS", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AutoTest_Cmd_textBox9.Location = new System.Drawing.Point(232, 192);
            this.AutoTest_Cmd_textBox9.Margin = new System.Windows.Forms.Padding(2);
            this.AutoTest_Cmd_textBox9.Name = "AutoTest_Cmd_textBox9";
            this.AutoTest_Cmd_textBox9.Size = new System.Drawing.Size(187, 18);
            this.AutoTest_Cmd_textBox9.TabIndex = 91;
            this.AutoTest_Cmd_textBox9.TabStop = false;
            this.AutoTest_Cmd_textBox9.Text = "00 00 00 00 00 00 00 00 00 00";
            // 
            // AutoTest_Cmd_textBox8
            // 
            this.AutoTest_Cmd_textBox8.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.AutoTest_Cmd_textBox8.Font = new System.Drawing.Font("Arial Unicode MS", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AutoTest_Cmd_textBox8.Location = new System.Drawing.Point(232, 171);
            this.AutoTest_Cmd_textBox8.Margin = new System.Windows.Forms.Padding(2);
            this.AutoTest_Cmd_textBox8.Name = "AutoTest_Cmd_textBox8";
            this.AutoTest_Cmd_textBox8.Size = new System.Drawing.Size(187, 18);
            this.AutoTest_Cmd_textBox8.TabIndex = 90;
            this.AutoTest_Cmd_textBox8.TabStop = false;
            this.AutoTest_Cmd_textBox8.Text = "00 00 00 00 00 00 00 00 00 00";
            // 
            // AutoTest_Enable_ChkBox2
            // 
            this.AutoTest_Enable_ChkBox2.AutoSize = true;
            this.AutoTest_Enable_ChkBox2.Checked = true;
            this.AutoTest_Enable_ChkBox2.CheckState = System.Windows.Forms.CheckState.Checked;
            this.AutoTest_Enable_ChkBox2.ForeColor = System.Drawing.Color.Black;
            this.AutoTest_Enable_ChkBox2.Location = new System.Drawing.Point(55, 46);
            this.AutoTest_Enable_ChkBox2.Name = "AutoTest_Enable_ChkBox2";
            this.AutoTest_Enable_ChkBox2.Padding = new System.Windows.Forms.Padding(17, 0, 0, 0);
            this.AutoTest_Enable_ChkBox2.Size = new System.Drawing.Size(32, 14);
            this.AutoTest_Enable_ChkBox2.TabIndex = 47;
            this.AutoTest_Enable_ChkBox2.UseVisualStyleBackColor = true;
            // 
            // label5
            // 
            this.label5.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label5.ForeColor = System.Drawing.Color.Blue;
            this.label5.Location = new System.Drawing.Point(2, 2);
            this.label5.Margin = new System.Windows.Forms.Padding(1);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(48, 18);
            this.label5.TabIndex = 34;
            this.label5.Tag = "";
            this.label5.Text = "Step";
            this.label5.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // AutoTest_Level1
            // 
            this.AutoTest_Level1.Font = new System.Drawing.Font("PMingLiU", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.AutoTest_Level1.Location = new System.Drawing.Point(2, 23);
            this.AutoTest_Level1.Margin = new System.Windows.Forms.Padding(1);
            this.AutoTest_Level1.Name = "AutoTest_Level1";
            this.AutoTest_Level1.Size = new System.Drawing.Size(48, 18);
            this.AutoTest_Level1.TabIndex = 32;
            this.AutoTest_Level1.Tag = "";
            this.AutoTest_Level1.Text = "Start";
            this.AutoTest_Level1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label6.ForeColor = System.Drawing.Color.Blue;
            this.label6.Location = new System.Drawing.Point(53, 2);
            this.label6.Margin = new System.Windows.Forms.Padding(1);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(53, 16);
            this.label6.TabIndex = 34;
            this.label6.Tag = "";
            this.label6.Text = "Enable";
            this.label6.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label10
            // 
            this.label10.Location = new System.Drawing.Point(2, 44);
            this.label10.Margin = new System.Windows.Forms.Padding(1);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(48, 18);
            this.label10.TabIndex = 38;
            this.label10.Tag = "";
            this.label10.Text = "Step1";
            this.label10.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label11
            // 
            this.label11.Location = new System.Drawing.Point(2, 65);
            this.label11.Margin = new System.Windows.Forms.Padding(1);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(48, 18);
            this.label11.TabIndex = 39;
            this.label11.Tag = "";
            this.label11.Text = "Step2";
            this.label11.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label12
            // 
            this.label12.Location = new System.Drawing.Point(2, 86);
            this.label12.Margin = new System.Windows.Forms.Padding(1);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(48, 18);
            this.label12.TabIndex = 40;
            this.label12.Tag = "";
            this.label12.Text = "Step3";
            this.label12.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label13
            // 
            this.label13.Location = new System.Drawing.Point(2, 107);
            this.label13.Margin = new System.Windows.Forms.Padding(1);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(48, 18);
            this.label13.TabIndex = 41;
            this.label13.Tag = "";
            this.label13.Text = "Step4";
            this.label13.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label14
            // 
            this.label14.Location = new System.Drawing.Point(2, 128);
            this.label14.Margin = new System.Windows.Forms.Padding(1);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(48, 18);
            this.label14.TabIndex = 42;
            this.label14.Tag = "";
            this.label14.Text = "Step5";
            this.label14.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label15
            // 
            this.label15.Location = new System.Drawing.Point(2, 149);
            this.label15.Margin = new System.Windows.Forms.Padding(1);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(48, 18);
            this.label15.TabIndex = 43;
            this.label15.Tag = "";
            this.label15.Text = "Step6";
            this.label15.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label16
            // 
            this.label16.Location = new System.Drawing.Point(2, 170);
            this.label16.Margin = new System.Windows.Forms.Padding(1);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(48, 18);
            this.label16.TabIndex = 44;
            this.label16.Tag = "";
            this.label16.Text = "Step7";
            this.label16.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label17
            // 
            this.label17.Location = new System.Drawing.Point(2, 191);
            this.label17.Margin = new System.Windows.Forms.Padding(1);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(48, 18);
            this.label17.TabIndex = 45;
            this.label17.Tag = "";
            this.label17.Text = "Step8";
            this.label17.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // AutoTest_Enable_ChkBox1
            // 
            this.AutoTest_Enable_ChkBox1.AutoSize = true;
            this.AutoTest_Enable_ChkBox1.Checked = true;
            this.AutoTest_Enable_ChkBox1.CheckState = System.Windows.Forms.CheckState.Checked;
            this.AutoTest_Enable_ChkBox1.ForeColor = System.Drawing.Color.Black;
            this.AutoTest_Enable_ChkBox1.Location = new System.Drawing.Point(55, 25);
            this.AutoTest_Enable_ChkBox1.Name = "AutoTest_Enable_ChkBox1";
            this.AutoTest_Enable_ChkBox1.Padding = new System.Windows.Forms.Padding(17, 0, 0, 0);
            this.AutoTest_Enable_ChkBox1.Size = new System.Drawing.Size(32, 14);
            this.AutoTest_Enable_ChkBox1.TabIndex = 34;
            this.AutoTest_Enable_ChkBox1.UseVisualStyleBackColor = true;
            // 
            // AutoTest_Enable_ChkBox3
            // 
            this.AutoTest_Enable_ChkBox3.AutoSize = true;
            this.AutoTest_Enable_ChkBox3.Checked = true;
            this.AutoTest_Enable_ChkBox3.CheckState = System.Windows.Forms.CheckState.Checked;
            this.AutoTest_Enable_ChkBox3.ForeColor = System.Drawing.Color.Black;
            this.AutoTest_Enable_ChkBox3.Location = new System.Drawing.Point(55, 67);
            this.AutoTest_Enable_ChkBox3.Name = "AutoTest_Enable_ChkBox3";
            this.AutoTest_Enable_ChkBox3.Padding = new System.Windows.Forms.Padding(17, 0, 0, 0);
            this.AutoTest_Enable_ChkBox3.Size = new System.Drawing.Size(32, 14);
            this.AutoTest_Enable_ChkBox3.TabIndex = 48;
            this.AutoTest_Enable_ChkBox3.UseVisualStyleBackColor = true;
            // 
            // AutoTest_Enable_ChkBox4
            // 
            this.AutoTest_Enable_ChkBox4.AutoSize = true;
            this.AutoTest_Enable_ChkBox4.ForeColor = System.Drawing.Color.Black;
            this.AutoTest_Enable_ChkBox4.Location = new System.Drawing.Point(55, 88);
            this.AutoTest_Enable_ChkBox4.Name = "AutoTest_Enable_ChkBox4";
            this.AutoTest_Enable_ChkBox4.Padding = new System.Windows.Forms.Padding(17, 0, 0, 0);
            this.AutoTest_Enable_ChkBox4.Size = new System.Drawing.Size(32, 14);
            this.AutoTest_Enable_ChkBox4.TabIndex = 46;
            this.AutoTest_Enable_ChkBox4.UseVisualStyleBackColor = true;
            // 
            // AutoTest_Enable_ChkBox5
            // 
            this.AutoTest_Enable_ChkBox5.AutoSize = true;
            this.AutoTest_Enable_ChkBox5.ForeColor = System.Drawing.Color.Black;
            this.AutoTest_Enable_ChkBox5.Location = new System.Drawing.Point(55, 109);
            this.AutoTest_Enable_ChkBox5.Name = "AutoTest_Enable_ChkBox5";
            this.AutoTest_Enable_ChkBox5.Padding = new System.Windows.Forms.Padding(17, 0, 0, 0);
            this.AutoTest_Enable_ChkBox5.Size = new System.Drawing.Size(32, 14);
            this.AutoTest_Enable_ChkBox5.TabIndex = 49;
            this.AutoTest_Enable_ChkBox5.UseVisualStyleBackColor = true;
            // 
            // AutoTest_Enable_ChkBox6
            // 
            this.AutoTest_Enable_ChkBox6.AutoSize = true;
            this.AutoTest_Enable_ChkBox6.ForeColor = System.Drawing.Color.Black;
            this.AutoTest_Enable_ChkBox6.Location = new System.Drawing.Point(55, 130);
            this.AutoTest_Enable_ChkBox6.Name = "AutoTest_Enable_ChkBox6";
            this.AutoTest_Enable_ChkBox6.Padding = new System.Windows.Forms.Padding(17, 0, 0, 0);
            this.AutoTest_Enable_ChkBox6.Size = new System.Drawing.Size(32, 14);
            this.AutoTest_Enable_ChkBox6.TabIndex = 51;
            this.AutoTest_Enable_ChkBox6.UseVisualStyleBackColor = true;
            // 
            // AutoTest_Enable_ChkBox7
            // 
            this.AutoTest_Enable_ChkBox7.AutoSize = true;
            this.AutoTest_Enable_ChkBox7.ForeColor = System.Drawing.Color.Black;
            this.AutoTest_Enable_ChkBox7.Location = new System.Drawing.Point(55, 151);
            this.AutoTest_Enable_ChkBox7.Name = "AutoTest_Enable_ChkBox7";
            this.AutoTest_Enable_ChkBox7.Padding = new System.Windows.Forms.Padding(17, 0, 0, 0);
            this.AutoTest_Enable_ChkBox7.Size = new System.Drawing.Size(32, 14);
            this.AutoTest_Enable_ChkBox7.TabIndex = 50;
            this.AutoTest_Enable_ChkBox7.UseVisualStyleBackColor = true;
            // 
            // AutoTest_Enable_ChkBox8
            // 
            this.AutoTest_Enable_ChkBox8.AutoSize = true;
            this.AutoTest_Enable_ChkBox8.ForeColor = System.Drawing.Color.Black;
            this.AutoTest_Enable_ChkBox8.Location = new System.Drawing.Point(55, 172);
            this.AutoTest_Enable_ChkBox8.Name = "AutoTest_Enable_ChkBox8";
            this.AutoTest_Enable_ChkBox8.Padding = new System.Windows.Forms.Padding(17, 0, 0, 0);
            this.AutoTest_Enable_ChkBox8.Size = new System.Drawing.Size(32, 14);
            this.AutoTest_Enable_ChkBox8.TabIndex = 52;
            this.AutoTest_Enable_ChkBox8.UseVisualStyleBackColor = true;
            // 
            // AutoTest_Enable_ChkBox9
            // 
            this.AutoTest_Enable_ChkBox9.AutoSize = true;
            this.AutoTest_Enable_ChkBox9.ForeColor = System.Drawing.Color.Black;
            this.AutoTest_Enable_ChkBox9.Location = new System.Drawing.Point(55, 193);
            this.AutoTest_Enable_ChkBox9.Name = "AutoTest_Enable_ChkBox9";
            this.AutoTest_Enable_ChkBox9.Padding = new System.Windows.Forms.Padding(17, 0, 0, 0);
            this.AutoTest_Enable_ChkBox9.Size = new System.Drawing.Size(32, 14);
            this.AutoTest_Enable_ChkBox9.TabIndex = 53;
            this.AutoTest_Enable_ChkBox9.UseVisualStyleBackColor = true;
            // 
            // label7
            // 
            this.label7.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label7.ForeColor = System.Drawing.Color.Blue;
            this.label7.Location = new System.Drawing.Point(170, 2);
            this.label7.Margin = new System.Windows.Forms.Padding(1);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(58, 18);
            this.label7.TabIndex = 35;
            this.label7.Tag = "";
            this.label7.Text = "Time";
            this.label7.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // AutoTest_Time_TextBox1
            // 
            this.AutoTest_Time_TextBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.AutoTest_Time_TextBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AutoTest_Time_TextBox1.Location = new System.Drawing.Point(170, 23);
            this.AutoTest_Time_TextBox1.Margin = new System.Windows.Forms.Padding(1);
            this.AutoTest_Time_TextBox1.Name = "AutoTest_Time_TextBox1";
            this.AutoTest_Time_TextBox1.Size = new System.Drawing.Size(58, 15);
            this.AutoTest_Time_TextBox1.TabIndex = 103;
            this.AutoTest_Time_TextBox1.TabStop = false;
            this.AutoTest_Time_TextBox1.Text = "0";
            this.AutoTest_Time_TextBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // AutoTest_Time_TextBox2
            // 
            this.AutoTest_Time_TextBox2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.AutoTest_Time_TextBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AutoTest_Time_TextBox2.Location = new System.Drawing.Point(170, 44);
            this.AutoTest_Time_TextBox2.Margin = new System.Windows.Forms.Padding(1);
            this.AutoTest_Time_TextBox2.Name = "AutoTest_Time_TextBox2";
            this.AutoTest_Time_TextBox2.Size = new System.Drawing.Size(58, 15);
            this.AutoTest_Time_TextBox2.TabIndex = 104;
            this.AutoTest_Time_TextBox2.TabStop = false;
            this.AutoTest_Time_TextBox2.Text = "30";
            this.AutoTest_Time_TextBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // AutoTest_Time_TextBox3
            // 
            this.AutoTest_Time_TextBox3.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.AutoTest_Time_TextBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AutoTest_Time_TextBox3.Location = new System.Drawing.Point(170, 65);
            this.AutoTest_Time_TextBox3.Margin = new System.Windows.Forms.Padding(1);
            this.AutoTest_Time_TextBox3.Name = "AutoTest_Time_TextBox3";
            this.AutoTest_Time_TextBox3.Size = new System.Drawing.Size(58, 15);
            this.AutoTest_Time_TextBox3.TabIndex = 105;
            this.AutoTest_Time_TextBox3.TabStop = false;
            this.AutoTest_Time_TextBox3.Text = "350";
            this.AutoTest_Time_TextBox3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // AutoTest_Time_TextBox4
            // 
            this.AutoTest_Time_TextBox4.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.AutoTest_Time_TextBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AutoTest_Time_TextBox4.Location = new System.Drawing.Point(170, 86);
            this.AutoTest_Time_TextBox4.Margin = new System.Windows.Forms.Padding(1);
            this.AutoTest_Time_TextBox4.Name = "AutoTest_Time_TextBox4";
            this.AutoTest_Time_TextBox4.Size = new System.Drawing.Size(58, 15);
            this.AutoTest_Time_TextBox4.TabIndex = 106;
            this.AutoTest_Time_TextBox4.TabStop = false;
            this.AutoTest_Time_TextBox4.Text = "0";
            this.AutoTest_Time_TextBox4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // AutoTest_Time_TextBox5
            // 
            this.AutoTest_Time_TextBox5.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.AutoTest_Time_TextBox5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AutoTest_Time_TextBox5.Location = new System.Drawing.Point(170, 107);
            this.AutoTest_Time_TextBox5.Margin = new System.Windows.Forms.Padding(1);
            this.AutoTest_Time_TextBox5.Name = "AutoTest_Time_TextBox5";
            this.AutoTest_Time_TextBox5.Size = new System.Drawing.Size(58, 15);
            this.AutoTest_Time_TextBox5.TabIndex = 107;
            this.AutoTest_Time_TextBox5.TabStop = false;
            this.AutoTest_Time_TextBox5.Text = "0";
            this.AutoTest_Time_TextBox5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // AutoTest_Time_TextBox6
            // 
            this.AutoTest_Time_TextBox6.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.AutoTest_Time_TextBox6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AutoTest_Time_TextBox6.Location = new System.Drawing.Point(170, 128);
            this.AutoTest_Time_TextBox6.Margin = new System.Windows.Forms.Padding(1);
            this.AutoTest_Time_TextBox6.Name = "AutoTest_Time_TextBox6";
            this.AutoTest_Time_TextBox6.Size = new System.Drawing.Size(58, 15);
            this.AutoTest_Time_TextBox6.TabIndex = 108;
            this.AutoTest_Time_TextBox6.TabStop = false;
            this.AutoTest_Time_TextBox6.Text = "0";
            this.AutoTest_Time_TextBox6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // AutoTest_Time_TextBox7
            // 
            this.AutoTest_Time_TextBox7.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.AutoTest_Time_TextBox7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AutoTest_Time_TextBox7.Location = new System.Drawing.Point(170, 149);
            this.AutoTest_Time_TextBox7.Margin = new System.Windows.Forms.Padding(1);
            this.AutoTest_Time_TextBox7.Name = "AutoTest_Time_TextBox7";
            this.AutoTest_Time_TextBox7.Size = new System.Drawing.Size(58, 15);
            this.AutoTest_Time_TextBox7.TabIndex = 109;
            this.AutoTest_Time_TextBox7.TabStop = false;
            this.AutoTest_Time_TextBox7.Text = "0";
            this.AutoTest_Time_TextBox7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // AutoTest_Time_TextBox8
            // 
            this.AutoTest_Time_TextBox8.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.AutoTest_Time_TextBox8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AutoTest_Time_TextBox8.Location = new System.Drawing.Point(170, 170);
            this.AutoTest_Time_TextBox8.Margin = new System.Windows.Forms.Padding(1);
            this.AutoTest_Time_TextBox8.Name = "AutoTest_Time_TextBox8";
            this.AutoTest_Time_TextBox8.Size = new System.Drawing.Size(58, 15);
            this.AutoTest_Time_TextBox8.TabIndex = 110;
            this.AutoTest_Time_TextBox8.TabStop = false;
            this.AutoTest_Time_TextBox8.Text = "0";
            this.AutoTest_Time_TextBox8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // AutoTest_Time_TextBox9
            // 
            this.AutoTest_Time_TextBox9.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.AutoTest_Time_TextBox9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AutoTest_Time_TextBox9.Location = new System.Drawing.Point(170, 191);
            this.AutoTest_Time_TextBox9.Margin = new System.Windows.Forms.Padding(1);
            this.AutoTest_Time_TextBox9.Name = "AutoTest_Time_TextBox9";
            this.AutoTest_Time_TextBox9.Size = new System.Drawing.Size(58, 15);
            this.AutoTest_Time_TextBox9.TabIndex = 111;
            this.AutoTest_Time_TextBox9.TabStop = false;
            this.AutoTest_Time_TextBox9.Text = "0";
            this.AutoTest_Time_TextBox9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // AutoTest_Time_TextBox10
            // 
            this.AutoTest_Time_TextBox10.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.AutoTest_Time_TextBox10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AutoTest_Time_TextBox10.Location = new System.Drawing.Point(170, 212);
            this.AutoTest_Time_TextBox10.Margin = new System.Windows.Forms.Padding(1);
            this.AutoTest_Time_TextBox10.Name = "AutoTest_Time_TextBox10";
            this.AutoTest_Time_TextBox10.Size = new System.Drawing.Size(58, 15);
            this.AutoTest_Time_TextBox10.TabIndex = 113;
            this.AutoTest_Time_TextBox10.TabStop = false;
            this.AutoTest_Time_TextBox10.Text = "180";
            this.AutoTest_Time_TextBox10.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // AutoTest_Enable_ChkBox11
            // 
            this.AutoTest_Enable_ChkBox11.AutoSize = true;
            this.AutoTest_Enable_ChkBox11.Checked = true;
            this.AutoTest_Enable_ChkBox11.CheckState = System.Windows.Forms.CheckState.Checked;
            this.AutoTest_Enable_ChkBox11.ForeColor = System.Drawing.Color.Black;
            this.AutoTest_Enable_ChkBox11.Location = new System.Drawing.Point(55, 235);
            this.AutoTest_Enable_ChkBox11.Name = "AutoTest_Enable_ChkBox11";
            this.AutoTest_Enable_ChkBox11.Padding = new System.Windows.Forms.Padding(17, 0, 0, 0);
            this.AutoTest_Enable_ChkBox11.Size = new System.Drawing.Size(32, 14);
            this.AutoTest_Enable_ChkBox11.TabIndex = 131;
            this.AutoTest_Enable_ChkBox11.UseVisualStyleBackColor = true;
            // 
            // AutoTest_Enable_ChkBox12
            // 
            this.AutoTest_Enable_ChkBox12.AutoSize = true;
            this.AutoTest_Enable_ChkBox12.Checked = true;
            this.AutoTest_Enable_ChkBox12.CheckState = System.Windows.Forms.CheckState.Checked;
            this.AutoTest_Enable_ChkBox12.ForeColor = System.Drawing.Color.Black;
            this.AutoTest_Enable_ChkBox12.Location = new System.Drawing.Point(55, 256);
            this.AutoTest_Enable_ChkBox12.Name = "AutoTest_Enable_ChkBox12";
            this.AutoTest_Enable_ChkBox12.Padding = new System.Windows.Forms.Padding(17, 0, 0, 0);
            this.AutoTest_Enable_ChkBox12.Size = new System.Drawing.Size(32, 14);
            this.AutoTest_Enable_ChkBox12.TabIndex = 132;
            this.AutoTest_Enable_ChkBox12.UseVisualStyleBackColor = true;
            // 
            // AutoTest_Time_TextBox11
            // 
            this.AutoTest_Time_TextBox11.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.AutoTest_Time_TextBox11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AutoTest_Time_TextBox11.Location = new System.Drawing.Point(170, 233);
            this.AutoTest_Time_TextBox11.Margin = new System.Windows.Forms.Padding(1);
            this.AutoTest_Time_TextBox11.Name = "AutoTest_Time_TextBox11";
            this.AutoTest_Time_TextBox11.Size = new System.Drawing.Size(58, 15);
            this.AutoTest_Time_TextBox11.TabIndex = 133;
            this.AutoTest_Time_TextBox11.TabStop = false;
            this.AutoTest_Time_TextBox11.Text = "220";
            this.AutoTest_Time_TextBox11.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // AutoTest_Time_TextBox12
            // 
            this.AutoTest_Time_TextBox12.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.AutoTest_Time_TextBox12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AutoTest_Time_TextBox12.Location = new System.Drawing.Point(170, 254);
            this.AutoTest_Time_TextBox12.Margin = new System.Windows.Forms.Padding(1);
            this.AutoTest_Time_TextBox12.Name = "AutoTest_Time_TextBox12";
            this.AutoTest_Time_TextBox12.Size = new System.Drawing.Size(58, 15);
            this.AutoTest_Time_TextBox12.TabIndex = 134;
            this.AutoTest_Time_TextBox12.TabStop = false;
            this.AutoTest_Time_TextBox12.Text = "230";
            this.AutoTest_Time_TextBox12.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // AutoTest_Cmd_textBox11
            // 
            this.AutoTest_Cmd_textBox11.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.AutoTest_Cmd_textBox11.Font = new System.Drawing.Font("Arial Unicode MS", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AutoTest_Cmd_textBox11.Location = new System.Drawing.Point(232, 234);
            this.AutoTest_Cmd_textBox11.Margin = new System.Windows.Forms.Padding(2);
            this.AutoTest_Cmd_textBox11.Name = "AutoTest_Cmd_textBox11";
            this.AutoTest_Cmd_textBox11.Size = new System.Drawing.Size(187, 18);
            this.AutoTest_Cmd_textBox11.TabIndex = 135;
            this.AutoTest_Cmd_textBox11.TabStop = false;
            this.AutoTest_Cmd_textBox11.Text = "StartUp(Is, ω) Record";
            // 
            // AutoTest_Cmd_textBox12
            // 
            this.AutoTest_Cmd_textBox12.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.AutoTest_Cmd_textBox12.Font = new System.Drawing.Font("Arial Unicode MS", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AutoTest_Cmd_textBox12.Location = new System.Drawing.Point(232, 255);
            this.AutoTest_Cmd_textBox12.Margin = new System.Windows.Forms.Padding(2);
            this.AutoTest_Cmd_textBox12.Name = "AutoTest_Cmd_textBox12";
            this.AutoTest_Cmd_textBox12.Size = new System.Drawing.Size(187, 18);
            this.AutoTest_Cmd_textBox12.TabIndex = 136;
            this.AutoTest_Cmd_textBox12.TabStop = false;
            this.AutoTest_Cmd_textBox12.Text = "StartUp(Theta) Record";
            // 
            // AutoTest_CmdUpadte_But
            // 
            this.AutoTest_CmdUpadte_But.FlatAppearance.BorderSize = 0;
            this.AutoTest_CmdUpadte_But.Location = new System.Drawing.Point(450, 346);
            this.AutoTest_CmdUpadte_But.Name = "AutoTest_CmdUpadte_But";
            this.AutoTest_CmdUpadte_But.Size = new System.Drawing.Size(106, 23);
            this.AutoTest_CmdUpadte_But.TabIndex = 37;
            this.AutoTest_CmdUpadte_But.Text = "Command Update";
            this.AutoTest_CmdUpadte_But.UseVisualStyleBackColor = true;
            this.AutoTest_CmdUpadte_But.Click += new System.EventHandler(this.AutoTest_CmdUpadte_But_Click);
            // 
            // AutoTest_Period_TextBox
            // 
            this.AutoTest_Period_TextBox.Font = new System.Drawing.Font("PMingLiU", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.AutoTest_Period_TextBox.ForeColor = System.Drawing.Color.Red;
            this.AutoTest_Period_TextBox.Location = new System.Drawing.Point(562, 30);
            this.AutoTest_Period_TextBox.Name = "AutoTest_Period_TextBox";
            this.AutoTest_Period_TextBox.Size = new System.Drawing.Size(49, 23);
            this.AutoTest_Period_TextBox.TabIndex = 36;
            this.AutoTest_Period_TextBox.Text = "360";
            this.AutoTest_Period_TextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("PMingLiU", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label19.ForeColor = System.Drawing.Color.Firebrick;
            this.label19.Location = new System.Drawing.Point(461, 30);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(95, 14);
            this.label19.TabIndex = 35;
            this.label19.Text = "Period (Sec) :";
            // 
            // COM2MCU_TagePage
            // 
            this.COM2MCU_TagePage.BackColor = System.Drawing.SystemColors.Control;
            this.COM2MCU_TagePage.Controls.Add(this.button_OpenFile);
            this.COM2MCU_TagePage.Controls.Add(this.button_OpenFolder);
            this.COM2MCU_TagePage.Controls.Add(this.button_Save);
            this.COM2MCU_TagePage.Controls.Add(this.groupBox6);
            this.COM2MCU_TagePage.Controls.Add(this.groupBox7);
            this.COM2MCU_TagePage.Controls.Add(this.groupBox5);
            this.COM2MCU_TagePage.Controls.Add(this.File_Name);
            this.COM2MCU_TagePage.Location = new System.Drawing.Point(4, 24);
            this.COM2MCU_TagePage.Name = "COM2MCU_TagePage";
            this.COM2MCU_TagePage.Size = new System.Drawing.Size(885, 569);
            this.COM2MCU_TagePage.TabIndex = 2;
            this.COM2MCU_TagePage.Text = "COM With 2 MCU";
            // 
            // button_OpenFile
            // 
            this.button_OpenFile.Location = new System.Drawing.Point(807, 543);
            this.button_OpenFile.Name = "button_OpenFile";
            this.button_OpenFile.Size = new System.Drawing.Size(75, 23);
            this.button_OpenFile.TabIndex = 31;
            this.button_OpenFile.Text = "Open File";
            this.button_OpenFile.UseVisualStyleBackColor = true;
            this.button_OpenFile.Click += new System.EventHandler(this.button_OpenFile_Click);
            // 
            // button_OpenFolder
            // 
            this.button_OpenFolder.Location = new System.Drawing.Point(726, 543);
            this.button_OpenFolder.Name = "button_OpenFolder";
            this.button_OpenFolder.Size = new System.Drawing.Size(75, 23);
            this.button_OpenFolder.TabIndex = 30;
            this.button_OpenFolder.Text = "Open Folder";
            this.button_OpenFolder.UseVisualStyleBackColor = true;
            this.button_OpenFolder.Click += new System.EventHandler(this.button_OpenFolder_Click);
            // 
            // button_Save
            // 
            this.button_Save.Location = new System.Drawing.Point(807, 515);
            this.button_Save.Name = "button_Save";
            this.button_Save.Size = new System.Drawing.Size(75, 23);
            this.button_Save.TabIndex = 29;
            this.button_Save.Text = "Save";
            this.button_Save.UseVisualStyleBackColor = true;
            this.button_Save.Click += new System.EventHandler(this.button_Save_Click);
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.tableLayoutPanel3);
            this.groupBox6.Location = new System.Drawing.Point(259, 21);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(211, 265);
            this.groupBox6.TabIndex = 2;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "TX Data";
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Outset;
            this.tableLayoutPanel3.ColumnCount = 2;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 144F));
            this.tableLayoutPanel3.Controls.Add(this.COM2MCU_Level_TX_Tin, 1, 10);
            this.tableLayoutPanel3.Controls.Add(this.COM2MCU_Level_TX_ErrCode, 1, 9);
            this.tableLayoutPanel3.Controls.Add(this.COM2MCU_Level_TX_ClrErr, 1, 8);
            this.tableLayoutPanel3.Controls.Add(this.COM2MCU_Level_TX_InputCur, 1, 7);
            this.tableLayoutPanel3.Controls.Add(this.COM2MCU_Level_TX_RealFre, 1, 6);
            this.tableLayoutPanel3.Controls.Add(this.COM2MCU_Level_TX_TarFre, 1, 5);
            this.tableLayoutPanel3.Controls.Add(this.COM2MCU_Level_TX_DC4, 1, 4);
            this.tableLayoutPanel3.Controls.Add(this.COM2MCU_Level_TX_DC3, 1, 3);
            this.tableLayoutPanel3.Controls.Add(this.COM2MCU_Level_TX_DC2, 1, 2);
            this.tableLayoutPanel3.Controls.Add(this.COM2MCU_Level_TX_DC1, 1, 1);
            this.tableLayoutPanel3.Controls.Add(this.COM2MCU_Level_TX_Cmd, 1, 0);
            this.tableLayoutPanel3.Controls.Add(this.label57, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.label41, 0, 10);
            this.tableLayoutPanel3.Controls.Add(this.label34, 0, 7);
            this.tableLayoutPanel3.Controls.Add(this.label40, 0, 9);
            this.tableLayoutPanel3.Controls.Add(this.label39, 0, 6);
            this.tableLayoutPanel3.Controls.Add(this.label26, 0, 5);
            this.tableLayoutPanel3.Controls.Add(this.label38, 0, 4);
            this.tableLayoutPanel3.Controls.Add(this.label37, 0, 3);
            this.tableLayoutPanel3.Controls.Add(this.label36, 0, 2);
            this.tableLayoutPanel3.Controls.Add(this.label35, 0, 1);
            this.tableLayoutPanel3.Controls.Add(this.label42, 0, 8);
            this.tableLayoutPanel3.Location = new System.Drawing.Point(6, 15);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 12;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(200, 244);
            this.tableLayoutPanel3.TabIndex = 1;
            // 
            // COM2MCU_Level_TX_Tin
            // 
            this.COM2MCU_Level_TX_Tin.Location = new System.Drawing.Point(105, 223);
            this.COM2MCU_Level_TX_Tin.Margin = new System.Windows.Forms.Padding(1);
            this.COM2MCU_Level_TX_Tin.Name = "COM2MCU_Level_TX_Tin";
            this.COM2MCU_Level_TX_Tin.Size = new System.Drawing.Size(93, 18);
            this.COM2MCU_Level_TX_Tin.TabIndex = 61;
            this.COM2MCU_Level_TX_Tin.Tag = "";
            this.COM2MCU_Level_TX_Tin.Text = "0.0";
            this.COM2MCU_Level_TX_Tin.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // COM2MCU_Level_TX_ErrCode
            // 
            this.COM2MCU_Level_TX_ErrCode.Location = new System.Drawing.Point(105, 201);
            this.COM2MCU_Level_TX_ErrCode.Margin = new System.Windows.Forms.Padding(1);
            this.COM2MCU_Level_TX_ErrCode.Name = "COM2MCU_Level_TX_ErrCode";
            this.COM2MCU_Level_TX_ErrCode.Size = new System.Drawing.Size(93, 18);
            this.COM2MCU_Level_TX_ErrCode.TabIndex = 60;
            this.COM2MCU_Level_TX_ErrCode.Tag = "";
            this.COM2MCU_Level_TX_ErrCode.Text = "00";
            this.COM2MCU_Level_TX_ErrCode.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // COM2MCU_Level_TX_ClrErr
            // 
            this.COM2MCU_Level_TX_ClrErr.Location = new System.Drawing.Point(105, 179);
            this.COM2MCU_Level_TX_ClrErr.Margin = new System.Windows.Forms.Padding(1);
            this.COM2MCU_Level_TX_ClrErr.Name = "COM2MCU_Level_TX_ClrErr";
            this.COM2MCU_Level_TX_ClrErr.Size = new System.Drawing.Size(93, 18);
            this.COM2MCU_Level_TX_ClrErr.TabIndex = 59;
            this.COM2MCU_Level_TX_ClrErr.Tag = "";
            this.COM2MCU_Level_TX_ClrErr.Text = "00";
            this.COM2MCU_Level_TX_ClrErr.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // COM2MCU_Level_TX_InputCur
            // 
            this.COM2MCU_Level_TX_InputCur.Location = new System.Drawing.Point(105, 157);
            this.COM2MCU_Level_TX_InputCur.Margin = new System.Windows.Forms.Padding(1);
            this.COM2MCU_Level_TX_InputCur.Name = "COM2MCU_Level_TX_InputCur";
            this.COM2MCU_Level_TX_InputCur.Size = new System.Drawing.Size(93, 18);
            this.COM2MCU_Level_TX_InputCur.TabIndex = 58;
            this.COM2MCU_Level_TX_InputCur.Tag = "";
            this.COM2MCU_Level_TX_InputCur.Text = "0.0";
            this.COM2MCU_Level_TX_InputCur.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // COM2MCU_Level_TX_RealFre
            // 
            this.COM2MCU_Level_TX_RealFre.Location = new System.Drawing.Point(105, 135);
            this.COM2MCU_Level_TX_RealFre.Margin = new System.Windows.Forms.Padding(1);
            this.COM2MCU_Level_TX_RealFre.Name = "COM2MCU_Level_TX_RealFre";
            this.COM2MCU_Level_TX_RealFre.Size = new System.Drawing.Size(93, 18);
            this.COM2MCU_Level_TX_RealFre.TabIndex = 57;
            this.COM2MCU_Level_TX_RealFre.Tag = "";
            this.COM2MCU_Level_TX_RealFre.Text = "0.0";
            this.COM2MCU_Level_TX_RealFre.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // COM2MCU_Level_TX_TarFre
            // 
            this.COM2MCU_Level_TX_TarFre.Location = new System.Drawing.Point(105, 113);
            this.COM2MCU_Level_TX_TarFre.Margin = new System.Windows.Forms.Padding(1);
            this.COM2MCU_Level_TX_TarFre.Name = "COM2MCU_Level_TX_TarFre";
            this.COM2MCU_Level_TX_TarFre.Size = new System.Drawing.Size(93, 18);
            this.COM2MCU_Level_TX_TarFre.TabIndex = 56;
            this.COM2MCU_Level_TX_TarFre.Tag = "";
            this.COM2MCU_Level_TX_TarFre.Text = "0.0";
            this.COM2MCU_Level_TX_TarFre.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // COM2MCU_Level_TX_DC4
            // 
            this.COM2MCU_Level_TX_DC4.Location = new System.Drawing.Point(105, 91);
            this.COM2MCU_Level_TX_DC4.Margin = new System.Windows.Forms.Padding(1);
            this.COM2MCU_Level_TX_DC4.Name = "COM2MCU_Level_TX_DC4";
            this.COM2MCU_Level_TX_DC4.Size = new System.Drawing.Size(93, 18);
            this.COM2MCU_Level_TX_DC4.TabIndex = 55;
            this.COM2MCU_Level_TX_DC4.Tag = "";
            this.COM2MCU_Level_TX_DC4.Text = "00";
            this.COM2MCU_Level_TX_DC4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // COM2MCU_Level_TX_DC3
            // 
            this.COM2MCU_Level_TX_DC3.Location = new System.Drawing.Point(105, 69);
            this.COM2MCU_Level_TX_DC3.Margin = new System.Windows.Forms.Padding(1);
            this.COM2MCU_Level_TX_DC3.Name = "COM2MCU_Level_TX_DC3";
            this.COM2MCU_Level_TX_DC3.Size = new System.Drawing.Size(93, 18);
            this.COM2MCU_Level_TX_DC3.TabIndex = 54;
            this.COM2MCU_Level_TX_DC3.Tag = "";
            this.COM2MCU_Level_TX_DC3.Text = "00";
            this.COM2MCU_Level_TX_DC3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // COM2MCU_Level_TX_DC2
            // 
            this.COM2MCU_Level_TX_DC2.Location = new System.Drawing.Point(105, 47);
            this.COM2MCU_Level_TX_DC2.Margin = new System.Windows.Forms.Padding(1);
            this.COM2MCU_Level_TX_DC2.Name = "COM2MCU_Level_TX_DC2";
            this.COM2MCU_Level_TX_DC2.Size = new System.Drawing.Size(93, 18);
            this.COM2MCU_Level_TX_DC2.TabIndex = 53;
            this.COM2MCU_Level_TX_DC2.Tag = "";
            this.COM2MCU_Level_TX_DC2.Text = "00";
            this.COM2MCU_Level_TX_DC2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // COM2MCU_Level_TX_DC1
            // 
            this.COM2MCU_Level_TX_DC1.Location = new System.Drawing.Point(105, 25);
            this.COM2MCU_Level_TX_DC1.Margin = new System.Windows.Forms.Padding(1);
            this.COM2MCU_Level_TX_DC1.Name = "COM2MCU_Level_TX_DC1";
            this.COM2MCU_Level_TX_DC1.Size = new System.Drawing.Size(93, 18);
            this.COM2MCU_Level_TX_DC1.TabIndex = 52;
            this.COM2MCU_Level_TX_DC1.Tag = "";
            this.COM2MCU_Level_TX_DC1.Text = "00";
            this.COM2MCU_Level_TX_DC1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // COM2MCU_Level_TX_Cmd
            // 
            this.COM2MCU_Level_TX_Cmd.Location = new System.Drawing.Point(105, 3);
            this.COM2MCU_Level_TX_Cmd.Margin = new System.Windows.Forms.Padding(1);
            this.COM2MCU_Level_TX_Cmd.Name = "COM2MCU_Level_TX_Cmd";
            this.COM2MCU_Level_TX_Cmd.Size = new System.Drawing.Size(93, 18);
            this.COM2MCU_Level_TX_Cmd.TabIndex = 51;
            this.COM2MCU_Level_TX_Cmd.Tag = "";
            this.COM2MCU_Level_TX_Cmd.Text = "00";
            this.COM2MCU_Level_TX_Cmd.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label57
            // 
            this.label57.Location = new System.Drawing.Point(3, 3);
            this.label57.Margin = new System.Windows.Forms.Padding(1);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(95, 18);
            this.label57.TabIndex = 42;
            this.label57.Tag = "";
            this.label57.Text = "Command";
            this.label57.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label41
            // 
            this.label41.Location = new System.Drawing.Point(3, 223);
            this.label41.Margin = new System.Windows.Forms.Padding(1);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(95, 18);
            this.label41.TabIndex = 39;
            this.label41.Tag = "";
            this.label41.Text = "Tin(℃) ";
            this.label41.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label34
            // 
            this.label34.Location = new System.Drawing.Point(3, 157);
            this.label34.Margin = new System.Windows.Forms.Padding(1);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(95, 18);
            this.label34.TabIndex = 39;
            this.label34.Tag = "";
            this.label34.Text = "Input Current (A)";
            this.label34.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label40
            // 
            this.label40.Location = new System.Drawing.Point(3, 201);
            this.label40.Margin = new System.Windows.Forms.Padding(1);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(95, 18);
            this.label40.TabIndex = 39;
            this.label40.Tag = "";
            this.label40.Text = "Error Code";
            this.label40.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label39
            // 
            this.label39.Location = new System.Drawing.Point(3, 135);
            this.label39.Margin = new System.Windows.Forms.Padding(1);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(95, 18);
            this.label39.TabIndex = 39;
            this.label39.Tag = "";
            this.label39.Text = "Real Fre (RPS)";
            this.label39.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label26
            // 
            this.label26.Location = new System.Drawing.Point(3, 113);
            this.label26.Margin = new System.Windows.Forms.Padding(1);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(95, 18);
            this.label26.TabIndex = 39;
            this.label26.Tag = "";
            this.label26.Text = "Target Fre(RPS)";
            this.label26.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label38
            // 
            this.label38.Location = new System.Drawing.Point(3, 91);
            this.label38.Margin = new System.Windows.Forms.Padding(1);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(95, 18);
            this.label38.TabIndex = 39;
            this.label38.Tag = "";
            this.label38.Text = "Data Code4";
            this.label38.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label37
            // 
            this.label37.Location = new System.Drawing.Point(3, 69);
            this.label37.Margin = new System.Windows.Forms.Padding(1);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(95, 18);
            this.label37.TabIndex = 39;
            this.label37.Tag = "";
            this.label37.Text = "Data Code3";
            this.label37.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label36
            // 
            this.label36.Location = new System.Drawing.Point(3, 47);
            this.label36.Margin = new System.Windows.Forms.Padding(1);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(95, 18);
            this.label36.TabIndex = 39;
            this.label36.Tag = "";
            this.label36.Text = "Data Code2";
            this.label36.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label35
            // 
            this.label35.Location = new System.Drawing.Point(3, 25);
            this.label35.Margin = new System.Windows.Forms.Padding(1);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(95, 18);
            this.label35.TabIndex = 39;
            this.label35.Tag = "";
            this.label35.Text = "Data Code1";
            this.label35.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label42
            // 
            this.label42.Location = new System.Drawing.Point(3, 179);
            this.label42.Margin = new System.Windows.Forms.Padding(1);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(95, 18);
            this.label42.TabIndex = 40;
            this.label42.Tag = "";
            this.label42.Text = "Clear Error";
            this.label42.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.tableLayoutPanel4);
            this.groupBox7.Location = new System.Drawing.Point(19, 313);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(366, 226);
            this.groupBox7.TabIndex = 1;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Information";
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Outset;
            this.tableLayoutPanel4.ColumnCount = 4;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 144F));
            this.tableLayoutPanel4.Controls.Add(this.COM2MCU_Level_Inf3_b2, 3, 3);
            this.tableLayoutPanel4.Controls.Add(this.label51, 3, 0);
            this.tableLayoutPanel4.Controls.Add(this.COM2MCU_Level_Inf3_b5, 3, 6);
            this.tableLayoutPanel4.Controls.Add(this.COM2MCU_Level_Inf3_b7, 3, 8);
            this.tableLayoutPanel4.Controls.Add(this.COM2MCU_Level_Inf2_b5, 2, 6);
            this.tableLayoutPanel4.Controls.Add(this.COM2MCU_Level_Inf2_b4, 2, 5);
            this.tableLayoutPanel4.Controls.Add(this.COM2MCU_Level_Inf2_b1, 2, 2);
            this.tableLayoutPanel4.Controls.Add(this.COM2MCU_Level_Inf2_b0, 2, 1);
            this.tableLayoutPanel4.Controls.Add(this.label50, 2, 0);
            this.tableLayoutPanel4.Controls.Add(this.label44, 1, 0);
            this.tableLayoutPanel4.Controls.Add(this.COM2MCU_Level_Inf1_b0, 1, 1);
            this.tableLayoutPanel4.Controls.Add(this.COM2MCU_Level_Inf1_b1, 1, 2);
            this.tableLayoutPanel4.Controls.Add(this.COM2MCU_Level_Inf1_b3, 1, 4);
            this.tableLayoutPanel4.Controls.Add(this.label49, 0, 1);
            this.tableLayoutPanel4.Controls.Add(this.label54, 0, 2);
            this.tableLayoutPanel4.Controls.Add(this.label56, 0, 3);
            this.tableLayoutPanel4.Controls.Add(this.label58, 0, 4);
            this.tableLayoutPanel4.Controls.Add(this.label61, 0, 5);
            this.tableLayoutPanel4.Controls.Add(this.label62, 0, 6);
            this.tableLayoutPanel4.Controls.Add(this.label63, 0, 7);
            this.tableLayoutPanel4.Controls.Add(this.label64, 0, 8);
            this.tableLayoutPanel4.Controls.Add(this.COM2MCU_Level_Inf1_b2, 1, 3);
            this.tableLayoutPanel4.Controls.Add(this.COM2MCU_Level_Inf1_b4, 1, 5);
            this.tableLayoutPanel4.Controls.Add(this.COM2MCU_Level_Inf1_b5, 1, 6);
            this.tableLayoutPanel4.Controls.Add(this.COM2MCU_Level_Inf1_b6, 1, 7);
            this.tableLayoutPanel4.Controls.Add(this.COM2MCU_Level_Inf1_b7, 1, 8);
            this.tableLayoutPanel4.Controls.Add(this.COM2MCU_Level_Inf2_b3, 2, 4);
            this.tableLayoutPanel4.Controls.Add(this.COM2MCU_Level_Inf2_b2, 2, 3);
            this.tableLayoutPanel4.Controls.Add(this.COM2MCU_Level_Inf2_b6, 2, 7);
            this.tableLayoutPanel4.Controls.Add(this.COM2MCU_Level_Inf2_b7, 2, 8);
            this.tableLayoutPanel4.Controls.Add(this.COM2MCU_Level_Inf3_b0, 3, 1);
            this.tableLayoutPanel4.Controls.Add(this.COM2MCU_Level_Inf3_b1, 3, 2);
            this.tableLayoutPanel4.Controls.Add(this.COM2MCU_Level_Inf3_b3, 3, 4);
            this.tableLayoutPanel4.Controls.Add(this.COM2MCU_Level_Inf3_b4, 3, 5);
            this.tableLayoutPanel4.Controls.Add(this.COM2MCU_Level_Inf3_b6, 3, 7);
            this.tableLayoutPanel4.Location = new System.Drawing.Point(6, 21);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 10;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(355, 199);
            this.tableLayoutPanel4.TabIndex = 1;
            // 
            // COM2MCU_Level_Inf3_b2
            // 
            this.COM2MCU_Level_Inf3_b2.Location = new System.Drawing.Point(259, 69);
            this.COM2MCU_Level_Inf3_b2.Margin = new System.Windows.Forms.Padding(1);
            this.COM2MCU_Level_Inf3_b2.Name = "COM2MCU_Level_Inf3_b2";
            this.COM2MCU_Level_Inf3_b2.Size = new System.Drawing.Size(93, 18);
            this.COM2MCU_Level_Inf3_b2.TabIndex = 70;
            this.COM2MCU_Level_Inf3_b2.Tag = "";
            this.COM2MCU_Level_Inf3_b2.Text = "●";
            this.COM2MCU_Level_Inf3_b2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label51
            // 
            this.label51.Font = new System.Drawing.Font("PMingLiU", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label51.Location = new System.Drawing.Point(259, 3);
            this.label51.Margin = new System.Windows.Forms.Padding(1);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(93, 18);
            this.label51.TabIndex = 39;
            this.label51.Tag = "";
            this.label51.Text = "Information3";
            this.label51.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // COM2MCU_Level_Inf3_b5
            // 
            this.COM2MCU_Level_Inf3_b5.Location = new System.Drawing.Point(259, 135);
            this.COM2MCU_Level_Inf3_b5.Margin = new System.Windows.Forms.Padding(1);
            this.COM2MCU_Level_Inf3_b5.Name = "COM2MCU_Level_Inf3_b5";
            this.COM2MCU_Level_Inf3_b5.Size = new System.Drawing.Size(93, 18);
            this.COM2MCU_Level_Inf3_b5.TabIndex = 48;
            this.COM2MCU_Level_Inf3_b5.Tag = "";
            this.COM2MCU_Level_Inf3_b5.Text = "Tin Conver Rule";
            this.COM2MCU_Level_Inf3_b5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // COM2MCU_Level_Inf3_b7
            // 
            this.COM2MCU_Level_Inf3_b7.Location = new System.Drawing.Point(259, 179);
            this.COM2MCU_Level_Inf3_b7.Margin = new System.Windows.Forms.Padding(1);
            this.COM2MCU_Level_Inf3_b7.Name = "COM2MCU_Level_Inf3_b7";
            this.COM2MCU_Level_Inf3_b7.Size = new System.Drawing.Size(93, 18);
            this.COM2MCU_Level_Inf3_b7.TabIndex = 49;
            this.COM2MCU_Level_Inf3_b7.Tag = "";
            this.COM2MCU_Level_Inf3_b7.Text = "PFC On";
            this.COM2MCU_Level_Inf3_b7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // COM2MCU_Level_Inf2_b5
            // 
            this.COM2MCU_Level_Inf2_b5.Location = new System.Drawing.Point(157, 135);
            this.COM2MCU_Level_Inf2_b5.Margin = new System.Windows.Forms.Padding(1);
            this.COM2MCU_Level_Inf2_b5.Name = "COM2MCU_Level_Inf2_b5";
            this.COM2MCU_Level_Inf2_b5.Size = new System.Drawing.Size(98, 18);
            this.COM2MCU_Level_Inf2_b5.TabIndex = 45;
            this.COM2MCU_Level_Inf2_b5.Tag = "";
            this.COM2MCU_Level_Inf2_b5.Text = "●";
            this.COM2MCU_Level_Inf2_b5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // COM2MCU_Level_Inf2_b4
            // 
            this.COM2MCU_Level_Inf2_b4.Location = new System.Drawing.Point(157, 113);
            this.COM2MCU_Level_Inf2_b4.Margin = new System.Windows.Forms.Padding(1);
            this.COM2MCU_Level_Inf2_b4.Name = "COM2MCU_Level_Inf2_b4";
            this.COM2MCU_Level_Inf2_b4.Size = new System.Drawing.Size(98, 18);
            this.COM2MCU_Level_Inf2_b4.TabIndex = 43;
            this.COM2MCU_Level_Inf2_b4.Tag = "";
            this.COM2MCU_Level_Inf2_b4.Text = "Current Restrict";
            this.COM2MCU_Level_Inf2_b4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // COM2MCU_Level_Inf2_b1
            // 
            this.COM2MCU_Level_Inf2_b1.Location = new System.Drawing.Point(157, 47);
            this.COM2MCU_Level_Inf2_b1.Margin = new System.Windows.Forms.Padding(1);
            this.COM2MCU_Level_Inf2_b1.Name = "COM2MCU_Level_Inf2_b1";
            this.COM2MCU_Level_Inf2_b1.Size = new System.Drawing.Size(98, 18);
            this.COM2MCU_Level_Inf2_b1.TabIndex = 50;
            this.COM2MCU_Level_Inf2_b1.Tag = "";
            this.COM2MCU_Level_Inf2_b1.Text = "Restart";
            this.COM2MCU_Level_Inf2_b1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // COM2MCU_Level_Inf2_b0
            // 
            this.COM2MCU_Level_Inf2_b0.Location = new System.Drawing.Point(157, 25);
            this.COM2MCU_Level_Inf2_b0.Margin = new System.Windows.Forms.Padding(1);
            this.COM2MCU_Level_Inf2_b0.Name = "COM2MCU_Level_Inf2_b0";
            this.COM2MCU_Level_Inf2_b0.Size = new System.Drawing.Size(98, 18);
            this.COM2MCU_Level_Inf2_b0.TabIndex = 40;
            this.COM2MCU_Level_Inf2_b0.Tag = "";
            this.COM2MCU_Level_Inf2_b0.Text = "Power Relay On";
            this.COM2MCU_Level_Inf2_b0.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label50
            // 
            this.label50.Font = new System.Drawing.Font("PMingLiU", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label50.Location = new System.Drawing.Point(157, 3);
            this.label50.Margin = new System.Windows.Forms.Padding(1);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(98, 18);
            this.label50.TabIndex = 39;
            this.label50.Tag = "";
            this.label50.Text = "Information2";
            this.label50.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label44
            // 
            this.label44.Font = new System.Drawing.Font("PMingLiU", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label44.Location = new System.Drawing.Point(55, 3);
            this.label44.Margin = new System.Windows.Forms.Padding(1);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(98, 18);
            this.label44.TabIndex = 39;
            this.label44.Tag = "";
            this.label44.Text = "Information1";
            this.label44.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // COM2MCU_Level_Inf1_b0
            // 
            this.COM2MCU_Level_Inf1_b0.Location = new System.Drawing.Point(55, 25);
            this.COM2MCU_Level_Inf1_b0.Margin = new System.Windows.Forms.Padding(1);
            this.COM2MCU_Level_Inf1_b0.Name = "COM2MCU_Level_Inf1_b0";
            this.COM2MCU_Level_Inf1_b0.Size = new System.Drawing.Size(98, 18);
            this.COM2MCU_Level_Inf1_b0.TabIndex = 39;
            this.COM2MCU_Level_Inf1_b0.Tag = "";
            this.COM2MCU_Level_Inf1_b0.Text = "Stop Due To Err";
            this.COM2MCU_Level_Inf1_b0.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // COM2MCU_Level_Inf1_b1
            // 
            this.COM2MCU_Level_Inf1_b1.Location = new System.Drawing.Point(55, 47);
            this.COM2MCU_Level_Inf1_b1.Margin = new System.Windows.Forms.Padding(1);
            this.COM2MCU_Level_Inf1_b1.Name = "COM2MCU_Level_Inf1_b1";
            this.COM2MCU_Level_Inf1_b1.Size = new System.Drawing.Size(98, 18);
            this.COM2MCU_Level_Inf1_b1.TabIndex = 39;
            this.COM2MCU_Level_Inf1_b1.Tag = "";
            this.COM2MCU_Level_Inf1_b1.Text = "Complete Error";
            this.COM2MCU_Level_Inf1_b1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // COM2MCU_Level_Inf1_b3
            // 
            this.COM2MCU_Level_Inf1_b3.Location = new System.Drawing.Point(55, 91);
            this.COM2MCU_Level_Inf1_b3.Margin = new System.Windows.Forms.Padding(1);
            this.COM2MCU_Level_Inf1_b3.Name = "COM2MCU_Level_Inf1_b3";
            this.COM2MCU_Level_Inf1_b3.Size = new System.Drawing.Size(98, 18);
            this.COM2MCU_Level_Inf1_b3.TabIndex = 39;
            this.COM2MCU_Level_Inf1_b3.Tag = "";
            this.COM2MCU_Level_Inf1_b3.Text = "No Power";
            this.COM2MCU_Level_Inf1_b3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label49
            // 
            this.label49.Location = new System.Drawing.Point(3, 25);
            this.label49.Margin = new System.Windows.Forms.Padding(1);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(48, 18);
            this.label49.TabIndex = 51;
            this.label49.Tag = "";
            this.label49.Text = "b0";
            this.label49.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label54
            // 
            this.label54.Location = new System.Drawing.Point(3, 47);
            this.label54.Margin = new System.Windows.Forms.Padding(1);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(48, 18);
            this.label54.TabIndex = 52;
            this.label54.Tag = "";
            this.label54.Text = "b1";
            this.label54.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label56
            // 
            this.label56.Location = new System.Drawing.Point(3, 69);
            this.label56.Margin = new System.Windows.Forms.Padding(1);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(48, 18);
            this.label56.TabIndex = 53;
            this.label56.Tag = "";
            this.label56.Text = "b2";
            this.label56.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label58
            // 
            this.label58.Location = new System.Drawing.Point(3, 91);
            this.label58.Margin = new System.Windows.Forms.Padding(1);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(48, 18);
            this.label58.TabIndex = 54;
            this.label58.Tag = "";
            this.label58.Text = "b3";
            this.label58.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label61
            // 
            this.label61.Location = new System.Drawing.Point(3, 113);
            this.label61.Margin = new System.Windows.Forms.Padding(1);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(48, 18);
            this.label61.TabIndex = 55;
            this.label61.Tag = "";
            this.label61.Text = "b4";
            this.label61.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label62
            // 
            this.label62.Location = new System.Drawing.Point(3, 135);
            this.label62.Margin = new System.Windows.Forms.Padding(1);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(48, 18);
            this.label62.TabIndex = 56;
            this.label62.Tag = "";
            this.label62.Text = "b5";
            this.label62.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label63
            // 
            this.label63.Location = new System.Drawing.Point(3, 157);
            this.label63.Margin = new System.Windows.Forms.Padding(1);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(48, 18);
            this.label63.TabIndex = 57;
            this.label63.Tag = "";
            this.label63.Text = "b6";
            this.label63.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label64
            // 
            this.label64.Location = new System.Drawing.Point(3, 179);
            this.label64.Margin = new System.Windows.Forms.Padding(1);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(48, 18);
            this.label64.TabIndex = 58;
            this.label64.Tag = "";
            this.label64.Text = "b7";
            this.label64.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // COM2MCU_Level_Inf1_b2
            // 
            this.COM2MCU_Level_Inf1_b2.Location = new System.Drawing.Point(55, 69);
            this.COM2MCU_Level_Inf1_b2.Margin = new System.Windows.Forms.Padding(1);
            this.COM2MCU_Level_Inf1_b2.Name = "COM2MCU_Level_Inf1_b2";
            this.COM2MCU_Level_Inf1_b2.Size = new System.Drawing.Size(98, 18);
            this.COM2MCU_Level_Inf1_b2.TabIndex = 59;
            this.COM2MCU_Level_Inf1_b2.Tag = "";
            this.COM2MCU_Level_Inf1_b2.Text = "●";
            this.COM2MCU_Level_Inf1_b2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // COM2MCU_Level_Inf1_b4
            // 
            this.COM2MCU_Level_Inf1_b4.Location = new System.Drawing.Point(55, 113);
            this.COM2MCU_Level_Inf1_b4.Margin = new System.Windows.Forms.Padding(1);
            this.COM2MCU_Level_Inf1_b4.Name = "COM2MCU_Level_Inf1_b4";
            this.COM2MCU_Level_Inf1_b4.Size = new System.Drawing.Size(98, 18);
            this.COM2MCU_Level_Inf1_b4.TabIndex = 60;
            this.COM2MCU_Level_Inf1_b4.Tag = "";
            this.COM2MCU_Level_Inf1_b4.Text = "●";
            this.COM2MCU_Level_Inf1_b4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // COM2MCU_Level_Inf1_b5
            // 
            this.COM2MCU_Level_Inf1_b5.Location = new System.Drawing.Point(55, 135);
            this.COM2MCU_Level_Inf1_b5.Margin = new System.Windows.Forms.Padding(1);
            this.COM2MCU_Level_Inf1_b5.Name = "COM2MCU_Level_Inf1_b5";
            this.COM2MCU_Level_Inf1_b5.Size = new System.Drawing.Size(98, 18);
            this.COM2MCU_Level_Inf1_b5.TabIndex = 61;
            this.COM2MCU_Level_Inf1_b5.Tag = "";
            this.COM2MCU_Level_Inf1_b5.Text = "●";
            this.COM2MCU_Level_Inf1_b5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // COM2MCU_Level_Inf1_b6
            // 
            this.COM2MCU_Level_Inf1_b6.Location = new System.Drawing.Point(55, 157);
            this.COM2MCU_Level_Inf1_b6.Margin = new System.Windows.Forms.Padding(1);
            this.COM2MCU_Level_Inf1_b6.Name = "COM2MCU_Level_Inf1_b6";
            this.COM2MCU_Level_Inf1_b6.Size = new System.Drawing.Size(98, 18);
            this.COM2MCU_Level_Inf1_b6.TabIndex = 62;
            this.COM2MCU_Level_Inf1_b6.Tag = "";
            this.COM2MCU_Level_Inf1_b6.Text = "●";
            this.COM2MCU_Level_Inf1_b6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // COM2MCU_Level_Inf1_b7
            // 
            this.COM2MCU_Level_Inf1_b7.ForeColor = System.Drawing.Color.Black;
            this.COM2MCU_Level_Inf1_b7.Location = new System.Drawing.Point(55, 179);
            this.COM2MCU_Level_Inf1_b7.Margin = new System.Windows.Forms.Padding(1);
            this.COM2MCU_Level_Inf1_b7.Name = "COM2MCU_Level_Inf1_b7";
            this.COM2MCU_Level_Inf1_b7.Size = new System.Drawing.Size(98, 18);
            this.COM2MCU_Level_Inf1_b7.TabIndex = 63;
            this.COM2MCU_Level_Inf1_b7.Tag = "";
            this.COM2MCU_Level_Inf1_b7.Text = "●";
            this.COM2MCU_Level_Inf1_b7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // COM2MCU_Level_Inf2_b3
            // 
            this.COM2MCU_Level_Inf2_b3.Location = new System.Drawing.Point(157, 91);
            this.COM2MCU_Level_Inf2_b3.Margin = new System.Windows.Forms.Padding(1);
            this.COM2MCU_Level_Inf2_b3.Name = "COM2MCU_Level_Inf2_b3";
            this.COM2MCU_Level_Inf2_b3.Size = new System.Drawing.Size(98, 18);
            this.COM2MCU_Level_Inf2_b3.TabIndex = 64;
            this.COM2MCU_Level_Inf2_b3.Tag = "";
            this.COM2MCU_Level_Inf2_b3.Text = "●";
            this.COM2MCU_Level_Inf2_b3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // COM2MCU_Level_Inf2_b2
            // 
            this.COM2MCU_Level_Inf2_b2.Location = new System.Drawing.Point(157, 69);
            this.COM2MCU_Level_Inf2_b2.Margin = new System.Windows.Forms.Padding(1);
            this.COM2MCU_Level_Inf2_b2.Name = "COM2MCU_Level_Inf2_b2";
            this.COM2MCU_Level_Inf2_b2.Size = new System.Drawing.Size(98, 18);
            this.COM2MCU_Level_Inf2_b2.TabIndex = 65;
            this.COM2MCU_Level_Inf2_b2.Tag = "";
            this.COM2MCU_Level_Inf2_b2.Text = "●";
            this.COM2MCU_Level_Inf2_b2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // COM2MCU_Level_Inf2_b6
            // 
            this.COM2MCU_Level_Inf2_b6.Location = new System.Drawing.Point(157, 157);
            this.COM2MCU_Level_Inf2_b6.Margin = new System.Windows.Forms.Padding(1);
            this.COM2MCU_Level_Inf2_b6.Name = "COM2MCU_Level_Inf2_b6";
            this.COM2MCU_Level_Inf2_b6.Size = new System.Drawing.Size(98, 18);
            this.COM2MCU_Level_Inf2_b6.TabIndex = 66;
            this.COM2MCU_Level_Inf2_b6.Tag = "";
            this.COM2MCU_Level_Inf2_b6.Text = "●";
            this.COM2MCU_Level_Inf2_b6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // COM2MCU_Level_Inf2_b7
            // 
            this.COM2MCU_Level_Inf2_b7.Location = new System.Drawing.Point(157, 179);
            this.COM2MCU_Level_Inf2_b7.Margin = new System.Windows.Forms.Padding(1);
            this.COM2MCU_Level_Inf2_b7.Name = "COM2MCU_Level_Inf2_b7";
            this.COM2MCU_Level_Inf2_b7.Size = new System.Drawing.Size(98, 18);
            this.COM2MCU_Level_Inf2_b7.TabIndex = 67;
            this.COM2MCU_Level_Inf2_b7.Tag = "";
            this.COM2MCU_Level_Inf2_b7.Text = "●";
            this.COM2MCU_Level_Inf2_b7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // COM2MCU_Level_Inf3_b0
            // 
            this.COM2MCU_Level_Inf3_b0.Location = new System.Drawing.Point(259, 25);
            this.COM2MCU_Level_Inf3_b0.Margin = new System.Windows.Forms.Padding(1);
            this.COM2MCU_Level_Inf3_b0.Name = "COM2MCU_Level_Inf3_b0";
            this.COM2MCU_Level_Inf3_b0.Size = new System.Drawing.Size(93, 18);
            this.COM2MCU_Level_Inf3_b0.TabIndex = 68;
            this.COM2MCU_Level_Inf3_b0.Tag = "";
            this.COM2MCU_Level_Inf3_b0.Text = "●";
            this.COM2MCU_Level_Inf3_b0.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // COM2MCU_Level_Inf3_b1
            // 
            this.COM2MCU_Level_Inf3_b1.Location = new System.Drawing.Point(259, 47);
            this.COM2MCU_Level_Inf3_b1.Margin = new System.Windows.Forms.Padding(1);
            this.COM2MCU_Level_Inf3_b1.Name = "COM2MCU_Level_Inf3_b1";
            this.COM2MCU_Level_Inf3_b1.Size = new System.Drawing.Size(93, 18);
            this.COM2MCU_Level_Inf3_b1.TabIndex = 69;
            this.COM2MCU_Level_Inf3_b1.Tag = "";
            this.COM2MCU_Level_Inf3_b1.Text = "●";
            this.COM2MCU_Level_Inf3_b1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // COM2MCU_Level_Inf3_b3
            // 
            this.COM2MCU_Level_Inf3_b3.Location = new System.Drawing.Point(259, 91);
            this.COM2MCU_Level_Inf3_b3.Margin = new System.Windows.Forms.Padding(1);
            this.COM2MCU_Level_Inf3_b3.Name = "COM2MCU_Level_Inf3_b3";
            this.COM2MCU_Level_Inf3_b3.Size = new System.Drawing.Size(93, 18);
            this.COM2MCU_Level_Inf3_b3.TabIndex = 71;
            this.COM2MCU_Level_Inf3_b3.Tag = "";
            this.COM2MCU_Level_Inf3_b3.Text = "●";
            this.COM2MCU_Level_Inf3_b3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // COM2MCU_Level_Inf3_b4
            // 
            this.COM2MCU_Level_Inf3_b4.Location = new System.Drawing.Point(259, 113);
            this.COM2MCU_Level_Inf3_b4.Margin = new System.Windows.Forms.Padding(1);
            this.COM2MCU_Level_Inf3_b4.Name = "COM2MCU_Level_Inf3_b4";
            this.COM2MCU_Level_Inf3_b4.Size = new System.Drawing.Size(93, 18);
            this.COM2MCU_Level_Inf3_b4.TabIndex = 72;
            this.COM2MCU_Level_Inf3_b4.Tag = "";
            this.COM2MCU_Level_Inf3_b4.Text = "●";
            this.COM2MCU_Level_Inf3_b4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // COM2MCU_Level_Inf3_b6
            // 
            this.COM2MCU_Level_Inf3_b6.Location = new System.Drawing.Point(259, 157);
            this.COM2MCU_Level_Inf3_b6.Margin = new System.Windows.Forms.Padding(1);
            this.COM2MCU_Level_Inf3_b6.Name = "COM2MCU_Level_Inf3_b6";
            this.COM2MCU_Level_Inf3_b6.Size = new System.Drawing.Size(93, 18);
            this.COM2MCU_Level_Inf3_b6.TabIndex = 73;
            this.COM2MCU_Level_Inf3_b6.Tag = "";
            this.COM2MCU_Level_Inf3_b6.Text = "●";
            this.COM2MCU_Level_Inf3_b6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.tableLayoutPanel2);
            this.groupBox5.Location = new System.Drawing.Point(19, 21);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(214, 221);
            this.groupBox5.TabIndex = 1;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "RX Data";
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Outset;
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 140F));
            this.tableLayoutPanel2.Controls.Add(this.COM2MCU_Level_RX_ClrErr, 1, 8);
            this.tableLayoutPanel2.Controls.Add(this.label43, 0, 8);
            this.tableLayoutPanel2.Controls.Add(this.label28, 0, 7);
            this.tableLayoutPanel2.Controls.Add(this.label25, 0, 6);
            this.tableLayoutPanel2.Controls.Add(this.label33, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.label27, 0, 5);
            this.tableLayoutPanel2.Controls.Add(this.label32, 0, 4);
            this.tableLayoutPanel2.Controls.Add(this.label31, 0, 3);
            this.tableLayoutPanel2.Controls.Add(this.label30, 0, 2);
            this.tableLayoutPanel2.Controls.Add(this.label29, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.COM2MCU_Level_RX_Cmd, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.COM2MCU_Level_RX_FC1, 1, 1);
            this.tableLayoutPanel2.Controls.Add(this.COM2MCU_Level_RX_FC2, 1, 2);
            this.tableLayoutPanel2.Controls.Add(this.COM2MCU_Level_RX_FC3, 1, 3);
            this.tableLayoutPanel2.Controls.Add(this.COM2MCU_Level_RX_FC4, 1, 4);
            this.tableLayoutPanel2.Controls.Add(this.COM2MCU_Level_RX_TarFre, 1, 5);
            this.tableLayoutPanel2.Controls.Add(this.COM2MCU_Level_RX_FreChange, 1, 6);
            this.tableLayoutPanel2.Controls.Add(this.COM2MCU_Level_RX_CurRel, 1, 7);
            this.tableLayoutPanel2.Location = new System.Drawing.Point(6, 15);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 10;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(200, 200);
            this.tableLayoutPanel2.TabIndex = 1;
            // 
            // COM2MCU_Level_RX_ClrErr
            // 
            this.COM2MCU_Level_RX_ClrErr.Location = new System.Drawing.Point(105, 179);
            this.COM2MCU_Level_RX_ClrErr.Margin = new System.Windows.Forms.Padding(1);
            this.COM2MCU_Level_RX_ClrErr.Name = "COM2MCU_Level_RX_ClrErr";
            this.COM2MCU_Level_RX_ClrErr.Size = new System.Drawing.Size(93, 18);
            this.COM2MCU_Level_RX_ClrErr.TabIndex = 50;
            this.COM2MCU_Level_RX_ClrErr.Tag = "";
            this.COM2MCU_Level_RX_ClrErr.Text = "00";
            this.COM2MCU_Level_RX_ClrErr.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label43
            // 
            this.label43.Location = new System.Drawing.Point(3, 179);
            this.label43.Margin = new System.Windows.Forms.Padding(1);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(95, 18);
            this.label43.TabIndex = 41;
            this.label43.Tag = "";
            this.label43.Text = "Clear Error";
            this.label43.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label28
            // 
            this.label28.Location = new System.Drawing.Point(3, 157);
            this.label28.Margin = new System.Windows.Forms.Padding(1);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(98, 18);
            this.label28.TabIndex = 39;
            this.label28.Tag = "";
            this.label28.Text = "Current release(A)";
            this.label28.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label25
            // 
            this.label25.Location = new System.Drawing.Point(3, 135);
            this.label25.Margin = new System.Windows.Forms.Padding(1);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(98, 18);
            this.label25.TabIndex = 39;
            this.label25.Tag = "";
            this.label25.Text = "Fre Change (RPS/s)";
            this.label25.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label33
            // 
            this.label33.Location = new System.Drawing.Point(3, 3);
            this.label33.Margin = new System.Windows.Forms.Padding(1);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(98, 18);
            this.label33.TabIndex = 39;
            this.label33.Tag = "";
            this.label33.Text = "Command";
            this.label33.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label27
            // 
            this.label27.Location = new System.Drawing.Point(3, 113);
            this.label27.Margin = new System.Windows.Forms.Padding(1);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(98, 18);
            this.label27.TabIndex = 39;
            this.label27.Tag = "";
            this.label27.Text = "Target Fre(RPS)";
            this.label27.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label32
            // 
            this.label32.Location = new System.Drawing.Point(3, 91);
            this.label32.Margin = new System.Windows.Forms.Padding(1);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(98, 18);
            this.label32.TabIndex = 39;
            this.label32.Tag = "";
            this.label32.Text = "Fixed Code4";
            this.label32.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label31
            // 
            this.label31.Location = new System.Drawing.Point(3, 69);
            this.label31.Margin = new System.Windows.Forms.Padding(1);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(98, 18);
            this.label31.TabIndex = 39;
            this.label31.Tag = "";
            this.label31.Text = "Fixed Code3";
            this.label31.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label30
            // 
            this.label30.Location = new System.Drawing.Point(3, 47);
            this.label30.Margin = new System.Windows.Forms.Padding(1);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(98, 18);
            this.label30.TabIndex = 39;
            this.label30.Tag = "";
            this.label30.Text = "Fixed Code2";
            this.label30.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label29
            // 
            this.label29.Location = new System.Drawing.Point(3, 25);
            this.label29.Margin = new System.Windows.Forms.Padding(1);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(98, 18);
            this.label29.TabIndex = 39;
            this.label29.Tag = "";
            this.label29.Text = "Fixed Code1";
            this.label29.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // COM2MCU_Level_RX_Cmd
            // 
            this.COM2MCU_Level_RX_Cmd.Location = new System.Drawing.Point(105, 3);
            this.COM2MCU_Level_RX_Cmd.Margin = new System.Windows.Forms.Padding(1);
            this.COM2MCU_Level_RX_Cmd.Name = "COM2MCU_Level_RX_Cmd";
            this.COM2MCU_Level_RX_Cmd.Size = new System.Drawing.Size(93, 18);
            this.COM2MCU_Level_RX_Cmd.TabIndex = 42;
            this.COM2MCU_Level_RX_Cmd.Tag = "";
            this.COM2MCU_Level_RX_Cmd.Text = "00";
            this.COM2MCU_Level_RX_Cmd.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // COM2MCU_Level_RX_FC1
            // 
            this.COM2MCU_Level_RX_FC1.Location = new System.Drawing.Point(105, 25);
            this.COM2MCU_Level_RX_FC1.Margin = new System.Windows.Forms.Padding(1);
            this.COM2MCU_Level_RX_FC1.Name = "COM2MCU_Level_RX_FC1";
            this.COM2MCU_Level_RX_FC1.Size = new System.Drawing.Size(93, 18);
            this.COM2MCU_Level_RX_FC1.TabIndex = 43;
            this.COM2MCU_Level_RX_FC1.Tag = "";
            this.COM2MCU_Level_RX_FC1.Text = "00";
            this.COM2MCU_Level_RX_FC1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // COM2MCU_Level_RX_FC2
            // 
            this.COM2MCU_Level_RX_FC2.Location = new System.Drawing.Point(105, 47);
            this.COM2MCU_Level_RX_FC2.Margin = new System.Windows.Forms.Padding(1);
            this.COM2MCU_Level_RX_FC2.Name = "COM2MCU_Level_RX_FC2";
            this.COM2MCU_Level_RX_FC2.Size = new System.Drawing.Size(93, 18);
            this.COM2MCU_Level_RX_FC2.TabIndex = 44;
            this.COM2MCU_Level_RX_FC2.Tag = "";
            this.COM2MCU_Level_RX_FC2.Text = "00";
            this.COM2MCU_Level_RX_FC2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // COM2MCU_Level_RX_FC3
            // 
            this.COM2MCU_Level_RX_FC3.Location = new System.Drawing.Point(105, 69);
            this.COM2MCU_Level_RX_FC3.Margin = new System.Windows.Forms.Padding(1);
            this.COM2MCU_Level_RX_FC3.Name = "COM2MCU_Level_RX_FC3";
            this.COM2MCU_Level_RX_FC3.Size = new System.Drawing.Size(93, 18);
            this.COM2MCU_Level_RX_FC3.TabIndex = 45;
            this.COM2MCU_Level_RX_FC3.Tag = "";
            this.COM2MCU_Level_RX_FC3.Text = "00";
            this.COM2MCU_Level_RX_FC3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // COM2MCU_Level_RX_FC4
            // 
            this.COM2MCU_Level_RX_FC4.Location = new System.Drawing.Point(105, 91);
            this.COM2MCU_Level_RX_FC4.Margin = new System.Windows.Forms.Padding(1);
            this.COM2MCU_Level_RX_FC4.Name = "COM2MCU_Level_RX_FC4";
            this.COM2MCU_Level_RX_FC4.Size = new System.Drawing.Size(93, 18);
            this.COM2MCU_Level_RX_FC4.TabIndex = 46;
            this.COM2MCU_Level_RX_FC4.Tag = "";
            this.COM2MCU_Level_RX_FC4.Text = "00";
            this.COM2MCU_Level_RX_FC4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // COM2MCU_Level_RX_TarFre
            // 
            this.COM2MCU_Level_RX_TarFre.Location = new System.Drawing.Point(105, 113);
            this.COM2MCU_Level_RX_TarFre.Margin = new System.Windows.Forms.Padding(1);
            this.COM2MCU_Level_RX_TarFre.Name = "COM2MCU_Level_RX_TarFre";
            this.COM2MCU_Level_RX_TarFre.Size = new System.Drawing.Size(93, 18);
            this.COM2MCU_Level_RX_TarFre.TabIndex = 47;
            this.COM2MCU_Level_RX_TarFre.Tag = "";
            this.COM2MCU_Level_RX_TarFre.Text = "0.0";
            this.COM2MCU_Level_RX_TarFre.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // COM2MCU_Level_RX_FreChange
            // 
            this.COM2MCU_Level_RX_FreChange.Location = new System.Drawing.Point(105, 135);
            this.COM2MCU_Level_RX_FreChange.Margin = new System.Windows.Forms.Padding(1);
            this.COM2MCU_Level_RX_FreChange.Name = "COM2MCU_Level_RX_FreChange";
            this.COM2MCU_Level_RX_FreChange.Size = new System.Drawing.Size(93, 18);
            this.COM2MCU_Level_RX_FreChange.TabIndex = 48;
            this.COM2MCU_Level_RX_FreChange.Tag = "";
            this.COM2MCU_Level_RX_FreChange.Text = "0.0";
            this.COM2MCU_Level_RX_FreChange.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // COM2MCU_Level_RX_CurRel
            // 
            this.COM2MCU_Level_RX_CurRel.Location = new System.Drawing.Point(105, 157);
            this.COM2MCU_Level_RX_CurRel.Margin = new System.Windows.Forms.Padding(1);
            this.COM2MCU_Level_RX_CurRel.Name = "COM2MCU_Level_RX_CurRel";
            this.COM2MCU_Level_RX_CurRel.Size = new System.Drawing.Size(93, 18);
            this.COM2MCU_Level_RX_CurRel.TabIndex = 49;
            this.COM2MCU_Level_RX_CurRel.Tag = "";
            this.COM2MCU_Level_RX_CurRel.Text = "0.0";
            this.COM2MCU_Level_RX_CurRel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Tab_ParaTuning
            // 
            this.Tab_ParaTuning.BackColor = System.Drawing.SystemColors.Control;
            this.Tab_ParaTuning.Controls.Add(this.button_PaTu_SaveFile);
            this.Tab_ParaTuning.Controls.Add(this.button_PaTu_OpenFile);
            this.Tab_ParaTuning.Controls.Add(this.groupBox12);
            this.Tab_ParaTuning.Controls.Add(this.ListView_ParaTuning);
            this.Tab_ParaTuning.Location = new System.Drawing.Point(4, 24);
            this.Tab_ParaTuning.Name = "Tab_ParaTuning";
            this.Tab_ParaTuning.Size = new System.Drawing.Size(885, 569);
            this.Tab_ParaTuning.TabIndex = 3;
            this.Tab_ParaTuning.Text = "Parameter Tuning";
            // 
            // button_PaTu_SaveFile
            // 
            this.button_PaTu_SaveFile.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_PaTu_SaveFile.Location = new System.Drawing.Point(755, 511);
            this.button_PaTu_SaveFile.Name = "button_PaTu_SaveFile";
            this.button_PaTu_SaveFile.Size = new System.Drawing.Size(104, 42);
            this.button_PaTu_SaveFile.TabIndex = 8;
            this.button_PaTu_SaveFile.Text = "Save File";
            this.button_PaTu_SaveFile.UseVisualStyleBackColor = true;
            this.button_PaTu_SaveFile.Click += new System.EventHandler(this.button_PaTu_SaveFile_Click);
            // 
            // button_PaTu_OpenFile
            // 
            this.button_PaTu_OpenFile.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_PaTu_OpenFile.Location = new System.Drawing.Point(629, 511);
            this.button_PaTu_OpenFile.Name = "button_PaTu_OpenFile";
            this.button_PaTu_OpenFile.Size = new System.Drawing.Size(104, 42);
            this.button_PaTu_OpenFile.TabIndex = 7;
            this.button_PaTu_OpenFile.Text = "Open File";
            this.button_PaTu_OpenFile.UseVisualStyleBackColor = true;
            this.button_PaTu_OpenFile.Click += new System.EventHandler(this.button_PaTu_OpenFile_Click);
            // 
            // groupBox12
            // 
            this.groupBox12.Controls.Add(this.button_PaTu_Update_MotoPara);
            this.groupBox12.Controls.Add(this.button_PaTu_Download);
            this.groupBox12.Controls.Add(this.button_PaTu_Upload);
            this.groupBox12.Controls.Add(this.button_PaTu_eFlashRead);
            this.groupBox12.Controls.Add(this.button_PaTu_eFlashWrite);
            this.groupBox12.Location = new System.Drawing.Point(629, 3);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Size = new System.Drawing.Size(207, 145);
            this.groupBox12.TabIndex = 6;
            this.groupBox12.TabStop = false;
            // 
            // button_PaTu_Update_MotoPara
            // 
            this.button_PaTu_Update_MotoPara.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_PaTu_Update_MotoPara.Location = new System.Drawing.Point(6, 101);
            this.button_PaTu_Update_MotoPara.Name = "button_PaTu_Update_MotoPara";
            this.button_PaTu_Update_MotoPara.Size = new System.Drawing.Size(196, 37);
            this.button_PaTu_Update_MotoPara.TabIndex = 9;
            this.button_PaTu_Update_MotoPara.Text = "Update Para";
            this.button_PaTu_Update_MotoPara.UseVisualStyleBackColor = true;
            this.button_PaTu_Update_MotoPara.Click += new System.EventHandler(this.button_PaTu_Update_MotoPara_Click);
            // 
            // button_PaTu_Download
            // 
            this.button_PaTu_Download.Location = new System.Drawing.Point(6, 17);
            this.button_PaTu_Download.Name = "button_PaTu_Download";
            this.button_PaTu_Download.Size = new System.Drawing.Size(95, 36);
            this.button_PaTu_Download.TabIndex = 1;
            this.button_PaTu_Download.Text = "Download";
            this.button_PaTu_Download.UseVisualStyleBackColor = true;
            this.button_PaTu_Download.Click += new System.EventHandler(this.button_PaTu_Download_Click);
            // 
            // button_PaTu_Upload
            // 
            this.button_PaTu_Upload.Location = new System.Drawing.Point(6, 59);
            this.button_PaTu_Upload.Name = "button_PaTu_Upload";
            this.button_PaTu_Upload.Size = new System.Drawing.Size(95, 36);
            this.button_PaTu_Upload.TabIndex = 2;
            this.button_PaTu_Upload.Text = "Upload";
            this.button_PaTu_Upload.UseVisualStyleBackColor = true;
            this.button_PaTu_Upload.Click += new System.EventHandler(this.button_PaTu_Upload_Click);
            // 
            // button_PaTu_eFlashRead
            // 
            this.button_PaTu_eFlashRead.Location = new System.Drawing.Point(107, 17);
            this.button_PaTu_eFlashRead.Name = "button_PaTu_eFlashRead";
            this.button_PaTu_eFlashRead.Size = new System.Drawing.Size(95, 36);
            this.button_PaTu_eFlashRead.TabIndex = 4;
            this.button_PaTu_eFlashRead.Text = "Read from eFlash";
            this.button_PaTu_eFlashRead.UseVisualStyleBackColor = true;
            this.button_PaTu_eFlashRead.Click += new System.EventHandler(this.button_PaTu_eFlashRead_Click);
            // 
            // button_PaTu_eFlashWrite
            // 
            this.button_PaTu_eFlashWrite.Location = new System.Drawing.Point(107, 59);
            this.button_PaTu_eFlashWrite.Name = "button_PaTu_eFlashWrite";
            this.button_PaTu_eFlashWrite.Size = new System.Drawing.Size(95, 36);
            this.button_PaTu_eFlashWrite.TabIndex = 3;
            this.button_PaTu_eFlashWrite.Text = "Write to eFlash";
            this.button_PaTu_eFlashWrite.UseVisualStyleBackColor = true;
            this.button_PaTu_eFlashWrite.Click += new System.EventHandler(this.button_PaTu_eFlashWrite_Click);
            // 
            // ListView_ParaTuning
            // 
            this.ListView_ParaTuning.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ListView_ParaTuning.Location = new System.Drawing.Point(3, 3);
            this.ListView_ParaTuning.Name = "ListView_ParaTuning";
            this.ListView_ParaTuning.Size = new System.Drawing.Size(591, 550);
            this.ListView_ParaTuning.TabIndex = 0;
            this.ListView_ParaTuning.UseCompatibleStateImageBehavior = false;
            // 
            // Monitor
            // 
            this.Monitor.BackColor = System.Drawing.SystemColors.Control;
            this.Monitor.Controls.Add(this.groupBox11);
            this.Monitor.Controls.Add(this.groupBox10);
            this.Monitor.Controls.Add(this.groupBox9);
            this.Monitor.Controls.Add(this.groupBox8);
            this.Monitor.Location = new System.Drawing.Point(4, 24);
            this.Monitor.Name = "Monitor";
            this.Monitor.Size = new System.Drawing.Size(885, 569);
            this.Monitor.TabIndex = 4;
            this.Monitor.Text = "Sys Monitor";
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.tableLayoutPanel10);
            this.groupBox11.Controls.Add(this.tableLayoutPanel9);
            this.groupBox11.Controls.Add(this.tableLayoutPanel8);
            this.groupBox11.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox11.Location = new System.Drawing.Point(471, 14);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(384, 320);
            this.groupBox11.TabIndex = 6;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "Protect Code";
            // 
            // tableLayoutPanel10
            // 
            this.tableLayoutPanel10.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel10.ColumnCount = 1;
            this.tableLayoutPanel10.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 276F));
            this.tableLayoutPanel10.Controls.Add(this.Label_SpyMon_Pro_Tcon, 0, 1);
            this.tableLayoutPanel10.Controls.Add(this.Label_SpyMon_Pro_CompHot, 0, 5);
            this.tableLayoutPanel10.Controls.Add(this.Label_SpyMon_Pro_Tamb, 0, 0);
            this.tableLayoutPanel10.Controls.Add(this.Label_SpyMon_Pro_IPM_Hot, 0, 8);
            this.tableLayoutPanel10.Controls.Add(this.Label_SpyMon_Pro_Tsuc, 0, 3);
            this.tableLayoutPanel10.Controls.Add(this.Label_SpyMon_Pro_Tdis, 0, 2);
            this.tableLayoutPanel10.Controls.Add(this.Label_SpyMon_Pro_T_IPM, 0, 4);
            this.tableLayoutPanel10.Controls.Add(this.Label_SpyMon_Pro_SucHot, 0, 6);
            this.tableLayoutPanel10.Controls.Add(this.Label_SpyMon_Pro_ConHot, 0, 7);
            this.tableLayoutPanel10.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tableLayoutPanel10.ForeColor = System.Drawing.Color.DarkGray;
            this.tableLayoutPanel10.Location = new System.Drawing.Point(256, 29);
            this.tableLayoutPanel10.Name = "tableLayoutPanel10";
            this.tableLayoutPanel10.RowCount = 9;
            this.tableLayoutPanel10.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel10.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel10.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel10.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel10.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel10.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel10.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel10.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel10.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel10.Size = new System.Drawing.Size(114, 283);
            this.tableLayoutPanel10.TabIndex = 7;
            // 
            // Label_SpyMon_Pro_Tcon
            // 
            this.Label_SpyMon_Pro_Tcon.AutoSize = true;
            this.Label_SpyMon_Pro_Tcon.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Label_SpyMon_Pro_Tcon.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_SpyMon_Pro_Tcon.Location = new System.Drawing.Point(21, 40);
            this.Label_SpyMon_Pro_Tcon.Margin = new System.Windows.Forms.Padding(20, 8, 0, 2);
            this.Label_SpyMon_Pro_Tcon.Name = "Label_SpyMon_Pro_Tcon";
            this.Label_SpyMon_Pro_Tcon.Size = new System.Drawing.Size(81, 15);
            this.Label_SpyMon_Pro_Tcon.TabIndex = 14;
            this.Label_SpyMon_Pro_Tcon.Text = "T_Condensor";
            // 
            // Label_SpyMon_Pro_CompHot
            // 
            this.Label_SpyMon_Pro_CompHot.AutoSize = true;
            this.Label_SpyMon_Pro_CompHot.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Label_SpyMon_Pro_CompHot.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_SpyMon_Pro_CompHot.Location = new System.Drawing.Point(16, 164);
            this.Label_SpyMon_Pro_CompHot.Margin = new System.Windows.Forms.Padding(15, 8, 0, 0);
            this.Label_SpyMon_Pro_CompHot.Name = "Label_SpyMon_Pro_CompHot";
            this.Label_SpyMon_Pro_CompHot.Size = new System.Drawing.Size(68, 15);
            this.Label_SpyMon_Pro_CompHot.TabIndex = 12;
            this.Label_SpyMon_Pro_CompHot.Text = "Comp (Hot)";
            // 
            // Label_SpyMon_Pro_Tamb
            // 
            this.Label_SpyMon_Pro_Tamb.AutoSize = true;
            this.Label_SpyMon_Pro_Tamb.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Label_SpyMon_Pro_Tamb.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_SpyMon_Pro_Tamb.Location = new System.Drawing.Point(24, 9);
            this.Label_SpyMon_Pro_Tamb.Margin = new System.Windows.Forms.Padding(23, 8, 0, 5);
            this.Label_SpyMon_Pro_Tamb.Name = "Label_SpyMon_Pro_Tamb";
            this.Label_SpyMon_Pro_Tamb.Size = new System.Drawing.Size(68, 15);
            this.Label_SpyMon_Pro_Tamb.TabIndex = 10;
            this.Label_SpyMon_Pro_Tamb.Text = "T_Ambient";
            // 
            // Label_SpyMon_Pro_IPM_Hot
            // 
            this.Label_SpyMon_Pro_IPM_Hot.AutoSize = true;
            this.Label_SpyMon_Pro_IPM_Hot.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Label_SpyMon_Pro_IPM_Hot.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_SpyMon_Pro_IPM_Hot.Location = new System.Drawing.Point(21, 257);
            this.Label_SpyMon_Pro_IPM_Hot.Margin = new System.Windows.Forms.Padding(20, 8, 0, 8);
            this.Label_SpyMon_Pro_IPM_Hot.Name = "Label_SpyMon_Pro_IPM_Hot";
            this.Label_SpyMon_Pro_IPM_Hot.Size = new System.Drawing.Size(75, 15);
            this.Label_SpyMon_Pro_IPM_Hot.TabIndex = 18;
            this.Label_SpyMon_Pro_IPM_Hot.Text = "IPM Too Hot";
            // 
            // Label_SpyMon_Pro_Tsuc
            // 
            this.Label_SpyMon_Pro_Tsuc.AutoSize = true;
            this.Label_SpyMon_Pro_Tsuc.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Label_SpyMon_Pro_Tsuc.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_SpyMon_Pro_Tsuc.Location = new System.Drawing.Point(26, 102);
            this.Label_SpyMon_Pro_Tsuc.Margin = new System.Windows.Forms.Padding(25, 8, 0, 8);
            this.Label_SpyMon_Pro_Tsuc.Name = "Label_SpyMon_Pro_Tsuc";
            this.Label_SpyMon_Pro_Tsuc.Size = new System.Drawing.Size(64, 14);
            this.Label_SpyMon_Pro_Tsuc.TabIndex = 18;
            this.Label_SpyMon_Pro_Tsuc.Text = "T_Suction";
            // 
            // Label_SpyMon_Pro_Tdis
            // 
            this.Label_SpyMon_Pro_Tdis.AutoSize = true;
            this.Label_SpyMon_Pro_Tdis.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Label_SpyMon_Pro_Tdis.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_SpyMon_Pro_Tdis.Location = new System.Drawing.Point(21, 71);
            this.Label_SpyMon_Pro_Tdis.Margin = new System.Windows.Forms.Padding(20, 8, 0, 2);
            this.Label_SpyMon_Pro_Tdis.Name = "Label_SpyMon_Pro_Tdis";
            this.Label_SpyMon_Pro_Tdis.Size = new System.Drawing.Size(79, 15);
            this.Label_SpyMon_Pro_Tdis.TabIndex = 19;
            this.Label_SpyMon_Pro_Tdis.Text = "T_Discharge";
            this.Label_SpyMon_Pro_Tdis.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Label_SpyMon_Pro_T_IPM
            // 
            this.Label_SpyMon_Pro_T_IPM.AutoSize = true;
            this.Label_SpyMon_Pro_T_IPM.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Label_SpyMon_Pro_T_IPM.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_SpyMon_Pro_T_IPM.Location = new System.Drawing.Point(31, 133);
            this.Label_SpyMon_Pro_T_IPM.Margin = new System.Windows.Forms.Padding(30, 8, 0, 2);
            this.Label_SpyMon_Pro_T_IPM.Name = "Label_SpyMon_Pro_T_IPM";
            this.Label_SpyMon_Pro_T_IPM.Size = new System.Drawing.Size(45, 15);
            this.Label_SpyMon_Pro_T_IPM.TabIndex = 14;
            this.Label_SpyMon_Pro_T_IPM.Text = "T_IPM";
            // 
            // Label_SpyMon_Pro_SucHot
            // 
            this.Label_SpyMon_Pro_SucHot.AutoSize = true;
            this.Label_SpyMon_Pro_SucHot.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Label_SpyMon_Pro_SucHot.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_SpyMon_Pro_SucHot.Location = new System.Drawing.Point(16, 195);
            this.Label_SpyMon_Pro_SucHot.Margin = new System.Windows.Forms.Padding(15, 8, 0, 2);
            this.Label_SpyMon_Pro_SucHot.Name = "Label_SpyMon_Pro_SucHot";
            this.Label_SpyMon_Pro_SucHot.Size = new System.Drawing.Size(79, 15);
            this.Label_SpyMon_Pro_SucHot.TabIndex = 16;
            this.Label_SpyMon_Pro_SucHot.Text = "Suction (Hot)";
            // 
            // Label_SpyMon_Pro_ConHot
            // 
            this.Label_SpyMon_Pro_ConHot.AutoSize = true;
            this.Label_SpyMon_Pro_ConHot.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Label_SpyMon_Pro_ConHot.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_SpyMon_Pro_ConHot.Location = new System.Drawing.Point(6, 226);
            this.Label_SpyMon_Pro_ConHot.Margin = new System.Windows.Forms.Padding(5, 8, 0, 2);
            this.Label_SpyMon_Pro_ConHot.Name = "Label_SpyMon_Pro_ConHot";
            this.Label_SpyMon_Pro_ConHot.Size = new System.Drawing.Size(96, 15);
            this.Label_SpyMon_Pro_ConHot.TabIndex = 15;
            this.Label_SpyMon_Pro_ConHot.Text = "Condesnor (Hot)";
            // 
            // tableLayoutPanel9
            // 
            this.tableLayoutPanel9.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel9.ColumnCount = 1;
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 276F));
            this.tableLayoutPanel9.Controls.Add(this.Label_SpyMon_Pro_VacHigh, 0, 3);
            this.tableLayoutPanel9.Controls.Add(this.Label_SpyMon_Pro_VbusHigh, 0, 5);
            this.tableLayoutPanel9.Controls.Add(this.Label_SpyMon_Pro_VbusLow, 0, 4);
            this.tableLayoutPanel9.Controls.Add(this.Label_SpyMon_Pro_VacLow, 0, 2);
            this.tableLayoutPanel9.Controls.Add(this.Label_SpyMon_Pro_IacLow, 0, 0);
            this.tableLayoutPanel9.Controls.Add(this.Label_SpyMon_Pro_IacOver, 0, 1);
            this.tableLayoutPanel9.Controls.Add(this.Label_SpyMon_Pro_DC_Fan, 0, 6);
            this.tableLayoutPanel9.Controls.Add(this.Label_SpyMon_Pro_Motor3MinStop, 0, 7);
            this.tableLayoutPanel9.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tableLayoutPanel9.ForeColor = System.Drawing.Color.DarkGray;
            this.tableLayoutPanel9.Location = new System.Drawing.Point(140, 60);
            this.tableLayoutPanel9.Name = "tableLayoutPanel9";
            this.tableLayoutPanel9.RowCount = 8;
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel9.Size = new System.Drawing.Size(115, 252);
            this.tableLayoutPanel9.TabIndex = 6;
            // 
            // Label_SpyMon_Pro_VacHigh
            // 
            this.Label_SpyMon_Pro_VacHigh.AutoSize = true;
            this.Label_SpyMon_Pro_VacHigh.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Label_SpyMon_Pro_VacHigh.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_SpyMon_Pro_VacHigh.Location = new System.Drawing.Point(16, 102);
            this.Label_SpyMon_Pro_VacHigh.Margin = new System.Windows.Forms.Padding(15, 8, 0, 0);
            this.Label_SpyMon_Pro_VacHigh.Name = "Label_SpyMon_Pro_VacHigh";
            this.Label_SpyMon_Pro_VacHigh.Size = new System.Drawing.Size(81, 15);
            this.Label_SpyMon_Pro_VacHigh.TabIndex = 12;
            this.Label_SpyMon_Pro_VacHigh.Text = "Vac Too High";
            // 
            // Label_SpyMon_Pro_VbusHigh
            // 
            this.Label_SpyMon_Pro_VbusHigh.AutoSize = true;
            this.Label_SpyMon_Pro_VbusHigh.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Label_SpyMon_Pro_VbusHigh.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_SpyMon_Pro_VbusHigh.ForeColor = System.Drawing.Color.DarkGray;
            this.Label_SpyMon_Pro_VbusHigh.Location = new System.Drawing.Point(16, 164);
            this.Label_SpyMon_Pro_VbusHigh.Margin = new System.Windows.Forms.Padding(15, 8, 0, 3);
            this.Label_SpyMon_Pro_VbusHigh.Name = "Label_SpyMon_Pro_VbusHigh";
            this.Label_SpyMon_Pro_VbusHigh.Size = new System.Drawing.Size(88, 15);
            this.Label_SpyMon_Pro_VbusHigh.TabIndex = 11;
            this.Label_SpyMon_Pro_VbusHigh.Text = "Vbus Too High";
            // 
            // Label_SpyMon_Pro_VbusLow
            // 
            this.Label_SpyMon_Pro_VbusLow.AutoSize = true;
            this.Label_SpyMon_Pro_VbusLow.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Label_SpyMon_Pro_VbusLow.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_SpyMon_Pro_VbusLow.ForeColor = System.Drawing.Color.DarkGray;
            this.Label_SpyMon_Pro_VbusLow.Location = new System.Drawing.Point(16, 133);
            this.Label_SpyMon_Pro_VbusLow.Margin = new System.Windows.Forms.Padding(15, 8, 8, 8);
            this.Label_SpyMon_Pro_VbusLow.Name = "Label_SpyMon_Pro_VbusLow";
            this.Label_SpyMon_Pro_VbusLow.Size = new System.Drawing.Size(83, 14);
            this.Label_SpyMon_Pro_VbusLow.TabIndex = 9;
            this.Label_SpyMon_Pro_VbusLow.Text = "Vbus Too Low";
            this.Label_SpyMon_Pro_VbusLow.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Label_SpyMon_Pro_VacLow
            // 
            this.Label_SpyMon_Pro_VacLow.AutoSize = true;
            this.Label_SpyMon_Pro_VacLow.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Label_SpyMon_Pro_VacLow.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_SpyMon_Pro_VacLow.Location = new System.Drawing.Point(19, 71);
            this.Label_SpyMon_Pro_VacLow.Margin = new System.Windows.Forms.Padding(18, 8, 8, 2);
            this.Label_SpyMon_Pro_VacLow.Name = "Label_SpyMon_Pro_VacLow";
            this.Label_SpyMon_Pro_VacLow.Size = new System.Drawing.Size(76, 15);
            this.Label_SpyMon_Pro_VacLow.TabIndex = 13;
            this.Label_SpyMon_Pro_VacLow.Text = "Vac Too Low";
            // 
            // Label_SpyMon_Pro_IacLow
            // 
            this.Label_SpyMon_Pro_IacLow.AutoSize = true;
            this.Label_SpyMon_Pro_IacLow.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Label_SpyMon_Pro_IacLow.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_SpyMon_Pro_IacLow.Location = new System.Drawing.Point(31, 9);
            this.Label_SpyMon_Pro_IacLow.Margin = new System.Windows.Forms.Padding(30, 8, 0, 5);
            this.Label_SpyMon_Pro_IacLow.Name = "Label_SpyMon_Pro_IacLow";
            this.Label_SpyMon_Pro_IacLow.Size = new System.Drawing.Size(48, 15);
            this.Label_SpyMon_Pro_IacLow.TabIndex = 10;
            this.Label_SpyMon_Pro_IacLow.Text = "Iac Low";
            // 
            // Label_SpyMon_Pro_IacOver
            // 
            this.Label_SpyMon_Pro_IacOver.AutoSize = true;
            this.Label_SpyMon_Pro_IacOver.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Label_SpyMon_Pro_IacOver.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_SpyMon_Pro_IacOver.Location = new System.Drawing.Point(31, 40);
            this.Label_SpyMon_Pro_IacOver.Margin = new System.Windows.Forms.Padding(30, 8, 0, 2);
            this.Label_SpyMon_Pro_IacOver.Name = "Label_SpyMon_Pro_IacOver";
            this.Label_SpyMon_Pro_IacOver.Size = new System.Drawing.Size(53, 15);
            this.Label_SpyMon_Pro_IacOver.TabIndex = 19;
            this.Label_SpyMon_Pro_IacOver.Text = "Iac Over";
            this.Label_SpyMon_Pro_IacOver.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Label_SpyMon_Pro_DC_Fan
            // 
            this.Label_SpyMon_Pro_DC_Fan.AutoSize = true;
            this.Label_SpyMon_Pro_DC_Fan.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Label_SpyMon_Pro_DC_Fan.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_SpyMon_Pro_DC_Fan.ForeColor = System.Drawing.Color.DarkGray;
            this.Label_SpyMon_Pro_DC_Fan.Location = new System.Drawing.Point(21, 195);
            this.Label_SpyMon_Pro_DC_Fan.Margin = new System.Windows.Forms.Padding(20, 8, 0, 3);
            this.Label_SpyMon_Pro_DC_Fan.Name = "Label_SpyMon_Pro_DC_Fan";
            this.Label_SpyMon_Pro_DC_Fan.Size = new System.Drawing.Size(72, 15);
            this.Label_SpyMon_Pro_DC_Fan.TabIndex = 11;
            this.Label_SpyMon_Pro_DC_Fan.Text = "DC Fan Fail";
            // 
            // Label_SpyMon_Pro_Motor3MinStop
            // 
            this.Label_SpyMon_Pro_Motor3MinStop.AutoSize = true;
            this.Label_SpyMon_Pro_Motor3MinStop.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Label_SpyMon_Pro_Motor3MinStop.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_SpyMon_Pro_Motor3MinStop.ForeColor = System.Drawing.Color.DarkGray;
            this.Label_SpyMon_Pro_Motor3MinStop.Location = new System.Drawing.Point(6, 226);
            this.Label_SpyMon_Pro_Motor3MinStop.Margin = new System.Windows.Forms.Padding(5, 8, 0, 3);
            this.Label_SpyMon_Pro_Motor3MinStop.Name = "Label_SpyMon_Pro_Motor3MinStop";
            this.Label_SpyMon_Pro_Motor3MinStop.Size = new System.Drawing.Size(102, 15);
            this.Label_SpyMon_Pro_Motor3MinStop.TabIndex = 20;
            this.Label_SpyMon_Pro_Motor3MinStop.Text = "Motor 3 Min Stop";
            // 
            // tableLayoutPanel8
            // 
            this.tableLayoutPanel8.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel8.ColumnCount = 1;
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 276F));
            this.tableLayoutPanel8.Controls.Add(this.Label_SpyMon_Pro_UVW, 0, 0);
            this.tableLayoutPanel8.Controls.Add(this.Label_SpyMon_Pro_LoseSPD, 0, 1);
            this.tableLayoutPanel8.Controls.Add(this.Label_SpyMon_Pro_AmbientHot, 0, 8);
            this.tableLayoutPanel8.Controls.Add(this.Label_SpyMon_Pro_ZeroSPD, 0, 2);
            this.tableLayoutPanel8.Controls.Add(this.Label_SpyMon_Pro_FBK_Err, 0, 3);
            this.tableLayoutPanel8.Controls.Add(this.Label_SpyMon_Pro_StartUp, 0, 4);
            this.tableLayoutPanel8.Controls.Add(this.Label_SpyMon_Pro_IPM_Fault, 0, 5);
            this.tableLayoutPanel8.Controls.Add(this.Label_SpyMon_Pro_COM_Fail, 0, 6);
            this.tableLayoutPanel8.Controls.Add(this.Label_SpyMon_Pro_CurSenErr, 0, 7);
            this.tableLayoutPanel8.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tableLayoutPanel8.ForeColor = System.Drawing.Color.DarkGray;
            this.tableLayoutPanel8.Location = new System.Drawing.Point(11, 29);
            this.tableLayoutPanel8.Name = "tableLayoutPanel8";
            this.tableLayoutPanel8.RowCount = 9;
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel8.Size = new System.Drawing.Size(127, 283);
            this.tableLayoutPanel8.TabIndex = 5;
            // 
            // Label_SpyMon_Pro_UVW
            // 
            this.Label_SpyMon_Pro_UVW.AutoSize = true;
            this.Label_SpyMon_Pro_UVW.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Label_SpyMon_Pro_UVW.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_SpyMon_Pro_UVW.ForeColor = System.Drawing.Color.DarkGray;
            this.Label_SpyMon_Pro_UVW.Location = new System.Drawing.Point(21, 9);
            this.Label_SpyMon_Pro_UVW.Margin = new System.Windows.Forms.Padding(20, 8, 8, 8);
            this.Label_SpyMon_Pro_UVW.Name = "Label_SpyMon_Pro_UVW";
            this.Label_SpyMon_Pro_UVW.Size = new System.Drawing.Size(74, 14);
            this.Label_SpyMon_Pro_UVW.TabIndex = 9;
            this.Label_SpyMon_Pro_UVW.Text = "UVW (Lose)";
            this.Label_SpyMon_Pro_UVW.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Label_SpyMon_Pro_LoseSPD
            // 
            this.Label_SpyMon_Pro_LoseSPD.AutoSize = true;
            this.Label_SpyMon_Pro_LoseSPD.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Label_SpyMon_Pro_LoseSPD.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_SpyMon_Pro_LoseSPD.Location = new System.Drawing.Point(9, 40);
            this.Label_SpyMon_Pro_LoseSPD.Margin = new System.Windows.Forms.Padding(8, 8, 8, 2);
            this.Label_SpyMon_Pro_LoseSPD.Name = "Label_SpyMon_Pro_LoseSPD";
            this.Label_SpyMon_Pro_LoseSPD.Size = new System.Drawing.Size(110, 15);
            this.Label_SpyMon_Pro_LoseSPD.TabIndex = 13;
            this.Label_SpyMon_Pro_LoseSPD.Text = "Lose Speed (Comp)";
            // 
            // Label_SpyMon_Pro_AmbientHot
            // 
            this.Label_SpyMon_Pro_AmbientHot.AutoSize = true;
            this.Label_SpyMon_Pro_AmbientHot.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Label_SpyMon_Pro_AmbientHot.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_SpyMon_Pro_AmbientHot.ForeColor = System.Drawing.Color.DarkGray;
            this.Label_SpyMon_Pro_AmbientHot.Location = new System.Drawing.Point(19, 257);
            this.Label_SpyMon_Pro_AmbientHot.Margin = new System.Windows.Forms.Padding(18, 8, 0, 3);
            this.Label_SpyMon_Pro_AmbientHot.Name = "Label_SpyMon_Pro_AmbientHot";
            this.Label_SpyMon_Pro_AmbientHot.Size = new System.Drawing.Size(83, 15);
            this.Label_SpyMon_Pro_AmbientHot.TabIndex = 11;
            this.Label_SpyMon_Pro_AmbientHot.Text = "Ambient (Hot)";
            // 
            // Label_SpyMon_Pro_ZeroSPD
            // 
            this.Label_SpyMon_Pro_ZeroSPD.AutoSize = true;
            this.Label_SpyMon_Pro_ZeroSPD.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Label_SpyMon_Pro_ZeroSPD.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_SpyMon_Pro_ZeroSPD.Location = new System.Drawing.Point(9, 71);
            this.Label_SpyMon_Pro_ZeroSPD.Margin = new System.Windows.Forms.Padding(8, 8, 0, 0);
            this.Label_SpyMon_Pro_ZeroSPD.Name = "Label_SpyMon_Pro_ZeroSPD";
            this.Label_SpyMon_Pro_ZeroSPD.Size = new System.Drawing.Size(110, 15);
            this.Label_SpyMon_Pro_ZeroSPD.TabIndex = 12;
            this.Label_SpyMon_Pro_ZeroSPD.Text = "Zero Speed (Comp)";
            // 
            // Label_SpyMon_Pro_FBK_Err
            // 
            this.Label_SpyMon_Pro_FBK_Err.AutoSize = true;
            this.Label_SpyMon_Pro_FBK_Err.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Label_SpyMon_Pro_FBK_Err.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_SpyMon_Pro_FBK_Err.Location = new System.Drawing.Point(9, 102);
            this.Label_SpyMon_Pro_FBK_Err.Margin = new System.Windows.Forms.Padding(8, 8, 0, 5);
            this.Label_SpyMon_Pro_FBK_Err.Name = "Label_SpyMon_Pro_FBK_Err";
            this.Label_SpyMon_Pro_FBK_Err.Size = new System.Drawing.Size(108, 15);
            this.Label_SpyMon_Pro_FBK_Err.TabIndex = 10;
            this.Label_SpyMon_Pro_FBK_Err.Text = "FBK Error (Comp)";
            // 
            // Label_SpyMon_Pro_StartUp
            // 
            this.Label_SpyMon_Pro_StartUp.AutoSize = true;
            this.Label_SpyMon_Pro_StartUp.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Label_SpyMon_Pro_StartUp.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_SpyMon_Pro_StartUp.Location = new System.Drawing.Point(9, 133);
            this.Label_SpyMon_Pro_StartUp.Margin = new System.Windows.Forms.Padding(8, 8, 0, 8);
            this.Label_SpyMon_Pro_StartUp.Name = "Label_SpyMon_Pro_StartUp";
            this.Label_SpyMon_Pro_StartUp.Size = new System.Drawing.Size(116, 14);
            this.Label_SpyMon_Pro_StartUp.TabIndex = 14;
            this.Label_SpyMon_Pro_StartUp.Text = "Start Up Err (Comp)";
            // 
            // Label_SpyMon_Pro_IPM_Fault
            // 
            this.Label_SpyMon_Pro_IPM_Fault.AutoSize = true;
            this.Label_SpyMon_Pro_IPM_Fault.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Label_SpyMon_Pro_IPM_Fault.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_SpyMon_Pro_IPM_Fault.ForeColor = System.Drawing.Color.DarkGray;
            this.Label_SpyMon_Pro_IPM_Fault.Location = new System.Drawing.Point(26, 164);
            this.Label_SpyMon_Pro_IPM_Fault.Margin = new System.Windows.Forms.Padding(25, 8, 8, 3);
            this.Label_SpyMon_Pro_IPM_Fault.Name = "Label_SpyMon_Pro_IPM_Fault";
            this.Label_SpyMon_Pro_IPM_Fault.Size = new System.Drawing.Size(61, 15);
            this.Label_SpyMon_Pro_IPM_Fault.TabIndex = 9;
            this.Label_SpyMon_Pro_IPM_Fault.Text = "IPM Fault";
            this.Label_SpyMon_Pro_IPM_Fault.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Label_SpyMon_Pro_COM_Fail
            // 
            this.Label_SpyMon_Pro_COM_Fail.AutoSize = true;
            this.Label_SpyMon_Pro_COM_Fail.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Label_SpyMon_Pro_COM_Fail.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_SpyMon_Pro_COM_Fail.Location = new System.Drawing.Point(26, 195);
            this.Label_SpyMon_Pro_COM_Fail.Margin = new System.Windows.Forms.Padding(25, 8, 8, 2);
            this.Label_SpyMon_Pro_COM_Fail.Name = "Label_SpyMon_Pro_COM_Fail";
            this.Label_SpyMon_Pro_COM_Fail.Size = new System.Drawing.Size(64, 15);
            this.Label_SpyMon_Pro_COM_Fail.TabIndex = 13;
            this.Label_SpyMon_Pro_COM_Fail.Text = "COM Fail ";
            // 
            // Label_SpyMon_Pro_CurSenErr
            // 
            this.Label_SpyMon_Pro_CurSenErr.AutoSize = true;
            this.Label_SpyMon_Pro_CurSenErr.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Label_SpyMon_Pro_CurSenErr.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_SpyMon_Pro_CurSenErr.Location = new System.Drawing.Point(6, 226);
            this.Label_SpyMon_Pro_CurSenErr.Margin = new System.Windows.Forms.Padding(5, 8, 0, 8);
            this.Label_SpyMon_Pro_CurSenErr.Name = "Label_SpyMon_Pro_CurSenErr";
            this.Label_SpyMon_Pro_CurSenErr.Size = new System.Drawing.Size(116, 14);
            this.Label_SpyMon_Pro_CurSenErr.TabIndex = 20;
            this.Label_SpyMon_Pro_CurSenErr.Text = "Current Sensor Err";
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.tableLayoutPanel7);
            this.groupBox10.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox10.Location = new System.Drawing.Point(13, 300);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(295, 266);
            this.groupBox10.TabIndex = 6;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "Working State";
            // 
            // tableLayoutPanel7
            // 
            this.tableLayoutPanel7.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel7.ColumnCount = 2;
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 116F));
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 268F));
            this.tableLayoutPanel7.Controls.Add(this.textBox_SpyMon_WS_MS, 1, 3);
            this.tableLayoutPanel7.Controls.Add(this.Label_SpyMon_WS_MS, 0, 3);
            this.tableLayoutPanel7.Controls.Add(this.Label_SpyMon_WS_Cmd, 0, 0);
            this.tableLayoutPanel7.Controls.Add(this.textBox_SpyMon_WS_Cmd, 1, 0);
            this.tableLayoutPanel7.Controls.Add(this.textBox_SpyMon_WS_WM, 1, 1);
            this.tableLayoutPanel7.Controls.Add(this.Label_SpyMon_WS_WM, 0, 1);
            this.tableLayoutPanel7.Controls.Add(this.Label_SpyMon_WS_WS, 0, 2);
            this.tableLayoutPanel7.Controls.Add(this.textBox_SpyMon_WS_WS, 1, 2);
            this.tableLayoutPanel7.Controls.Add(this.Label_SpyMon_RstTime, 0, 6);
            this.tableLayoutPanel7.Controls.Add(this.Label_SpyMon_WS_FS, 0, 5);
            this.tableLayoutPanel7.Controls.Add(this.Label_SpyMon_WS_SS, 0, 4);
            this.tableLayoutPanel7.Controls.Add(this.textBox_SpyMon_RstTime, 1, 6);
            this.tableLayoutPanel7.Controls.Add(this.textBox_SpyMon_WS_FS, 1, 5);
            this.tableLayoutPanel7.Controls.Add(this.textBox_SpyMon_WS_SS, 1, 4);
            this.tableLayoutPanel7.Location = new System.Drawing.Point(6, 28);
            this.tableLayoutPanel7.Name = "tableLayoutPanel7";
            this.tableLayoutPanel7.RowCount = 7;
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel7.Size = new System.Drawing.Size(283, 217);
            this.tableLayoutPanel7.TabIndex = 5;
            // 
            // textBox_SpyMon_WS_MS
            // 
            this.textBox_SpyMon_WS_MS.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_SpyMon_WS_MS.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_SpyMon_WS_MS.Location = new System.Drawing.Point(126, 102);
            this.textBox_SpyMon_WS_MS.Margin = new System.Windows.Forms.Padding(8);
            this.textBox_SpyMon_WS_MS.Name = "textBox_SpyMon_WS_MS";
            this.textBox_SpyMon_WS_MS.ReadOnly = true;
            this.textBox_SpyMon_WS_MS.Size = new System.Drawing.Size(152, 14);
            this.textBox_SpyMon_WS_MS.TabIndex = 21;
            this.textBox_SpyMon_WS_MS.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Label_SpyMon_WS_MS
            // 
            this.Label_SpyMon_WS_MS.AutoSize = true;
            this.Label_SpyMon_WS_MS.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Label_SpyMon_WS_MS.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_SpyMon_WS_MS.Location = new System.Drawing.Point(21, 102);
            this.Label_SpyMon_WS_MS.Margin = new System.Windows.Forms.Padding(20, 8, 0, 0);
            this.Label_SpyMon_WS_MS.Name = "Label_SpyMon_WS_MS";
            this.Label_SpyMon_WS_MS.Size = new System.Drawing.Size(75, 15);
            this.Label_SpyMon_WS_MS.TabIndex = 20;
            this.Label_SpyMon_WS_MS.Text = "Motor_State";
            // 
            // Label_SpyMon_WS_Cmd
            // 
            this.Label_SpyMon_WS_Cmd.AutoSize = true;
            this.Label_SpyMon_WS_Cmd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Label_SpyMon_WS_Cmd.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_SpyMon_WS_Cmd.Location = new System.Drawing.Point(26, 9);
            this.Label_SpyMon_WS_Cmd.Margin = new System.Windows.Forms.Padding(25, 8, 8, 8);
            this.Label_SpyMon_WS_Cmd.Name = "Label_SpyMon_WS_Cmd";
            this.Label_SpyMon_WS_Cmd.Size = new System.Drawing.Size(61, 14);
            this.Label_SpyMon_WS_Cmd.TabIndex = 9;
            this.Label_SpyMon_WS_Cmd.Text = "Command";
            this.Label_SpyMon_WS_Cmd.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // textBox_SpyMon_WS_Cmd
            // 
            this.textBox_SpyMon_WS_Cmd.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_SpyMon_WS_Cmd.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_SpyMon_WS_Cmd.Location = new System.Drawing.Point(126, 9);
            this.textBox_SpyMon_WS_Cmd.Margin = new System.Windows.Forms.Padding(8);
            this.textBox_SpyMon_WS_Cmd.Name = "textBox_SpyMon_WS_Cmd";
            this.textBox_SpyMon_WS_Cmd.ReadOnly = true;
            this.textBox_SpyMon_WS_Cmd.Size = new System.Drawing.Size(152, 14);
            this.textBox_SpyMon_WS_Cmd.TabIndex = 0;
            this.textBox_SpyMon_WS_Cmd.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox_SpyMon_WS_WM
            // 
            this.textBox_SpyMon_WS_WM.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_SpyMon_WS_WM.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_SpyMon_WS_WM.Location = new System.Drawing.Point(126, 40);
            this.textBox_SpyMon_WS_WM.Margin = new System.Windows.Forms.Padding(8);
            this.textBox_SpyMon_WS_WM.Name = "textBox_SpyMon_WS_WM";
            this.textBox_SpyMon_WS_WM.ReadOnly = true;
            this.textBox_SpyMon_WS_WM.Size = new System.Drawing.Size(152, 14);
            this.textBox_SpyMon_WS_WM.TabIndex = 6;
            this.textBox_SpyMon_WS_WM.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Label_SpyMon_WS_WM
            // 
            this.Label_SpyMon_WS_WM.AutoSize = true;
            this.Label_SpyMon_WS_WM.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Label_SpyMon_WS_WM.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_SpyMon_WS_WM.Location = new System.Drawing.Point(21, 40);
            this.Label_SpyMon_WS_WM.Margin = new System.Windows.Forms.Padding(20, 8, 8, 2);
            this.Label_SpyMon_WS_WM.Name = "Label_SpyMon_WS_WM";
            this.Label_SpyMon_WS_WM.Size = new System.Drawing.Size(76, 15);
            this.Label_SpyMon_WS_WM.TabIndex = 13;
            this.Label_SpyMon_WS_WM.Text = "Work_Mode";
            // 
            // Label_SpyMon_WS_WS
            // 
            this.Label_SpyMon_WS_WS.AutoSize = true;
            this.Label_SpyMon_WS_WS.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Label_SpyMon_WS_WS.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_SpyMon_WS_WS.Location = new System.Drawing.Point(21, 71);
            this.Label_SpyMon_WS_WS.Margin = new System.Windows.Forms.Padding(20, 8, 0, 0);
            this.Label_SpyMon_WS_WS.Name = "Label_SpyMon_WS_WS";
            this.Label_SpyMon_WS_WS.Size = new System.Drawing.Size(75, 15);
            this.Label_SpyMon_WS_WS.TabIndex = 12;
            this.Label_SpyMon_WS_WS.Text = "Work_State";
            // 
            // textBox_SpyMon_WS_WS
            // 
            this.textBox_SpyMon_WS_WS.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_SpyMon_WS_WS.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_SpyMon_WS_WS.Location = new System.Drawing.Point(126, 71);
            this.textBox_SpyMon_WS_WS.Margin = new System.Windows.Forms.Padding(8);
            this.textBox_SpyMon_WS_WS.Name = "textBox_SpyMon_WS_WS";
            this.textBox_SpyMon_WS_WS.ReadOnly = true;
            this.textBox_SpyMon_WS_WS.Size = new System.Drawing.Size(152, 14);
            this.textBox_SpyMon_WS_WS.TabIndex = 15;
            this.textBox_SpyMon_WS_WS.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Label_SpyMon_RstTime
            // 
            this.Label_SpyMon_RstTime.AutoSize = true;
            this.Label_SpyMon_RstTime.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Label_SpyMon_RstTime.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_SpyMon_RstTime.Location = new System.Drawing.Point(24, 195);
            this.Label_SpyMon_RstTime.Margin = new System.Windows.Forms.Padding(23, 8, 0, 2);
            this.Label_SpyMon_RstTime.Name = "Label_SpyMon_RstTime";
            this.Label_SpyMon_RstTime.Size = new System.Drawing.Size(69, 15);
            this.Label_SpyMon_RstTime.TabIndex = 18;
            this.Label_SpyMon_RstTime.Text = "Reset Time";
            // 
            // Label_SpyMon_WS_FS
            // 
            this.Label_SpyMon_WS_FS.AutoSize = true;
            this.Label_SpyMon_WS_FS.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Label_SpyMon_WS_FS.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_SpyMon_WS_FS.Location = new System.Drawing.Point(24, 164);
            this.Label_SpyMon_WS_FS.Margin = new System.Windows.Forms.Padding(23, 8, 0, 2);
            this.Label_SpyMon_WS_FS.Name = "Label_SpyMon_WS_FS";
            this.Label_SpyMon_WS_FS.Size = new System.Drawing.Size(67, 15);
            this.Label_SpyMon_WS_FS.TabIndex = 14;
            this.Label_SpyMon_WS_FS.Text = "Freq_State";
            // 
            // Label_SpyMon_WS_SS
            // 
            this.Label_SpyMon_WS_SS.AutoSize = true;
            this.Label_SpyMon_WS_SS.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Label_SpyMon_WS_SS.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_SpyMon_WS_SS.Location = new System.Drawing.Point(26, 133);
            this.Label_SpyMon_WS_SS.Margin = new System.Windows.Forms.Padding(25, 8, 0, 5);
            this.Label_SpyMon_WS_SS.Name = "Label_SpyMon_WS_SS";
            this.Label_SpyMon_WS_SS.Size = new System.Drawing.Size(62, 15);
            this.Label_SpyMon_WS_SS.TabIndex = 10;
            this.Label_SpyMon_WS_SS.Text = "Sys_State";
            // 
            // textBox_SpyMon_RstTime
            // 
            this.textBox_SpyMon_RstTime.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_SpyMon_RstTime.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_SpyMon_RstTime.Location = new System.Drawing.Point(126, 195);
            this.textBox_SpyMon_RstTime.Margin = new System.Windows.Forms.Padding(8);
            this.textBox_SpyMon_RstTime.Name = "textBox_SpyMon_RstTime";
            this.textBox_SpyMon_RstTime.ReadOnly = true;
            this.textBox_SpyMon_RstTime.Size = new System.Drawing.Size(152, 14);
            this.textBox_SpyMon_RstTime.TabIndex = 19;
            this.textBox_SpyMon_RstTime.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox_SpyMon_WS_FS
            // 
            this.textBox_SpyMon_WS_FS.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.textBox_SpyMon_WS_FS.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_SpyMon_WS_FS.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_SpyMon_WS_FS.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.textBox_SpyMon_WS_FS.Location = new System.Drawing.Point(126, 164);
            this.textBox_SpyMon_WS_FS.Margin = new System.Windows.Forms.Padding(8);
            this.textBox_SpyMon_WS_FS.Name = "textBox_SpyMon_WS_FS";
            this.textBox_SpyMon_WS_FS.ReadOnly = true;
            this.textBox_SpyMon_WS_FS.Size = new System.Drawing.Size(152, 14);
            this.textBox_SpyMon_WS_FS.TabIndex = 17;
            this.textBox_SpyMon_WS_FS.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox_SpyMon_WS_SS
            // 
            this.textBox_SpyMon_WS_SS.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_SpyMon_WS_SS.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_SpyMon_WS_SS.Location = new System.Drawing.Point(126, 133);
            this.textBox_SpyMon_WS_SS.Margin = new System.Windows.Forms.Padding(8);
            this.textBox_SpyMon_WS_SS.Name = "textBox_SpyMon_WS_SS";
            this.textBox_SpyMon_WS_SS.ReadOnly = true;
            this.textBox_SpyMon_WS_SS.Size = new System.Drawing.Size(152, 14);
            this.textBox_SpyMon_WS_SS.TabIndex = 16;
            this.textBox_SpyMon_WS_SS.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.tableLayoutPanel6);
            this.groupBox9.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox9.Location = new System.Drawing.Point(231, 14);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(212, 279);
            this.groupBox9.TabIndex = 2;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Temperature (℃)";
            // 
            // tableLayoutPanel6
            // 
            this.tableLayoutPanel6.BackColor = System.Drawing.Color.Transparent;
            this.tableLayoutPanel6.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel6.ColumnCount = 2;
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 116F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 233F));
            this.tableLayoutPanel6.Controls.Add(this.textBox_SpyMon_T_Suc, 1, 5);
            this.tableLayoutPanel6.Controls.Add(this.textBox_SpyMon_T_OutdoorEx, 1, 4);
            this.tableLayoutPanel6.Controls.Add(this.textBox_SpyMon_T_Outdoor, 1, 3);
            this.tableLayoutPanel6.Controls.Add(this.textBox_SpyMon_T_Set, 1, 2);
            this.tableLayoutPanel6.Controls.Add(this.textBox_SpyMon_T_IndoorEx, 1, 1);
            this.tableLayoutPanel6.Controls.Add(this.Label_SpyMon_T_Set, 0, 2);
            this.tableLayoutPanel6.Controls.Add(this.Label_SpyMon_T_IndoorEx, 0, 1);
            this.tableLayoutPanel6.Controls.Add(this.Label_SpyMon_T_Indoor, 0, 0);
            this.tableLayoutPanel6.Controls.Add(this.Label_SpyMon_T_Outdoor, 0, 3);
            this.tableLayoutPanel6.Controls.Add(this.Label_SpyMon_T_OutdoorEx, 0, 4);
            this.tableLayoutPanel6.Controls.Add(this.Label_SpyMon_T_Suc, 0, 5);
            this.tableLayoutPanel6.Controls.Add(this.textBox_SpyMon_T_Indoor, 1, 0);
            this.tableLayoutPanel6.Controls.Add(this.Label_SpyMon_T_Dis, 0, 6);
            this.tableLayoutPanel6.Controls.Add(this.textBox_SpyMon_T_Dis, 1, 6);
            this.tableLayoutPanel6.Controls.Add(this.textBox_SpyMon_T_IPM, 1, 7);
            this.tableLayoutPanel6.Controls.Add(this.Label_SpyMon_T_IPM, 0, 7);
            this.tableLayoutPanel6.Location = new System.Drawing.Point(6, 28);
            this.tableLayoutPanel6.Name = "tableLayoutPanel6";
            this.tableLayoutPanel6.RowCount = 8;
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel6.Size = new System.Drawing.Size(200, 244);
            this.tableLayoutPanel6.TabIndex = 5;
            // 
            // textBox_SpyMon_T_Suc
            // 
            this.textBox_SpyMon_T_Suc.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_SpyMon_T_Suc.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_SpyMon_T_Suc.Location = new System.Drawing.Point(126, 164);
            this.textBox_SpyMon_T_Suc.Margin = new System.Windows.Forms.Padding(8);
            this.textBox_SpyMon_T_Suc.Name = "textBox_SpyMon_T_Suc";
            this.textBox_SpyMon_T_Suc.ReadOnly = true;
            this.textBox_SpyMon_T_Suc.Size = new System.Drawing.Size(63, 14);
            this.textBox_SpyMon_T_Suc.TabIndex = 17;
            this.textBox_SpyMon_T_Suc.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox_SpyMon_T_OutdoorEx
            // 
            this.textBox_SpyMon_T_OutdoorEx.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_SpyMon_T_OutdoorEx.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_SpyMon_T_OutdoorEx.Location = new System.Drawing.Point(126, 133);
            this.textBox_SpyMon_T_OutdoorEx.Margin = new System.Windows.Forms.Padding(8);
            this.textBox_SpyMon_T_OutdoorEx.Name = "textBox_SpyMon_T_OutdoorEx";
            this.textBox_SpyMon_T_OutdoorEx.ReadOnly = true;
            this.textBox_SpyMon_T_OutdoorEx.Size = new System.Drawing.Size(63, 14);
            this.textBox_SpyMon_T_OutdoorEx.TabIndex = 16;
            this.textBox_SpyMon_T_OutdoorEx.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox_SpyMon_T_Outdoor
            // 
            this.textBox_SpyMon_T_Outdoor.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_SpyMon_T_Outdoor.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_SpyMon_T_Outdoor.Location = new System.Drawing.Point(126, 102);
            this.textBox_SpyMon_T_Outdoor.Margin = new System.Windows.Forms.Padding(8);
            this.textBox_SpyMon_T_Outdoor.Name = "textBox_SpyMon_T_Outdoor";
            this.textBox_SpyMon_T_Outdoor.ReadOnly = true;
            this.textBox_SpyMon_T_Outdoor.Size = new System.Drawing.Size(63, 14);
            this.textBox_SpyMon_T_Outdoor.TabIndex = 15;
            this.textBox_SpyMon_T_Outdoor.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox_SpyMon_T_Set
            // 
            this.textBox_SpyMon_T_Set.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_SpyMon_T_Set.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_SpyMon_T_Set.Location = new System.Drawing.Point(126, 71);
            this.textBox_SpyMon_T_Set.Margin = new System.Windows.Forms.Padding(8);
            this.textBox_SpyMon_T_Set.Name = "textBox_SpyMon_T_Set";
            this.textBox_SpyMon_T_Set.ReadOnly = true;
            this.textBox_SpyMon_T_Set.Size = new System.Drawing.Size(63, 14);
            this.textBox_SpyMon_T_Set.TabIndex = 6;
            this.textBox_SpyMon_T_Set.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox_SpyMon_T_IndoorEx
            // 
            this.textBox_SpyMon_T_IndoorEx.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_SpyMon_T_IndoorEx.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_SpyMon_T_IndoorEx.Location = new System.Drawing.Point(126, 40);
            this.textBox_SpyMon_T_IndoorEx.Margin = new System.Windows.Forms.Padding(8);
            this.textBox_SpyMon_T_IndoorEx.Name = "textBox_SpyMon_T_IndoorEx";
            this.textBox_SpyMon_T_IndoorEx.ReadOnly = true;
            this.textBox_SpyMon_T_IndoorEx.Size = new System.Drawing.Size(63, 14);
            this.textBox_SpyMon_T_IndoorEx.TabIndex = 7;
            this.textBox_SpyMon_T_IndoorEx.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Label_SpyMon_T_Set
            // 
            this.Label_SpyMon_T_Set.AutoSize = true;
            this.Label_SpyMon_T_Set.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Label_SpyMon_T_Set.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_SpyMon_T_Set.Location = new System.Drawing.Point(36, 71);
            this.Label_SpyMon_T_Set.Margin = new System.Windows.Forms.Padding(35, 8, 8, 2);
            this.Label_SpyMon_T_Set.Name = "Label_SpyMon_T_Set";
            this.Label_SpyMon_T_Set.Size = new System.Drawing.Size(47, 15);
            this.Label_SpyMon_T_Set.TabIndex = 13;
            this.Label_SpyMon_T_Set.Text = "Setting";
            // 
            // Label_SpyMon_T_IndoorEx
            // 
            this.Label_SpyMon_T_IndoorEx.AutoSize = true;
            this.Label_SpyMon_T_IndoorEx.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Label_SpyMon_T_IndoorEx.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_SpyMon_T_IndoorEx.Location = new System.Drawing.Point(13, 40);
            this.Label_SpyMon_T_IndoorEx.Margin = new System.Windows.Forms.Padding(12, 8, 0, 3);
            this.Label_SpyMon_T_IndoorEx.Name = "Label_SpyMon_T_IndoorEx";
            this.Label_SpyMon_T_IndoorEx.Size = new System.Drawing.Size(97, 15);
            this.Label_SpyMon_T_IndoorEx.TabIndex = 11;
            this.Label_SpyMon_T_IndoorEx.Text = "Indoor Exchange";
            // 
            // Label_SpyMon_T_Indoor
            // 
            this.Label_SpyMon_T_Indoor.AutoSize = true;
            this.Label_SpyMon_T_Indoor.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Label_SpyMon_T_Indoor.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_SpyMon_T_Indoor.Location = new System.Drawing.Point(13, 9);
            this.Label_SpyMon_T_Indoor.Margin = new System.Windows.Forms.Padding(12, 8, 8, 8);
            this.Label_SpyMon_T_Indoor.Name = "Label_SpyMon_T_Indoor";
            this.Label_SpyMon_T_Indoor.Size = new System.Drawing.Size(91, 14);
            this.Label_SpyMon_T_Indoor.TabIndex = 9;
            this.Label_SpyMon_T_Indoor.Text = "Indoor Ambient";
            this.Label_SpyMon_T_Indoor.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Label_SpyMon_T_Outdoor
            // 
            this.Label_SpyMon_T_Outdoor.AutoSize = true;
            this.Label_SpyMon_T_Outdoor.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Label_SpyMon_T_Outdoor.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_SpyMon_T_Outdoor.Location = new System.Drawing.Point(6, 102);
            this.Label_SpyMon_T_Outdoor.Margin = new System.Windows.Forms.Padding(5, 8, 0, 0);
            this.Label_SpyMon_T_Outdoor.Name = "Label_SpyMon_T_Outdoor";
            this.Label_SpyMon_T_Outdoor.Size = new System.Drawing.Size(101, 15);
            this.Label_SpyMon_T_Outdoor.TabIndex = 12;
            this.Label_SpyMon_T_Outdoor.Text = "Outdoor Ambient";
            // 
            // Label_SpyMon_T_OutdoorEx
            // 
            this.Label_SpyMon_T_OutdoorEx.AutoSize = true;
            this.Label_SpyMon_T_OutdoorEx.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Label_SpyMon_T_OutdoorEx.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_SpyMon_T_OutdoorEx.Location = new System.Drawing.Point(6, 133);
            this.Label_SpyMon_T_OutdoorEx.Margin = new System.Windows.Forms.Padding(5, 8, 0, 5);
            this.Label_SpyMon_T_OutdoorEx.Name = "Label_SpyMon_T_OutdoorEx";
            this.Label_SpyMon_T_OutdoorEx.Size = new System.Drawing.Size(107, 15);
            this.Label_SpyMon_T_OutdoorEx.TabIndex = 10;
            this.Label_SpyMon_T_OutdoorEx.Text = "Outdoor Exchange";
            // 
            // Label_SpyMon_T_Suc
            // 
            this.Label_SpyMon_T_Suc.AutoSize = true;
            this.Label_SpyMon_T_Suc.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Label_SpyMon_T_Suc.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_SpyMon_T_Suc.Location = new System.Drawing.Point(31, 164);
            this.Label_SpyMon_T_Suc.Margin = new System.Windows.Forms.Padding(30, 8, 0, 8);
            this.Label_SpyMon_T_Suc.Name = "Label_SpyMon_T_Suc";
            this.Label_SpyMon_T_Suc.Size = new System.Drawing.Size(49, 14);
            this.Label_SpyMon_T_Suc.TabIndex = 14;
            this.Label_SpyMon_T_Suc.Text = "Suction";
            // 
            // textBox_SpyMon_T_Indoor
            // 
            this.textBox_SpyMon_T_Indoor.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_SpyMon_T_Indoor.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_SpyMon_T_Indoor.Location = new System.Drawing.Point(126, 9);
            this.textBox_SpyMon_T_Indoor.Margin = new System.Windows.Forms.Padding(8);
            this.textBox_SpyMon_T_Indoor.Name = "textBox_SpyMon_T_Indoor";
            this.textBox_SpyMon_T_Indoor.ReadOnly = true;
            this.textBox_SpyMon_T_Indoor.Size = new System.Drawing.Size(63, 14);
            this.textBox_SpyMon_T_Indoor.TabIndex = 0;
            this.textBox_SpyMon_T_Indoor.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Label_SpyMon_T_Dis
            // 
            this.Label_SpyMon_T_Dis.AutoSize = true;
            this.Label_SpyMon_T_Dis.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Label_SpyMon_T_Dis.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_SpyMon_T_Dis.Location = new System.Drawing.Point(26, 195);
            this.Label_SpyMon_T_Dis.Margin = new System.Windows.Forms.Padding(25, 8, 0, 2);
            this.Label_SpyMon_T_Dis.Name = "Label_SpyMon_T_Dis";
            this.Label_SpyMon_T_Dis.Size = new System.Drawing.Size(58, 15);
            this.Label_SpyMon_T_Dis.TabIndex = 19;
            this.Label_SpyMon_T_Dis.Text = "Dischage";
            this.Label_SpyMon_T_Dis.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // textBox_SpyMon_T_Dis
            // 
            this.textBox_SpyMon_T_Dis.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_SpyMon_T_Dis.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_SpyMon_T_Dis.Location = new System.Drawing.Point(126, 195);
            this.textBox_SpyMon_T_Dis.Margin = new System.Windows.Forms.Padding(8);
            this.textBox_SpyMon_T_Dis.Name = "textBox_SpyMon_T_Dis";
            this.textBox_SpyMon_T_Dis.ReadOnly = true;
            this.textBox_SpyMon_T_Dis.Size = new System.Drawing.Size(63, 14);
            this.textBox_SpyMon_T_Dis.TabIndex = 20;
            this.textBox_SpyMon_T_Dis.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox_SpyMon_T_IPM
            // 
            this.textBox_SpyMon_T_IPM.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_SpyMon_T_IPM.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_SpyMon_T_IPM.Location = new System.Drawing.Point(126, 226);
            this.textBox_SpyMon_T_IPM.Margin = new System.Windows.Forms.Padding(8);
            this.textBox_SpyMon_T_IPM.Name = "textBox_SpyMon_T_IPM";
            this.textBox_SpyMon_T_IPM.ReadOnly = true;
            this.textBox_SpyMon_T_IPM.Size = new System.Drawing.Size(63, 14);
            this.textBox_SpyMon_T_IPM.TabIndex = 21;
            this.textBox_SpyMon_T_IPM.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Label_SpyMon_T_IPM
            // 
            this.Label_SpyMon_T_IPM.AutoSize = true;
            this.Label_SpyMon_T_IPM.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Label_SpyMon_T_IPM.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_SpyMon_T_IPM.Location = new System.Drawing.Point(41, 226);
            this.Label_SpyMon_T_IPM.Margin = new System.Windows.Forms.Padding(40, 8, 0, 8);
            this.Label_SpyMon_T_IPM.Name = "Label_SpyMon_T_IPM";
            this.Label_SpyMon_T_IPM.Size = new System.Drawing.Size(30, 14);
            this.Label_SpyMon_T_IPM.TabIndex = 18;
            this.Label_SpyMon_T_IPM.Text = "IPM";
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.tableLayoutPanel5);
            this.groupBox8.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox8.Location = new System.Drawing.Point(13, 14);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(212, 279);
            this.groupBox8.TabIndex = 1;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Operating State";
            // 
            // tableLayoutPanel5
            // 
            this.tableLayoutPanel5.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel5.ColumnCount = 2;
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 116F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 233F));
            this.tableLayoutPanel5.Controls.Add(this.textBox_SpyMon_ApparentW, 1, 5);
            this.tableLayoutPanel5.Controls.Add(this.textBox_SpyMon_Vac, 1, 4);
            this.tableLayoutPanel5.Controls.Add(this.textBox_SpyMon_Iac, 1, 3);
            this.tableLayoutPanel5.Controls.Add(this.textBox_SpyMon_VBus, 1, 2);
            this.tableLayoutPanel5.Controls.Add(this.textBox_SpyMon_RealFre, 1, 1);
            this.tableLayoutPanel5.Controls.Add(this.Label_SpyMon_VBus, 0, 2);
            this.tableLayoutPanel5.Controls.Add(this.Label_SpyMon_RealFre, 0, 1);
            this.tableLayoutPanel5.Controls.Add(this.Label_SpyMon_SetFre, 0, 0);
            this.tableLayoutPanel5.Controls.Add(this.Label_SpyMon_Iac, 0, 3);
            this.tableLayoutPanel5.Controls.Add(this.Label_SpyMon_Vac, 0, 4);
            this.tableLayoutPanel5.Controls.Add(this.Label_SpyMon_ApparentW, 0, 5);
            this.tableLayoutPanel5.Controls.Add(this.textBox_SpyMon_SetFre, 1, 0);
            this.tableLayoutPanel5.Controls.Add(this.Label_SpyMon_PFC_State, 0, 6);
            this.tableLayoutPanel5.Controls.Add(this.textBox_SpyMon_PFC_State, 1, 6);
            this.tableLayoutPanel5.Controls.Add(this.textBox_SpyMon_RelayState, 1, 7);
            this.tableLayoutPanel5.Controls.Add(this.Label_SpyMon_RelayState, 0, 7);
            this.tableLayoutPanel5.Location = new System.Drawing.Point(6, 28);
            this.tableLayoutPanel5.Name = "tableLayoutPanel5";
            this.tableLayoutPanel5.RowCount = 8;
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel5.Size = new System.Drawing.Size(200, 244);
            this.tableLayoutPanel5.TabIndex = 5;
            // 
            // textBox_SpyMon_ApparentW
            // 
            this.textBox_SpyMon_ApparentW.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_SpyMon_ApparentW.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_SpyMon_ApparentW.Location = new System.Drawing.Point(126, 164);
            this.textBox_SpyMon_ApparentW.Margin = new System.Windows.Forms.Padding(8);
            this.textBox_SpyMon_ApparentW.Name = "textBox_SpyMon_ApparentW";
            this.textBox_SpyMon_ApparentW.ReadOnly = true;
            this.textBox_SpyMon_ApparentW.Size = new System.Drawing.Size(63, 14);
            this.textBox_SpyMon_ApparentW.TabIndex = 17;
            this.textBox_SpyMon_ApparentW.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox_SpyMon_Vac
            // 
            this.textBox_SpyMon_Vac.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_SpyMon_Vac.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_SpyMon_Vac.Location = new System.Drawing.Point(126, 133);
            this.textBox_SpyMon_Vac.Margin = new System.Windows.Forms.Padding(8);
            this.textBox_SpyMon_Vac.Name = "textBox_SpyMon_Vac";
            this.textBox_SpyMon_Vac.ReadOnly = true;
            this.textBox_SpyMon_Vac.Size = new System.Drawing.Size(63, 14);
            this.textBox_SpyMon_Vac.TabIndex = 16;
            this.textBox_SpyMon_Vac.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox_SpyMon_Iac
            // 
            this.textBox_SpyMon_Iac.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_SpyMon_Iac.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_SpyMon_Iac.Location = new System.Drawing.Point(126, 102);
            this.textBox_SpyMon_Iac.Margin = new System.Windows.Forms.Padding(8);
            this.textBox_SpyMon_Iac.Name = "textBox_SpyMon_Iac";
            this.textBox_SpyMon_Iac.ReadOnly = true;
            this.textBox_SpyMon_Iac.Size = new System.Drawing.Size(63, 14);
            this.textBox_SpyMon_Iac.TabIndex = 15;
            this.textBox_SpyMon_Iac.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox_SpyMon_VBus
            // 
            this.textBox_SpyMon_VBus.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_SpyMon_VBus.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_SpyMon_VBus.Location = new System.Drawing.Point(126, 71);
            this.textBox_SpyMon_VBus.Margin = new System.Windows.Forms.Padding(8);
            this.textBox_SpyMon_VBus.Name = "textBox_SpyMon_VBus";
            this.textBox_SpyMon_VBus.ReadOnly = true;
            this.textBox_SpyMon_VBus.Size = new System.Drawing.Size(63, 14);
            this.textBox_SpyMon_VBus.TabIndex = 6;
            this.textBox_SpyMon_VBus.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox_SpyMon_RealFre
            // 
            this.textBox_SpyMon_RealFre.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_SpyMon_RealFre.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_SpyMon_RealFre.Location = new System.Drawing.Point(126, 40);
            this.textBox_SpyMon_RealFre.Margin = new System.Windows.Forms.Padding(8);
            this.textBox_SpyMon_RealFre.Name = "textBox_SpyMon_RealFre";
            this.textBox_SpyMon_RealFre.ReadOnly = true;
            this.textBox_SpyMon_RealFre.Size = new System.Drawing.Size(63, 14);
            this.textBox_SpyMon_RealFre.TabIndex = 7;
            this.textBox_SpyMon_RealFre.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Label_SpyMon_VBus
            // 
            this.Label_SpyMon_VBus.AutoSize = true;
            this.Label_SpyMon_VBus.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Label_SpyMon_VBus.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_SpyMon_VBus.Location = new System.Drawing.Point(21, 71);
            this.Label_SpyMon_VBus.Margin = new System.Windows.Forms.Padding(20, 8, 8, 8);
            this.Label_SpyMon_VBus.Name = "Label_SpyMon_VBus";
            this.Label_SpyMon_VBus.Size = new System.Drawing.Size(70, 14);
            this.Label_SpyMon_VBus.TabIndex = 13;
            this.Label_SpyMon_VBus.Text = "DC Bus (V)";
            // 
            // Label_SpyMon_RealFre
            // 
            this.Label_SpyMon_RealFre.AutoSize = true;
            this.Label_SpyMon_RealFre.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Label_SpyMon_RealFre.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_SpyMon_RealFre.Location = new System.Drawing.Point(13, 40);
            this.Label_SpyMon_RealFre.Margin = new System.Windows.Forms.Padding(12, 8, 0, 8);
            this.Label_SpyMon_RealFre.Name = "Label_SpyMon_RealFre";
            this.Label_SpyMon_RealFre.Size = new System.Drawing.Size(90, 14);
            this.Label_SpyMon_RealFre.TabIndex = 11;
            this.Label_SpyMon_RealFre.Text = "Real Fre (RPS)";
            // 
            // Label_SpyMon_SetFre
            // 
            this.Label_SpyMon_SetFre.AutoSize = true;
            this.Label_SpyMon_SetFre.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Label_SpyMon_SetFre.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_SpyMon_SetFre.Location = new System.Drawing.Point(13, 9);
            this.Label_SpyMon_SetFre.Margin = new System.Windows.Forms.Padding(12, 8, 8, 8);
            this.Label_SpyMon_SetFre.Name = "Label_SpyMon_SetFre";
            this.Label_SpyMon_SetFre.Size = new System.Drawing.Size(83, 14);
            this.Label_SpyMon_SetFre.TabIndex = 9;
            this.Label_SpyMon_SetFre.Text = "Set Fre (RPS)";
            this.Label_SpyMon_SetFre.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Label_SpyMon_Iac
            // 
            this.Label_SpyMon_Iac.AutoSize = true;
            this.Label_SpyMon_Iac.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Label_SpyMon_Iac.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_SpyMon_Iac.Location = new System.Drawing.Point(11, 102);
            this.Label_SpyMon_Iac.Margin = new System.Windows.Forms.Padding(10, 8, 0, 0);
            this.Label_SpyMon_Iac.Name = "Label_SpyMon_Iac";
            this.Label_SpyMon_Iac.Size = new System.Drawing.Size(93, 15);
            this.Label_SpyMon_Iac.TabIndex = 12;
            this.Label_SpyMon_Iac.Text = "AC Current (A)";
            // 
            // Label_SpyMon_Vac
            // 
            this.Label_SpyMon_Vac.AutoSize = true;
            this.Label_SpyMon_Vac.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Label_SpyMon_Vac.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_SpyMon_Vac.Location = new System.Drawing.Point(11, 133);
            this.Label_SpyMon_Vac.Margin = new System.Windows.Forms.Padding(10, 8, 0, 5);
            this.Label_SpyMon_Vac.Name = "Label_SpyMon_Vac";
            this.Label_SpyMon_Vac.Size = new System.Drawing.Size(90, 15);
            this.Label_SpyMon_Vac.TabIndex = 10;
            this.Label_SpyMon_Vac.Text = "AC Voltage (V)";
            // 
            // Label_SpyMon_ApparentW
            // 
            this.Label_SpyMon_ApparentW.AutoSize = true;
            this.Label_SpyMon_ApparentW.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Label_SpyMon_ApparentW.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_SpyMon_ApparentW.Location = new System.Drawing.Point(3, 164);
            this.Label_SpyMon_ApparentW.Margin = new System.Windows.Forms.Padding(2, 8, 0, 8);
            this.Label_SpyMon_ApparentW.Name = "Label_SpyMon_ApparentW";
            this.Label_SpyMon_ApparentW.Size = new System.Drawing.Size(111, 14);
            this.Label_SpyMon_ApparentW.TabIndex = 14;
            this.Label_SpyMon_ApparentW.Text = "Apparent Watt (W)";
            // 
            // textBox_SpyMon_SetFre
            // 
            this.textBox_SpyMon_SetFre.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_SpyMon_SetFre.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_SpyMon_SetFre.Location = new System.Drawing.Point(126, 9);
            this.textBox_SpyMon_SetFre.Margin = new System.Windows.Forms.Padding(8);
            this.textBox_SpyMon_SetFre.Name = "textBox_SpyMon_SetFre";
            this.textBox_SpyMon_SetFre.ReadOnly = true;
            this.textBox_SpyMon_SetFre.Size = new System.Drawing.Size(63, 14);
            this.textBox_SpyMon_SetFre.TabIndex = 0;
            this.textBox_SpyMon_SetFre.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Label_SpyMon_PFC_State
            // 
            this.Label_SpyMon_PFC_State.AutoSize = true;
            this.Label_SpyMon_PFC_State.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Label_SpyMon_PFC_State.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_SpyMon_PFC_State.Location = new System.Drawing.Point(26, 195);
            this.Label_SpyMon_PFC_State.Margin = new System.Windows.Forms.Padding(25, 8, 0, 8);
            this.Label_SpyMon_PFC_State.Name = "Label_SpyMon_PFC_State";
            this.Label_SpyMon_PFC_State.Size = new System.Drawing.Size(62, 14);
            this.Label_SpyMon_PFC_State.TabIndex = 19;
            this.Label_SpyMon_PFC_State.Text = "PFC State";
            this.Label_SpyMon_PFC_State.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // textBox_SpyMon_PFC_State
            // 
            this.textBox_SpyMon_PFC_State.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_SpyMon_PFC_State.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_SpyMon_PFC_State.Location = new System.Drawing.Point(126, 195);
            this.textBox_SpyMon_PFC_State.Margin = new System.Windows.Forms.Padding(8);
            this.textBox_SpyMon_PFC_State.Name = "textBox_SpyMon_PFC_State";
            this.textBox_SpyMon_PFC_State.ReadOnly = true;
            this.textBox_SpyMon_PFC_State.Size = new System.Drawing.Size(63, 14);
            this.textBox_SpyMon_PFC_State.TabIndex = 20;
            this.textBox_SpyMon_PFC_State.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox_SpyMon_RelayState
            // 
            this.textBox_SpyMon_RelayState.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_SpyMon_RelayState.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_SpyMon_RelayState.Location = new System.Drawing.Point(126, 226);
            this.textBox_SpyMon_RelayState.Margin = new System.Windows.Forms.Padding(8);
            this.textBox_SpyMon_RelayState.Name = "textBox_SpyMon_RelayState";
            this.textBox_SpyMon_RelayState.ReadOnly = true;
            this.textBox_SpyMon_RelayState.Size = new System.Drawing.Size(63, 14);
            this.textBox_SpyMon_RelayState.TabIndex = 21;
            this.textBox_SpyMon_RelayState.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Label_SpyMon_RelayState
            // 
            this.Label_SpyMon_RelayState.AutoSize = true;
            this.Label_SpyMon_RelayState.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Label_SpyMon_RelayState.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_SpyMon_RelayState.Location = new System.Drawing.Point(23, 226);
            this.Label_SpyMon_RelayState.Margin = new System.Windows.Forms.Padding(22, 8, 0, 8);
            this.Label_SpyMon_RelayState.Name = "Label_SpyMon_RelayState";
            this.Label_SpyMon_RelayState.Size = new System.Drawing.Size(69, 14);
            this.Label_SpyMon_RelayState.TabIndex = 18;
            this.Label_SpyMon_RelayState.Text = "Relay State";
            // 
            // button_COM_Scan
            // 
            this.button_COM_Scan.Font = new System.Drawing.Font("PMingLiU", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button_COM_Scan.Location = new System.Drawing.Point(907, 156);
            this.button_COM_Scan.Name = "button_COM_Scan";
            this.button_COM_Scan.Size = new System.Drawing.Size(80, 30);
            this.button_COM_Scan.TabIndex = 25;
            this.button_COM_Scan.Text = "COM Scan";
            this.button_COM_Scan.UseVisualStyleBackColor = true;
            this.button_COM_Scan.Click += new System.EventHandler(this.button_COM_Scan_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Label_COM_Port_State,
            this.toolStripProgressBar});
            this.statusStrip1.Location = new System.Drawing.Point(0, 636);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(995, 22);
            this.statusStrip1.TabIndex = 26;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // Label_COM_Port_State
            // 
            this.Label_COM_Port_State.Font = new System.Drawing.Font("Microsoft JhengHei", 9F, System.Drawing.FontStyle.Bold);
            this.Label_COM_Port_State.Name = "Label_COM_Port_State";
            this.Label_COM_Port_State.Size = new System.Drawing.Size(80, 17);
            this.Label_COM_Port_State.Text = "COM1 Close";
            // 
            // toolStripProgressBar
            // 
            this.toolStripProgressBar.Margin = new System.Windows.Forms.Padding(10, 3, 1, 3);
            this.toolStripProgressBar.Name = "toolStripProgressBar";
            this.toolStripProgressBar.Size = new System.Drawing.Size(100, 16);
            this.toolStripProgressBar.Step = 1;
            // 
            // SerialPortTimer100ms
            // 
            this.SerialPortTimer100ms.Enabled = true;
            this.SerialPortTimer100ms.Tick += new System.EventHandler(this.SerialPortReadTimer100ms_Tick);
            // 
            // timer_AutoSave
            // 
            this.timer_AutoSave.Enabled = true;
            this.timer_AutoSave.Interval = 120000;
            this.timer_AutoSave.Tick += new System.EventHandler(this.timer_AutoSave_Tick);
            // 
            // Tatung_Record
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(995, 658);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.button_COM_Scan);
            this.Controls.Add(this.TabControl_Page);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.ComboBox_Baud_Rate);
            this.Controls.Add(this.ComboBox_COM_Port);
            this.Controls.Add(this.button_COM_Switch);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "Tatung_Record";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.Text = "TT";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Tatung_Record_FormClosing);
            this.TabControl_Page.ResumeLayout(false);
            this.Command_TagPage.ResumeLayout(false);
            this.Command_TagPage.PerformLayout();
            this.groupBox13.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.SPD_NumUpDown)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.PFC_Menu.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.ControMenu_Group.ResumeLayout(false);
            this.AutoTest_Tagpage.ResumeLayout(false);
            this.AutoTest_Tagpage.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.COM2MCU_TagePage.ResumeLayout(false);
            this.COM2MCU_TagePage.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.tableLayoutPanel3.ResumeLayout(false);
            this.groupBox7.ResumeLayout(false);
            this.tableLayoutPanel4.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.Tab_ParaTuning.ResumeLayout(false);
            this.groupBox12.ResumeLayout(false);
            this.Monitor.ResumeLayout(false);
            this.groupBox11.ResumeLayout(false);
            this.tableLayoutPanel10.ResumeLayout(false);
            this.tableLayoutPanel10.PerformLayout();
            this.tableLayoutPanel9.ResumeLayout(false);
            this.tableLayoutPanel9.PerformLayout();
            this.tableLayoutPanel8.ResumeLayout(false);
            this.tableLayoutPanel8.PerformLayout();
            this.groupBox10.ResumeLayout(false);
            this.tableLayoutPanel7.ResumeLayout(false);
            this.tableLayoutPanel7.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            this.tableLayoutPanel6.ResumeLayout(false);
            this.tableLayoutPanel6.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.tableLayoutPanel5.ResumeLayout(false);
            this.tableLayoutPanel5.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.IO.Ports.SerialPort serialPort1;
        private System.Windows.Forms.Button button_2MCU_RX;
        private System.Windows.Forms.Button button_COM_Switch;
        private System.Windows.Forms.RichTextBox Command_Data_Send;
        private System.Windows.Forms.ComboBox ComboBox_COM_Port;
        private System.Windows.Forms.ComboBox ComboBox_Baud_Rate;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.RichTextBox richText_Display;
        private System.Windows.Forms.Button button_TextBoxClr;
        private System.Windows.Forms.Button button_2MCU_TX;
        private System.Windows.Forms.Button button_SendCMD;
        private System.Windows.Forms.TextBox File_Name;
        private System.Windows.Forms.Button button_CmprStartUp;
        private System.Windows.Forms.Button button_CmprStop;
        private System.Windows.Forms.Button AutoTest_Run_But;
        private System.Windows.Forms.Label AutoTest_ElapsedTime_Lebel;
        private System.Windows.Forms.TabControl TabControl_Page;
        private System.Windows.Forms.TabPage Command_TagPage;
        private System.Windows.Forms.TabPage AutoTest_Tagpage;
        private System.Windows.Forms.GroupBox ControMenu_Group;
        private System.Windows.Forms.Button button_Manual;
        private System.Windows.Forms.Button button_Auto;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox PFC_Menu;
        private System.Windows.Forms.Button button_PFC_Off;
        private System.Windows.Forms.Button button_PFC_On;
        private System.Windows.Forms.Button button_PFC_AutoOn;
        private System.Windows.Forms.Button button_PFC_AutoOff;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.CheckBox Char_Cmd_CheckBox;
        private System.Windows.Forms.Button AutoTest_CmdUpadte_But;
        private System.Windows.Forms.TextBox AutoTest_Period_TextBox;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.TextBox AutoTest_Time_TextBox8;
        private System.Windows.Forms.TextBox AutoTest_Time_TextBox7;
        private System.Windows.Forms.TextBox AutoTest_Time_TextBox6;
        private System.Windows.Forms.TextBox AutoTest_Time_TextBox5;
        private System.Windows.Forms.TextBox AutoTest_Time_TextBox4;
        private System.Windows.Forms.TextBox AutoTest_Time_TextBox3;
        private System.Windows.Forms.TextBox AutoTest_Time_TextBox2;
        private System.Windows.Forms.TextBox AutoTest_Time_TextBox1;
        private System.Windows.Forms.TextBox AutoTest_Cmd_textBox8;
        private System.Windows.Forms.TextBox AutoTest_Cmd_textBox7;
        private System.Windows.Forms.TextBox AutoTest_Cmd_textBox6;
        private System.Windows.Forms.TextBox AutoTest_Cmd_textBox5;
        private System.Windows.Forms.TextBox AutoTest_Cmd_textBox4;
        private System.Windows.Forms.TextBox AutoTest_Cmd_textBox3;
        private System.Windows.Forms.TextBox AutoTest_Cmd_textBox2;
        private System.Windows.Forms.TextBox AutoTest_Cmd_textBox1;
        private System.Windows.Forms.CheckBox AutoTest_Enable_ChkBox2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label AutoTest_Level1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.CheckBox AutoTest_Enable_ChkBox1;
        private System.Windows.Forms.CheckBox AutoTest_Enable_ChkBox3;
        private System.Windows.Forms.CheckBox AutoTest_Enable_ChkBox4;
        private System.Windows.Forms.CheckBox AutoTest_Enable_ChkBox5;
        private System.Windows.Forms.CheckBox AutoTest_Enable_ChkBox6;
        private System.Windows.Forms.CheckBox AutoTest_Enable_ChkBox7;
        private System.Windows.Forms.CheckBox AutoTest_Enable_ChkBox8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label AutoTest_ThisPeriod_Lebel;
        private System.Windows.Forms.Label AutoTest_NumOfTimes_Lebel;
        private System.Windows.Forms.TextBox AutoTest_Cmd_textBox10;
        private System.Windows.Forms.TextBox AutoTest_Time_TextBox10;
        private System.Windows.Forms.CheckBox AutoTest_Enable_ChkBox10;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox AutoTest_Time_TextBox9;
        private System.Windows.Forms.TextBox AutoTest_Cmd_textBox9;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.CheckBox AutoTest_Enable_ChkBox9;
        private System.Windows.Forms.Button AutoTest_Reset_But;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.CheckBox AutoTest_Polling_ChkBox8;
        private System.Windows.Forms.CheckBox AutoTest_Polling_ChkBox7;
        private System.Windows.Forms.CheckBox AutoTest_Polling_ChkBox6;
        private System.Windows.Forms.CheckBox AutoTest_Polling_ChkBox5;
        private System.Windows.Forms.CheckBox AutoTest_Polling_ChkBox4;
        private System.Windows.Forms.CheckBox AutoTest_Polling_ChkBox3;
        private System.Windows.Forms.CheckBox AutoTest_Polling_ChkBox2;
        private System.Windows.Forms.CheckBox AutoTest_Polling_ChkBox10;
        private System.Windows.Forms.CheckBox AutoTest_Polling_ChkBox9;
        private System.Windows.Forms.CheckBox AutoTest_Polling_ChkBox1;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.NumericUpDown SPD_NumUpDown;
        private System.Windows.Forms.Button button_SPD_Set;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TabPage COM2MCU_TagePage;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label COM2MCU_Level_Inf1_b0;
        private System.Windows.Forms.Label COM2MCU_Level_Inf1_b1;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label COM2MCU_Level_Inf1_b3;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label COM2MCU_Level_Inf2_b0;
        private System.Windows.Forms.Label COM2MCU_Level_Inf2_b4;
        private System.Windows.Forms.Label COM2MCU_Level_Inf2_b5;
        private System.Windows.Forms.Label COM2MCU_Level_Inf3_b5;
        private System.Windows.Forms.Label COM2MCU_Level_Inf3_b7;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label COM2MCU_Level_Inf3_b2;
        private System.Windows.Forms.Label COM2MCU_Level_Inf2_b1;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.Label COM2MCU_Level_Inf1_b2;
        private System.Windows.Forms.Label COM2MCU_Level_Inf1_b4;
        private System.Windows.Forms.Label COM2MCU_Level_Inf1_b5;
        private System.Windows.Forms.Label COM2MCU_Level_Inf1_b6;
        private System.Windows.Forms.Label COM2MCU_Level_Inf1_b7;
        private System.Windows.Forms.Label COM2MCU_Level_Inf2_b3;
        private System.Windows.Forms.Label COM2MCU_Level_Inf2_b2;
        private System.Windows.Forms.Label COM2MCU_Level_Inf2_b6;
        private System.Windows.Forms.Label COM2MCU_Level_Inf2_b7;
        private System.Windows.Forms.Label COM2MCU_Level_Inf3_b0;
        private System.Windows.Forms.Label COM2MCU_Level_Inf3_b1;
        private System.Windows.Forms.Label COM2MCU_Level_Inf3_b3;
        private System.Windows.Forms.Label COM2MCU_Level_Inf3_b4;
        private System.Windows.Forms.Label COM2MCU_Level_Inf3_b6;
        private System.Windows.Forms.Label COM2MCU_Level_TX_Tin;
        private System.Windows.Forms.Label COM2MCU_Level_TX_ErrCode;
        private System.Windows.Forms.Label COM2MCU_Level_TX_ClrErr;
        private System.Windows.Forms.Label COM2MCU_Level_TX_InputCur;
        private System.Windows.Forms.Label COM2MCU_Level_TX_RealFre;
        private System.Windows.Forms.Label COM2MCU_Level_TX_TarFre;
        private System.Windows.Forms.Label COM2MCU_Level_TX_DC4;
        private System.Windows.Forms.Label COM2MCU_Level_TX_DC3;
        private System.Windows.Forms.Label COM2MCU_Level_TX_DC2;
        private System.Windows.Forms.Label COM2MCU_Level_TX_DC1;
        private System.Windows.Forms.Label COM2MCU_Level_TX_Cmd;
        private System.Windows.Forms.Label COM2MCU_Level_RX_ClrErr;
        private System.Windows.Forms.Label COM2MCU_Level_RX_Cmd;
        private System.Windows.Forms.Label COM2MCU_Level_RX_FC1;
        private System.Windows.Forms.Label COM2MCU_Level_RX_FC2;
        private System.Windows.Forms.Label COM2MCU_Level_RX_FC3;
        private System.Windows.Forms.Label COM2MCU_Level_RX_FC4;
        private System.Windows.Forms.Label COM2MCU_Level_RX_TarFre;
        private System.Windows.Forms.Label COM2MCU_Level_RX_FreChange;
        private System.Windows.Forms.Label COM2MCU_Level_RX_CurRel;
        private System.Windows.Forms.Button button_COM_Scan;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel Label_COM_Port_State;
        private System.Windows.Forms.TabPage Tab_ParaTuning;
        private System.Windows.Forms.ListView ListView_ParaTuning;
        private System.Windows.Forms.Timer SerialPortTimer100ms;
        private System.Windows.Forms.TabPage Monitor;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel5;
        private System.Windows.Forms.TextBox textBox_SpyMon_ApparentW;
        private System.Windows.Forms.TextBox textBox_SpyMon_Vac;
        private System.Windows.Forms.TextBox textBox_SpyMon_Iac;
        private System.Windows.Forms.TextBox textBox_SpyMon_VBus;
        private System.Windows.Forms.TextBox textBox_SpyMon_RealFre;
        private System.Windows.Forms.Label Label_SpyMon_VBus;
        private System.Windows.Forms.Label Label_SpyMon_RealFre;
        private System.Windows.Forms.Label Label_SpyMon_SetFre;
        private System.Windows.Forms.Label Label_SpyMon_Iac;
        private System.Windows.Forms.Label Label_SpyMon_Vac;
        private System.Windows.Forms.Label Label_SpyMon_ApparentW;
        private System.Windows.Forms.TextBox textBox_SpyMon_SetFre;
        private System.Windows.Forms.Label Label_SpyMon_PFC_State;
        private System.Windows.Forms.TextBox textBox_SpyMon_PFC_State;
        private System.Windows.Forms.TextBox textBox_SpyMon_RelayState;
        private System.Windows.Forms.Label Label_SpyMon_RelayState;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel6;
        private System.Windows.Forms.TextBox textBox_SpyMon_T_Suc;
        private System.Windows.Forms.TextBox textBox_SpyMon_T_OutdoorEx;
        private System.Windows.Forms.TextBox textBox_SpyMon_T_Outdoor;
        private System.Windows.Forms.TextBox textBox_SpyMon_T_Set;
        private System.Windows.Forms.TextBox textBox_SpyMon_T_IndoorEx;
        private System.Windows.Forms.Label Label_SpyMon_T_Set;
        private System.Windows.Forms.Label Label_SpyMon_T_IndoorEx;
        private System.Windows.Forms.Label Label_SpyMon_T_Indoor;
        private System.Windows.Forms.Label Label_SpyMon_T_Outdoor;
        private System.Windows.Forms.Label Label_SpyMon_T_OutdoorEx;
        private System.Windows.Forms.Label Label_SpyMon_T_Suc;
        private System.Windows.Forms.TextBox textBox_SpyMon_T_Indoor;
        private System.Windows.Forms.Label Label_SpyMon_T_Dis;
        private System.Windows.Forms.TextBox textBox_SpyMon_T_Dis;
        private System.Windows.Forms.TextBox textBox_SpyMon_T_IPM;
        private System.Windows.Forms.Label Label_SpyMon_T_IPM;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel7;
        private System.Windows.Forms.TextBox textBox_SpyMon_WS_FS;
        private System.Windows.Forms.TextBox textBox_SpyMon_WS_SS;
        private System.Windows.Forms.TextBox textBox_SpyMon_WS_WS;
        private System.Windows.Forms.TextBox textBox_SpyMon_WS_WM;
        private System.Windows.Forms.Label Label_SpyMon_WS_WM;
        private System.Windows.Forms.Label Label_SpyMon_WS_Cmd;
        private System.Windows.Forms.Label Label_SpyMon_WS_WS;
        private System.Windows.Forms.Label Label_SpyMon_WS_SS;
        private System.Windows.Forms.Label Label_SpyMon_WS_FS;
        private System.Windows.Forms.TextBox textBox_SpyMon_WS_Cmd;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel8;
        private System.Windows.Forms.Label Label_SpyMon_Pro_LoseSPD;
        private System.Windows.Forms.Label Label_SpyMon_Pro_AmbientHot;
        private System.Windows.Forms.Label Label_SpyMon_Pro_UVW;
        private System.Windows.Forms.Label Label_SpyMon_Pro_ZeroSPD;
        private System.Windows.Forms.Label Label_SpyMon_Pro_FBK_Err;
        private System.Windows.Forms.Label Label_SpyMon_Pro_StartUp;
        private System.Windows.Forms.Label Label_SpyMon_Pro_IacOver;
        private System.Windows.Forms.Label Label_SpyMon_Pro_IPM_Hot;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel9;
        private System.Windows.Forms.Label Label_SpyMon_Pro_COM_Fail;
        private System.Windows.Forms.Label Label_SpyMon_Pro_VbusHigh;
        private System.Windows.Forms.Label Label_SpyMon_Pro_VbusLow;
        private System.Windows.Forms.Label Label_SpyMon_Pro_CompHot;
        private System.Windows.Forms.Label Label_SpyMon_Pro_Tamb;
        private System.Windows.Forms.Label Label_SpyMon_Pro_Tcon;
        private System.Windows.Forms.Label Label_SpyMon_Pro_Tdis;
        private System.Windows.Forms.Label Label_SpyMon_Pro_Tsuc;
        private System.Windows.Forms.Label Label_SpyMon_Pro_CurSenErr;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel10;
        private System.Windows.Forms.Label Label_SpyMon_Pro_VacLow;
        private System.Windows.Forms.Label Label_SpyMon_Pro_DC_Fan;
        private System.Windows.Forms.Label Label_SpyMon_Pro_IPM_Fault;
        private System.Windows.Forms.Label Label_SpyMon_Pro_VacHigh;
        private System.Windows.Forms.Label Label_SpyMon_Pro_IacLow;
        private System.Windows.Forms.Label Label_SpyMon_Pro_T_IPM;
        private System.Windows.Forms.Label Label_SpyMon_Pro_ConHot;
        private System.Windows.Forms.Label Label_SpyMon_Pro_SucHot;
        private System.Windows.Forms.TextBox textBox_SpyMon_RstTime;
        private System.Windows.Forms.Label Label_SpyMon_RstTime;
        private System.Windows.Forms.Timer TimerOneSecond;
        private System.Windows.Forms.Button button_PaTu_Download;
        private System.Windows.Forms.ToolStripProgressBar toolStripProgressBar;
        private System.Windows.Forms.Button button_PaTu_Upload;
        private System.Windows.Forms.Button button_PaTu_eFlashRead;
        private System.Windows.Forms.Button button_PaTu_eFlashWrite;
        private System.Windows.Forms.Timer timer_AutoSave;
        private System.Windows.Forms.Label Label_SpyMon_Pro_Motor3MinStop;
        private System.Windows.Forms.Button button_Save;
        private System.Windows.Forms.TextBox textBox_SpyMon_WS_MS;
        private System.Windows.Forms.Label Label_SpyMon_WS_MS;
        private System.Windows.Forms.Button button_OpenFolder;
        private System.Windows.Forms.Button button_OpenFile;
        private System.Windows.Forms.Button button_PaTu_SaveFile;
        private System.Windows.Forms.Button button_PaTu_OpenFile;
        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.Button button_PaTu_Update_MotoPara;
        private System.Windows.Forms.Button button_ThetaPrt;
        private System.Windows.Forms.Button button_SpeedPrt;
        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.Button button_SpeedSave;
        private System.Windows.Forms.Button button_RcdClr;
        private System.Windows.Forms.Button button_ThetaSave;
        private System.Windows.Forms.Button button_StartUpFolderOpen;
        private System.Windows.Forms.CheckBox AutoTest_Enable_ChkBox11;
        private System.Windows.Forms.CheckBox AutoTest_Enable_ChkBox12;
        private System.Windows.Forms.TextBox AutoTest_Time_TextBox11;
        private System.Windows.Forms.TextBox AutoTest_Time_TextBox12;
        private System.Windows.Forms.TextBox AutoTest_Cmd_textBox11;
        private System.Windows.Forms.TextBox AutoTest_Cmd_textBox12;
    }
}


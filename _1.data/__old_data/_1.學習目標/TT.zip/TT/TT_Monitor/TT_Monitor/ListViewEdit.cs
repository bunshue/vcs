﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Drawing;
namespace TT_Monitor
{
    class ListViewEdit
    {
        public ListView MyListView = null;
        private ListViewHitTestInfo hitinfo;
        private TextBox editbox = new TextBox();
        private ListViewHitTestInfo SelectedItemHitTestInf;
        public int ListViewIndicesSize { get; set; }
        public string Header(int index)
        {
            return MyListView.Columns[index].Text;            
        }
        public void ListView_ParaTuning_Ini()
        {
            // Create a new ListView control.
			//ListView listView2 = new ListView();
            MyListView.Bounds = new Rectangle(new Point(10, 10), new Size(591,550));
			// Set the view to show details.
            MyListView.View = View.Details;
			// Allow the user to edit item text.
            MyListView.LabelEdit = false;
			// Not allow the user to rearrange columns.
            MyListView.AllowColumnReorder = false;			
			// Select the item and subitems when selection is made.
            MyListView.FullRowSelect = false;
			// Display grid lines.
            MyListView.GridLines = true;
            //Add column header
            ColumnHeader header1, header2,header3, header4, header5;
            header1 = new ColumnHeader();
            header2 = new ColumnHeader();
            header3 = new ColumnHeader();
            header4 = new ColumnHeader();
            header5 = new ColumnHeader();
            header1.Text = "No.";
            header1.TextAlign = HorizontalAlignment.Center;
            header1.Width = 50;
            header2.Text = "Name";
            header2.TextAlign = HorizontalAlignment.Left;
            header2.Width = 160;
            header3.TextAlign = HorizontalAlignment.Center;
            header3.Text = "Decimal";
            header3.Width = 120;
            header4.TextAlign = HorizontalAlignment.Center;
            header4.Text = "Q24";
            header4.Width = 120;
            header5.TextAlign = HorizontalAlignment.Center;
            header5.Text = "Hexadecimal";
            header5.Width = 120;
            MyListView.Columns.Add(header1);
            MyListView.Columns.Add(header2);
            MyListView.Columns.Add(header3);
            MyListView.Columns.Add(header4);
            MyListView.Columns.Add(header5);
            #region
            string[] ListViewRowName = new string[] 
            {  
                "Ver"					
                ,"Date"					
                ,"Type"

                ,"Rs"
                ,"Ld"
                ,"Lq"
                ,"PolePair"

                ,"StartCurPID_P_1"
                ,"StartCurPID_P_2"
                ,"StartCurPID_P_3"
                ,"StartCurPID_P_4"
                ,"StartCurPID_P_5"

                ,"StartCurPID_I_1"
                ,"StartCurPID_I_2"
                ,"StartCurPID_I_3"
                ,"StartCurPID_I_4"
                ,"StartCurPID_I_5"

                ,"StartCurPID_D_1"
                ,"StartCurPID_D_2"
                ,"StartCurPID_D_3"
                ,"StartCurPID_D_4"
                ,"StartCurPID_D_5"

                ,"E0_StartUp_1"
                ,"E0_StartUp_2"

                ,"Kslide_StartUp_1"
                ,"Kslide_StartUp_2"

                ,"Kslf_StartUp_1"
                ,"Kslf_StartUp_2"

                ,"CUR_START_ST1"
                ,"CUR_START_ST2"

                ,"Count_StartUp_ST2_ADD"
                ,"Count_StartUp_ST3_ADD"
                ,"Count_StartUp_ST4_ADD1"
                ,"Count_StartUp_ST4_ADD2"

                ,"CUR_START_OFFSET"

                ,"StartSpdPID_P"
                ,"StartSpdPID_I"
                ,"StartSpdPID_D"

                ,"CurPID_KP_0"
                ,"CurPID_KP_1"
                ,"CurPID_KP_2"
                ,"CurPID_KP_3"
                ,"CurPID_KP_4"
                ,"CurPID_KP_5"

                ,"CurPID_KI_0"
                ,"CurPID_KI_1"
                ,"CurPID_KI_2"
                ,"CurPID_KI_3"
                ,"CurPID_KI_4"
                ,"CurPID_KI_5"

                ,"CurPID_KD_0"
                ,"CurPID_KD_1"
                ,"CurPID_KD_2"
                ,"CurPID_KD_3"
                ,"CurPID_KD_4"
                ,"CurPID_KD_5"

                ,"SpdPID_KP_0"
                ,"SpdPID_KP_1"
                ,"SpdPID_KP_2"
                ,"SpdPID_KP_3"
                ,"SpdPID_KP_4"
                ,"SpdPID_KP_5"

                ,"SpdPID_KI_0"
                ,"SpdPID_KI_1"
                ,"SpdPID_KI_2"
                ,"SpdPID_KI_3"
                ,"SpdPID_KI_4"
                ,"SpdPID_KI_5"

                ,"SpdPID_KD_0"
                ,"SpdPID_KD_1"
                ,"SpdPID_KD_2"
                ,"SpdPID_KD_3"
                ,"SpdPID_KD_4"
                ,"SpdPID_KD_5"

                ,"SPD_Interval0_H"
                ,"SPD_Interval1_H"
                ,"SPD_Interval2_H"
                ,"SPD_Interval3_H"
                ,"SPD_Interval4_H"

                ,"SPD_Interval1_L"
                ,"SPD_Interval2_L"
                ,"SPD_Interval3_L"
                ,"SPD_Interval4_L"
                ,"SPD_Interval5_L"

                ,"K_THETA0_MAX"
                ,"ISQ_Limit"
            };
            #endregion
            for (int i = 0; i < ListViewIndicesSize; i++)
            {
                string rowName ;
                if (i < ListViewRowName.Length)
                    rowName = ListViewRowName[i];
                else
                    rowName = "";
                string[] StringItem2 = { i.ToString(), rowName, "0.000000", "0000000000", "00000000" };
                ListViewItem itm = new ListViewItem(StringItem2);
                MyListView.Items.Add(itm);                
            }

            //Initial for ListView selected items can be changed
            editbox.Parent = MyListView;
            editbox.Hide();
            editbox.LostFocus += new EventHandler(editbox_LostFocus);            
            this.MyListView.MouseDoubleClick += new MouseEventHandler(MyListView_MouseEventHandler);
            MyListView.FullRowSelect = true;
        }
        //private string editboxTextTemp = "";
        private string editboxTextTemp { get; set; }
        private void MyListView_MouseEventHandler(object sender, MouseEventArgs e)
        {
            SelectedItemHitTestInf = MyListView.HitTest(e.X, e.Y);

            //If Select Number (Colume = 0), no response
            if (SelectedItemHitTestInf.Item.SubItems.IndexOf(SelectedItemHitTestInf.SubItem) != 0 && SelectedItemHitTestInf.Item.SubItems.IndexOf(SelectedItemHitTestInf.SubItem) != 1) 
            { 
                hitinfo = MyListView.HitTest(e.X, e.Y);
                editbox.Bounds = hitinfo.SubItem.Bounds;
                editbox.Text = hitinfo.SubItem.Text;
                // Save the text if input data is not reasonable, then restore it 
                editboxTextTemp = editbox.Text; 
                editbox.Focus();
                editbox.Show();   
            }               
        }
        private void editbox_LostFocus(object sender, EventArgs e)
        {            
            hitinfo.SubItem.Text = editbox.Text;
            editbox.Hide();
            editboxUpdataRowShow(SelectedItemHitTestInf.Item.Index, SelectedItemHitTestInf.Item.SubItems.IndexOf(SelectedItemHitTestInf.SubItem));            
        }
        private void editboxUpdataRowShow(int row, int col) 
        {
            double double_decimal = 0;
            #region Input data transform
            try
            {
                switch (col)
                {
                    case 2: //Decimal                    
                        double_decimal = Convert.ToDouble(editbox.Text);
                        break;
                    case 3: //Q24
                        double_decimal = Convert.ToDouble(editbox.Text) / 16777216.0;
                        if (double_decimal > 256) double_decimal = 256;
                        break;
                    case 4: //Heximal
                        double_decimal = Convert.ToInt64(editbox.Text, 16) / 16777216.0;
                        if (double_decimal > 256) double_decimal = 256;
                        break;
                    default:
                        break;
                }
                ListViewRowUpdata(row, double_decimal);

            }
            catch
            {
                
                switch (col)
                {
                    case 2: //Decimal                    
                        double_decimal = Convert.ToDouble(editboxTextTemp);
                        break;
                    case 3: //Q24
                        double_decimal = Convert.ToDouble(editboxTextTemp) / 16777216.0;
                        if (double_decimal > 256) double_decimal = 256;
                        break;
                    case 4: //Heximal
                        double_decimal = Convert.ToInt64(editboxTextTemp, 16) / 16777216.0;
                        if (double_decimal > 256) double_decimal = 256;
                        break;
                    default:
                        break;
                }
                ListViewRowUpdata(row, double_decimal);
                MessageBox.Show("Input Wrong Number.");
            }
            #endregion
        }
        public void ListViewRowUpdata(int row, double number)
        {
            Int64 int_q24 = 0;
            string string_decimal;
            string string_q24;
            string string_hex;

            string_decimal = number.ToString("0.000000");
            MyListView.Items[row].SubItems[2].Text = string_decimal;
            number *= 16777216.0; //2^24
            int_q24 = Convert.ToInt64(number);
            string_q24 = int_q24.ToString("0000000000");
            string_hex = int_q24.ToString("X8");
            MyListView.Items[row].SubItems[3].Text = string_q24;
            MyListView.Items[row].SubItems[4].Text = string_hex;
        }
        public void ListViewRowUpdata(int row, Int64 number)
        {
            double decNum = (double) number / 16777216.0;
            string string_decimal;
            string string_q24;
            string string_hex;

            string_decimal = decNum.ToString("0.000000");
            MyListView.Items[row].SubItems[2].Text = string_decimal;
            //number *= ; //2^24
           // int_q24 = Convert.ToInt64(number);
            string_q24 = number.ToString("0000000000");
            string_hex = number.ToString("X8");
            MyListView.Items[row].SubItems[3].Text = string_q24;
            MyListView.Items[row].SubItems[4].Text = string_hex;
        }
        public string ElementToString(int row, int col)
        {
            if (MyListView.Items[row].SubItems[col].Text != "")
                return MyListView.Items[row].SubItems[col].Text;
            else
                return "Null";
        }
        public void StringToElement(int row, int col, string setText)
        {
            MyListView.Items[row].SubItems[col].Text = setText;
        }
        public Int64 LiswtViewRowQ24Read(int row)
        {
            return Convert.ToInt64(MyListView.Items[row].SubItems[3].Text);
        }
    }

    /* Code Reference 
     * 
     * However, the code can be simplified by letting the listview be the textbox parent. Because hitinfo contains an reference to the actual listview cell object, it can be used direct if we share it between the two event handlers. No need to calculate the textbox position (C# code, details omitted):

        private ListViewHitTestInfo hitinfo;
        private TextBox editbox = new TextBox();

        public FormMain()
        {
            editbox.Parent = listView;
            editbox.Hide();
            editbox.LostFocus += new EventHandler(editbox_LostFocus);
            listView.MouseDoubleClick += new MouseEventHandler(listView_MouseDoubleClick);
            listView.FullRowSelect = true;
        }

        private void listView_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            hitinfo = listView.HitTest(e.X, e.Y);
            editbox.Bounds = hitinfo.SubItem.Bounds;
            editbox.Text = hitinfo.SubItem.Text;
            editbox.Focus();
            editbox.Show();
        }

        void editbox_LostFocus(object sender, EventArgs e)
        {
            hitinfo.SubItem.Text = editbox.Text;
            editbox.Hide();
        }
     * 
     */
}

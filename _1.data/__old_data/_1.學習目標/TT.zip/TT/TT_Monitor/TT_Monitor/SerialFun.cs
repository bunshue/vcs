﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.IO.Ports;

namespace TT_Monitor
{
    public partial class Tatung_Record
    {
        string[] COM_Ports_NameArr;
       

        private void Baud_Rate_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (!serialPort1.IsOpen) serialPort1.BaudRate = Convert.ToInt32(ComboBox_Baud_Rate.Text);
        }
        private void button_COM_Scan_Click(object sender, EventArgs e)
        {
            serialPort_AutoDetect();
        }        
        private void serialPort_AutoDetect()
        {
            string[] tempString = SerialPort.GetPortNames();
            Array.Resize(ref COM_Ports_NameArr, tempString.Length);
            tempString.CopyTo(COM_Ports_NameArr, 0);

            ComboBox_COM_Port.Items.Clear(); //Clear All items in Combobox

            foreach (string port in COM_Ports_NameArr)
                ComboBox_COM_Port.Items.Add(port);

            if (COM_Ports_NameArr.Length > 0)
                ComboBox_COM_Port.Text = COM_Ports_NameArr[0];
            ShowCOM_Port_State();          
        }
        private void ShowCOM_Port_State()
        {
            if (serialPort1.IsOpen)
            {
                Label_COM_Port_State.Text = serialPort1.PortName + " Open";
                Label_COM_Port_State.ForeColor = System.Drawing.Color.Blue;
            }
            else
            {
                if (COM_Ports_NameArr.Length == 0)
                    Label_COM_Port_State.Text = "No COM PORT Existed";
                else
                    Label_COM_Port_State.Text = ComboBox_COM_Port.Text + " Close";
                Label_COM_Port_State.ForeColor = System.Drawing.Color.Red;
            }
        }
       
        private void SpyStringSend(string SpyCmd)
        {
            if (serialPort1.IsOpen)
            {
                byte[] tmpByte = StringCmdToByteArr(SpyCmd);
                SerialSendByteArray(tmpByte, 0, tmpByte.Length);
            }
            else
                MessageBox.Show("Please Open COM Port");
        }
        private void SerialSendByteArray(byte[] SendByteArray, int offset, int end)
        {
            if (serialPort1.IsOpen)
                serialPort1.Write(SendByteArray, offset, end);
            else
            {
                //int tototallines = richtext_display.lines.length;
                //string lastline;
                //if (tototallines > 0)
                //{
                //    lastline = richtext_display.lines[tototallines - 1];
                //}
                //else
                //{
                //    lastline = "";
                //}
                //if (lastline != "please open com port")
                //    datashowonscreen("\nplease open com port");
                MessageBox.Show("Please Open COM Port");
            }

        }
        private byte CRC_Cal(Byte[] ByteCmd)
        {
            int tmpSum = 0;
            for (byte i = 0; i < ByteCmd.Length; i++)
                tmpSum += ByteCmd[i];
            tmpSum = (tmpSum ^ 0xFF) + 1;
            return (byte)tmpSum;
        }
        private string ConvertByteArrayToString(Byte[] ByteArr)
        {            
            System.Text.StringBuilder sb = new System.Text.StringBuilder();
            for (int i = 0; i < ByteArr.Length; i++)
                sb.Append(ByteArr[i].ToString("X2")).Append(" ");
            return (sb.ToString());
        }
        private byte[] StringCmdToByteArr(string StrTmp)
        {
            string[] seperators = { " " };
            string[] tmpStrSplit = StrTmp.Split(seperators, StringSplitOptions.RemoveEmptyEntries);
            byte[] tmpByte = new byte[10];
            for (int i = 0; (i < tmpStrSplit.Length && i < 9); i++)
            {
                try
                {
                    tmpByte[i] = Convert.ToByte(tmpStrSplit[i], 16);
                }
                catch (Exception err)
                {
                   // DataShowOnScreen(err.Message);
                    richText_Display.AppendText(err.Message);
                }
            }
            tmpByte[9] = CRC_Cal(tmpByte);
            return tmpByte;
        }
        private byte[] StringToByteArr(string StrTmp)
        {
            string[] seperators = { " " };
            string[] tmpStrSplit = StrTmp.Split(seperators, StringSplitOptions.RemoveEmptyEntries);
            byte[] tmpByte = new byte[tmpStrSplit.Length];
            for (int i = 0; i < tmpStrSplit.Length; i++)
            {
                try
                {
                    tmpByte[i] = Convert.ToByte(tmpStrSplit[i], 16);
                }
                catch (Exception err)
                {
                    richText_Display.AppendText(err.Message);
                }
            }
            return tmpByte;

        }
        private void ByteArrCmdSend(byte[] cmdArr)
        {
            if (cmdArr.Length <= 10)
            {
                byte[] tempByteArr = new byte[10];
                for (int i = 0; i < cmdArr.Length; i++)
                    tempByteArr[i] = cmdArr[i];
                tempByteArr[9] = CRC_Cal(tempByteArr);
                SerialSendByteArray(tempByteArr, 0, 10);                
            }
            else
            {
                Console.WriteLine("ByteArrCmdSend length is not correct.");
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.IO.Ports;

namespace TT_Monitor
{
    public partial class Tatung_Record
    {
        struct SpyMonitor_Struct 
        {
           public byte[] ByteArrRX ;
           public byte[] ByteArrTX;
           public bool UpdateRX;
           public int TX_CMD_InTurn;
        };

        private SpyMonitor_Struct SpyMonitor_Var;
        SpyRX Spy_RX = new SpyRX();
        private void SpyMonitorIni()
        {
            SpyMonitor_Var.ByteArrRX = new byte[10];
            SpyMonitor_Var.ByteArrTX = new byte[10];
            SpyMonitor_Var.UpdateRX = false;
            SpyMonitor_Var.TX_CMD_InTurn = 0;
            Spy_RX.SpyRX_Ini();
            byte[] Spy_RXcmdID = new byte[] {0x55};
            Spy_RX.SetCmdID(Spy_RXcmdID);
        }

        private void SpyMonitorRX()
        {
            
            

            byte[] byteArr = new byte[serialPort1.BytesToRead];
            serialPort1.Read(byteArr, 0, byteArr.Length);

            Spy_RX.InputByteArrToBuffer(byteArr);

            if (Spy_RX.IsGetPackage())
            {
                if (SpyMonitor_Var.UpdateRX == false)
                {
                    SpyMonitor_Var.ByteArrRX = Spy_RX.ReadData();
                    SpyMonitor_Var.UpdateRX = true;
                }
            }
        }
        private void SpyMonitorTX()
        {
            if (SpyMonitor_Var.UpdateRX)
            {
                SpyMonitor_Var.UpdateRX = false;
                SpyRX_DataToGUI();
                string stringSpy = DateTime.Now.ToString("HH:mm:ss   ");
            
                
                for (int i = 0; i < SpyMonitor_Var.ByteArrRX.Length; i++)
                    stringSpy += SpyMonitor_Var.ByteArrRX[i].ToString("X2") + " ";
                stringSpy += "\n";
                richText_Display.AppendText(stringSpy);
            }
            else
            {
                if (serialPort1.BytesToRead == 0) //Test
                    SpySendCMD();  
            }
                
            
        }
       
        private void SpyRX_DataToGUI()
        {
            if (SpyMonitor_Var.ByteArrRX[0] == 0x55)
            {
                switch (SpyMonitor_Var.ByteArrRX[1])
                {
                    //case 00:
                    //    break;
                    case 01:
                        SpyRX_DataToGUI_01();
                        break;
                    case 02:
                        SpyRX_DataToGUI_02();
                        break;
                    case 03:
                        SpyRX_DataToGUI_03();
                        break;
                    case 04:
                        SpyRX_DataToGUI_04();
                        break;
                    //case 05:
                    //    break;
                    //case 06:
                    //    break;
                    //case 07:
                    //    break;
                    case 08:
                        SpyRX_DataToGUI_08();
                        break;
                    case 09:
                        SpyRX_DataToGUI_09(); //55 09                      
                        break;
                    case 10:
                        SpyRX_DataToGUI_10(); //55 A0
                        break;
                    case 11:
                        SpyRX_DataToGUI_11(); //55 11
                        break;
                    //case 12:
                    //    break;
                    default:
                        break;

                }
            }
        }
      
        private void SpyRX_DataToGUI_01()
        {
            int temp = 0;

            temp = (int)SpyMonitor_Var.ByteArrRX[2];
            if (temp != 0xFF)
                textBox_SpyMon_T_Indoor.Text = temp.ToString();
            else
                textBox_SpyMon_T_Indoor.Text = "Null";

            temp = (int)SpyMonitor_Var.ByteArrRX[3];
            if (temp != 0xFF)
                textBox_SpyMon_T_IndoorEx.Text = temp.ToString();
            else
                textBox_SpyMon_T_IndoorEx.Text = "Null";

            temp = (int)SpyMonitor_Var.ByteArrRX[4];
            if (temp != 0xFF)
                textBox_SpyMon_T_Outdoor.Text = temp.ToString();
            else
                textBox_SpyMon_T_Outdoor.Text = "Null";

            temp = (int)SpyMonitor_Var.ByteArrRX[5];
            if (temp != 0xFF)
                textBox_SpyMon_T_OutdoorEx.Text = temp.ToString();
            else
                textBox_SpyMon_T_OutdoorEx.Text = "Null";
                
            temp = (int)SpyMonitor_Var.ByteArrRX[6];
            if (temp != 0xFF)
                textBox_SpyMon_T_Dis.Text = temp.ToString();
            else
                textBox_SpyMon_T_Dis.Text = "Null";

            temp = (int)SpyMonitor_Var.ByteArrRX[7];
            if (temp != 0xFF)
                textBox_SpyMon_T_Suc.Text = temp.ToString();
            else
                textBox_SpyMon_T_Suc.Text = "Null";

            temp = (int)SpyMonitor_Var.ByteArrRX[8];
            if (temp != 0xFF)
                textBox_SpyMon_T_Set.Text = temp.ToString();
            else
                textBox_SpyMon_T_Set.Text = "Null";
        }
 
        private void SpyRX_DataToGUI_02()
        {
            #region 
            //Uint32 rsvd1:7;
            //Uint32 Motor3MinStop:1 ;	//b24   0       //Motor 3 minutes stop protect
            //Uint32 Suctfailure:1;     //b23   7
            //Uint32 OutCoilfailure:1;  //b22	6        //Outdoor condensor temperature too high	
            //Uint32 IPMSensorErr:1;	//b21   5
            //Uint32 IACLow:1;          //b20	4	  // Iac too low (no refrigerant)
            //Uint32 VacTooHighError:1; //b19   3   	  // Vac 入電過低
            //Uint32 VacTooLowError:1;  //b18   2 	  // Vac 入電過低
            //Uint32 DCFanfailure:1;	//b17   1
            //Uint32 IPMFault:1;        //b16   0		  // 模組故障
	
            //Uint32 SensorError:4;     //b12~b15 	  //b12: Tamb, b13:Tcod, b14:Tdis, b15:Tsuc
            //Uint32 CompTopfailure:1;  //b11		  // 壓縮機頂部溫度保護
            //Uint32 CommuFault:1;      //b10		  // 通訊故障
            //Uint32 VBUSError:2;       //b8~b9 	  // b8:Vbus low, b9:Vbus high
	
            //Uint32 CurSensorErr:1;    //b7 		  // 電流採樣電路故障
            //Uint32 IPMTempOver:1;     //b6  		  // 模組溫度高(預留)
            //Uint32 IACOver:1;         //b5 		  // 室外機交流總電流過流
            //Uint32 CompProtect:3;     //b2~b4  	  // 壓縮機回饋故障 //1:StartupErr, 2:PhaseLose, 3:ZeroSpd,  4: LoseSpeed
            //Uint32 Outdoorfailure:1;  //b1 		  // outdoor too hot
            //Uint32 UVWDetect:1;       //b0 		  // check the lines of UVW		
            #endregion   
            Byte firstByte = SpyMonitor_Var.ByteArrRX[5];
            Byte secondByte = SpyMonitor_Var.ByteArrRX[4];
            Byte thirdByte = SpyMonitor_Var.ByteArrRX[3];
            Byte forthByte = SpyMonitor_Var.ByteArrRX[2];
            #region firstByte
            if ((firstByte & 0x01) > 0) //bit0 (0/32)
                Label_SpyMon_Pro_UVW.ForeColor = Color.Red;
            else
                Label_SpyMon_Pro_UVW.ForeColor = Color.DarkGray;

            if ((firstByte & 0x02) > 0) //bit1 (1/32)
                Label_SpyMon_Pro_AmbientHot.ForeColor = Color.Red;
            else
                Label_SpyMon_Pro_AmbientHot.ForeColor = Color.DarkGray;

            
            int tempInt = (firstByte & 0x1C)>>2;
                    
            if (tempInt == 4)  
                Label_SpyMon_Pro_LoseSPD.ForeColor = Color.Red;
            else
                Label_SpyMon_Pro_LoseSPD.ForeColor = Color.DarkGray;

            if (tempInt == 3)
                Label_SpyMon_Pro_ZeroSPD.ForeColor = Color.Red;
            else
                Label_SpyMon_Pro_ZeroSPD.ForeColor = Color.DarkGray;

            if (tempInt == 2)
                Label_SpyMon_Pro_FBK_Err.ForeColor = Color.Red;
            else
                Label_SpyMon_Pro_FBK_Err.ForeColor = Color.DarkGray;

            if (tempInt == 1)
                Label_SpyMon_Pro_StartUp.ForeColor = Color.Red;
            else
                Label_SpyMon_Pro_StartUp.ForeColor = Color.DarkGray;
                

            if ((firstByte & 0x20) > 0) //bit5 (5/32)
                Label_SpyMon_Pro_IacOver.ForeColor = Color.Red;              
            else
                Label_SpyMon_Pro_IacOver.ForeColor = Color.DarkGray;

            if ((firstByte & 0x40) > 0) //bit6 (6/32)
                Label_SpyMon_Pro_IPM_Hot.ForeColor = Color.Red;
            else
                Label_SpyMon_Pro_IPM_Hot.ForeColor = Color.DarkGray;

            if ((firstByte & 0x80) > 0) //bit7 (7/32)
                Label_SpyMon_Pro_CurSenErr.ForeColor = Color.Red;
            else
                Label_SpyMon_Pro_CurSenErr.ForeColor = Color.DarkGray;
            #endregion

            #region secondByte
            if ((secondByte & 0x01) > 0) //bit0 (8/32)
                Label_SpyMon_Pro_VbusLow.ForeColor  = Color.Red;
            else
                Label_SpyMon_Pro_VbusLow.ForeColor = Color.DarkGray;

            if ((secondByte & 0x02) > 0) //bit1 (9/32)
                Label_SpyMon_Pro_VbusHigh.ForeColor = Color.Red;
            else
                Label_SpyMon_Pro_VbusHigh.ForeColor = Color.DarkGray;

            if ((secondByte & 0x04) > 0) //bit2 (10/32)
                Label_SpyMon_Pro_COM_Fail.ForeColor = Color.Red;
            else
                Label_SpyMon_Pro_COM_Fail.ForeColor = Color.DarkGray;

            if ((secondByte & 0x08) > 0) //bit3 (11/32)
                Label_SpyMon_Pro_CompHot.ForeColor = Color.Red;
            else
                Label_SpyMon_Pro_CompHot.ForeColor = Color.DarkGray;

            if ((secondByte & 0x10) > 0) //bit4 (12/32)
                Label_SpyMon_Pro_Tamb.ForeColor = Color.Red;
            else
                Label_SpyMon_Pro_Tamb.ForeColor = Color.DarkGray;

            if ((secondByte & 0x20) > 0) //bit5 (13/32)
                Label_SpyMon_Pro_Tcon.ForeColor = Color.Red;
            else
                Label_SpyMon_Pro_Tcon.ForeColor = Color.DarkGray;

            if ((secondByte & 0x40) > 0) //bit6 (14/32)
                Label_SpyMon_Pro_Tdis.ForeColor = Color.Red;
            else
                Label_SpyMon_Pro_Tdis.ForeColor = Color.DarkGray;

            if ((secondByte & 0x80) > 0) //bit7 (15/32)
                Label_SpyMon_Pro_Tsuc.ForeColor = Color.Red;
            else
                Label_SpyMon_Pro_Tsuc.ForeColor = Color.DarkGray;
            #endregion thirdByte

            #region thirdByte
            if ((thirdByte & 0x01) > 0) //bit0 (16/32)
                Label_SpyMon_Pro_IPM_Fault.ForeColor = Color.Red;
            else
                Label_SpyMon_Pro_IPM_Fault.ForeColor = Color.DarkGray;

            if ((thirdByte & 0x02) > 0)//bit1 (17/32)
                Label_SpyMon_Pro_DC_Fan.ForeColor = Color.Red;
            else
                Label_SpyMon_Pro_DC_Fan.ForeColor = Color.DarkGray;

            if ((thirdByte & 0x04) > 0)//bit2 (18/32)
                Label_SpyMon_Pro_VacLow.ForeColor = Color.Red;
            else
                Label_SpyMon_Pro_VacLow.ForeColor = Color.DarkGray;

            if ((thirdByte & 0x08) > 0)//bit3 (19/32)
                Label_SpyMon_Pro_VacHigh.ForeColor= Color.Red;
            else
                Label_SpyMon_Pro_VacHigh.ForeColor = Color.DarkGray;

            if ((thirdByte & 0x10) > 0)//bit4 (20/32)
                Label_SpyMon_Pro_IacLow.ForeColor = Color.Red;
            else
                Label_SpyMon_Pro_IacLow.ForeColor = Color.DarkGray;

            if ((thirdByte & 0x20) > 0)//bit5 (21/32)
                Label_SpyMon_Pro_T_IPM.ForeColor = Color.Red;
            else
                Label_SpyMon_Pro_T_IPM.ForeColor = Color.DarkGray;

            if ((thirdByte & 0x40) > 0) //bit6 (22/32)
                Label_SpyMon_Pro_ConHot.ForeColor = Color.Red;
            else
                Label_SpyMon_Pro_ConHot.ForeColor = Color.DarkGray;

            if ((thirdByte & 0x80) > 0) //bit7 (23/32)
                Label_SpyMon_Pro_SucHot.ForeColor = Color.Red;
            else
                Label_SpyMon_Pro_SucHot.ForeColor = Color.DarkGray;

            
            
            #endregion

            #region forthByte
            if ((forthByte & 0x01)>0)
                Label_SpyMon_Pro_Motor3MinStop.ForeColor = Color.Red;
            else
                Label_SpyMon_Pro_Motor3MinStop.ForeColor = Color.DarkGray;
            #endregion

        }
     //   {SYS_IDLE, SYS_RESET, SYS_FAULT, SYS_PROTECT, SYS_RUN, SYS_OFF_DLY, SYS_POWERUP_DLY} SYS_STATE;
        string[] SYS_STATE = {"SYS_IDLE","SYS_PROTECT", "SYS_RUN","SYS_POWERUP_DLY" };
        //{OFF, REFRIGERATING, DEHUMIDIFIERING=3, HEATING=7, 
        //AUTO, TESTING, WARMUP,COOL_TESTING,HEAT_TESTING} WORK_MODE;   
        string[] WORK_MODE = { "OFF", "REFRIGERATING","" ,"DEHUMIDIFIERING","","",
                                "", "HEATING", "AUTO", "TESTING", "WARMUP","COOL_TESTING","HEAT_TESTING"};
        //{IDLE, STAR, RUN, OFFING, OFF} WORK_STATE;
        string[] WORK_STATE = { "IDLE", "STAR", "RUN", "OFFING", "OFF" };
        string[] FREQ_STATE = { "FREQ_STOP", "FORCE_ZERO", "FORBID_STAR", "FREQ_STAR", "FREQ_RISING", "FREQ_HOLDING", "FREQ_FALLING", 
                                  "FORCE_FALLING_80", "FORCE_FALLING_70", "FORCE_FALLING_BASE"};
        string[] MOTOR_STATE = {"MOTOR_STOP", "MOTOR_RUN" };
        private void SpyRX_DataToGUI_03()
        {
            int temp = 0;
            temp = (int)SpyMonitor_Var.ByteArrRX[2];
            textBox_SpyMon_WS_Cmd.Text = WORK_MODE[temp];
        }
        private void SpyRX_DataToGUI_04()
        {
            int temp = 0;
            try
            {
                temp = (int)SpyMonitor_Var.ByteArrRX[2];
                textBox_SpyMon_WS_SS.Text = SYS_STATE[temp];
                temp = (int)SpyMonitor_Var.ByteArrRX[3];
                textBox_SpyMon_WS_WM.Text = WORK_MODE[temp];
                //temp = (int)SpyMonitor_Var.ByteArrRX[4];
                temp = (int)SpyMonitor_Var.ByteArrRX[5];
                textBox_SpyMon_WS_WS.Text = WORK_MODE[temp];
                temp = (int)SpyMonitor_Var.ByteArrRX[6];
                textBox_SpyMon_WS_FS.Text = FREQ_STATE[temp];
                switch (FREQ_STATE[temp])
                {
                    case "FREQ_RISING":
                        textBox_SpyMon_WS_FS.ForeColor = Color.Blue;
                        break;
                    case "FREQ_FALLING":
                        textBox_SpyMon_WS_FS.ForeColor = Color.Red;
                        break;
                    case "FREQ_HOLDING":
                        textBox_SpyMon_WS_FS.ForeColor = Color.Green;
                        break;
                    default:
                        textBox_SpyMon_WS_FS.ForeColor = Color.Black;
                        break;

                }
            }
            catch
            {
                Console.WriteLine("SpyRX_DataToGUI_04() Error!");
            }
            
            

        }
        private void SpyRX_DataToGUI_08()
        {
            int temp = 0;
            temp = (SpyMonitor_Var.ByteArrRX[6])<<8;
            temp += SpyMonitor_Var.ByteArrRX[7];
            textBox_SpyMon_RstTime.Text = temp.ToString();
        }
        private void SpyRX_DataToGUI_09()
        {
            double temp = 0;
            double tempVac = 0;
            double tempIac = 0;
            temp = (double)SpyMonitor_Var.ByteArrRX[2] * 2;
            textBox_SpyMon_VBus.Text = temp.ToString();
            tempVac = (double)SpyMonitor_Var.ByteArrRX[3] * 2;
            textBox_SpyMon_Vac.Text = tempVac.ToString();
            tempIac = (double)SpyMonitor_Var.ByteArrRX[4] / 10;
            textBox_SpyMon_Iac.Text = tempIac.ToString("0.0");
            temp = tempVac * tempIac;
            textBox_SpyMon_ApparentW.Text = temp.ToString("0.0");
        }
        private void SpyRX_DataToGUI_10()
        {
            int temp = 0;
            temp = SpyMonitor_Var.ByteArrRX[2]/2;
            textBox_SpyMon_SetFre.Text = temp.ToString();
            temp = SpyMonitor_Var.ByteArrRX[3]/2;
            textBox_SpyMon_RealFre.Text = temp.ToString();            
            
            //temp = SpyMonitor_Var.ByteArrRX[4];
            
            temp = SpyMonitor_Var.ByteArrRX[5];
            if (temp > 1)
                textBox_SpyMon_PFC_State.Text = "On";
            else
                textBox_SpyMon_PFC_State.Text = "Off";

            //temp = SpyMonitor_Var.ByteArrRX[6];
            temp = SpyMonitor_Var.ByteArrRX[8];
            if (temp > 0)
                textBox_SpyMon_RelayState.Text = "On";
            else
                textBox_SpyMon_RelayState.Text = "Off";

        }
        private void SpyRX_DataToGUI_11()
        {
            int temp = 0;
            temp = SpyMonitor_Var.ByteArrRX[2];
            textBox_SpyMon_WS_MS.Text = MOTOR_STATE[temp];
            temp = SpyMonitor_Var.ByteArrRX[8];
            textBox_SpyMon_T_IPM.Text = temp.ToString();
        }

        //Not all commands from 0 to 12 are used
        private int[] SpyCMdArr = new int[] { 1,2,3,4,8,9,10,11};
        private int SpyCMdCnt = 0;
        private void SpySendCMD()
        {
            SpyMonitor_Var.ByteArrTX[0] = 0xAA;
            SpyMonitor_Var.ByteArrTX[1] = 0x10;
            SpyMonitor_Var.ByteArrTX[2] = (byte)SpyMonitor_Var.TX_CMD_InTurn;

            for (int i = 3; i < SpyMonitor_Var.ByteArrTX.Length; i++)
                SpyMonitor_Var.ByteArrTX[i] = 0;
            ByteArrCmdSend(SpyMonitor_Var.ByteArrTX);          

            if (++SpyCMdCnt >= SpyCMdArr.Length) SpyCMdCnt = 0;
                SpyMonitor_Var.TX_CMD_InTurn = SpyCMdArr[SpyCMdCnt];
        }
      
    }


}
﻿using System;
using System.Windows.Forms;
using Plot;
using System.Collections.Generic;
namespace TT_Monitor
{
    public partial class Tatung_Record
    {
        //Variables for AutoTest
        private byte[][] AutoTest_Cmd = new byte[10][];
        private int[] AutoTest_SendTime = new int[12];
        private int AutoTestCmdSelect = 0;
        private int AutoTestCmdPolling = 0;
        private int AutoTestElaspedTime = 0;
        private int AutoTestTimeAfterLastPeriod = 0;
        private int AutoTestPeriod = 0;
        private int AutoTestTimes = 0;

        private void AutoTest_SendCMD()
        {
            int i = 1, N = 0, t = 0;
            t = AutoTestElaspedTime % AutoTestPeriod;
           

            for (; N < 10; N++)
            {
                //Check this step is selected
                if ((AutoTestCmdSelect & i) > 0) 
                {
                    //Asking Polling or just send one time each period
                    if ((AutoTestCmdPolling & i) > 0)
                    {
                        if ((t % AutoTest_SendTime[N]) == 0)
                        {
                            SerialSendByteArray(AutoTest_Cmd[N], 0, AutoTest_Cmd[N].Length);
                        }
                    }
                    else
                    {
                        if (t == AutoTest_SendTime[N])
                        {
                            SerialSendByteArray(AutoTest_Cmd[N], 0, AutoTest_Cmd[N].Length);
                        }
                    }

                }
                i <<= 1;
            }

            if ((AutoTestCmdSelect & (1 << 10)) > 0)
            {
                if (t == AutoTest_SendTime[10])
                {
                    richText_Display.Clear();
                    SpyStringSend(CMD_StartupSpdPrt);
                }

                if (t == (AutoTest_SendTime[10] + 5))
                {
                    
                    TextFileWrite tFW = new TextFileWrite();
                    tFW.FolderName = StartUpSaveFolderName;
                    tFW.FileName = "Stage_Speed_Current." + DateTime.Now.ToString("MMdd.HH.mm") + ".txt";
                    tFW.FileClear();
                    startUpRcdSave(tFW);
                    richText_Display.Clear();
                    PlotStartup startup = new PlotStartup();
                    startup.RcdFilePath = tFW.FilePath; // Path.Combine(Directory.GetCurrentDirectory(), "IntArray.txt");
                    startup.X_Max = 1000;
                    startup.X_Min = 0;
                    startup.Y_Max = 350; //Speed(RPS)
                    startup.Y_Min = 0;
                    startup.Y2_Max = 50; //Current
                    startup.Y2_Min = 0;
                    startup.Show();
                    startup.SavePic();
                    startup.Close();
                    
                }

            }
            if ((AutoTestCmdSelect & (1 << 11)) > 0)
            {
                if (t == AutoTest_SendTime[11])
                {
                    richText_Display.Clear();
                    SpyStringSend(CMD_StartupThetaPrt);
                }

                if (t == (AutoTest_SendTime[11] + 10))
                {

                    TextFileWrite tFW = new TextFileWrite();
                    tFW.FolderName = StartUpSaveFolderName;
                    tFW.FileName = "Theta." + DateTime.Now.ToString("MMdd.HH.mm") + ".txt";
                    tFW.FileClear();
                    thetaSave(tFW);

                    richText_Display.Clear();

                    PlotTheta thetaPlot = new PlotTheta();

                    thetaPlot.RcdFilePath = tFW.FilePath;
                    thetaPlot.X_Min = 1800;
                    thetaPlot.X_Max = 2800;
                    thetaPlot.Y_Min = 0;
                    thetaPlot.Y_Max = 360;

                    thetaPlot.Show();
                    thetaPlot.SavePic();
                    thetaPlot.Close();

                }

            }


        }
        private void AutoTest_Reset_But_Click(object sender, EventArgs e)
        {
            AutoTestResetTimeShow();
        }
        private void AutoTestResetTimeShow()
        {

            string tempString;
            TimerOneSecond.Enabled = false;
            AutoTestElaspedTime = 0;
            AutoTestPeriod = Convert.ToInt16(AutoTest_Period_TextBox.Text);
            AutoTestTimes = 0;
            AutoTestTimeAfterLastPeriod = 0;
            AutoTest_NumOfTimes_Lebel.Text = "0";
            AutoTest_Run_But.Text = "Run";
            AutoTest_ElapsedTime_Lebel.Text = "00:00:00";

            tempString = SecToHMS(AutoTestElaspedTime) + " ~ " + SecToHMS(AutoTestPeriod * (AutoTestTimes + 1));
            AutoTest_ThisPeriod_Lebel.Text = tempString;
            AutoTest_CmdUpdate();

        }
        private void AutoTest_Run_But_Click(object sender, EventArgs e)
        {
            if (TimerOneSecond.Enabled == true)
            {
                TimerOneSecond.Enabled = false;
                AutoTest_Run_But.Text = "Run";
            }
            else
            {
                TimerOneSecond.Enabled = true;
                AutoTest_Run_But.Text = "Pause";
                AutoTestPeriod = Convert.ToInt16(AutoTest_Period_TextBox.Text);
                AutoTest_SendCMD();
            }

        }
        private string SecToHMS(int timeSec)
        {
            string tempString;
            int temp = 0;
            temp = timeSec / 3600;
            tempString = temp.ToString("d2") + ":";
            temp = (timeSec % 3600) / 60;
            tempString += temp.ToString("d2") + ":";
            temp = timeSec % 60;
            tempString += temp.ToString("d2");
            return tempString;
        }
        private void OneSecondTimer_Tick(object sender, EventArgs e)
        {
            AutoTestElaspedTime++;
            AutoTestTimeAfterLastPeriod++;
            AutoTest_ElapsedTime_Lebel.Text = SecToHMS(AutoTestElaspedTime);
            AutoTest_SendCMD();

            if (AutoTestTimeAfterLastPeriod >= AutoTestPeriod)
            {
                string tempString;
                AutoTestTimes++;
                AutoTestTimeAfterLastPeriod=0;
                AutoTest_NumOfTimes_Lebel.Text = Convert.ToString(AutoTestTimes);
                tempString = SecToHMS(AutoTestPeriod * AutoTestTimes) + " ~ " + SecToHMS(AutoTestPeriod * (AutoTestTimes + 1));
                AutoTest_ThisPeriod_Lebel.Text = tempString;
                Console.Beep();
            }
        }
        private void AutoTest_CmdUpadte_But_Click(object sender, EventArgs e)
        {
            AutoTest_CmdUpdate();
            AutoTestResetTimeShow();
        }
        private void AutoTest_CmdUpdate()
        {

            AutoTestCmdSelect = 0;
            AutoTestPeriod = Convert.ToInt16(AutoTest_Period_TextBox.Text);
            if (AutoTestPeriod <= 0)
            {
                MessageBox.Show("The Period musts be positive number.");
                AutoTestPeriod = 10000; //To prevent nothing happen
            }
            if (AutoTest_Enable_ChkBox1.Checked == true)
            {
                AutoTestCmdSelect |= 1 << 0;
                if (AutoTest_Polling_ChkBox1.Checked == true) AutoTestCmdPolling |= 1 << 0;
                AutoTest_Cmd[0] = StringCmdToByteArr(AutoTest_Cmd_textBox1.Text);
                AutoTest_Cmd_textBox1.Text = ConvertByteArrayToString(AutoTest_Cmd[0]);
                AutoTest_SendTime[0] = Convert.ToInt16(AutoTest_Time_TextBox1.Text);
            }
            if (AutoTest_Enable_ChkBox2.Checked == true)
            {
                AutoTestCmdSelect |= 1 << 1;
                if (AutoTest_Polling_ChkBox2.Checked == true) AutoTestCmdPolling |= 1 << 1;
                AutoTest_Cmd[1] = StringCmdToByteArr(AutoTest_Cmd_textBox2.Text);
                AutoTest_Cmd_textBox2.Text = ConvertByteArrayToString(AutoTest_Cmd[1]);
                AutoTest_SendTime[1] = Convert.ToInt16(AutoTest_Time_TextBox2.Text);
            }
            if (AutoTest_Enable_ChkBox3.Checked == true)
            {
                AutoTestCmdSelect |= 1 << 2;
                if (AutoTest_Polling_ChkBox3.Checked == true) AutoTestCmdPolling |= 1 << 2;
                AutoTest_Cmd[2] = StringCmdToByteArr(AutoTest_Cmd_textBox3.Text);
                AutoTest_Cmd_textBox3.Text = ConvertByteArrayToString(AutoTest_Cmd[2]);
                AutoTest_SendTime[2] = Convert.ToInt16(AutoTest_Time_TextBox3.Text);
            }
            if (AutoTest_Enable_ChkBox4.Checked == true)
            {
                AutoTestCmdSelect |= 1 << 3;
                if (AutoTest_Polling_ChkBox4.Checked == true) AutoTestCmdPolling |= 1 << 3;
                AutoTest_Cmd[3] = StringCmdToByteArr(AutoTest_Cmd_textBox4.Text);
                AutoTest_Cmd_textBox4.Text = ConvertByteArrayToString(AutoTest_Cmd[3]);
                AutoTest_SendTime[3] = Convert.ToInt16(AutoTest_Time_TextBox4.Text);
            }
            if (AutoTest_Enable_ChkBox5.Checked == true)
            {
                AutoTestCmdSelect |= 1 << 4;
                if (AutoTest_Polling_ChkBox5.Checked == true) AutoTestCmdPolling |= 1 << 4;
                AutoTest_Cmd[4] = StringCmdToByteArr(AutoTest_Cmd_textBox5.Text);
                AutoTest_Cmd_textBox5.Text = ConvertByteArrayToString(AutoTest_Cmd[4]);
                AutoTest_SendTime[4] = Convert.ToInt16(AutoTest_Time_TextBox5.Text);
            }
            if (AutoTest_Enable_ChkBox6.Checked == true)
            {
                AutoTestCmdSelect |= 1 << 5;
                if (AutoTest_Polling_ChkBox6.Checked == true) AutoTestCmdPolling |= 1 << 5;
                AutoTest_Cmd[5] = StringCmdToByteArr(AutoTest_Cmd_textBox6.Text);
                AutoTest_Cmd_textBox6.Text = ConvertByteArrayToString(AutoTest_Cmd[5]);
                AutoTest_SendTime[5] = Convert.ToInt16(AutoTest_Time_TextBox6.Text);
            }
            if (AutoTest_Enable_ChkBox7.Checked == true)
            {
                AutoTestCmdSelect |= 1 << 6;
                if (AutoTest_Polling_ChkBox7.Checked == true) AutoTestCmdPolling |= 1 << 6;
                AutoTest_Cmd[6] = StringCmdToByteArr(AutoTest_Cmd_textBox7.Text);
                AutoTest_Cmd_textBox7.Text = ConvertByteArrayToString(AutoTest_Cmd[6]);
                AutoTest_SendTime[6] = Convert.ToInt16(AutoTest_Time_TextBox7.Text);
            }
            if (AutoTest_Enable_ChkBox8.Checked == true)
            {
                AutoTestCmdSelect |= 1 << 7;
                if (AutoTest_Polling_ChkBox8.Checked == true) AutoTestCmdPolling |= 1 << 7;
                AutoTest_Cmd[7] = StringCmdToByteArr(AutoTest_Cmd_textBox8.Text);
                AutoTest_Cmd_textBox8.Text = ConvertByteArrayToString(AutoTest_Cmd[7]);
                AutoTest_SendTime[7] = Convert.ToInt16(AutoTest_Time_TextBox8.Text);
            }
            if (AutoTest_Enable_ChkBox9.Checked == true)
            {
                AutoTestCmdSelect |= 1 << 8;
                if (AutoTest_Polling_ChkBox9.Checked == true) AutoTestCmdPolling |= 1 << 8;
                AutoTest_Cmd[8] = StringCmdToByteArr(AutoTest_Cmd_textBox9.Text);
                AutoTest_Cmd_textBox9.Text = ConvertByteArrayToString(AutoTest_Cmd[8]);
                AutoTest_SendTime[8] = Convert.ToInt16(AutoTest_Time_TextBox9.Text);
            }
            if (AutoTest_Enable_ChkBox10.Checked == true)
            {
                AutoTestCmdSelect |= 1 << 9;
                if (AutoTest_Polling_ChkBox10.Checked == true) AutoTestCmdPolling |= 1 << 9;
                AutoTest_Cmd[9] = StringCmdToByteArr(AutoTest_Cmd_textBox10.Text);
                AutoTest_Cmd_textBox10.Text = ConvertByteArrayToString(AutoTest_Cmd[9]);
                AutoTest_SendTime[9] = Convert.ToInt16(AutoTest_Time_TextBox10.Text);
            }
            //StartUp(Is, ω) Record
            if (AutoTest_Enable_ChkBox11.Checked == true)
            {
                AutoTestCmdSelect |= 1 << 10;
                AutoTest_SendTime[10] = Convert.ToInt16(AutoTest_Time_TextBox11.Text);
            }
            if (AutoTest_Enable_ChkBox12.Checked == true)
            {
                AutoTestCmdSelect |= 1 << 11;
                AutoTest_SendTime[11] = Convert.ToInt16(AutoTest_Time_TextBox12.Text);
            }


        }
    }
}
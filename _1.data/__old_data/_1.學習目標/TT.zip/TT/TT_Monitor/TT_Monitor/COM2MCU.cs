﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.IO.Ports;

namespace TT_Monitor
{
    /*
    class COM2MCU 
    {
        private byte GetFlag;
        private byte Index;
        private byte[] DataArr;
       // private byte[] Buffer;
        private int WDT;

        public void COM2MCU_Ini(byte GetFlag, byte Index, int WDT, byte[] DataArr)
        {
            this.GetFlag = GetFlag;
            this.Index = Index;
            this.WDT = WDT;
            this.DataArr = DataArr;
        }
        public bool GetPackage() 
        {
            if (GetFlag > 0)
                return true;
            else
                return false;
        }
        public void PackageCollect(byte [] BytesReceive)
        {
            for (int i = 0; i < BytesReceive.Length; i++)
            {
                /// if GetFlag is not cleared, it means the data had not been processed.
                /// Return and do not change the data that is a correct package.
                if ( GetFlag > 0) return;

                switch (Index)
                {
                    case 0:
                        if (BytesReceive[i] == 0x00 || BytesReceive[i] == 0x01)
                        {
                            DataArr[0] = BytesReceive[i];
                            Index = 1;
                        }
                        else
                            Index = 0;
                        break;
                    case 1:
                        if (BytesReceive[i] == 0x01 || BytesReceive[i] == 0x00)
                        {
                            DataArr[1] = BytesReceive[i];
                            Index = 2;
                        }
                        else
                            Index = 0;
                        break;
                    case 2:
                        if ((BytesReceive[i] == 0x00) || (BytesReceive[i] == 0x10) || 
                            (BytesReceive[i] == 0x11) || (BytesReceive[i] == 0x40) || 
                            (BytesReceive[i] == 0x41) || (BytesReceive[i] == 0x51))
                        {
                            DataArr[2] = BytesReceive[i];
                            Index = 3;
                        }
                        else
                            Index = 0;
                        break;
                    case 3:
                        DataArr[3] = BytesReceive[i];
                        Index = 4;
                        break;
                    default:
                        DataArr[Index] = BytesReceive[i];
                        if ((Index >= DataArr[3] + 5) || Index == (DataArr.Length))
                        {
                            //if (DataArr[DataArr[3] + 5] == CRC_Cal(DataArr))
                            if (true)
                            {
                                GetFlag = 1;
                                Index = 0;
                            }
                            else
                                Index = 0;
                        }
                        else
                            Index++;
                        break;
                }

            }

        }
        private byte CRC_Cal(byte[] ByteArr)
        {        
            byte temp = 0;
            byte CRC_temp = 0;
            for (; temp < (ByteArr[3] + 5); temp++)
                CRC_temp += ByteArr[temp];
            CRC_temp ^= 0xFF;
            CRC_temp++;
            return CRC_temp;
        }
        public bool WatchDogTimerAddAndCheck(int CheckTime)
        { 
            WDT++;
            if (WDT > CheckTime) return true;
            else return false;
        }

    }
    */
    public partial class Tatung_Record
    {

        struct COM2MCU_Struct
        {
            // "GetFlag" will be rose if it get a complete package.
            // After the data had been read, "GetFlag" needs to be cleard.
            public byte GetFlag;

            // Record the index of the receive package
            public byte DataIndex;

            // The maximum amounts of data is 9 bytes
            // After reading the data from array, the array has to be cleared.
            public byte[] Data;
            public byte[] Buffer;
        };
        private COM2MCU_Struct COM2MCU_Var;
        private int COM2MCU_ConnectCheck; //bit0:check RX, bit1:check TX
        private TextFileWrite COM2MCU_tFW = new TextFileWrite();
        private void COM2MCU_Var_Ini()
        {
            COM2MCU_Var.GetFlag = 0;
            COM2MCU_Var.DataIndex = 0;
            COM2MCU_Var.Data = new byte[30];

            if (COM2MCU_Var.Buffer != null)
            { 
               for (int i = 0; i < COM2MCU_Var.Buffer.Length; i++)
                COM2MCU_Var.Buffer[i] = 0;
            } 
            COM2MCU_ConnectCheck = 0; // if MCU does not send the code, then PC send the request command.
            
            //SaveFile Initial
            COM2MCU_tFW.FolderName = "Record";
            COM2MCU_tFW.FileName = File_Name.Text;

        }
        private void COM2MCU_RX_TX_Deal()
        {
          //  string stringTmp = serialPort1.ReadExisting(); //test
           // byte[]  ArrTmp = StringToByteArr(stringTmp);

            COM2MCU_Var.Buffer = new byte[serialPort1.BytesToRead];
            serialPort1.Read(COM2MCU_Var.Buffer, 0, COM2MCU_Var.Buffer.Length);
            for (int i = 0; i < COM2MCU_Var.Buffer.Length; i++)           
            COM_WithMaster_ByteDeal(COM2MCU_Var.Buffer[i]);

            if (COM2MCU_Var.GetFlag > 0)
            {                
                COM2MCU_Var.GetFlag = 0;
                byte[] tempByte = new byte[Convert.ToInt16(COM2MCU_Var.Data[3] + 6)];
                for (int i = 0; i < tempByte.Length; i++) tempByte[i] = COM2MCU_Var.Data[i];
                //DataShowOnScreen(DateTime.Now.ToString("\nHH:mm ss "));
                string stringSave = DateTime.Now.ToString("HH:mm:ss   ");

                if (COM2MCU_Var.Data[0] == 0x00) //Get Receive Package
                {
                    COM2MCU_ConnectCheck |= 1;
                    stringSave += "R ";
                    RX_FromMaster_ShowUpdate(tempByte);
                }
                else
                {
                    COM2MCU_ConnectCheck |= 2;
                    stringSave += "T ";
                    TX_FromMaster_ShowUpdate(tempByte);
                }
               // DataShowOnScreen(ConvertByteArrayToString(tempByte));
                stringSave += ConvertByteArrayToString(tempByte);
                StreamSaveQ.Enqueue(stringSave);
            }
            
        }
        private void TX_FromMaster_ShowUpdate(byte[] TX_DataArr)
        {
            #region
            Label[] LabelArr_COM2MCU_TX_Inf1 = new Label[8];
            LabelArr_COM2MCU_TX_Inf1[0] = COM2MCU_Level_Inf1_b0;
            LabelArr_COM2MCU_TX_Inf1[1] = COM2MCU_Level_Inf1_b1;
            LabelArr_COM2MCU_TX_Inf1[2] = COM2MCU_Level_Inf1_b2;
            LabelArr_COM2MCU_TX_Inf1[3] = COM2MCU_Level_Inf1_b3;
            LabelArr_COM2MCU_TX_Inf1[4] = COM2MCU_Level_Inf1_b4;
            LabelArr_COM2MCU_TX_Inf1[5] = COM2MCU_Level_Inf1_b5;
            LabelArr_COM2MCU_TX_Inf1[6] = COM2MCU_Level_Inf1_b6;
            LabelArr_COM2MCU_TX_Inf1[7] = COM2MCU_Level_Inf1_b7;

            Label[] LabelArr_COM2MCU_TX_Inf2 = new Label[8];
            LabelArr_COM2MCU_TX_Inf2[0] = COM2MCU_Level_Inf2_b0;
            LabelArr_COM2MCU_TX_Inf2[1] = COM2MCU_Level_Inf2_b1;
            LabelArr_COM2MCU_TX_Inf2[2] = COM2MCU_Level_Inf2_b2;
            LabelArr_COM2MCU_TX_Inf2[3] = COM2MCU_Level_Inf2_b3;
            LabelArr_COM2MCU_TX_Inf2[4] = COM2MCU_Level_Inf2_b4;
            LabelArr_COM2MCU_TX_Inf2[5] = COM2MCU_Level_Inf2_b5;
            LabelArr_COM2MCU_TX_Inf2[6] = COM2MCU_Level_Inf2_b6;
            LabelArr_COM2MCU_TX_Inf2[7] = COM2MCU_Level_Inf2_b7;

            Label[] LabelArr_COM2MCU_TX_Inf3 = new Label[8];
            LabelArr_COM2MCU_TX_Inf3[0] = COM2MCU_Level_Inf3_b0;
            LabelArr_COM2MCU_TX_Inf3[1] = COM2MCU_Level_Inf3_b1;
            LabelArr_COM2MCU_TX_Inf3[2] = COM2MCU_Level_Inf3_b2;
            LabelArr_COM2MCU_TX_Inf3[3] = COM2MCU_Level_Inf3_b3;
            LabelArr_COM2MCU_TX_Inf3[4] = COM2MCU_Level_Inf3_b4;
            LabelArr_COM2MCU_TX_Inf3[5] = COM2MCU_Level_Inf3_b5;
            LabelArr_COM2MCU_TX_Inf3[6] = COM2MCU_Level_Inf3_b6;
            LabelArr_COM2MCU_TX_Inf3[7] = COM2MCU_Level_Inf3_b7;
            #endregion
           
            COM2MCU_Level_TX_Cmd.Text = string.Format("{0:X2}", TX_DataArr[2]);
            try
            {
                #region
                switch (TX_DataArr[2])
                {
                    case 0x00:
                        COM2MCU_Level_TX_DC1.Text = string.Format("{0:X2}", TX_DataArr[4]);
                        COM2MCU_Level_TX_DC2.Text = string.Format("{0:X2}", TX_DataArr[5]);
                        COM2MCU_Level_TX_DC3.Text = string.Format("{0:X2}", TX_DataArr[6]);
                        COM2MCU_Level_TX_DC4.Text = string.Format("{0:X2}", TX_DataArr[7]);
                        break;
                    case 0x10:
                        double tempDouble = 0;
                        tempDouble = Convert.ToDouble(TX_DataArr[4]) * 0.6;
                        COM2MCU_Level_TX_TarFre.Text = tempDouble.ToString("#0.0");
                        tempDouble = Convert.ToDouble(TX_DataArr[5]) * 0.6;
                        COM2MCU_Level_TX_RealFre.Text = tempDouble.ToString("#0.0");
                        tempDouble = Convert.ToDouble(TX_DataArr[6]) / 10;
                        COM2MCU_Level_TX_InputCur.Text = tempDouble.ToString("#0.0");
                        COM2MCU_Level_TX_ErrCode.Text = string.Format("{0:X2}", TX_DataArr[7]);
                        tempDouble = Convert.ToDouble(TX_DataArr[8]);
                        if ((TX_DataArr[11] & 0x20) == 0) //Termperature conversion rule: R8 = Tin * 2  +108 => Tin = (R8-108)/2
                        {
                            tempDouble = (tempDouble - 108) / 2;
                        }
                        else //R8 = Tin*2 -32 => Tin = (R8 + 32) /2
                        {
                            tempDouble = (tempDouble + 32) / 2;
                        }
                        COM2MCU_Level_TX_Tin.Text = tempDouble.ToString("#0.0");

                        // Information1
                        for (int i = 0, N = 1; i < LabelArr_COM2MCU_TX_Inf1.Length; i++)
                        {
                            if ((TX_DataArr[9] & N) > 0) LabelArr_COM2MCU_TX_Inf1[i].ForeColor = Color.ForestGreen;
                            else LabelArr_COM2MCU_TX_Inf1[i].ForeColor = Color.Black;
                            N <<= 1;
                        }
                        // Information2                 
                        for (int i = 0, N = 1; i < LabelArr_COM2MCU_TX_Inf1.Length; i++)
                        {
                            if ((TX_DataArr[10] & N) > 0) LabelArr_COM2MCU_TX_Inf2[i].ForeColor = Color.ForestGreen;
                            else LabelArr_COM2MCU_TX_Inf2[i].ForeColor = Color.Black;
                            N <<= 1;
                        }
                        // Information3
                        for (int i = 0, N = 1; i < LabelArr_COM2MCU_TX_Inf1.Length; i++)
                        {
                            if ((TX_DataArr[11] & N) > 0) LabelArr_COM2MCU_TX_Inf3[i].ForeColor = Color.ForestGreen;
                            else LabelArr_COM2MCU_TX_Inf3[i].ForeColor = Color.Black;
                            N <<= 1;
                        }

                        break;
                    case 0x40:
                    case 0x41:
                        COM2MCU_Level_TX_ClrErr.Text = string.Format("{00:X2}", TX_DataArr[4]);
                        break;
                    default:
                        break;
                }
                #endregion
            }
            catch(Exception err)
            {
                MessageBox.Show(err.ToString());
            }
           

        }
        private void RX_FromMaster_ShowUpdate(byte[] RX_DataArr)
        {

            COM2MCU_Level_RX_Cmd.Text = string.Format("{0:X2}", RX_DataArr[2]);

            try
            {
                #region
                switch (RX_DataArr[2])
                {
                    case 0x00:
                        COM2MCU_Level_RX_FC1.Text = string.Format("{0:X2}", RX_DataArr[4]);
                        COM2MCU_Level_RX_FC2.Text = string.Format("{0:X2}", RX_DataArr[5]);
                        COM2MCU_Level_RX_FC3.Text = string.Format("{0:X2}", RX_DataArr[6]);
                        COM2MCU_Level_RX_FC4.Text = string.Format("{0:X2}", RX_DataArr[7]);
                        break;
                    case 0x10:
                        double tempDouble = 0;
                        tempDouble = Convert.ToDouble(RX_DataArr[4]) * 0.6;
                        COM2MCU_Level_RX_TarFre.Text = tempDouble.ToString("#0.0");
                        tempDouble = Convert.ToDouble(RX_DataArr[5]) / 6;
                        COM2MCU_Level_RX_FreChange.Text = tempDouble.ToString("#0.0");
                        tempDouble = Convert.ToDouble(RX_DataArr[6]) / 10;
                        COM2MCU_Level_RX_CurRel.Text = tempDouble.ToString("#0.0");
                        break;
                    case 0x40:
                    case 0x41:
                        COM2MCU_Level_RX_ClrErr.Text = string.Format("{0:X2}", RX_DataArr[4]);
                        break;
                    default:
                        break;

                }
                #endregion
            }
            catch (Exception err)
            {
                MessageBox.Show(err.ToString());
            }
           
        }
        private void COM_WithMaster_ByteDeal(byte GetByte)
        {

            /// if GetFlag is not cleared, it means the data had not been processed.
            /// Return and do not change the data that is a correct package.
            if (COM2MCU_Var.GetFlag > 0)
                return;
           

                switch (COM2MCU_Var.DataIndex)
                {
                    case 0:
                        if (GetByte == 0x00 || GetByte == 0x01)
                        {
                            COM2MCU_Var.Data[0] = GetByte;
                            COM2MCU_Var.DataIndex = 1;
                        }
                        else
                            COM2MCU_Var.DataIndex = 0;
                        break;
                    case 1:
                        if (GetByte == 0x01 || GetByte == 0x00)
                        {
                            COM2MCU_Var.Data[1] = GetByte;
                            COM2MCU_Var.DataIndex = 2;
                        }
                        else
                            COM2MCU_Var.DataIndex = 0;
                        break;
                    case 2:
                        if ((GetByte == 0x00) || (GetByte == 0x10) || (GetByte == 0x11) || (GetByte == 0x40) || (GetByte == 0x41) || (GetByte == 0x51))
                        {
                            COM2MCU_Var.Data[2] = GetByte;
                            COM2MCU_Var.DataIndex = 3;
                        }
                        else
                            COM2MCU_Var.DataIndex = 0;
                        break;
                    case 3:
                        COM2MCU_Var.Data[3] = GetByte;
                        COM2MCU_Var.DataIndex = 4;
                        break;
                    default:
                        if (COM2MCU_Var.DataIndex < (COM2MCU_Var.Data.Length - 1))
                            COM2MCU_Var.Data[COM2MCU_Var.DataIndex] = GetByte;
                        if (COM2MCU_Var.DataIndex >= (COM2MCU_Var.Data[3] + 5) || COM2MCU_Var.DataIndex >= (COM2MCU_Var.Data.Length))
                        {

                            if ((COM2MCU_Var.Data[3] + 5)<=COM2MCU_Var.Data.Length && COM2MCU_Var.Data[COM2MCU_Var.Data[3] + 5] == COM_WithMasterCRC(COM2MCU_Var.Data))
                            // if (true)
                            {
                                COM2MCU_Var.GetFlag = 1;
                                COM2MCU_Var.DataIndex = 0;
                            }
                            else
                                COM2MCU_Var.DataIndex = 0;
                        }
                        else
                            COM2MCU_Var.DataIndex++;
                        break;
                }

        }
        private byte COM_WithMasterCRC(byte[] Arr)
        {

            byte temp = 0;
            byte CRC_temp = 0;
            
            if (Arr[0]==0 && Arr[1] == 0 )
            {
                temp = Arr[4];
                temp++;
                return temp; // return fake CRC (Arr[3]+1)
            }
            else
            {
                for (; temp < (Arr[3] + 5) && temp < Arr.Length; temp++)
                    CRC_temp += Arr[temp];
                CRC_temp ^= 0xFF;
                CRC_temp++;
                return CRC_temp;
            }
            

        }


        Queue StreamSaveQ = new Queue();
        private void button_Save_Click(object sender, EventArgs e)
        {
            StringQueueSave(StreamSaveQ);
        }
        private void StringQueueSave(Queue SaveQ)
        {
            while (SaveQ.Count > 0)
            {
                COM2MCU_tFW.StringAppendToFile(SaveQ.Dequeue().ToString());
            }           
        }
        private void timer_AutoSave_Tick(object sender, EventArgs e)
        {
            StringQueueSave(StreamSaveQ);
        }
        private void button_OpenFolder_Click(object sender, EventArgs e)
        {
            COM2MCU_tFW.FolderOpen();
        }
        private void button_OpenFile_Click(object sender, EventArgs e)
        {          
            COM2MCU_tFW.FileOpen();
        }

     

    }
}

﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.IO.Ports;
using System.Threading;
namespace TT_Monitor
{
    public partial class Tatung_Record
    {
        private byte[][] ParaByteData = new byte [512][];
        private int ParaDownloadCnt = 0;
        private int ParaDownloadTimerOut = 0;
        SpyRX PaTuRX = new SpyRX();
        ListViewEdit ListViewParaTuning = new ListViewEdit();

        private void ParaTuingIni()
        {
            ListViewParaTuning.MyListView = ListView_ParaTuning;
            ListViewParaTuning.ListViewIndicesSize = 512;
            ListViewParaTuning.ListView_ParaTuning_Ini();
            this.Tab_ParaTuning.Controls.Add(ListView_ParaTuning);
            ParaByteData = new byte[512][];
            PaTuRX.SpyRX_Ini();
            byte[] PaTuRX_ID = new byte[] {0x55, 0xF1};
            PaTuRX.SetCmdID(PaTuRX_ID);

            toolStripProgressBar.Minimum = 0;
            toolStripProgressBar.Maximum = 512;
        }

        private enum PaTuCase
        { DownloadPara, UploadPara,Compare, Idle };

        private PaTuCase PaTuState = PaTuCase.Idle;

        private void ParaTuningMain()
        {
            switch (PaTuState)
            { 
                case PaTuCase.DownloadPara:
                    if(isParaDonloadTimeOut() )
                    {
                        PaTuState = PaTuCase.Idle;
                        MessageBox.Show("Time Out.\nPlease Download again.");
                    }
 
                    if (serialPort1.BytesToRead > 0)
                        ParaTuningDownload();
                    break;
                case PaTuCase.UploadPara:
                        ParaTuningUpload();
                    break;
                case PaTuCase.Compare:
                    if (isParaDonloadTimeOut())
                    {
                        PaTuState = PaTuCase.Idle;
                        MessageBox.Show("Time Out.\nPlease Download again.");
                    }
                    else
                        ParaTuningCompare();
                    break;
                default:
                    break;
            
            }
            
        }

        private bool isParaDonloadTimeOut()
        {
            if (ParaDownloadTimerOut > 0)
            {
                ParaDownloadTimerOut--;
                return false;
            }
            else
                return true;

        }
  
        private void ParaBufferIni()
        {
            ParaDownloadTimerOut = 20;
            ParaDownloadCnt = 0;           
           
            ParaByteData = new byte[512][];
            for (int i = 0; i < ParaByteData.Length; i++)
                ParaByteData[i] = new byte[10];
        }
        private void button_PaTu_Upload_Click(object sender, EventArgs e)
        {
            PaTuState = PaTuCase.UploadPara;
        }
        private void button_PaTu_eFlashRead_Click(object sender, EventArgs e)
        {
            SpyStringSend(CMD_eFlashRead);
        }
        private void button_PaTu_eFlashWrite_Click(object sender, EventArgs e)
        {
            SpyStringSend(CMD_eFlashWrite);
        }
        private void button_PaTu_Download_Click(object sender, EventArgs e)
        {
            PaTuState = PaTuCase.DownloadPara;
            SpyStringSend(CMD_eFlashDownload);
            ParaBufferIni();
        }
        
        private void button_PaTu_Update_MotoPara_Click(object sender, EventArgs e)
        {
            SpyStringSend(CMD_eFlashUpdateMotoPara);
        }
        private void button_PaTu_OpenFile_Click(object sender, EventArgs e)
        {
            OpenFileDialog oFD = new OpenFileDialog();
            oFD.InitialDirectory = Directory.GetCurrentDirectory();
            oFD.Filter = "txt files (*.txt)|*.txt|All files (*.*)|*.*";
            oFD.Title = "Open File";
            
            if (oFD.ShowDialog() == DialogResult.OK)
            {
                TextFileRead tFR = new TextFileRead();
                tFR.FilePath = oFD.FileName;
                tFR.ReadTextToStringArray();
                char[] seperator = new Char[] { ' ', ',', ':', '\t' };
               
                for (int i = 1; i < tFR.StringArray.Length; i++)
                {
                    string[] tmpStrSplit = tFR.StringArray[i].Split(seperator,StringSplitOptions.RemoveEmptyEntries);

                    //No.
                    ListViewParaTuning.StringToElement(i - 1, 0, tmpStrSplit[0]);
                    //Name
                    ListViewParaTuning.StringToElement(i - 1, 1, tmpStrSplit[1]);
                    //Q24 (Update statistics by Q24)
                    ListViewParaTuning.ListViewRowUpdata(i - 1, Convert.ToInt64(tmpStrSplit[3]));
                }
            }
            else
            {
                Console.WriteLine("Open File Fail.");
            }
        }

        //Button Save Click Function
        private void button_PaTu_SaveFile_Click(object sender, EventArgs e)
        {
            SaveFileDialog sFd = new SaveFileDialog();
            sFd.InitialDirectory = Directory.GetCurrentDirectory();
            sFd.Filter = "txt files (*.txt)|*.txt|All files (*.*)|*.*";
            sFd.Title = "Parameters Save";
            sFd.FileName = "TuningParameter.txt";
            sFd.ShowDialog();
            if (sFd.FileName != "")
            {
                using (StreamWriter sw = File.CreateText(sFd.FileName))
                {
                    // Print Header 
                    string header = "";
                    header = String.Format("{0,3}", ListViewParaTuning.Header(0)) + " ";
                    header += String.Format("{0,23}", ListViewParaTuning.Header(1)) + " ";
                    header += String.Format("{0,9}", ListViewParaTuning.Header(2)) + " ";
                    header += String.Format("{0,10}", ListViewParaTuning.Header(3)) + " ";
                    header += String.Format("{0,11}", ListViewParaTuning.Header(4));
                    sw.WriteLine(header);

                    //Print Data
                    for (int i = 0; i < ListViewParaTuning.ListViewIndicesSize; i++)
                    {
                        string saveString = "";
                        saveString  = String.Format("{0,3}", ListViewParaTuning.ElementToString(i, 0)) + " ";
                        saveString += String.Format("{0,23}", ListViewParaTuning.ElementToString(i, 1)) + " ";
                        saveString += String.Format("{0,9}", ListViewParaTuning.ElementToString(i, 2)) + " ";
                        saveString += String.Format("{0,10}", ListViewParaTuning.ElementToString(i, 3)) + " ";
                        saveString += String.Format("{0,11}", ListViewParaTuning.ElementToString(i, 4)) ;
                        sw.WriteLine(saveString);                       
                    }
                }
             //   sw.Close();
            }
        }
        private void ParaTuningDownload()
        {
            if (ParaTuningRxCollectIsFinished())
            { 
                ParaTuningListViewUpdata();
                PaTuState = PaTuCase.Idle;
                MessageBox.Show("Download Finished!");
            }

        }
        private void ParaTuningCompare()
        {
            if (ParaTuningRxCollectIsFinished())
            {
                int ErrCollect = 0;
                Int64 NumBuffer = 0;
                Int64 NumListView = 0;

                for (int i = 0; i < 512; i++)
                {
                    NumBuffer = ParaTuningBufferIndexLookup(i);
                    NumListView = ListViewParaTuning.LiswtViewRowQ24Read(i);
                    if (NumBuffer != NumListView)
                        ErrCollect++;                    
                }
                PaTuState = PaTuCase.Idle;

                if (ErrCollect == 0)
                    MessageBox.Show("Correct");
                else
                    MessageBox.Show("Error");
            }
            
        }
        private bool ParaTuningRxCollectIsFinished()
        {
            byte[] byteReadArr = new byte[serialPort1.BytesToRead];
            serialPort1.Read(byteReadArr, 0, byteReadArr.Length);

            for (int ByteDealedCnt = 0; (ByteDealedCnt < byteReadArr.Length); ByteDealedCnt++)
            {
                byte[] tempByte = new byte[1];
                tempByte[0] = byteReadArr[ByteDealedCnt];
                PaTuRX.InputByteArrToBuffer(tempByte);

                if (PaTuRX.IsGetPackage())
                {
                    byte[] tempArr = new byte[10];
                    tempArr = PaTuRX.ReadData();
                    int index = Convert.ToInt16(tempArr[3]) << 8;
                    index += Convert.ToInt16(tempArr[4]);

                    if (index < ParaByteData.Length)
                    { 
                        ParaByteData[index] = new byte[10];
                        for (int b = 0; b < 10; b++)
                            ParaByteData[index][b] = tempArr[b];

                        toolStripProgressBar.Value = ParaDownloadCnt;
                        ParaDownloadCnt++;
                    }                    
                 }
            }
            if (ParaDownloadCnt == 512)                
                return true;
            else
                return false;
        }
        private void ParaTuningUpload()
        {
            //Turn off the timer of Serial Port until all data is uploaded
            SerialPortTimer100ms.Enabled = false; 

            //Windows Forms forbids to operate until all data is uploaded
           
            Int64 Q24Num = 0;
            byte[] uploadCmdByteArr = new byte[10];
            uploadCmdByteArr[0] = 0xAA;
            uploadCmdByteArr[1] = 0xF0;
            uploadCmdByteArr[2] = 0x02;
            for (int i = 0; i < 512; i++)
            {
                uploadCmdByteArr[3] = Convert.ToByte(i >> 8);
                uploadCmdByteArr[4] = Convert.ToByte(i & 0xFF);

                Q24Num = ListViewParaTuning.LiswtViewRowQ24Read(i);
                
                uploadCmdByteArr[5] = Convert.ToByte((Q24Num & 0xFF000000) >> 24); //2^24
                uploadCmdByteArr[6] = Convert.ToByte((Q24Num & 0xFF0000) >> 16); //2^16
                uploadCmdByteArr[7] = Convert.ToByte((Q24Num & 0xFF00) >> 8); //2^8
                uploadCmdByteArr[8] = Convert.ToByte(Q24Num & 0xFF);
                ByteArrCmdSend(uploadCmdByteArr);
                toolStripProgressBar.Value = i;
                Thread.Sleep(5); 
            }
           //  MessageBox.Show("Upload Finished!");

            //Turn on the timer of Serial Port 
            SerialPortTimer100ms.Enabled = true;
            Thread.Sleep(1); 
            PaTuState = PaTuCase.Compare;
            SpyStringSend(CMD_eFlashDownload);
            ParaBufferIni();
        }
        private void ParaTuningListViewUpdata()
        {         
            for (int i = 0; i < 512 ; i ++ )
                ListViewParaTuning.ListViewRowUpdata(i, ParaTuningBufferIndexLookup(i));
        }
        
        private Int64 ParaTuningBufferIndexLookup(int index)
        {
            Int64 NumQ24 = 0;
            NumQ24  = Convert.ToInt64(ParaByteData[index][5]) << 24;
            NumQ24 += Convert.ToInt64(ParaByteData[index][6]) << 16;
            NumQ24 += Convert.ToInt64(ParaByteData[index][7]) << 8;
            NumQ24 += Convert.ToInt64(ParaByteData[index][8]);
            return NumQ24;
        }
    }
}
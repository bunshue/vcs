﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.IO.Ports;
using System.Threading;
using Plot;

namespace TT_Monitor
{
    public partial class Tatung_Record : Form
    {
      

        private string DataShowString;
        // private string SendDataString = "04 0A 32 32";
        private int OldTabControlSeletct = 0;
        private byte[] bufferData;
       
       
        private string FileSaveNameText = "TT2MCU." + DateTime.Now.ToString("MM.dd.HH.mm") +".txt";
        public Tatung_Record()
        {
            InitializeComponent();
            serialPort_AutoDetect();
            COM2MCU_Var_Ini();
            File_Name.Text = FileSaveNameText;
            AutoTestResetTimeShow();
            ParaTuingIni();
     
        }
        private void TabControl_Selected(Object sender, EventArgs e)
        {

            switch (this.TabControl_Page.SelectedIndex)
            {
                case 0:
                    this.Command_TagPage.Controls.Add(this.Char_Cmd_CheckBox);
                    this.Command_TagPage.Controls.Add(this.richText_Display);
                    this.Command_TagPage.Controls.Add(this.button_TextBoxClr);

                    break;
                case 1:
                    this.AutoTest_Tagpage.Controls.Add(this.Char_Cmd_CheckBox);
                    this.AutoTest_Tagpage.Controls.Add(this.richText_Display);
                    this.AutoTest_Tagpage.Controls.Add(this.button_TextBoxClr);
                    break;
                case 2:
                   // this.COM2MCU_TagePage.Controls.Add(this.richText_Display);
                   // this.COM2MCU_TagePage.Controls.Add(this.Clear_But);    
                    COM2MCU_Var_Ini();
                    COM2MCU_ConnectCheck = 0;
                     // */
                    break;
                case 3:
                    //ParaTuingIni();
                    #region
                    /*
                    ListView ParameterTuningTable = new ListView();
                    ParameterTuningTable.Width = 500;
                    ParameterTuningTable.Height = 450;
                    ParameterTuningTable.Location = new System.Drawing.Point(10, 10);

                    ColumnHeader header1, header2, header3, header4;
                    header1 = new ColumnHeader();
                    header2 = new ColumnHeader();
                    header3 = new ColumnHeader();
                    header4 = new ColumnHeader();

                    header1.Text = "No.";
                    header2.Text = "Decimal";
                    header3.Text = "Q24";
                    header4.Text = "Heximal";

                    header1.Width = 50;
                    header2.Width = 150;
                    header3.Width = 150;
                    header4.Width = 150;

                    header1.TextAlign = HorizontalAlignment.Center;
                    header2.TextAlign = HorizontalAlignment.Center;
                    header3.TextAlign = HorizontalAlignment.Center;
                    header4.TextAlign = HorizontalAlignment.Center;

                    ParameterTuningTable.Columns.Add(header1);
                    ParameterTuningTable.Columns.Add(header2);
                    ParameterTuningTable.Columns.Add(header3);
                    ParameterTuningTable.Columns.Add(header4);
                    ParameterTuningTable.View = View.Details;
                    for (int i = 0; i < 512; i++)
                    { 
                        string[] StringItem = { i.ToString(), "0.0000", "12345", "ABC" };
                        ListViewItem itm = new ListViewItem(StringItem);
                        ParameterTuningTable.Items.Add(itm);
                       // ParameterTuningTable.Focus();
                       // ParameterTuningTable.Items[i].Selected =true;
                    }
                    
                    this.Tab_ParaTuning.Controls.Add(ParameterTuningTable);
                    //*/
                    #endregion
                    break;
                case 4:
                    //SerialPortTimer100ms.Enabled = true;
                    SpyMonitorIni();
                    break;
                default:
                    break;                  
            }

            //Discard all data when change the TabPage
            if (serialPort1.IsOpen) serialPort1.ReadExisting();

            // if (TabControl.SelectedIndex != 2) Timer500ms.Enabled = false;
            if (OldTabControlSeletct != TabControl_Page.SelectedIndex)
            {
                if (serialPort1.IsOpen)
                {
                    if (OldTabControlSeletct == 2)
                    {
                        //Stop sending the COM2MCU communication data 
                        //Send few times in order to prevent MCU missing the command
                        for (int i = 0; i < 3; i++)
                        {
                            Thread.Sleep(10);
                            SpyStringSend(CMD_2MCU_RX_PrtOff); //RX Disable
                            Thread.Sleep(10);
                            SpyStringSend(CMD_2MCU_TX_PrtOff); //TX Disable        
                        }
                    }
                }
                OldTabControlSeletct = TabControl_Page.SelectedIndex;
            }
           // */
        }

        
        private void DataFromSerialShowOnScreen(object sender, EventArgs e)
        {

            switch (TabControl_Page.SelectedIndex)
            {
                case 0:
                case 1:
                    if (Char_Cmd_CheckBox.Checked == false) //Char Output
                    {
                        try
                        {
                            char[] charArray = new char[serialPort1.BytesToRead];
                            serialPort1.Read(charArray, 0, serialPort1.BytesToRead);
                            DataShowString = "";
                            for (int i = 0; i < charArray.Length; i++)
                            {
                                // if the char is null or not ASCII code, then ignore it.
                                if ((int)charArray[i] > 0 && (int)charArray[i] <= 127)
                                    DataShowString += charArray[i].ToString();
                            }
                        }
                        catch
                        {
                            Console.Write("Serial Read Error!");
                        }
                    }
                    else //Heximal Output
                    {
                        bufferData = new byte[serialPort1.BytesToRead];
                        serialPort1.Read(bufferData, 0, bufferData.Length);
                        DataShowString = ConvertByteArrayToString(bufferData);
                    }
                 
                    richText_Display.AppendText(DataShowString);
                    break;
               
                default:
                    break;
            }

        }
      /*  private void DataShowOnScreen(string ShowString)
        {

            switch (OldTabControlSeletct)
            {
                case 0:
                case 1:
                    richText_Display.AppendText(ShowString);
                    richText_Display.SelectionStart = richText_Display.Text.Length;
                    break;
                case 2:
                    richText_Display.AppendText(ShowString);
                    richText_Display.SelectionStart = richText_Display.Text.Length;
                    break;
                default:
                    break;
            }

        }
      */
       
        private void button_COM_Switch_Click(object sender, EventArgs e)
        {
            if (button_COM_Switch.Text == "Open Port")
            {
                if ((!serialPort1.IsOpen) && (COM_Ports_NameArr.Length != 0))
                {   // set status 
                    serialPort1.PortName = ComboBox_COM_Port.Text;
                    serialPort1.BaudRate = Convert.ToInt32(ComboBox_Baud_Rate.Text);
                    try
                    {
                        serialPort1.ReadBufferSize = 1000;
                        serialPort1.Open();
                        button_COM_Switch.Text = "Close Port";
                        ComboBox_COM_Port.Enabled = false;
                        ComboBox_Baud_Rate.Enabled = false;
                        button_COM_Scan.Enabled = false;
                    }
                    catch (Exception err)
                    {
                        MessageBox.Show(err.Message);
                        button_COM_Switch.Text = "Open Port";
                        ComboBox_COM_Port.Enabled = true;
                        ComboBox_Baud_Rate.Enabled = true;
                        button_COM_Scan.Enabled = true;
                    }
                    
                }
            }
            else
            {
                if (serialPort1.IsOpen)
                    serialPort1.Close();
                button_COM_Switch.Text = "Open Port";
                ComboBox_COM_Port.Enabled = true;
                ComboBox_Baud_Rate.Enabled = true;
                button_COM_Scan.Enabled = true;
            }

            ShowCOM_Port_State();                    
        }
        private void Close_But_Click(object sender, EventArgs e)
        {
            if(serialPort1.IsOpen)
                serialPort1.Close();
            ShowCOM_Port_State();
        }
       

     
      
        private void button_TextBoxClr_Click(object sender, EventArgs e)
        {
            richText_Display.Clear();
            DataShowString = "";
        }      
        private void button_2MCU_TX_Click(object sender, EventArgs e)
        {

            if (button_2MCU_TX.Text == "TX_En")
            {
                SpyStringSend(CMD_2MCU_TX_PrtOn);
                button_2MCU_TX.Text = "TX_Dis";                
            }
            else
            {
                SpyStringSend(CMD_2MCU_TX_PrtOff);
                button_2MCU_TX.Text = "TX_En";
              
            }
           
        }
        private void button_SendCMD_Click(object sender, EventArgs e)
        {
            byte[] tmpByte = StringCmdToByteArr(Command_Data_Send.Text);
            Command_Data_Send.Text = ConvertByteArrayToString(tmpByte);
            SerialSendByteArray(tmpByte, 0, tmpByte.Length);
        }
     
      
        
      
        private void button_CmprStartUp_Click(object sender, EventArgs e)
        {
            SpyStringSend(CMD_CmprStartUp);//Compressor StartUp           
        }
        private void button_CmprStop_Click(object sender, EventArgs e)
        {
            SpyStringSend(CMD_CmprStop);
        }
        private void button_Manual_Click(object sender, EventArgs e)
        {
            SpyStringSend(CMD_Manual);

        }
        private void button_Auto_Click(object sender, EventArgs e)
        {
            SpyStringSend(CMD_Auto);
        }
        private void button_2MCU_RX_Click(object sender, EventArgs e)
        {

            if (button_2MCU_RX.Text == "RX_En")
            {
                SpyStringSend(CMD_2MCU_RX_PrtOn);
                button_2MCU_RX.Text = "RX_Dis";
            }
            else
            {
                SpyStringSend(CMD_2MCU_RX_PrtOff);
                button_2MCU_RX.Text = "RX_En";
            }
        }
        private void button_PFC_AutoOn_Click(object sender, EventArgs e)
        {
            SpyStringSend(CMD_PFC_AutoOn);
        }
        private void button_PFC_AutoOff_Click(object sender, EventArgs e)
        {
            SpyStringSend(CMD_PFC_AutoOff);
        }
        private void button_PFC_On_Click(object sender, EventArgs e)
        {
            SpyStringSend(CMD_PFC_On);
        }
       
        private void button_PFC_Off_Click(object sender, EventArgs e)
        {
            SpyStringSend(CMD_PFC_Off);
        }
        private void AutoTest_ClearBut_Click(object sender, EventArgs e)
        {
            richText_Display.Clear();
            Console.Beep();            
        }
        private void File_Name_TextChanged(object sender, EventArgs e)
        {
            FileSaveNameText = File_Name.Text;
        }
        private void button_SPD_Set_Click(object sender, EventArgs e)
        {          
            int tmpValue = Convert.ToInt32(SPD_NumUpDown.Value);
            string tmpString = CMD_SPD_Set+ " " + String.Format("{0:X}", tmpValue); //string.Format("{0:X}",(SPD_NumUpDown.Value));
            byte[] tmpByte = StringCmdToByteArr(tmpString);
            SerialSendByteArray(tmpByte, 0, tmpByte.Length);
        }

        private void richText_Display_TextChanged(object sender, EventArgs e)
        {
            richText_Display.SelectionStart = richText_Display.Text.Length;
            richText_Display.ScrollToCaret();
        }

        private void Tatung_Record_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (serialPort1.IsOpen)
                serialPort1.Close(); 
        }

       // public int SerialReceiveSendInTurn = 0;
        private void SerialPortReadTimer100ms_Tick(object sender, EventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                #region //RX
                    switch (TabControl_Page.SelectedIndex)
                    {
                        case 0: //command
                        case 1: //Auto Test
                            if (serialPort1.BytesToRead > 0)
                                this.Invoke(new EventHandler(DataFromSerialShowOnScreen));
                            break;
                        case 2: //COM2MCU 
                            if (serialPort1.BytesToRead > 0)
                                COM2MCU_RX_TX_Deal();
                            break;
                        case 3: //parameter tuning
                            ParaTuningMain();
                            break;
                        case 4: //Sys Monitor
                            SpyMonitorRX();
                            break;
                        default:
                            serialPort1.ReadExisting();
                            break;
                    }
                
                #endregion 
                switch (TabControl_Page.SelectedIndex)
                { 
                 #region //TX
                    case 2:
                        if ((COM2MCU_ConnectCheck & 1) == 0) SpyStringSend(CMD_2MCU_RX_PrtOn); //RX Enable
                        if ((COM2MCU_ConnectCheck & 2) == 0) SpyStringSend(CMD_2MCU_TX_PrtOn); //TX Enable
                        break;
                    case 3:
                        break;
                    case 4:
                        SpyMonitorTX();
                        break;

                    default:

                        break;
                 #endregion 
                }
               

            }
           
        }




        const string StartUpSaveFolderName = "StratUp Record";
        private void button_SpeedPrt_Click(object sender, EventArgs e)
        {
            richText_Display.Clear();
            SpyStringSend(CMD_StartupSpdPrt);
        }

        private void button_ThetaPrt_Click(object sender, EventArgs e)
        {
            richText_Display.Clear();
            SpyStringSend(CMD_StartupThetaPrt);
        }

        private void button_SpeedSave_Click(object sender, EventArgs e)
        {
            TextFileWrite tFW = new TextFileWrite();
            tFW.FolderName = StartUpSaveFolderName;
            tFW.FileName = "Stage_Speed_Current." + DateTime.Now.ToString("MMdd.HH.mm") + ".txt";
            tFW.FileClear();

            startUpRcdSave(tFW);
            
           
            richText_Display.Clear();


            PlotStartup startup = new PlotStartup();
            startup.RcdFilePath = tFW.FilePath; // Path.Combine(Directory.GetCurrentDirectory(), "IntArray.txt");

            startup.Show();
        }

        private void startUpRcdSave(TextFileWrite tFW)
        {
            string[] stringRemoveEmpty = richText_Display.Text.Split(new char[] { '\n' }, StringSplitOptions.RemoveEmptyEntries);
            Queue<string> stringQ = new Queue<string>();
            for (int i = 0; i < stringRemoveEmpty.Length; i++)
                stringQ.Enqueue(stringRemoveEmpty[i]);
            tFW.StringQueueAppendToFile(stringQ);
        }
        private void button_StartUpFolderOpen_Click(object sender, EventArgs e)
        {
            TextFileWrite tFW = new TextFileWrite();
            tFW.FolderName = StartUpSaveFolderName;
            tFW.FolderOpen();
        }

        private void button_ThetaSave_Click(object sender, EventArgs e)
        {
            TextFileWrite tFW = new TextFileWrite();
            tFW.FolderName = StartUpSaveFolderName;
            tFW.FileName = "Theta." + DateTime.Now.ToString("MMdd.HH.mm") + ".txt";
            tFW.FileClear();
            thetaSave(tFW);
           
            richText_Display.Clear();

            PlotTheta thetaPlot = new PlotTheta();

            thetaPlot.RcdFilePath = tFW.FilePath;
            thetaPlot.X_Min = 0;
            thetaPlot.X_Max = 5000;
            thetaPlot.Show();
            
            
           // thetaPlot.SavePic();
            //thetaPlot.Close();
        }

        //Split the string to string array(split by new line)
        //And Save to a text file
        private void thetaSave(TextFileWrite tFW)
        {
            string[] stringRemoveEmpty = richText_Display.Text.Split(new char[] { '\n' }, StringSplitOptions.RemoveEmptyEntries);
            Queue<string> stringQ = new Queue<string>();

            for (int i = 0; i < stringRemoveEmpty.Length; i++)
            {
                string[] tempStringSplit = stringRemoveEmpty[i].Split(new char[] { ' ', '\t' });
                string putTextString = tempStringSplit[0] + " ";

                if (tempStringSplit.Length > 1)
                {
                    try
                    {
                        double tmpDouble = Convert.ToDouble(tempStringSplit[1]);
                        tmpDouble = tmpDouble * 360 / 65535; //Q16 transform 
                        putTextString += tmpDouble.ToString("000.0");
                    }
                    catch
                    {
                        putTextString += tempStringSplit[1];
                    }
                }
                stringQ.Enqueue(putTextString);
            }

            tFW.StringQueueAppendToFile(stringQ);
        
        }
        private void button_RcdClr_Click(object sender, EventArgs e)
        {
            SpyStringSend(CMD_StartupRcdClr);
        }

      

      

    

        
        
        
      



        


       

       

       
       
       

     

        
       
       

       

       


      
   

      

       
       
    
       
       
        

       
      
        
        
    }
}

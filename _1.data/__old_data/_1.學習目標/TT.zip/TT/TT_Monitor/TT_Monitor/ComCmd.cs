﻿namespace TT_Monitor
{
    public partial class Tatung_Record
    {
        //Command
        const string CMD_CmprStartUp = "02 01";
        const string CMD_CmprStop = "02 03";//"AA 20";
        const string CMD_Manual = "04 07";//"AA 20 0 0 0 0 1";
        const string CMD_Auto = "04 07 01";//"AA 20 0 0 0 0 1";
        const string CMD_PFC_AutoOn = "02 04";
        const string CMD_PFC_AutoOff = "02 05";
        const string CMD_PFC_On = "02 00";
        const string CMD_PFC_Off = "02 02";
        const string CMD_SPD_Set = "06 31";

        //COM2MCU
        const string CMD_2MCU_RX_PrtOn = "04 04 02 01";
        const string CMD_2MCU_RX_PrtOff = "04 04 02";
        const string CMD_2MCU_TX_PrtOn = "04 04 03 01";
        const string CMD_2MCU_TX_PrtOff = "04 04 03";

        //ParaTuning
        const string CMD_eFlashRead = "AA F0 04";
        const string CMD_eFlashWrite = "AA F0 03";
        const string CMD_eFlashDownload = "AA F0 01";
        const string CMD_eFlashUpdateMotoPara = "AA F0 05";

        //Startup Record
        const string CMD_StartupSpdPrt = "04 01";
        const string CMD_StartupThetaPrt = "04 01 01";
        const string CMD_StartupRcdClr = "04 01 02";
    }
}
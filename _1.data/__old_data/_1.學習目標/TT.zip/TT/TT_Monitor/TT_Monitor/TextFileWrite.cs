﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TT_Monitor
{
    class TextFileWrite
    {
        public string FolderName{set; get;}
        public string FileName {set; get;}
        public string FolderPath {
            get
            {
                string currentPath = Directory.GetCurrentDirectory();
                Directory.CreateDirectory(FolderName);
                return Path.Combine(currentPath, FolderName);
            }
        }
        public string FilePath {
            get
            {
                return Path.Combine(this.FolderPath, this.FileName);
            }
        }
        public void StringQueueAppendToFile(Queue<string> stringQ)
        {
            if (stringQ.Count > 0)
            {
                if (Directory.Exists(this.FolderName) == false)
                    Directory.CreateDirectory(this.FolderName);
                using (StreamWriter sw = File.AppendText(this.FilePath))
                {
                    while (stringQ.Count > 0)
                        sw.WriteLine(stringQ.Dequeue());
                }
            }
        
        }
        public void StringAppendToFile(string stringData)
        {
            if (stringData.Length > 0)
            {
                if (Directory.Exists(this.FolderName) == false)
                    Directory.CreateDirectory(this.FolderName);
                using (StreamWriter sw = File.AppendText(this.FilePath))
                {
                    sw.WriteLine(stringData);
                }
            }
        }
        public void StringAppendToFile(string[] stringData)
        {
            if (stringData.Length > 0)
            {
                if (Directory.Exists(this.FolderName) == false)
                    Directory.CreateDirectory(this.FolderName);
                using (StreamWriter sw = File.AppendText(this.FilePath))
                {
                    for (int i = 0; i < stringData.Length; i++)
                        sw.WriteLine(stringData[i]);
                }
            }
        }
        public bool FolderOpen()
        {
             if (Directory.Exists(this.FolderPath))
             {
                System.Diagnostics.Process.Start(this.FolderPath);
                 return true;
             }
             else 
                 return false;
        }
        public bool FileOpen()
        { 
            if (File.Exists(this.FilePath))            
            {
                System.Diagnostics.Process.Start(this.FilePath);
                return true;
            }
            else 
                return false;
        
        }
        public bool FileClear()
        {
            if (File.Exists(FilePath))
            {
                try
                {
                    File.Delete(FilePath);
                    return true;
                }
                catch
                {
                    return false;
                }
            }
            else
                return false;
        }
    }
}

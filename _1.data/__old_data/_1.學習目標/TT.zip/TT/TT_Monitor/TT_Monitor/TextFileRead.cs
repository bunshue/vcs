﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
namespace TT_Monitor
{
    class TextFileRead
    {        
        // Set the path of text file
        public string FilePath { get; set; }          
        public char[] seperator { get; set; }       
        public string[] StringArray { get; private set; }            
        //True: Success to Read a File and turn into int array
        public bool ReadTextToStringArray()
        {
            if (File.Exists(FilePath))
            {
                Queue<string> stringArrQ = new Queue<string>();

                using (StreamReader sr = new StreamReader(FilePath))
                {
                    while (sr.Peek() > 0)
                    {
                        string stringRead = sr.ReadLine();
                        if (string.IsNullOrEmpty(stringRead))
                            continue;
                        else
                            stringArrQ.Enqueue(stringRead);
                    }
                }

                StringArray = new string[stringArrQ.Count];
                for (int i = 0; i < StringArray.Length; i++)
                    StringArray[i] = stringArrQ.Dequeue();                 
                return true;
            }
            else
            {                   
                return false;
            }


        }
       
    }
}

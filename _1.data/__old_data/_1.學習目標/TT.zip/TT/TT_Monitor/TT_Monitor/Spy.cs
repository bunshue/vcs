﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TT_Monitor
{
    class SpyRX
    {
        public byte[] Last9Byte ;
        private byte[] buffer; //Get the byte array from serial port
        private byte[] data ; //Store Data

        private byte[] commandID;
        //True: Get Complete Package
        //False: Clear after read the data 
        private bool getFlag ;
        public void SpyRX_Ini()
        {
            data = new byte[10];
            Last9Byte = new byte[9];
            getFlag = false;
        }

        public void InputByteArrToBuffer(byte[] ByteArr)
        {
            buffer = new byte[ByteArr.Length];
            for (int i = 0; i < 9; i++)
                data[i + 1] = Last9Byte[i];
                buffer = ByteArr;
            DataDeal();
        }
        //Read ASCII code string to Buffer
        public void InputStringToBuffer(string ReadString)
        {
            string[] seperators = { " " };
            string[] tmpStrSplit = ReadString.Split(seperators, StringSplitOptions.RemoveEmptyEntries);
            buffer = new byte[tmpStrSplit.Length];

            try
            {
                for (int i = 0; i < tmpStrSplit.Length; i++)
                    buffer[i] = Convert.ToByte(tmpStrSplit[i], 16);
            }
            catch (Exception err)
            {
                Console.WriteLine("Spy RX ReadStringToBuffer:" + err);
            }
            for (int i = 0; i < 9; i++)
                data[i + 1] = Last9Byte[i];
            DataDeal();
        }
        public void SetCmdID(byte[] cmdID)
        {
            if (cmdID != null)
            {
                commandID = new byte[cmdID.Length];
                for (int i = 0; i < cmdID.Length; i++)
                    commandID[i] = cmdID[i];
            }
        }
        private void DataDeal()
        {
            for (int i = 0; i < buffer.Length && getFlag == false; i++)
            {                
                //int dataLen = data.Length;
                int dataLen = 10;
                //data shift one byte
                for (int j = 0; j < (dataLen - 1); j++)
                    data[j] = data[j + 1];

                //put the one byte of buffer into data array
                data[dataLen - 1] = buffer[i];

                if (data[dataLen - 1] == calCheckSum())
                {
                    getFlag = true;
                    for (int k = 0; k < 9; k++)
                       // Last9Byte[k] = 0;
                        Last9Byte[k] = data[k + 1];
                }
                else
                {
                    getFlag = false;
                    for (int k = 0; k < 9; k++)
                        Last9Byte[k] = data[k + 1];
                }
            }

        }
        public bool IsGetPackage()
        {
            return getFlag;
        }
        public byte[] ReadData()
        {
            getFlag = false;
            return data;
        }
        private bool examCmdID()
        {
            bool examResult = true;
            if (commandID != null)
            {
                for (int i = 0; i < commandID.Length && examResult == true ; i++)
                    if (commandID[i] != data[i])
                        examResult = false;
            }
            return examResult;                
        }
        private byte calCheckSum()
        {

            if (examCmdID() == false)
                return (byte)(data[9] + 1); //Fake CRC
            else 
            { 
                int sum = 0;      
                for (int i=0; i < (data.Length-1); i++)
                {
                    sum += data[i];               
                }
                sum = (sum ^ 0xFF) + 1;           
                    return (byte)sum;
            }

        }
    }
}

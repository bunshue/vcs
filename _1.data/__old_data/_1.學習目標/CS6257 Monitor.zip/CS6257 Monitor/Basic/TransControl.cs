﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Threading;

namespace CS6257_Monitor
{

    public class TransControl : Communication
    {
        // 連線狀態
        public enum COM_STATE { DISCONNECTED, ESTABLISHED };
        // 參數同步狀態
        public enum PARAM_STATE { DEFAULT,
            SYN, ASY, REQ, GET, SEND,
            GET_WAIT, SEND_WAIT,
            RECV_CHECK, SEND_CHECK};
        // 監控狀態
        public enum MONITOR_STATE { DEFAULT, ON, OFF };
        // 參數類型
        public enum DATA_TYPE { BOTH, MOTOR, STATEMACHINE };

        public enum TRANS { READ, DOWNLOAD };

        public enum RUNPARAM_STATE { SEND, ACK, NACK, WAIT, DEFAULE };

        public enum EFLASH_STATE { WRITE, READ, ACK, NACK, WAIT, DEFAULT };

        public enum EFLASH_CMD { READ, WRITE };

        public struct PC_STATE
        {
            public int TimeOut;
            public COM_STATE ComState;                        // 連線狀態
            public MONITOR_STATE MonitorState;                // 監控狀態
            public PARAM_STATE ParamState;                    // 參數同步狀態
            public DATA_TYPE DataType;                      // 傳送 / 接收 資料類型
            public RUNPARAM_STATE RunParamState;            // 運行參數更新狀態
            public EFLASH_STATE EfalshState;                // Eflash 狀態
            public int RetryCnt;
            public int RunParamRetryCnt;
            public int WaitTime;
            public int WaitRetryCnt;
        }

        public struct MCU_STATE
        {
            public bool Established;                            // 連線狀態
            public bool MotorParamChk;                          // 
            public bool StateMachineParamChk;
            public bool MotorParamUpd;
            public bool StateMachineParamUpd;
            public bool EflashRead;
            public bool EflashWrite;
        }

        public PC_STATE pcState;
        public ResolvePack resp;
        public ResolvePack2 resp2;
        public ResolvePack.MONITOR_DATA Monitor_Data;
        public ResolvePack2.DISP_DATA Disp_Data;

        public MCU_STATE McuState;

        private Thread thread;

        /// <summary>
        /// 建構函式
        /// </summary>
        public TransControl()
        {
            //
            Init_PcState();
            resp = new ResolvePack(ref SciBuf.RxBuff);
            resp2 = new ResolvePack2(ref SciBuf.RxBuff2);
            thread = new Thread(new ThreadStart(MainWork));
            thread.Name = "TransControl Thread";
            thread.IsBackground = true;
            thread.Start();
        }

        /// <summary>
        /// 初始化
        /// </summary>
        public void Init_PcState()
        {
            pcState.ComState = COM_STATE.DISCONNECTED;
            pcState.MonitorState = MONITOR_STATE.DEFAULT;
            pcState.ParamState = PARAM_STATE.DEFAULT;
            pcState.RunParamState = RUNPARAM_STATE.DEFAULE;
            pcState.EfalshState = EFLASH_STATE.DEFAULT;
        }

        /// <summary>
        /// 主程式
        /// 由Form1 UpdateForm_Method 呼叫 (1sec)
        /// </summary>
        public void MainWork()
        {
            while(true)
            {
                if (IsComPortOpen() == true)
                {
                    switch (pcState.ComState)
                    {
                        case COM_STATE.ESTABLISHED:
                            // 確認參數是否已同步處理
                            CheckParamSYNStatus();
                            EflashOp_Process();
                            if (pcState.MonitorState == MONITOR_STATE.ON)
                            {
                                SciFlag.ReqMonitorData = true;
                            }
                            else
                            {
                                SciFlag.ReqMonitorData = false;
                            }

                            // 確認連線中
                            pcState.TimeOut -= 1;
                            if (pcState.TimeOut <= 0)
                            {
                                int retrycnt = 5;    // 嘗試傳送5次
                                while(retrycnt > 0)
                                {   
                                    if (SendSYN())
                                    {
                                        UpdateMcuState();
                                        if (McuState.Established == true)
                                        {
                                            pcState.ComState = COM_STATE.ESTABLISHED;
                                            pcState.TimeOut = 100;
                                            break;
                                        }
                                    }
                                    Thread.Sleep(200);
                                    retrycnt--;
                                    if (retrycnt == 0)
                                    {
                                        pcState.ComState = COM_STATE.DISCONNECTED;
                                    }
                                }

                            }
                            break;

                        case COM_STATE.DISCONNECTED:
                            // 若傳出echo和回傳echo相同則狀態改為ESTABLISHED    
                            if (SendSYN())
                            {
                                UpdateMcuState();
                                if (McuState.Established == true)
                                {
                                    pcState.ComState = COM_STATE.ESTABLISHED;
                                    pcState.TimeOut = 100;
                                }
                            }
                            pcState.ParamState = PARAM_STATE.DEFAULT;
                            pcState.RunParamState = RUNPARAM_STATE.DEFAULE;
                            pcState.EfalshState = EFLASH_STATE.DEFAULT;
                            SciFlag.ReqMonitorData = false;
                            break;
                    }
                }
                else
                {
                    pcState.ComState = COM_STATE.DISCONNECTED;
                    pcState.ParamState = PARAM_STATE.DEFAULT;
                    pcState.RunParamState = RUNPARAM_STATE.DEFAULE;
                    pcState.EfalshState = EFLASH_STATE.DEFAULT;
                }
                //
                Thread.Sleep(100);
            }
        }

        /// <summary>
        /// 確認參數是否已同步處理
        /// </summary>
        public void CheckParamSYNStatus()
        {
            switch (pcState.ParamState)
            {
                case PARAM_STATE.REQ:
                    // 1. 取得 第255 & 第511筆資料
                    // 2. 取得 listview (Form1) 資料至 listview_Data
                    // 3. 檢查是否和listview的checksum相同
                    // 4.1 若為相同則狀態為 SYN
                    // 4.2 若不相同則狀態為 ASY
                    Thread.Sleep(100);      // Delay
                    ReqMCUCheckSumData();   // 取得MCU資料中Chceksum的值
                    pcState.DataType = DATA_TYPE.MOTOR;
                    pcState.ParamState = PARAM_STATE.RECV_CHECK;
                    break;

                case PARAM_STATE.GET:
                    // 重新下載更新參數
                    Console.WriteLine("\nGet Parameter From MCU [GET]");
                    Thread.Sleep(100);      // Delay                    
                    Get_ParamFromMCU();     // 從MCU取得參數資料
                    pcState.ParamState = PARAM_STATE.GET_WAIT;
                    break;

                case PARAM_STATE.SEND:
                    Console.WriteLine("\nSend Parameter To MCU [SEND]");
                    Thread.Sleep(100);      // Delay
                    Send_ParamToMCU();      // 發送參數資料至MCU
                    pcState.ParamState = PARAM_STATE.SEND_WAIT;
                    break;

                case PARAM_STATE.GET_WAIT:
                    // TODO : 需要 Timout ?
                    // 等待接收完畢
                    if ((SciState.mode != WORKING_MODE.GET_PARAM) &&
                        (SciState.mode != WORKING_MODE.GET_MT_PARAM) &&
                        (SciState.mode != WORKING_MODE.GET_ST_PARAM))
                    {
                        if (DataBuf.Param_Updated == true)
                        {
                            DataBuf.Param_Updated = false;
                            pcState.ParamState = PARAM_STATE.RECV_CHECK;
                            pcState.WaitTime = 0;
                        }
                        else
                        {
                            if (++pcState.WaitTime > 50)  // 5 sec
                            {
                                pcState.WaitTime = 0;
                                if (++pcState.WaitRetryCnt < 3)
                                {
                                    Console.WriteLine("Not response... [GET_WAIT]");
                                    pcState.ParamState = PARAM_STATE.GET;
                                }
                                else
                                {
                                    pcState.WaitRetryCnt = 0;
                                    Console.WriteLine("Get Data Fail... [GET_WAIT]");
                                    pcState.ParamState = PARAM_STATE.ASY;
                                }
                            }
                        }

                    }
                    break;

                case PARAM_STATE.SEND_WAIT:
                    // 等待發送完畢
                    if (SciState.mode != WORKING_MODE.SEND_PARAM &&
                        SciState.mode != WORKING_MODE.SEND_MT_PARAM &&
                        SciState.mode != WORKING_MODE.SEND_ST_PARAM)
                    {
                        pcState.ParamState = PARAM_STATE.SEND_CHECK;
                        pcState.WaitTime = 0;
                    }
                    else
                    {
                        if (++pcState.WaitTime > 50)  // 5 sec
                        {
                            pcState.WaitTime = 0;
                            if (++pcState.WaitRetryCnt < 3)
                            {
                                Console.WriteLine("Not response... [SEND_WAIT]");
                                pcState.ParamState = PARAM_STATE.SEND;
                            }
                            else
                            {
                                pcState.WaitRetryCnt = 0;
                                Console.WriteLine("Send Data Fail... [SEND_WAIT]");
                                pcState.ParamState = PARAM_STATE.ASY;
                            }
                        }
                    }
                    break;

                case PARAM_STATE.RECV_CHECK:
                    Console.WriteLine("Check Receive Data SYN Status [RECV_CHECK]");
                    //Thread.Sleep(400);
                    ReqMCUCheckSumData();   // 取得MCU資料中Chceksum的值
                    CheckParamSYN();          // 檢查CheckSum是否和PC端同步   
                    if (pcState.DataType == DATA_TYPE.MOTOR)
                    {
                        if (CheckSumSYSState.MotorPara)
                        {
                            Console.WriteLine("Receive Data Status [SYN]");
                            pcState.ParamState = PARAM_STATE.SYN;
                        }
                        else
                        {
                            if (++pcState.RetryCnt > 3)
                            {
                                Console.WriteLine("Get Motor Parameter Data Fail [ASY]\n");
                                pcState.ParamState = PARAM_STATE.ASY;
                            }
                            else
                            {
                                Console.WriteLine("Get Motor Parameter Data Again..\n");
                                pcState.DataType = DATA_TYPE.MOTOR;
                                pcState.ParamState = PARAM_STATE.GET;
                            }

                        }
                    }
                    else if (pcState.DataType == DATA_TYPE.STATEMACHINE)
                    {
                        if (CheckSumSYSState.StateMachine)
                        {
                            pcState.ParamState = PARAM_STATE.SYN;
                        }
                        else
                        {
                            pcState.DataType = DATA_TYPE.STATEMACHINE;
                            pcState.ParamState = PARAM_STATE.GET;
                        }
                    }
                    else
                    {
                        if (CheckSumSYSState.MotorPara && CheckSumSYSState.StateMachine)
                        {
                            pcState.ParamState = PARAM_STATE.SYN;
                        }
                        else
                        {
                            pcState.DataType = DATA_TYPE.BOTH;
                            pcState.ParamState = PARAM_STATE.GET;
                        }
                    }
                    break;

                case PARAM_STATE.SEND_CHECK:
                    Console.WriteLine("Check Send Data SYN Status [SEND_CHECK]");
                    Thread.Sleep(400);
                    ReqMCUCheckSumData();   // 取得MCU資料中Chceksum的值
                    CheckParamSYN();          // 檢查CheckSum是否和PC端同步
                    Thread.Sleep(100);
                    if (pcState.DataType == DATA_TYPE.MOTOR)
                    {
                        if (CheckSumSYSState.MotorPara)
                        {
                            Console.WriteLine("Send Data Status [SYN]");
                            pcState.ParamState = PARAM_STATE.SYN;
                        }
                        else
                        {
                            if (++pcState.RetryCnt > 3)
                            {
                                Console.WriteLine("Send Motor Parameter Data Fail [ASY]");
                                pcState.ParamState = PARAM_STATE.ASY;
                            }
                            else
                            {
                                Console.WriteLine("Send Motor Parameter Data Again..\n");
                                pcState.DataType = DATA_TYPE.MOTOR;
                                pcState.ParamState = PARAM_STATE.SEND;
                            }

                        }
                    }
                    else if (pcState.DataType == DATA_TYPE.STATEMACHINE)
                    {
                        if (CheckSumSYSState.StateMachine)
                        {
                            pcState.ParamState = PARAM_STATE.SYN;
                        }
                        else
                        {
                            pcState.DataType = DATA_TYPE.STATEMACHINE;
                            pcState.ParamState = PARAM_STATE.SEND;
                        }
                    }
                    else
                    {
                        if (CheckSumSYSState.MotorPara && CheckSumSYSState.StateMachine)
                        {
                            pcState.ParamState = PARAM_STATE.SYN;
                        }
                        else
                        {
                            pcState.DataType = DATA_TYPE.BOTH;
                            pcState.ParamState = PARAM_STATE.SEND;
                        }
                    }

                    break;

                case PARAM_STATE.ASY:
                    pcState.RetryCnt = 0;
                    pcState.WaitRetryCnt = 0;
                    break;

                case PARAM_STATE.SYN:
                    //
                    UpdateRunPara_Process();
                    //EflashOp_Process();

                    break;

                case PARAM_STATE.DEFAULT:
                    pcState.RetryCnt = 0;
                    pcState.RunParamRetryCnt = 0;
                    pcState.WaitRetryCnt = 0;
                    pcState.ParamState = PARAM_STATE.SYN;
                    break;
            }
        }


        /// <summary>
        /// 更新運轉參數流程
        /// </summary>
        private void UpdateRunPara_Process()
        {
            switch (pcState.RunParamState)
            {
                case RUNPARAM_STATE.SEND:
                    //
                    if (pcState.RunParamRetryCnt < 3)
                    {
                        switch (pcState.DataType)
                        {
                            case DATA_TYPE.MOTOR:
                                Send_UpdateMotorRun_Para();         // 發送命令                      
                                Console.WriteLine("Send Update MotorRun Para. Cmd...");
                                break;
                            case DATA_TYPE.STATEMACHINE:
                                Send_UpdateStateMachineRun_Para();  // 發送命令
                                break;
                        }
                        pcState.RunParamState = RUNPARAM_STATE.WAIT;
                    }
                    else
                    {
                        pcState.RunParamRetryCnt = 0;
                        Console.WriteLine("Send Update Para Fail !! [ERROR]");
                        pcState.RunParamState = RUNPARAM_STATE.NACK;
                    }
                    
                    break;

                case RUNPARAM_STATE.WAIT:
                    Thread.Sleep(500);      // Delay
                    UpdateMcuState();
                    //
                    switch (pcState.DataType)
                    {
                        case DATA_TYPE.MOTOR:
                            if (McuState.MotorParamUpd)
                            {
                                Console.WriteLine("Update Motor Run Para. Successed [OK]");
                                pcState.RunParamState = RUNPARAM_STATE.ACK;
                            } 
                            else
                            {
                                pcState.RunParamRetryCnt++;
                                pcState.RunParamState = RUNPARAM_STATE.SEND;
                            }
                            break;
                        case DATA_TYPE.STATEMACHINE:
                            if (McuState.StateMachineParamUpd)
                                pcState.RunParamState = RUNPARAM_STATE.ACK;
                            else
                            {
                                pcState.RunParamRetryCnt++;
                                pcState.RunParamState = RUNPARAM_STATE.SEND;
                            }
                            break;
                    }
                    break;

                case RUNPARAM_STATE.NACK:

                    break;

                case RUNPARAM_STATE.ACK:
                    Thread.Sleep(3000);
                    pcState.RunParamState = RUNPARAM_STATE.DEFAULE;
                    //if ((McuState.MotorParamUpd || McuState.StateMachineParamUpd) == false)
                    //{
                    //    pcState.RunParamState = RUNPARAM_STATE.DEFAULE;
                    //}
                    break;
                case RUNPARAM_STATE.DEFAULE:
                    break;
            }
        }

        /// <summary>
        /// Eflash 操作流程
        /// </summary>
        public void EflashOp_Process()
        {
            switch(pcState.EfalshState)
            {
                case EFLASH_STATE.READ:
                    Send_ReadEflash_Cmd();
                    pcState.EfalshState = EFLASH_STATE.WAIT;
                    break;

                case EFLASH_STATE.WRITE:
                    Send_WriteEflash_Cmd();
                    Console.WriteLine("\nSend Write Eflash Cmd...");
                    pcState.EfalshState = EFLASH_STATE.WAIT;
                    break;

                case EFLASH_STATE.WAIT:
                    Thread.Sleep(3000);
                    UpdateMcuState();
                    if (McuState.EflashRead || McuState.EflashWrite)
                    {
                        pcState.EfalshState = EFLASH_STATE.ACK;
                    }
                    else
                        pcState.EfalshState = EFLASH_STATE.NACK;
                    break;

                case EFLASH_STATE.NACK:
                    
                    break;

                case EFLASH_STATE.ACK:

                    break;
                case EFLASH_STATE.DEFAULT:
                    break;
            }
        }

        /// <summary>
        /// 更新監控參數
        /// 馬達運轉參數、故障保護狀態、溫度資訊
        /// </summary>
        public void UpdateMonitorData()
        {
            // 複製接收暫存資料至RxBuff
            CopyRxBuff();
            resp.Update(ref Monitor_Data);
            //
            CopyRxBuff2();
            resp2.Update(ref Disp_Data);
        }

        /// <summary>
        /// 更新MCU系統狀態參數
        /// </summary>
        public void UpdateMcuState()
        {
            // 複製至 SciBuf.MsgBuf
            CopyMsgBuf();

            // Echo 狀態
            if (SciBuf.MsgBuf[2] != 0x00)
            {
                McuState.Established = true;
            }
            else
            {
                McuState.Established = false;
            }

            McuState.MotorParamChk = IsCheckSumOK(SciBuf.MsgBuf[4 + 2]);
            McuState.StateMachineParamChk = IsCheckSumOK(SciBuf.MsgBuf[8 + 2]);
            McuState.MotorParamUpd = IsCheckSumOK(SciBuf.MsgBuf[16 + 2]);
            McuState.StateMachineParamUpd = IsCheckSumOK(SciBuf.MsgBuf[20 + 2]);
            
            if (SciBuf.MsgBuf[24 + 2] != 0x00)
            {
                McuState.EflashRead = true;
            }
            else
            {
                McuState.EflashRead = false;
            }

            if (SciBuf.MsgBuf[28 + 2] != 0x00)
            {
                McuState.EflashWrite = true;
            }
            else
            {
                McuState.EflashWrite = false;
            }
            

            // 清除 
            ClearQMsgBuf();
        }

        /// <summary>
        /// 取得校驗狀態
        /// </summary>
        /// <param name="b"></param>
        /// <returns></returns>
        public bool IsCheckSumOK(byte b)
        {
            if (b == 0xAA)
                return true;
            else return false;
        }

        /// <summary>
        /// 
        /// </summary>
        public void SetParamTransControl(TRANS trans, DATA_TYPE dataType)
        {
            if (pcState.ParamState == PARAM_STATE.SYN || pcState.ParamState == PARAM_STATE.ASY)
            {
                if (trans == TRANS.READ)
                {
                    pcState.DataType = dataType;
                    pcState.ParamState = PARAM_STATE.GET;
                }
                else if (trans == TRANS.DOWNLOAD)
                {
                    pcState.DataType = dataType;
                    pcState.ParamState = PARAM_STATE.SEND;
                }
            }
        }

        /// <summary>
        /// 
        /// </summary>
        public void EflashReadWriteControl(EFLASH_CMD cmd)
        {
            switch(cmd)
            {
                case EFLASH_CMD.READ:
                    pcState.EfalshState = EFLASH_STATE.READ;
                    break;
                case EFLASH_CMD.WRITE:
                    pcState.EfalshState = EFLASH_STATE.WRITE;
                    break;
                default:
                    break;
            }
        }

        #region 參數傳輸指令更改

        /// <summary>
        /// 從MCU取得參數
        /// </summary>
        private void Get_ParamFromMCU()
        {
            switch(pcState.DataType)
            {
                case DATA_TYPE.BOTH:
                    Get_ALL_ParamFromMCU();
                    break;
                case DATA_TYPE.MOTOR:
                    Get_Motor_ParamFromMCU();
                    break;
                case DATA_TYPE.STATEMACHINE:
                    Get_StateMachine_ParamFromMCU();
                    break;
            }
        }

        /// <summary>
        /// 從MCU取得全部所有參數
        /// </summary>
        private void Get_ALL_ParamFromMCU()
        {
            if (SciState.mode == WORKING_MODE.MONITOR || SciState.mode == WORKING_MODE.DEFAULT)
                SciState.mode = WORKING_MODE.GET_PARAM;
        }

        /// <summary>
        /// 從MCU取得馬達參數
        /// </summary>
        private void Get_Motor_ParamFromMCU()
        {
            if (SciState.mode == WORKING_MODE.MONITOR || SciState.mode == WORKING_MODE.DEFAULT)
                SciState.mode = WORKING_MODE.GET_MT_PARAM;
        }

        /// <summary>
        /// 從MCU取得溫控邏輯參數
        /// </summary>
        private void Get_StateMachine_ParamFromMCU()
        {
            if (SciState.mode == WORKING_MODE.MONITOR || SciState.mode == WORKING_MODE.DEFAULT)
                SciState.mode = WORKING_MODE.GET_ST_PARAM;
        }

        /// <summary>
        /// 發送參數至MCU
        /// </summary>
        private void Send_ParamToMCU()
        {
            switch(pcState.DataType)
            {
                case DATA_TYPE.BOTH:
                    Send_ALL_ParamToMCU();
                    break;
                case DATA_TYPE.MOTOR:
                    Send_Motor_ParamToMCU();
                    break;
                case DATA_TYPE.STATEMACHINE:
                    Send_StateMachine_ParamToMCU();
                    break;
            }
        }

        /// <summary>
        /// 發送所有參數至MCU
        /// </summary>
        private void Send_ALL_ParamToMCU()
        {
            if (SciState.mode == WORKING_MODE.MONITOR || SciState.mode == WORKING_MODE.DEFAULT)
                SciState.mode = WORKING_MODE.SEND_PARAM;
        }

        /// <summary>
        /// 發送馬達參數至MCU
        /// </summary>
        private void Send_Motor_ParamToMCU()
        {
            if (SciState.mode == WORKING_MODE.MONITOR || SciState.mode == WORKING_MODE.DEFAULT)
                SciState.mode = WORKING_MODE.SEND_MT_PARAM;
        }

        /// <summary>
        /// 發送溫控邏輯參數至MCU
        /// </summary>
        private void Send_StateMachine_ParamToMCU()
        {
            if (SciState.mode == WORKING_MODE.MONITOR || SciState.mode == WORKING_MODE.DEFAULT)
                SciState.mode = WORKING_MODE.SEND_ST_PARAM;
        }

        /// <summary>
        /// 更新馬達運行參數
        /// </summary>
        public void UpdataMotorRun_Param()
        {
            if (pcState.ParamState == PARAM_STATE.SYN)
            {
                if (pcState.RunParamState == RUNPARAM_STATE.DEFAULE)
                {
                    pcState.DataType = DATA_TYPE.MOTOR;
                    pcState.RunParamState = RUNPARAM_STATE.SEND;
                }
            }
        }

        /// <summary>
        /// 更新溫控邏輯運行參數
        /// </summary>
        public void UpdateStateMachineRun_Param()
        {
            if (pcState.ParamState == PARAM_STATE.SYN)
            {
                if (pcState.RunParamState == RUNPARAM_STATE.DEFAULE)
                {
                    pcState.DataType = DATA_TYPE.STATEMACHINE;
                    pcState.RunParamState = RUNPARAM_STATE.SEND;
                }
            }
        }

        #endregion

    }
}

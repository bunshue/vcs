﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CS6257_Monitor
{
    public class ResolvePack
    {
        public const int VERSION = 2;
        public const int SERIALNUM = 3;
        public const int SYSTIME_1 = 4;
        public const int SYSTIME_2 = 5;
        public const int SYSTIME_3 = 8;

        public const int POLE_PAIR = 6;             // 極對數
        public const int OP_MODE = 7;               // 系統操作模式

        public const int ROOM_TEMP = 12;                // 室內環境溫度
        public const int INCOIL_TEMP = 13;              // 室內銅管溫度
        public const int OUTDOOR_TEMP = 14;             // 室外環境溫度
        public const int OUTCOIL_TEMP = 15;              // 室外銅管溫度
        public const int DISCHARGE_TEMP = 16;           // 壓縮機排氣溫度
        public const int SUCTION_TEMP = 17;             // 壓縮機入口溫度
        public const int SET_TEMP = 18;                 // 室內設定溫度

        public const int IN_FAULT_CODE_1 = 22;         // 室內故障狀態 1
        public const int IN_FAULT_CODE_2 = 23;         // 室內故障狀態 2

        public const int FAULT_CODE_1 = 24;         // 室外故障狀態 1
        public const int FAULT_CODE_2 = 25;         // 室外故障狀態 2
        public const int PRO_CODE_1 = 26;           // 室外保護狀態 1
        public const int PRO_CODE_2 = 27;           // 室外保護狀態 2
        public const int FREQ_PRO_CODE = 28;         // 頻率限制狀態

        public const int INMODE = 32;               // 室內機運行模式
        public const int INMODEAPP = 33;            // 室內機運行附加模式
        public const int TESTCMD = 34;              // 測試模式
        public const int INFANGRADE = 35;           // 室內風機轉速
        public const int PROTECT_ERR = 36;          // 錯誤碼
        public const int PROTECT_LIM = 37;          // 限頻碼
        public const int RSDELTA_TEMP = 38;         // 溫差

        public const int STATE = 42;                // 系統狀態
        public const int BASIC_RUNMODE = 43;        // 工作模式
        public const int SUB_CMD = 44;              // 子工作模式
        public const int WKSTATE = 45;              // 運行狀態
        public const int FCSTATE = 46;              // 運行模式
        public const int ACMODE = 47;               // 頻率計算時工作模式

        public const int _DTG_STATE_ = 52;            // 溫度變化狀態
        public const int DTG_TIMER_LO = 53;         // 頻率區間保持時間低字節
        public const int DTG_TIMER_HI = 54;         // 頻率區間保持時間高字節

        public const int TEMPGRADE_OLD = 55;        // 上次溫度區間
        public const int TEMPGRADE_NOW = 56;        // 本次溫度區間

        public const int FREQGRADE_OUT = 57;        // 計算頻率等級輸出
        public const int FREQGRADE_MAX = 58;        // 室外機允許最大頻率等級

        public const int OTEMPFREGMAX = 62;         // 室外溫度限制最大頻率等級
        public const int INFANFREGMAX = 63;         // 室內風速限制最大頻率等級
        public const int DEFROSTCTRL = 64;          // 除霜狀態
        public const int DEFROTIMERCNT_LO = 65;     // 除霜-製熱流程切換計時器低字節
        public const int DEFROTIMERCNT_HI = 66;     // 除霜-製熱流程切換計時器高字節

        public const int TIMERTEMPCNT_LO = 67;      // 滿足除霜溫度時間計數器低字節
        public const int TIMERTEMPCNT_HI = 68;      // 滿足除霜溫度時間計數器高字節

        public const int _FAULTSTATE_ = 72;         // 故障-保護狀態
        public const int _FAULTCODE_ = 73;          // 故障-保護編號
        public const int IPMCNT = 74;               // IPM 保護次數
        public const int STARCNT = 75;              // 啟動保護次數
        public const int COMPPROCNT = 76;           // 驅動保護次數
        public const int PROTIMECNT_LO = 77;        // 保護復位後，時間計數低字節
        public const int PROTIMECNT_HI = 78;        // 保護復位後，時間計數高字節

        public const int OFFTIME_LO = 82;           // 保護關機流程計時器低字節
        public const int OFFTIME_HI = 83;           // 保護關機流程計時器高字節

        public const int PRONUM = 84;               // 降頻保護代碼
        public const int PROFREQGRADE = 85;         // 降頻保護時頻率檔位元
        public const int RESETTIMER_LO = 86;        // 降頻保護允許恢復延遲時間低字節
        public const int RESETTIMER_HI = 87;        // 降頻保護允許恢復延遲時間高字節
        public const int OCCUREDCNT = 88;           // 故障-保護已發生的次數

        public const int DC_VOLTAGE = 92;           // DC 電壓

        public const int AC_VOLTAGE = 93;           // AC 電壓
        public const int AC_CURRENT = 94;           // AC 電流

        public const int VD_VOLT = 95;              // D軸電壓
        public const int VQ_VOLT = 96;              // Q軸電壓

        public const int ID_CURRENT = 97;           // D軸電流
        public const int IQ_CURRENT = 98;           // Q軸電流

        public const int SET_SPEED = 102;           // 設定轉速
        public const int REAL_SPEED = 103;          // 實際轉速

        public const int PFC_STATE = 105;           // PFC 狀態
        public const int FORUWAY_VALVE_STATE = 106; // 四通閥狀態
        public const int MAIN_RELAY_STATE = 108;    // 主繼電器狀態

        public const int MOTORSTATE = 112;         // 壓縮機狀態
        public const int MOTOR_ST_CNT_LO = 113;     // 壓縮機狀態計數低字節
        public const int MOTOR_ST_CNT_HI = 114;     // 壓縮機狀態計數高字節

        public const int CompProtect = 115;         // 壓縮機故障狀態

        public const int IPM_TEMP = 118;            // IPM 溫度

        public const int DCFAN_STATE = 122;         // DC 風扇狀態
        public const int OUTFANST_LO = 123;         // 室外風扇狀態計數低字節
        public const int OUTFANST_HI = 124;         // 室外風扇狀態計數高字節

        public const int DCFAN_SPEED_L = 125;       // DC 風扇轉速低位
        public const int DCFAN_SPEED_H = 126;       // DC 風扇轉速高位


        // 系統狀態
        public enum SYS_STATE
        {
            SYS_IDLE,       // 系統待機
            SYS_RESET,      // 系統重置
            SYS_FAULT,      // 系統錯誤
            SYS_PROTECT,    // 系統保護
            SYS_RUN,        // 系統正常運行
            SYS_OFF_DLY,    // 延遲停機
            SYS_POWERUP_DLY // 延遲啟動
        }

        // 工作模式
        public enum WORK_MODE
        {
            WMS_OFF,                // 停機
            WMS_REFRIGERATING,      // 冷氣  
            WMS_WIND,               // 送風
            WMS_DEHUMIDIFIERING,    // 除濕
            WMS_HEATING,            // 暖氣
            WMS_AUTO,               // 自動
            WMS_TESTING,            // 測試
            WMS_WARMUP,             // 預熱
            WMS_COOL_TESTING,       // 製冷測試
            WMS_HEAT_TESTING        // 製熱測試
        }

        // 子工作模式
        public enum SUB_MODE
        {
            NO_SUB,                 // 無
            SUB_FORCE,              // 強制運行
            SUB_TEST,               // 測試模式
            SUB_SLEEP,              // 睡眠模式
            SUB_ECONO,              // 經濟模式
            SUB_POWER,              // 強力模式
            SUB_QUITE,              // 靜音模式
            SUB_VENTILATE           // 通風模式
        }

        // 運行狀態
        public enum WORK_STATE
        {
            WS_IDLE,
            WS_STAR,
            WS_RUN,
            WS_OFFING,
            WS_OFF
        }

        // 頻率狀態
        public enum FREQ_STATE
        {
            FREQ_STOP,              // 正常停機
            FORCE_ZERO,             // 強制關機
            FORBID_STAR,            // 禁止啟動
            FREQ_STAR,              // 啟動
            FREQ_AUTO,              // 自動計算
            FORCE_FALLING_80,
            FORCE_FALLING_70,
            FREQ_HOLDING            // 禁止升頻
        }

        // 溫度變化狀態
        public enum DTG_STATE
        {
            DTG_HOLDING,
            DTG_FALL,
            DTG_RISE,
            DTG_OFF,
            DTG_ERROR
        }

        // 除霜狀態
        public enum DEFRO_STATE
        {
            DEFRO_HEATING,
            DEFRO_STAR,
            DEFRO_RUN,
            DEFRO_END,
            DEFRO_ERROR
        }

        public enum FAULT_STATE
        {
            NO_FAULT,
            FAULT,
            PROTECT,
            PROTECT_DELAY,
            PROTECT_RESET
        }

        public enum FAULT_CODE
        {
	        FAULT_NONE, FAULT_IPM, FAULT_OUTEMP_SENSOR, FAULT_OUTCOIL_SENSOR, FAULT_SUCT_SENSOR,
	        FAULT_DISC_SENSOR, FAULT_CUR_SENSOR, FAULT_COMPRESS, FAULT_PHASE, FAULT_BACK_SENSOR,
	        PROTECT_IPM, PROTECT_IAC, PROTECT_DISCHAR_TEMP, PROTECT_TOP_TEMP,
	        PROTECT_SUCT_TEMP, PROTECT_VBUS, PROTECT_LOW_PRESSURE, PROTECT_OVER_PRESSURE,
	        PROTECT_INCOIL_TEMP, PROTECT_OUTDOOR_TEMP, FAULT_COMMUN,
	        FAULT_EEPROM, FAULT_STAR, FAULT_FANMOTOR, PROTECT_IPM_TEMP, PROTECT_IPM_SOFT_OVERCUR,
	        FAULT_VBUS, PROTECT_COMMUN, PROTECT_STAR, FAULT_LACKFI, PROTECT_INERR,
	        PROTECT_COM_DRIVER, PROTECT_OUT_COIL_TEMP, FAULT_FORCE_OFF, FAULT_PFC, FAULT_VAC,
	        FAULT_IPM_SENSOR, PROTECT_IAC_LOW, ERROR
        }

        public struct MOTORRUN_INFO
        {
            public int SetSpeed_rps;        // 設定轉速 (rps)
            public int SetSpeed_rpm;        // 設定轉速 (rpm)
            public int RealSpeed_rps;       // 實際轉速 (rps)
            public int RealSpeed_rpm;       // 實際轉速 (rpm)

            public int ACVoltage;           // AC 電壓
            public double ACCurrent;        // AC 電流
            public int DCVoltage;           // DC 電壓
            public double dVolt;            // d軸電壓
            public double qVolt;            // q軸電壓
            public double IdCurrent;        // d軸電流
            public double IqCurrent;        // 轉矩電流

            public double Power;            // 入電功率

            public int IPMTemp;             // IPM 溫度
            public int DCFanSpeed;          // DC風扇轉速
            public int PFCState;            // PFC 狀態
            public int FourWayValveState;   // 四通閥狀態
            public int MainRelayState;      // 主繼電器狀態
            public int OpMode;              // 操作模式
            public int FirmwareVersion;     // 韌體版本
            public int SysTime;             // 系統運行時間
        }

        public struct MOTOR_STATE
        {
            public int state;               // 電機狀態 (0: OFF 1: ON)
            public int MotorStCnt;          // 電機狀態計數
            public int outFanState;         // 室外風扇狀態
            public int outFanStCnt;         // 室外風扇狀態計數
            public int outFanSpd;           // 室外風扇轉速
        }

        public struct SYSRUN_INFO
        {
            public WORK_MODE inMode;        // 室內機運行模式
            public SUB_MODE inModeApp;      // 室內機運行附加模式
            public int testCmd;             // 測試模式
            public int inFanGrade;          // 室內風機等級
            public int Protect_err;         // 錯誤碼
            public int Protect_lim;         // 限頻碼
            public int rsDeltaTemp;         // 溫差

            public SYS_STATE state;         // 系統狀態
            public WORK_MODE basicRunMode;  // 工作模式
            public SUB_MODE subCmd;         // 子工作模式
            public WORK_STATE wkState;      // 運行狀態
            public FREQ_STATE fcState;
        }

        public struct DTGGRADE_FREQ
        {
            public DTG_STATE state;         // 溫度變化狀態
            public int timer;               // 頻率區間保持時間
            public int tempGradeOld;        // 上一次溫度區間
            public int tempGradNow;         // 本次溫度區間
            public int freqGradeOut;        // 計算頻率等級輸出
            public int freqGradeMax;        // 室外機允許運行最大頻率等級
            public int rsDeltaTemp;         // 溫度差
            public int oTempFreGMax;        // 室外溫度限制最大頻率等級
            public int inFanFreGMax;        // 室內風速限制最大頻率等級
        }

        public struct DEFROST
        {
            public DEFRO_STATE state;
            public int timeCnt;             //除霜-制熱流程切換計時器
            public int timeTempCnt;         //滿足除霜溫度時間計數器
        }

        public struct STR_SYSPROTECT
        {
            public int proNum;              // 保護原因標誌位
            public int proFreqGrade;        // 降頻保護時頻率檔位元
            public int resetTime;           // 保護限頻允許恢復延遲時間
            
        }

        public struct SYS_FAULT
        {
            public FAULT_STATE state;       //故障-保護狀態
            public FAULT_CODE code;         //故障-保護編號
            public int occuredCnt;          //故障-保護已經發生的次數
            public int dlyTime;             //故障-保護小時後，延時復位時間
            public int timeCnt;             //保護復位後，時間計數
            public int ipmCnt;              // ipm保護次數
            public int starCnt;             // 起動保護次數
            public int compProCnt;          // 驅動故障計數
            public int offTimer;            // 保護關機流程計時器
        }

        public struct TEMPERATURE
        {
            public int roomTemp;            // 室內環境溫度
            public int inCoilTemp;          // 室內銅管溫度
            public int outDoorTemp;         // 室外環境溫度
            public int outCoilTemp;         // 室外銅管溫度
            public int disChargeTemp;       // 壓縮機排氣溫度
            public int suctionTemp;         // 壓縮機入口溫度
            public int setTemp;             // 室內設定溫度
        }

        public enum MOTOR_FAULT
        {
            None,                           // 無
            StartUpErr,                     // 啟動故障
            PhaseLose,                      // 缺相保護
            ZeroSpeed,                      // 零速保護
            LoseSpeed,                      // 失速保護
            ICompOver,                      // 過流保護
            PhaseErr                        // 相序錯誤
        }

        public struct INFAULT_INFO
        {
            // IN FAULT CODE 1
            public bool roomTempSensor;     // 室內環境溫度感測器故障
            public bool inCoilinSensor;     // 室內蒸發器入口溫度感測器故障
            public bool inCoilMidSensor;    // 室內蒸發器中間溫度感測器故障
            public bool inCoilOutSensor;    // 室內蒸發器出口溫度感測器故障
            public bool inFan;              // 室內風機故障
            public bool inEeprom;           // 室內 EEPROM 故障
            public bool valveFl;            // 製冷系統缺氟或換相閥故障
            public bool zeroCheck;          // 過零檢測出錯故障

            // IN FAULT CODE 2
            public bool inCoilFreeze;       // 室內蒸發器溫度過低保護
            public bool inCoilExcHeat;      // 室內蒸發器溫度過高保護
        }

        public struct FAULT_INFO
        {
            // FAULT CODE 1
            public bool IPMFault;           // IPM 模組故障
            public bool outTempSensor;      // 室外環境溫度感測器故障
            public bool outCoilMidSensor;   // 室外機盤管中部溫度感測器故障
            public bool suctionSensor;      // 壓縮機吸氣溫度感測器故障
            public bool discharSensor;      // 壓縮機排氣溫度感測器故障
            public bool curSensor;          // 電流感測器故障
            public short vBusErr;            // DC電壓 (1: 低 2: 高)

            // FAULT CODE 2
            public bool IPMSensorErr;       // IPM 溫度感測器故障
            public bool outFanMotor;        // 室外機風扇故障
            public bool communicate;        // 室內外通訊故障

            public bool iacOver;            // AC 電流過大
            public bool VacLow;             // AC 電壓過小
            public bool VacHigh;            // AC 電壓過大

            // 馬達故障狀態
            public MOTOR_FAULT MotorFault;
        }

        public enum FREQ_PRO_NUM
        {
            INFAN_LO_PRO,       // 室內機風扇限頻
            IC_OL_PRO,          // 壓縮機電流超載限頻保護
            VBUS_PRO,           // DC電壓限頻保護
            IAC_PRO,            // 交流電流限頻保護
            DISCHARGE_PRO,      // 排氣高溫限頻保護
            HINCOIL_PRO,        // 製熱室內盤管防過熱限頻保護
            ROUTCOIL_PRO,       // 製冷室外盤管防過熱限頻保護
            RINCOIL_PRO         // 製冷室內盤管防凍結限頻保護
        }

        public struct PROTECT_INFO
        {
            // PROTECT 1
            public bool ipmTemp;            // IPM過熱保護
            public bool iacOverCur;         // AC 輸入電流過大保護
            public bool discharTemp;        // 壓縮機排氣溫度保護
            public bool compTopTemp;        // 壓縮機頂部溫度過熱保護
            public bool suctionTemp;        // 壓縮機吸氣溫度保護
            public bool iacLowCur;          // 交流輸入電流過小保護

            // PROTECT 2
            public bool disPressure;        // 排氣高壓保護
            public bool outCoilTemp;        // 室外冷凝管高溫保護
            public bool outTemp;            // 室外環境溫度高溫保護
            public bool inCoilFreeze;       // 室內蒸發器低溫保護
            public bool inCoilOverTemp;     // 室內蒸發器高溫保護
            public bool sysErrReset;        // 室外系統異常重定

            public FREQ_PRO_NUM freqProNum; // 限頻保護代碼
        }

        public struct FREQ_LIMIT
        {
            public bool Infan_Lo_Pro;       // 室內風扇限頻
            public bool Ic_Ol_Pro;          // 壓縮機電流超載限頻
            public bool Vbus_Pro;           // 母線電壓限頻保護
            public bool Iac_Pro;            // 交流電流限頻保護
            public bool Discharge_Pro;      // 排氣高溫限頻保護
            public bool HinCoil_Pro;        // 製熱室內盤管防過熱限頻保護
            public bool RoutCoil_Pro;       // 製冷室外盤管防過熱限頻保護
            public bool RinCoil_Pro;        // 製冷室內盤管凍結限頻保護
        }

        public struct MONITOR_DATA
        {
            public int Version;
            public int SerialNum;
            public int PolePair;
            public MOTORRUN_INFO MotorRunInfo;
            public MOTOR_STATE motorState;
            public SYSRUN_INFO SysRunInfo;
            public DTGGRADE_FREQ fgCtrl;
            public DEFROST defro;
            public SYS_FAULT sysFault;
            public STR_SYSPROTECT sysFreqPro;
            public TEMPERATURE Temperature;
            public INFAULT_INFO inFaultInfo;
            public FAULT_INFO FaultInfo;
            public PROTECT_INFO ProtectInfo;
            public FREQ_LIMIT Freqlimit;
        }

        private byte[] SciRxBuff;

        /// <summary>
        /// 
        /// </summary>
        public ResolvePack()
        {

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="RxBuff_ref"></param>
        public ResolvePack(ref byte[] RxBuff_ref)
        {
            SciRxBuff = RxBuff_ref;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="Monitor_Data"></param>
        public void Update(ref MONITOR_DATA Monitor_Data)
        {
            // 從 RxBuff 取得資料並計算相對應的值
            Monitor_Data.Version = Get_Version(ref SciRxBuff);
            Monitor_Data.SerialNum = Get_SerialNum(ref SciRxBuff);
            Monitor_Data.PolePair = Get_PolePair(ref SciRxBuff);
            Monitor_Data.MotorRunInfo.SetSpeed_rps = CalcSetSpeed(ref SciRxBuff, 0);
            Monitor_Data.MotorRunInfo.SetSpeed_rpm = CalcSetSpeed(ref SciRxBuff, 1);

            Monitor_Data.MotorRunInfo.RealSpeed_rps = CalcRealSpeed(ref SciRxBuff, 0);
            Monitor_Data.MotorRunInfo.RealSpeed_rpm = CalcRealSpeed(ref SciRxBuff, 1);

            Monitor_Data.MotorRunInfo.ACVoltage = CalcACVoltage(ref SciRxBuff);
            Monitor_Data.MotorRunInfo.ACCurrent = CalcACCurrent(ref SciRxBuff);

            Monitor_Data.MotorRunInfo.DCVoltage = CalcDCVoltage(ref SciRxBuff);

            Monitor_Data.MotorRunInfo.dVolt = CalcVdVolt(ref SciRxBuff);
            Monitor_Data.MotorRunInfo.qVolt = CalcVqVolt(ref SciRxBuff);

            Monitor_Data.MotorRunInfo.IdCurrent = CalcIdCurrent(ref SciRxBuff);
            Monitor_Data.MotorRunInfo.IqCurrent = CalcIqCurrent(ref SciRxBuff);

            Monitor_Data.MotorRunInfo.Power = CalcPower(ref SciRxBuff);
            Monitor_Data.MotorRunInfo.IPMTemp = CalcIPMTemp(ref SciRxBuff);

            Monitor_Data.MotorRunInfo.DCFanSpeed = CalcDCFanSpeed(ref SciRxBuff);

            Monitor_Data.MotorRunInfo.PFCState = GetPFCState(ref SciRxBuff);
            Monitor_Data.MotorRunInfo.FourWayValveState = GetFourWayValveState(ref SciRxBuff);
            Monitor_Data.MotorRunInfo.MainRelayState = GetMainRelayState(ref SciRxBuff);

            Monitor_Data.MotorRunInfo.OpMode = GetOpMode(ref SciRxBuff);
            // 系統運行時間
            Monitor_Data.MotorRunInfo.SysTime = Get_SysTime(ref SciRxBuff);
            //
            // 室內外機溫度
            Monitor_Data.Temperature.roomTemp = roomTemp(ref SciRxBuff);
            Monitor_Data.Temperature.inCoilTemp = inCoilTemp(ref SciRxBuff);
            Monitor_Data.Temperature.outDoorTemp = outDoorTemp(ref SciRxBuff);
            Monitor_Data.Temperature.outCoilTemp = outCoilTemp(ref SciRxBuff);
            Monitor_Data.Temperature.disChargeTemp = disChargeTemp(ref SciRxBuff);
            Monitor_Data.Temperature.suctionTemp = suctionTemp(ref SciRxBuff);
            Monitor_Data.Temperature.setTemp = setTemp(ref SciRxBuff);
            // 室內機狀態
            Monitor_Data.SysRunInfo.inMode = Get_inMode(ref SciRxBuff);
            Monitor_Data.SysRunInfo.inModeApp = Get_inModeApp(ref SciRxBuff);
            Monitor_Data.SysRunInfo.testCmd = Get_testCmd(ref SciRxBuff);
            Monitor_Data.SysRunInfo.inFanGrade = Get_inFanGrade(ref SciRxBuff);
            Monitor_Data.SysRunInfo.Protect_err = Get_inFaultCode(ref SciRxBuff);
            Monitor_Data.SysRunInfo.Protect_lim = Get_inLimCode(ref SciRxBuff);
            // 電機狀態
            Monitor_Data.motorState.state = Get_MotorState(ref SciRxBuff);
            Monitor_Data.motorState.MotorStCnt = Get_MotorStateCnt(ref SciRxBuff);
            Monitor_Data.motorState.outFanState = Get_OutFanState(ref SciRxBuff);
            Monitor_Data.motorState.outFanStCnt = Get_OurFanStateCnt(ref SciRxBuff);
            Monitor_Data.motorState.outFanSpd = CalcDCFanSpeed(ref SciRxBuff);
            // 系統運行狀態
            Monitor_Data.SysRunInfo.state = GET_SYS_STATE(ref SciRxBuff);
            Monitor_Data.SysRunInfo.basicRunMode = GET_WORK_MODE(ref SciRxBuff);
            Monitor_Data.SysRunInfo.subCmd = GET_SUB_MODE(ref SciRxBuff);
            Monitor_Data.SysRunInfo.wkState = GET_WORK_STATE(ref SciRxBuff);
            Monitor_Data.SysRunInfo.fcState = GET_FREQ_STATE(ref SciRxBuff);
            // 溫度變化資訊
            Monitor_Data.fgCtrl.state = Get_DTGState(ref SciRxBuff);
            Monitor_Data.fgCtrl.timer = Get_DTGTimer(ref SciRxBuff);
            Monitor_Data.fgCtrl.tempGradeOld = Get_tempGradeOld(ref SciRxBuff);
            Monitor_Data.fgCtrl.tempGradNow = Get_tempGradeNow(ref SciRxBuff);
            Monitor_Data.fgCtrl.freqGradeOut = Get_freqGradeOut(ref SciRxBuff);
            Monitor_Data.fgCtrl.freqGradeMax = Get_freqGradeMax(ref SciRxBuff);
            Monitor_Data.fgCtrl.oTempFreGMax = Get_oTempFreGMax(ref SciRxBuff);
            Monitor_Data.fgCtrl.rsDeltaTemp = Get_rsDeltaTemp(ref SciRxBuff);
            Monitor_Data.fgCtrl.inFanFreGMax = Get_inFanFreGMax(ref SciRxBuff);
            // 除霜狀態資訊
            Monitor_Data.defro.state = Get_DEFRO_STATE(ref SciRxBuff);
            Monitor_Data.defro.timeCnt = GET_DEFRO_timeCnt(ref SciRxBuff);
            Monitor_Data.defro.timeTempCnt = GET_DEFRO_timeTempCnt(ref SciRxBuff);
            // 故障-保護狀態
            Monitor_Data.sysFault.state = Get_FaultState(ref SciRxBuff);
            Monitor_Data.sysFault.code = Get_FaultCode(ref SciRxBuff);
            Monitor_Data.sysFault.ipmCnt = Get_IPMFaultCnt(ref SciRxBuff);
            Monitor_Data.sysFault.starCnt = Get_StartUpFaultCnt(ref SciRxBuff);
            Monitor_Data.sysFault.compProCnt = Get_compProCnt(ref SciRxBuff);
            Monitor_Data.sysFault.occuredCnt = Get_occuredCnt(ref SciRxBuff);
            Monitor_Data.sysFault.dlyTime = Get_dlyTime(ref SciRxBuff);
            Monitor_Data.sysFault.offTimer = Get_offTime(ref SciRxBuff);
            // 保護限頻資訊
            Monitor_Data.sysFreqPro.proNum = Get_proNum(ref SciRxBuff);
            Monitor_Data.sysFreqPro.proFreqGrade = Get_proFreqGrade(ref SciRxBuff);
            Monitor_Data.sysFreqPro.resetTime = Get_resetTime(ref SciRxBuff);
            // 室內故障狀態
            Monitor_Data.inFaultInfo.roomTempSensor = InFaultInfo("roomTempSensor", ref SciRxBuff);
            //Monitor_Data.inFaultInfo.inCoilinSensor = resp.InFaultInfo("inCoilInSensor", SciBuf.RxBuff);
            Monitor_Data.inFaultInfo.inCoilMidSensor = InFaultInfo("inCoilMidSensor", ref SciRxBuff);
            Monitor_Data.inFaultInfo.inFan = InFaultInfo("inFan", ref SciRxBuff);
            Monitor_Data.inFaultInfo.inCoilFreeze = InFaultInfo("inCoilFreeze", ref SciRxBuff);
            Monitor_Data.inFaultInfo.inCoilExcHeat = InFaultInfo("inCoilExcHeat", ref SciRxBuff);
            // 室外故障狀態1
            Monitor_Data.FaultInfo.IPMFault = Fault1Info("IPMFault", ref SciRxBuff);
            Monitor_Data.FaultInfo.outTempSensor = Fault1Info("outTempSensor", ref SciRxBuff);
            Monitor_Data.FaultInfo.outCoilMidSensor = Fault1Info("outCoilMidSensor", ref SciRxBuff);
            Monitor_Data.FaultInfo.suctionSensor = Fault1Info("suctionSensor", ref SciRxBuff);
            Monitor_Data.FaultInfo.discharSensor = Fault1Info("discharSensor", ref SciRxBuff);
            Monitor_Data.FaultInfo.curSensor = Fault1Info("curSensor", ref SciRxBuff);
            // 室外故障狀態2
            Monitor_Data.FaultInfo.IPMSensorErr = Fault2Info("IPMSensorErr", ref SciRxBuff);
            Monitor_Data.FaultInfo.outFanMotor = Fault2Info("outFanMotor", ref SciRxBuff);
            Monitor_Data.FaultInfo.communicate = Fault2Info("communicate", ref SciRxBuff);
            Monitor_Data.FaultInfo.iacOver = Fault2Info("iacOver", ref SciRxBuff);
            Monitor_Data.FaultInfo.VacLow = Fault2Info("VacLow", ref SciRxBuff);
            Monitor_Data.FaultInfo.VacHigh = Fault2Info("VacHigh", ref SciRxBuff);
            // 馬達故障狀態
            Monitor_Data.FaultInfo.MotorFault = Get_MotorFault(ref SciRxBuff);
            // 室外保護狀態1
            Monitor_Data.ProtectInfo.ipmTemp = Protect_Code1("ipmTemp", ref SciRxBuff);
            Monitor_Data.ProtectInfo.iacOverCur = Protect_Code1("icaOverCur", ref SciRxBuff);
            Monitor_Data.ProtectInfo.discharTemp = Protect_Code1("discharTemp", ref SciRxBuff);
            Monitor_Data.ProtectInfo.compTopTemp = Protect_Code1("compTopTemp", ref SciRxBuff);
            Monitor_Data.ProtectInfo.suctionTemp = Protect_Code1("suctionTemp", ref SciRxBuff);
            Monitor_Data.ProtectInfo.iacLowCur = Protect_Code1("iacLowCur", ref SciRxBuff);
            // 室外保護狀態2
            Monitor_Data.ProtectInfo.disPressure = Protect_Code2("disPressure", ref SciRxBuff);
            Monitor_Data.ProtectInfo.outCoilTemp = Protect_Code2("outCoilTemp", ref SciRxBuff);
            Monitor_Data.ProtectInfo.outTemp = Protect_Code2("outTemp", ref SciRxBuff);
            Monitor_Data.ProtectInfo.inCoilFreeze = Protect_Code2("inCoilFreeze", ref SciRxBuff);
            Monitor_Data.ProtectInfo.inCoilOverTemp = Protect_Code2("inCoilOverTemp", ref SciRxBuff);
            Monitor_Data.ProtectInfo.sysErrReset = Protect_Code2("sysErrReset", ref SciRxBuff);
            // 頻率限制狀態
            Monitor_Data.Freqlimit.Infan_Lo_Pro = Get_FreqProNum("INFAN_LO_PRO", ref SciRxBuff);
            Monitor_Data.Freqlimit.Ic_Ol_Pro = Get_FreqProNum("IC_OL_PRO", ref SciRxBuff);
            Monitor_Data.Freqlimit.Vbus_Pro = Get_FreqProNum("VBUS_PRO", ref SciRxBuff);
            Monitor_Data.Freqlimit.Iac_Pro = Get_FreqProNum("IAC_PRO", ref SciRxBuff);
            Monitor_Data.Freqlimit.Discharge_Pro = Get_FreqProNum("DISCHARGE_PRO", ref SciRxBuff);
            Monitor_Data.Freqlimit.HinCoil_Pro = Get_FreqProNum("HINCOIL_PRO", ref SciRxBuff);
            Monitor_Data.Freqlimit.RoutCoil_Pro = Get_FreqProNum("ROUTCOIL_PRO", ref SciRxBuff);
            Monitor_Data.Freqlimit.RinCoil_Pro = Get_FreqProNum("RINCOIL_PRO", ref SciRxBuff);
        }

        /// <summary>
        /// 取得版本信息
        /// </summary>
        /// <param name="RxBuff"></param>
        /// <returns></returns>
        public int Get_Version(ref byte[] RxBuff)
        {
            int value = Convert.ToInt32(RxBuff[VERSION]);
            return value;
        }

        /// <summary>
        /// 取得序號
        /// </summary>
        /// <param name="RxBuff"></param>
        /// <returns></returns>
        public int Get_SerialNum(ref byte[] RxBuff)
        {
            int value = Convert.ToInt32(RxBuff[SERIALNUM]);
            return value;
        }

        /// <summary>
        /// 取得系統時間
        /// </summary>
        /// <param name="RxBuff"></param>
        /// <returns></returns>
        public int Get_SysTime(ref byte[] RxBuff)
        {
            int value = Convert.ToInt32(RxBuff[SYSTIME_3]) +
                Convert.ToInt32(RxBuff[SYSTIME_2]) * 256 +
                Convert.ToInt32(RxBuff[SYSTIME_1]) * 65536;
            return value;
        }

        #region 馬達運行狀態

        /// <summary>
        /// 取得極對數
        /// </summary>
        /// <param name="RxBuff"></param>
        /// <returns></returns>
        public int Get_PolePair(ref byte[] RxBuff)
        {
            int PolePair = Convert.ToInt32(RxBuff[POLE_PAIR]);
            return PolePair;
        }

        /// <summary>
        /// 計算設定轉速 (rps / rpm )
        /// s = 0, return rps; s = 1, return rpm
        /// </summary>
        public int CalcSetSpeed(ref byte[] RxBuff, int s)
        {
            int value = 0;
            int PolePair = Convert.ToInt32(RxBuff[POLE_PAIR]);
            if (PolePair <= 0) PolePair = 1;
            value = Convert.ToInt32(RxBuff[SET_SPEED]);
            int SetSpeed_rps = value / PolePair;     // rps
            value = value * 60 / PolePair;
            int SetSpeed_rpm = value;                // rpm

            if (s == 0)         
                return SetSpeed_rps;
            else    
                return SetSpeed_rpm;
        }

        /// <summary>
        /// 計算實際轉速 (rps /rpm)
        /// s = 0, return rps; s = 1, return rpm        
        /// </summary>
        public int CalcRealSpeed(ref byte[] RxBuff, int s)
        {
            int value = 0;
            int PolePair = Convert.ToInt32(RxBuff[POLE_PAIR]);
            if (PolePair <= 0) PolePair = 1;
            value = Convert.ToInt32(RxBuff[REAL_SPEED]);
            int RealSpeed_rps = value / PolePair;     // rps
            value = value * 60 / PolePair;
            int RealSpeed_rpm = value;                // rpm

            if (s == 0)
                return RealSpeed_rps;
            else
                return RealSpeed_rpm;
        }

        /// <summary>
        /// 計算 AC 電壓
        /// </summary>
        public int CalcACVoltage(ref byte[] RxBuff)
        {
            Int32 value = Convert.ToInt32(RxBuff[AC_VOLTAGE]) * 2;
            return value;
        }

        /// <summary>
        /// 計算 AC 電流
        /// </summary>
        /// <param name="RxBuff"></param>
        /// <returns></returns>
        public double CalcACCurrent(ref byte[] RxBuff)
        {
            Double value = (double)(Convert.ToInt32(RxBuff[AC_CURRENT])) / (double)10.0;
            return value;
        }

        /// <summary>
        /// 計算 DC 電壓
        /// </summary>
        public int CalcDCVoltage(ref byte[] RxBuff)
        {
            Int32 value = Convert.ToInt32(RxBuff[DC_VOLTAGE]) * 2;
            return value;
        }

        /// <summary>
        /// 計算平均d軸電壓開度
        /// </summary>
        /// <param name="RxBuff"></param>
        /// <returns></returns>
        public double CalcVdVolt(ref byte[] RxBuff)
        {
            Int32 temp = RxBuff[VD_VOLT];
            if (temp > 127) temp = -(256 - temp);
            Double value = (double)(Convert.ToInt32(temp)) / (double)100.0;
            value = Math.Round(value, 2);
            return value;
        }

        /// <summary>
        /// 平算平均q軸電壓開度
        /// </summary>
        /// <param name="RxBuff"></param>
        /// <returns></returns>
        public double CalcVqVolt(ref byte[] RxBuff)
        {
            Int32 temp = RxBuff[VQ_VOLT];
            if (temp > 127) temp = -(256 - temp);
            Double value = (double)(Convert.ToInt32(temp)) / (double)100.0;
            value = Math.Round(value, 2);
            return value;
        }

        /// <summary>
        /// 計算 d 軸電流
        /// </summary>
        /// <param name="RxBuff"></param>
        /// <returns></returns>
        public double CalcIdCurrent(ref byte[] RxBuff)
        {
            Int32 temp = RxBuff[ID_CURRENT];
            Double value = (double)((double)Convert.ToInt32(temp) / (double)10.0);
            value = Math.Round(value, 2);
            return value;
        }

        /// <summary>
        /// 計算 q 軸電流
        /// </summary>
        public double CalcIqCurrent(ref byte[] RxBuff)
        {
            Int32 temp = RxBuff[IQ_CURRENT];
            //if (temp > 128) temp -= 256;
            Double value = (double)((double)Convert.ToInt32(temp)) / (double)10.0;
            value = Math.Round(value, 2);
            return value;
        }

        /// <summary>
        /// 計算功率
        /// </summary>
        public double CalcPower(ref byte[] RxBuff)
        {
            Double value1 = (double)(Convert.ToInt32(RxBuff[AC_VOLTAGE])) * (double)2.0;
            Double value2 = (double)(Convert.ToInt32(RxBuff[AC_CURRENT])) / (double)10.0;
            Double value3 = value1 * value2;
            value3 = Math.Round(value3, 2);
            return value3;
        }

        /// <summary>
        /// 計算IPM溫度
        /// </summary>
        public int CalcIPMTemp(ref byte[] RxBuff)
        {
            Int32 value = Convert.ToInt32(RxBuff[IPM_TEMP]);
            return value;
        }

        /// <summary>
        /// 計算DC風扇轉速
        /// </summary>
        public int CalcDCFanSpeed(ref byte[] RxBuff)
        {
            Int32 value = Convert.ToInt32(RxBuff[DCFAN_SPEED_L]) + (Convert.ToInt32(RxBuff[DCFAN_SPEED_H]) << 8);
            return value;
        }

        /// <summary>
        /// 取得 PFC 狀態
        /// </summary>
        public int GetPFCState(ref byte[] RxBuff)
        {
            int PFCState = Convert.ToInt32(RxBuff[PFC_STATE]);
            return PFCState;
        }

        /// <summary>
        /// 取得四通閥狀態
        /// </summary>
        public int GetFourWayValveState(ref byte[] RxBuff)
        {
            int FourWayValveState = Convert.ToInt32(RxBuff[FORUWAY_VALVE_STATE]);
            return FourWayValveState;
        }

        /// <summary>
        /// 取得主繼電器狀態
        /// </summary>
        /// <param name="RxBuff"></param>
        /// <returns></returns>
        public int GetMainRelayState(ref byte[] RxBuff)
        {
            int MainRelayState = Convert.ToInt32(RxBuff[MAIN_RELAY_STATE]);
            return MainRelayState;
        }

        /// <summary>
        /// 取得系統操作模式
        /// </summary>
        public int GetOpMode(ref byte[] RxBuff)
        {
            // 0 : Auto  1: Manual
            int OpMode = Convert.ToInt32(RxBuff[OP_MODE]);
            return OpMode;
        }

        #endregion

        #region 室內外機溫度

        /// <summary>
        /// 室內環境溫度 roomTemp
        /// </summary>
        public int roomTemp(ref byte[] RxBuff)
        {
            int value = Convert.ToInt32(RxBuff[ROOM_TEMP]);
            if (value > 127) value -= 256;
            return value;
        }

        /// <summary>
        /// 室內銅管溫度 inCoilTemp
        /// </summary>
        /// <param name="RxBuff"></param>
        /// <returns></returns>
        public int inCoilTemp(ref byte[] RxBuff)
        {
            int value = Convert.ToInt32(RxBuff[INCOIL_TEMP]);
            if (value > 127) value -= 256;
            return value;
        }

        /// <summary>
        /// 室外環境溫度
        /// </summary>
        /// <param name="RxBuff"></param>
        /// <returns></returns>
        public int outDoorTemp(ref byte[] RxBuff)
        {
            int value = Convert.ToInt32(RxBuff[OUTDOOR_TEMP]);
            if (value > 127) value -= 256;
            return value;
        }

        /// <summary>
        /// 室外銅管溫度 outCoilTemp
        /// </summary>
        /// <param name="RxBuff"></param>
        /// <returns></returns>
        public int outCoilTemp(ref byte[] RxBuff)
        {
            int value = Convert.ToInt32(RxBuff[OUTCOIL_TEMP]);
            if (value > 127) value -= 256;
            return value;
        }

        /// <summary>
        /// 壓縮機排氣溫度 disChargeTemp
        /// </summary>
        /// <param name="RxBuff"></param>
        /// <returns></returns>
        public int disChargeTemp(ref byte[] RxBuff)
        {
            int value = Convert.ToInt32(RxBuff[DISCHARGE_TEMP]);
            if (value > 127) value -= 256;
            return value;
        }

        /// <summary>
        /// 壓縮機入口溫度
        /// </summary>
        /// <param name="RxBuff"></param>
        /// <returns></returns>
        public int suctionTemp(ref byte[] RxBuff)
        {
            int value = Convert.ToInt32(RxBuff[SUCTION_TEMP]);
            if (value > 127) value -= 256;
            return value;
        }

        /// <summary>
        /// 室內設定溫度
        /// </summary>
        /// <param name="RxBuff"></param>
        /// <returns></returns>
        public int setTemp(ref byte[] RxBuff)
        {
            int value = Convert.ToInt32(RxBuff[SET_TEMP]);
            if (value > 127) value -= 256;
            return value;
        }

        #endregion

        #region 電機狀態 Motor State

        /// <summary>
        /// 取得電機狀態
        /// </summary>
        /// <param name="RxBuff"></param>
        /// <returns></returns>
        public int Get_MotorState(ref byte[] RxBuff)
        {
            Int32 value = Convert.ToInt32(RxBuff[MOTORSTATE]);
            return value;
        }

        /// <summary>
        /// 取得壓縮機狀態計數
        /// </summary>
        /// <param name="RxBuff"></param>
        /// <returns></returns>
        public int Get_MotorStateCnt(ref byte[] RxBuff)
        {
            Int32 value = Convert.ToInt32(RxBuff[MOTOR_ST_CNT_LO]) + (Convert.ToInt32(RxBuff[MOTOR_ST_CNT_HI]) << 8);
            return value;
        }

        /// <summary>
        /// 室外風機狀態
        /// </summary>
        /// <param name="RxBuff"></param>
        /// <returns></returns>
        public int Get_OutFanState(ref byte[] RxBuff)
        {
            Int32 value = Convert.ToInt32(RxBuff[DCFAN_STATE]);
            return value;
        }

        /// <summary>
        /// 室外風機狀態計數
        /// </summary>
        /// <param name="RxBuff"></param>
        /// <returns></returns>
        public int Get_OurFanStateCnt(ref byte[] RxBuff)
        {
            Int32 value = Convert.ToInt32(RxBuff[OUTFANST_LO]) + (Convert.ToInt32(RxBuff[OUTFANST_HI] << 8));
            return value;
        }

        #endregion

        #region 室內機運行模式 / 狀態

        /// <summary>
        /// 室內機運行模式
        /// </summary>
        /// <param name="RxBuff"></param>
        public WORK_MODE Get_inMode(ref byte[] RxBuff)
        {
            Int32 value = Convert.ToInt32(RxBuff[INMODE]);
            WORK_MODE mode = WORK_MODE.WMS_OFF;
            switch (value)
            {
                case 0x00:
                    mode = WORK_MODE.WMS_OFF;
                    break;
                case 0x01:
                    mode = WORK_MODE.WMS_REFRIGERATING;
                    break;
                case 0x02:
                    mode = WORK_MODE.WMS_WIND;
                    break;
                case 0x03:
                    mode = WORK_MODE.WMS_DEHUMIDIFIERING;
                    break;
                case 0x07:
                    mode = WORK_MODE.WMS_HEATING;
                    break;
                case 0x08:
                    mode = WORK_MODE.WMS_AUTO;
                    break;
                case 0x09:
                    mode = WORK_MODE.WMS_TESTING;
                    break;
                case 0x0A:
                    mode = WORK_MODE.WMS_WARMUP;
                    break;
                case 0x0B:
                    mode = WORK_MODE.WMS_COOL_TESTING;
                    break;
                case 0x0C:
                    mode = WORK_MODE.WMS_HEAT_TESTING;
                    break;
            }
            return mode;
        }

        /// <summary>
        /// 室內機運行附加模式
        /// </summary>
        /// <param name="RxBuff"></param>
        public SUB_MODE Get_inModeApp(ref byte[] RxBuff)
        {
            Int32 value = Convert.ToInt32(RxBuff[INMODEAPP]);
            SUB_MODE subMode = SUB_MODE.NO_SUB;
            switch (value)
            {
                case 0x00:
                    subMode = SUB_MODE.NO_SUB;
                    break;
                case 0x01:
                    subMode = SUB_MODE.SUB_FORCE;
                    break;
                case 0x02:
                    subMode = SUB_MODE.SUB_TEST;
                    break;
                case 0x03:
                    subMode = SUB_MODE.SUB_SLEEP;
                    break;
                case 0x08:
                    subMode = SUB_MODE.SUB_ECONO;
                    break;
                case 0x10:
                    subMode = SUB_MODE.SUB_POWER;
                    break;
                case 0x20:
                    subMode = SUB_MODE.SUB_QUITE;
                    break;
                case 0x80:
                    subMode = SUB_MODE.SUB_VENTILATE;
                    break;
            }
            return subMode;
        }

        /// <summary>
        /// 測試模式
        /// </summary>
        /// <param name="RxBuff"></param>
        public int Get_testCmd(ref byte[] RxBuff)
        {
            Int32 value = Convert.ToInt32(RxBuff[TESTCMD]);
            return value;
        }

        /// <summary>
        /// 室內風機等級
        /// </summary>
        /// <param name="RxBuff"></param>
        public int Get_inFanGrade(ref byte[] RxBuff)
        {
            Int32 value = Convert.ToInt32(RxBuff[INFANGRADE]);
            return value;
        }

        /// <summary>
        /// 錯誤代碼
        /// </summary>
        /// <param name="RxBuff"></param>
        /// <returns></returns>
        public int Get_inFaultCode(ref byte[] RxBuff)
        {
            Int32 value = Convert.ToInt32(RxBuff[PROTECT_ERR]);
            return value;
        }

        /// <summary>
        /// 限頻代碼
        /// </summary>
        /// <param name="RxBuff"></param>
        /// <returns></returns>
        public int Get_inLimCode(ref byte[] RxBuff)
        {
            Int32 value = Convert.ToInt32(RxBuff[PROTECT_LIM]);
            return value;
        }
        
        #endregion

        #region 系統工作模式

        /// <summary>
        /// 系統狀態 SYS_STATE
        /// </summary>
        /// <param name="RxBuff"></param>
        public SYS_STATE GET_SYS_STATE(ref byte[] RxBuff)
        {
            Int32 value = Convert.ToInt32(RxBuff[STATE]);
            SYS_STATE state = SYS_STATE.SYS_IDLE;
            switch(value)
            {
                case 0:
                    state = SYS_STATE.SYS_IDLE;
                    break;
                case 1:
                    state = SYS_STATE.SYS_RESET;
                    break;
                case 2:
                    state = SYS_STATE.SYS_FAULT;
                    break;
                case 3:
                    state = SYS_STATE.SYS_PROTECT;
                    break;
                case 4:
                    state = SYS_STATE.SYS_RUN;
                    break;
                case 5:
                    state = SYS_STATE.SYS_OFF_DLY;
                    break;
                case 6:
                    state = SYS_STATE.SYS_POWERUP_DLY;
                    break;
            }
            return state;
        }

        /// <summary>
        /// 工作模式 WORK_MODE
        /// </summary>
        /// <param name="RxBuff"></param>
        /// <returns></returns>
        public WORK_MODE GET_WORK_MODE(ref byte[] RxBuff)
        {
            Int32 value = Convert.ToInt32(RxBuff[BASIC_RUNMODE]);
            WORK_MODE mode = WORK_MODE.WMS_OFF;
            switch(value)
            {
                case 0x00:
                    mode = WORK_MODE.WMS_OFF;
                    break;
                case 0x01:
                    mode = WORK_MODE.WMS_REFRIGERATING;
                    break;
                case 0x02:
                    mode = WORK_MODE.WMS_WIND;
                    break;
                case 0x03:
                    mode = WORK_MODE.WMS_DEHUMIDIFIERING;
                    break;
                case 0x07:
                    mode = WORK_MODE.WMS_HEATING;
                    break;
                case 0x08:
                    mode = WORK_MODE.WMS_AUTO;
                    break;
                case 0x09:
                    mode = WORK_MODE.WMS_TESTING;
                    break;
                case 0x0A:
                    mode = WORK_MODE.WMS_WARMUP;
                    break;
                case 0x0B:
                    mode = WORK_MODE.WMS_COOL_TESTING;
                    break;
                case 0x0C:
                    mode = WORK_MODE.WMS_HEAT_TESTING;
                    break;
            }
            return mode;
        }

        /// <summary>
        /// 子工作模式 SUB_MODE
        /// </summary>
        /// <param name="RxBuff"></param>
        /// <returns></returns>
        public SUB_MODE GET_SUB_MODE(ref byte[] RxBuff)
        {
            Int32 value = Convert.ToInt32(RxBuff[SUB_CMD]);
            SUB_MODE subMode = SUB_MODE.NO_SUB;
            switch(value)
            {
                case 0:
                    subMode = SUB_MODE.NO_SUB;
                    break;
                case 1:
                    subMode = SUB_MODE.SUB_FORCE;
                    break;
                case 2:
                    subMode = SUB_MODE.SUB_TEST;
                    break;
                case 3:
                    subMode = SUB_MODE.SUB_SLEEP;
                    break;
                case 4:
                    subMode = SUB_MODE.SUB_ECONO;
                    break;
                case 5:
                    subMode = SUB_MODE.SUB_POWER;
                    break;
                case 6:
                    subMode = SUB_MODE.SUB_QUITE;
                    break;
                case 7:
                    subMode = SUB_MODE.SUB_VENTILATE;
                    break;
            }
            return subMode;
        }

        /// <summary>
        /// 運行狀態 WORK_STATE
        /// </summary>
        /// <param name="RxBuff"></param>
        /// <returns></returns>
        public WORK_STATE GET_WORK_STATE(ref byte[] RxBuff)
        {
            Int32 value = Convert.ToInt32(RxBuff[WKSTATE]);
            WORK_STATE wkState = WORK_STATE.WS_IDLE;
            switch(value)
            {
                case 0:
                    wkState = WORK_STATE.WS_IDLE;
                    break;
                case 1: 
                    wkState = WORK_STATE.WS_STAR;
                    break;
                case 2:
                    wkState = WORK_STATE.WS_RUN;
                    break;
                case 3:
                    wkState = WORK_STATE.WS_OFFING;
                    break;
                case 4:
                    wkState = WORK_STATE.WS_OFF;
                    break;
            }
            return wkState;
        }

        /// <summary>
        /// 頻率狀態 FREQ_STATE
        /// </summary>
        /// <param name="RxBuff"></param>
        /// <returns></returns>
        public FREQ_STATE GET_FREQ_STATE(ref byte[] RxBuff)
        {
            Int32 value = Convert.ToInt32(RxBuff[FCSTATE]);
            FREQ_STATE fcState = FREQ_STATE.FREQ_STOP;
            switch(value)
            {
                case 0:
                    fcState = FREQ_STATE.FREQ_STOP;
                    break;
                case 1:
                    fcState = FREQ_STATE.FORCE_ZERO;
                    break;
                case 2:
                    fcState = FREQ_STATE.FORBID_STAR;
                    break;
                case 3:
                    fcState = FREQ_STATE.FREQ_STAR;
                    break;
                case 4:
                    fcState = FREQ_STATE.FREQ_AUTO;
                    break;
                case 5:
                    fcState = FREQ_STATE.FORCE_FALLING_80;
                    break;
                case 6:
                    fcState = FREQ_STATE.FORCE_FALLING_70;
                    break;
                case 7:
                    fcState = FREQ_STATE.FREQ_HOLDING;
                    break;
            }
            return fcState;
        }

        #endregion

        #region 溫控邏輯

        /// <summary>
        /// 取得溫度變化狀態
        /// </summary>
        /// <param name="RxBuff"></param>
        /// <returns></returns>
        public DTG_STATE Get_DTGState(ref byte[] RxBuff)
        {
            DTG_STATE state = DTG_STATE.DTG_ERROR;
            Int32 value = Convert.ToInt32(RxBuff[_DTG_STATE_]);
            switch(value)
            {
                case 0x00:
                    state = DTG_STATE.DTG_HOLDING;
                    break;
                case 0x01:
                    state = DTG_STATE.DTG_FALL;
                    break;
                case 0x02:
                    state = DTG_STATE.DTG_RISE;
                    break;
                case 0x03:
                    state = DTG_STATE.DTG_OFF;
                    break;
                default:
                    state = DTG_STATE.DTG_ERROR;
                    break;
            }
            return state;
        }

        /// <summary>
        /// 取得頻率區間保持時間
        /// </summary>
        /// <param name="RxBuff"></param>
        /// <returns></returns>
        public int Get_DTGTimer(ref byte[] RxBuff)
        {
            Int32 value = Convert.ToInt32(RxBuff[DTG_TIMER_LO]) + (Convert.ToInt32(RxBuff[DTG_TIMER_HI]) << 8);
            return value;
        }

        /// <summary>
        /// 取得上次溫度區間
        /// </summary>
        /// <param name="RxBuff"></param>
        /// <returns></returns>
        public int Get_tempGradeOld(ref byte[] RxBuff)
        {
            Int32 value = Convert.ToInt32(RxBuff[TEMPGRADE_OLD]);
            return value;
        }

        /// <summary>
        /// 取得本次溫度區間
        /// </summary>
        /// <param name="RxBuff"></param>
        /// <returns></returns>
        public int Get_tempGradeNow(ref byte[] RxBuff)
        {
            Int32 value = Convert.ToInt32(RxBuff[TEMPGRADE_NOW]);
            return value;
        }

        /// <summary>
        /// 取得計算頻率等級輸出
        /// </summary>
        /// <param name="RxBuff"></param>
        /// <returns></returns>
        public int Get_freqGradeOut(ref byte[] RxBuff)
        {
            Int32 value = Convert.ToInt32(RxBuff[FREQGRADE_OUT]);
            return value;
        }

        /// <summary>
        /// 室外機允許最大頻率等級
        /// </summary>
        /// <param name="RxBuff"></param>
        /// <returns></returns>
        public int Get_freqGradeMax(ref byte[] RxBuff)
        {
            Int32 value = Convert.ToInt32(RxBuff[FREQGRADE_MAX]);
            return value;
        }

        /// <summary>
        /// 取得溫度差
        /// </summary>
        /// <param name="RxBuff"></param>
        /// <returns></returns>
        public int Get_rsDeltaTemp(ref byte[] RxBuff)
        {
            Int32 value = Convert.ToInt32(RxBuff[RSDELTA_TEMP]);
            if (value > 127) value -= 256;
            return value;
        }

        /// <summary>
        /// 室外溫度限制最大頻率等級
        /// </summary>
        /// <param name="RxBuff"></param>
        /// <returns></returns>
        public int Get_oTempFreGMax(ref byte[] RxBuff)
        {
            Int32 value = Convert.ToInt32(RxBuff[OTEMPFREGMAX]);
            return value;
        }

        /// <summary>
        /// 室內風速限制最大頻率等級
        /// </summary>
        /// <param name="RxBuff"></param>
        /// <returns></returns>
        public int Get_inFanFreGMax(ref byte[] RxBuff)
        {
            Int32 value = Convert.ToInt32(RxBuff[INFANFREGMAX]);
            return value;
        }

        #endregion

        #region 除霜狀態資訊

        /// <summary>
        /// 取得除霜狀態資訊
        /// </summary>
        /// <param name="RxBuff"></param>
        public DEFRO_STATE Get_DEFRO_STATE(ref byte[] RxBuff)
        {
            Int32 value = Convert.ToInt32(RxBuff[DEFROSTCTRL]);
            DEFRO_STATE state = DEFRO_STATE.DEFRO_ERROR;
            switch(value)
            {
                case 0x00:
                    state = DEFRO_STATE.DEFRO_HEATING;
                    break;
                case 0x01:
                    state = DEFRO_STATE.DEFRO_STAR;
                    break;
                case 0x02:
                    state = DEFRO_STATE.DEFRO_RUN;
                    break;
                case 0x03:
                    state = DEFRO_STATE.DEFRO_END;
                    break;
                default:
                    state = DEFRO_STATE.DEFRO_ERROR;
                    break;
            }
            return state;
        }

        /// <summary>
        /// 取得 除霜-制熱流程切換計時器
        /// </summary>
        /// <param name="RxBuff"></param>
        /// <returns></returns>
        public int GET_DEFRO_timeCnt(ref byte[] RxBuff)
        {
            int value = Convert.ToInt32(RxBuff[DEFROTIMERCNT_LO]) + Convert.ToInt32(RxBuff[DEFROTIMERCNT_HI]) * 256;
            return value;
        }

        /// <summary>
        /// 取得 滿足除霜溫度時間計數器
        /// </summary>
        /// <param name="RxBuff"></param>
        /// <returns></returns>
        public int GET_DEFRO_timeTempCnt(ref byte[] RxBuff)
        {
            int value = Convert.ToInt32(RxBuff[TIMERTEMPCNT_LO]) + Convert.ToInt32(RxBuff[TIMERTEMPCNT_HI]) * 256;
            return value;
        }

        #endregion

        #region 錯誤資訊顯示

        /// <summary>
        /// 取得 故障-保護狀態
        /// </summary>
        /// <param name="RxBuff"></param>
        /// <returns></returns>
        public FAULT_STATE Get_FaultState(ref byte[] RxBuff)
        {
            FAULT_STATE state = FAULT_STATE.NO_FAULT;
            Int32 value = Convert.ToInt32(RxBuff[_FAULTSTATE_]);
            switch(value)
            {
                case 0x00:
                    state = FAULT_STATE.NO_FAULT;
                    break;
                case 0x01:
                    state = FAULT_STATE.FAULT;
                    break;
                case 0x02:
                    state = FAULT_STATE.PROTECT;
                    break;
                case 0x03:
                    state = FAULT_STATE.PROTECT_DELAY;
                    break;
                case 0x04:
                    state = FAULT_STATE.PROTECT_RESET;
                    break;
            }
            return state;
        }

        /// <summary>
        /// 取得 故障-保護編號
        /// </summary>
        /// <param name="RxBuff"></param>
        /// <returns></returns>
        public FAULT_CODE Get_FaultCode(ref byte[] RxBuff)
        {
            FAULT_CODE code = FAULT_CODE.FAULT_NONE;
            Int32 value = Convert.ToInt32(RxBuff[_FAULTCODE_]);
            switch (value)
            {
                case 0x00:
                    code = FAULT_CODE.FAULT_NONE;
                    break;
                case 0x01:
                    code = FAULT_CODE.FAULT_IPM;
                    break;
                case 0x02:
                    code = FAULT_CODE.FAULT_OUTEMP_SENSOR;
                    break;
                case 0x03:
                    code = FAULT_CODE.FAULT_OUTCOIL_SENSOR;
                    break;
                case 0x04:
                    code = FAULT_CODE.FAULT_SUCT_SENSOR;
                    break;
                case 0x05:
                    code = FAULT_CODE.FAULT_DISC_SENSOR;
                    break;
                case 0x06:
                    code = FAULT_CODE.FAULT_CUR_SENSOR;
                    break;
                case 0x07:
                    code = FAULT_CODE.FAULT_COMPRESS;
                    break;
                case 0x08:
                    code = FAULT_CODE.FAULT_PHASE;
                    break;
                case 0x09:
                    code = FAULT_CODE.FAULT_BACK_SENSOR;
                    break;
                case 0x0A:
                    code = FAULT_CODE.PROTECT_IPM;
                    break;
                case 0x0B:
                    code = FAULT_CODE.PROTECT_IAC;
                    break;
                case 0x0C:
                    code = FAULT_CODE.PROTECT_DISCHAR_TEMP;
                    break;
                case 0x0D:
                    code = FAULT_CODE.PROTECT_TOP_TEMP;
                    break;
                case 0x0E:
                    code = FAULT_CODE.PROTECT_SUCT_TEMP;
                    break;
                case 0x0F:
                    code = FAULT_CODE.PROTECT_VBUS;
                    break;
                case 0x10:
                    code = FAULT_CODE.PROTECT_LOW_PRESSURE;
                    break;
                case 0x11:
                    code = FAULT_CODE.PROTECT_OVER_PRESSURE;
                    break;
                case 0x12:
                    code = FAULT_CODE.PROTECT_INCOIL_TEMP;
                    break;
                case 0x13:
                    code = FAULT_CODE.PROTECT_OUTDOOR_TEMP;
                    break;
                case 0x14:
                    code = FAULT_CODE.FAULT_COMMUN;
                    break;
                case 0x15:
                    code = FAULT_CODE.FAULT_EEPROM;
                    break;
                case 0x16:
                    code = FAULT_CODE.FAULT_STAR;
                    break;
                case 0x17:
                    code = FAULT_CODE.FAULT_FANMOTOR;
                    break;
                case 0x18:
                    code = FAULT_CODE.PROTECT_IPM_TEMP;
                    break;
                case 0x19:
                    code = FAULT_CODE.PROTECT_IPM_SOFT_OVERCUR;
                    break;
                case 0x1A:
                    code = FAULT_CODE.FAULT_VBUS;
                    break;
                case 0x1B:
                    code = FAULT_CODE.PROTECT_COMMUN;
                    break;
                case 0x1C:
                    code = FAULT_CODE.PROTECT_STAR;
                    break;
                case 0x1D:
                    code = FAULT_CODE.FAULT_LACKFI;
                    break;
                case 0x1E:
                    code = FAULT_CODE.PROTECT_INERR;
                    break;
                case 0x1F:
                    code = FAULT_CODE.PROTECT_COM_DRIVER;
                    break;
                case 0x20:
                    code = FAULT_CODE.PROTECT_OUT_COIL_TEMP;
                    break;
                case 0x21:
                    code = FAULT_CODE.FAULT_FORCE_OFF;
                    break;
                case 0x22:
                    code = FAULT_CODE.FAULT_PFC;
                    break;
                case 0x23:
                    code = FAULT_CODE.FAULT_VAC;
                    break;
                case 0x24:
                    code = FAULT_CODE.FAULT_IPM_SENSOR;
                    break;
                case 0x25:
                    code = FAULT_CODE.PROTECT_IAC_LOW;
                    break;
                default:
                    code = FAULT_CODE.ERROR;                   
                    break;
            }
            return code;
        }

        /// <summary>
        /// 取得 IPM 保護次數
        /// </summary>
        /// <param name="RxBuff"></param>
        /// <returns></returns>
        public int Get_IPMFaultCnt(ref byte[] RxBuff)
        {
            Int32 value = Convert.ToInt32(RxBuff[IPMCNT]);
            return value;
        }

        /// <summary>
        /// 取得 啟動保護次數
        /// </summary>
        /// <param name="RxBuff"></param>
        /// <returns></returns>
        public int Get_StartUpFaultCnt(ref byte[] RxBuff)
        {
            Int32 value = Convert.ToInt32(RxBuff[STARCNT]);
            return value;
        }

        /// <summary>
        /// 取得 驅動保護次數
        /// </summary>
        /// <param name="RxBuff"></param>
        /// <returns></returns>
        public int Get_compProCnt(ref byte[] RxBuff)
        {
            Int32 value = Convert.ToInt32(RxBuff[COMPPROCNT]);
            return value;
        }

        /// <summary>
        /// 取得 故障-保護發生次數
        /// </summary>
        /// <param name="RxBuff"></param>
        /// <returns></returns>
        public int Get_occuredCnt(ref byte[] RxBuff)
        {
            Int32 value = Convert.ToInt32(RxBuff[OCCUREDCNT]);
            return value;
        }

        /// <summary>
        /// 取得故障延遲復位時間
        /// </summary>
        /// <param name="RxBuff"></param>
        /// <returns></returns>
        public int Get_dlyTime(ref byte[] RxBuff)
        {
            Int32 value = Convert.ToInt32(RxBuff[PROTIMECNT_LO]) + (Convert.ToInt32(RxBuff[PROTIMECNT_HI]) * 256);
            return value;
        }

        /// <summary>
        /// 取得保護關機流程計時時間
        /// </summary>
        /// <param name="RxBuff"></param>
        /// <returns></returns>
        public int Get_offTime(ref byte[] RxBuff)
        {
            Int32 value = Convert.ToInt32(RxBuff[OFFTIME_LO]) + (Convert.ToInt32(RxBuff[OFFTIME_HI])) * 256;
            return value;
        }

        #endregion

        #region 保護限頻資訊

        /// <summary>
        /// 取得降頻保護代碼
        /// </summary>
        /// <param name="RxBuff"></param>
        /// <returns></returns>
        public int Get_proNum(ref byte[] RxBuff)
        {
            Int32 value = Convert.ToInt32(RxBuff[PRONUM]);
            return value;
        }

        /// <summary>
        /// 取得降頻保護頻率檔位
        /// </summary>
        /// <param name="RxBuff"></param>
        /// <returns></returns>
        public int Get_proFreqGrade(ref byte[] RxBuff)
        {
            Int32 value = Convert.ToInt32(RxBuff[PROFREQGRADE]);
            return value;
        }

        /// <summary>
        /// 取得降頻保護恢復時間
        /// </summary>
        /// <param name="RxBuff"></param>
        /// <returns></returns>
        public int Get_resetTime(ref byte[] RxBuff)
        {
            Int32 value = Convert.ToInt32(RxBuff[RESETTIMER_LO]) + Convert.ToInt32(RxBuff[RESETTIMER_HI]) * 256 ;
            return value;
        }

        #endregion

        #region 故障保護狀態

        /// <summary>
        /// 室內故障狀態
        /// </summary>
        /// <param name="str"></param>
        /// <param name="RxBuff"></param>
        /// <returns></returns>
        public bool InFaultInfo(string str, ref byte[] RxBuff)
        {
            byte infault1 = RxBuff[IN_FAULT_CODE_1];
            byte infault2 = RxBuff[IN_FAULT_CODE_2];
            bool state = false;
            switch(str)
            {
                case "roomTempSensor":
                    // 室內環境溫度感測器故障
                    if ((infault1 & 0x80) == 0x80)
                        state = true;
                    break;
                case "inCoilInSensor":
                    // 室內蒸發器入口溫度感測器故障
                    break;
                case "inCoilMidSensor":
                    // 室內蒸發器中間溫度感測器故障
                    if ((infault1 & 0x20) == 0x20)
                        state = true;
                    break;
                case "inCoilOutSensor":
                    // 室內蒸發器出口溫度感測器故障
                    break;
                case "inFan":
                    // 室內風機故障
                    if ((infault1 & 0x08) == 0x08)
                        state = true;
                    break;
                case "inEeprom":
                    // 室內EEPROM故障
                    break;
                case "valveFI":
                    // 製冷系統缺氟或換相閥故障
                    break;
                case "zeroCheck":
                    // 過零檢測出錯故障
                    break;
                case "inCoilFreeze":
                    // 室內蒸發器溫度過低保護
                    if ((infault2 & 0x80) == 0x80)
                        state = true;
                    break;
                case "inCoilExcHeat":
                    // 室內蒸發器溫度過高保護
                    if ((infault2 & 0x40) == 0x40)
                        state = true;
                    break;
                default:
                    MessageBox.Show("Error : " + str);
                    break;
            }
            return state;
        }

        /// <summary>
        /// 室外故障狀態 1
        /// </summary>
        /// <param name="str"></param>
        /// <param name="RxBuff"></param>
        /// <returns></returns>
        public bool Fault1Info(string str, ref byte[] RxBuff)
        {
            byte faultCode = RxBuff[FAULT_CODE_1];
            bool state = false;
            switch(str)
            {
                case "IPMFault":
                    if ((faultCode & 0x80) == 0x80)
                        state = true;
                    break;
                case "outTempSensor":
                    if ((faultCode & 0x40) == 0x40)
                        state = true;
                    break;
                case "outCoilMidSensor":
                    if ((faultCode & 0x20) == 0x20)
                        state = true;
                    break;
                case "suctionSensor":
                    if ((faultCode & 0x10) == 0x10)
                        state = true;
                    break;
                case "discharSensor":
                    if ((faultCode & 0x08) == 0x08)
                        state = true;
                    break;
                case "curSensor":
                    if ((faultCode & 0x04) == 0x04)
                        state = true;
                    break;
                default:
                    MessageBox.Show("Error : " + str);
                    break;
            }

            return state;
        }

        /// <summary>
        /// 室外故障狀態 2
        /// </summary>
        /// <param name="str"></param>
        /// <param name="RxBuff"></param>
        /// <returns></returns>
        public bool Fault2Info(string str, ref byte[] RxBuff)
        {
            byte faultCode2 = RxBuff[FAULT_CODE_2];
            bool state = false;
            switch (str)
            {
                case "IPMSensorErr":
                    if ((faultCode2 & 0x80) == 0x80)
                        state = true;
                    break;
                case "outFanMotor":
                    if ((faultCode2 & 0x40) == 0x40)
                        state = true;
                    break;
                case "communicate":
                    if ((faultCode2 & 0x20) == 0x20)
                        state = true;
                    break;
                case "iacOver":
                    if ((faultCode2 & 0x08) == 0x08)
                        state = true;
                    break;
                case "VacLow":
                    if ((faultCode2 & 0x02) == 0x02)
                        state = true;
                    break;
                case "VacHigh":
                    if ((faultCode2 & 0x01) == 0x01)
                        state = true;
                    break;
                default:
                    MessageBox.Show("Error : " + str);
                    break;
            }
            return state;
        }

        /// <summary>
        /// 馬達故障狀態
        /// </summary>
        public MOTOR_FAULT Get_MotorFault(ref byte[] RxBuff)
        {
            MOTOR_FAULT MotorFault = MOTOR_FAULT.None;
            byte CompErr = RxBuff[CompProtect];
            switch (CompErr)
            {
                case 0:
                    MotorFault = MOTOR_FAULT.None;
                    break;
                case 1:
                    // 啟動故障
                    MotorFault = MOTOR_FAULT.StartUpErr;
                    break;
                case 2:
                    // 缺相保護
                    MotorFault = MOTOR_FAULT.PhaseLose;
                    break;
                case 3:
                    // 零速保護
                    MotorFault = MOTOR_FAULT.ZeroSpeed;
                    break;
                case 4:
                    // 失速保護
                    MotorFault = MOTOR_FAULT.LoseSpeed;
                    break;
                case 5:
                    // 過流保護
                    MotorFault = MOTOR_FAULT.ICompOver;
                    break;
                case 6:
                    // 相序錯誤
                    MotorFault = MOTOR_FAULT.PhaseErr;
                    break;
                default:
                    MotorFault = MOTOR_FAULT.None;
                    break;
            }
            return MotorFault;
        }

        /// <summary>
        /// 室外保護狀態1
        /// </summary>
        /// <param name="str"></param>
        /// <param name="RxBuff"></param>
        /// <returns></returns>
        public bool Protect_Code1(string str, ref byte[] RxBuff)
        {
            byte protCode1 = RxBuff[PRO_CODE_1];
            bool state = false;
            switch(str)
            {
                case "ipmTemp":
                    // IPM 過熱保護
                    if ((protCode1 & 0x80) == 0x80)
                        state = true;
                    break;
                case "iacOverCur":
                    // 交流輸入電流過大保護
                    if ((protCode1 & 0x40) == 0x40)
                        state = true;
                    break;
                case "discharTemp":
                    // 壓縮機排氣溫度保護
                    if ((protCode1 & 0x20) == 0x20)
                        state = true;
                    break;
                case "compTopTemp":
                    // 壓縮機頂部溫度過熱保護
                    if ((protCode1 & 0x10) == 0x10)
                        state = true;
                    break;
                case "suctionTemp":
                    // 壓縮機吸氣溫度保護
                    if ((protCode1 & 0x08) == 0x08)
                        state = true;
                    break;
                case "iacLowCur":
                    // 交流輸入電流過小保護
                    if ((protCode1 & 0x04) == 0x04)
                        state = true;
                    break;
                default:
                    break;
            }

            return state;
        }

        /// <summary>
        /// 室外保護狀態2
        /// </summary>
        /// <param name="str"></param>
        /// <param name="RxBuff"></param>
        /// <returns></returns>
        public bool Protect_Code2(string str, ref byte[] RxBuff)
        {
            byte protCode2 = RxBuff[PRO_CODE_2];
            bool state = false;
            switch(str)
            {
                case "disPressure":
                    // 排氣高壓保護
                    break;
                case "outCoilTemp":
                    // 室外冷凝管高溫保護
                    break;
                case "outTemp":
                    // 室外環境溫度高溫保護
                    break;
                case "inCoilFreeze":
                    // 室內蒸發器低溫保護
                    break;
                case "inCoilOverTemp":
                    // 室內蒸發器高溫保護
                    break;
                case "sysErrReset":
                    // 室外系統異常重定
                    break;
                default:
                    break;
            }
            return state;
        }

        /// <summary>
        /// 頻率限制狀態
        /// </summary>
        /// <param name="str"></param>
        /// <param name="RxBuff"></param>
        /// <returns></returns>
        public bool Get_FreqProNum(string str, ref byte[] RxBuff)
        {
            byte freqPro = RxBuff[FREQ_PRO_CODE];
            bool state = false;
            switch(str)
            {
                case "INFAN_LO_PRO":
                    // 室內機風扇限頻
                    if ((freqPro & 0x80) == 0x80)
                        state = true;
                    break;
                case "IC_OL_PRO":
                    // 壓縮機電流超載限頻保護
                    if ((freqPro & 0x40) == 0x40)
                        state = true;
                    break;
                case "VBUS_PRO":
                    // 母線電壓限頻保護
                    if ((freqPro & 0x20) == 0x20)
                        state = true;
                    break;
                case "IAC_PRO":
                    // 交流電流限頻保護
                    if ((freqPro & 0x10) == 0x10)
                        state = true;
                    break;
                case "DISCHARGE_PRO":
                    // 排氣高溫限頻保護
                    if ((freqPro & 0x08) == 0x08)
                        state = true;
                    break;
                case "HINCOIL_PRO":
                    // 製熱室內盤管防過熱限頻保護
                    if ((freqPro & 0x04) == 0x04)
                        state = true;
                    break;
                case "ROUTCOIL_PRO":
                    // 製冷室內盤管防過熱限頻保護
                    if ((freqPro & 0x02) == 0x02)
                        state = true;
                    break;
                case "RINCOIL_PRO":
                    // 製冷室內盤管凍結限頻保護
                    if ((freqPro & 0x01) == 0x01)
                        state = true;
                    break;
                default:
                    break;
            }
            return state;
        }

        #endregion
    }
}

﻿ using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace CS6257_Monitor
{
    public class ResolvePack2
    {
        public const int STATE = 1;
        public const int MOTORSTATE = 2;
        public const int FAULT_CODE = 3;
        public const int POLE_PAIR = 5;
        public const int SET_SPEED_HI = 6;
        public const int SET_SPEED_LO = 7;
        public const int REAL_SPEED_HI = 8;
        public const int REAL_SPEED_LO = 9;
        public const int CompProtect = 4;
        public const int AC_VOLTAGE = 11;
        public const int AC_CURRENT = 12;
        public const int DC_VOLTAGE = 10;
        public const int IQ_CURRENT = 13;
        public const int IQ_CURRENT_H = 13;
        public const int IQ_CURRENT_L = 14;

        // 系統狀態
        public enum SYS_STATE
        {
            SYS_IDLE,       // 系統待機
            SYS_RESET,      // 系統重置
            SYS_FAULT,      // 系統錯誤
            SYS_PROTECT,    // 系統保護
            SYS_RUN,        // 系統正常運行
            SYS_OFF_DLY,    // 延遲停機
            SYS_POWERUP_DLY // 延遲啟動
        }

        public enum MOTOR_STATE
        {
            MOTOR_STOP,
            MOTOR_STARTUP,
            MOTOR_RUN
        }

        public struct MOTORRUN_INFO
        {
            public int SetSpeed_rps;        // 設定轉速 (rps)
            public int SetSpeed_rpm;        // 設定轉速 (rpm)
            public int RealSpeed_rps;       // 實際轉速 (rps)
            public int RealSpeed_rpm;       // 實際轉速 (rpm)

            public int ACVoltage;           // AC 電壓
            public double ACCurrent;        // AC 電流
            public int DCVoltage;           // DC 電壓
            public double dVolt;            // d軸電壓
            public double qVolt;            // q軸電壓
            public double IdCurrent;        // d軸電流
            public double IqCurrent;        // 轉矩電流

            public double Power;            // 入電功率
            public int IPMTemp;             // IPM 溫度
            public int PFCState;            // PFC 狀態

            public int MainRelayState;      // 主繼電器狀態
            public int OpMode;              // 操作模式
            public int FirmwareVersion;     // 韌體版本
            public int SysTime;             // 系統運行時間
        }

        public enum MOTOR_FAULT
        {
            None,                           // 無
            StartUpErr,                     // 啟動故障
            PhaseLose,                      // 缺相保護
            ZeroSpeed,                      // 零速保護
            LoseSpeed,                      // 失速保護
            ICompOver,                      // 過流保護
            PhaseErr                        // 相序錯誤
        }

        public struct FAULT_INFO
        {
            public bool IPMFault;           // IPM模組故障
            public bool VacHi;              // AC 電壓過高
            public bool VacLo;              // AC 電壓過低
            public bool IacOver;            // AC 電流過高
            public bool vBusHi;              // DC 電壓過高
            public bool vBusLo;              // DC 電壓過低
            public bool CurSensorErr;        // 取樣電路異常
            // 馬達故障狀態
            public MOTOR_FAULT MotorFault;
        }

        public struct DISP_DATA
        {
            public int PolePair;
            public SYS_STATE state;                // 系統狀態
            public MOTORRUN_INFO MotorRunInfo;
            public MOTOR_STATE motorState;
            //public SYSRUN_INFO SysRunInfo;
            //public DTGGRADE_FREQ fgCtrl;
            //public DEFROST defro;
            //public SYS_FAULT sysFault;
            //public STR_SYSPROTECT sysFreqPro;
            //public TEMPERATURE Temperature;
            //public INFAULT_INFO inFaultInfo;
            public FAULT_INFO FaultInfo;
            //public PROTECT_INFO ProtectInfo;
            //public FREQ_LIMIT Freqlimit;
        }

        private byte[] SciRxBuff;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="RxBuff_ref"></param>
        public ResolvePack2(ref byte[] RxBuff_ref)
        {
            SciRxBuff = RxBuff_ref;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="Disp_Data"></param>
        public void Update(ref DISP_DATA Disp_Data)
        {
            // 系統運行狀態
            Disp_Data.state = GET_SYS_STATE(ref SciRxBuff);
            Disp_Data.motorState = GET_MOTOR_STATE(ref SciRxBuff);

            // 馬達運行狀態
            Disp_Data.PolePair = Get_PolePair(ref SciRxBuff);
            Disp_Data.MotorRunInfo.SetSpeed_rps = CalcSetSpeed(ref SciRxBuff, 0);
            Disp_Data.MotorRunInfo.SetSpeed_rpm = CalcSetSpeed(ref SciRxBuff, 1);

            Disp_Data.MotorRunInfo.RealSpeed_rps = CalcRealSpeed(ref SciRxBuff, 0);
            Disp_Data.MotorRunInfo.RealSpeed_rpm = CalcRealSpeed(ref SciRxBuff, 1);

            Disp_Data.MotorRunInfo.ACVoltage = CalcACVoltage(ref SciRxBuff);
            Disp_Data.MotorRunInfo.ACCurrent = CalcACCurrent(ref SciRxBuff);

            Disp_Data.MotorRunInfo.DCVoltage = CalcDCVoltage(ref SciRxBuff);

            Disp_Data.MotorRunInfo.IqCurrent = CalcIqCurrent(ref SciRxBuff);

            Disp_Data.MotorRunInfo.Power = CalcPower(ref SciRxBuff);

            Disp_Data.FaultInfo.IPMFault = FaultInfo("IPMFault", ref SciRxBuff);
            Disp_Data.FaultInfo.VacHi = FaultInfo("VacHi", ref SciRxBuff);
            Disp_Data.FaultInfo.VacLo = FaultInfo("VacLo", ref SciRxBuff);

            Disp_Data.FaultInfo.IacOver = FaultInfo("IacOver", ref SciRxBuff);

            Disp_Data.FaultInfo.vBusHi = FaultInfo("vBusHi", ref SciRxBuff);
            Disp_Data.FaultInfo.vBusLo = FaultInfo("vBusLo", ref SciRxBuff);

            Disp_Data.FaultInfo.CurSensorErr = FaultInfo("CurSensorErr", ref SciRxBuff);

            // 馬達故障狀態
            Disp_Data.FaultInfo.MotorFault = Get_MotorFault(ref SciRxBuff);
        }



        #region 馬達運行狀態

        /// <summary>
        /// 系統狀態 SYS_STATE
        /// </summary>
        /// <param name="RxBuff"></param>
        public SYS_STATE GET_SYS_STATE(ref byte[] RxBuff)
        {
            Int32 value = Convert.ToInt32(RxBuff[STATE]);
            SYS_STATE state = SYS_STATE.SYS_IDLE;
            switch (value)
            {
                case 0:
                    state = SYS_STATE.SYS_IDLE;
                    break;
                case 1:
                    state = SYS_STATE.SYS_RESET;
                    break;
                case 2:
                    state = SYS_STATE.SYS_FAULT;
                    break;
                case 3:
                    state = SYS_STATE.SYS_PROTECT;
                    break;
                case 4:
                    state = SYS_STATE.SYS_RUN;
                    break;
                case 5:
                    state = SYS_STATE.SYS_OFF_DLY;
                    break;
                case 6:
                    state = SYS_STATE.SYS_POWERUP_DLY;
                    break;
            }
            return state;
        }

        /// <summary>
        /// 
        /// </summary>
        public MOTOR_STATE GET_MOTOR_STATE(ref byte[] RxBuff)
        {
            Int32 value = Convert.ToInt32(RxBuff[MOTORSTATE]);
            MOTOR_STATE state = MOTOR_STATE.MOTOR_STOP;
            switch(value)
            {
                case 0:
                    state = MOTOR_STATE.MOTOR_STOP;
                    break;
                case 1:
                    state = MOTOR_STATE.MOTOR_STARTUP;
                    break;
                default:
                    state = MOTOR_STATE.MOTOR_RUN;
                    break;
            }
            return state;
        }

        /// <summary>
        /// 取得極對數
        /// </summary>
        /// <param name="RxBuff"></param>
        /// <returns></returns>
        public int Get_PolePair(ref byte[] RxBuff)
        {
            int PolePair = Convert.ToInt32(RxBuff[POLE_PAIR]);
            return PolePair;
        }

        /// <summary>
        /// 計算設定轉速 (rps / rpm )
        /// s = 0, return rps; s = 1, return rpm
        /// </summary>
        public int CalcSetSpeed(ref byte[] RxBuff, int s)
        {
            double value = 0;
            int PolePair = Convert.ToInt32(RxBuff[POLE_PAIR]);
            if (PolePair <= 0) PolePair = 1;
            value = Convert.ToInt32(RxBuff[SET_SPEED_LO]) + Convert.ToInt32(RxBuff[SET_SPEED_HI]) * 256; ;
            value = value / 100;
            double SetSpeed_rps = value / PolePair;     // rps
            value = value * 60 / PolePair;
            double SetSpeed_rpm = value;                // rpm

            if (s == 0)
                return (int)SetSpeed_rps;
            else
                return (int)SetSpeed_rpm;
        }

        /// <summary>
        /// 計算實際轉速 (rps /rpm)
        /// s = 0, return rps; s = 1, return rpm        
        /// </summary>
        public int CalcRealSpeed(ref byte[] RxBuff, int s)
        {
            double value = 0;
            int PolePair = Convert.ToInt32(RxBuff[POLE_PAIR]);
            if (PolePair <= 0) PolePair = 1;
            value = Convert.ToInt32(RxBuff[REAL_SPEED_LO]) + Convert.ToInt32(RxBuff[REAL_SPEED_HI]) * 256;
            value = value / 100;
            double RealSpeed_rps = value / PolePair;     // rps
            value = value * 60 / PolePair;
            double RealSpeed_rpm = value;                // rpm

            if (s == 0)
                return (int)RealSpeed_rps;
            else
                return (int)RealSpeed_rpm;
        }

        /// <summary>
        /// 計算 AC 電壓
        /// </summary>
        public int CalcACVoltage(ref byte[] RxBuff)
        {
            Int32 value = Convert.ToInt32(RxBuff[AC_VOLTAGE]) * 2;
            return value;
        }

        /// <summary>
        /// 計算 AC 電流
        /// </summary>
        /// <param name="RxBuff"></param>
        /// <returns></returns>
        public double CalcACCurrent(ref byte[] RxBuff)
        {
            Double value = (double)(Convert.ToInt32(RxBuff[AC_CURRENT])) / (double)10.0;
            return value;
        }

        /// <summary>
        /// 計算 DC 電壓
        /// </summary>
        public int CalcDCVoltage(ref byte[] RxBuff)
        {
            Int32 value = Convert.ToInt32(RxBuff[DC_VOLTAGE]) * 2;
            return value;
        }

        /// <summary>
        /// 計算 q 軸電流
        /// </summary>
        public double CalcIqCurrent(ref byte[] RxBuff)
        {
            //Int32 temp = RxBuff[IQ_CURRENT];
            Int32 temp = Convert.ToInt32(RxBuff[IQ_CURRENT_L]) + Convert.ToInt32(RxBuff[IQ_CURRENT_H]) * 256;
            //if (temp >= 128) temp -= 256;
            if (temp >= 32768) temp -= 65536;
            Double value = (double)((double)(temp) / (double)65536.0 * (double)20.0);
            return value;
        }

        /// <summary>
        /// 計算功率
        /// </summary>
        public double CalcPower(ref byte[] RxBuff)
        {
            Double value1 = (double)(Convert.ToInt32(RxBuff[AC_VOLTAGE])) * (double)2.0;
            Double value2 = (double)(Convert.ToInt32(RxBuff[AC_CURRENT])) / (double)10.0;
            Double value3 = value1 * value2;
            value3 = Math.Round(value3, 2);
            return value3;
        }

        /// <summary>
        /// 馬達故障狀態
        /// </summary>
        public MOTOR_FAULT Get_MotorFault(ref byte[] RxBuff)
        {
            MOTOR_FAULT MotorFault = MOTOR_FAULT.None;
            byte CompErr = RxBuff[CompProtect];
            switch (CompErr)
            {
                case 0:
                    MotorFault = MOTOR_FAULT.None;
                    break;
                case 1:
                    // 啟動故障
                    MotorFault = MOTOR_FAULT.StartUpErr;
                    break;
                case 2:
                    // 缺相保護
                    MotorFault = MOTOR_FAULT.PhaseLose;
                    break;
                case 3:
                    // 零速保護
                    MotorFault = MOTOR_FAULT.ZeroSpeed;
                    break;
                case 4:
                    // 失速保護
                    MotorFault = MOTOR_FAULT.LoseSpeed;
                    break;
                case 5:
                    // 過流保護
                    MotorFault = MOTOR_FAULT.ICompOver;
                    break;
                case 6:
                    // 相序錯誤
                    MotorFault = MOTOR_FAULT.PhaseErr;
                    break;
                default:
                    MotorFault = MOTOR_FAULT.None;
                    break;
            }
            return MotorFault;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="str"></param>
        /// <param name="RxBuff"></param>
        /// <returns></returns>
        public bool FaultInfo(string str, ref byte[] RxBuff)
        {
            byte faultCode = RxBuff[FAULT_CODE];
            bool state = false;
            switch (str)
            {
                case "IPMFault":
                    if ((faultCode & 0x80) == 0x80)
                        state = true;
                    break;
                case "VacHi":
                    if ((faultCode & 0x40) == 0x40)
                        state = true;
                    break;
                case "VacLo":
                    if ((faultCode & 0x20) == 0x20)
                        state = true;
                    break;
                case "IacOver":
                    if ((faultCode & 0x10) == 0x10)
                        state = true;
                    break;
                case "vBusHi":
                    if ((faultCode & 0x08) == 0x08)
                        state = true;
                    break;
                case "vBusLo":
                    if ((faultCode & 0x04) == 0x04)
                        state = true;
                    break;
                case "CurSensorErr":
                    if ((faultCode & 0x02) == 0x02)
                        state = true;
                    break;
                default:
                    MessageBox.Show("Error : " + str);
                    break;
            }

            return state;
        }

        #endregion

    }
}

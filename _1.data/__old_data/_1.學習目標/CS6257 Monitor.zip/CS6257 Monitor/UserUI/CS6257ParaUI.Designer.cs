﻿namespace CS6257_Monitor
{
    partial class CS6257ParaUI
    {
        /// <summary> 
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 元件設計工具產生的程式碼

        /// <summary> 
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器
        /// 修改這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.numericUpDown2 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.groupBox22 = new System.Windows.Forms.GroupBox();
            this.ResetEflashData_button = new System.Windows.Forms.Button();
            this.OpenEflashData_button = new System.Windows.Forms.Button();
            this.SaveAsEflashData_button = new System.Windows.Forms.Button();
            this.SaveEflashData_button = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.TB_RunParaState = new System.Windows.Forms.TextBox();
            this.TB_ParaSYNState = new System.Windows.Forms.TextBox();
            this.TB_LinkState = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.update_MotoRunPara_button = new System.Windows.Forms.Button();
            this.Updata_StateMachineRunPara_button = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.Write_efd_button = new System.Windows.Forms.Button();
            this.Read_efd_button = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.Update_StateMachine_param_button = new System.Windows.Forms.Button();
            this.Update_Motor_param_button = new System.Windows.Forms.Button();
            this.Update_param_button = new System.Windows.Forms.Button();
            this.Download_StateMachine_param_button = new System.Windows.Forms.Button();
            this.Download_Motor_param_button = new System.Windows.Forms.Button();
            this.Download_param_button = new System.Windows.Forms.Button();
            this.listViewEx1 = new ListViewEx.ListViewEx();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            this.groupBox22.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(399, 357);
            this.textBox4.Name = "textBox4";
            this.textBox4.ReadOnly = true;
            this.textBox4.Size = new System.Drawing.Size(85, 22);
            this.textBox4.TabIndex = 41;
            this.textBox4.Visible = false;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(399, 313);
            this.textBox3.Name = "textBox3";
            this.textBox3.ReadOnly = true;
            this.textBox3.Size = new System.Drawing.Size(85, 22);
            this.textBox3.TabIndex = 40;
            this.textBox3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.textBox3.Visible = false;
            // 
            // numericUpDown2
            // 
            this.numericUpDown2.DecimalPlaces = 7;
            this.numericUpDown2.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.numericUpDown2.Location = new System.Drawing.Point(399, 272);
            this.numericUpDown2.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.numericUpDown2.Minimum = new decimal(new int[] {
            10,
            0,
            0,
            -2147483648});
            this.numericUpDown2.Name = "numericUpDown2";
            this.numericUpDown2.Size = new System.Drawing.Size(105, 22);
            this.numericUpDown2.TabIndex = 39;
            this.numericUpDown2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.numericUpDown2.Visible = false;
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.Location = new System.Drawing.Point(273, 272);
            this.numericUpDown1.Maximum = new decimal(new int[] {
            67108864,
            0,
            0,
            0});
            this.numericUpDown1.Minimum = new decimal(new int[] {
            67108864,
            0,
            0,
            -2147483648});
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(105, 22);
            this.numericUpDown1.TabIndex = 38;
            this.numericUpDown1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.numericUpDown1.Visible = false;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(167, 272);
            this.textBox2.Name = "textBox2";
            this.textBox2.ReadOnly = true;
            this.textBox2.Size = new System.Drawing.Size(85, 22);
            this.textBox2.TabIndex = 36;
            this.textBox2.Visible = false;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(61, 272);
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(85, 22);
            this.textBox1.TabIndex = 37;
            this.textBox1.Visible = false;
            // 
            // groupBox22
            // 
            this.groupBox22.Controls.Add(this.ResetEflashData_button);
            this.groupBox22.Controls.Add(this.textBox4);
            this.groupBox22.Controls.Add(this.OpenEflashData_button);
            this.groupBox22.Controls.Add(this.textBox3);
            this.groupBox22.Controls.Add(this.SaveAsEflashData_button);
            this.groupBox22.Controls.Add(this.numericUpDown2);
            this.groupBox22.Controls.Add(this.SaveEflashData_button);
            this.groupBox22.Controls.Add(this.numericUpDown1);
            this.groupBox22.Controls.Add(this.textBox2);
            this.groupBox22.Controls.Add(this.textBox1);
            this.groupBox22.Controls.Add(this.listViewEx1);
            this.groupBox22.Location = new System.Drawing.Point(3, 0);
            this.groupBox22.Name = "groupBox22";
            this.groupBox22.Size = new System.Drawing.Size(567, 565);
            this.groupBox22.TabIndex = 42;
            this.groupBox22.TabStop = false;
            this.groupBox22.Text = "檔案";
            // 
            // ResetEflashData_button
            // 
            this.ResetEflashData_button.Location = new System.Drawing.Point(260, 21);
            this.ResetEflashData_button.Name = "ResetEflashData_button";
            this.ResetEflashData_button.Size = new System.Drawing.Size(67, 30);
            this.ResetEflashData_button.TabIndex = 24;
            this.ResetEflashData_button.Text = "重置";
            this.ResetEflashData_button.UseVisualStyleBackColor = true;
            this.ResetEflashData_button.Click += new System.EventHandler(this.ResetEflashData_button_Click);
            // 
            // OpenEflashData_button
            // 
            this.OpenEflashData_button.Location = new System.Drawing.Point(11, 21);
            this.OpenEflashData_button.Name = "OpenEflashData_button";
            this.OpenEflashData_button.Size = new System.Drawing.Size(67, 30);
            this.OpenEflashData_button.TabIndex = 23;
            this.OpenEflashData_button.Text = "開啟";
            this.OpenEflashData_button.UseVisualStyleBackColor = true;
            this.OpenEflashData_button.Click += new System.EventHandler(this.OpenEflashData_button_Click);
            // 
            // SaveAsEflashData_button
            // 
            this.SaveAsEflashData_button.Location = new System.Drawing.Point(177, 21);
            this.SaveAsEflashData_button.Name = "SaveAsEflashData_button";
            this.SaveAsEflashData_button.Size = new System.Drawing.Size(67, 30);
            this.SaveAsEflashData_button.TabIndex = 23;
            this.SaveAsEflashData_button.Text = "另存新檔";
            this.SaveAsEflashData_button.UseVisualStyleBackColor = true;
            this.SaveAsEflashData_button.Click += new System.EventHandler(this.SaveAsEflashData_button_Click);
            // 
            // SaveEflashData_button
            // 
            this.SaveEflashData_button.Enabled = false;
            this.SaveEflashData_button.Location = new System.Drawing.Point(94, 21);
            this.SaveEflashData_button.Name = "SaveEflashData_button";
            this.SaveEflashData_button.Size = new System.Drawing.Size(67, 30);
            this.SaveEflashData_button.TabIndex = 23;
            this.SaveEflashData_button.Text = "儲存";
            this.SaveEflashData_button.UseVisualStyleBackColor = true;
            this.SaveEflashData_button.Click += new System.EventHandler(this.SaveEflashData_button_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.TB_RunParaState);
            this.groupBox1.Controls.Add(this.TB_ParaSYNState);
            this.groupBox1.Controls.Add(this.TB_LinkState);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Location = new System.Drawing.Point(574, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(483, 84);
            this.groupBox1.TabIndex = 43;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "資訊";
            // 
            // TB_RunParaState
            // 
            this.TB_RunParaState.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.TB_RunParaState.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.TB_RunParaState.Font = new System.Drawing.Font("Consolas", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TB_RunParaState.Location = new System.Drawing.Point(246, 42);
            this.TB_RunParaState.Name = "TB_RunParaState";
            this.TB_RunParaState.ReadOnly = true;
            this.TB_RunParaState.Size = new System.Drawing.Size(91, 22);
            this.TB_RunParaState.TabIndex = 36;
            this.TB_RunParaState.Text = "UNKNOW";
            this.TB_RunParaState.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // TB_ParaSYNState
            // 
            this.TB_ParaSYNState.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.TB_ParaSYNState.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.TB_ParaSYNState.Font = new System.Drawing.Font("Consolas", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TB_ParaSYNState.Location = new System.Drawing.Point(126, 42);
            this.TB_ParaSYNState.Name = "TB_ParaSYNState";
            this.TB_ParaSYNState.ReadOnly = true;
            this.TB_ParaSYNState.Size = new System.Drawing.Size(91, 22);
            this.TB_ParaSYNState.TabIndex = 36;
            this.TB_ParaSYNState.Text = "UNKNOW";
            this.TB_ParaSYNState.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // TB_LinkState
            // 
            this.TB_LinkState.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.TB_LinkState.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.TB_LinkState.Font = new System.Drawing.Font("Consolas", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TB_LinkState.ForeColor = System.Drawing.SystemColors.WindowText;
            this.TB_LinkState.Location = new System.Drawing.Point(17, 42);
            this.TB_LinkState.Name = "TB_LinkState";
            this.TB_LinkState.ReadOnly = true;
            this.TB_LinkState.Size = new System.Drawing.Size(91, 22);
            this.TB_LinkState.TabIndex = 35;
            this.TB_LinkState.Text = "UNKNOW";
            this.TB_LinkState.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(244, 27);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(101, 12);
            this.label7.TabIndex = 33;
            this.label7.Text = "運轉參數更新狀態";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(124, 27);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(77, 12);
            this.label6.TabIndex = 33;
            this.label6.Text = "參數同步狀態";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(15, 27);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(53, 12);
            this.label5.TabIndex = 33;
            this.label5.Text = "連線狀態";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.panel3);
            this.groupBox2.Controls.Add(this.panel2);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.panel1);
            this.groupBox2.Location = new System.Drawing.Point(574, 93);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(483, 374);
            this.groupBox2.TabIndex = 44;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "控制";
            // 
            // panel3
            // 
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.update_MotoRunPara_button);
            this.panel3.Controls.Add(this.Updata_StateMachineRunPara_button);
            this.panel3.Location = new System.Drawing.Point(9, 175);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(362, 66);
            this.panel3.TabIndex = 33;
            // 
            // update_MotoRunPara_button
            // 
            this.update_MotoRunPara_button.Location = new System.Drawing.Point(13, 14);
            this.update_MotoRunPara_button.Name = "update_MotoRunPara_button";
            this.update_MotoRunPara_button.Size = new System.Drawing.Size(136, 37);
            this.update_MotoRunPara_button.TabIndex = 29;
            this.update_MotoRunPara_button.Text = "更新馬達運轉參數";
            this.update_MotoRunPara_button.UseVisualStyleBackColor = true;
            this.update_MotoRunPara_button.Click += new System.EventHandler(this.update_MotoRunPara_button_Click);
            // 
            // Updata_StateMachineRunPara_button
            // 
            this.Updata_StateMachineRunPara_button.Location = new System.Drawing.Point(155, 14);
            this.Updata_StateMachineRunPara_button.Name = "Updata_StateMachineRunPara_button";
            this.Updata_StateMachineRunPara_button.Size = new System.Drawing.Size(136, 37);
            this.Updata_StateMachineRunPara_button.TabIndex = 30;
            this.Updata_StateMachineRunPara_button.Text = "更新溫控邏輯運行參數";
            this.Updata_StateMachineRunPara_button.UseVisualStyleBackColor = true;
            this.Updata_StateMachineRunPara_button.Click += new System.EventHandler(this.Updata_StateMachineRunPara_button_Click);
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.Write_efd_button);
            this.panel2.Controls.Add(this.Read_efd_button);
            this.panel2.Location = new System.Drawing.Point(9, 288);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(178, 72);
            this.panel2.TabIndex = 33;
            // 
            // Write_efd_button
            // 
            this.Write_efd_button.ForeColor = System.Drawing.Color.Red;
            this.Write_efd_button.Location = new System.Drawing.Point(20, 17);
            this.Write_efd_button.Name = "Write_efd_button";
            this.Write_efd_button.Size = new System.Drawing.Size(67, 37);
            this.Write_efd_button.TabIndex = 28;
            this.Write_efd_button.Text = "寫入EFLASH";
            this.Write_efd_button.UseVisualStyleBackColor = true;
            // 
            // Read_efd_button
            // 
            this.Read_efd_button.ForeColor = System.Drawing.Color.DarkGreen;
            this.Read_efd_button.Location = new System.Drawing.Point(93, 17);
            this.Read_efd_button.Name = "Read_efd_button";
            this.Read_efd_button.Size = new System.Drawing.Size(67, 37);
            this.Read_efd_button.TabIndex = 27;
            this.Read_efd_button.Text = "讀取EFLASH";
            this.Read_efd_button.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("新細明體", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label4.Location = new System.Drawing.Point(5, 270);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(138, 15);
            this.label4.TabIndex = 32;
            this.label4.Text = "Eflash 讀 / 寫 控制";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("新細明體", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label8.Location = new System.Drawing.Point(5, 155);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(71, 15);
            this.label8.TabIndex = 32;
            this.label8.Text = "參數更新";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("新細明體", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label1.Location = new System.Drawing.Point(6, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(123, 15);
            this.label1.TabIndex = 32;
            this.label1.Text = "傳送 / 接收 控制";
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.Update_StateMachine_param_button);
            this.panel1.Controls.Add(this.Update_Motor_param_button);
            this.panel1.Controls.Add(this.Update_param_button);
            this.panel1.Controls.Add(this.Download_StateMachine_param_button);
            this.panel1.Controls.Add(this.Download_Motor_param_button);
            this.panel1.Controls.Add(this.Download_param_button);
            this.panel1.Location = new System.Drawing.Point(8, 47);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(466, 101);
            this.panel1.TabIndex = 31;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("新細明體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label3.Location = new System.Drawing.Point(20, 66);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(59, 13);
            this.label3.TabIndex = 32;
            this.label3.Text = "傳送參數";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("新細明體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label2.Location = new System.Drawing.Point(20, 25);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(59, 13);
            this.label2.TabIndex = 32;
            this.label2.Text = "傳送參數";
            // 
            // Update_StateMachine_param_button
            // 
            this.Update_StateMachine_param_button.ForeColor = System.Drawing.Color.Red;
            this.Update_StateMachine_param_button.Location = new System.Drawing.Point(340, 13);
            this.Update_StateMachine_param_button.Name = "Update_StateMachine_param_button";
            this.Update_StateMachine_param_button.Size = new System.Drawing.Size(117, 37);
            this.Update_StateMachine_param_button.TabIndex = 26;
            this.Update_StateMachine_param_button.Text = "傳送溫控邏輯參數資料";
            this.Update_StateMachine_param_button.UseVisualStyleBackColor = true;
            this.Update_StateMachine_param_button.Click += new System.EventHandler(this.Update_StateMachine_param_button_Click);
            // 
            // Update_Motor_param_button
            // 
            this.Update_Motor_param_button.ForeColor = System.Drawing.Color.Red;
            this.Update_Motor_param_button.Location = new System.Drawing.Point(217, 13);
            this.Update_Motor_param_button.Name = "Update_Motor_param_button";
            this.Update_Motor_param_button.Size = new System.Drawing.Size(117, 37);
            this.Update_Motor_param_button.TabIndex = 26;
            this.Update_Motor_param_button.Text = "傳送馬達參數資料";
            this.Update_Motor_param_button.UseVisualStyleBackColor = true;
            this.Update_Motor_param_button.Click += new System.EventHandler(this.Update_Motor_param_button_Click);
            // 
            // Update_param_button
            // 
            this.Update_param_button.ForeColor = System.Drawing.Color.Red;
            this.Update_param_button.Location = new System.Drawing.Point(94, 13);
            this.Update_param_button.Name = "Update_param_button";
            this.Update_param_button.Size = new System.Drawing.Size(117, 37);
            this.Update_param_button.TabIndex = 26;
            this.Update_param_button.Text = "傳送所有參數資料";
            this.Update_param_button.UseVisualStyleBackColor = true;
            this.Update_param_button.Click += new System.EventHandler(this.Update_param_button_Click);
            // 
            // Download_StateMachine_param_button
            // 
            this.Download_StateMachine_param_button.ForeColor = System.Drawing.Color.DarkGreen;
            this.Download_StateMachine_param_button.Location = new System.Drawing.Point(340, 54);
            this.Download_StateMachine_param_button.Name = "Download_StateMachine_param_button";
            this.Download_StateMachine_param_button.Size = new System.Drawing.Size(117, 37);
            this.Download_StateMachine_param_button.TabIndex = 25;
            this.Download_StateMachine_param_button.Text = "接收溫控邏輯參數資料";
            this.Download_StateMachine_param_button.UseVisualStyleBackColor = true;
            this.Download_StateMachine_param_button.Click += new System.EventHandler(this.Download_StateMachine_param_button_Click);
            // 
            // Download_Motor_param_button
            // 
            this.Download_Motor_param_button.ForeColor = System.Drawing.Color.DarkGreen;
            this.Download_Motor_param_button.Location = new System.Drawing.Point(217, 54);
            this.Download_Motor_param_button.Name = "Download_Motor_param_button";
            this.Download_Motor_param_button.Size = new System.Drawing.Size(117, 37);
            this.Download_Motor_param_button.TabIndex = 25;
            this.Download_Motor_param_button.Text = "接收馬達參數資料";
            this.Download_Motor_param_button.UseVisualStyleBackColor = true;
            this.Download_Motor_param_button.Click += new System.EventHandler(this.Download_Motor_param_button_Click);
            // 
            // Download_param_button
            // 
            this.Download_param_button.ForeColor = System.Drawing.Color.DarkGreen;
            this.Download_param_button.Location = new System.Drawing.Point(94, 54);
            this.Download_param_button.Name = "Download_param_button";
            this.Download_param_button.Size = new System.Drawing.Size(117, 37);
            this.Download_param_button.TabIndex = 25;
            this.Download_param_button.Text = "接收所有參數資料";
            this.Download_param_button.UseVisualStyleBackColor = true;
            this.Download_param_button.Click += new System.EventHandler(this.Download_param_button_Click);
            // 
            // listViewEx1
            // 
            this.listViewEx1.AllowColumnReorder = true;
            this.listViewEx1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.listViewEx1.DoubleClickActivation = false;
            this.listViewEx1.FullRowSelect = true;
            this.listViewEx1.GridLines = true;
            this.listViewEx1.Location = new System.Drawing.Point(6, 64);
            this.listViewEx1.Name = "listViewEx1";
            this.listViewEx1.Size = new System.Drawing.Size(555, 498);
            this.listViewEx1.TabIndex = 35;
            this.listViewEx1.UseCompatibleStateImageBehavior = false;
            this.listViewEx1.View = System.Windows.Forms.View.Details;
            // 
            // CS6257ParaUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBox22);
            this.Name = "CS6257ParaUI";
            this.Size = new System.Drawing.Size(1065, 568);
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            this.groupBox22.ResumeLayout(false);
            this.groupBox22.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.NumericUpDown numericUpDown2;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private ListViewEx.ListViewEx listViewEx1;
        private System.Windows.Forms.GroupBox groupBox22;
        private System.Windows.Forms.Button ResetEflashData_button;
        private System.Windows.Forms.Button OpenEflashData_button;
        private System.Windows.Forms.Button SaveAsEflashData_button;
        private System.Windows.Forms.Button SaveEflashData_button;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button Updata_StateMachineRunPara_button;
        private System.Windows.Forms.Button update_MotoRunPara_button;
        private System.Windows.Forms.Button Read_efd_button;
        private System.Windows.Forms.Button Write_efd_button;
        private System.Windows.Forms.Button Download_param_button;
        private System.Windows.Forms.Button Update_param_button;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button Update_StateMachine_param_button;
        private System.Windows.Forms.Button Update_Motor_param_button;
        private System.Windows.Forms.Button Download_StateMachine_param_button;
        private System.Windows.Forms.Button Download_Motor_param_button;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox TB_LinkState;
        private System.Windows.Forms.TextBox TB_ParaSYNState;
        private System.Windows.Forms.TextBox TB_RunParaState;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace CS6257_Monitor.UserUI
{
    public partial class ControlUI_Lite : UserControl
    {
        public ControlUI_Lite()
        {
            InitializeComponent();
        }
    }
}

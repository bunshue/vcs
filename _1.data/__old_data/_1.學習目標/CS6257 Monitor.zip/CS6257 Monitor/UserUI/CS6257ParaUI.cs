﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace CS6257_Monitor
{
    public partial class CS6257ParaUI : UserControl
    {
        private Control[] Editors;

        private TransControl bc;
        private string eflash_filepath = string.Empty;  // 參數儲存路徑

        public CS6257ParaUI()
        {
            InitializeComponent();

            // 初始 Control 物件
            Editors = new Control[] {
                textBox1,
                textBox2,
                numericUpDown1,
                numericUpDown2,
                textBox3,
                textBox4
            };

            // 
            // listViewEx1
            // 
            this.listViewEx1.SubItemClicked += new ListViewEx.SubItemEventHandler(listViewEx1_SubItemClicked);
            this.listViewEx1.SubItemEndEditing += new ListViewEx.SubItemEndEditingEventHandler(listViewEx1_SubItemEndEditing);
            // Add Columns
            this.listViewEx1.Columns.Add("No.", 50, HorizontalAlignment.Left);
            this.listViewEx1.Columns.Add("Name", 125, HorizontalAlignment.Left);
            this.listViewEx1.Columns.Add("Value", 100, HorizontalAlignment.Right);
            this.listViewEx1.Columns.Add("Q24 Format", 100, HorizontalAlignment.Right);
            this.listViewEx1.Columns.Add("Hex", 100, HorizontalAlignment.Right);
            this.listViewEx1.Columns.Add("Description", 100, HorizontalAlignment.Left);

        }

        /// <summary>
        /// // 初始化
        /// </summary>
        /// <param name="bc_ref"></param>
        public void Init_CS6257ParaUI(TransControl bc_ref)
        {
            bc = bc_ref;

            // 初始化 ListViewEx
            Init_ListViewEx(this.listViewEx1);
        }

        /// <summary>
        /// 
        /// </summary>
        public void UpdateUI()
        {
            UpdateConectionStatus();
            UpdateParamSynStatus();
            UpdateRunParaState();

            // 說明 : 完成接收時更新 EflashData ListView
            if (bc.SciFlag.UpdateListView == true)
            {
                bc.SciFlag.UpdateListView = false;
                // 更新 EflashData ListView
                this.UpdateEflashData_ListView();
            }
        }

        /// <summary>
        /// 名稱 : listViewEx1_SubItemClicked
        /// 說明 :
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void listViewEx1_SubItemClicked(object sender, ListViewEx.SubItemEventArgs e)
        {
            try
            {
                listViewEx1.StartEditing(Editors[e.SubItem], e.Item, e.SubItem);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Er1: " + ex.ToString());
            }

        }

        /// <summary>
        /// 名稱 : listViewEx1_SubItemEndEditing
        /// 說明 :
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void listViewEx1_SubItemEndEditing(object sender, ListViewEx.SubItemEndEditingEventArgs e)
        {
            double dtemp = 0;
            int itemp = 0;
            try
            {
                if (e.SubItem == 2)
                {
                    dtemp = double.Parse(e.DisplayText) / (double)16777216;
                    dtemp = Math.Round(dtemp, 7);
                    e.Item.SubItems[3].Text = dtemp.ToString("#0.0000000");
                    e.Item.SubItems[4].Text = "0x" + Int32.Parse(e.DisplayText).ToString("X8"); // 16進位顯示
                }
                else if (e.SubItem == 3)
                {
                    itemp = (int)(double.Parse(e.DisplayText) * 16777216);
                    e.Item.SubItems[2].Text = itemp.ToString();
                    e.Item.SubItems[4].Text = "0x" + itemp.ToString("X8");                      // 16進位顯示
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Er2: " + ex.ToString());
            }
        }

        /// <summary>
        /// 初始化 ListViewEx
        /// </summary>
        /// <param name="listViewEx"></param>
        public void Init_ListViewEx(ListViewEx.ListViewEx listViewEx)
        {
            ListViewItem item;
            listViewEx.Items.Clear();
            string[] rowdata = new string[6];
 
            for (int ii = 0; ii < bc.parmDB.Length; ii++)
            {
                rowdata[0] = bc.parmDB[ii].Number.ToString();
                rowdata[1] = bc.parmDB[ii].Name;
                rowdata[2] = bc.parmDB[ii].Value.ToString();
                rowdata[3] = (double.Parse(rowdata[2]) / (double)16777216).ToString("0.0000000");
                rowdata[4] = "0x" + Int32.Parse(rowdata[2]).ToString("X8");
                rowdata[5] = "";
                item = new ListViewItem(rowdata);
                listViewEx.Items.Add(item);
            }
        }

        /// <summary>
        /// 名稱 : Reset_ListViewEx
        /// 說明 : 重設 Eflash Listview 顯示
        /// </summary>
        /// <param name="listViewEx"></param>
        public void Reset_ListViewEx()
        {
            string[] rowdat = new string[5];
            for (int ii = 0; ii < 512; ii++)
            {
                this.listViewEx1.Items[ii].SubItems[0].Text = ii.ToString();
                this.listViewEx1.Items[ii].SubItems[2].Text = "0";
                this.listViewEx1.Items[ii].SubItems[3].Text = "0.0000000";
                this.listViewEx1.Items[ii].SubItems[4].Text = "0x00000000";
            }
        }

        /// <summary>
        /// 更新 Eflash Data ListView 內容
        /// </summary>
        /// <param name="listview"></param>
        public void UpdateEflashData_ListView()
        {
            for (int ii = 0; ii < bc.parmDB.Length; ii++)
            {
                int value = bc.parmDB[ii].Value;
                this.listViewEx1.Items[ii].SubItems[2].Text = value.ToString();
                double dvalue = (double)value / (double)16777216.0;
                dvalue = Math.Round(dvalue, 7);
                this.listViewEx1.Items[ii].SubItems[3].Text = dvalue.ToString("#0.0000000");
                this.listViewEx1.Items[ii].SubItems[4].Text = "0x" + value.ToString("X8");
            }
            Console.WriteLine("\nListView Data Disp. Update [Done] ***");
        }

        /// <summary>
        /// 複製 listviewEx 內容至Eflash Buf
        /// </summary>
        /// <param name="listviewEx"></param>
        public void CopyListViewDataToBuf()
        {
            Console.WriteLine("Copy ListViewData To parmDB [Done]");
            int temp = 0;
            for (int ii = 0; ii < 512; ii++)
            {
                temp = Int32.Parse(this.listViewEx1.Items[ii].SubItems[2].Text);
                bc.parmDB[ii].Value = temp;
            }
        }

        /// <summary>
        /// 設定 dataName 對應之 Listview 的數值
        /// </summary>
        /// <param name="dataName"></param>
        public void SetListViewParam(string dataName, int value)
        {
            string str = string.Empty;
            double dtemp = 0;
            //int itemp = 0;
            for (int ii = 0; ii < this.listViewEx1.Items.Count; ii++)
            {
                str = this.listViewEx1.Items[ii].SubItems[1].Text;
                if (str.CompareTo(dataName) == 0)
                {
                    this.listViewEx1.Items[ii].SubItems[2].Text = value.ToString();
                    dtemp = (double)value / (double)(16777216.0);
                    this.listViewEx1.Items[ii].SubItems[3].Text = dtemp.ToString("#0.0000000");
                    this.listViewEx1.Items[ii].SubItems[4].Text = "0x" + value.ToString("X8");
                }
            }
        }

        /// <summary>
        /// 取得 dataName 對應到之 ListView 的內容
        /// </summary>
        /// <param name="dataName"></param>
        /// <returns></returns>
        public int GetListViewParam(string dataName)
        {
            int value = 0;
            string str = string.Empty;
            for (int ii = 0; ii < this.listViewEx1.Items.Count; ii ++)
            {
                str = this.listViewEx1.Items[ii].SubItems[1].Text;
                if (str.CompareTo(dataName) == 0)
                {
                    string temp = this.listViewEx1.Items[ii].SubItems[2].Text;
                    value = Int32.Parse(temp);
                    return value;
                }
            }
            return value;
        }

        #region 檔案處理 Files

        /// <summary>
        /// 開啟讀取Eflash資料
        /// </summary>
        private void OpenEflashFile(ListViewEx.ListViewEx listViewEx)
        {
            string filepath = string.Empty;
            string[] rowdat = new string[6];
            string context = string.Empty;
            int t1 = 0;
            int t2 = 0;
            OpenFileDialog P_OpenFileDialog = new OpenFileDialog();
            if (P_OpenFileDialog.ShowDialog() == DialogResult.OK)
            {
                filepath = P_OpenFileDialog.FileName;
                eflash_filepath = filepath;
                this.SaveEflashData_button.Enabled = true;
                FileStream filestream = File.Open(filepath, FileMode.Open);
                StreamReader str_reader = new StreamReader(filestream);
                //this.listViewEx1.Items.Clear();
                for (int ii = 0; ii < 512; ii++)
                {
                    context = str_reader.ReadLine();
                    t1 = t2 = 0;
                    for (int jj = 0; jj < 3; jj++)
                    {
                        t2 = context.IndexOf("\t", t1);
                        rowdat[jj] = context.Substring(t1, t2 - t1);
                        t1 = t2 + 1;
                    }
                    //rowdat[3] = context.Substring(t1, context.Length - t1);
                    rowdat[3] = (double.Parse(rowdat[2]) / (double)16777216).ToString("0.0000000");
                    rowdat[4] = "0x" + Int32.Parse(rowdat[2]).ToString("X8");
                    //item = new ListViewItem(rowdat);
                    //this.listViewEx1.Items.Add(item);
                    //listViewEx.Items[ii].SubItems[0].Text = rowdat[0];
                    //listViewEx.Items[ii].SubItems[1].Text = rowdat[1];
                    listViewEx.Items[ii].SubItems[2].Text = rowdat[2];
                    listViewEx.Items[ii].SubItems[3].Text = rowdat[3];
                    listViewEx.Items[ii].SubItems[4].Text = rowdat[4];
                    listViewEx.Items[ii].SubItems[5].Text = rowdat[5];
                }
                str_reader.Dispose();
                filestream.Close();
            }
        }

        /// <summary>
        /// 儲存Eflash資料
        /// </summary>
        private void SaveEflashFile(ListViewEx.ListViewEx listViewEx)
        {
            string filepath = string.Empty;
            string[] rowdat = new string[6];
            string context = string.Empty;
            FileStream filestream = File.OpenWrite(eflash_filepath);
            StreamWriter str_writer = new StreamWriter(filestream);
            for (int ii = 0; ii < 512; ii++)
            {
                rowdat[0] = listViewEx.Items[ii].SubItems[0].Text;
                rowdat[1] = listViewEx.Items[ii].SubItems[1].Text;
                rowdat[2] = listViewEx.Items[ii].SubItems[2].Text;
                rowdat[3] = listViewEx.Items[ii].SubItems[3].Text;
                rowdat[5] = listViewEx.Items[ii].SubItems[5].Text;
                context = rowdat[0] + "\t" + rowdat[1] + "\t" + rowdat[2] + "\t" + rowdat[3];// +"\t" + rowdat[5];
                str_writer.WriteLine(context);
            }
            str_writer.Dispose();
            filestream.Close();
            MessageBox.Show("檔案已儲存");
        }

        /// <summary>
        /// 另存新檔 Eflash資料
        /// </summary>
        private void SaveAsEflashFile(ListViewEx.ListViewEx listViewEx)
        {
            string filepath = string.Empty;
            string[] rowdat = new string[6];
            string context = string.Empty;
            SaveFileDialog P_SaveFileDialog = new SaveFileDialog();

            if (P_SaveFileDialog.ShowDialog() == DialogResult.OK)
            {
                filepath = P_SaveFileDialog.FileName;
                this.SaveEflashData_button.Enabled = true;
                //this.儲存ToolStripMenuItem.Enabled = true;
                FileStream filestream = File.Open(filepath, FileMode.Create);
                StreamWriter str_writer = new StreamWriter(filestream);
                for (int ii = 0; ii < 512; ii++)
                {
                    rowdat[0] = listViewEx1.Items[ii].SubItems[0].Text;
                    rowdat[1] = listViewEx1.Items[ii].SubItems[1].Text;
                    rowdat[2] = listViewEx1.Items[ii].SubItems[2].Text;
                    rowdat[3] = listViewEx1.Items[ii].SubItems[3].Text;
                    rowdat[5] = listViewEx1.Items[ii].SubItems[5].Text;
                    context = rowdat[0] + "\t" + rowdat[1] + "\t" + rowdat[2] + "\t" + rowdat[3];// +"\t" + rowdat[5];
                    str_writer.WriteLine(context);
                }
                str_writer.Dispose();
                filestream.Close();
            }
        }

        #endregion

        /// <summary>
        /// 開啟Eflash檔案
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void OpenEflashData_button_Click(object sender, EventArgs e)
        {
            OpenEflashFile(this.listViewEx1);
        }

        /// <summary>
        /// 儲存 Eflash 檔案
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void SaveEflashData_button_Click(object sender, EventArgs e)
        {
            SaveEflashFile(this.listViewEx1);
        }

        /// <summary>
        /// 另存 Eflash 檔案
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void SaveAsEflashData_button_Click(object sender, EventArgs e)
        {
            SaveAsEflashFile(this.listViewEx1);
        }

        /// <summary>
        /// 重置 Eflash Data
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ResetEflashData_button_Click(object sender, EventArgs e)
        {
            Reset_ListViewEx();
        }

        /// <summary>
        /// 傳送所有參數資料
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Update_param_button_Click(object sender, EventArgs e)
        {
            // 將listViewEx資料複製到 eflash_listView_Data 暫存
            this.CopyListViewDataToBuf();
            bc.SetParamTransControl(TransControl.TRANS.DOWNLOAD, TransControl.DATA_TYPE.BOTH);
        }

        /// <summary>
        /// 傳送馬達參數資料
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Update_Motor_param_button_Click(object sender, EventArgs e)
        {
            // 將listViewEx資料複製到 eflash_listView_Data 暫存
            this.CopyListViewDataToBuf();
            bc.SetParamTransControl(TransControl.TRANS.DOWNLOAD, TransControl.DATA_TYPE.MOTOR);
        }

        /// <summary>
        /// 傳送溫控邏輯參數資料
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Update_StateMachine_param_button_Click(object sender, EventArgs e)
        {
            // 將listViewEx資料複製到 eflash_listView_Data 暫存
            this.CopyListViewDataToBuf();
            bc.SetParamTransControl(TransControl.TRANS.DOWNLOAD, TransControl.DATA_TYPE.STATEMACHINE);
            
        }

        /// <summary>
        /// 接收所有參數資料
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Download_param_button_Click(object sender, EventArgs e)
        {
            bc.SetParamTransControl(TransControl.TRANS.READ, TransControl.DATA_TYPE.BOTH);
        }

        /// <summary>
        /// 接收馬達參數資料
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Download_Motor_param_button_Click(object sender, EventArgs e)
        {
            bc.SetParamTransControl(TransControl.TRANS.READ, TransControl.DATA_TYPE.MOTOR);
        }

        /// <summary>
        /// 接收溫控邏輯參數資料
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Download_StateMachine_param_button_Click(object sender, EventArgs e)
        {
            bc.SetParamTransControl(TransControl.TRANS.READ, TransControl.DATA_TYPE.STATEMACHINE);
        }

        // 更新馬達參數 
        // bc.Send_Update_MotoPara_Cmd();


        /// <summary>
        /// 更新連線狀態顯示
        /// </summary>
        public void UpdateConectionStatus()
        {
            if (bc.pcState.ComState == TransControl.COM_STATE.ESTABLISHED)
            {
                this.TB_LinkState.ForeColor = Color.Green;
                this.TB_LinkState.Text = "ESTABLISHED";
            }
            else if (bc.pcState.ComState == TransControl.COM_STATE.DISCONNECTED)
            {
                this.TB_LinkState.ForeColor = Color.Red;
                this.TB_LinkState.Text = "DISCONNECTED";
            }
        }


        /// <summary>
        /// 更新參數同步狀態顯示
        /// </summary>
        public void UpdateParamSynStatus()
        {
            switch (bc.pcState.ParamState)
            {
                case TransControl.PARAM_STATE.REQ:
                    this.TB_ParaSYNState.Text = "REQ";
                    break;
                case TransControl.PARAM_STATE.RECV_CHECK:
                    this.TB_ParaSYNState.Text = "RECV_CHECK";
                    break;
                case TransControl.PARAM_STATE.SEND_CHECK:
                    this.TB_ParaSYNState.Text = "SEND_CHECK";
                    break;
                case TransControl.PARAM_STATE.GET:
                    this.TB_ParaSYNState.Text = "GET";
                    break;
                case TransControl.PARAM_STATE.GET_WAIT:
                    this.TB_ParaSYNState.Text = "GET_WAIT";
                    break;
                case TransControl.PARAM_STATE.SEND:
                    this.TB_ParaSYNState.Text = "SEND";
                    break;
                case TransControl.PARAM_STATE.SEND_WAIT:
                    this.TB_ParaSYNState.Text = "SEND_WAIT";
                    break;
                case TransControl.PARAM_STATE.ASY:
                    this.TB_ParaSYNState.Text = "ASY";
                    break;
                case TransControl.PARAM_STATE.SYN:
                    this.TB_ParaSYNState.Text = "SYN";
                    break;
                case TransControl.PARAM_STATE.DEFAULT:
                    this.TB_ParaSYNState.Text = "DEFAULT";
                    break;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        public void UpdateRunParaState()
        {
            switch(bc.pcState.RunParamState)
            {
                case TransControl.RUNPARAM_STATE.DEFAULE:
                    this.TB_RunParaState.Text = "DEFAULT";
                    break;
                case TransControl.RUNPARAM_STATE.SEND:
                    this.TB_RunParaState.Text = "SEND";
                    break;
                case TransControl.RUNPARAM_STATE.ACK:
                    this.TB_RunParaState.Text = "ACK";
                    break;
                case TransControl.RUNPARAM_STATE.NACK:
                    this.TB_RunParaState.Text = "NACK";
                    break;
                case TransControl.RUNPARAM_STATE.WAIT:
                    this.TB_RunParaState.Text = "WAIT";
                    break;
            }
        }

        /// <summary>
        /// 更新馬達運轉參數按鈕
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void update_MotoRunPara_button_Click(object sender, EventArgs e)
        {
            bc.UpdataMotorRun_Param();
        }

        /// <summary>
        /// 更新溫控邏輯運行參數按鈕
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Updata_StateMachineRunPara_button_Click(object sender, EventArgs e)
        {
            bc.UpdateStateMachineRun_Param();
        }

    }
}

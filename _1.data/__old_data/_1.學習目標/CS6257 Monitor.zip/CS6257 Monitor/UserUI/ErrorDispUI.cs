﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CS6257_Monitor
{
    public partial class ErrorDispUI : UserControl
    {
        public ErrorDispUI()
        {
            InitializeComponent();
        }

        TransControl trans;

        /// <summary>
        /// 初始化設定
        /// </summary>
        /// <param name="trans_ref"></param>
        public void Init_ErrorDispUI(TransControl trans_ref)
        {
            trans = trans_ref;

            this.TB_DCHighVoltage.BackColor = Color.Silver;
            this.TB_DCLowVoltage.BackColor = Color.Silver;

            this.TB_ACHighVoltage.BackColor = Color.Silver;
            this.TB_ACLowVoltage.BackColor = Color.Silver;

            this.TB_ACOverCurrent.BackColor = Color.Silver;

            this.TB_IPMFault.BackColor = Color.Silver;
            this.TB_IPMTemp.BackColor = Color.Silver;

            this.TB_StartUpErr.BackColor = Color.Silver;
            this.TB_LoseSpeed.BackColor = Color.Silver;
            this.TB_PhaseLose.BackColor = Color.Silver;
        }

        /// <summary>
        /// 
        /// </summary>
        public void UpdateUI()
        {
            PowerState();
            IPMModule();
            ErrorCode();
            Fault_code(this.TB_FaultState);
        }

        /// <summary>
        /// 電源狀態
        /// </summary>
        private void PowerState()
        {
            // DC 電壓異常狀態
            if (trans.Monitor_Data.FaultInfo.vBusErr == 1)
            {
                // DC 電壓過低
                this.TB_DCLowVoltage.BackColor = Color.Crimson;
                this.TB_DCHighVoltage.BackColor = Color.Silver;
            }
            else if (trans.Monitor_Data.FaultInfo.vBusErr == 2)
            {
                // DC 電壓過高
                this.TB_DCLowVoltage.BackColor = Color.Silver;
                this.TB_DCHighVoltage.BackColor = Color.Crimson;
            }
            else
            {
                this.TB_DCLowVoltage.BackColor = Color.Silver;
                this.TB_DCHighVoltage.BackColor = Color.Silver;
            }

            // AC 電壓過高
            if (trans.Monitor_Data.FaultInfo.VacHigh)
            {
                this.TB_ACHighVoltage.BackColor = Color.Crimson;
            }
            else
            {
                this.TB_ACHighVoltage.BackColor = Color.Silver;
            }

            // AC 電壓過低
            if (trans.Monitor_Data.FaultInfo.VacLow)
            {
                this.TB_ACLowVoltage.BackColor = Color.Crimson;
            }
            else
            {
                this.TB_ACLowVoltage.BackColor = Color.Silver;
            }

            // AC電流過高
            if (trans.Monitor_Data.FaultInfo.iacOver)
            {
                this.TB_ACHighVoltage.BackColor = Color.Crimson;
            }
            else
            {
                this.TB_ACHighVoltage.BackColor = Color.Silver;
            }
        }

        /// <summary>
        /// 功率模組狀態
        /// </summary>
        private void IPMModule()
        {
            // IPM 功率模組故障
            if (trans.Monitor_Data.FaultInfo.IPMFault)
            {
                this.TB_IPMFault.BackColor = Color.Crimson;
            }
            else
            {
                this.TB_IPMFault.BackColor = Color.Silver;
            }

            // IPM 溫度過高
            if (trans.Monitor_Data.ProtectInfo.ipmTemp)
            {
                this.TB_IPMTemp.BackColor = Color.Crimson;
            }
            else
            {
                this.TB_IPMTemp.BackColor = Color.Silver;
            }
        }

        /// <summary>
        /// 錯誤狀態顯示
        /// </summary>
        private void ErrorCode()
        {
            this.TB_Protect_err.Text = trans.Monitor_Data.SysRunInfo.Protect_err.ToString();
            this.TB_Protect_lim.Text = trans.Monitor_Data.SysRunInfo.Protect_lim.ToString();
        }

        /// <summary>
        /// 故障-保護編號
        /// </summary>
        /// <param name="textbox"></param>
        public void Fault_code(TextBox textbox)
        {
            string str = string.Empty;
            switch (trans.Monitor_Data.sysFault.code)
            {
                case ResolvePack.FAULT_CODE.FAULT_NONE:
                    str = "FAULT_NONE";
                    //textbox.ForeColor = Color.Green;
                    break;
                case ResolvePack.FAULT_CODE.FAULT_IPM:
                    str = "FAULT_IPM";
                    //textbox.ForeColor = Color.Red;
                    break;
                case ResolvePack.FAULT_CODE.FAULT_OUTEMP_SENSOR:
                    str = "FAULT_OUTEMP_SENSOR";
                    //textbox.ForeColor = Color.Red;
                    break;
                case ResolvePack.FAULT_CODE.FAULT_OUTCOIL_SENSOR:
                    str = "FAULT_OUTCOIL_SENSOR";
                    //textbox.ForeColor = Color.Red;
                    break;
                case ResolvePack.FAULT_CODE.FAULT_SUCT_SENSOR:
                    str = "FAULT_SUCT_SENSOR";
                    //textbox.ForeColor = Color.Red;
                    break;
                case ResolvePack.FAULT_CODE.FAULT_DISC_SENSOR:
                    str = "FAULT_DISC_SENSOR";
                    //textbox.ForeColor = Color.Red;
                    break;
                case ResolvePack.FAULT_CODE.FAULT_CUR_SENSOR:
                    str = "FAULT_CUR_SENSOR";
                    //textbox.ForeColor = Color.Red;
                    break;
                case ResolvePack.FAULT_CODE.FAULT_COMPRESS:
                    str = "FAULT_COMPRESS";
                    //textbox.ForeColor = Color.Red;
                    break;
                case ResolvePack.FAULT_CODE.FAULT_PHASE:
                    str = "FAULT_PHASE";
                    //textbox.ForeColor = Color.Red;
                    break;
                case ResolvePack.FAULT_CODE.FAULT_BACK_SENSOR:
                    str = "FAULT_BACK_SENSOR";
                    //textbox.ForeColor = Color.Red;
                    break;
                case ResolvePack.FAULT_CODE.PROTECT_IPM:
                    str = "PROTECT_IPM";
                    //textbox.ForeColor = Color.Orange;
                    break;
                case ResolvePack.FAULT_CODE.PROTECT_IAC:
                    str = "PROTECT_IAC";
                    //textbox.ForeColor = Color.Orange;
                    break;
                case ResolvePack.FAULT_CODE.PROTECT_DISCHAR_TEMP:
                    str = "PROTECT_DISCHAR_TEMP";
                    //textbox.ForeColor = Color.Orange;
                    break;
                case ResolvePack.FAULT_CODE.PROTECT_TOP_TEMP:
                    str = "PROTECT_TOP_TEMP";
                    //textbox.ForeColor = Color.Orange;
                    break;
                case ResolvePack.FAULT_CODE.PROTECT_SUCT_TEMP:
                    str = "PROTECT_SUCT_TEMP";
                    //textbox.ForeColor = Color.Orange;
                    break;
                case ResolvePack.FAULT_CODE.PROTECT_VBUS:
                    str = "PROTECT_VBUS";
                    //textbox.ForeColor = Color.Orange;
                    break;
                case ResolvePack.FAULT_CODE.PROTECT_LOW_PRESSURE:
                    str = "PROTECT_LOW_PRESSURE";
                    //textbox.ForeColor = Color.Orange;
                    break;
                case ResolvePack.FAULT_CODE.PROTECT_OVER_PRESSURE:
                    str = "PROTECT_OVER_PRESSURE";
                    //textbox.ForeColor = Color.Orange;
                    break;
                case ResolvePack.FAULT_CODE.PROTECT_INCOIL_TEMP:
                    str = "PROTECT_INCOIL_TEMP";
                    //textbox.ForeColor = Color.Orange;
                    break;
                case ResolvePack.FAULT_CODE.PROTECT_OUTDOOR_TEMP:
                    str = "PROTECT_OUTDOOR_TEMP";
                    //textbox.ForeColor = Color.Orange;
                    break;
                case ResolvePack.FAULT_CODE.FAULT_COMMUN:
                    str = "FAULT_COMMUN";
                    //textbox.ForeColor = Color.Red;
                    break;
                case ResolvePack.FAULT_CODE.FAULT_EEPROM:
                    str = "FAULT_EEPROM";
                    //textbox.ForeColor = Color.Red;
                    break;
                case ResolvePack.FAULT_CODE.FAULT_STAR:
                    str = "FAULT_STAR";
                    //textbox.ForeColor = Color.Red;
                    break;
                case ResolvePack.FAULT_CODE.FAULT_FANMOTOR:
                    str = "FAULT_FANMOTOR";
                    //textbox.ForeColor = Color.Red;
                    break;
                case ResolvePack.FAULT_CODE.PROTECT_IPM_TEMP:
                    str = "PROTECT_IPM_TEMP";
                    //textbox.ForeColor = Color.Red;
                    break;
                case ResolvePack.FAULT_CODE.PROTECT_IPM_SOFT_OVERCUR:
                    str = "PROTECT_IPM_SOFT_OVERCUR";
                    //textbox.ForeColor = Color.Red;
                    break;
                case ResolvePack.FAULT_CODE.FAULT_VBUS:
                    str = "FAULT_VBUS";
                    //textbox.ForeColor = Color.Red;
                    break;
                case ResolvePack.FAULT_CODE.PROTECT_COMMUN:
                    str = "PROTECT_COMMUN";
                    //textbox.ForeColor = Color.Orange;
                    break;
                case ResolvePack.FAULT_CODE.PROTECT_STAR:
                    str = "PROTECT_STAR";
                    //textbox.ForeColor = Color.Orange;
                    break;
                case ResolvePack.FAULT_CODE.FAULT_LACKFI:
                    str = "FAULT_LACKFI";
                    //textbox.ForeColor = Color.Red;
                    break;
                case ResolvePack.FAULT_CODE.PROTECT_INERR:
                    str = "PROTECT_INERR";
                    //textbox.ForeColor = Color.Orange;
                    break;
                case ResolvePack.FAULT_CODE.PROTECT_COM_DRIVER:
                    str = "PROTECT_COM_DRIVER";
                    //textbox.ForeColor = Color.Orange;
                    break;
                case ResolvePack.FAULT_CODE.PROTECT_OUT_COIL_TEMP:
                    str = "PROTECT_OUT_COIL_TEMP";
                    //textbox.ForeColor = Color.Orange;
                    break;
                case ResolvePack.FAULT_CODE.FAULT_FORCE_OFF:
                    str = "FAULT_FORCE_OFF";
                    //textbox.ForeColor = Color.Red;
                    break;
                case ResolvePack.FAULT_CODE.FAULT_PFC:
                    str = "FAULT_PFC";
                    //textbox.ForeColor = Color.Red;
                    break;
                case ResolvePack.FAULT_CODE.FAULT_VAC:
                    str = "FAULT_VAC";
                    //textbox.ForeColor = Color.Red;
                    break;
                case ResolvePack.FAULT_CODE.FAULT_IPM_SENSOR:
                    str = "FAULT_IPM_SENSOR";
                    //textbox.ForeColor = Color.Red;
                    break;
                case ResolvePack.FAULT_CODE.PROTECT_IAC_LOW:
                    str = "PROTECT_IAC_LOW";
                    //textbox.ForeColor = Color.Red;
                    break;
                default:
                    str = "Error";
                    //textbox.ForeColor = Color.Red;
                    break;
            }
            textbox.Text = str;
        }
    }
}

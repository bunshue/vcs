﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CS6257_Monitor
{
    public partial class InformationUI : UserControl
    {
        public InformationUI()
        {
            InitializeComponent();
        }


        private TransControl bc;
        private CS6257ParaUI cs6257ParaUI;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="bc"></param>
        public void Init_InformationUI(TransControl bc_ref, CS6257ParaUI cs6257ParaUI_ref)
        {
            bc = bc_ref;
            cs6257ParaUI = cs6257ParaUI_ref;

            UpdateUI();
        }

        public void UpdateUI()
        {
            UpdateMotorInformation();

            UpdateConectionStatus();
            UpdateParamSynStatus();
            UpdateControlInformation();
            
        }

        /// <summary>
        /// 更新馬達資訊
        /// </summary>
        public void UpdateMotorInformation()
        {
            double value = 0;
            value = cs6257ParaUI.GetListViewParam("Rs");
            value = value / 16777215;
            this.TB_Rs.Text = value.ToString("#0.00");
            this.TB_Rs.BackColor = Color.FromName("ButtonHighlight");

            value = cs6257ParaUI.GetListViewParam("PolePair");
            this.TB_PolePair.Text = value.ToString();
            this.TB_PolePair.BackColor = Color.FromName("ButtonHighlight");

            value = cs6257ParaUI.GetListViewParam("Ld");
            value = value / 16777215;
            value = Math.Round(value, 5) * 1000;
            this.TB_Ld.Text = value.ToString("#0.00");
            this.TB_Ld.BackColor = Color.FromName("ButtonHighlight");

            value = cs6257ParaUI.GetListViewParam("Lq");
            value = value / 16777215;
            value = Math.Round(value, 5) * 1000;
            this.TB_Lq.Text = value.ToString("#0.00");
            this.TB_Lq.BackColor = Color.FromName("ButtonHighlight");
        }

        /// <summary>
        /// 更新控制資訊
        /// </summary>
        public void UpdateControlInformation()
        {
            double value = 0;

            value = cs6257ParaUI.GetListViewParam("Comp_Base_Freq");
            this.TB_CompBaseFreq.Text = value.ToString();
            this.TB_CompBaseFreq.BackColor = Color.FromName("ButtonHighlight");

            value = cs6257ParaUI.GetListViewParam("Comp_Max_Freq");
            this.TB_CompMaxFreq.Text = value.ToString();
            this.TB_CompMaxFreq.BackColor = Color.FromName("ButtonHighlight");
            
            value = cs6257ParaUI.GetListViewParam("Comp_Min_Freq");
            this.TB_CompMinFreq.Text = value.ToString();
            this.TB_CompMinFreq.BackColor = Color.FromName("ButtonHighlight");

            value = cs6257ParaUI.GetListViewParam("CUR_START_OFFSET");
            value = value / 16777215.0;
            this.TB_CurrentStartOffset.Text = value.ToString("#0.00");
            this.TB_CurrentStartOffset.BackColor = Color.FromName("ButtonHighlight");

            value = cs6257ParaUI.GetListViewParam("I_Start_MAX");
            value = value / 16777215.0;
            this.TB_MaxStartUpCurrent.Text = value.ToString("#0.00");
            this.TB_MaxStartUpCurrent.BackColor = Color.FromName("ButtonHighlight");

            value = cs6257ParaUI.GetListViewParam("ISQ_Limit");
            value = value / 16777215.0;
            this.TB_MaxIqCurrent.Text = value.ToString("#0.00");
            this.TB_MaxIqCurrent.BackColor = Color.FromName("ButtonHighlight");

            value = cs6257ParaUI.GetListViewParam("AccRate");
            value = value / 10.0;
            this.TB_AccRate.Text = value.ToString("#0.0");
            this.TB_AccRate.BackColor = Color.FromName("ButtonHighlight");
        }

        /// <summary>
        /// 更新連線狀態顯示
        /// </summary>
        public void UpdateConectionStatus()
        {
            if (bc.pcState.ComState == TransControl.COM_STATE.ESTABLISHED)
            {
                this.TB_LinkState.ForeColor = Color.Green;
                this.TB_LinkState.Text = "ESTABLISHED";
            }
            else if (bc.pcState.ComState == TransControl.COM_STATE.DISCONNECTED)
            {
                this.TB_LinkState.ForeColor = Color.Red;
                this.TB_LinkState.Text = "DISCONNECTED";
            }
        }


        /// <summary>
        /// 更新參數同步狀態顯示
        /// </summary>
        public void UpdateParamSynStatus()
        {
            switch(bc.pcState.ParamState)
            {
                case TransControl.PARAM_STATE.REQ:
                    this.TB_ParaSYNState.Text = "REQ";
                    break;
                case TransControl.PARAM_STATE.RECV_CHECK:
                    this.TB_ParaSYNState.Text = "RECV_CHECK";
                    break;
                case TransControl.PARAM_STATE.SEND_CHECK:
                    this.TB_ParaSYNState.Text = "SEND_CHECK";
                    break;
                case TransControl.PARAM_STATE.GET:
                    this.TB_ParaSYNState.Text = "GET";
                    break;
                case TransControl.PARAM_STATE.GET_WAIT:
                    this.TB_ParaSYNState.Text = "GET_WAIT";
                    break;
                case TransControl.PARAM_STATE.SEND:
                    this.TB_ParaSYNState.Text = "SEND";
                    break;
                case TransControl.PARAM_STATE.SEND_WAIT:
                    this.TB_ParaSYNState.Text = "SEND_WAIT";
                    break;
                case TransControl.PARAM_STATE.ASY:
                    this.TB_ParaSYNState.Text = "ASY";
                    break;
                case TransControl.PARAM_STATE.SYN:
                    this.TB_ParaSYNState.Text = "SYN";
                    break;
                case TransControl.PARAM_STATE.DEFAULT:
                    this.TB_ParaSYNState.Text = "DEFAULT";
                    break;
            }
        }
    }
}

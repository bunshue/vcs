﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CS6257_Monitor
{
    public partial class ProMonitorUI : UserControl
    {
        public ProMonitorUI()
        {
            InitializeComponent();
        }

        TransControl trans;

        /// <summary>
        /// 初始化設定
        /// </summary>
        /// <param name="trans_ref"></param>
        public void Init_ProMonitorUI(TransControl trans_ref)
        {
            trans = trans_ref;
        }

        public void UpdateUI()
        {
            SysTime(this.TB_sysTime);
            SysMode(this.TB_OpMode);

            roomTemp(this.TB_roomTemp);
            inCoilTemp(this.TB_CoilMidTemp);
            outDoorTemp(this.TB_OutTemp);
            outCoilTemp(this.TB_outCoilMid);
            disChargeTemp(this.TB_disCharTemp);
            suctionTemp(this.TB_suctionTemp);
            setTemp(this.TB_SetTemp);
            //
            // 室內機狀態
            inFanGrade(this.TB_InFan);                   // 室內風機等級
            inFault(this.TB_inFault); 
            // 電機狀態
            motoState(this.TB_MotoState);
            motoStateCnt(this.TB_MotoStateCnt);
            OutFanState(this.TB_OutFanState);
            OutFanStateCnt(this.TB_OutFanCnt);
            OutFanSpd(this.TB_OutFanSpd);
            //
            // 工作模式
            inMode(this.TB_RunMod);
            inAppMode(this.TB_SubRunMod);
            WORK_MODE(this.TB_baseMod);
            WORK_STATE(this.TB_runState);
            SYS_STATE(this.TB_sysState);
            FREQ_STATE(this.TB_freqState);
            TestCmd(this.TB_TestCmd);
            // 溫控邏輯
            DTGREAD_STATE(this.TB_DTGREAD_State);
            DTG_timer(this.TB_fgCtrlTimer);
            freqGradeMax(this.TB_freqGradeMax);          // 室外機允許最大頻率等級
            freqGradeOut(this.TB_freqGradeOut);          // 計算頻率等級輸出

            RsDeltaTemp(this.TB_rsDeltaTemp);            // 溫度差
            tempGradeNow(this.TB_tempGradeNow);          // 本次溫度區間
            tempGradeOld(this.TB_tempGradeOld);          // 上次溫度區間
            oTempFreGMax(this.TB_oTempFreGMax);          // 室外溫度限制最大頻率等級
            inFanFreGMax(this.TB_inFanFreGMax);    
            // 除霜狀態資訊
            DEFRO_STATE(this.TB_defrostState);
            DEFRO_timeCnt(this.TB_defortTimeCnt);
            DEFRO_timeTempCnt(this.TB_defortTimeTemp);
            // 錯誤資訊顯示
            Fault_State(this.TB_FaultState);
            Fault_code(this.TB_FaultCode);
            IPMFaultCnt(this.TB_IPMCnt);
            StartUpFaultCnt(this.TB_starCnt);
            compProCnt(this.TB_compProCnt);
            occuredCnt(this.TB_occuredCnt);
            dlyTime(this.TB_dlyTime);
            offTime(this.TB_offTime);
            // 保護限頻資訊
            proNum(this.TB_proNum);
            proFreqGrade(this.TB_proFreqGrade);
            resetTime(this.TB_proresetTime);
            // 運轉資訊
            TargetFreq(this.TB_TargetFreq);
            FactFreq(this.TB_FactFreq);
            VBUS(this.TB_VBUS);
            VAC(this.TB_VAC);
            IAC(this.TB_IAC);
            PFC_State(this.TB_pfcState);
            FourWayValveState(this.TB_forWayValveState);
            MainRelayState(this.TB_mainrelayState);
            IPMTemp(this.TB_IPMTemp);
            Power(this.TB_POWER);
            // 
            AVG_dVolt(this.TB_AVG_dVolt);
            AVG_qVolt(this.TB_AVG_qVolt);
            AVG_Vs(this.TB_AVG_Vs);
            AVG_dCurrent(this.TB_AVG_dCurrent);
            AVG_qCurrent(this.TB_AVG_qCurrent);
            AVG_Is(this.TB_AVG_Is);
            //
            InFaultDisp();
            OutFaultDisp_1();
            OutFaultDisp_2();
            //
            CompressorFault();
            PFCFaultState();
            //
            Protect_Code1();
            Protect_Code2();
            //
            FreqProNum();

        }

        #region 室內外機溫度 / Temperature
        
        /// <summary>
        /// 室內環境溫度 roomTemp
        /// </summary>
        /// <param name="textbox"></param>
        public void roomTemp(TextBox textbox)
        {
            int value = trans.Monitor_Data.Temperature.roomTemp;
            textbox.Text = value.ToString() + " ℃";
        }

        /// <summary>
        /// 室內銅管溫度
        /// </summary>
        /// <param name="textbox"></param>
        public void inCoilTemp(TextBox textbox)
        {
            int value = trans.Monitor_Data.Temperature.inCoilTemp;
            textbox.Text = value.ToString() + " ℃";
        }

        /// <summary>
        /// 室外環境溫度
        /// </summary>
        /// <param name="textbox"></param>
        public void outDoorTemp(TextBox textbox)
        {
            int value = trans.Monitor_Data.Temperature.outDoorTemp;
            textbox.Text = value.ToString() + " ℃";
        }

        /// <summary>
        /// 室外銅管溫度
        /// </summary>
        /// <param name="textbox"></param>
        public void outCoilTemp(TextBox textbox)
        {
            int value = trans.Monitor_Data.Temperature.outCoilTemp;
            textbox.Text = value.ToString() + " ℃";
        }

        /// <summary>
        /// 壓縮機排氣溫度
        /// </summary>
        /// <param name="textbox"></param>
        public void disChargeTemp(TextBox textbox)
        {
            int value = trans.Monitor_Data.Temperature.disChargeTemp;
            textbox.Text = value.ToString() + " ℃";
        }

        /// <summary>
        /// 壓縮機入口溫度
        /// </summary>
        /// <param name="textbox"></param>
        public void suctionTemp(TextBox textbox)
        {
            int value = trans.Monitor_Data.Temperature.suctionTemp;
            textbox.Text = value.ToString() + " ℃";
        }

        /// <summary>
        /// 室內設定溫度
        /// </summary>
        /// <param name="textbox"></param>
        public void setTemp(TextBox textbox)
        {
            int value = trans.Monitor_Data.Temperature.setTemp;
            textbox.Text = value.ToString() + " ℃";
        }

        #endregion

        #region 室內機資訊 / Indoor Information

        /// <summary>
        /// 室內風機等級
        /// </summary>
        /// <param name="textbox"></param>
        public void inFanGrade(TextBox textbox)
        {
            string str = string.Empty;
            switch (trans.Monitor_Data.SysRunInfo.inFanGrade)
            {
                case 0:
                    str = "關閉";
                    textbox.ForeColor = Color.Black;
                    break;
                case 1:
                    str = "防冷風";
                    textbox.ForeColor = Color.Orange;
                    break;
                case 2:
                    str = "靜音風";
                    textbox.ForeColor = Color.Green;
                    break;
                case 3:
                    str = "弱風";
                    textbox.ForeColor = Color.Green;
                    break;
                case 4:
                    str = "中風";
                    textbox.ForeColor = Color.Green;
                    break;
                case 5:
                    str = "強風";
                    textbox.ForeColor = Color.Green;
                    break;
                case 6:
                    str = "強力風";
                    textbox.ForeColor = Color.Green;
                    break;
                case 7:
                    str = "測試風";
                    textbox.ForeColor = Color.Orange;
                    break;
                default:
                    str = "異常";
                    textbox.ForeColor = Color.Red;
                    break;
            }
            textbox.Text = str;
        }

        /// <summary>
        /// 室內機錯誤代碼
        /// </summary>
        /// <param name="textbox"></param>
        public void inFault(TextBox textbox)
        {
            string str = string.Empty;
            Int32 var1 = trans.Monitor_Data.SysRunInfo.Protect_err;   // 錯誤碼
            Int32 var2 = trans.Monitor_Data.SysRunInfo.Protect_lim;   // 限頻碼
            str = "Er " + var1.ToString() + " / " +  "Lim " + var2.ToString();
            textbox.Text = str;
        }

        #endregion

        #region 電機狀態 Motor State

        /// <summary>
        /// 壓縮機狀態
        /// </summary>
        /// <param name="textbox"></param>
        public void motoState(TextBox textbox)
        {
            string str = string.Empty;
            switch (trans.Monitor_Data.motorState.state)
            {
                case 0x00:
                    str = "停機";
                    textbox.ForeColor = Color.Red;
                    break;
                case 0x01:
                    str = "運轉";
                    textbox.ForeColor = Color.Green;
                    break;
                default:
                    break;
            }
            textbox.Text = str;
        }

        /// <summary>
        /// 壓縮機狀態計數
        /// </summary>
        /// <param name="textbox"></param>
        public void motoStateCnt(TextBox textbox)
        {
            string str = string.Empty;
            Int32 var = trans.Monitor_Data.motorState.MotorStCnt;
            str = var.ToString();
            textbox.Text = str + " 秒";
        }

        /// <summary>
        /// 室外風機狀態
        /// </summary>
        /// <param name="textbox"></param>
        public void OutFanState(TextBox textbox)
        {
            string str = string.Empty;
            switch (trans.Monitor_Data.motorState.outFanState)
            {
                case 0x00:
                    str = "停機";
                    textbox.ForeColor = Color.Red;
                    break;
                case 0x01:
                    str = "運轉";
                    textbox.ForeColor = Color.Green;
                    break;
                default:
                    break;
            }
            textbox.Text = str;
        }

        /// <summary>
        /// 室外風機轉速
        /// </summary>
        /// <param name="textbox"></param>
        public void OutFanSpd(TextBox textbox)
        {
            string str = string.Empty;
            Int32 var = trans.Monitor_Data.MotorRunInfo.DCFanSpeed;
            str = var.ToString();
            textbox.Text = str + " rpm";
        }

        /// <summary>
        /// 室外風機狀態計數
        /// </summary>
        /// <param name="textbox"></param>
        public void OutFanStateCnt(TextBox textbox)
        {
            string str = string.Empty;
            Int32 var = trans.Monitor_Data.motorState.outFanStCnt;
            str = var.ToString();
            textbox.Text = str + " 秒";
        }

        #endregion

        #region 溫度變化資訊
        /// <summary>
        /// 溫度變化狀態 DTGREAD_STATE
        /// </summary>
        /// <param name="textbox"></param>
        public void DTGREAD_STATE(TextBox textbox)
        {
            string str = string.Empty;
            switch (trans.Monitor_Data.fgCtrl.state)
            {
                case ResolvePack.DTG_STATE.DTG_HOLDING:
                    // DTG_HOLDING
                    str = "DTG_HOLDING";
                    textbox.ForeColor = Color.Green;
                    break;
                case ResolvePack.DTG_STATE.DTG_FALL:
                    // DTG_FALL
                    str = "DTG_FALL";
                    textbox.ForeColor = Color.Orange;
                    break;
                case ResolvePack.DTG_STATE.DTG_RISE:
                    // DTG_RISE
                    str = "DTG_RISE";
                    textbox.ForeColor = Color.Orange;
                    break;
                case ResolvePack.DTG_STATE.DTG_OFF:
                    // DTG_OFF
                    str = "DTG_OFF";
                    textbox.ForeColor = Color.Blue;
                    break;
                default:
                    str = "Error";
                    textbox.ForeColor = Color.Red;
                    break;
            }
            textbox.Text = str;
        }

        /// <summary>
        /// 頻率區間保持時間
        /// </summary>
        public void DTG_timer(TextBox textbox)
        {
            string str = string.Empty;
            Int32 var = trans.Monitor_Data.fgCtrl.timer;
            str = var.ToString();
            textbox.Text = str + " 秒";
        }

        /// <summary>
        /// 上次溫度區間
        /// </summary>
        /// <param name="textbox"></param>
        public void tempGradeOld(TextBox textbox)
        {
            string str = string.Empty;
            Int32 value = trans.Monitor_Data.fgCtrl.tempGradeOld;
            str = value.ToString();
            textbox.Text = "GRADE " + str;
        }

        /// <summary>
        /// 本次溫度區間
        /// </summary>
        /// <param name="textbox"></param>
        public void tempGradeNow(TextBox textbox)
        {
            string str = string.Empty;
            Int32 value = trans.Monitor_Data.fgCtrl.tempGradNow;
            str = value.ToString();
            textbox.Text = "GRADE " + str;
        }

        /// <summary>
        /// 溫度差
        /// </summary>
        /// <param name="textbox"></param>
        public void RsDeltaTemp(TextBox textbox)
        {
            string str = string.Empty;
            Int32 value = trans.Monitor_Data.fgCtrl.rsDeltaTemp;
            if (value > 127) value -= 256;
            if (value >= 0) textbox.ForeColor = Color.Black;
            else textbox.ForeColor = Color.Red;
            str = value.ToString();
            textbox.Text = str + " ℃";
        }

        /// <summary>
        /// 計算頻率等級輸出
        /// </summary>
        /// <param name="textbox"></param>
        public void freqGradeOut(TextBox textbox)
        {
            string str = string.Empty;
            Int32 value = trans.Monitor_Data.fgCtrl.freqGradeOut;
            str = value.ToString();
            textbox.Text = str + " 級";
        }

        /// <summary>
        /// 室外機允許最大頻率等級
        /// </summary>
        /// <param name="textbox"></param>
        public void freqGradeMax(TextBox textbox)
        {
            string str = string.Empty;
            Int32 value = trans.Monitor_Data.fgCtrl.freqGradeMax;
            str = value.ToString();
            textbox.Text = str + " 級";
        }

        /// <summary>
        /// 室外溫度限制最大頻率等級
        /// </summary>
        /// <param name="textbox"></param>
        public void oTempFreGMax(TextBox textbox)
        {
            string str = string.Empty;
            Int32 value = trans.Monitor_Data.fgCtrl.oTempFreGMax;
            str = value.ToString();
            textbox.Text = str + " 級";
        }

        /// <summary>
        /// 室內風速限制最大頻率等級
        /// </summary>
        /// <param name="textbox"></param>
        public void inFanFreGMax(TextBox textbox)
        {
            string str = string.Empty;
            Int32 value = trans.Monitor_Data.fgCtrl.inFanFreGMax;
            str = value.ToString();
            textbox.Text = str + " 級";
        }
        #endregion

        #region 除霜狀態資訊

        /// <summary>
        /// 除霜狀態 DEFRO_STATE
        /// </summary>
        /// <param name="textbox"></param>
        public void DEFRO_STATE(TextBox textbox)
        {
            string str = string.Empty;
            switch (trans.Monitor_Data.defro.state)
            {
                case ResolvePack.DEFRO_STATE.DEFRO_HEATING:
                    // DEFRO_HEATING
                    str = "DEFRO_HEATING";
                    textbox.ForeColor = Color.Orange;
                    break;
                case ResolvePack.DEFRO_STATE.DEFRO_STAR:
                    // DEFRO_STAR
                    str = "DEFRO_STAR";
                    textbox.ForeColor = Color.Blue;
                    break;
                case ResolvePack.DEFRO_STATE.DEFRO_RUN:
                    // DEFRO_RUN
                    str = "DEFRO_RUN";
                    textbox.ForeColor = Color.Green;
                    break;
                case ResolvePack.DEFRO_STATE.DEFRO_END:
                    // DEFRO_END
                    str = "DEFRO_END";
                    textbox.ForeColor = Color.Red;
                    break;
                default:
                    // ERROR
                    str = "ERROR";
                    textbox.ForeColor = Color.Red;
                    break;
            }
            textbox.Text = str;
        }

        /// <summary>
        /// 除霜-制熱流程切換計時器
        /// </summary>
        /// <param name="textbox"></param>
        public void DEFRO_timeCnt(TextBox textbox)
        {
            string str = string.Empty;
            Int32 var = trans.Monitor_Data.defro.timeCnt;
            str = var.ToString();
            textbox.Text = str + " 秒";
        }

        /// <summary>
        /// 滿足除霜溫度時間計數器
        /// </summary>
        /// <param name="textbox"></param>
        public void DEFRO_timeTempCnt(TextBox textbox)
        {
            string str = string.Empty;
            Int32 var = trans.Monitor_Data.defro.timeTempCnt;
            str = var.ToString();
            textbox.Text = str + " 秒";
        }

        #endregion

        #region 系統工作模式

        /// <summary>
        /// 室內機運行模式
        /// </summary>
        public void inMode(TextBox textbox)
        {
            string str = string.Empty;
            switch(trans.Monitor_Data.SysRunInfo.inMode)
            {
                case ResolvePack.WORK_MODE.WMS_OFF:
                    // WMS_OFF
                    str = "停機";
                    textbox.ForeColor = Color.Black;
                    break;
                case ResolvePack.WORK_MODE.WMS_REFRIGERATING:
                    // WMS_REFRIGERATING
                    str = "冷氣";
                    textbox.ForeColor = Color.DeepSkyBlue;
                    break;
                case ResolvePack.WORK_MODE.WMS_WIND:
                    // 
                    str = "送風";
                    textbox.ForeColor = Color.DeepSkyBlue;
                    break;
                case ResolvePack.WORK_MODE.WMS_DEHUMIDIFIERING:
                    // WMS_DEHUMIDIFIREING
                    str = "除濕";
                    textbox.ForeColor = Color.DeepSkyBlue;
                    break;
                case ResolvePack.WORK_MODE.WMS_HEATING:
                    // WMS_HEATING
                    str = "暖氣";
                    textbox.ForeColor = Color.OrangeRed;
                    break;
                case ResolvePack.WORK_MODE.WMS_AUTO:
                    // WMS_AUTO
                    str = "自動";
                    textbox.ForeColor = Color.Green;
                    break;
                case ResolvePack.WORK_MODE.WMS_TESTING:
                    // WMS_TESTING
                    str = "測試";
                    textbox.ForeColor = Color.BlueViolet;
                    break;
                case ResolvePack.WORK_MODE.WMS_WARMUP:
                    // WMS_WARMUP
                    str = "預熱";
                    textbox.ForeColor = Color.OrangeRed;
                    break;
                case ResolvePack.WORK_MODE.WMS_COOL_TESTING:
                    // WMS_COOL_TESTING
                    str = "製冷測試";
                    textbox.ForeColor = Color.BlueViolet;
                    break;
                case ResolvePack.WORK_MODE.WMS_HEAT_TESTING:
                    // WMS_HEAT_TESTING
                    str = "製熱測試";
                    textbox.ForeColor = Color.BlueViolet;
                    break;
                default:
                    str = "Error";
                    textbox.ForeColor = Color.Red;
                    break;
            }
            textbox.Text = str;
        }

        /// <summary>
        /// 室內機子工作模式
        /// </summary>
        /// <param name="textbox"></param>
        public void inAppMode(TextBox textbox)
        {
            string str = string.Empty;
            switch (trans.Monitor_Data.SysRunInfo.inModeApp)
            {
                case ResolvePack.SUB_MODE.NO_SUB:
                    // NO_SUB
                    str = "無";
                    break;
                case ResolvePack.SUB_MODE.SUB_FORCE:
                    // SUB_FORCE
                    str = "強制運行";
                    break;
                case ResolvePack.SUB_MODE.SUB_TEST:
                    // SUB_TEST
                    str = "測試模式";
                    break;
                case ResolvePack.SUB_MODE.SUB_SLEEP:
                    // SUB_SLEEP
                    str = "睡眠模式";
                    break;
                case ResolvePack.SUB_MODE.SUB_ECONO:
                    // SUB_ECONO
                    str = "經濟模式";
                    break;
                case ResolvePack.SUB_MODE.SUB_POWER:
                    // SUB_POWER
                    str = "強力模式";
                    break;
                case ResolvePack.SUB_MODE.SUB_QUITE:
                    // SUB_QUITE
                    str = "靜音模式";
                    break;
                case ResolvePack.SUB_MODE.SUB_VENTILATE:
                    //SUB_VENTILATE
                    str = "通風模式";
                    break;
                default:
                    str = "Error";
                    break;
            }
            textbox.Text = str;
        }

        /// <summary>
        /// 系統狀態 SYS_STATE
        /// </summary>
        /// <param name="textbox"></param>
        public void SYS_STATE(TextBox textbox)
        {
            string str = string.Empty;
            switch (trans.Monitor_Data.SysRunInfo.state)
            {
                case ResolvePack.SYS_STATE.SYS_IDLE:
                    // SYS_IDLE 系統待機
                    str = "SYS_IDLE";
                    textbox.ForeColor = Color.Black;
                    break;
                case ResolvePack.SYS_STATE.SYS_RESET:
                    // SYS_RESET 系統重置
                    str = "SYS_RESET";
                    textbox.ForeColor = Color.Orange;
                    break;
                case ResolvePack.SYS_STATE.SYS_FAULT:
                    // SYS_FAULT 系統錯誤
                    str = "SYS_FAULT";
                    textbox.ForeColor = Color.Red;
                    break;
                case ResolvePack.SYS_STATE.SYS_PROTECT:
                    // SYS_PROTECT 系統保護
                    str = "SYS_PROTECT";
                    textbox.ForeColor = Color.Red;
                    break;
                case ResolvePack.SYS_STATE.SYS_RUN:
                    // SYS_RUN 系統正常運行
                    str = "SYS_RUN";
                    textbox.ForeColor = Color.Green;
                    break;
                case ResolvePack.SYS_STATE.SYS_OFF_DLY:
                    // SYS_OFF_DLY 延遲停機
                    str = "SYS_OFF_DLY";
                    textbox.ForeColor = Color.Orange;
                    break;
                case ResolvePack.SYS_STATE.SYS_POWERUP_DLY:
                    // SYS_POWER_DLY 延遲啟動
                    str = "SYS_POWER_DLY";
                    textbox.ForeColor = Color.Orange;
                    break;
                default:
                    str = "Error";
                    textbox.ForeColor = Color.Red;
                    break;
            }
            textbox.Text = str;
        }

        /// <summary>
        /// 工作模式 WORK_MODE
        /// </summary>
        /// <param name="textbox"></param>
        public void WORK_MODE(TextBox textbox)
        {
            string str = string.Empty;
            switch (trans.Monitor_Data.SysRunInfo.basicRunMode)
            {
                case ResolvePack.WORK_MODE.WMS_OFF:
                    // WMS_OFF 停機
                    str = "WMS_OFF";
                    break;
                case ResolvePack.WORK_MODE.WMS_REFRIGERATING:
                    // WMS_REFRIGERATING 冷氣
                    str = "WMS_REFRIGERATING";
                    break;
                case ResolvePack.WORK_MODE.WMS_WIND:
                    // 送風
                    str = " NONE DEFINE";
                    break;
                case ResolvePack.WORK_MODE.WMS_DEHUMIDIFIERING:
                    //WMS_DEHUMIDIFIERING 除濕
                    str = "WMS_DEHUMIDIFIERING";
                    break;
                case ResolvePack.WORK_MODE.WMS_HEATING:
                    // WMS_HEATING 暖氣
                    str = "WMS_HEATING";
                    break;
                case ResolvePack.WORK_MODE.WMS_AUTO:
                    // WMS_AUTO 自動
                    str = "WMS_AUTO";
                    break;
                case ResolvePack.WORK_MODE.WMS_TESTING:
                    // WMS_TESTING 測試
                    str = "WMS_TESTING";
                    break;
                case ResolvePack.WORK_MODE.WMS_WARMUP:
                    // WMS_WARMUP 預熱
                    str = "WMS_WARMUP";
                    break;
                case ResolvePack.WORK_MODE.WMS_COOL_TESTING:
                    // WMS_COOL_TESTING 制冷測試
                    str = "WMS_COOL_TESTING";
                    break;
                case ResolvePack.WORK_MODE.WMS_HEAT_TESTING:
                    // WMS_HEAT_TESTING 制熱測試
                    str = "WMS_HEAT_TESTING";
                    break;
                default:
                    str = "Error";
                    break;
            }
            textbox.Text = str;
        }

        /// <summary>
        /// 子工作模式
        /// </summary>
        /// <param name="textbox"></param>
        public void SUB_MODE(TextBox textbox)
        {
            // TODO :
        }

        /// <summary>
        /// 運行狀態
        /// </summary>
        /// <param name="textbox"></param>
        public void WORK_STATE(TextBox textbox)
        {
            string str = string.Empty;
            switch (trans.Monitor_Data.SysRunInfo.wkState)
            {
                case ResolvePack.WORK_STATE.WS_IDLE:
                    // WS_IDLE
                    str = "WS_IDLE";
                    textbox.ForeColor = Color.Black;
                    break;
                case ResolvePack.WORK_STATE.WS_STAR:
                    // WS_STAR
                    str = "WS_STAR";
                    textbox.ForeColor = Color.Orange;
                    break;
                case ResolvePack.WORK_STATE.WS_RUN:
                    // WS_RUN
                    str = "WS_RUN";
                    textbox.ForeColor = Color.Green;
                    break;
                case ResolvePack.WORK_STATE.WS_OFFING:
                    // WS_OFFING
                    str = "WS_OFFING";
                    textbox.ForeColor = Color.Red;
                    break;
                case ResolvePack.WORK_STATE.WS_OFF:
                    // WS_OFF
                    str = "WS_OFF";
                    textbox.ForeColor = Color.Black;
                    break;
                default:
                    str = "Error";
                    textbox.ForeColor = Color.Red;
                    break;
            }
            textbox.Text = str;
        }

        /// <summary>
        /// 頻率狀態 FREQ_STATE
        /// </summary>
        /// <param name="textbox"></param>
        public void FREQ_STATE(TextBox textbox)
        {
            string str = string.Empty;
            switch (trans.Monitor_Data.SysRunInfo.fcState)
            {
                case ResolvePack.FREQ_STATE.FREQ_STOP:
                    // FREQ_STOP 正常停機
                    str = "FREQ_STOP";
                    textbox.ForeColor = Color.Black;
                    break;
                case ResolvePack.FREQ_STATE.FORCE_ZERO:
                    // FORCE_ZERO 強制關機
                    str = "FORCE_ZERO";
                    textbox.ForeColor = Color.Red;
                    break;
                case ResolvePack.FREQ_STATE.FORBID_STAR:
                    //FORBID_STAR 禁止啟動
                    str = "FORBID_STAR";
                    textbox.ForeColor = Color.Red;
                    break;
                case ResolvePack.FREQ_STATE.FREQ_STAR:
                    // FREQ_STAR 啟動
                    str = "FREQ_STAR";
                    textbox.ForeColor = Color.Orange;
                    break;
                case ResolvePack.FREQ_STATE.FREQ_AUTO:
                    // FREQ_AUTO 自動計算
                    str = "FREQ_AUTO";
                    textbox.ForeColor = Color.Green;
                    break;
                case ResolvePack.FREQ_STATE.FORCE_FALLING_80:
                    // FORCE_FALLING_80
                    str = "FORCE_FALLING_80";
                    textbox.ForeColor = Color.Orange;
                    break;
                case ResolvePack.FREQ_STATE.FORCE_FALLING_70:
                    // FORCE_FALLING_70
                    str = "FORCE_FALLING_70";
                    textbox.ForeColor = Color.Orange;
                    break;
                case ResolvePack.FREQ_STATE.FREQ_HOLDING:
                    // FREQ_HOLDING 禁止升頻
                    str = "FREQ_HOLDING";
                    textbox.ForeColor = Color.Red;
                    break;
                //case 0x08:
                //    // FORCE_FALLING_BASE 降至基頻
                //    str = "FORCE_FALLING_BASE";
                //    textbox.ForeColor = Color.Orange;
                //    break;
                //case 0x09:
                //    // FORCE_FALLING_MIN 降至最小頻率
                //    str = "FORCE_FALLING_MIN";
                //    textbox.ForeColor = Color.Orange;
                //    break;
                default:
                    str = "Error";
                    break;
            }
            textbox.Text = str;
        }

        /// <summary>
        /// 測試命令 TestCmd
        /// </summary>
        /// <param name="textbox"></param>
        public void TestCmd(TextBox textbox)
        {
            string str = string.Empty;
            switch (trans.Monitor_Data.SysRunInfo.testCmd)
            {
                case 0:
                    str = "NO_TEST";
                    break;
                case 8:
                    str = "EUR_LOW";
                    break;
                case 9:
                    str = "EUR_MID";
                    break;
                case 10:
                    str = "EUR_HI";
                    break;
                case 16:
                    str = "NORA_1";
                    break;
                case 17:
                    str = "NORA_2";
                    break;
                case 18:
                    str = "NORA_3";
                    break;
                case 19:
                    str = "NORA_4";
                    break;
                case 20:
                    str = "NORA_5";
                    break;
                case 21:
                    str = "NORA_6";
                    break;
                case 22:
                    str = "NORA_7";
                    break;
                case 23:
                    str = "NORA_8";
                    break;
                case 33:
                    str = "FORCE_REFR";
                    break;
                case 34:
                    str = "Q_REFR";
                    break;
                case 35:
                    str = "Q_HEAT";
                    break;
                case 36:
                    str = "RATED_FREQ";
                    break;
                case 37:
                    str = "FORCE_RUN";
                    break;
                case 38:
                    str = "MER_TEST";
                    break;
                default:
                    str = "ERROR";
                    break;
            }
            textbox.Text = str;
        }

        #endregion

        #region 錯誤資訊顯示

        /// <summary>
        /// 故障-保護狀態
        /// </summary>
        /// <param name="text"></param>
        public void Fault_State(TextBox textbox)
        {
            string str = string.Empty;
            switch (trans.Monitor_Data.sysFault.state)
            {
                case ResolvePack.FAULT_STATE.NO_FAULT:
                    str = "NO_FAULT";
                    textbox.ForeColor = Color.Green;
                    break;
                case ResolvePack.FAULT_STATE.FAULT:
                    str = "FAULT";
                    textbox.ForeColor = Color.Red;
                    break;
                case ResolvePack.FAULT_STATE.PROTECT:
                    str = "PROTECT";
                    textbox.ForeColor = Color.Orange;
                    break;
                case ResolvePack.FAULT_STATE.PROTECT_DELAY:
                    str = "PROTECT_DELAY";
                    textbox.ForeColor = Color.Orange;
                    break;
                case ResolvePack.FAULT_STATE.PROTECT_RESET:
                    str = "PROTECT_RESET";
                    textbox.ForeColor = Color.SkyBlue;
                    break;
            }
            textbox.Text = str;
        }

        /// <summary>
        /// 故障-保護編號
        /// </summary>
        /// <param name="textbox"></param>
        public void Fault_code(TextBox textbox)
        {
            string str = string.Empty;
            switch (trans.Monitor_Data.sysFault.code)
            {
                case ResolvePack.FAULT_CODE.FAULT_NONE:
                    str = "FAULT_NONE";
                    textbox.ForeColor = Color.Green;
                    break;
                case ResolvePack.FAULT_CODE.FAULT_IPM:
                    str = "FAULT_IPM";
                    textbox.ForeColor = Color.Red;
                    break;
                case ResolvePack.FAULT_CODE.FAULT_OUTEMP_SENSOR:
                    str = "FAULT_OUTEMP_SENSOR";
                    textbox.ForeColor = Color.Red;
                    break;
                case ResolvePack.FAULT_CODE.FAULT_OUTCOIL_SENSOR:
                    str = "FAULT_OUTCOIL_SENSOR";
                    textbox.ForeColor = Color.Red;
                    break;
                case ResolvePack.FAULT_CODE.FAULT_SUCT_SENSOR:
                    str = "FAULT_SUCT_SENSOR";
                    textbox.ForeColor = Color.Red;
                    break;
                case ResolvePack.FAULT_CODE.FAULT_DISC_SENSOR:
                    str = "FAULT_DISC_SENSOR";
                    textbox.ForeColor = Color.Red;
                    break;
                case ResolvePack.FAULT_CODE.FAULT_CUR_SENSOR:
                    str = "FAULT_CUR_SENSOR";
                    textbox.ForeColor = Color.Red;
                    break;
                case ResolvePack.FAULT_CODE.FAULT_COMPRESS:
                    str = "FAULT_COMPRESS";
                    textbox.ForeColor = Color.Red;
                    break;
                case ResolvePack.FAULT_CODE.FAULT_PHASE:
                    str = "FAULT_PHASE";
                    textbox.ForeColor = Color.Red;
                    break;
                case ResolvePack.FAULT_CODE.FAULT_BACK_SENSOR:
                    str = "FAULT_BACK_SENSOR";
                    textbox.ForeColor = Color.Red;
                    break;
                case ResolvePack.FAULT_CODE.PROTECT_IPM:
                    str = "PROTECT_IPM";
                    textbox.ForeColor = Color.Orange;
                    break;
                case ResolvePack.FAULT_CODE.PROTECT_IAC:
                    str = "PROTECT_IAC";
                    textbox.ForeColor = Color.Orange;
                    break;
                case ResolvePack.FAULT_CODE.PROTECT_DISCHAR_TEMP:
                    str = "PROTECT_DISCHAR_TEMP";
                    textbox.ForeColor = Color.Orange;
                    break;
                case ResolvePack.FAULT_CODE.PROTECT_TOP_TEMP:
                    str = "PROTECT_TOP_TEMP";
                    textbox.ForeColor = Color.Orange;
                    break;
                case ResolvePack.FAULT_CODE.PROTECT_SUCT_TEMP:
                    str = "PROTECT_SUCT_TEMP";
                    textbox.ForeColor = Color.Orange;
                    break;
                case ResolvePack.FAULT_CODE.PROTECT_VBUS:
                    str = "PROTECT_VBUS";
                    textbox.ForeColor = Color.Orange;
                    break;
                case ResolvePack.FAULT_CODE.PROTECT_LOW_PRESSURE:
                    str = "PROTECT_LOW_PRESSURE";
                    textbox.ForeColor = Color.Orange;
                    break;
                case ResolvePack.FAULT_CODE.PROTECT_OVER_PRESSURE:
                    str = "PROTECT_OVER_PRESSURE";
                    textbox.ForeColor = Color.Orange;
                    break;
                case ResolvePack.FAULT_CODE.PROTECT_INCOIL_TEMP:
                    str = "PROTECT_INCOIL_TEMP";
                    textbox.ForeColor = Color.Orange;
                    break;
                case ResolvePack.FAULT_CODE.PROTECT_OUTDOOR_TEMP:
                    str = "PROTECT_OUTDOOR_TEMP";
                    textbox.ForeColor = Color.Orange;
                    break;
                case ResolvePack.FAULT_CODE.FAULT_COMMUN:
                    str = "FAULT_COMMUN";
                    textbox.ForeColor = Color.Red;
                    break;
                case ResolvePack.FAULT_CODE.FAULT_EEPROM:
                    str = "FAULT_EEPROM";
                    textbox.ForeColor = Color.Red;
                    break;
                case ResolvePack.FAULT_CODE.FAULT_STAR:
                    str = "FAULT_STAR";
                    textbox.ForeColor = Color.Red;
                    break;
                case ResolvePack.FAULT_CODE.FAULT_FANMOTOR:
                    str = "FAULT_FANMOTOR";
                    textbox.ForeColor = Color.Red;
                    break;
                case ResolvePack.FAULT_CODE.PROTECT_IPM_TEMP:
                    str = "PROTECT_IPM_TEMP";
                    textbox.ForeColor = Color.Red;
                    break;
                case ResolvePack.FAULT_CODE.PROTECT_IPM_SOFT_OVERCUR:
                    str = "PROTECT_IPM_SOFT_OVERCUR";
                    textbox.ForeColor = Color.Red;
                    break;
                case ResolvePack.FAULT_CODE.FAULT_VBUS:
                    str = "FAULT_VBUS";
                    textbox.ForeColor = Color.Red;
                    break;
                case ResolvePack.FAULT_CODE.PROTECT_COMMUN:
                    str = "PROTECT_COMMUN";
                    textbox.ForeColor = Color.Orange;
                    break;
                case ResolvePack.FAULT_CODE.PROTECT_STAR:
                    str = "PROTECT_STAR";
                    textbox.ForeColor = Color.Orange;
                    break;
                case ResolvePack.FAULT_CODE.FAULT_LACKFI:
                    str = "FAULT_LACKFI";
                    textbox.ForeColor = Color.Red;
                    break;
                case ResolvePack.FAULT_CODE.PROTECT_INERR:
                    str = "PROTECT_INERR";
                    textbox.ForeColor = Color.Orange;
                    break;
                case ResolvePack.FAULT_CODE.PROTECT_COM_DRIVER:
                    str = "PROTECT_COM_DRIVER";
                    textbox.ForeColor = Color.Orange;
                    break;
                case ResolvePack.FAULT_CODE.PROTECT_OUT_COIL_TEMP:
                    str = "PROTECT_OUT_COIL_TEMP";
                    textbox.ForeColor = Color.Orange;
                    break;
                case ResolvePack.FAULT_CODE.FAULT_FORCE_OFF:
                    str = "FAULT_FORCE_OFF";
                    textbox.ForeColor = Color.Red;
                    break;
                case ResolvePack.FAULT_CODE.FAULT_PFC:
                    str = "FAULT_PFC";
                    textbox.ForeColor = Color.Red;
                    break;
                case ResolvePack.FAULT_CODE.FAULT_VAC:
                    str = "FAULT_VAC";
                    textbox.ForeColor = Color.Red;
                    break;
                case ResolvePack.FAULT_CODE.FAULT_IPM_SENSOR:
                    str = "FAULT_IPM_SENSOR";
                    textbox.ForeColor = Color.Red;
                    break;
                case ResolvePack.FAULT_CODE.PROTECT_IAC_LOW:
                    str = "PROTECT_IAC_LOW";
                    textbox.ForeColor = Color.Red;
                    break;
                default:
                    str = "Error";
                    textbox.ForeColor = Color.Red;
                    break;
            }
            textbox.Text = str;
        }

        /// <summary>
        /// IPM 保護次數
        /// </summary>
        /// <param name="textbox"></param>
        public void IPMFaultCnt(TextBox textbox)
        {
            Int32 value = trans.Monitor_Data.sysFault.ipmCnt;
            textbox.Text = value.ToString();
        }

        /// <summary>
        /// 啟動保護次數
        /// </summary>
        /// <param name="textbox"></param>
        public void StartUpFaultCnt(TextBox textbox)
        {
            Int32 value = trans.Monitor_Data.sysFault.compProCnt;
            textbox.Text = value.ToString();
        }

        /// <summary>
        /// 驅動保護次數
        /// </summary>
        /// <param name="textbox"></param>
        public void compProCnt(TextBox textbox)
        {
            Int32 value = trans.Monitor_Data.sysFault.compProCnt;
            textbox.Text = value.ToString();
        }

        /// <summary>
        /// 故障-保護發生次數
        /// </summary>
        /// <param name="textbox"></param>
        public void occuredCnt(TextBox textbox)
        {
            Int32 value = trans.Monitor_Data.sysFault.occuredCnt;
            textbox.Text = value.ToString();
        }

        /// <summary>
        /// 故障延遲復位時間
        /// </summary>
        /// <param name="textbox"></param>
        public void dlyTime(TextBox textbox)
        {
            Int32 value = trans.Monitor_Data.sysFault.dlyTime;
            textbox.Text = value.ToString() + " 秒";
        }

        /// <summary>
        /// 保護關機時間
        /// </summary>
        /// <param name="textbox"></param>
        public void offTime(TextBox textbox)
        {
            Int32 value = trans.Monitor_Data.sysFault.offTimer;
            textbox.Text = value.ToString() + " 秒";
        }

        #endregion

        #region 保護限頻資訊

        /// <summary>
        /// 降頻保護代碼
        /// </summary>
        /// <param name="textbox"></param>
        public void proNum(TextBox textbox)
        {
            string str = string.Empty;
            switch (trans.Monitor_Data.sysFreqPro.proNum)
            {
                case 0x00:
                    // 無降頻保護
                    str = "NO_PROTECT";
                    textbox.ForeColor = Color.Green;
                    break;
                case 0x01:
                    // 製冷室內銅管凍結限頻保護
                    str = "RINCOIL_PRO";
                    textbox.ForeColor = Color.Red;
                    break;
                case 0x02:
                    // 製熱室外銅管防過熱限頻保護
                    str = "ROUTCOIL_PRO";
                    textbox.ForeColor = Color.Red;
                    break;
                case 0x04:
                    // 製熱室內銅管防過熱限頻保護
                    str = "HINCOIL_PRO";
                    textbox.ForeColor = Color.Red;
                    break;
                case 0x08:
                    // 排氣高溫限頻保護
                    str = "DISCHARGE_PRO";
                    textbox.ForeColor = Color.Red;
                    break;
                case 0x10:
                    // 交流電流限頻保護
                    str = "IAC_PRO";
                    textbox.ForeColor = Color.Red;
                    break;
                case 0x20:
                    // 母線電壓限頻保護
                    str = "VBUS_PRO";
                    textbox.ForeColor = Color.Red;
                    break;
                case 0x40:
                    // 壓縮機電流超載限頻保護
                    str = "IC_OL_PRO";
                    textbox.ForeColor = Color.Red;
                    break;
                case 0x80:
                    // 室內機風扇限頻
                    str = "INFAN_LO_PRO";
                    textbox.ForeColor = Color.Red;
                    break;
            }
            textbox.Text = str;
        }

        /// <summary>
        /// 降頻保護頻率檔位
        /// </summary>
        /// <param name="textbox"></param>
        public void proFreqGrade(TextBox textbox)
        {
            string str = string.Empty;
            Int32 value = trans.Monitor_Data.sysFreqPro.proFreqGrade;
            str = value.ToString();
            textbox.Text = str + " 級";
        }

        /// <summary>
        /// 降頻保護恢復時間
        /// </summary>
        /// <param name="textbox"></param>
        public void resetTime(TextBox textbox)
        {
            Int32 value = trans.Monitor_Data.sysFreqPro.resetTime;
            textbox.Text = value.ToString() + " 秒";
        }

        #endregion

        #region 故障燈號顯示 / Error Display

        /// <summary>
        /// 錯誤顯示 : 字體(粗體) 顏色 (紅)
        /// </summary>
        /// <param name="label"></param>
        public void ErrorDisp(Label label)
        {
            Font f = new Font(new FontFamily(label.Font.Name), 9, FontStyle.Bold);
            label.Font = f;
            label.ForeColor = Color.Red;
        }

        /// <summary>
        /// 正常顯示 : 字體(正常) 顏色(灰)
        /// </summary>
        /// <param name="label"></param>
        public void NormalDisp(Label label)
        {
            Font f = new Font(new FontFamily(label.Font.Name), 9, FontStyle.Regular);
            label.Font = f;
            label.ForeColor = Color.Gray;
        }

        #region 故障狀態資訊 / Fault

        /// <summary>
        /// 室內機故障功能顯示
        /// </summary>
        public void InFaultDisp()
        {
            // 室內環境溫度感測器故障
            if (trans.Monitor_Data.inFaultInfo.roomTempSensor)
                ErrorDisp(this.LB_indoorTempFault);
            else
                NormalDisp(this.LB_indoorTempFault);

            // 室內銅管溫度感測器故障
            if (trans.Monitor_Data.inFaultInfo.inCoilMidSensor)
                ErrorDisp(this.LB_inCoilFault);
            else
                NormalDisp(this.LB_inCoilFault);

            // 室內風機故障
            if (trans.Monitor_Data.inFaultInfo.inFan)
                ErrorDisp(this.LB_inFanFault);
            else
                NormalDisp(this.LB_inFanFault);

            // 室內銅管溫度過低
            if (trans.Monitor_Data.inFaultInfo.inCoilFreeze)
                ErrorDisp(this.LB_inCoilLoTempFault);
            else
                NormalDisp(this.LB_inCoilLoTempFault);

            // 室內銅管溫度過高
            if (trans.Monitor_Data.inFaultInfo.inCoilExcHeat)
                ErrorDisp(this.LB_inCoilHiTempFault);
            else
                NormalDisp(this.LB_inCoilHiTempFault);

        }

        /// <summary>
        /// 室外機錯誤訊息顯示 1 
        /// </summary>
        public void OutFaultDisp_1()
        {
            // IPM Fault
            if (trans.Monitor_Data.FaultInfo.IPMFault)
                ErrorDisp(this.LB_IPMFault);
            else
                NormalDisp(this.LB_IPMFault);
            // 室外環境溫度感測器故障
            if (trans.Monitor_Data.FaultInfo.outTempSensor)
                ErrorDisp(this.LB_OutTempFault);
            else
                NormalDisp(this.LB_OutTempFault);

            // 室外銅管溫度感測器故障
            if (trans.Monitor_Data.FaultInfo.outCoilMidSensor)
                ErrorDisp(this.LB_CoilMidTempFault);
            else
                NormalDisp(this.LB_CoilMidTempFault);

            // 壓縮機進氣溫度感測器故障
            if (trans.Monitor_Data.FaultInfo.suctionSensor)
                ErrorDisp(this.LB_suctionFault);
            else
                NormalDisp(this.LB_suctionFault);

            // 壓縮機排氣溫度感測器故障
            if (trans.Monitor_Data.FaultInfo.discharSensor)
                ErrorDisp(this.LB_disCharTempFault);
            else
                NormalDisp(this.LB_disCharTempFault);

            // 電流感測器故障
            if (trans.Monitor_Data.FaultInfo.curSensor)
                ErrorDisp(this.LB_CurrentSenFault);
            else
                NormalDisp(this.LB_CurrentSenFault);

            if (trans.Monitor_Data.FaultInfo.vBusErr == 1)
            {
                // 電壓感測器 ( 電壓過高 )
                ErrorDisp(this.LB_HighVoltFault);
                NormalDisp(this.LB_LowVoltFault);
            }
            else if (trans.Monitor_Data.FaultInfo.vBusErr == 2)
            {
                // 電壓感測器 ( 電壓過低 )
                NormalDisp(this.LB_HighVoltFault);
                ErrorDisp(this.LB_LowVoltFault);
            }
            else
            {
                NormalDisp(this.LB_HighVoltFault);
                NormalDisp(this.LB_LowVoltFault);
            }
        }

        /// <summary>
        /// 室外機錯誤訊息顯示 2 
        /// </summary>
        public void OutFaultDisp_2()
        {
            // 室外機風扇故障
            if (trans.Monitor_Data.FaultInfo.outFanMotor)
                ErrorDisp(this.LB_outfan_err);
            else
                NormalDisp(this.LB_outfan_err);

            // 室內外通訊故障
            if (trans.Monitor_Data.FaultInfo.communicate)
                ErrorDisp(this.LB_communicate_err);
            else
                NormalDisp(this.LB_communicate_err);

            // IPM 溫度感測器故障
            if (trans.Monitor_Data.FaultInfo.IPMSensorErr)
                ErrorDisp(this.LB_IPMSensorErr);
            else
                NormalDisp(this.LB_IPMSensorErr);

        }

        /// <summary>
        /// 壓縮機故障狀態
        /// </summary>
        public void CompressorFault()
        {
            switch(trans.Monitor_Data.FaultInfo.MotorFault)
            {
                case ResolvePack.MOTOR_FAULT.None:
                    NormalDisp(this.LB_StartUpErr);
                    NormalDisp(this.LB_PhaseLose);
                    NormalDisp(this.LB_ZeroSpeed);
                    NormalDisp(this.LB_LoseSpeed);
                    NormalDisp(this.LB_ICompOver);
                    NormalDisp(this.LB_PhaseErr);
                    break;
                case ResolvePack.MOTOR_FAULT.StartUpErr:
                    // 啟動故障
                    ErrorDisp(this.LB_StartUpErr);
                    NormalDisp(this.LB_PhaseLose);
                    NormalDisp(this.LB_ZeroSpeed);
                    NormalDisp(this.LB_LoseSpeed);
                    NormalDisp(this.LB_ICompOver);
                    NormalDisp(this.LB_PhaseErr);
                    break;
                case ResolvePack.MOTOR_FAULT.PhaseLose:
                    // 缺相保護
                    NormalDisp(this.LB_StartUpErr);
                    ErrorDisp(this.LB_PhaseLose);
                    NormalDisp(this.LB_ZeroSpeed);
                    NormalDisp(this.LB_LoseSpeed);
                    NormalDisp(this.LB_ICompOver);
                    NormalDisp(this.LB_PhaseErr);
                    break;
                case ResolvePack.MOTOR_FAULT.ZeroSpeed:
                    // 零速保護
                    NormalDisp(this.LB_StartUpErr);
                    NormalDisp(this.LB_PhaseLose);
                    ErrorDisp(this.LB_ZeroSpeed);
                    NormalDisp(this.LB_LoseSpeed);
                    NormalDisp(this.LB_ICompOver);
                    NormalDisp(this.LB_PhaseErr);
                    break;
                case ResolvePack.MOTOR_FAULT.LoseSpeed:
                    // 失速保護
                    NormalDisp(this.LB_StartUpErr);
                    NormalDisp(this.LB_PhaseLose);
                    NormalDisp(this.LB_ZeroSpeed);
                    ErrorDisp(this.LB_LoseSpeed);
                    NormalDisp(this.LB_ICompOver);
                    NormalDisp(this.LB_PhaseErr);
                    break;
                case ResolvePack.MOTOR_FAULT.ICompOver:
                    // 過流保護
                    NormalDisp(this.LB_StartUpErr);
                    NormalDisp(this.LB_PhaseLose);
                    NormalDisp(this.LB_ZeroSpeed);
                    NormalDisp(this.LB_LoseSpeed);
                    ErrorDisp(this.LB_ICompOver);
                    NormalDisp(this.LB_PhaseErr);
                    break;
                case ResolvePack.MOTOR_FAULT.PhaseErr:
                    // 相序錯誤
                    NormalDisp(this.LB_StartUpErr);
                    NormalDisp(this.LB_PhaseLose);
                    NormalDisp(this.LB_ZeroSpeed);
                    NormalDisp(this.LB_LoseSpeed);
                    NormalDisp(this.LB_ICompOver);
                    ErrorDisp(this.LB_PhaseErr);
                    break;
                default:
                    break;
            }
        }

        /// <summary>
        /// PFC 故障狀態
        /// </summary>
        public void PFCFaultState()
        {
            // AC 電壓過大
            if (trans.Monitor_Data.FaultInfo.VacHigh)
                ErrorDisp(this.LB_PfcHiVolt);
            else
                NormalDisp(this.LB_PfcHiVolt);

            // AC 電壓過小
            if (trans.Monitor_Data.FaultInfo.VacLow)
                ErrorDisp(this.LB_PfcLowVolt);
            else
                NormalDisp(this.LB_PfcLowVolt);

            // AC 電流過大
            if (trans.Monitor_Data.FaultInfo.iacOver)
                ErrorDisp(this.LB_Pfcovercurrent);
            else
                NormalDisp(this.LB_Pfcovercurrent);
        }

        #endregion

        #region 保護限頻資訊 Protect / Limit Freq.

        /// <summary>
        /// 室外保護狀態 1 
        /// </summary>
        public void Protect_Code1()
        {
            // IPM 過熱保護
            if (trans.Monitor_Data.ProtectInfo.ipmTemp)
                ErrorDisp(this.LB_ipmHiTemp);
            else
                NormalDisp(this.LB_ipmHiTemp);

            // 交流輸入電流過大
            if (trans.Monitor_Data.ProtectInfo.iacOverCur)
                ErrorDisp(this.LB_iacOver);
            else
                NormalDisp(this.LB_iacOver);

            // 壓縮機排氣溫度保護
            if (trans.Monitor_Data.ProtectInfo.discharTemp)
                ErrorDisp(this.LB_dishcharTempPro);
            else
                NormalDisp(this.LB_dishcharTempPro);

            // 壓縮機頂部過熱保護
            if (trans.Monitor_Data.ProtectInfo.compTopTemp)
                ErrorDisp(this.LB_comTopTempPro);
            else
                NormalDisp(this.LB_comTopTempPro);

            // 壓縮機吸氣溫度保護
            if (trans.Monitor_Data.ProtectInfo.suctionTemp)
                ErrorDisp(this.LB_suctionTempPro);
            else
                NormalDisp(this.LB_suctionTempPro);
            // 
        }

        /// <summary>
        /// 室外保護狀態 2
        /// </summary>
        public void Protect_Code2()
        {
            // 排氣高壓保護
            if (trans.Monitor_Data.ProtectInfo.disPressure)
                ErrorDisp(this.LB_disPressure);
            else
                NormalDisp(this.LB_disPressure);

            // 室外冷凝管高溫
            if (trans.Monitor_Data.ProtectInfo.outCoilTemp)
                ErrorDisp(this.LB_outCoilHiTemp);
            else
                NormalDisp(this.LB_outCoilHiTemp);

            // 室外環境溫度高溫保護
            if (trans.Monitor_Data.ProtectInfo.outTemp)
                ErrorDisp(this.LB_outroomHiTemp);
            else
                NormalDisp(this.LB_outroomHiTemp);

            // 室內銅管低溫保護
            if (trans.Monitor_Data.ProtectInfo.inCoilFreeze)
                ErrorDisp(this.LB_inCoilLowTemp);
            else
                NormalDisp(this.LB_inCoilLowTemp);

            // 室內銅管高溫保護
            if (trans.Monitor_Data.ProtectInfo.inCoilOverTemp)
                ErrorDisp(this.LB_inCoilHiTemp);
            else
                NormalDisp(this.LB_inCoilHiTemp);

            // 室外系統異常重定
            if (trans.Monitor_Data.ProtectInfo.sysErrReset)
                ErrorDisp(this.LB_outErr);
            else
                NormalDisp(this.LB_outErr);
        }

        /// <summary>
        /// 保護限頻顯示
        /// </summary>
        public void FreqProNum()
        {
            // 室內風速限頻
            if (trans.Monitor_Data.Freqlimit.Infan_Lo_Pro)
                ErrorDisp(this.LB_infanlimit);
            else
                NormalDisp(this.LB_infanlimit);

            // 壓縮機電流超載限頻保護
            if (trans.Monitor_Data.Freqlimit.Ic_Ol_Pro)
                ErrorDisp(this.LB_CompOver);
            else
                NormalDisp(this.LB_CompOver);

            // 母線電壓限頻
            if (trans.Monitor_Data.Freqlimit.Vbus_Pro)
                ErrorDisp(this.LB_VdcLimit);
            else
                NormalDisp(this.LB_VdcLimit);

            // 交流電流限頻保護
            if (trans.Monitor_Data.Freqlimit.Iac_Pro)
                ErrorDisp(this.LB_IacLimit);
            else
                NormalDisp(this.LB_IacLimit);

            // 排氣高溫限頻保護
            if (trans.Monitor_Data.Freqlimit.Discharge_Pro)
                ErrorDisp(this.LB_dischargeHi);
            else
                NormalDisp(this.LB_dischargeHi);

            // 製熱室內盤管防過熱限頻保護
            if (trans.Monitor_Data.Freqlimit.HinCoil_Pro)
                ErrorDisp(this.LB_inCoilHi);
            else
                NormalDisp(this.LB_inCoilHi);

            // 製冷室內盤管防過熱限頻保護
            if (trans.Monitor_Data.Freqlimit.RoutCoil_Pro)
                ErrorDisp(this.LB_outCoilHi);
            else
                NormalDisp(this.LB_outCoilHi);

            // 製冷室內盤管防凍結限頻保護
            if (trans.Monitor_Data.Freqlimit.RinCoil_Pro)
                ErrorDisp(this.LB_inCoilLow);
            else
                NormalDisp(this.LB_inCoilLow);
        }

        #endregion

        #endregion

        #region 運轉狀態資訊 / 電壓 電流

        /// <summary>
        /// 目標轉速
        /// </summary>
        /// <param name="textbox"></param>
        public void TargetFreq(TextBox textbox)
        {
            string str = string.Empty;
            Int32 value = trans.Monitor_Data.MotorRunInfo.SetSpeed_rps;
            Int32 polepair = trans.Monitor_Data.PolePair;
            if (polepair <= 0) polepair = 1;
            str = (value * polepair).ToString() + " Hz / ";
            str += value.ToString() + " rps";
            textbox.Text = str;
        }

        /// <summary>
        /// 實際轉速
        /// </summary>
        /// <param name="textbox"></param>
        public void FactFreq(TextBox textbox)
        {
            string str = string.Empty;
            Int32 value = trans.Monitor_Data.MotorRunInfo.RealSpeed_rps;
            Int32 polepair = trans.Monitor_Data.PolePair;
            if (polepair <= 0) polepair = 1;
            str = (value * polepair).ToString() + " Hz / ";
            str += value.ToString() + " rps";
            textbox.Text = str;
        }

        /// <summary>
        /// VBUS 電壓
        /// </summary>
        /// <param name="textbox"></param>
        public void VBUS(TextBox textbox)
        {
            Int32 value = trans.Monitor_Data.MotorRunInfo.DCVoltage;
            textbox.Text = value.ToString() + " V";
        }

        /// <summary>
        /// AC 電壓
        /// </summary>
        /// <param name="textbox"></param>
        public void VAC(TextBox textbox)
        {
            Int32 value = trans.Monitor_Data.MotorRunInfo.ACVoltage;
            textbox.Text = value.ToString() + " V";
        }

        /// <summary>
        /// AC 電流
        /// </summary>
        /// <param name="textbox"></param>
        public void IAC(TextBox textbox)
        {
            Double value = trans.Monitor_Data.MotorRunInfo.ACCurrent;
            textbox.Text = value.ToString() + " A";
        }

        /// <summary>
        /// 視在功率
        /// </summary>
        /// <param name="textbox"></param>
        public void Power(TextBox textbox)
        {
            Double value = trans.Monitor_Data.MotorRunInfo.Power;
            textbox.Text = value.ToString() + " VA";
        }

        /// <summary>
        /// PFC 狀態
        /// </summary>
        /// <param name="textbox"></param>
        public void PFC_State(TextBox textbox)
        {
            string str = string.Empty;
            switch(trans.Monitor_Data.MotorRunInfo.PFCState)
            {
                case 0x00:
                    str = "OFF";
                    textbox.ForeColor = Color.Red;
                    break;
                case 0x01:
                    str = "ON";
                    textbox.ForeColor = Color.Green;
                    break;
                default:
                    str = "Error";
                    textbox.ForeColor = Color.Red;
                    break;
            }
            textbox.Text = str;
        }

        /// <summary>
        /// 四通閥狀態
        /// </summary>
        /// <param name="textbox"></param>
        public void FourWayValveState(TextBox textbox)
        {
            string str = string.Empty;
            switch(trans.Monitor_Data.MotorRunInfo.FourWayValveState)
            {
                case 0x00:
                    str = "OFF";
                    textbox.ForeColor = Color.Red;
                    break;
                case 0x01:
                    str = "ON";
                    textbox.ForeColor = Color.Green;
                    break;
                default:
                    str = "Error";
                    textbox.ForeColor = Color.Red;
                    break;
            }
            textbox.Text = str;
        }

        /// <summary>
        /// 主繼電器狀態
        /// </summary>
        /// <param name="textbox"></param>
        public void MainRelayState(TextBox textbox)
        {
            string str = string.Empty;
            switch (trans.Monitor_Data.MotorRunInfo.MainRelayState)
            {
                case 0x00:
                    str = "OFF";
                    textbox.ForeColor = Color.Red;
                    break;
                case 0x01:
                    str = "ON";
                    textbox.ForeColor = Color.Green;
                    break;
                default:
                    str = "Error";
                    textbox.ForeColor = Color.Red;
                    break;
            }
            textbox.Text = str;
        }

        /// <summary>
        /// IPM 功率元件溫度
        /// </summary>
        /// <param name="textbox"></param>
        public void IPMTemp(TextBox textbox)
        {
            Int32 value = trans.Monitor_Data.MotorRunInfo.IPMTemp;
            if (value < 60) textbox.ForeColor = Color.Black;
            else if (value < 90) textbox.ForeColor = Color.Orange;
            else textbox.ForeColor = Color.Red;
            textbox.Text = value.ToString() + " ℃";
        }

        /// <summary>
        /// 平均d軸電壓
        /// </summary>
        /// <param name="textbox"></param>
        public void AVG_dVolt(TextBox textbox)
        {
            Double value = trans.Monitor_Data.MotorRunInfo.dVolt;
            textbox.Text = value.ToString();
        }

        /// <summary>
        /// 平均q軸電壓
        /// </summary>
        /// <param name="textbox"></param>
        public void AVG_qVolt(TextBox textbox)
        {
            Double value = trans.Monitor_Data.MotorRunInfo.qVolt;
            textbox.Text = value.ToString();
        }

        /// <summary>
        /// 平均電壓輸出
        /// </summary>
        /// <param name="textbox"></param>
        public void AVG_Vs(TextBox textbox)
        {
            Double value = 0;
            Double value1 = trans.Monitor_Data.MotorRunInfo.dVolt;
            Double value2 = trans.Monitor_Data.MotorRunInfo.qVolt;
            value = Math.Sqrt(Math.Pow(value1, 2) + Math.Pow(value2, 2));
            value = Math.Round(value, 2);
            textbox.Text = value.ToString();
        }

        /// <summary>
        /// 平均d軸電流
        /// </summary>
        /// <param name="textbox"></param>
        public void AVG_dCurrent(TextBox textbox)
        {
            Double value = trans.Monitor_Data.MotorRunInfo.IdCurrent;
            textbox.Text = value.ToString() + " A";
        }

        /// <summary>
        /// 平均q軸電流
        /// </summary>
        /// <param name="textbox"></param>
        /// <returns></returns>
        public void AVG_qCurrent(TextBox textbox)
        {
            Double value = trans.Monitor_Data.MotorRunInfo.IqCurrent;
            textbox.Text = value.ToString() + " A";
        }

        /// <summary>
        /// 平均電流輸出
        /// </summary>
        /// <param name="textbox"></param>
        public void AVG_Is(TextBox textbox)
        {
            Double value = 0;
            Double value1 = trans.Monitor_Data.MotorRunInfo.IdCurrent;
            Double value2 = trans.Monitor_Data.MotorRunInfo.IqCurrent;
            value = Math.Sqrt(Math.Pow(value1, 2) + Math.Pow(value2, 2));
            value = Math.Round(value, 2);
            textbox.Text = value.ToString() + " A";
        }

        #endregion

        /// <summary>
        /// 手動 / 自動 模式
        /// </summary>
        /// <param name="textbox"></param>
        public void SysMode(TextBox textbox)
        {
            string str = string.Empty;
            switch (trans.Monitor_Data.MotorRunInfo.OpMode)
            {
                case 0x00:
                    str = "自動";
                    break;
                case 0x01:
                    str = "手動";
                    break;
                default:
                    str = "Error";
                    break;
            }
            textbox.Text = str;
        }

        /// <summary>
        /// 運行時間
        /// </summary>
        /// <param name="textbox"></param>
        public void SysTime(TextBox textbox)
        {
            string str = string.Empty;
            int secs = trans.Monitor_Data.MotorRunInfo.SysTime;
            TimeSpan t = TimeSpan.FromSeconds(secs);

            str = string.Format("{0:D2}h:{1:D2}m:{2:D2}s",
                            t.Hours,
                            t.Minutes,
                            t.Seconds
                            );
            textbox.Text = str;
        }
    }
}

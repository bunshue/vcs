﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using System.IO;

namespace CS6257_Monitor.UserUI
{
    public partial class ParameterConfigUI : UserControl
    {
        private delegate void Delegate_DispParameter();
        private delegate void Delegate_GetParameter();
        private delegate void Delegate_ResetColor();
        private delegate void Delegate_UpdatePara();
        private delegate void Delegate_Disp_Message(string str, int i);
 
        private Delegate_DispParameter D_DispParameter;
        private Delegate_GetParameter D_GetParameter;
        private Delegate_ResetColor D_ResetColor;
        private Delegate_Disp_Message D_Disp_Message;

        private TransControl trans;
        private PARAMETER_T parameter_T;
        private Thread thread;

        public enum STATE { DEFAULT, CHECK, IDLE, READ, RELOAD, DOWNLOAD, APPLY, EFLASH_READ, EFLASH_WRITE}

        public STATE state;

        private bool Init_flag = false;

        private int delaycnt = 0;

        public ParameterConfigUI()
        {
            InitializeComponent();
        }

        /// <summary>
        /// 初始化設定
        /// </summary>
        /// <param name="trans_ref"></param>
        public void Init_ParameterConfigUI(TransControl trans_ref)
        {
            trans = trans_ref;

            parameter_T = new PARAMETER_T(trans);

            // 初始化委派函式
            D_DispParameter = new Delegate_DispParameter(DispParameter_Method);
            D_GetParameter = new Delegate_GetParameter(GetParameter_Method);
            D_ResetColor = new Delegate_ResetColor(ResetNumericColor_Method);
            D_Disp_Message = new Delegate_Disp_Message(Disp_Message);

            #region Parameter Set

            this.comboBox_FilterSelected.SelectedValueChanged += new System.EventHandler(this.comboBox_SelectedIndexChanged);

            this.num_Rs.Name = "Rs";
            this.num_Rs.ValueChanged += new System.EventHandler(this.numic_ValueChanged);

            this.num_Ld.Name = "Ld";
            this.num_Ld.ValueChanged += new System.EventHandler(this.numic_ValueChanged);

            this.num_Lq.Name = "Lq";
            this.num_Lq.ValueChanged += new System.EventHandler(this.numic_ValueChanged);

            this.num_PolePair.Name = "PolePair";
            this.num_PolePair.ValueChanged += new System.EventHandler(this.numic_ValueChanged);

            this.num_minFreq.Name = "Comp_Min_Freq";
            this.num_minFreq.ValueChanged += new System.EventHandler(this.numic_ValueChanged);

            this.num_maxFreq.Name = "Comp_Max_Freq";
            this.num_maxFreq.ValueChanged += new System.EventHandler(this.numic_ValueChanged);

            this.num_baseFreq.Name = "Comp_Base_Freq";
            this.num_baseFreq.ValueChanged += new System.EventHandler(this.numic_ValueChanged);

            this.num_ISQLimit.Name = "ISQ_Limit";
            this.num_ISQLimit.ValueChanged += new System.EventHandler(this.numic_ValueChanged);

            this.num_incUp.Name = "incUp";
            this.num_incUp.ValueChanged += new System.EventHandler(this.numic_ValueChanged);

            this.num_incDown.Name = "incDown";
            this.num_incDown.ValueChanged += new System.EventHandler(this.numic_ValueChanged);

            this.num_CurStart_ST1.Name = "CUR_START_ST1";
            this.num_CurStart_ST1.ValueChanged += new System.EventHandler(this.numic_ValueChanged);

            this.num_CurStart_ST2.Name = "CUR_START_ST2";
            this.num_CurStart_ST2.ValueChanged += new System.EventHandler(this.numic_ValueChanged);

            this.num_CurStartOffset.Name = "CUR_START_OFFSET";
            this.num_CurStartOffset.ValueChanged += new System.EventHandler(this.numic_ValueChanged);

            this.num_Count_StartUp_ST2_ADD.Name = "Count_StartUp_ST2_ADD";
            this.num_Count_StartUp_ST2_ADD.ValueChanged += new System.EventHandler(this.numic_ValueChanged);

            this.num_Count_StartUp_ST3_ADD.Name = "Count_StartUp_ST3_ADD";
            this.num_Count_StartUp_ST3_ADD.ValueChanged += new System.EventHandler(this.numic_ValueChanged);

            this.num_Count_StartUp_ST4_ADD.Name = "Count_StartUp_ST4_ADD";
            this.num_Count_StartUp_ST4_ADD.ValueChanged += new System.EventHandler(this.numic_ValueChanged);

            this.num_Kslide_StartUp_1.Name = "Kslide_StartUp_1";
            this.num_Kslide_StartUp_1.ValueChanged += new System.EventHandler(this.numic_ValueChanged);

            this.num_Kslide_StartUp_2.Name = "Kslide_StartUp_2";
            this.num_Kslide_StartUp_2.ValueChanged += new System.EventHandler(this.numic_ValueChanged);

            this.num_Kslf_StartUp_1.Name = "Kslf_StartUp_1";
            this.num_Kslf_StartUp_1.ValueChanged += new System.EventHandler(this.numic_ValueChanged);

            this.num_Kslf_StartUp_2.Name = "Kslf_StartUp_2";
            this.num_Kslf_StartUp_2.ValueChanged += new System.EventHandler(this.numic_ValueChanged);

            this.num_E0_StartUp_1.Name = "E0_StartUp_1";
            this.num_E0_StartUp_1.ValueChanged += new System.EventHandler(this.numic_ValueChanged);

            this.num_E0_StartUp_2.Name = "E0_StartUp_2";
            this.num_E0_StartUp_2.ValueChanged += new System.EventHandler(this.numic_ValueChanged);

            this.num_K_OmC_StartUp.Name = "K_OmgC_StartUp";
            this.num_K_OmC_StartUp.ValueChanged += new System.EventHandler(this.numic_ValueChanged);

            this.num_K_THETA0_MAX.Name = "K_THETA0_MAX";
            this.num_K_THETA0_MAX.ValueChanged += new System.EventHandler(this.numic_ValueChanged);

            this.num_I_Start_Max.Name = "I_Start_MAX";
            this.num_I_Start_Max.ValueChanged += new System.EventHandler(this.numic_ValueChanged);

            this.num_V_Sample_K.Name = "V_Sample_K";
            this.num_V_Sample_K.ValueChanged += new System.EventHandler(this.numic_ValueChanged);

            this.num_I_Sample_K.Name = "I_Sample_K";
            this.num_I_Sample_K.ValueChanged += new System.EventHandler(this.numic_ValueChanged);

            this.num_Freq_pwm.Name = "Freq_pwm";
            this.num_Freq_pwm.ValueChanged += new System.EventHandler(this.numic_ValueChanged);
            this.num_Freq_pwm.Enabled = false;      // Read Only

            this.num_DeadTime.Name = "Deadtime";
            this.num_DeadTime.ValueChanged += new System.EventHandler(this.numic_ValueChanged);
            this.num_DeadTime.Enabled = false;      // Read Only

            this.num_PhaseCurLimit.Name = "PhaseCurLimit";
            this.num_PhaseCurLimit.ValueChanged += new System.EventHandler(this.numic_ValueChanged);

            this.num_VbusMax.Name = "VbusMax";
            this.num_VbusMax.ValueChanged += new System.EventHandler(this.numic_ValueChanged);

            this.num_VbusMin.Name = "VbusMin";
            this.num_VbusMin.ValueChanged += new System.EventHandler(this.numic_ValueChanged);

            this.num_VacMax.Name = "VacMax";
            this.num_VacMax.ValueChanged += new System.EventHandler(this.numic_ValueChanged);

            this.num_VacMin.Name = "VacMin";
            this.num_VacMin.ValueChanged += new System.EventHandler(this.numic_ValueChanged);

            this.num_StartCurPID_KP.Name = "StartCurPID_P[0]";
            this.num_StartCurPID_KP.ValueChanged += new System.EventHandler(this.numic_ValueChanged);

            this.num_StartCurPID_KI.Name = "StartCurPID_I[0]";
            this.num_StartCurPID_KI.ValueChanged += new System.EventHandler(this.numic_ValueChanged);

            this.num_StartCurPID_KD.Name = "StartCurPID_D[0]";
            this.num_StartCurPID_KD.ValueChanged += new System.EventHandler(this.numic_ValueChanged);

            this.num_StartSpdPID_P.Name = "StartSpdPID_P";
            this.num_StartSpdPID_P.ValueChanged += new System.EventHandler(this.numic_ValueChanged);

            this.num_StartSpdPID_I.Name = "StartSpdPID_I";
            this.num_StartSpdPID_I.ValueChanged += new System.EventHandler(this.numic_ValueChanged);

            this.num_StartSpdPID_D.Name = "StartSpdPID_D";
            this.num_StartSpdPID_D.ValueChanged += new System.EventHandler(this.numic_ValueChanged);

            this.num_Accrate.Name = "Accrate";
            this.num_Accrate.ValueChanged += new System.EventHandler(this.numic_ValueChanged);

            this.num_SynSpd.Name = "SynSpd";
            this.num_SynSpd.ValueChanged += new System.EventHandler(this.numic_ValueChanged);

            this.num_SynTime.Name = "SynTime";
            this.num_SynTime.ValueChanged += new System.EventHandler(this.numic_ValueChanged);

            // PID 參數
            // CurPID_KP
            this.num_CurPID_KP_0.Name = "CurPID_KP[0]";
            this.num_CurPID_KP_0.ValueChanged += new System.EventHandler(this.numic_ValueChanged);

            this.num_CurPID_KP_1.Name = "CurPID_KP[1]";
            this.num_CurPID_KP_1.ValueChanged += new System.EventHandler(this.numic_ValueChanged);

            this.num_CurPID_KP_2.Name = "CurPID_KP[2]";
            this.num_CurPID_KP_2.ValueChanged += new System.EventHandler(this.numic_ValueChanged);

            this.num_CurPID_KP_3.Name = "CurPID_KP[3]";
            this.num_CurPID_KP_3.ValueChanged += new System.EventHandler(this.numic_ValueChanged);

            this.num_CurPID_KP_4.Name = "CurPID_KP[4]";
            this.num_CurPID_KP_4.ValueChanged += new System.EventHandler(this.numic_ValueChanged);

            this.num_CurPID_KP_5.Name = "CurPID_KP[5]";
            this.num_CurPID_KP_5.ValueChanged += new System.EventHandler(this.numic_ValueChanged);
            // CurPID_KI
            this.num_CurPID_KI_0.Name = "CurPID_KI[0]";
            this.num_CurPID_KI_0.ValueChanged += new System.EventHandler(this.numic_ValueChanged);

            this.num_CurPID_KI_1.Name = "CurPID_KI[1]";
            this.num_CurPID_KI_1.ValueChanged += new System.EventHandler(this.numic_ValueChanged);

            this.num_CurPID_KI_2.Name = "CurPID_KI[2]";
            this.num_CurPID_KI_2.ValueChanged += new System.EventHandler(this.numic_ValueChanged);

            this.num_CurPID_KI_3.Name = "CurPID_KI[3]";
            this.num_CurPID_KI_3.ValueChanged += new System.EventHandler(this.numic_ValueChanged);

            this.num_CurPID_KI_4.Name = "CurPID_KI[4]";
            this.num_CurPID_KI_4.ValueChanged += new System.EventHandler(this.numic_ValueChanged);

            this.num_CurPID_KI_5.Name = "CurPID_KI[5]";
            this.num_CurPID_KI_5.ValueChanged += new System.EventHandler(this.numic_ValueChanged);
            // CurPID_KD
            this.num_CurPID_KD_0.Name = "CurPID_KD[0]";
            this.num_CurPID_KD_0.ValueChanged += new System.EventHandler(this.numic_ValueChanged);

            this.num_CurPID_KD_1.Name = "CurPID_KD[1]";
            this.num_CurPID_KD_1.ValueChanged += new System.EventHandler(this.numic_ValueChanged);

            this.num_CurPID_KD_2.Name = "CurPID_KD[2]";
            this.num_CurPID_KD_2.ValueChanged += new System.EventHandler(this.numic_ValueChanged);

            this.num_CurPID_KD_3.Name = "CurPID_KD[3]";
            this.num_CurPID_KD_3.ValueChanged += new System.EventHandler(this.numic_ValueChanged);

            this.num_CurPID_KD_4.Name = "CurPID_KD[4]";
            this.num_CurPID_KD_4.ValueChanged += new System.EventHandler(this.numic_ValueChanged);

            this.num_CurPID_KD_5.Name = "CurPID_KD[5]";
            this.num_CurPID_KD_5.ValueChanged += new System.EventHandler(this.numic_ValueChanged);

            // SpdPID_KP
            this.num_SpdPID_KP_0.Name = "SpdPID_KP[0]";
            this.num_SpdPID_KP_0.ValueChanged += new System.EventHandler(this.numic_ValueChanged);

            this.num_SpdPID_KP_1.Name = "SpdPID_KP[1]";
            this.num_SpdPID_KP_1.ValueChanged += new System.EventHandler(this.numic_ValueChanged);

            this.num_SpdPID_KP_2.Name = "SpdPID_KP[2]";
            this.num_SpdPID_KP_2.ValueChanged += new System.EventHandler(this.numic_ValueChanged);

            this.num_SpdPID_KP_3.Name = "SpdPID_KP[3]";
            this.num_SpdPID_KP_3.ValueChanged += new System.EventHandler(this.numic_ValueChanged);

            this.num_SpdPID_KP_4.Name = "SpdPID_KP[4]";
            this.num_SpdPID_KP_4.ValueChanged += new System.EventHandler(this.numic_ValueChanged);

            this.num_SpdPID_KP_5.Name = "SpdPID_KP[5]";
            this.num_SpdPID_KP_5.ValueChanged += new System.EventHandler(this.numic_ValueChanged);

            // SpdPID_KI
            this.num_SpdPID_KI_0.Name = "SpdPID_KI[0]";
            this.num_SpdPID_KI_0.ValueChanged += new System.EventHandler(this.numic_ValueChanged);

            this.num_SpdPID_KI_1.Name = "SpdPID_KI[1]";
            this.num_SpdPID_KI_1.ValueChanged += new System.EventHandler(this.numic_ValueChanged);

            this.num_SpdPID_KI_2.Name = "SpdPID_KI[2]";
            this.num_SpdPID_KI_2.ValueChanged += new System.EventHandler(this.numic_ValueChanged);

            this.num_SpdPID_KI_3.Name = "SpdPID_KI[3]";
            this.num_SpdPID_KI_3.ValueChanged += new System.EventHandler(this.numic_ValueChanged);

            this.num_SpdPID_KI_4.Name = "SpdPID_KI[4]";
            this.num_SpdPID_KI_4.ValueChanged += new System.EventHandler(this.numic_ValueChanged);

            this.num_SpdPID_KI_5.Name = "SpdPID_KI[5]";
            this.num_SpdPID_KI_5.ValueChanged += new System.EventHandler(this.numic_ValueChanged);

            // SpdPID_KD
            this.num_SpdPID_KD_0.Name = "SpdPID_KD[0]";
            this.num_SpdPID_KD_0.ValueChanged += new System.EventHandler(this.numic_ValueChanged);

            this.num_SpdPID_KD_1.Name = "SpdPID_KD[1]";
            this.num_SpdPID_KD_1.ValueChanged += new System.EventHandler(this.numic_ValueChanged);

            this.num_SpdPID_KD_2.Name = "SpdPID_KD[2]";
            this.num_SpdPID_KD_2.ValueChanged += new System.EventHandler(this.numic_ValueChanged);

            this.num_SpdPID_KD_3.Name = "SpdPID_KD[3]";
            this.num_SpdPID_KD_3.ValueChanged += new System.EventHandler(this.numic_ValueChanged);

            this.num_SpdPID_KD_4.Name = "SpdPID_KD[4]";
            this.num_SpdPID_KD_4.ValueChanged += new System.EventHandler(this.numic_ValueChanged);

            this.num_SpdPID_KD_5.Name = "SpdPID_KD[5]";
            this.num_SpdPID_KD_5.ValueChanged += new System.EventHandler(this.numic_ValueChanged);
            
            // SPD_Interval_H
            this.num_SPD_Interval0_H.Name = "SPD_Interval0_H";
            this.num_SPD_Interval0_H.ValueChanged += new System.EventHandler(this.numic_ValueChanged);

            this.num_SPD_Interval1_H.Name = "SPD_Interval1_H";
            this.num_SPD_Interval1_H.ValueChanged += new System.EventHandler(this.numic_ValueChanged);

            this.num_SPD_Interval2_H.Name = "SPD_Interval2_H";
            this.num_SPD_Interval2_H.ValueChanged += new System.EventHandler(this.numic_ValueChanged);

            this.num_SPD_Interval3_H.Name = "SPD_Interval3_H";
            this.num_SPD_Interval3_H.ValueChanged += new System.EventHandler(this.numic_ValueChanged);

            this.num_SPD_Interval4_H.Name = "SPD_Interval4_H";
            this.num_SPD_Interval4_H.ValueChanged += new System.EventHandler(this.numic_ValueChanged);

            // SPD_Interval_L
            this.num_SPD_Interval1_L.Name = "SPD_Interval1_L";
            this.num_SPD_Interval1_L.ValueChanged += new System.EventHandler(this.numic_ValueChanged);

            this.num_SPD_Interval2_L.Name = "SPD_Interval2_L";
            this.num_SPD_Interval2_L.ValueChanged += new System.EventHandler(this.numic_ValueChanged);

            this.num_SPD_Interval3_L.Name = "SPD_Interval3_L";
            this.num_SPD_Interval3_L.ValueChanged += new System.EventHandler(this.numic_ValueChanged);

            this.num_SPD_Interval4_L.Name = "SPD_Interval4_L";
            this.num_SPD_Interval4_L.ValueChanged += new System.EventHandler(this.numic_ValueChanged);

            this.num_SPD_Interval5_L.Name = "SPD_Interval5_L";
            this.num_SPD_Interval5_L.ValueChanged += new System.EventHandler(this.numic_ValueChanged);

            // --------------------------------------------------------------------------------

            parameter_T.paraUnitList.Add(new PARAMETER_UNIT(this.num_Rs, "Q24"));
            parameter_T.paraUnitList.Add(new PARAMETER_UNIT(this.num_Ld, "Q24m"));
            parameter_T.paraUnitList.Add(new PARAMETER_UNIT(this.num_Lq, "Q24m"));
            parameter_T.paraUnitList.Add(new PARAMETER_UNIT(this.num_PolePair, "Q0"));

            parameter_T.paraUnitList.Add(new PARAMETER_UNIT(this.num_minFreq, "Q0"));
            parameter_T.paraUnitList.Add(new PARAMETER_UNIT(this.num_maxFreq, "Q0"));
            parameter_T.paraUnitList.Add(new PARAMETER_UNIT(this.num_baseFreq, "Q0"));

            parameter_T.paraUnitList.Add(new PARAMETER_UNIT(this.num_ISQLimit, "Q24Cur"));
            parameter_T.paraUnitList.Add(new PARAMETER_UNIT(this.num_incUp, "incRamp"));
            parameter_T.paraUnitList.Add(new PARAMETER_UNIT(this.num_incDown, "incRamp"));

            parameter_T.paraUnitList.Add(new PARAMETER_UNIT(this.num_CurStart_ST1, "Q24Cur"));
            parameter_T.paraUnitList.Add(new PARAMETER_UNIT(this.num_CurStart_ST2, "Q24Cur"));
            parameter_T.paraUnitList.Add(new PARAMETER_UNIT(this.num_CurStartOffset, "Q24Cur"));

            parameter_T.paraUnitList.Add(new PARAMETER_UNIT(this.num_Count_StartUp_ST2_ADD, "Q0"));
            parameter_T.paraUnitList.Add(new PARAMETER_UNIT(this.num_Count_StartUp_ST3_ADD, "Q0"));
            parameter_T.paraUnitList.Add(new PARAMETER_UNIT(this.num_Count_StartUp_ST4_ADD, "Q0"));

            parameter_T.paraUnitList.Add(new PARAMETER_UNIT(this.num_Kslide_StartUp_1, "Q24"));
            parameter_T.paraUnitList.Add(new PARAMETER_UNIT(this.num_Kslide_StartUp_2, "Q24"));

            parameter_T.paraUnitList.Add(new PARAMETER_UNIT(this.num_Kslf_StartUp_1, "Q24"));
            parameter_T.paraUnitList.Add(new PARAMETER_UNIT(this.num_Kslf_StartUp_2, "Q24"));

            parameter_T.paraUnitList.Add(new PARAMETER_UNIT(this.num_E0_StartUp_1, "Q24"));
            parameter_T.paraUnitList.Add(new PARAMETER_UNIT(this.num_E0_StartUp_2, "Q24"));

            parameter_T.paraUnitList.Add(new PARAMETER_UNIT(this.num_K_OmC_StartUp, "Q24Freq"));
            parameter_T.paraUnitList.Add(new PARAMETER_UNIT(this.num_K_THETA0_MAX, "Q24"));

            parameter_T.paraUnitList.Add(new PARAMETER_UNIT(this.num_I_Start_Max, "Q24Cur"));

            parameter_T.paraUnitList.Add(new PARAMETER_UNIT(this.num_V_Sample_K, "Q0"));
            parameter_T.paraUnitList.Add(new PARAMETER_UNIT(this.num_I_Sample_K, "Q0"));

            parameter_T.paraUnitList.Add(new PARAMETER_UNIT(this.num_Freq_pwm, "Q0"));
            parameter_T.paraUnitList.Add(new PARAMETER_UNIT(this.num_DeadTime, "Q0"));

            parameter_T.paraUnitList.Add(new PARAMETER_UNIT(this.num_PhaseCurLimit, "Q24Cur"));

            parameter_T.paraUnitList.Add(new PARAMETER_UNIT(this.num_VbusMax, "Q0"));
            parameter_T.paraUnitList.Add(new PARAMETER_UNIT(this.num_VbusMin, "Q0"));

            parameter_T.paraUnitList.Add(new PARAMETER_UNIT(this.num_VacMax, "Q0"));
            parameter_T.paraUnitList.Add(new PARAMETER_UNIT(this.num_VacMin, "Q0"));

            parameter_T.paraUnitList.Add(new PARAMETER_UNIT(this.num_StartCurPID_KP, "Q24"));
            parameter_T.paraUnitList.Add(new PARAMETER_UNIT(this.num_StartCurPID_KI, "Q24"));
            parameter_T.paraUnitList.Add(new PARAMETER_UNIT(this.num_StartCurPID_KD, "Q24"));

            parameter_T.paraUnitList.Add(new PARAMETER_UNIT(this.num_StartSpdPID_P, "Q24"));
            parameter_T.paraUnitList.Add(new PARAMETER_UNIT(this.num_StartSpdPID_I, "Q24"));
            parameter_T.paraUnitList.Add(new PARAMETER_UNIT(this.num_StartSpdPID_D, "Q24"));

            parameter_T.paraUnitList.Add(new PARAMETER_UNIT(this.num_Accrate, "incRamp"));
            parameter_T.paraUnitList.Add(new PARAMETER_UNIT(this.num_SynSpd, "incRamp"));
            parameter_T.paraUnitList.Add(new PARAMETER_UNIT(this.num_SynTime, "Q0"));

            parameter_T.paraUnitList.Add(new PARAMETER_UNIT(this.num_CurPID_KP_0, "Q24"));
            parameter_T.paraUnitList.Add(new PARAMETER_UNIT(this.num_CurPID_KP_1, "Q24"));
            parameter_T.paraUnitList.Add(new PARAMETER_UNIT(this.num_CurPID_KP_2, "Q24"));
            parameter_T.paraUnitList.Add(new PARAMETER_UNIT(this.num_CurPID_KP_3, "Q24"));
            parameter_T.paraUnitList.Add(new PARAMETER_UNIT(this.num_CurPID_KP_4, "Q24"));
            parameter_T.paraUnitList.Add(new PARAMETER_UNIT(this.num_CurPID_KP_5, "Q24"));

            parameter_T.paraUnitList.Add(new PARAMETER_UNIT(this.num_CurPID_KI_0, "Q24"));
            parameter_T.paraUnitList.Add(new PARAMETER_UNIT(this.num_CurPID_KI_1, "Q24"));
            parameter_T.paraUnitList.Add(new PARAMETER_UNIT(this.num_CurPID_KI_2, "Q24"));
            parameter_T.paraUnitList.Add(new PARAMETER_UNIT(this.num_CurPID_KI_3, "Q24"));
            parameter_T.paraUnitList.Add(new PARAMETER_UNIT(this.num_CurPID_KI_4, "Q24"));
            parameter_T.paraUnitList.Add(new PARAMETER_UNIT(this.num_CurPID_KI_5, "Q24"));

            parameter_T.paraUnitList.Add(new PARAMETER_UNIT(this.num_CurPID_KD_0, "Q24"));
            parameter_T.paraUnitList.Add(new PARAMETER_UNIT(this.num_CurPID_KD_1, "Q24"));
            parameter_T.paraUnitList.Add(new PARAMETER_UNIT(this.num_CurPID_KD_2, "Q24"));
            parameter_T.paraUnitList.Add(new PARAMETER_UNIT(this.num_CurPID_KD_3, "Q24"));
            parameter_T.paraUnitList.Add(new PARAMETER_UNIT(this.num_CurPID_KD_4, "Q24"));
            parameter_T.paraUnitList.Add(new PARAMETER_UNIT(this.num_CurPID_KD_5, "Q24"));

            parameter_T.paraUnitList.Add(new PARAMETER_UNIT(this.num_SpdPID_KP_0, "Q24"));
            parameter_T.paraUnitList.Add(new PARAMETER_UNIT(this.num_SpdPID_KP_1, "Q24"));
            parameter_T.paraUnitList.Add(new PARAMETER_UNIT(this.num_SpdPID_KP_2, "Q24"));
            parameter_T.paraUnitList.Add(new PARAMETER_UNIT(this.num_SpdPID_KP_3, "Q24"));
            parameter_T.paraUnitList.Add(new PARAMETER_UNIT(this.num_SpdPID_KP_4, "Q24"));
            parameter_T.paraUnitList.Add(new PARAMETER_UNIT(this.num_SpdPID_KP_5, "Q24"));

            parameter_T.paraUnitList.Add(new PARAMETER_UNIT(this.num_SpdPID_KI_0, "Q24"));
            parameter_T.paraUnitList.Add(new PARAMETER_UNIT(this.num_SpdPID_KI_1, "Q24"));
            parameter_T.paraUnitList.Add(new PARAMETER_UNIT(this.num_SpdPID_KI_2, "Q24"));
            parameter_T.paraUnitList.Add(new PARAMETER_UNIT(this.num_SpdPID_KI_3, "Q24"));
            parameter_T.paraUnitList.Add(new PARAMETER_UNIT(this.num_SpdPID_KI_4, "Q24"));
            parameter_T.paraUnitList.Add(new PARAMETER_UNIT(this.num_SpdPID_KI_5, "Q24"));

            parameter_T.paraUnitList.Add(new PARAMETER_UNIT(this.num_SpdPID_KD_0, "Q24"));
            parameter_T.paraUnitList.Add(new PARAMETER_UNIT(this.num_SpdPID_KD_1, "Q24"));
            parameter_T.paraUnitList.Add(new PARAMETER_UNIT(this.num_SpdPID_KD_2, "Q24"));
            parameter_T.paraUnitList.Add(new PARAMETER_UNIT(this.num_SpdPID_KD_3, "Q24"));
            parameter_T.paraUnitList.Add(new PARAMETER_UNIT(this.num_SpdPID_KD_4, "Q24"));
            parameter_T.paraUnitList.Add(new PARAMETER_UNIT(this.num_SpdPID_KD_5, "Q24"));

            parameter_T.paraUnitList.Add(new PARAMETER_UNIT(this.num_SPD_Interval0_H, "Q24rps"));
            parameter_T.paraUnitList.Add(new PARAMETER_UNIT(this.num_SPD_Interval1_H, "Q24rps"));
            parameter_T.paraUnitList.Add(new PARAMETER_UNIT(this.num_SPD_Interval2_H, "Q24rps"));
            parameter_T.paraUnitList.Add(new PARAMETER_UNIT(this.num_SPD_Interval3_H, "Q24rps"));
            parameter_T.paraUnitList.Add(new PARAMETER_UNIT(this.num_SPD_Interval4_H, "Q24rps"));

            parameter_T.paraUnitList.Add(new PARAMETER_UNIT(this.num_SPD_Interval1_L, "Q24rps"));
            parameter_T.paraUnitList.Add(new PARAMETER_UNIT(this.num_SPD_Interval2_L, "Q24rps"));
            parameter_T.paraUnitList.Add(new PARAMETER_UNIT(this.num_SPD_Interval3_L, "Q24rps"));
            parameter_T.paraUnitList.Add(new PARAMETER_UNIT(this.num_SPD_Interval4_L, "Q24rps"));
            parameter_T.paraUnitList.Add(new PARAMETER_UNIT(this.num_SPD_Interval5_L, "Q24rps"));

            #endregion

            #region ComboBox Init
            // 初始 ComboBox_StartUp_Mode 選擇 Normal
            this.comboBox_StartUp_Mode.SelectedIndex = 0;
            //
            this.comboBox_FilterSelected.SelectedIndex = 0;
            #endregion

            thread = new Thread(new ThreadStart(DoWork));
            thread.Name = "ParameterConfigUI Thread";
            thread.IsBackground = true;
            thread.Start();
        }

        /// <summary>
        /// 
        /// </summary>
        private void DoWork()
        {
            while(true)
            {
                switch(state)
                {
                    case STATE.DEFAULT:
                        state = STATE.IDLE;
                        break;
                    case STATE.CHECK:
                        if (trans.pcState.ParamState == TransControl.PARAM_STATE.SYN)
                        {
                            state = STATE.RELOAD;
                        }
                        else if (trans.pcState.ParamState == TransControl.PARAM_STATE.ASY)
                        {
                            //this.Invoke(D_Disp_Message, "參數接收失敗 !!", 2);
                            this.Invoke(D_Disp_Message, "Parameter Read Fail !!", 2);
                            state = STATE.IDLE;
                        }                        
                        break;
                    case STATE.READ:
                        trans.SetParamTransControl(TransControl.TRANS.READ, TransControl.DATA_TYPE.MOTOR);
                        //this.Invoke(D_Disp_Message, "從MCU取得參數 [DOWNLOAD]", 0);
                        //this.Invoke(D_Disp_Message, "參數接收中...", 0);
                        this.Invoke(D_Disp_Message, "Getting Parameter from MCU [READ]", 0);
                        this.Invoke(D_Disp_Message, "READING...", 0);
                        state = STATE.CHECK;
                        break;
                    case STATE.RELOAD:
                        Thread.Sleep(250);
                        this.Invoke(D_DispParameter);
                        // 重新設定所有 numericUpDown 背景顏色
                        this.Invoke(D_ResetColor);
                        //this.Invoke(D_Disp_Message, "參數接收成功 !!", 1);
                        this.Invoke(D_Disp_Message, "Parameter Read Successfully !!", 1);
                        state = STATE.IDLE;
                        break;
                    case STATE.DOWNLOAD:
                        //
                        // 將顯示參數更新並傳送至MCU
                        UpdatePara_Method();
                        trans.SetParamTransControl(TransControl.TRANS.DOWNLOAD, TransControl.DATA_TYPE.MOTOR);
                        //this.Invoke(D_Disp_Message, "傳送參數至MCU [UPLOAD]", 0);
                        //this.Invoke(D_Disp_Message, "參數傳送中...", 0);
                        this.Invoke(D_Disp_Message, "Downloading Parameter to MCU [DOWNLOAD]", 0);
                        this.Invoke(D_Disp_Message, "DOWNLOADING...", 0);
                        state = STATE.APPLY;
                        break;
                    case STATE.APPLY:
                        if (trans.pcState.ParamState == TransControl.PARAM_STATE.SYN)
                        {
                            // 更新馬達運轉參數
                            trans.UpdataMotorRun_Param();
                            Thread.Sleep(100);
                            if(trans.pcState.RunParamState == TransControl.RUNPARAM_STATE.ACK)
                            {
                                // 重新設定所有 numericUpDown 背景顏色
                                this.Invoke(D_ResetColor);
                                //this.Invoke(D_Disp_Message, "參數傳送更新成功 !!", 1);
                                this.Invoke(D_Disp_Message, "Parameter Download Successfully !!", 1);
                                state = STATE.IDLE;
                            }
                            else if (trans.pcState.RunParamState == TransControl.RUNPARAM_STATE.NACK)
                            {
                                //this.Invoke(D_Disp_Message, "參數傳送更新失敗 !!", 2);
                                this.Invoke(D_Disp_Message, "Parameter Download Fail !!", 2);
                                state = STATE.IDLE;
                            }

                        }
                        else if (trans.pcState.ParamState == TransControl.PARAM_STATE.ASY)
                        {
                            //this.Invoke(D_Disp_Message, "參數傳送失敗 !!", 2);
                            this.Invoke(D_Disp_Message, "Parameter Download Fail !!", 2);
                            state = STATE.IDLE;
                        }
                        //
                        break;
                    case STATE.EFLASH_READ:
                        if (trans.pcState.EfalshState == TransControl.EFLASH_STATE.ACK)
                        {
                            //this.Invoke(D_Disp_Message, "Eflash 讀取成功 !!", 1);
                            this.Invoke(D_Disp_Message, "Read Eflash Successfully !!", 1);
                            state = STATE.IDLE;
                        }
                        else if (++delaycnt > 500)  // 5s
                        {
                            //this.Invoke(D_Disp_Message, "Eflash 讀取失敗 !!", 2);
                            this.Invoke(D_Disp_Message, "Read Eflash Fail!!", 2);
                            delaycnt = 0;
                            state = STATE.IDLE;
                        }
                        break;
                    case STATE.EFLASH_WRITE:
                        if (trans.pcState.EfalshState == TransControl.EFLASH_STATE.ACK)
                        {
                            //this.Invoke(D_Disp_Message, "Eflash 寫入成功 !!", 1);
                            this.Invoke(D_Disp_Message, "Write Eflash Successfully !!", 1);
                            state = STATE.IDLE;
                        }
                        else if (++delaycnt > 500)  // 5s
                        {
                            //this.Invoke(D_Disp_Message, "Eflash 寫入失敗 !!", 2);
                            this.Invoke(D_Disp_Message, "Write Eflash Fail !!", 2);
                            delaycnt = 0;
                            state = STATE.IDLE;
                        }
                        break;
                    case STATE.IDLE:
                        // 
                        break;
                }
                Thread.Sleep(10);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="msg"></param>
        /// <param name="i"></param>
        private void Disp_Message(string msg, int i)
        {
            //
            string time_str = DateTime.Now.ToString();
            this.richTextBox_Message.SelectionColor = Color.Black;
            this.richTextBox_Message.AppendText(time_str + "\t");
            switch(i)
            {
                case 0:
                    break;
                case 1:
                    this.richTextBox_Message.SelectionColor = Color.Green;
                    this.richTextBox_Message.AppendText("[OK] ");
                    this.richTextBox_Message.SelectionColor = Color.Black;
                    break;
                case 2:
                    this.richTextBox_Message.SelectionColor = Color.Red;
                    this.richTextBox_Message.AppendText("[Fail] ");
                    this.richTextBox_Message.SelectionColor = Color.Black;
                    break;
            }
            this.richTextBox_Message.AppendText(msg + "\n");
            this.richTextBox_Message.ScrollToCaret();
            //
        }

        /// <summary>
        /// 顯示數值
        /// </summary>
        private void DispParameter_Method()
        {
            int value = 0;
            Init_flag = false;
            parameter_T.DispInNumeric();
            //
            value = trans.Get_ParamDBValue("StartUpMode");
            try
            {
                this.comboBox_StartUp_Mode.SelectedIndex = value;
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            
            value = trans.Get_ParamDBValue("FilterSelected");
            try
            {
                this.comboBox_FilterSelected.SelectedIndex = value;
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }

            value = trans.Get_ParamDBValue("PidParaCalc_Enable");

            if (value == 1) 
                PidCalc_Enable_checkBox1.Checked = true;
            else
            {
                PidCalc_Enable_checkBox1.Checked = false;
            }

            Init_flag = true;
        }

        /// <summary>
        /// 取得數值方法
        /// </summary>
        private void GetParameter_Method()
        {
            int value = 0;
            bool check_value = false;

            value = comboBox_StartUp_Mode.SelectedIndex;
            trans.Set_ParamDBValue("StartUpMode", value);

            value = comboBox_FilterSelected.SelectedIndex;
            trans.Set_ParamDBValue("FilterSelected", value);

            check_value = PidCalc_Enable_checkBox1.Checked;
            if (check_value)
            {
                trans.Set_ParamDBValue("PidParaCalc_Enable", 1);
            }
            else
            {
                trans.Set_ParamDBValue("PidParaCalc_Enable", 0);
            }
        }

        /// <summary>
        /// 重設背景顏色
        /// </summary>
        private void ResetNumericColor_Method()
        {
            parameter_T.ResetALLnumicColor();
        }

        /// <summary>
        /// 更新ParamDB數值
        /// </summary>
        private void UpdatePara_Method()
        {
            // Clear ParamDB Value
            trans.Clear_ParamDBValue();
            // Update Parameter to ParamDB
            parameter_T.UpdateTableValue();
            // Get ComboBox and Checkbox Value
            this.Invoke(D_GetParameter);
        }


        /// <summary>
        /// 數值更新後觸發此函式
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void numic_ValueChanged(object sender, EventArgs e)
        {
            if (Init_flag == true)
            {
                foreach (PARAMETER_UNIT unit in parameter_T.paraUnitList)
                {
                    // 從 numericupdonw 取得Q24數值
                    int value = unit.GetValueFromNumeric();
                    unit.q24Data = value;
                }
                parameter_T.CompareLastValue();
            }
        }

        /// <summary>
        /// ComboBox 更新後觸發此函式
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void comboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            //
        }

        /// <summary>
        /// CheckBox 更新後觸發此函式
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void PidCalc_Enable_checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            //
        }

        #region Button

        /// <summary>
        /// 重新讀取參數
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Reload_button_Click(object sender, EventArgs e)
        {
            if (state == STATE.IDLE)
                state = STATE.READ;
        }

        /// <summary>
        /// 更新按鈕
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Update_button_Click(object sender, EventArgs e)
        {
            if (state == STATE.IDLE)
                state = STATE.DOWNLOAD;
        }

        /// <summary>
        /// 寫入至Eflash
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Write_efd_button_Click(object sender, EventArgs e)
        {
            if (state == STATE.IDLE)
            {
                trans.EflashReadWriteControl(TransControl.EFLASH_CMD.WRITE);
                //Disp_Message("Efalsh 寫入中...", 0);
                Disp_Message("Writing to Eflash...", 0);
                state = STATE.EFLASH_WRITE;
            }
        }

        /// <summary>
        /// 從 Eflash 讀取
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Read_efd_button_Click(object sender, EventArgs e)
        {
            if (state == STATE.IDLE)
            {
                trans.EflashReadWriteControl(TransControl.EFLASH_CMD.READ);
                //Disp_Message("Efalsh 讀取中...", 0);
                Disp_Message("Reading from Eflash...", 0);
                state = STATE.EFLASH_READ;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void OpenFile_button_Click(object sender, EventArgs e)
        {
            OpenFile();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void SaveFile_button_Click(object sender, EventArgs e)
        {
            SaveFile();
        }

        #endregion

        #region File Read/Write

        /// <summary>
        /// 
        /// </summary>
        private void OpenFile()
        {
            string filepath = string.Empty;
            string[] rowdat = new string[3];
            string[] paraname = new string[512];
            int[] value = new int[512];
            string context = string.Empty;
            int t1 = 0;
            int t2 = 0;

            OpenFileDialog P_OpenFileDialog = new OpenFileDialog();
            if (P_OpenFileDialog.ShowDialog() == DialogResult.OK)
            {
                filepath = P_OpenFileDialog.FileName;
                FileStream filestream = File.Open(filepath, FileMode.Open);
                StreamReader str_reader = new StreamReader(filestream);
                try
                {
                    // Read File text
                    for (int ii = 0; ii < 512; ii++)
                    {
                        context = str_reader.ReadLine();
                        t1 = t2 = 0;
                        for (int jj = 0; jj < 3; jj++)
                        {
                            t2 = context.IndexOf("\t", t1);
                            rowdat[jj] = context.Substring(t1, t2 - t1);
                            t1 = t2 + 1;
                        }
                        paraname[ii] = rowdat[1];
                        value[ii] = Int32.Parse(rowdat[2]);
                    }

                    // TODO : 將參數顯示至所有numeric             

                    for (int ii = 0; ii < 512; ii++)
                    {
                        foreach(PARAMETER_UNIT unit in parameter_T.paraUnitList)
                        {
                            if (unit.ParaName.CompareTo(paraname[ii]) == 0)
                            {
                                unit.q24Data = value[ii];
                                // 顯示數值
                                unit.DispValue();
                                // 紀錄數值
                                unit.LogValue();
                            }
                        }
                        //
                        if (paraname[ii] == "StartUpMode")
                        {
                            this.comboBox_StartUp_Mode.SelectedIndex = value[ii];
                        }
                        else if (paraname[ii] == "FilterSelected")
                        {
                            this.comboBox_FilterSelected.SelectedIndex = value[ii];
                        }
                        else if (paraname[ii] == "PidParaCalc_Enable")
                        {
                            if (value[ii] == 1)
                            {
                                PidCalc_Enable_checkBox1.Checked = true;
                            }
                            else
                            {
                                PidCalc_Enable_checkBox1.Checked = false;
                            }
                        }

                    }
                    //this.Disp_Message("開啟檔案 : " + filepath, 0);
                    //this.Disp_Message("讀取檔案成功 !!", 1);
                    this.Disp_Message("Open File : " + filepath, 0);
                    this.Disp_Message("Read File Successfully !!", 1);
                }
                catch(Exception ex)
                {
                    Console.WriteLine(ex.ToString());
                    //this.Disp_Message("開啟檔案 : " + filepath, 0);
                    //this.Disp_Message("讀取檔案失敗 !!", 2);
                    this.Disp_Message("Open File : " + filepath, 0);
                    this.Disp_Message("Read File Fail !!", 2);
                }

                // Dispose StreamReader
                str_reader.Dispose();
                // Close FileStream
                filestream.Close();


            }
        }


        private void SaveFile()
        {
            string filepath = string.Empty;
            string[] rowdat = new string[6];
            string context = string.Empty;
            SaveFileDialog P_SaveFileDialog = new SaveFileDialog();
            if (P_SaveFileDialog.ShowDialog() == DialogResult.OK)
            {
                filepath = P_SaveFileDialog.FileName;
                FileStream filestream = File.Open(filepath, FileMode.Create);
                StreamWriter str_writer = new StreamWriter(filestream);
                for(int ii = 0; ii < 512; ii++)
                {
                    int num = trans.parmDB[ii].Number;
                    string paraname = trans.parmDB[ii].Name;
                    int value = 0;
                    foreach(PARAMETER_UNIT unit in parameter_T.paraUnitList)
                    {
                        if (unit.ParaName.CompareTo(paraname) == 0)
                        {
                            value = unit.q24Data;
                        }
                    }
                    if (paraname.CompareTo("StartUpMode") == 0)
                    {
                        value = this.comboBox_StartUp_Mode.SelectedIndex;
                    }
                    else if (paraname.CompareTo("FilterSelected") == 0)
                    {
                        value = this.comboBox_FilterSelected.SelectedIndex;
                    }
                    else if (paraname.CompareTo("PidParaCalc_Enable") == 0)
                    {
                        if (PidCalc_Enable_checkBox1.Checked)
                        {
                            value = 1;
                        }
                        else
                        {
                            value = 0;
                        }
                    }
                    //          No.                     Name                Value                Q0 Value
                    context = num.ToString() + "\t" + paraname + "\t" + value.ToString() + "\t" + "0";// +"\t" + rowdat[5];
                    str_writer.WriteLine(context);
                    Console.WriteLine("{0}", context);
                }
              
                // Dispose StreamWriter
                str_writer.Dispose();
                // Close FileStream
                filestream.Close();

                //this.Disp_Message("已儲存檔案至 " + filepath, 1);
                this.Disp_Message("Save To " + filepath, 1);
            }
        }
        #endregion
    }

    public class PARAMETER_T
    {
        /// <summary>
        /// 
        /// </summary>
        private TransControl trans;
        public List<PARAMETER_UNIT> paraUnitList = new List<PARAMETER_UNIT>();

        /// <summary>
        /// 
        /// </summary>
        /// <param name="cs6257paraUI_ref"></param>
        public PARAMETER_T(TransControl trans_ref)
        {
            trans = trans_ref;
        }

        /// <summary>
        /// 顯示數值於Numeric
        /// </summary>
        public void DispInNumeric()
        {
            foreach(PARAMETER_UNIT unit in paraUnitList)
            {
                // 從 ListView Table 取得數值
                //unit.q24Data = cs6257ParaUI.GetListViewParam(unit.ParaName);
                unit.q24Data = trans.Get_ParamDBValue(unit.ParaName);
                // 顯示數值
                unit.DispValue();
                // 紀錄數值
                unit.LogValue();
            }
        }

        /// <summary>
        /// 將顯示參數更新至ParamDB
        /// </summary>
        public void UpdateTableValue()
        {
            foreach(PARAMETER_UNIT unit in paraUnitList)
            {
                // 從 numericupdonw 取得Q24數值
                int value = unit.GetValueFromNumeric();
                unit.q24Data = value;
                //cs6257ParaUI.SetListViewParam(unit.ParaName, value);
                trans.Set_ParamDBValue(unit.ParaName, value);
                if (unit.ParaName == "Count_StartUp_ST4_ADD")
                {
                    int temp = (int)((double)16777216.0/ (double)(unit.q24Data * 6.0));
                    trans.Set_ParamDBValue("Count_StartUp_ST4_ADD_INV", temp);
                    Console.WriteLine("Count_StartUp_ST4_ADD = {0}", value);
                    Console.WriteLine("Count_StartUp_ST4_ADD_INV = {0}", temp);
                }
            }
        }

        /// <summary>
        /// 和上一次的值做比較
        /// </summary>
        public void CompareLastValue()
        {
            foreach(PARAMETER_UNIT unit in paraUnitList)
            {
                unit.CompareLog();
            }
        }

        /// <summary>
        /// 重設背景顏色
        /// </summary>
        public void ResetALLnumicColor()
        {
            foreach(PARAMETER_UNIT unit in paraUnitList)
            {
                // 紀錄數值
                unit.LogValue();
                // 重設背景顏色
                unit.numeric.BackColor = Color.White;
            }
        }
    }

    public class PARAMETER_UNIT
    {
        public NumericUpDown numeric;
        public string ParaName;
        public string format;
        public int q24Data = 0;
        public int q24DataLog = 0;

        public PARAMETER_UNIT(NumericUpDown numeric_ref, string format_ref)
        {
            numeric = numeric_ref;
            format = format_ref;
            ParaName = numeric.Name;
        }

        /// <summary>
        /// 
        /// </summary>
        public void DispValue()
        {
            // 取得轉換後數值並顯示於numeric
            try
            {
                numeric.Value = GetValue();
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public decimal GetValue()
        {
            double value = 0;
            switch(format)
            {
                case "Q24":
                    value = (double)q24Data / 16777216.0;
                    break;
                case "Q24m":
                    value = (double)q24Data / 16777216.0 * 1000;
                    break;
                case "Q24Cur":
                    value = (double)q24Data / 16777216.0 * 20.0;
                    break;
                case "Q24Volt":
                    value = (double)q24Data / 16777216.0 * 310.0;
                    break;
                case "Q24Freq":
                    value = (double)q24Data * 400.0 / 16777216.0;
                    break;
                case "Q0":
                    value = (double)q24Data;
                    break;
                case "incRamp":
                    value = (double)q24Data * 0.1;
                    break;
                case "Q24rps":
                    value = (double)q24Data / 16777216.0 * 400; // TODO : div PolePair
                    break;
                default:
                    break;
            }

            return (decimal)value;
        }

        /// <summary>
        /// 
        /// </summary>
        public int GetValueFromNumeric()
        {
            double value = (double)numeric.Value;
            switch(format)
            {
                case "Q24":
                    value =  Math.Round(value * 16777216.0);
                    break;
                case "Q24m":
                    value = Math.Round(value / 1000.0 * 16777216.0);
                    break;
                case "Q24Cur":
                    value = Math.Round(value * 16777216.0 / 20.0);
                    break;
                case "Q24Volt":
                    value = Math.Round(value * 16777216.0 / 310.0);
                    break;
                case "Q24Freq":
                    value = Math.Round(value * 16777216.0 / 400.0);
                    break;
                case "Q0":
                    value = Math.Round(value);
                    break;
                case "incRamp":
                    value = Math.Round(value * 10.0);
                    break;
                case "Q24rps":
                    value = Math.Round(value * 16777216.0 / 400.0);
                    break;
            }
            return (int)value;
        }

        /// <summary>
        /// 紀錄數值
        /// </summary>
        public void LogValue()
        {
            q24DataLog = q24Data;
        }

        /// <summary>
        /// 
        /// </summary>
        public void CompareLog()
        {
            if (q24Data != q24DataLog)
            {
                numeric.BackColor = Color.Pink;
            }
            else
            {
                numeric.BackColor = Color.White;
            }
        }
    }
}

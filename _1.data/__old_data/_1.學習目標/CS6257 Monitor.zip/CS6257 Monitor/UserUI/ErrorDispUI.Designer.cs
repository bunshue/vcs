﻿namespace CS6257_Monitor
{
    partial class ErrorDispUI
    {
        /// <summary> 
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 元件設計工具產生的程式碼

        /// <summary> 
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器
        /// 修改這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.TB_IPMTemp = new System.Windows.Forms.TextBox();
            this.TB_IPMFault = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.TB_StartUpErr = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.TB_PhaseLose = new System.Windows.Forms.TextBox();
            this.TB_LoseSpeed = new System.Windows.Forms.TextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.TB_DCHighVoltage = new System.Windows.Forms.TextBox();
            this.TB_ACHighVoltage = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.TB_DCLowVoltage = new System.Windows.Forms.TextBox();
            this.TB_ACLowVoltage = new System.Windows.Forms.TextBox();
            this.TB_ACOverCurrent = new System.Windows.Forms.TextBox();
            this.TB_VacLimit = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.TB_OverLoad = new System.Windows.Forms.TextBox();
            this.LB_VdcLimit = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.TB_FaultState = new System.Windows.Forms.TextBox();
            this.TB_Protect_lim = new System.Windows.Forms.TextBox();
            this.TB_Protect_err = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox4.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox4
            // 
            this.groupBox4.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.groupBox4.Controls.Add(this.panel4);
            this.groupBox4.Controls.Add(this.panel3);
            this.groupBox4.Controls.Add(this.panel2);
            this.groupBox4.Location = new System.Drawing.Point(3, 0);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(424, 232);
            this.groupBox4.TabIndex = 8;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "錯誤警示";
            // 
            // panel4
            // 
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel4.Controls.Add(this.TB_IPMTemp);
            this.panel4.Controls.Add(this.TB_IPMFault);
            this.panel4.Controls.Add(this.label13);
            this.panel4.Location = new System.Drawing.Point(6, 108);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(410, 57);
            this.panel4.TabIndex = 1;
            // 
            // TB_IPMTemp
            // 
            this.TB_IPMTemp.BackColor = System.Drawing.Color.Silver;
            this.TB_IPMTemp.Cursor = System.Windows.Forms.Cursors.Default;
            this.TB_IPMTemp.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.TB_IPMTemp.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.TB_IPMTemp.Location = new System.Drawing.Point(141, 24);
            this.TB_IPMTemp.Name = "TB_IPMTemp";
            this.TB_IPMTemp.ReadOnly = true;
            this.TB_IPMTemp.Size = new System.Drawing.Size(123, 25);
            this.TB_IPMTemp.TabIndex = 0;
            this.TB_IPMTemp.Text = "IPM溫度過高";
            this.TB_IPMTemp.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // TB_IPMFault
            // 
            this.TB_IPMFault.BackColor = System.Drawing.Color.Crimson;
            this.TB_IPMFault.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.TB_IPMFault.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.TB_IPMFault.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.TB_IPMFault.Location = new System.Drawing.Point(12, 24);
            this.TB_IPMFault.Name = "TB_IPMFault";
            this.TB_IPMFault.ReadOnly = true;
            this.TB_IPMFault.Size = new System.Drawing.Size(123, 25);
            this.TB_IPMFault.TabIndex = 0;
            this.TB_IPMFault.Text = "IPM模組故障";
            this.TB_IPMFault.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("新細明體", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label13.Location = new System.Drawing.Point(9, 5);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(116, 13);
            this.label13.TabIndex = 1;
            this.label13.Text = "IPM功率模組狀態";
            // 
            // panel3
            // 
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.TB_StartUpErr);
            this.panel3.Controls.Add(this.label14);
            this.panel3.Controls.Add(this.TB_PhaseLose);
            this.panel3.Controls.Add(this.TB_LoseSpeed);
            this.panel3.Location = new System.Drawing.Point(6, 170);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(410, 62);
            this.panel3.TabIndex = 1;
            // 
            // TB_StartUpErr
            // 
            this.TB_StartUpErr.BackColor = System.Drawing.Color.Silver;
            this.TB_StartUpErr.Cursor = System.Windows.Forms.Cursors.Default;
            this.TB_StartUpErr.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.TB_StartUpErr.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.TB_StartUpErr.Location = new System.Drawing.Point(12, 24);
            this.TB_StartUpErr.Name = "TB_StartUpErr";
            this.TB_StartUpErr.ReadOnly = true;
            this.TB_StartUpErr.Size = new System.Drawing.Size(123, 25);
            this.TB_StartUpErr.TabIndex = 0;
            this.TB_StartUpErr.Text = "啟動故障";
            this.TB_StartUpErr.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("新細明體", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label14.Location = new System.Drawing.Point(9, 5);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(63, 13);
            this.label14.TabIndex = 1;
            this.label14.Text = "電機狀態";
            // 
            // TB_PhaseLose
            // 
            this.TB_PhaseLose.BackColor = System.Drawing.Color.Silver;
            this.TB_PhaseLose.Cursor = System.Windows.Forms.Cursors.Default;
            this.TB_PhaseLose.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.TB_PhaseLose.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.TB_PhaseLose.Location = new System.Drawing.Point(141, 24);
            this.TB_PhaseLose.Name = "TB_PhaseLose";
            this.TB_PhaseLose.ReadOnly = true;
            this.TB_PhaseLose.Size = new System.Drawing.Size(123, 25);
            this.TB_PhaseLose.TabIndex = 0;
            this.TB_PhaseLose.Text = "缺相保護";
            this.TB_PhaseLose.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // TB_LoseSpeed
            // 
            this.TB_LoseSpeed.BackColor = System.Drawing.Color.Silver;
            this.TB_LoseSpeed.Cursor = System.Windows.Forms.Cursors.Default;
            this.TB_LoseSpeed.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.TB_LoseSpeed.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.TB_LoseSpeed.Location = new System.Drawing.Point(270, 24);
            this.TB_LoseSpeed.Name = "TB_LoseSpeed";
            this.TB_LoseSpeed.ReadOnly = true;
            this.TB_LoseSpeed.Size = new System.Drawing.Size(123, 25);
            this.TB_LoseSpeed.TabIndex = 0;
            this.TB_LoseSpeed.Text = "失速保護";
            this.TB_LoseSpeed.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.TB_DCHighVoltage);
            this.panel2.Controls.Add(this.TB_ACHighVoltage);
            this.panel2.Controls.Add(this.label15);
            this.panel2.Controls.Add(this.TB_DCLowVoltage);
            this.panel2.Controls.Add(this.TB_ACLowVoltage);
            this.panel2.Controls.Add(this.TB_ACOverCurrent);
            this.panel2.Location = new System.Drawing.Point(6, 15);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(410, 87);
            this.panel2.TabIndex = 1;
            // 
            // TB_DCHighVoltage
            // 
            this.TB_DCHighVoltage.BackColor = System.Drawing.Color.Crimson;
            this.TB_DCHighVoltage.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.TB_DCHighVoltage.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.TB_DCHighVoltage.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.TB_DCHighVoltage.Location = new System.Drawing.Point(12, 24);
            this.TB_DCHighVoltage.Name = "TB_DCHighVoltage";
            this.TB_DCHighVoltage.ReadOnly = true;
            this.TB_DCHighVoltage.Size = new System.Drawing.Size(123, 25);
            this.TB_DCHighVoltage.TabIndex = 0;
            this.TB_DCHighVoltage.Text = " DC電壓過高";
            this.TB_DCHighVoltage.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // TB_ACHighVoltage
            // 
            this.TB_ACHighVoltage.BackColor = System.Drawing.Color.Silver;
            this.TB_ACHighVoltage.Cursor = System.Windows.Forms.Cursors.Default;
            this.TB_ACHighVoltage.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.TB_ACHighVoltage.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.TB_ACHighVoltage.Location = new System.Drawing.Point(141, 24);
            this.TB_ACHighVoltage.Name = "TB_ACHighVoltage";
            this.TB_ACHighVoltage.ReadOnly = true;
            this.TB_ACHighVoltage.Size = new System.Drawing.Size(123, 25);
            this.TB_ACHighVoltage.TabIndex = 0;
            this.TB_ACHighVoltage.Text = "AC電壓過高";
            this.TB_ACHighVoltage.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("新細明體", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label15.Location = new System.Drawing.Point(9, 5);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(63, 13);
            this.label15.TabIndex = 1;
            this.label15.Text = "電源狀態";
            // 
            // TB_DCLowVoltage
            // 
            this.TB_DCLowVoltage.BackColor = System.Drawing.Color.Silver;
            this.TB_DCLowVoltage.Cursor = System.Windows.Forms.Cursors.Default;
            this.TB_DCLowVoltage.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.TB_DCLowVoltage.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.TB_DCLowVoltage.Location = new System.Drawing.Point(12, 54);
            this.TB_DCLowVoltage.Name = "TB_DCLowVoltage";
            this.TB_DCLowVoltage.ReadOnly = true;
            this.TB_DCLowVoltage.Size = new System.Drawing.Size(123, 25);
            this.TB_DCLowVoltage.TabIndex = 0;
            this.TB_DCLowVoltage.Text = " DC電壓過低";
            this.TB_DCLowVoltage.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // TB_ACLowVoltage
            // 
            this.TB_ACLowVoltage.BackColor = System.Drawing.Color.Silver;
            this.TB_ACLowVoltage.Cursor = System.Windows.Forms.Cursors.Default;
            this.TB_ACLowVoltage.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.TB_ACLowVoltage.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.TB_ACLowVoltage.Location = new System.Drawing.Point(141, 54);
            this.TB_ACLowVoltage.Name = "TB_ACLowVoltage";
            this.TB_ACLowVoltage.ReadOnly = true;
            this.TB_ACLowVoltage.Size = new System.Drawing.Size(123, 25);
            this.TB_ACLowVoltage.TabIndex = 0;
            this.TB_ACLowVoltage.Text = "AC電壓過低";
            this.TB_ACLowVoltage.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // TB_ACOverCurrent
            // 
            this.TB_ACOverCurrent.BackColor = System.Drawing.Color.Silver;
            this.TB_ACOverCurrent.Cursor = System.Windows.Forms.Cursors.Default;
            this.TB_ACOverCurrent.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.TB_ACOverCurrent.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.TB_ACOverCurrent.Location = new System.Drawing.Point(270, 24);
            this.TB_ACOverCurrent.Name = "TB_ACOverCurrent";
            this.TB_ACOverCurrent.ReadOnly = true;
            this.TB_ACOverCurrent.Size = new System.Drawing.Size(123, 25);
            this.TB_ACOverCurrent.TabIndex = 0;
            this.TB_ACOverCurrent.Text = "AC電流過高";
            this.TB_ACOverCurrent.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // TB_VacLimit
            // 
            this.TB_VacLimit.BackColor = System.Drawing.Color.Silver;
            this.TB_VacLimit.Cursor = System.Windows.Forms.Cursors.Default;
            this.TB_VacLimit.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.TB_VacLimit.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.TB_VacLimit.Location = new System.Drawing.Point(19, 20);
            this.TB_VacLimit.Name = "TB_VacLimit";
            this.TB_VacLimit.ReadOnly = true;
            this.TB_VacLimit.Size = new System.Drawing.Size(123, 25);
            this.TB_VacLimit.TabIndex = 0;
            this.TB_VacLimit.Text = "電流限頻";
            this.TB_VacLimit.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.groupBox1.Controls.Add(this.TB_OverLoad);
            this.groupBox1.Controls.Add(this.LB_VdcLimit);
            this.groupBox1.Controls.Add(this.TB_VacLimit);
            this.groupBox1.Location = new System.Drawing.Point(3, 238);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(424, 59);
            this.groupBox1.TabIndex = 9;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "限頻狀況";
            // 
            // TB_OverLoad
            // 
            this.TB_OverLoad.BackColor = System.Drawing.Color.Silver;
            this.TB_OverLoad.Cursor = System.Windows.Forms.Cursors.Default;
            this.TB_OverLoad.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.TB_OverLoad.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.TB_OverLoad.Location = new System.Drawing.Point(277, 20);
            this.TB_OverLoad.Name = "TB_OverLoad";
            this.TB_OverLoad.ReadOnly = true;
            this.TB_OverLoad.Size = new System.Drawing.Size(123, 25);
            this.TB_OverLoad.TabIndex = 0;
            this.TB_OverLoad.Text = "過負載限頻";
            this.TB_OverLoad.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // LB_VdcLimit
            // 
            this.LB_VdcLimit.BackColor = System.Drawing.Color.Silver;
            this.LB_VdcLimit.Cursor = System.Windows.Forms.Cursors.Default;
            this.LB_VdcLimit.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.LB_VdcLimit.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.LB_VdcLimit.Location = new System.Drawing.Point(148, 20);
            this.LB_VdcLimit.Name = "LB_VdcLimit";
            this.LB_VdcLimit.ReadOnly = true;
            this.LB_VdcLimit.Size = new System.Drawing.Size(123, 25);
            this.LB_VdcLimit.TabIndex = 0;
            this.LB_VdcLimit.Text = "電壓限頻";
            this.LB_VdcLimit.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.groupBox2.Controls.Add(this.TB_FaultState);
            this.groupBox2.Controls.Add(this.TB_Protect_lim);
            this.groupBox2.Controls.Add(this.TB_Protect_err);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Location = new System.Drawing.Point(3, 303);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(424, 74);
            this.groupBox2.TabIndex = 10;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "狀態顯示";
            // 
            // TB_FaultState
            // 
            this.TB_FaultState.BackColor = System.Drawing.Color.Green;
            this.TB_FaultState.Cursor = System.Windows.Forms.Cursors.Default;
            this.TB_FaultState.Font = new System.Drawing.Font("Consolas", 15F);
            this.TB_FaultState.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.TB_FaultState.Location = new System.Drawing.Point(241, 34);
            this.TB_FaultState.Name = "TB_FaultState";
            this.TB_FaultState.ReadOnly = true;
            this.TB_FaultState.Size = new System.Drawing.Size(148, 31);
            this.TB_FaultState.TabIndex = 0;
            this.TB_FaultState.Text = "NO_FAULT";
            this.TB_FaultState.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // TB_Protect_lim
            // 
            this.TB_Protect_lim.BackColor = System.Drawing.Color.SteelBlue;
            this.TB_Protect_lim.Cursor = System.Windows.Forms.Cursors.Default;
            this.TB_Protect_lim.Font = new System.Drawing.Font("Consolas", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TB_Protect_lim.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.TB_Protect_lim.Location = new System.Drawing.Point(144, 34);
            this.TB_Protect_lim.Name = "TB_Protect_lim";
            this.TB_Protect_lim.ReadOnly = true;
            this.TB_Protect_lim.Size = new System.Drawing.Size(66, 32);
            this.TB_Protect_lim.TabIndex = 0;
            this.TB_Protect_lim.Text = "01";
            this.TB_Protect_lim.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // TB_Protect_err
            // 
            this.TB_Protect_err.BackColor = System.Drawing.Color.SteelBlue;
            this.TB_Protect_err.Cursor = System.Windows.Forms.Cursors.Default;
            this.TB_Protect_err.Font = new System.Drawing.Font("Consolas", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TB_Protect_err.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.TB_Protect_err.Location = new System.Drawing.Point(47, 34);
            this.TB_Protect_err.Name = "TB_Protect_err";
            this.TB_Protect_err.ReadOnly = true;
            this.TB_Protect_err.Size = new System.Drawing.Size(66, 32);
            this.TB_Protect_err.TabIndex = 0;
            this.TB_Protect_err.Text = "01";
            this.TB_Protect_err.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(275, 18);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(77, 12);
            this.label3.TabIndex = 0;
            this.label3.Text = "故障保護狀態";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(150, 18);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 12);
            this.label2.TabIndex = 0;
            this.label2.Text = "限頻代碼";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(54, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "錯誤代碼";
            // 
            // ErrorDispUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBox4);
            this.Name = "ErrorDispUI";
            this.Size = new System.Drawing.Size(435, 380);
            this.groupBox4.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.TextBox TB_IPMTemp;
        private System.Windows.Forms.TextBox TB_IPMFault;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TextBox TB_StartUpErr;
        private System.Windows.Forms.TextBox TB_VacLimit;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox TB_PhaseLose;
        private System.Windows.Forms.TextBox TB_LoseSpeed;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox TB_DCHighVoltage;
        private System.Windows.Forms.TextBox TB_ACHighVoltage;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox TB_DCLowVoltage;
        private System.Windows.Forms.TextBox TB_ACLowVoltage;
        private System.Windows.Forms.TextBox TB_ACOverCurrent;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox TB_OverLoad;
        private System.Windows.Forms.TextBox LB_VdcLimit;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox TB_Protect_err;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox TB_Protect_lim;
        private System.Windows.Forms.TextBox TB_FaultState;
        private System.Windows.Forms.Label label3;
    }
}

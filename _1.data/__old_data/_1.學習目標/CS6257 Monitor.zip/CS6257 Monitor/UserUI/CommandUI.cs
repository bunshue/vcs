﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace CS6257_Monitor
{
    public partial class CommandUI : UserControl
    {
        public CommandUI()
        {
            InitializeComponent();
        }

        public TransControl bc;

        /// <summary>
        /// 初始化
        /// </summary>
        /// <param name="bc_ref"></param>
        public void Init_CommandUI(TransControl bc_ref)
        {
            bc = bc_ref;
        }

        /// <summary>
        /// 開啟命令檔案
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Open_CMD_File_button_Click(object sender, EventArgs e)
        {
            this.Open_CMD_FileToListView(this.CMD_listView);
        }

        /// <summary>
        /// 發送命令按鈕按下後引發事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Send_Click(object sender, EventArgs e)
        {
            Send_HexCommand(this.Send_richText);
        }

        /// <summary>
        /// 清除 Send_richText 中的內容
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Clear_sendrichtext_Click(object sender, EventArgs e)
        {
            this.Send_richText.Clear();
        }

        /// <summary>
        /// ListView 滑鼠雙擊時引發事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void CMD_listView_DoubleClick(object sender, EventArgs e)
        {
            ListViewDoubleClick(this.CMD_listView, this.Send_richText);
        }

        /// <summary>
        /// ListView 滑鼠雙擊時傳送至 SendRichText
        /// </summary>
        /// <param name="listview"></param>
        public void ListViewDoubleClick(ListView listview, RichTextBox richtextbox)
        {
            if (listview.SelectedItems.Count != 0)
            {
                string str = listview.SelectedItems[0].Text;
                str = str.Trim();
                richtextbox.Text = str;
                ToIntString(str, richtextbox);
            }
        }


        /// <summary>
        /// 開啟 CMD 命令檔案並加入至ListView
        /// </summary>
        private void Open_CMD_FileToListView(ListView listview)
        {
            OpenFileDialog P_OpenFileDialog = new OpenFileDialog();
            if (P_OpenFileDialog.ShowDialog() == DialogResult.OK)
            {
                string filepath = P_OpenFileDialog.FileName;
                FileStream fs = File.Open(filepath, FileMode.Open);
                StreamReader str_reader = new StreamReader(fs);
                string str = string.Empty;
                listview.Items.Clear();
                while ((str = str_reader.ReadLine()) != null)
                {
                    ListViewItem item = new ListViewItem(str);
                    listview.Items.Add(item);
                }
            }
        }


        /// <summary>
        /// 發送命令
        /// </summary>
        public void Send_HexCommand(RichTextBox richtextbox)
        {
            byte[] b;
            if (richtextbox.Text != string.Empty)
            {
                try
                {
                    b = ToByte(richtextbox.Text);
                    if (bc.IsComPortOpen())
                    {
                        try
                        {
                            bc.SendCmdByte(b);
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(ex.ToString());
                        }

                    }
                    else
                    {
                        MessageBox.Show("連接埠未開啟");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());
                }

            }
            else
            {
                return;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="hex_str"></param>
        /// <param name="richtextbox"></param>
        public void ToIntString(string hex_str, RichTextBox richtextbox)
        {
            richtextbox.Clear();
            string[] hexValuesSplit = hex_str.Split(' ');
            try
            {
                byte sum = 0;
                foreach (String hex in hexValuesSplit)
                {
                    int value = Convert.ToInt32(hex, 16);
                    byte b = Convert.ToByte(hex, 16);
                    sum += b;
                    //string stringValue = Char.ConvertFromUtf32(value);
                    //richtextbox.Text += value.ToString() + ' ';
                    richtextbox.Text += hex + ' ';
                }
                sum = (byte)((sum ^ 0xFF) + 1);
                richtextbox.Text += sum.ToString("X2");
            }
            catch (Exception ex)
            {
                //richtextbox.AppendText("Error : " + ex.ToString());
                richtextbox.AppendText(ex.ToString());
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="hex_str"></param>
        /// <returns></returns>
        public byte[] ToByte(string hex_str)
        {
            byte[] temp = new byte[100];
            int cnt = 0;

            string[] hexValuesSplit = hex_str.Split(' ');
            foreach (String hex in hexValuesSplit)
            {
                temp[cnt] = Convert.ToByte(hex, 16);
                cnt++;
            }

            byte[] b = new byte[cnt];

            for (int ii = 0; ii < cnt; ii++)
            {
                b[ii] = temp[ii];
            }

            return b;
        }



    }
}

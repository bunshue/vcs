﻿namespace CS6257_Monitor
{
    partial class ControlUI
    {
        /// <summary> 
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 元件設計工具產生的程式碼

        /// <summary> 
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器
        /// 修改這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.panel6 = new System.Windows.Forms.Panel();
            this.Spd_Cmd_trackBar = new System.Windows.Forms.TrackBar();
            this.motor_spd_cmd_button = new System.Windows.Forms.Button();
            this.label68 = new System.Windows.Forms.Label();
            this.label67 = new System.Windows.Forms.Label();
            this.num_spd_rpm_cmd = new System.Windows.Forms.NumericUpDown();
            this.num_spd_rps_cmd = new System.Windows.Forms.NumericUpDown();
            this.label66 = new System.Windows.Forms.Label();
            this.panel11 = new System.Windows.Forms.Panel();
            this.Auto_Mode_button = new System.Windows.Forms.Button();
            this.Manual_Mode_button = new System.Windows.Forms.Button();
            this.label84 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.Ra_SpdCtrl = new System.Windows.Forms.RadioButton();
            this.Ra_DutyCtrl = new System.Windows.Forms.RadioButton();
            this.stop_outfan_button = new System.Windows.Forms.Button();
            this.weak_wind_button = new System.Windows.Forms.Button();
            this.Medium_wind_button = new System.Windows.Forms.Button();
            this.Strong_wind_button = new System.Windows.Forms.Button();
            this.outfan_spd_cmd_button = new System.Windows.Forms.Button();
            this.label_OutFanCtrl = new System.Windows.Forms.Label();
            this.label69 = new System.Windows.Forms.Label();
            this.num_outfan_spd_cmd = new System.Windows.Forms.NumericUpDown();
            this.panel7 = new System.Windows.Forms.Panel();
            this.Enable_checkBox = new System.Windows.Forms.CheckBox();
            this.label74 = new System.Windows.Forms.Label();
            this.label73 = new System.Windows.Forms.Label();
            this.Four_Way_Valve_OFF_button = new System.Windows.Forms.Button();
            this.PFC_OFF_button = new System.Windows.Forms.Button();
            this.Four_Way_Valve_ON_button = new System.Windows.Forms.Button();
            this.PFC_ON_button = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.motor_start_button = new System.Windows.Forms.Button();
            this.motor_stop_button = new System.Windows.Forms.Button();
            this.panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Spd_Cmd_trackBar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_spd_rpm_cmd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_spd_rps_cmd)).BeginInit();
            this.panel11.SuspendLayout();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.num_outfan_spd_cmd)).BeginInit();
            this.panel7.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel6
            // 
            this.panel6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel6.Controls.Add(this.Spd_Cmd_trackBar);
            this.panel6.Controls.Add(this.motor_spd_cmd_button);
            this.panel6.Controls.Add(this.label68);
            this.panel6.Controls.Add(this.label67);
            this.panel6.Controls.Add(this.num_spd_rpm_cmd);
            this.panel6.Controls.Add(this.num_spd_rps_cmd);
            this.panel6.Controls.Add(this.label66);
            this.panel6.Location = new System.Drawing.Point(3, 55);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(347, 112);
            this.panel6.TabIndex = 35;
            // 
            // Spd_Cmd_trackBar
            // 
            this.Spd_Cmd_trackBar.LargeChange = 10;
            this.Spd_Cmd_trackBar.Location = new System.Drawing.Point(22, 64);
            this.Spd_Cmd_trackBar.Maximum = 120;
            this.Spd_Cmd_trackBar.Minimum = 20;
            this.Spd_Cmd_trackBar.Name = "Spd_Cmd_trackBar";
            this.Spd_Cmd_trackBar.Size = new System.Drawing.Size(310, 45);
            this.Spd_Cmd_trackBar.SmallChange = 10;
            this.Spd_Cmd_trackBar.TabIndex = 27;
            this.Spd_Cmd_trackBar.TickFrequency = 10;
            this.Spd_Cmd_trackBar.Value = 20;
            this.Spd_Cmd_trackBar.Scroll += new System.EventHandler(this.Spd_Cmd_trackBar_Scroll);
            // 
            // motor_spd_cmd_button
            // 
            this.motor_spd_cmd_button.Location = new System.Drawing.Point(267, 26);
            this.motor_spd_cmd_button.Name = "motor_spd_cmd_button";
            this.motor_spd_cmd_button.Size = new System.Drawing.Size(65, 33);
            this.motor_spd_cmd_button.TabIndex = 25;
            this.motor_spd_cmd_button.Text = "設定";
            this.motor_spd_cmd_button.UseVisualStyleBackColor = true;
            this.motor_spd_cmd_button.Click += new System.EventHandler(this.motor_spd_cmd_button_Click);
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Location = new System.Drawing.Point(230, 45);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(19, 12);
            this.label68.TabIndex = 26;
            this.label68.Text = "rps";
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Location = new System.Drawing.Point(106, 44);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(24, 12);
            this.label67.TabIndex = 22;
            this.label67.Text = "rpm";
            // 
            // num_spd_rpm_cmd
            // 
            this.num_spd_rpm_cmd.Location = new System.Drawing.Point(22, 34);
            this.num_spd_rpm_cmd.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.num_spd_rpm_cmd.Name = "num_spd_rpm_cmd";
            this.num_spd_rpm_cmd.ReadOnly = true;
            this.num_spd_rpm_cmd.Size = new System.Drawing.Size(78, 22);
            this.num_spd_rpm_cmd.TabIndex = 24;
            // 
            // num_spd_rps_cmd
            // 
            this.num_spd_rps_cmd.Location = new System.Drawing.Point(146, 34);
            this.num_spd_rps_cmd.Maximum = new decimal(new int[] {
            200,
            0,
            0,
            0});
            this.num_spd_rps_cmd.Name = "num_spd_rps_cmd";
            this.num_spd_rps_cmd.Size = new System.Drawing.Size(78, 22);
            this.num_spd_rps_cmd.TabIndex = 23;
            this.num_spd_rps_cmd.Value = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.num_spd_rps_cmd.ValueChanged += new System.EventHandler(this.num_spd_rps_cmd_ValueChanged);
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label66.ForeColor = System.Drawing.Color.Maroon;
            this.label66.Location = new System.Drawing.Point(20, 12);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(96, 12);
            this.label66.TabIndex = 21;
            this.label66.Text = "壓縮機轉速控制";
            // 
            // panel11
            // 
            this.panel11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel11.Controls.Add(this.Auto_Mode_button);
            this.panel11.Controls.Add(this.Manual_Mode_button);
            this.panel11.Controls.Add(this.label84);
            this.panel11.Location = new System.Drawing.Point(3, 3);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(265, 46);
            this.panel11.TabIndex = 34;
            // 
            // Auto_Mode_button
            // 
            this.Auto_Mode_button.Location = new System.Drawing.Point(189, 3);
            this.Auto_Mode_button.Name = "Auto_Mode_button";
            this.Auto_Mode_button.Size = new System.Drawing.Size(65, 37);
            this.Auto_Mode_button.TabIndex = 0;
            this.Auto_Mode_button.Text = "自動";
            this.Auto_Mode_button.UseVisualStyleBackColor = true;
            this.Auto_Mode_button.Click += new System.EventHandler(this.Auto_Mode_button_Click);
            // 
            // Manual_Mode_button
            // 
            this.Manual_Mode_button.Location = new System.Drawing.Point(114, 3);
            this.Manual_Mode_button.Name = "Manual_Mode_button";
            this.Manual_Mode_button.Size = new System.Drawing.Size(65, 37);
            this.Manual_Mode_button.TabIndex = 0;
            this.Manual_Mode_button.Text = "手動";
            this.Manual_Mode_button.UseVisualStyleBackColor = true;
            this.Manual_Mode_button.Click += new System.EventHandler(this.Manual_Mode_button_Click);
            // 
            // label84
            // 
            this.label84.AutoSize = true;
            this.label84.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label84.ForeColor = System.Drawing.Color.Maroon;
            this.label84.Location = new System.Drawing.Point(20, 15);
            this.label84.Name = "label84";
            this.label84.Size = new System.Drawing.Size(83, 12);
            this.label84.TabIndex = 21;
            this.label84.Text = "操作模式設定";
            // 
            // panel5
            // 
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel5.Controls.Add(this.Ra_SpdCtrl);
            this.panel5.Controls.Add(this.Ra_DutyCtrl);
            this.panel5.Controls.Add(this.stop_outfan_button);
            this.panel5.Controls.Add(this.weak_wind_button);
            this.panel5.Controls.Add(this.Medium_wind_button);
            this.panel5.Controls.Add(this.Strong_wind_button);
            this.panel5.Controls.Add(this.outfan_spd_cmd_button);
            this.panel5.Controls.Add(this.label_OutFanCtrl);
            this.panel5.Controls.Add(this.label69);
            this.panel5.Controls.Add(this.num_outfan_spd_cmd);
            this.panel5.Location = new System.Drawing.Point(3, 173);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(347, 125);
            this.panel5.TabIndex = 36;
            // 
            // Ra_SpdCtrl
            // 
            this.Ra_SpdCtrl.AutoSize = true;
            this.Ra_SpdCtrl.Checked = true;
            this.Ra_SpdCtrl.Location = new System.Drawing.Point(231, 14);
            this.Ra_SpdCtrl.Name = "Ra_SpdCtrl";
            this.Ra_SpdCtrl.Size = new System.Drawing.Size(90, 16);
            this.Ra_SpdCtrl.TabIndex = 27;
            this.Ra_SpdCtrl.TabStop = true;
            this.Ra_SpdCtrl.Text = "Speed Control";
            this.Ra_SpdCtrl.UseVisualStyleBackColor = true;
            // 
            // Ra_DutyCtrl
            // 
            this.Ra_DutyCtrl.AutoSize = true;
            this.Ra_DutyCtrl.Location = new System.Drawing.Point(139, 14);
            this.Ra_DutyCtrl.Name = "Ra_DutyCtrl";
            this.Ra_DutyCtrl.Size = new System.Drawing.Size(85, 16);
            this.Ra_DutyCtrl.TabIndex = 26;
            this.Ra_DutyCtrl.Text = "Duty Control";
            this.Ra_DutyCtrl.UseVisualStyleBackColor = true;
            // 
            // stop_outfan_button
            // 
            this.stop_outfan_button.Location = new System.Drawing.Point(254, 78);
            this.stop_outfan_button.Name = "stop_outfan_button";
            this.stop_outfan_button.Size = new System.Drawing.Size(67, 33);
            this.stop_outfan_button.TabIndex = 25;
            this.stop_outfan_button.Text = "關閉";
            this.stop_outfan_button.UseVisualStyleBackColor = true;
            this.stop_outfan_button.Click += new System.EventHandler(this.stop_outfan_button_Click);
            // 
            // weak_wind_button
            // 
            this.weak_wind_button.Location = new System.Drawing.Point(168, 79);
            this.weak_wind_button.Name = "weak_wind_button";
            this.weak_wind_button.Size = new System.Drawing.Size(67, 33);
            this.weak_wind_button.TabIndex = 25;
            this.weak_wind_button.Text = "弱風";
            this.weak_wind_button.UseVisualStyleBackColor = true;
            this.weak_wind_button.Click += new System.EventHandler(this.weak_wind_button_Click);
            // 
            // Medium_wind_button
            // 
            this.Medium_wind_button.Location = new System.Drawing.Point(95, 79);
            this.Medium_wind_button.Name = "Medium_wind_button";
            this.Medium_wind_button.Size = new System.Drawing.Size(67, 33);
            this.Medium_wind_button.TabIndex = 25;
            this.Medium_wind_button.Text = "中風";
            this.Medium_wind_button.UseVisualStyleBackColor = true;
            this.Medium_wind_button.Click += new System.EventHandler(this.Medium_wind_button_Click);
            // 
            // Strong_wind_button
            // 
            this.Strong_wind_button.Location = new System.Drawing.Point(22, 79);
            this.Strong_wind_button.Name = "Strong_wind_button";
            this.Strong_wind_button.Size = new System.Drawing.Size(67, 33);
            this.Strong_wind_button.TabIndex = 25;
            this.Strong_wind_button.Text = "強風";
            this.Strong_wind_button.UseVisualStyleBackColor = true;
            this.Strong_wind_button.Click += new System.EventHandler(this.Strong_wind_button_Click);
            // 
            // outfan_spd_cmd_button
            // 
            this.outfan_spd_cmd_button.Location = new System.Drawing.Point(246, 36);
            this.outfan_spd_cmd_button.Name = "outfan_spd_cmd_button";
            this.outfan_spd_cmd_button.Size = new System.Drawing.Size(75, 36);
            this.outfan_spd_cmd_button.TabIndex = 25;
            this.outfan_spd_cmd_button.Text = "設定";
            this.outfan_spd_cmd_button.UseVisualStyleBackColor = true;
            this.outfan_spd_cmd_button.Click += new System.EventHandler(this.outfan_spd_cmd_button_Click);
            // 
            // label_OutFanCtrl
            // 
            this.label_OutFanCtrl.AutoSize = true;
            this.label_OutFanCtrl.Location = new System.Drawing.Point(20, 48);
            this.label_OutFanCtrl.Name = "label_OutFanCtrl";
            this.label_OutFanCtrl.Size = new System.Drawing.Size(33, 12);
            this.label_OutFanCtrl.TabIndex = 21;
            this.label_OutFanCtrl.Text = "Speed";
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label69.ForeColor = System.Drawing.Color.Maroon;
            this.label69.Location = new System.Drawing.Point(20, 16);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(109, 12);
            this.label69.TabIndex = 21;
            this.label69.Text = "室外風扇轉速控制";
            // 
            // num_outfan_spd_cmd
            // 
            this.num_outfan_spd_cmd.Location = new System.Drawing.Point(90, 44);
            this.num_outfan_spd_cmd.Maximum = new decimal(new int[] {
            50000,
            0,
            0,
            0});
            this.num_outfan_spd_cmd.Name = "num_outfan_spd_cmd";
            this.num_outfan_spd_cmd.Size = new System.Drawing.Size(89, 22);
            this.num_outfan_spd_cmd.TabIndex = 24;
            // 
            // panel7
            // 
            this.panel7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel7.Controls.Add(this.Enable_checkBox);
            this.panel7.Controls.Add(this.label74);
            this.panel7.Controls.Add(this.label73);
            this.panel7.Controls.Add(this.Four_Way_Valve_OFF_button);
            this.panel7.Controls.Add(this.PFC_OFF_button);
            this.panel7.Controls.Add(this.Four_Way_Valve_ON_button);
            this.panel7.Controls.Add(this.PFC_ON_button);
            this.panel7.Location = new System.Drawing.Point(356, 55);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(133, 145);
            this.panel7.TabIndex = 37;
            // 
            // Enable_checkBox
            // 
            this.Enable_checkBox.AutoSize = true;
            this.Enable_checkBox.Location = new System.Drawing.Point(9, 8);
            this.Enable_checkBox.Name = "Enable_checkBox";
            this.Enable_checkBox.Size = new System.Drawing.Size(60, 16);
            this.Enable_checkBox.TabIndex = 3;
            this.Enable_checkBox.Text = "Control";
            this.Enable_checkBox.UseVisualStyleBackColor = true;
            this.Enable_checkBox.CheckedChanged += new System.EventHandler(this.Enable_checkBox_CheckedChanged);
            // 
            // label74
            // 
            this.label74.AutoSize = true;
            this.label74.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label74.ForeColor = System.Drawing.Color.Navy;
            this.label74.Location = new System.Drawing.Point(7, 80);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(44, 12);
            this.label74.TabIndex = 1;
            this.label74.Text = "四通閥";
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label73.ForeColor = System.Drawing.Color.Navy;
            this.label73.Location = new System.Drawing.Point(7, 27);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(28, 12);
            this.label73.TabIndex = 1;
            this.label73.Text = "PFC";
            // 
            // Four_Way_Valve_OFF_button
            // 
            this.Four_Way_Valve_OFF_button.Enabled = false;
            this.Four_Way_Valve_OFF_button.Location = new System.Drawing.Point(67, 97);
            this.Four_Way_Valve_OFF_button.Name = "Four_Way_Valve_OFF_button";
            this.Four_Way_Valve_OFF_button.Size = new System.Drawing.Size(52, 30);
            this.Four_Way_Valve_OFF_button.TabIndex = 0;
            this.Four_Way_Valve_OFF_button.Text = "OFF";
            this.Four_Way_Valve_OFF_button.UseVisualStyleBackColor = true;
            this.Four_Way_Valve_OFF_button.Click += new System.EventHandler(this.Four_Way_Valve_OFF_button_Click);
            // 
            // PFC_OFF_button
            // 
            this.PFC_OFF_button.Enabled = false;
            this.PFC_OFF_button.Location = new System.Drawing.Point(67, 42);
            this.PFC_OFF_button.Name = "PFC_OFF_button";
            this.PFC_OFF_button.Size = new System.Drawing.Size(52, 30);
            this.PFC_OFF_button.TabIndex = 0;
            this.PFC_OFF_button.Text = "OFF";
            this.PFC_OFF_button.UseVisualStyleBackColor = true;
            this.PFC_OFF_button.Click += new System.EventHandler(this.PFC_OFF_button_Click);
            // 
            // Four_Way_Valve_ON_button
            // 
            this.Four_Way_Valve_ON_button.Enabled = false;
            this.Four_Way_Valve_ON_button.Location = new System.Drawing.Point(9, 97);
            this.Four_Way_Valve_ON_button.Name = "Four_Way_Valve_ON_button";
            this.Four_Way_Valve_ON_button.Size = new System.Drawing.Size(52, 30);
            this.Four_Way_Valve_ON_button.TabIndex = 0;
            this.Four_Way_Valve_ON_button.Text = "ON";
            this.Four_Way_Valve_ON_button.UseVisualStyleBackColor = true;
            this.Four_Way_Valve_ON_button.Click += new System.EventHandler(this.Four_Way_Valve_ON_button_Click);
            // 
            // PFC_ON_button
            // 
            this.PFC_ON_button.Enabled = false;
            this.PFC_ON_button.Location = new System.Drawing.Point(9, 42);
            this.PFC_ON_button.Name = "PFC_ON_button";
            this.PFC_ON_button.Size = new System.Drawing.Size(52, 30);
            this.PFC_ON_button.TabIndex = 0;
            this.PFC_ON_button.Text = "ON";
            this.PFC_ON_button.UseVisualStyleBackColor = true;
            this.PFC_ON_button.Click += new System.EventHandler(this.PFC_ON_button_Click);
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.motor_start_button);
            this.panel1.Controls.Add(this.motor_stop_button);
            this.panel1.Location = new System.Drawing.Point(356, 206);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(133, 92);
            this.panel1.TabIndex = 38;
            // 
            // motor_start_button
            // 
            this.motor_start_button.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.motor_start_button.ForeColor = System.Drawing.Color.MediumSeaGreen;
            this.motor_start_button.Location = new System.Drawing.Point(9, 8);
            this.motor_start_button.Name = "motor_start_button";
            this.motor_start_button.Size = new System.Drawing.Size(52, 75);
            this.motor_start_button.TabIndex = 19;
            this.motor_start_button.Text = "啟動";
            this.motor_start_button.UseVisualStyleBackColor = true;
            this.motor_start_button.Click += new System.EventHandler(this.motor_start_button_Click);
            // 
            // motor_stop_button
            // 
            this.motor_stop_button.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.motor_stop_button.ForeColor = System.Drawing.Color.Crimson;
            this.motor_stop_button.Location = new System.Drawing.Point(67, 8);
            this.motor_stop_button.Name = "motor_stop_button";
            this.motor_stop_button.Size = new System.Drawing.Size(52, 75);
            this.motor_stop_button.TabIndex = 20;
            this.motor_stop_button.Text = "停止";
            this.motor_stop_button.UseVisualStyleBackColor = true;
            this.motor_stop_button.Click += new System.EventHandler(this.motor_stop_button_Click);
            // 
            // ControlUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel7);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel11);
            this.Name = "ControlUI";
            this.Size = new System.Drawing.Size(501, 307);
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Spd_Cmd_trackBar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_spd_rpm_cmd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_spd_rps_cmd)).EndInit();
            this.panel11.ResumeLayout(false);
            this.panel11.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.num_outfan_spd_cmd)).EndInit();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.TrackBar Spd_Cmd_trackBar;
        private System.Windows.Forms.Button motor_spd_cmd_button;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.NumericUpDown num_spd_rpm_cmd;
        private System.Windows.Forms.NumericUpDown num_spd_rps_cmd;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Button Auto_Mode_button;
        private System.Windows.Forms.Button Manual_Mode_button;
        private System.Windows.Forms.Label label84;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.RadioButton Ra_SpdCtrl;
        private System.Windows.Forms.RadioButton Ra_DutyCtrl;
        private System.Windows.Forms.Button stop_outfan_button;
        private System.Windows.Forms.Button weak_wind_button;
        private System.Windows.Forms.Button Medium_wind_button;
        private System.Windows.Forms.Button Strong_wind_button;
        private System.Windows.Forms.Button outfan_spd_cmd_button;
        private System.Windows.Forms.Label label_OutFanCtrl;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.NumericUpDown num_outfan_spd_cmd;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.CheckBox Enable_checkBox;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.Button Four_Way_Valve_OFF_button;
        private System.Windows.Forms.Button PFC_OFF_button;
        private System.Windows.Forms.Button Four_Way_Valve_ON_button;
        private System.Windows.Forms.Button PFC_ON_button;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button motor_start_button;
        private System.Windows.Forms.Button motor_stop_button;
    }
}

﻿namespace CS6257_Monitor.UserUI
{
    partial class MonitorUI_Lite
    {
        /// <summary> 
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 元件設計工具產生的程式碼

        /// <summary> 
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器
        /// 修改這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel10 = new System.Windows.Forms.Panel();
            this.TB_SystemState = new System.Windows.Forms.TextBox();
            this.TB_MotorState = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.TB_SetSpeed = new System.Windows.Forms.TextBox();
            this.panel8 = new System.Windows.Forms.Panel();
            this.panel11 = new System.Windows.Forms.Panel();
            this.motor_start_button = new System.Windows.Forms.Button();
            this.motor_stop_button = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.panel9 = new System.Windows.Forms.Panel();
            this.label68 = new System.Windows.Forms.Label();
            this.num_spd_rpm_cmd = new System.Windows.Forms.NumericUpDown();
            this.label4 = new System.Windows.Forms.Label();
            this.Spd_Cmd_trackBar = new System.Windows.Forms.TrackBar();
            this.motor_spd_cmd_button = new System.Windows.Forms.Button();
            this.label66 = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.TB_OverCurrent = new System.Windows.Forms.TextBox();
            this.TB_LosePhase = new System.Windows.Forms.TextBox();
            this.TB_StartUpErr = new System.Windows.Forms.TextBox();
            this.TB_ACVoltageErr = new System.Windows.Forms.TextBox();
            this.TB_IPMFault = new System.Windows.Forms.TextBox();
            this.TB_CurSensorErr = new System.Windows.Forms.TextBox();
            this.TB_ACOverCurrent = new System.Windows.Forms.TextBox();
            this.TB_DCVoltageErr = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.TB_ParaSYNState = new System.Windows.Forms.TextBox();
            this.TB_LinkState = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.TB_Power = new System.Windows.Forms.TextBox();
            this.aGauge_Power = new AGaugeApp.AGauge();
            this.panel2 = new System.Windows.Forms.Panel();
            this.TB_RealSpeed = new System.Windows.Forms.TextBox();
            this.aGauge_Speed = new AGaugeApp.AGauge();
            this.panel6 = new System.Windows.Forms.Panel();
            this.TB_IqCurrent = new System.Windows.Forms.TextBox();
            this.TB_ACCurrent = new System.Windows.Forms.TextBox();
            this.aGauge_IqCurrent = new AGaugeApp.AGauge();
            this.aGauge_ACCurrent = new AGaugeApp.AGauge();
            this.panel1 = new System.Windows.Forms.Panel();
            this.TB_DCVoltage = new System.Windows.Forms.TextBox();
            this.TB_ACVoltage = new System.Windows.Forms.TextBox();
            this.aGauge_DCVoltage = new AGaugeApp.AGauge();
            this.aGauge_ACVoltage = new AGaugeApp.AGauge();
            this.TB_LoseSpeed = new System.Windows.Forms.TextBox();
            this.panel3.SuspendLayout();
            this.panel10.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel11.SuspendLayout();
            this.panel9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.num_spd_rpm_cmd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Spd_Cmd_trackBar)).BeginInit();
            this.panel7.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.panel3.Controls.Add(this.panel10);
            this.panel3.Controls.Add(this.panel8);
            this.panel3.Controls.Add(this.panel7);
            this.panel3.Controls.Add(this.panel5);
            this.panel3.Controls.Add(this.panel4);
            this.panel3.Controls.Add(this.panel2);
            this.panel3.Controls.Add(this.panel6);
            this.panel3.Controls.Add(this.panel1);
            this.panel3.Location = new System.Drawing.Point(3, 3);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1071, 578);
            this.panel3.TabIndex = 37;
            // 
            // panel10
            // 
            this.panel10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel10.Controls.Add(this.TB_SystemState);
            this.panel10.Controls.Add(this.TB_MotorState);
            this.panel10.Controls.Add(this.label7);
            this.panel10.Controls.Add(this.label6);
            this.panel10.Controls.Add(this.label5);
            this.panel10.Controls.Add(this.TB_SetSpeed);
            this.panel10.Location = new System.Drawing.Point(3, 6);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(771, 41);
            this.panel10.TabIndex = 38;
            // 
            // TB_SystemState
            // 
            this.TB_SystemState.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TB_SystemState.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TB_SystemState.ForeColor = System.Drawing.Color.DarkGreen;
            this.TB_SystemState.Location = new System.Drawing.Point(530, 8);
            this.TB_SystemState.Name = "TB_SystemState";
            this.TB_SystemState.Size = new System.Drawing.Size(100, 26);
            this.TB_SystemState.TabIndex = 2;
            this.TB_SystemState.Text = "IDLE";
            this.TB_SystemState.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // TB_MotorState
            // 
            this.TB_MotorState.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TB_MotorState.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TB_MotorState.ForeColor = System.Drawing.Color.DarkGreen;
            this.TB_MotorState.Location = new System.Drawing.Point(114, 8);
            this.TB_MotorState.Name = "TB_MotorState";
            this.TB_MotorState.Size = new System.Drawing.Size(100, 26);
            this.TB_MotorState.TabIndex = 2;
            this.TB_MotorState.Text = "Running";
            this.TB_MotorState.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe UI Symbol", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(421, 8);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(100, 21);
            this.label7.TabIndex = 1;
            this.label7.Text = "System State";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe UI Symbol", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(13, 8);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(92, 21);
            this.label6.TabIndex = 1;
            this.label6.Text = "Motor State";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI Symbol", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(223, 8);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(79, 21);
            this.label5.TabIndex = 1;
            this.label5.Text = "Set Speed";
            // 
            // TB_SetSpeed
            // 
            this.TB_SetSpeed.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.TB_SetSpeed.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TB_SetSpeed.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.TB_SetSpeed.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TB_SetSpeed.ForeColor = System.Drawing.SystemColors.ControlText;
            this.TB_SetSpeed.Location = new System.Drawing.Point(311, 8);
            this.TB_SetSpeed.Name = "TB_SetSpeed";
            this.TB_SetSpeed.ReadOnly = true;
            this.TB_SetSpeed.Size = new System.Drawing.Size(101, 26);
            this.TB_SetSpeed.TabIndex = 0;
            this.TB_SetSpeed.Text = "1200 rpm";
            this.TB_SetSpeed.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // panel8
            // 
            this.panel8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel8.Controls.Add(this.panel11);
            this.panel8.Controls.Add(this.panel9);
            this.panel8.Controls.Add(this.label66);
            this.panel8.Location = new System.Drawing.Point(780, 296);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(288, 278);
            this.panel8.TabIndex = 37;
            // 
            // panel11
            // 
            this.panel11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel11.Controls.Add(this.motor_start_button);
            this.panel11.Controls.Add(this.motor_stop_button);
            this.panel11.Controls.Add(this.label8);
            this.panel11.Location = new System.Drawing.Point(9, 191);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(274, 74);
            this.panel11.TabIndex = 29;
            // 
            // motor_start_button
            // 
            this.motor_start_button.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.motor_start_button.ForeColor = System.Drawing.Color.MediumSeaGreen;
            this.motor_start_button.Location = new System.Drawing.Point(91, 9);
            this.motor_start_button.Name = "motor_start_button";
            this.motor_start_button.Size = new System.Drawing.Size(75, 56);
            this.motor_start_button.TabIndex = 19;
            this.motor_start_button.Text = "Run";
            this.motor_start_button.UseVisualStyleBackColor = true;
            this.motor_start_button.Click += new System.EventHandler(this.motor_start_button_Click);
            // 
            // motor_stop_button
            // 
            this.motor_stop_button.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.motor_stop_button.ForeColor = System.Drawing.Color.Crimson;
            this.motor_stop_button.Location = new System.Drawing.Point(185, 9);
            this.motor_stop_button.Name = "motor_stop_button";
            this.motor_stop_button.Size = new System.Drawing.Size(75, 56);
            this.motor_stop_button.TabIndex = 20;
            this.motor_stop_button.Text = "Stop";
            this.motor_stop_button.UseVisualStyleBackColor = true;
            this.motor_stop_button.Click += new System.EventHandler(this.motor_stop_button_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Segoe UI Symbol", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(7, 9);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(78, 17);
            this.label8.TabIndex = 1;
            this.label8.Text = "Motor State";
            // 
            // panel9
            // 
            this.panel9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel9.Controls.Add(this.label68);
            this.panel9.Controls.Add(this.num_spd_rpm_cmd);
            this.panel9.Controls.Add(this.label4);
            this.panel9.Controls.Add(this.Spd_Cmd_trackBar);
            this.panel9.Controls.Add(this.motor_spd_cmd_button);
            this.panel9.Location = new System.Drawing.Point(9, 27);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(274, 158);
            this.panel9.TabIndex = 28;
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label68.Location = new System.Drawing.Point(194, 55);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(36, 19);
            this.label68.TabIndex = 29;
            this.label68.Text = "rpm";
            // 
            // num_spd_rpm_cmd
            // 
            this.num_spd_rpm_cmd.Font = new System.Drawing.Font("Consolas", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.num_spd_rpm_cmd.Location = new System.Drawing.Point(110, 47);
            this.num_spd_rpm_cmd.Maximum = new decimal(new int[] {
            7200,
            0,
            0,
            0});
            this.num_spd_rpm_cmd.Name = "num_spd_rpm_cmd";
            this.num_spd_rpm_cmd.Size = new System.Drawing.Size(78, 32);
            this.num_spd_rpm_cmd.TabIndex = 28;
            this.num_spd_rpm_cmd.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.num_spd_rpm_cmd.Value = new decimal(new int[] {
            1200,
            0,
            0,
            0});
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI Symbol", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(6, 8);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(92, 17);
            this.label4.TabIndex = 1;
            this.label4.Text = "Speed Control";
            // 
            // Spd_Cmd_trackBar
            // 
            this.Spd_Cmd_trackBar.LargeChange = 100;
            this.Spd_Cmd_trackBar.Location = new System.Drawing.Point(19, 34);
            this.Spd_Cmd_trackBar.Maximum = 7200;
            this.Spd_Cmd_trackBar.Minimum = 600;
            this.Spd_Cmd_trackBar.Name = "Spd_Cmd_trackBar";
            this.Spd_Cmd_trackBar.Orientation = System.Windows.Forms.Orientation.Vertical;
            this.Spd_Cmd_trackBar.Size = new System.Drawing.Size(45, 113);
            this.Spd_Cmd_trackBar.SmallChange = 100;
            this.Spd_Cmd_trackBar.TabIndex = 27;
            this.Spd_Cmd_trackBar.TickFrequency = 10;
            this.Spd_Cmd_trackBar.Value = 1200;
            this.Spd_Cmd_trackBar.Scroll += new System.EventHandler(this.Spd_Cmd_trackBar_Scroll);
            // 
            // motor_spd_cmd_button
            // 
            this.motor_spd_cmd_button.Location = new System.Drawing.Point(90, 94);
            this.motor_spd_cmd_button.Name = "motor_spd_cmd_button";
            this.motor_spd_cmd_button.Size = new System.Drawing.Size(169, 44);
            this.motor_spd_cmd_button.TabIndex = 25;
            this.motor_spd_cmd_button.Text = "Set";
            this.motor_spd_cmd_button.UseVisualStyleBackColor = true;
            this.motor_spd_cmd_button.Click += new System.EventHandler(this.motor_spd_cmd_button_Click);
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label66.ForeColor = System.Drawing.Color.Maroon;
            this.label66.Location = new System.Drawing.Point(7, 9);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(48, 12);
            this.label66.TabIndex = 21;
            this.label66.Text = "Control";
            // 
            // panel7
            // 
            this.panel7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel7.Controls.Add(this.TB_OverCurrent);
            this.panel7.Controls.Add(this.TB_LosePhase);
            this.panel7.Controls.Add(this.TB_StartUpErr);
            this.panel7.Controls.Add(this.TB_ACVoltageErr);
            this.panel7.Controls.Add(this.TB_IPMFault);
            this.panel7.Controls.Add(this.TB_LoseSpeed);
            this.panel7.Controls.Add(this.TB_CurSensorErr);
            this.panel7.Controls.Add(this.TB_ACOverCurrent);
            this.panel7.Controls.Add(this.TB_DCVoltageErr);
            this.panel7.Controls.Add(this.label2);
            this.panel7.Location = new System.Drawing.Point(780, 96);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(288, 194);
            this.panel7.TabIndex = 35;
            // 
            // TB_OverCurrent
            // 
            this.TB_OverCurrent.BackColor = System.Drawing.Color.Silver;
            this.TB_OverCurrent.Cursor = System.Windows.Forms.Cursors.Default;
            this.TB_OverCurrent.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.TB_OverCurrent.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.TB_OverCurrent.Location = new System.Drawing.Point(17, 154);
            this.TB_OverCurrent.Name = "TB_OverCurrent";
            this.TB_OverCurrent.ReadOnly = true;
            this.TB_OverCurrent.Size = new System.Drawing.Size(123, 25);
            this.TB_OverCurrent.TabIndex = 26;
            this.TB_OverCurrent.Text = "Over Current";
            this.TB_OverCurrent.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // TB_LosePhase
            // 
            this.TB_LosePhase.BackColor = System.Drawing.Color.Silver;
            this.TB_LosePhase.Cursor = System.Windows.Forms.Cursors.Default;
            this.TB_LosePhase.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.TB_LosePhase.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.TB_LosePhase.Location = new System.Drawing.Point(146, 154);
            this.TB_LosePhase.Name = "TB_LosePhase";
            this.TB_LosePhase.ReadOnly = true;
            this.TB_LosePhase.Size = new System.Drawing.Size(123, 25);
            this.TB_LosePhase.TabIndex = 26;
            this.TB_LosePhase.Text = "Lose Phase";
            this.TB_LosePhase.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // TB_StartUpErr
            // 
            this.TB_StartUpErr.BackColor = System.Drawing.Color.Silver;
            this.TB_StartUpErr.Cursor = System.Windows.Forms.Cursors.Default;
            this.TB_StartUpErr.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.TB_StartUpErr.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.TB_StartUpErr.Location = new System.Drawing.Point(17, 124);
            this.TB_StartUpErr.Name = "TB_StartUpErr";
            this.TB_StartUpErr.ReadOnly = true;
            this.TB_StartUpErr.Size = new System.Drawing.Size(123, 25);
            this.TB_StartUpErr.TabIndex = 26;
            this.TB_StartUpErr.Text = "StartUp Error";
            this.TB_StartUpErr.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // TB_ACVoltageErr
            // 
            this.TB_ACVoltageErr.BackColor = System.Drawing.Color.Silver;
            this.TB_ACVoltageErr.Cursor = System.Windows.Forms.Cursors.Default;
            this.TB_ACVoltageErr.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.TB_ACVoltageErr.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.TB_ACVoltageErr.Location = new System.Drawing.Point(146, 31);
            this.TB_ACVoltageErr.Name = "TB_ACVoltageErr";
            this.TB_ACVoltageErr.ReadOnly = true;
            this.TB_ACVoltageErr.Size = new System.Drawing.Size(123, 25);
            this.TB_ACVoltageErr.TabIndex = 23;
            this.TB_ACVoltageErr.Text = "AC Voltage";
            this.TB_ACVoltageErr.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // TB_IPMFault
            // 
            this.TB_IPMFault.BackColor = System.Drawing.Color.Silver;
            this.TB_IPMFault.Cursor = System.Windows.Forms.Cursors.Default;
            this.TB_IPMFault.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.TB_IPMFault.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.TB_IPMFault.Location = new System.Drawing.Point(146, 62);
            this.TB_IPMFault.Name = "TB_IPMFault";
            this.TB_IPMFault.ReadOnly = true;
            this.TB_IPMFault.Size = new System.Drawing.Size(123, 25);
            this.TB_IPMFault.TabIndex = 25;
            this.TB_IPMFault.Text = "IPM Fault";
            this.TB_IPMFault.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // TB_CurSensorErr
            // 
            this.TB_CurSensorErr.BackColor = System.Drawing.Color.Silver;
            this.TB_CurSensorErr.Cursor = System.Windows.Forms.Cursors.Default;
            this.TB_CurSensorErr.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.TB_CurSensorErr.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.TB_CurSensorErr.Location = new System.Drawing.Point(17, 93);
            this.TB_CurSensorErr.Name = "TB_CurSensorErr";
            this.TB_CurSensorErr.ReadOnly = true;
            this.TB_CurSensorErr.Size = new System.Drawing.Size(123, 25);
            this.TB_CurSensorErr.TabIndex = 25;
            this.TB_CurSensorErr.Text = "CurSensorErr";
            this.TB_CurSensorErr.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // TB_ACOverCurrent
            // 
            this.TB_ACOverCurrent.BackColor = System.Drawing.Color.Silver;
            this.TB_ACOverCurrent.Cursor = System.Windows.Forms.Cursors.Default;
            this.TB_ACOverCurrent.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.TB_ACOverCurrent.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.TB_ACOverCurrent.Location = new System.Drawing.Point(17, 62);
            this.TB_ACOverCurrent.Name = "TB_ACOverCurrent";
            this.TB_ACOverCurrent.ReadOnly = true;
            this.TB_ACOverCurrent.Size = new System.Drawing.Size(123, 25);
            this.TB_ACOverCurrent.TabIndex = 25;
            this.TB_ACOverCurrent.Text = "AC Current";
            this.TB_ACOverCurrent.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // TB_DCVoltageErr
            // 
            this.TB_DCVoltageErr.BackColor = System.Drawing.Color.Crimson;
            this.TB_DCVoltageErr.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.TB_DCVoltageErr.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.TB_DCVoltageErr.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.TB_DCVoltageErr.Location = new System.Drawing.Point(17, 31);
            this.TB_DCVoltageErr.Name = "TB_DCVoltageErr";
            this.TB_DCVoltageErr.ReadOnly = true;
            this.TB_DCVoltageErr.Size = new System.Drawing.Size(123, 25);
            this.TB_DCVoltageErr.TabIndex = 22;
            this.TB_DCVoltageErr.Text = "DC Voltage";
            this.TB_DCVoltageErr.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label2.ForeColor = System.Drawing.Color.Maroon;
            this.label2.Location = new System.Drawing.Point(7, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(85, 12);
            this.label2.TabIndex = 21;
            this.label2.Text = "Error Message";
            // 
            // panel5
            // 
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel5.Controls.Add(this.TB_ParaSYNState);
            this.panel5.Controls.Add(this.TB_LinkState);
            this.panel5.Controls.Add(this.label1);
            this.panel5.Location = new System.Drawing.Point(780, 6);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(288, 84);
            this.panel5.TabIndex = 35;
            // 
            // TB_ParaSYNState
            // 
            this.TB_ParaSYNState.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.TB_ParaSYNState.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.TB_ParaSYNState.Font = new System.Drawing.Font("Consolas", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TB_ParaSYNState.ForeColor = System.Drawing.SystemColors.WindowText;
            this.TB_ParaSYNState.Location = new System.Drawing.Point(146, 35);
            this.TB_ParaSYNState.Name = "TB_ParaSYNState";
            this.TB_ParaSYNState.ReadOnly = true;
            this.TB_ParaSYNState.Size = new System.Drawing.Size(91, 22);
            this.TB_ParaSYNState.TabIndex = 36;
            this.TB_ParaSYNState.Text = "UNKNOW";
            this.TB_ParaSYNState.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // TB_LinkState
            // 
            this.TB_LinkState.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.TB_LinkState.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.TB_LinkState.Font = new System.Drawing.Font("Consolas", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TB_LinkState.ForeColor = System.Drawing.SystemColors.WindowText;
            this.TB_LinkState.Location = new System.Drawing.Point(17, 35);
            this.TB_LinkState.Name = "TB_LinkState";
            this.TB_LinkState.ReadOnly = true;
            this.TB_LinkState.Size = new System.Drawing.Size(91, 22);
            this.TB_LinkState.TabIndex = 35;
            this.TB_LinkState.Text = "UNKNOW";
            this.TB_LinkState.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label1.ForeColor = System.Drawing.Color.Maroon;
            this.label1.Location = new System.Drawing.Point(7, 8);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(106, 12);
            this.label1.TabIndex = 21;
            this.label1.Text = "Connection Status";
            // 
            // panel4
            // 
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel4.Controls.Add(this.TB_Power);
            this.panel4.Controls.Add(this.aGauge_Power);
            this.panel4.Location = new System.Drawing.Point(3, 314);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(325, 260);
            this.panel4.TabIndex = 33;
            // 
            // TB_Power
            // 
            this.TB_Power.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.TB_Power.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TB_Power.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.TB_Power.Font = new System.Drawing.Font("Consolas", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TB_Power.ForeColor = System.Drawing.SystemColors.ControlText;
            this.TB_Power.Location = new System.Drawing.Point(108, 207);
            this.TB_Power.Name = "TB_Power";
            this.TB_Power.ReadOnly = true;
            this.TB_Power.Size = new System.Drawing.Size(98, 32);
            this.TB_Power.TabIndex = 0;
            this.TB_Power.Text = "1200";
            this.TB_Power.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // aGauge_Power
            // 
            this.aGauge_Power.BaseArcColor = System.Drawing.Color.Gray;
            this.aGauge_Power.BaseArcRadius = 100;
            this.aGauge_Power.BaseArcStart = 135;
            this.aGauge_Power.BaseArcSweep = 270;
            this.aGauge_Power.BaseArcWidth = 2;
            this.aGauge_Power.Cap_Idx = ((byte)(1));
            this.aGauge_Power.CapColors = new System.Drawing.Color[] {
        System.Drawing.Color.Black,
        System.Drawing.Color.Black,
        System.Drawing.Color.Black,
        System.Drawing.Color.Black,
        System.Drawing.Color.Black};
            this.aGauge_Power.CapPosition = new System.Drawing.Point(115, 95);
            this.aGauge_Power.CapsPosition = new System.Drawing.Point[] {
        new System.Drawing.Point(10, 10),
        new System.Drawing.Point(115, 95),
        new System.Drawing.Point(10, 10),
        new System.Drawing.Point(10, 10),
        new System.Drawing.Point(10, 10)};
            this.aGauge_Power.CapsText = new string[] {
        "",
        "Power (W)",
        "",
        "",
        ""};
            this.aGauge_Power.CapText = "Power (W)";
            this.aGauge_Power.Center = new System.Drawing.Point(150, 150);
            this.aGauge_Power.Font = new System.Drawing.Font("Microsoft JhengHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.aGauge_Power.Location = new System.Drawing.Point(6, -1);
            this.aGauge_Power.MaxValue = 750F;
            this.aGauge_Power.MinValue = 0F;
            this.aGauge_Power.Name = "aGauge_Power";
            this.aGauge_Power.NeedleColor1 = AGaugeApp.AGauge.NeedleColorEnum.Gray;
            this.aGauge_Power.NeedleColor2 = System.Drawing.Color.DimGray;
            this.aGauge_Power.NeedleRadius = 80;
            this.aGauge_Power.NeedleType = 0;
            this.aGauge_Power.NeedleWidth = 2;
            this.aGauge_Power.Range_Idx = ((byte)(0));
            this.aGauge_Power.RangeColor = System.Drawing.Color.LightGreen;
            this.aGauge_Power.RangeEnabled = true;
            this.aGauge_Power.RangeEndValue = 500F;
            this.aGauge_Power.RangeInnerRadius = 85;
            this.aGauge_Power.RangeOuterRadius = 100;
            this.aGauge_Power.RangesColor = new System.Drawing.Color[] {
        System.Drawing.Color.LightGreen,
        System.Drawing.Color.OrangeRed,
        System.Drawing.SystemColors.Control,
        System.Drawing.SystemColors.Control,
        System.Drawing.SystemColors.Control};
            this.aGauge_Power.RangesEnabled = new bool[] {
        true,
        true,
        false,
        false,
        false};
            this.aGauge_Power.RangesEndValue = new float[] {
        500F,
        750F,
        0F,
        0F,
        0F};
            this.aGauge_Power.RangesInnerRadius = new int[] {
        85,
        85,
        70,
        70,
        70};
            this.aGauge_Power.RangesOuterRadius = new int[] {
        100,
        100,
        80,
        80,
        80};
            this.aGauge_Power.RangesStartValue = new float[] {
        0F,
        500F,
        0F,
        0F,
        0F};
            this.aGauge_Power.RangeStartValue = 0F;
            this.aGauge_Power.ScaleLinesInterColor = System.Drawing.Color.Black;
            this.aGauge_Power.ScaleLinesInterInnerRadius = 100;
            this.aGauge_Power.ScaleLinesInterOuterRadius = 85;
            this.aGauge_Power.ScaleLinesInterWidth = 1;
            this.aGauge_Power.ScaleLinesMajorColor = System.Drawing.Color.Black;
            this.aGauge_Power.ScaleLinesMajorInnerRadius = 80;
            this.aGauge_Power.ScaleLinesMajorOuterRadius = 100;
            this.aGauge_Power.ScaleLinesMajorStepValue = 50F;
            this.aGauge_Power.ScaleLinesMajorWidth = 2;
            this.aGauge_Power.ScaleLinesMinorColor = System.Drawing.Color.DimGray;
            this.aGauge_Power.ScaleLinesMinorInnerRadius = 100;
            this.aGauge_Power.ScaleLinesMinorNumOf = 2;
            this.aGauge_Power.ScaleLinesMinorOuterRadius = 90;
            this.aGauge_Power.ScaleLinesMinorWidth = 1;
            this.aGauge_Power.ScaleNumbersColor = System.Drawing.Color.Black;
            this.aGauge_Power.ScaleNumbersFormat = null;
            this.aGauge_Power.ScaleNumbersRadius = 125;
            this.aGauge_Power.ScaleNumbersRotation = 0;
            this.aGauge_Power.ScaleNumbersStartScaleLine = 1;
            this.aGauge_Power.ScaleNumbersStepScaleLines = 1;
            this.aGauge_Power.Size = new System.Drawing.Size(314, 256);
            this.aGauge_Power.TabIndex = 2;
            this.aGauge_Power.Text = "aGauge1";
            this.aGauge_Power.Value = 0F;
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.TB_RealSpeed);
            this.panel2.Controls.Add(this.aGauge_Speed);
            this.panel2.Location = new System.Drawing.Point(3, 51);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(325, 260);
            this.panel2.TabIndex = 33;
            // 
            // TB_RealSpeed
            // 
            this.TB_RealSpeed.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.TB_RealSpeed.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TB_RealSpeed.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.TB_RealSpeed.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TB_RealSpeed.ForeColor = System.Drawing.SystemColors.ControlText;
            this.TB_RealSpeed.Location = new System.Drawing.Point(108, 205);
            this.TB_RealSpeed.Name = "TB_RealSpeed";
            this.TB_RealSpeed.ReadOnly = true;
            this.TB_RealSpeed.Size = new System.Drawing.Size(98, 26);
            this.TB_RealSpeed.TabIndex = 0;
            this.TB_RealSpeed.Text = "1200 rpm";
            this.TB_RealSpeed.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // aGauge_Speed
            // 
            this.aGauge_Speed.BaseArcColor = System.Drawing.Color.Gray;
            this.aGauge_Speed.BaseArcRadius = 100;
            this.aGauge_Speed.BaseArcStart = 135;
            this.aGauge_Speed.BaseArcSweep = 270;
            this.aGauge_Speed.BaseArcWidth = 2;
            this.aGauge_Speed.Cap_Idx = ((byte)(1));
            this.aGauge_Speed.CapColors = new System.Drawing.Color[] {
        System.Drawing.Color.Black,
        System.Drawing.Color.Black,
        System.Drawing.Color.Black,
        System.Drawing.Color.Black,
        System.Drawing.Color.Black};
            this.aGauge_Speed.CapPosition = new System.Drawing.Point(110, 95);
            this.aGauge_Speed.CapsPosition = new System.Drawing.Point[] {
        new System.Drawing.Point(10, 10),
        new System.Drawing.Point(110, 95),
        new System.Drawing.Point(10, 10),
        new System.Drawing.Point(10, 10),
        new System.Drawing.Point(10, 10)};
            this.aGauge_Speed.CapsText = new string[] {
        "",
        "Speed (rpm)",
        "",
        "",
        ""};
            this.aGauge_Speed.CapText = "Speed (rpm)";
            this.aGauge_Speed.Center = new System.Drawing.Point(150, 150);
            this.aGauge_Speed.Font = new System.Drawing.Font("Microsoft JhengHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.aGauge_Speed.Location = new System.Drawing.Point(6, 1);
            this.aGauge_Speed.MaxValue = 5000F;
            this.aGauge_Speed.MinValue = 0F;
            this.aGauge_Speed.Name = "aGauge_Speed";
            this.aGauge_Speed.NeedleColor1 = AGaugeApp.AGauge.NeedleColorEnum.Gray;
            this.aGauge_Speed.NeedleColor2 = System.Drawing.Color.DimGray;
            this.aGauge_Speed.NeedleRadius = 80;
            this.aGauge_Speed.NeedleType = 0;
            this.aGauge_Speed.NeedleWidth = 2;
            this.aGauge_Speed.Range_Idx = ((byte)(2));
            this.aGauge_Speed.RangeColor = System.Drawing.Color.OrangeRed;
            this.aGauge_Speed.RangeEnabled = false;
            this.aGauge_Speed.RangeEndValue = 5000F;
            this.aGauge_Speed.RangeInnerRadius = 85;
            this.aGauge_Speed.RangeOuterRadius = 100;
            this.aGauge_Speed.RangesColor = new System.Drawing.Color[] {
        System.Drawing.Color.LightGreen,
        System.Drawing.Color.OrangeRed,
        System.Drawing.Color.OrangeRed,
        System.Drawing.SystemColors.Control,
        System.Drawing.SystemColors.Control};
            this.aGauge_Speed.RangesEnabled = new bool[] {
        true,
        true,
        false,
        false,
        false};
            this.aGauge_Speed.RangesEndValue = new float[] {
        4500F,
        5000F,
        5000F,
        0F,
        0F};
            this.aGauge_Speed.RangesInnerRadius = new int[] {
        85,
        85,
        85,
        70,
        70};
            this.aGauge_Speed.RangesOuterRadius = new int[] {
        100,
        100,
        100,
        80,
        80};
            this.aGauge_Speed.RangesStartValue = new float[] {
        0F,
        4500F,
        4500F,
        0F,
        0F};
            this.aGauge_Speed.RangeStartValue = 4500F;
            this.aGauge_Speed.ScaleLinesInterColor = System.Drawing.Color.Black;
            this.aGauge_Speed.ScaleLinesInterInnerRadius = 100;
            this.aGauge_Speed.ScaleLinesInterOuterRadius = 85;
            this.aGauge_Speed.ScaleLinesInterWidth = 1;
            this.aGauge_Speed.ScaleLinesMajorColor = System.Drawing.Color.Black;
            this.aGauge_Speed.ScaleLinesMajorInnerRadius = 80;
            this.aGauge_Speed.ScaleLinesMajorOuterRadius = 100;
            this.aGauge_Speed.ScaleLinesMajorStepValue = 500F;
            this.aGauge_Speed.ScaleLinesMajorWidth = 2;
            this.aGauge_Speed.ScaleLinesMinorColor = System.Drawing.Color.DimGray;
            this.aGauge_Speed.ScaleLinesMinorInnerRadius = 100;
            this.aGauge_Speed.ScaleLinesMinorNumOf = 5;
            this.aGauge_Speed.ScaleLinesMinorOuterRadius = 90;
            this.aGauge_Speed.ScaleLinesMinorWidth = 1;
            this.aGauge_Speed.ScaleNumbersColor = System.Drawing.Color.Black;
            this.aGauge_Speed.ScaleNumbersFormat = null;
            this.aGauge_Speed.ScaleNumbersRadius = 125;
            this.aGauge_Speed.ScaleNumbersRotation = 0;
            this.aGauge_Speed.ScaleNumbersStartScaleLine = 1;
            this.aGauge_Speed.ScaleNumbersStepScaleLines = 1;
            this.aGauge_Speed.Size = new System.Drawing.Size(314, 253);
            this.aGauge_Speed.TabIndex = 2;
            this.aGauge_Speed.Text = "aGauge1";
            this.aGauge_Speed.Value = 0F;
            // 
            // panel6
            // 
            this.panel6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel6.Controls.Add(this.TB_IqCurrent);
            this.panel6.Controls.Add(this.TB_ACCurrent);
            this.panel6.Controls.Add(this.aGauge_IqCurrent);
            this.panel6.Controls.Add(this.aGauge_ACCurrent);
            this.panel6.Location = new System.Drawing.Point(329, 314);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(445, 260);
            this.panel6.TabIndex = 32;
            // 
            // TB_IqCurrent
            // 
            this.TB_IqCurrent.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.TB_IqCurrent.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TB_IqCurrent.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.TB_IqCurrent.Font = new System.Drawing.Font("Consolas", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TB_IqCurrent.ForeColor = System.Drawing.SystemColors.ControlText;
            this.TB_IqCurrent.Location = new System.Drawing.Point(121, 211);
            this.TB_IqCurrent.Name = "TB_IqCurrent";
            this.TB_IqCurrent.ReadOnly = true;
            this.TB_IqCurrent.Size = new System.Drawing.Size(98, 32);
            this.TB_IqCurrent.TabIndex = 0;
            this.TB_IqCurrent.Text = "000 A";
            this.TB_IqCurrent.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // TB_ACCurrent
            // 
            this.TB_ACCurrent.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.TB_ACCurrent.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TB_ACCurrent.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.TB_ACCurrent.Font = new System.Drawing.Font("Consolas", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TB_ACCurrent.ForeColor = System.Drawing.SystemColors.ControlText;
            this.TB_ACCurrent.Location = new System.Drawing.Point(342, 207);
            this.TB_ACCurrent.Name = "TB_ACCurrent";
            this.TB_ACCurrent.ReadOnly = true;
            this.TB_ACCurrent.Size = new System.Drawing.Size(98, 32);
            this.TB_ACCurrent.TabIndex = 0;
            this.TB_ACCurrent.Text = "000 A";
            this.TB_ACCurrent.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // aGauge_IqCurrent
            // 
            this.aGauge_IqCurrent.BaseArcColor = System.Drawing.Color.Gray;
            this.aGauge_IqCurrent.BaseArcRadius = 100;
            this.aGauge_IqCurrent.BaseArcStart = 135;
            this.aGauge_IqCurrent.BaseArcSweep = 135;
            this.aGauge_IqCurrent.BaseArcWidth = 2;
            this.aGauge_IqCurrent.Cap_Idx = ((byte)(1));
            this.aGauge_IqCurrent.CapColors = new System.Drawing.Color[] {
        System.Drawing.Color.Black,
        System.Drawing.Color.Black,
        System.Drawing.Color.Black,
        System.Drawing.Color.Black,
        System.Drawing.Color.Black};
            this.aGauge_IqCurrent.CapPosition = new System.Drawing.Point(115, 95);
            this.aGauge_IqCurrent.CapsPosition = new System.Drawing.Point[] {
        new System.Drawing.Point(10, 10),
        new System.Drawing.Point(115, 95),
        new System.Drawing.Point(10, 10),
        new System.Drawing.Point(10, 10),
        new System.Drawing.Point(10, 10)};
            this.aGauge_IqCurrent.CapsText = new string[] {
        "",
        "Iq Current",
        "",
        "",
        ""};
            this.aGauge_IqCurrent.CapText = "Iq Current";
            this.aGauge_IqCurrent.Center = new System.Drawing.Point(150, 150);
            this.aGauge_IqCurrent.Font = new System.Drawing.Font("Microsoft JhengHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.aGauge_IqCurrent.Location = new System.Drawing.Point(6, 7);
            this.aGauge_IqCurrent.MaxValue = 10F;
            this.aGauge_IqCurrent.MinValue = 0F;
            this.aGauge_IqCurrent.Name = "aGauge_IqCurrent";
            this.aGauge_IqCurrent.NeedleColor1 = AGaugeApp.AGauge.NeedleColorEnum.Gray;
            this.aGauge_IqCurrent.NeedleColor2 = System.Drawing.Color.DimGray;
            this.aGauge_IqCurrent.NeedleRadius = 80;
            this.aGauge_IqCurrent.NeedleType = 0;
            this.aGauge_IqCurrent.NeedleWidth = 2;
            this.aGauge_IqCurrent.Range_Idx = ((byte)(2));
            this.aGauge_IqCurrent.RangeColor = System.Drawing.Color.OrangeRed;
            this.aGauge_IqCurrent.RangeEnabled = true;
            this.aGauge_IqCurrent.RangeEndValue = 10F;
            this.aGauge_IqCurrent.RangeInnerRadius = 85;
            this.aGauge_IqCurrent.RangeOuterRadius = 100;
            this.aGauge_IqCurrent.RangesColor = new System.Drawing.Color[] {
        System.Drawing.Color.LightGreen,
        System.Drawing.Color.Yellow,
        System.Drawing.Color.OrangeRed,
        System.Drawing.SystemColors.Control,
        System.Drawing.SystemColors.Control};
            this.aGauge_IqCurrent.RangesEnabled = new bool[] {
        true,
        true,
        true,
        false,
        false};
            this.aGauge_IqCurrent.RangesEndValue = new float[] {
        5F,
        8F,
        10F,
        0F,
        0F};
            this.aGauge_IqCurrent.RangesInnerRadius = new int[] {
        85,
        85,
        85,
        70,
        70};
            this.aGauge_IqCurrent.RangesOuterRadius = new int[] {
        100,
        100,
        100,
        80,
        80};
            this.aGauge_IqCurrent.RangesStartValue = new float[] {
        0F,
        5F,
        8F,
        0F,
        0F};
            this.aGauge_IqCurrent.RangeStartValue = 8F;
            this.aGauge_IqCurrent.ScaleLinesInterColor = System.Drawing.Color.Black;
            this.aGauge_IqCurrent.ScaleLinesInterInnerRadius = 100;
            this.aGauge_IqCurrent.ScaleLinesInterOuterRadius = 85;
            this.aGauge_IqCurrent.ScaleLinesInterWidth = 1;
            this.aGauge_IqCurrent.ScaleLinesMajorColor = System.Drawing.Color.Black;
            this.aGauge_IqCurrent.ScaleLinesMajorInnerRadius = 80;
            this.aGauge_IqCurrent.ScaleLinesMajorOuterRadius = 100;
            this.aGauge_IqCurrent.ScaleLinesMajorStepValue = 1F;
            this.aGauge_IqCurrent.ScaleLinesMajorWidth = 2;
            this.aGauge_IqCurrent.ScaleLinesMinorColor = System.Drawing.Color.DimGray;
            this.aGauge_IqCurrent.ScaleLinesMinorInnerRadius = 100;
            this.aGauge_IqCurrent.ScaleLinesMinorNumOf = 3;
            this.aGauge_IqCurrent.ScaleLinesMinorOuterRadius = 90;
            this.aGauge_IqCurrent.ScaleLinesMinorWidth = 1;
            this.aGauge_IqCurrent.ScaleNumbersColor = System.Drawing.Color.Black;
            this.aGauge_IqCurrent.ScaleNumbersFormat = null;
            this.aGauge_IqCurrent.ScaleNumbersRadius = 125;
            this.aGauge_IqCurrent.ScaleNumbersRotation = 0;
            this.aGauge_IqCurrent.ScaleNumbersStartScaleLine = 1;
            this.aGauge_IqCurrent.ScaleNumbersStepScaleLines = 1;
            this.aGauge_IqCurrent.Size = new System.Drawing.Size(214, 252);
            this.aGauge_IqCurrent.TabIndex = 3;
            this.aGauge_IqCurrent.Text = "aGauge2";
            this.aGauge_IqCurrent.Value = 0F;
            // 
            // aGauge_ACCurrent
            // 
            this.aGauge_ACCurrent.BaseArcColor = System.Drawing.Color.Gray;
            this.aGauge_ACCurrent.BaseArcRadius = 100;
            this.aGauge_ACCurrent.BaseArcStart = 135;
            this.aGauge_ACCurrent.BaseArcSweep = 135;
            this.aGauge_ACCurrent.BaseArcWidth = 2;
            this.aGauge_ACCurrent.Cap_Idx = ((byte)(1));
            this.aGauge_ACCurrent.CapColors = new System.Drawing.Color[] {
        System.Drawing.Color.Black,
        System.Drawing.Color.Black,
        System.Drawing.Color.Black,
        System.Drawing.Color.Black,
        System.Drawing.Color.Black};
            this.aGauge_ACCurrent.CapPosition = new System.Drawing.Point(115, 95);
            this.aGauge_ACCurrent.CapsPosition = new System.Drawing.Point[] {
        new System.Drawing.Point(10, 10),
        new System.Drawing.Point(115, 95),
        new System.Drawing.Point(10, 10),
        new System.Drawing.Point(10, 10),
        new System.Drawing.Point(10, 10)};
            this.aGauge_ACCurrent.CapsText = new string[] {
        "",
        "AC Current",
        "",
        "",
        ""};
            this.aGauge_ACCurrent.CapText = "AC Current";
            this.aGauge_ACCurrent.Center = new System.Drawing.Point(150, 150);
            this.aGauge_ACCurrent.Font = new System.Drawing.Font("Microsoft JhengHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.aGauge_ACCurrent.Location = new System.Drawing.Point(226, 3);
            this.aGauge_ACCurrent.MaxValue = 6F;
            this.aGauge_ACCurrent.MinValue = 0F;
            this.aGauge_ACCurrent.Name = "aGauge_ACCurrent";
            this.aGauge_ACCurrent.NeedleColor1 = AGaugeApp.AGauge.NeedleColorEnum.Gray;
            this.aGauge_ACCurrent.NeedleColor2 = System.Drawing.Color.DimGray;
            this.aGauge_ACCurrent.NeedleRadius = 80;
            this.aGauge_ACCurrent.NeedleType = 0;
            this.aGauge_ACCurrent.NeedleWidth = 2;
            this.aGauge_ACCurrent.Range_Idx = ((byte)(1));
            this.aGauge_ACCurrent.RangeColor = System.Drawing.Color.Yellow;
            this.aGauge_ACCurrent.RangeEnabled = true;
            this.aGauge_ACCurrent.RangeEndValue = 5F;
            this.aGauge_ACCurrent.RangeInnerRadius = 85;
            this.aGauge_ACCurrent.RangeOuterRadius = 100;
            this.aGauge_ACCurrent.RangesColor = new System.Drawing.Color[] {
        System.Drawing.Color.LightGreen,
        System.Drawing.Color.Yellow,
        System.Drawing.Color.OrangeRed,
        System.Drawing.SystemColors.Control,
        System.Drawing.SystemColors.Control};
            this.aGauge_ACCurrent.RangesEnabled = new bool[] {
        true,
        true,
        true,
        false,
        false};
            this.aGauge_ACCurrent.RangesEndValue = new float[] {
        5F,
        5F,
        6F,
        0F,
        0F};
            this.aGauge_ACCurrent.RangesInnerRadius = new int[] {
        85,
        85,
        85,
        70,
        70};
            this.aGauge_ACCurrent.RangesOuterRadius = new int[] {
        100,
        100,
        100,
        80,
        80};
            this.aGauge_ACCurrent.RangesStartValue = new float[] {
        0F,
        3F,
        5F,
        0F,
        0F};
            this.aGauge_ACCurrent.RangeStartValue = 3F;
            this.aGauge_ACCurrent.ScaleLinesInterColor = System.Drawing.Color.Black;
            this.aGauge_ACCurrent.ScaleLinesInterInnerRadius = 100;
            this.aGauge_ACCurrent.ScaleLinesInterOuterRadius = 85;
            this.aGauge_ACCurrent.ScaleLinesInterWidth = 1;
            this.aGauge_ACCurrent.ScaleLinesMajorColor = System.Drawing.Color.Black;
            this.aGauge_ACCurrent.ScaleLinesMajorInnerRadius = 80;
            this.aGauge_ACCurrent.ScaleLinesMajorOuterRadius = 100;
            this.aGauge_ACCurrent.ScaleLinesMajorStepValue = 1F;
            this.aGauge_ACCurrent.ScaleLinesMajorWidth = 2;
            this.aGauge_ACCurrent.ScaleLinesMinorColor = System.Drawing.Color.DimGray;
            this.aGauge_ACCurrent.ScaleLinesMinorInnerRadius = 100;
            this.aGauge_ACCurrent.ScaleLinesMinorNumOf = 3;
            this.aGauge_ACCurrent.ScaleLinesMinorOuterRadius = 90;
            this.aGauge_ACCurrent.ScaleLinesMinorWidth = 1;
            this.aGauge_ACCurrent.ScaleNumbersColor = System.Drawing.Color.Black;
            this.aGauge_ACCurrent.ScaleNumbersFormat = null;
            this.aGauge_ACCurrent.ScaleNumbersRadius = 125;
            this.aGauge_ACCurrent.ScaleNumbersRotation = 0;
            this.aGauge_ACCurrent.ScaleNumbersStartScaleLine = 1;
            this.aGauge_ACCurrent.ScaleNumbersStepScaleLines = 1;
            this.aGauge_ACCurrent.Size = new System.Drawing.Size(214, 252);
            this.aGauge_ACCurrent.TabIndex = 3;
            this.aGauge_ACCurrent.Text = "aGauge2";
            this.aGauge_ACCurrent.Value = 0F;
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.TB_DCVoltage);
            this.panel1.Controls.Add(this.TB_ACVoltage);
            this.panel1.Controls.Add(this.aGauge_DCVoltage);
            this.panel1.Controls.Add(this.aGauge_ACVoltage);
            this.panel1.Location = new System.Drawing.Point(329, 51);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(445, 260);
            this.panel1.TabIndex = 32;
            // 
            // TB_DCVoltage
            // 
            this.TB_DCVoltage.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.TB_DCVoltage.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TB_DCVoltage.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.TB_DCVoltage.Font = new System.Drawing.Font("Consolas", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TB_DCVoltage.ForeColor = System.Drawing.SystemColors.ControlText;
            this.TB_DCVoltage.Location = new System.Drawing.Point(122, 205);
            this.TB_DCVoltage.Name = "TB_DCVoltage";
            this.TB_DCVoltage.ReadOnly = true;
            this.TB_DCVoltage.Size = new System.Drawing.Size(98, 32);
            this.TB_DCVoltage.TabIndex = 0;
            this.TB_DCVoltage.Text = "000 V";
            this.TB_DCVoltage.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // TB_ACVoltage
            // 
            this.TB_ACVoltage.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.TB_ACVoltage.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TB_ACVoltage.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.TB_ACVoltage.Font = new System.Drawing.Font("Consolas", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TB_ACVoltage.ForeColor = System.Drawing.SystemColors.ControlText;
            this.TB_ACVoltage.Location = new System.Drawing.Point(342, 205);
            this.TB_ACVoltage.Name = "TB_ACVoltage";
            this.TB_ACVoltage.ReadOnly = true;
            this.TB_ACVoltage.Size = new System.Drawing.Size(98, 32);
            this.TB_ACVoltage.TabIndex = 0;
            this.TB_ACVoltage.Text = "000 V";
            this.TB_ACVoltage.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // aGauge_DCVoltage
            // 
            this.aGauge_DCVoltage.BaseArcColor = System.Drawing.Color.Gray;
            this.aGauge_DCVoltage.BaseArcRadius = 100;
            this.aGauge_DCVoltage.BaseArcStart = 135;
            this.aGauge_DCVoltage.BaseArcSweep = 135;
            this.aGauge_DCVoltage.BaseArcWidth = 2;
            this.aGauge_DCVoltage.Cap_Idx = ((byte)(1));
            this.aGauge_DCVoltage.CapColors = new System.Drawing.Color[] {
        System.Drawing.Color.Black,
        System.Drawing.Color.Black,
        System.Drawing.Color.Black,
        System.Drawing.Color.Black,
        System.Drawing.Color.Black};
            this.aGauge_DCVoltage.CapPosition = new System.Drawing.Point(115, 95);
            this.aGauge_DCVoltage.CapsPosition = new System.Drawing.Point[] {
        new System.Drawing.Point(10, 10),
        new System.Drawing.Point(115, 95),
        new System.Drawing.Point(10, 10),
        new System.Drawing.Point(10, 10),
        new System.Drawing.Point(10, 10)};
            this.aGauge_DCVoltage.CapsText = new string[] {
        "",
        "DC Voltage",
        "",
        "",
        ""};
            this.aGauge_DCVoltage.CapText = "DC Voltage";
            this.aGauge_DCVoltage.Center = new System.Drawing.Point(150, 150);
            this.aGauge_DCVoltage.Font = new System.Drawing.Font("Microsoft JhengHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.aGauge_DCVoltage.Location = new System.Drawing.Point(4, 2);
            this.aGauge_DCVoltage.MaxValue = 450F;
            this.aGauge_DCVoltage.MinValue = 0F;
            this.aGauge_DCVoltage.Name = "aGauge_DCVoltage";
            this.aGauge_DCVoltage.NeedleColor1 = AGaugeApp.AGauge.NeedleColorEnum.Gray;
            this.aGauge_DCVoltage.NeedleColor2 = System.Drawing.Color.DimGray;
            this.aGauge_DCVoltage.NeedleRadius = 80;
            this.aGauge_DCVoltage.NeedleType = 0;
            this.aGauge_DCVoltage.NeedleWidth = 2;
            this.aGauge_DCVoltage.Range_Idx = ((byte)(0));
            this.aGauge_DCVoltage.RangeColor = System.Drawing.Color.LightGreen;
            this.aGauge_DCVoltage.RangeEnabled = true;
            this.aGauge_DCVoltage.RangeEndValue = 400F;
            this.aGauge_DCVoltage.RangeInnerRadius = 85;
            this.aGauge_DCVoltage.RangeOuterRadius = 100;
            this.aGauge_DCVoltage.RangesColor = new System.Drawing.Color[] {
        System.Drawing.Color.LightGreen,
        System.Drawing.Color.OrangeRed,
        System.Drawing.SystemColors.Control,
        System.Drawing.SystemColors.Control,
        System.Drawing.SystemColors.Control};
            this.aGauge_DCVoltage.RangesEnabled = new bool[] {
        true,
        true,
        false,
        false,
        false};
            this.aGauge_DCVoltage.RangesEndValue = new float[] {
        400F,
        450F,
        0F,
        0F,
        0F};
            this.aGauge_DCVoltage.RangesInnerRadius = new int[] {
        85,
        85,
        70,
        70,
        70};
            this.aGauge_DCVoltage.RangesOuterRadius = new int[] {
        100,
        100,
        80,
        80,
        80};
            this.aGauge_DCVoltage.RangesStartValue = new float[] {
        0F,
        400F,
        0F,
        0F,
        0F};
            this.aGauge_DCVoltage.RangeStartValue = 0F;
            this.aGauge_DCVoltage.ScaleLinesInterColor = System.Drawing.Color.Black;
            this.aGauge_DCVoltage.ScaleLinesInterInnerRadius = 100;
            this.aGauge_DCVoltage.ScaleLinesInterOuterRadius = 85;
            this.aGauge_DCVoltage.ScaleLinesInterWidth = 1;
            this.aGauge_DCVoltage.ScaleLinesMajorColor = System.Drawing.Color.Black;
            this.aGauge_DCVoltage.ScaleLinesMajorInnerRadius = 80;
            this.aGauge_DCVoltage.ScaleLinesMajorOuterRadius = 100;
            this.aGauge_DCVoltage.ScaleLinesMajorStepValue = 50F;
            this.aGauge_DCVoltage.ScaleLinesMajorWidth = 2;
            this.aGauge_DCVoltage.ScaleLinesMinorColor = System.Drawing.Color.DimGray;
            this.aGauge_DCVoltage.ScaleLinesMinorInnerRadius = 100;
            this.aGauge_DCVoltage.ScaleLinesMinorNumOf = 5;
            this.aGauge_DCVoltage.ScaleLinesMinorOuterRadius = 90;
            this.aGauge_DCVoltage.ScaleLinesMinorWidth = 1;
            this.aGauge_DCVoltage.ScaleNumbersColor = System.Drawing.Color.Black;
            this.aGauge_DCVoltage.ScaleNumbersFormat = null;
            this.aGauge_DCVoltage.ScaleNumbersRadius = 125;
            this.aGauge_DCVoltage.ScaleNumbersRotation = 0;
            this.aGauge_DCVoltage.ScaleNumbersStartScaleLine = 1;
            this.aGauge_DCVoltage.ScaleNumbersStepScaleLines = 1;
            this.aGauge_DCVoltage.Size = new System.Drawing.Size(214, 252);
            this.aGauge_DCVoltage.TabIndex = 3;
            this.aGauge_DCVoltage.Text = "aGauge2";
            this.aGauge_DCVoltage.Value = 0F;
            // 
            // aGauge_ACVoltage
            // 
            this.aGauge_ACVoltage.BaseArcColor = System.Drawing.Color.Gray;
            this.aGauge_ACVoltage.BaseArcRadius = 100;
            this.aGauge_ACVoltage.BaseArcStart = 135;
            this.aGauge_ACVoltage.BaseArcSweep = 135;
            this.aGauge_ACVoltage.BaseArcWidth = 2;
            this.aGauge_ACVoltage.Cap_Idx = ((byte)(1));
            this.aGauge_ACVoltage.CapColors = new System.Drawing.Color[] {
        System.Drawing.Color.Black,
        System.Drawing.Color.Black,
        System.Drawing.Color.Black,
        System.Drawing.Color.Black,
        System.Drawing.Color.Black};
            this.aGauge_ACVoltage.CapPosition = new System.Drawing.Point(115, 95);
            this.aGauge_ACVoltage.CapsPosition = new System.Drawing.Point[] {
        new System.Drawing.Point(10, 10),
        new System.Drawing.Point(115, 95),
        new System.Drawing.Point(10, 10),
        new System.Drawing.Point(10, 10),
        new System.Drawing.Point(10, 10)};
            this.aGauge_ACVoltage.CapsText = new string[] {
        "",
        "AC Voltage",
        "",
        "",
        ""};
            this.aGauge_ACVoltage.CapText = "AC Voltage";
            this.aGauge_ACVoltage.Center = new System.Drawing.Point(150, 150);
            this.aGauge_ACVoltage.Font = new System.Drawing.Font("Microsoft JhengHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.aGauge_ACVoltage.Location = new System.Drawing.Point(226, 1);
            this.aGauge_ACVoltage.MaxValue = 280F;
            this.aGauge_ACVoltage.MinValue = 0F;
            this.aGauge_ACVoltage.Name = "aGauge_ACVoltage";
            this.aGauge_ACVoltage.NeedleColor1 = AGaugeApp.AGauge.NeedleColorEnum.Gray;
            this.aGauge_ACVoltage.NeedleColor2 = System.Drawing.Color.DimGray;
            this.aGauge_ACVoltage.NeedleRadius = 80;
            this.aGauge_ACVoltage.NeedleType = 0;
            this.aGauge_ACVoltage.NeedleWidth = 2;
            this.aGauge_ACVoltage.Range_Idx = ((byte)(2));
            this.aGauge_ACVoltage.RangeColor = System.Drawing.Color.OrangeRed;
            this.aGauge_ACVoltage.RangeEnabled = false;
            this.aGauge_ACVoltage.RangeEndValue = 280F;
            this.aGauge_ACVoltage.RangeInnerRadius = 85;
            this.aGauge_ACVoltage.RangeOuterRadius = 100;
            this.aGauge_ACVoltage.RangesColor = new System.Drawing.Color[] {
        System.Drawing.Color.LightGreen,
        System.Drawing.Color.OrangeRed,
        System.Drawing.Color.OrangeRed,
        System.Drawing.SystemColors.Control,
        System.Drawing.SystemColors.Control};
            this.aGauge_ACVoltage.RangesEnabled = new bool[] {
        true,
        true,
        false,
        false,
        false};
            this.aGauge_ACVoltage.RangesEndValue = new float[] {
        240F,
        280F,
        280F,
        0F,
        0F};
            this.aGauge_ACVoltage.RangesInnerRadius = new int[] {
        85,
        85,
        85,
        70,
        70};
            this.aGauge_ACVoltage.RangesOuterRadius = new int[] {
        100,
        100,
        100,
        80,
        80};
            this.aGauge_ACVoltage.RangesStartValue = new float[] {
        0F,
        240F,
        260F,
        0F,
        0F};
            this.aGauge_ACVoltage.RangeStartValue = 260F;
            this.aGauge_ACVoltage.ScaleLinesInterColor = System.Drawing.Color.Black;
            this.aGauge_ACVoltage.ScaleLinesInterInnerRadius = 100;
            this.aGauge_ACVoltage.ScaleLinesInterOuterRadius = 85;
            this.aGauge_ACVoltage.ScaleLinesInterWidth = 1;
            this.aGauge_ACVoltage.ScaleLinesMajorColor = System.Drawing.Color.Black;
            this.aGauge_ACVoltage.ScaleLinesMajorInnerRadius = 80;
            this.aGauge_ACVoltage.ScaleLinesMajorOuterRadius = 100;
            this.aGauge_ACVoltage.ScaleLinesMajorStepValue = 40F;
            this.aGauge_ACVoltage.ScaleLinesMajorWidth = 2;
            this.aGauge_ACVoltage.ScaleLinesMinorColor = System.Drawing.Color.DimGray;
            this.aGauge_ACVoltage.ScaleLinesMinorInnerRadius = 100;
            this.aGauge_ACVoltage.ScaleLinesMinorNumOf = 5;
            this.aGauge_ACVoltage.ScaleLinesMinorOuterRadius = 90;
            this.aGauge_ACVoltage.ScaleLinesMinorWidth = 1;
            this.aGauge_ACVoltage.ScaleNumbersColor = System.Drawing.Color.Black;
            this.aGauge_ACVoltage.ScaleNumbersFormat = null;
            this.aGauge_ACVoltage.ScaleNumbersRadius = 125;
            this.aGauge_ACVoltage.ScaleNumbersRotation = 0;
            this.aGauge_ACVoltage.ScaleNumbersStartScaleLine = 1;
            this.aGauge_ACVoltage.ScaleNumbersStepScaleLines = 1;
            this.aGauge_ACVoltage.Size = new System.Drawing.Size(214, 252);
            this.aGauge_ACVoltage.TabIndex = 3;
            this.aGauge_ACVoltage.Text = "aGauge2";
            this.aGauge_ACVoltage.Value = 0F;
            // 
            // TB_LoseSpeed
            // 
            this.TB_LoseSpeed.BackColor = System.Drawing.Color.Silver;
            this.TB_LoseSpeed.Cursor = System.Windows.Forms.Cursors.Default;
            this.TB_LoseSpeed.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.TB_LoseSpeed.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.TB_LoseSpeed.Location = new System.Drawing.Point(146, 123);
            this.TB_LoseSpeed.Name = "TB_LoseSpeed";
            this.TB_LoseSpeed.ReadOnly = true;
            this.TB_LoseSpeed.Size = new System.Drawing.Size(123, 25);
            this.TB_LoseSpeed.TabIndex = 25;
            this.TB_LoseSpeed.Text = "Lose Speed";
            this.TB_LoseSpeed.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // MonitorUI_Lite
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.panel3);
            this.Name = "MonitorUI_Lite";
            this.Size = new System.Drawing.Size(1080, 590);
            this.panel3.ResumeLayout(false);
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.panel11.ResumeLayout(false);
            this.panel11.PerformLayout();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.num_spd_rpm_cmd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Spd_Cmd_trackBar)).EndInit();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox TB_SetSpeed;
        private AGaugeApp.AGauge aGauge_Speed;
        private System.Windows.Forms.Panel panel1;
        private AGaugeApp.AGauge aGauge_ACVoltage;
        private System.Windows.Forms.TextBox TB_ACVoltage;
        private System.Windows.Forms.TextBox TB_DCVoltage;
        private AGaugeApp.AGauge aGauge_DCVoltage;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.TextBox TB_RealSpeed;
        private System.Windows.Forms.TextBox TB_IqCurrent;
        private AGaugeApp.AGauge aGauge_IqCurrent;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.TextBox TB_ACCurrent;
        private AGaugeApp.AGauge aGauge_ACCurrent;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Button motor_start_button;
        private System.Windows.Forms.Button motor_stop_button;
        private System.Windows.Forms.TrackBar Spd_Cmd_trackBar;
        private System.Windows.Forms.Button motor_spd_cmd_button;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.TextBox TB_Power;
        private AGaugeApp.AGauge aGauge_Power;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox TB_LinkState;
        private System.Windows.Forms.TextBox TB_ParaSYNState;
        private System.Windows.Forms.TextBox TB_DCVoltageErr;
        private System.Windows.Forms.TextBox TB_ACVoltageErr;
        private System.Windows.Forms.TextBox TB_ACOverCurrent;
        private System.Windows.Forms.TextBox TB_StartUpErr;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.TextBox TB_IPMFault;
        private System.Windows.Forms.TextBox TB_OverCurrent;
        private System.Windows.Forms.TextBox TB_LosePhase;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox TB_MotorState;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox TB_SystemState;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox TB_CurSensorErr;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.NumericUpDown num_spd_rpm_cmd;
        private System.Windows.Forms.TextBox TB_LoseSpeed;

    }
}

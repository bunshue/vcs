﻿namespace CS6257_Monitor
{
    partial class CommandUI
    {
        /// <summary> 
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 元件設計工具產生的程式碼

        /// <summary> 
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器
        /// 修改這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox24 = new System.Windows.Forms.GroupBox();
            this.CMD_listView = new System.Windows.Forms.ListView();
            this.Command = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Clear_sendrichtext = new System.Windows.Forms.Button();
            this.Send = new System.Windows.Forms.Button();
            this.Send_richText = new System.Windows.Forms.RichTextBox();
            this.button8 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.Save_CMD_File_button = new System.Windows.Forms.Button();
            this.Open_CMD_File_button = new System.Windows.Forms.Button();
            this.groupBox24.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox24
            // 
            this.groupBox24.Controls.Add(this.CMD_listView);
            this.groupBox24.Controls.Add(this.Clear_sendrichtext);
            this.groupBox24.Controls.Add(this.Send);
            this.groupBox24.Controls.Add(this.Send_richText);
            this.groupBox24.Controls.Add(this.button8);
            this.groupBox24.Controls.Add(this.button7);
            this.groupBox24.Controls.Add(this.Save_CMD_File_button);
            this.groupBox24.Controls.Add(this.Open_CMD_File_button);
            this.groupBox24.Location = new System.Drawing.Point(3, 3);
            this.groupBox24.Name = "groupBox24";
            this.groupBox24.Size = new System.Drawing.Size(334, 573);
            this.groupBox24.TabIndex = 7;
            this.groupBox24.TabStop = false;
            this.groupBox24.Text = "命令列";
            // 
            // CMD_listView
            // 
            this.CMD_listView.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.Command});
            this.CMD_listView.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.CMD_listView.Location = new System.Drawing.Point(6, 59);
            this.CMD_listView.Name = "CMD_listView";
            this.CMD_listView.Size = new System.Drawing.Size(318, 424);
            this.CMD_listView.TabIndex = 4;
            this.CMD_listView.UseCompatibleStateImageBehavior = false;
            this.CMD_listView.View = System.Windows.Forms.View.Details;
            this.CMD_listView.DoubleClick += new System.EventHandler(this.CMD_listView_DoubleClick);
            // 
            // Command
            // 
            this.Command.Text = "";
            this.Command.Width = 250;
            // 
            // Clear_sendrichtext
            // 
            this.Clear_sendrichtext.Location = new System.Drawing.Point(229, 530);
            this.Clear_sendrichtext.Name = "Clear_sendrichtext";
            this.Clear_sendrichtext.Size = new System.Drawing.Size(75, 23);
            this.Clear_sendrichtext.TabIndex = 3;
            this.Clear_sendrichtext.Text = "清除";
            this.Clear_sendrichtext.UseVisualStyleBackColor = true;
            this.Clear_sendrichtext.Click += new System.EventHandler(this.Clear_sendrichtext_Click);
            // 
            // Send
            // 
            this.Send.Location = new System.Drawing.Point(229, 493);
            this.Send.Name = "Send";
            this.Send.Size = new System.Drawing.Size(75, 23);
            this.Send.TabIndex = 3;
            this.Send.Text = "發送";
            this.Send.UseVisualStyleBackColor = true;
            this.Send.Click += new System.EventHandler(this.Send_Click);
            // 
            // Send_richText
            // 
            this.Send_richText.Location = new System.Drawing.Point(6, 489);
            this.Send_richText.Name = "Send_richText";
            this.Send_richText.ReadOnly = true;
            this.Send_richText.Size = new System.Drawing.Size(202, 73);
            this.Send_richText.TabIndex = 2;
            this.Send_richText.Text = "";
            // 
            // button8
            // 
            this.button8.Enabled = false;
            this.button8.Location = new System.Drawing.Point(249, 30);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(75, 23);
            this.button8.TabIndex = 1;
            this.button8.Text = "移除";
            this.button8.UseVisualStyleBackColor = true;
            // 
            // button7
            // 
            this.button7.Enabled = false;
            this.button7.Location = new System.Drawing.Point(168, 30);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(75, 23);
            this.button7.TabIndex = 1;
            this.button7.Text = "新增";
            this.button7.UseVisualStyleBackColor = true;
            // 
            // Save_CMD_File_button
            // 
            this.Save_CMD_File_button.Enabled = false;
            this.Save_CMD_File_button.Location = new System.Drawing.Point(87, 30);
            this.Save_CMD_File_button.Name = "Save_CMD_File_button";
            this.Save_CMD_File_button.Size = new System.Drawing.Size(75, 23);
            this.Save_CMD_File_button.TabIndex = 1;
            this.Save_CMD_File_button.Text = "儲存";
            this.Save_CMD_File_button.UseVisualStyleBackColor = true;
            // 
            // Open_CMD_File_button
            // 
            this.Open_CMD_File_button.Location = new System.Drawing.Point(6, 30);
            this.Open_CMD_File_button.Name = "Open_CMD_File_button";
            this.Open_CMD_File_button.Size = new System.Drawing.Size(75, 23);
            this.Open_CMD_File_button.TabIndex = 1;
            this.Open_CMD_File_button.Text = "開啟";
            this.Open_CMD_File_button.UseVisualStyleBackColor = true;
            this.Open_CMD_File_button.Click += new System.EventHandler(this.Open_CMD_File_button_Click);
            // 
            // CommandUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.groupBox24);
            this.Name = "CommandUI";
            this.Size = new System.Drawing.Size(342, 583);
            this.groupBox24.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox24;
        private System.Windows.Forms.ListView CMD_listView;
        private System.Windows.Forms.ColumnHeader Command;
        private System.Windows.Forms.Button Clear_sendrichtext;
        private System.Windows.Forms.Button Send;
        private System.Windows.Forms.RichTextBox Send_richText;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button Save_CMD_File_button;
        private System.Windows.Forms.Button Open_CMD_File_button;
    }
}

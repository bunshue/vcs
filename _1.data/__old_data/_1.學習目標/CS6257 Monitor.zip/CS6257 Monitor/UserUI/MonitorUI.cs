﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CS6257_Monitor
{
    public partial class MonitorUI : UserControl
    {
        public struct DATA
        {
            public int SetSpeed;            // 設定轉速 (rpm)
            public int RealSpeed;           // 實際轉速 (rpm)
            public int ACVoltage;           // AC 電壓
            public double ACCurrent;        // AC 電流
            public int DCVoltage;           // DC 電壓
            public double IqCurrent;        // 轉矩電流
            public double Power;            // 入電功率

            public int IPMTemp;             // IPM 溫度
            public int MotorState;          // 馬達狀態
            public int DCFanSpeed;          // DC風扇轉速
            public int PFCState;            // PFC 狀態
            public int FourWayValveState;   // 四通閥狀態
            public int OpMode;              // 操作模式
            public int FirmwareVersion;     // 韌體版本
        }

        public DATA Data;

        public MonitorUI()
        {
            InitializeComponent();
        }

        /// <summary>
        /// 更新 Monitor 控制項
        /// </summary>
        /// <param name="bc"></param>
        public void UpdateMonitorUI(ResolvePack.MONITOR_DATA Monitor_Data)
        {
            this.SetSpeed = Monitor_Data.MotorRunInfo.SetSpeed_rpm;
            this.RealSpeed = Monitor_Data.MotorRunInfo.RealSpeed_rpm;
            this.ACVoltage = Monitor_Data.MotorRunInfo.ACVoltage;
            this.ACCurrent = Monitor_Data.MotorRunInfo.ACCurrent;
            this.DCVoltage = Monitor_Data.MotorRunInfo.DCVoltage;
            this.IqCurrent = Monitor_Data.MotorRunInfo.IqCurrent;
            this.Power = Monitor_Data.MotorRunInfo.Power;
            this.IPMTemp = Monitor_Data.MotorRunInfo.IPMTemp;
            this.DCFanSpeed = Monitor_Data.MotorRunInfo.DCFanSpeed;
            this.PFCState = Monitor_Data.MotorRunInfo.PFCState;
            this.FourWayValveState = Monitor_Data.MotorRunInfo.FourWayValveState;
            this.OpMode = Monitor_Data.MotorRunInfo.OpMode;

            FirmwareVersion(this.TB_FirmwareVer, Monitor_Data);

            UpdateSetSpeed();
            UpdateRealSpeed();
            UpdateACVoltageCurrent();
            UpdateDCVoltage();
            UpdateIqCurrent();
            UpdatePower();

            UpdateIPMTemp();
            UpdateMotorState();
            UpdateDCFanSpeed();
            UpdatePFCState();
            UpdateFourWayValveState();
            UpdateOpMode();
        }

        /// <summary>
        /// 更新設定轉速
        /// </summary>
        private void UpdateSetSpeed()
        {
            int temp = Data.SetSpeed;
            if (temp < 100) temp = 0;   // JM
            this.TB_SetSpeed.Text = temp.ToString() + " rpm";
        }
        
        /// <summary>
        /// 更新實際轉速
        /// </summary>
        private void UpdateRealSpeed()
        {
            int temp = Data.RealSpeed;
            if (temp < 100) temp = 0;   // JM
            this.TB_RealSpeed.Text = temp.ToString() + " rpm";
        }

        /// <summary>
        /// 更新 AC 電壓、電流
        /// </summary>
        private void UpdateACVoltageCurrent()
        {
            this.TB_ACVoltage.Text = Data.ACVoltage.ToString() + " V";
            this.TB_ACCurrent.Text = Data.ACCurrent.ToString("#0.0") + " A";
        }


        /// <summary>
        /// 更新 DC 電壓
        /// </summary>
        private void UpdateDCVoltage()
        {
            this.TB_DCVoltage.Text = Data.DCVoltage.ToString() + " V";
        }

        /// <summary>
        /// 更新轉矩電流
        /// </summary>
        private void UpdateIqCurrent()
        {
            this.TB_IqCurrent.Text = Data.IqCurrent.ToString("#0.0") + " A";
        }

        /// <summary>
        /// 更新入電功率
        /// </summary>
        private void UpdatePower()
        {
            this.TB_Power.Text = Data.Power.ToString("#0.0") + " W";
        }

        /// <summary>
        /// 更新IPM溫度
        /// </summary>
        private void UpdateIPMTemp()
        {
            this.TB_IPMTemp.Text = Data.IPMTemp.ToString() + " ℃";
        }

        /// <summary>
        /// 更新馬達狀態
        /// </summary>
        private void UpdateMotorState()
        {
            string str = string.Empty;
            Color color;
            int temp = 0;
            if (Data.SetSpeed > 60)
                temp = 1;
            else
                temp = 0;        
            switch(temp)
            {
                case 0:
                    color = Color.OrangeRed;
                    str = "STOP";
                    break;
                case 1:
                    color = Color.MediumSpringGreen;
                    str = "RUNNING";
                    break;
                default:
                    color = Color.Red;
                    str = "ERROR";
                    break;
            }
            this.TB_MotorState.Text = str;
            this.TB_MotorState.ForeColor = color;
        }

        /// <summary>
        /// 更新DC風扇轉速
        /// </summary>
        private void UpdateDCFanSpeed()
        {
            this.TB_DCFanSpeed.Text = Data.DCFanSpeed.ToString() + " rpm";
        }

        /// <summary>
        /// 更新PFC狀態
        /// </summary>
        private void UpdatePFCState()
        {
            int temp = Data.PFCState;
            Color color;
            string str = string.Empty;
            switch(temp)
            {
                case 0:
                    color = Color.OrangeRed;
                    str = "OFF";
                    break;
                case 1:
                    color = Color.MediumSpringGreen;
                    str = "ON";
                    break;
                default:
                    color = Color.Red;
                    str = "ERROR";
                    break;
            }
            this.TB_PFCState.Text = str;
            this.TB_PFCState.ForeColor = color;
        }

        /// <summary>
        /// 更新四通閥狀態
        /// </summary>
        private void UpdateFourWayValveState()
        {
            int temp = Data.FourWayValveState;
            string str = string.Empty;
            switch(temp)
            {
                case 0:
                    str = "OFF";
                    break;
                case 1:
                    str = "ON";
                    break;
                default:
                    str = "ERROR";
                    break;
            }
            this.TB_FourWayValveState.Text = str;
        }

        /// <summary>
        /// 更新操作模式
        /// </summary>
        private void UpdateOpMode()
        {
            int temp = Data.OpMode;
            Color color;
            string str = string.Empty;
            switch(temp)
            {
                case 0:
                    str = "Auto";
                    color = Color.MediumSpringGreen;
                    break;
                case 1:
                    str = "Manual";
                    color = Color.Yellow;
                    break;
                default:
                    str = "ERROR";
                    color = Color.Red;
                    break;
            }
            this.TB_OpMode.Text = str;
            this.TB_OpMode.ForeColor = color;
        }

        #region 取得數值 Get Value

        /// <summary>
        /// 設定轉速
        /// </summary>
        public int SetSpeed
        {
            set { Data.SetSpeed = value; }
        }

        /// <summary>
        /// 實際轉速
        /// </summary>
        public int RealSpeed
        {
            set { Data.RealSpeed = value; }
        }

        /// <summary>
        /// AC 電壓
        /// </summary>
        public int ACVoltage
        {
            set { Data.ACVoltage = value; }
        }

        /// <summary>
        /// AC 電流
        /// </summary>
        public double ACCurrent
        {
            set { Data.ACCurrent = value; }
        }

        /// <summary>
        /// DC 電壓
        /// </summary>
        public int DCVoltage
        {
            set { Data.DCVoltage = value; }
        }

        /// <summary>
        /// 轉矩電流
        /// </summary>
        public double IqCurrent
        {
            set { Data.IqCurrent = value; }
        }

        /// <summary>
        /// 入電功率
        /// </summary>
        public double Power
        {
            set { Data.Power = value; }
        }

        /// <summary>
        /// IPM溫度
        /// </summary>
        public int IPMTemp
        {
            set { Data.IPMTemp = value; }
        }

        /// <summary>
        /// 馬達狀態
        /// </summary>
        public int MotorState
        {
            set { Data.MotorState = value; }
        }

        /// <summary>
        /// DC風扇轉速
        /// </summary>
        public int DCFanSpeed
        {
            set { Data.DCFanSpeed = value; }
        }

        /// <summary>
        /// PFC 狀態
        /// </summary>
        public int PFCState
        {
            set { Data.PFCState = value; }
        }

        /// <summary>
        /// 四通閥狀態
        /// </summary>
        public int FourWayValveState
        {
            set { Data.FourWayValveState = value; }
        }

        /// <summary>
        /// 操作模式
        /// </summary>
        public int OpMode
        {
            set { Data.OpMode = value; }
        }

        #endregion

        /// <summary>
        /// 顯示韌體版本
        /// </summary>
        /// <param name="textbox"></param>
        public void FirmwareVersion(TextBox textbox, ResolvePack.MONITOR_DATA Monitor_Data)
        {
            string str = string.Empty;
            int value1 = Monitor_Data.Version;
            int value2 = Monitor_Data.SerialNum;

            str = "V" + value1.ToString() + "." + value2.ToString("000");

            textbox.Text = str;
        }
    }
}

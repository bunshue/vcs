﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

namespace CS6257_Monitor
{
    public partial class ControlUI : UserControl
    {
        public ControlUI()
        {
            InitializeComponent();
        }

        private TransControl bc;

        /// <summary>
        /// 初始化設定
        /// </summary>
        /// <param name="bc_ptr"></param>
        public void Init_ControlUI(TransControl bc_ptr)
        {
            bc = bc_ptr;
        }

        /// <summary>
        /// 手動模式設定按鈕
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Manual_Mode_button_Click(object sender, EventArgs e)
        {
            bc.Send_Manual_Auto_Mode_Cmd(true);
        }

        /// <summary>
        /// 自動模式設定按鈕
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Auto_Mode_button_Click(object sender, EventArgs e)
        {
            bc.Send_Manual_Auto_Mode_Cmd(false);
        }

        /// <summary>
        /// 電動機啟動按鈕
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void motor_start_button_Click(object sender, EventArgs e)
        {
            bc.Send_Start_Motor_Cmd();

            #region 測試用

            Thread.Sleep(500);

            byte[] b = new byte[10];
            b[0] = 0xAA;
            b[1] = 0x62;
            b[2] = 0x00;
            b[3] = 0x00;
            b[4] = 0x00;
            b[5] = 0x00;
            b[6] = 0x00;
            b[7] = 0x00;
            b[8] = 0x00;
            b[9] = 0x00;
            bc.SendCmdByte(b);

            #endregion
        }

        /// <summary>
        /// 電動機停止按鈕
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void motor_stop_button_Click(object sender, EventArgs e)
        {
            bc.Send_Stop_Motor_Cmd();
        }

        /// <summary>
        /// 轉速設定按鈕
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void motor_spd_cmd_button_Click(object sender, EventArgs e)
        {
            Int32 spd_rps_cmd = (Int32)this.num_spd_rps_cmd.Value;
            if (spd_rps_cmd < 20)
            {
                this.Spd_Cmd_trackBar.Value = 20;
            }
            else if (spd_rps_cmd > 120)
            {
                this.Spd_Cmd_trackBar.Value = 120;
            }
            else
            {
                this.Spd_Cmd_trackBar.Value = spd_rps_cmd;
            }

            bc.Send_Motor_Spd_Cmd(spd_rps_cmd);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void num_spd_rps_cmd_ValueChanged(object sender, EventArgs e)
        {
            int value = (int)this.num_spd_rps_cmd.Value;
            this.num_spd_rpm_cmd.Text = (this.num_spd_rps_cmd.Value * 60).ToString();

            if (value > this.Spd_Cmd_trackBar.Minimum && value < this.Spd_Cmd_trackBar.Maximum)
                this.Spd_Cmd_trackBar.Value = value;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Spd_Cmd_trackBar_Scroll(object sender, EventArgs e)
        {
            this.num_spd_rps_cmd.Value = this.Spd_Cmd_trackBar.Value;
            this.num_spd_rpm_cmd.Text = (this.num_spd_rps_cmd.Value * 60).ToString();
        }

        /// <summary>
        /// 室外風機轉速設定按鈕
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void outfan_spd_cmd_button_Click(object sender, EventArgs e)
        {
            Int32 spd_cmd = (Int32)this.num_outfan_spd_cmd.Value;
            if (this.Ra_DutyCtrl.Checked == true)
            {
                bc.Send_OutFan_Spd_Cmd(spd_cmd, 1);
            }
            else if (this.Ra_SpdCtrl.Checked == true)
            {
                bc.Send_OutFan_Spd_Cmd(spd_cmd, 2);
            }
        }

        /// <summary>
        /// 室外風機強風設定按鈕
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Strong_wind_button_Click(object sender, EventArgs e)
        {
            Int32 spd_cmd = 0;
            if (this.Ra_DutyCtrl.Checked == true)
            {
                this.num_outfan_spd_cmd.Value = 9800;
                spd_cmd = (Int32)this.num_outfan_spd_cmd.Value;
                bc.Send_OutFan_Spd_Cmd(spd_cmd, 1);
            }
            else if (this.Ra_SpdCtrl.Checked == true)
            {
                this.num_outfan_spd_cmd.Value = 850;
                spd_cmd = (Int32)this.num_outfan_spd_cmd.Value;
                bc.Send_OutFan_Spd_Cmd(spd_cmd, 2);
            }
            this.num_outfan_spd_cmd.Value = spd_cmd;
        }

        /// <summary>
        /// 室外風機中風設定按鈕
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Medium_wind_button_Click(object sender, EventArgs e)
        {
            Int32 spd_cmd = 0;
            if (this.Ra_DutyCtrl.Checked == true)
            {
                this.num_outfan_spd_cmd.Value = 9000;
                spd_cmd = (Int32)this.num_outfan_spd_cmd.Value;
                bc.Send_OutFan_Spd_Cmd(spd_cmd, 1);
            }
            else if (this.Ra_SpdCtrl.Checked == true)
            {
                this.num_outfan_spd_cmd.Value = 750;
                spd_cmd = (Int32)this.num_outfan_spd_cmd.Value;
                bc.Send_OutFan_Spd_Cmd(spd_cmd, 2);
            }
            this.num_outfan_spd_cmd.Value = spd_cmd;
        }

        /// <summary>
        /// 室外風機弱風設定按鈕
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void weak_wind_button_Click(object sender, EventArgs e)
        {
            Int32 spd_cmd = 0;
            if (this.Ra_DutyCtrl.Checked == true)
            {
                this.num_outfan_spd_cmd.Value = 8000;
                spd_cmd = (Int32)this.num_outfan_spd_cmd.Value;
                bc.Send_OutFan_Spd_Cmd(spd_cmd, 1);
            }
            else if (this.Ra_SpdCtrl.Checked == true)
            {
                this.num_outfan_spd_cmd.Value = 650;
                spd_cmd = (Int32)this.num_outfan_spd_cmd.Value;
                bc.Send_OutFan_Spd_Cmd(spd_cmd, 2);
            }
            this.num_outfan_spd_cmd.Value = spd_cmd;
        }

        /// <summary>
        /// 室外風機停止按鈕
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void stop_outfan_button_Click(object sender, EventArgs e)
        {
            Int32 spd_cmd = 0;
            if (this.Ra_DutyCtrl.Checked == true)
            {
                this.num_outfan_spd_cmd.Value = 0;
                spd_cmd = (Int32)this.num_outfan_spd_cmd.Value;
                bc.Send_OutFan_Spd_Cmd(spd_cmd, 1);
            }
            else if (this.Ra_SpdCtrl.Checked == true)
            {
                this.num_outfan_spd_cmd.Value = 0;
                spd_cmd = (Int32)this.num_outfan_spd_cmd.Value;
                bc.Send_OutFan_Spd_Cmd(spd_cmd, 2);
            }
            this.num_outfan_spd_cmd.Value = spd_cmd;
        }

        /// <summary>
        /// 功能開啟按鈕
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Enable_checkBox_CheckedChanged(object sender, EventArgs e)
        {
            if (this.Enable_checkBox.Checked)
            {
                this.PFC_ON_button.Enabled = true;
                this.PFC_OFF_button.Enabled = true;
                this.Four_Way_Valve_ON_button.Enabled = true;
                this.Four_Way_Valve_OFF_button.Enabled = true;
            }
            else
            {
                this.PFC_ON_button.Enabled = false;
                this.PFC_OFF_button.Enabled = false;
                this.Four_Way_Valve_ON_button.Enabled = false;
                this.Four_Way_Valve_OFF_button.Enabled = false;
            }
        }

        /// <summary>
        /// PFC 開啟按鈕
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void PFC_ON_button_Click(object sender, EventArgs e)
        {
            bc.Send_PFC_ON_OFF_Cmd(true);
        }

        /// <summary>
        /// PFC 關閉按鈕
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void PFC_OFF_button_Click(object sender, EventArgs e)
        {
            bc.Send_PFC_ON_OFF_Cmd(false);
        }

        /// <summary>
        /// 四通閥開啟按鈕
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Four_Way_Valve_ON_button_Click(object sender, EventArgs e)
        {
            bc.Send_FourWayValve_ON_OFF_Cmd(true);
        }

        /// <summary>
        /// 四通閥關閉按鈕
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Four_Way_Valve_OFF_button_Click(object sender, EventArgs e)
        {
            bc.Send_FourWayValve_ON_OFF_Cmd(false);
        }

    }
}

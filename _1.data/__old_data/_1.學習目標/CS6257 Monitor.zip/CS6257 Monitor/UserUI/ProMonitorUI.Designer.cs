﻿namespace CS6257_Monitor
{
    partial class ProMonitorUI
    {
        /// <summary> 
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 元件設計工具產生的程式碼

        /// <summary> 
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器
        /// 修改這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.TB_SetTemp = new System.Windows.Forms.TextBox();
            this.TB_CoilMidTemp = new System.Windows.Forms.TextBox();
            this.TB_roomTemp = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.TB_OutTemp = new System.Windows.Forms.TextBox();
            this.label34 = new System.Windows.Forms.Label();
            this.TB_outCoilMid = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.TB_suctionTemp = new System.Windows.Forms.TextBox();
            this.label49 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.TB_IPMTemp = new System.Windows.Forms.TextBox();
            this.TB_disCharTemp = new System.Windows.Forms.TextBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.TB_InFan = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.TB_inFault = new System.Windows.Forms.TextBox();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.TB_OutFanSpd = new System.Windows.Forms.TextBox();
            this.label44 = new System.Windows.Forms.Label();
            this.TB_OutFanCnt = new System.Windows.Forms.TextBox();
            this.TB_OutFanState = new System.Windows.Forms.TextBox();
            this.TB_MotoStateCnt = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.TB_MotoState = new System.Windows.Forms.TextBox();
            this.groupBox23 = new System.Windows.Forms.GroupBox();
            this.TB_proresetTime = new System.Windows.Forms.TextBox();
            this.TB_proFreqGrade = new System.Windows.Forms.TextBox();
            this.TB_proNum = new System.Windows.Forms.TextBox();
            this.label65 = new System.Windows.Forms.Label();
            this.label64 = new System.Windows.Forms.Label();
            this.label63 = new System.Windows.Forms.Label();
            this.groupBox19 = new System.Windows.Forms.GroupBox();
            this.TB_offTime = new System.Windows.Forms.TextBox();
            this.TB_dlyTime = new System.Windows.Forms.TextBox();
            this.TB_occuredCnt = new System.Windows.Forms.TextBox();
            this.TB_compProCnt = new System.Windows.Forms.TextBox();
            this.TB_starCnt = new System.Windows.Forms.TextBox();
            this.TB_IPMCnt = new System.Windows.Forms.TextBox();
            this.TB_FaultCode = new System.Windows.Forms.TextBox();
            this.TB_FaultState = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label61 = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.label83 = new System.Windows.Forms.Label();
            this.label82 = new System.Windows.Forms.Label();
            this.label81 = new System.Windows.Forms.Label();
            this.label80 = new System.Windows.Forms.Label();
            this.label79 = new System.Windows.Forms.Label();
            this.groupBox18 = new System.Windows.Forms.GroupBox();
            this.label55 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.TB_inFanFreGMax = new System.Windows.Forms.TextBox();
            this.TB_oTempFreGMax = new System.Windows.Forms.TextBox();
            this.label59 = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.TB_freqGradeMax = new System.Windows.Forms.TextBox();
            this.label75 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.TB_fgCtrlTimer = new System.Windows.Forms.TextBox();
            this.TB_DTGREAD_State = new System.Windows.Forms.TextBox();
            this.TB_tempGradeOld = new System.Windows.Forms.TextBox();
            this.TB_tempGradeNow = new System.Windows.Forms.TextBox();
            this.label52 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.TB_rsDeltaTemp = new System.Windows.Forms.TextBox();
            this.TB_freqGradeOut = new System.Windows.Forms.TextBox();
            this.groupBox16 = new System.Windows.Forms.GroupBox();
            this.TB_AVG_Is = new System.Windows.Forms.TextBox();
            this.TB_AVG_qCurrent = new System.Windows.Forms.TextBox();
            this.TB_AVG_Vs = new System.Windows.Forms.TextBox();
            this.TB_AVG_dCurrent = new System.Windows.Forms.TextBox();
            this.TB_AVG_qVolt = new System.Windows.Forms.TextBox();
            this.TB_AVG_dVolt = new System.Windows.Forms.TextBox();
            this.label77 = new System.Windows.Forms.Label();
            this.label76 = new System.Windows.Forms.Label();
            this.label72 = new System.Windows.Forms.Label();
            this.label78 = new System.Windows.Forms.Label();
            this.label71 = new System.Windows.Forms.Label();
            this.label70 = new System.Windows.Forms.Label();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.TB_defortTimeTemp = new System.Windows.Forms.TextBox();
            this.TB_defortTimeCnt = new System.Windows.Forms.TextBox();
            this.label50 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.TB_defrostState = new System.Windows.Forms.TextBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.TB_mainrelayState = new System.Windows.Forms.TextBox();
            this.TB_forWayValveState = new System.Windows.Forms.TextBox();
            this.TB_pfcState = new System.Windows.Forms.TextBox();
            this.TB_POWER = new System.Windows.Forms.TextBox();
            this.TB_VAC = new System.Windows.Forms.TextBox();
            this.label48 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label62 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.TB_IAC = new System.Windows.Forms.TextBox();
            this.TB_VBUS = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.TB_FactFreq = new System.Windows.Forms.TextBox();
            this.TB_TargetFreq = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.TB_freqState = new System.Windows.Forms.TextBox();
            this.TB_sysState = new System.Windows.Forms.TextBox();
            this.label42 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.TB_runState = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.TB_TestCmd = new System.Windows.Forms.TextBox();
            this.TB_baseMod = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.TB_SubRunMod = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.TB_RunMod = new System.Windows.Forms.TextBox();
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.panel8 = new System.Windows.Forms.Panel();
            this.label53 = new System.Windows.Forms.Label();
            this.LB_PfcLowVolt = new System.Windows.Forms.Label();
            this.LB_PfcHiVolt = new System.Windows.Forms.Label();
            this.LB_Pfcovercurrent = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label51 = new System.Windows.Forms.Label();
            this.LB_ICompOver = new System.Windows.Forms.Label();
            this.LB_LoseSpeed = new System.Windows.Forms.Label();
            this.LB_PhaseErr = new System.Windows.Forms.Label();
            this.LB_ZeroSpeed = new System.Windows.Forms.Label();
            this.LB_PhaseLose = new System.Windows.Forms.Label();
            this.LB_StartUpErr = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.LB_IPMSensorErr = new System.Windows.Forms.Label();
            this.LB_outfan_err = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.LB_disCharTempFault = new System.Windows.Forms.Label();
            this.LB_LowVoltFault = new System.Windows.Forms.Label();
            this.LB_IPMFault = new System.Windows.Forms.Label();
            this.LB_suctionFault = new System.Windows.Forms.Label();
            this.LB_HighVoltFault = new System.Windows.Forms.Label();
            this.LB_OutTempFault = new System.Windows.Forms.Label();
            this.LB_CurrentSenFault = new System.Windows.Forms.Label();
            this.LB_CoilMidTempFault = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.LB_communicate_err = new System.Windows.Forms.Label();
            this.label60 = new System.Windows.Forms.Label();
            this.LB_indoorTempFault = new System.Windows.Forms.Label();
            this.LB_inCoilFault = new System.Windows.Forms.Label();
            this.LB_inFanFault = new System.Windows.Forms.Label();
            this.LB_inCoilHiTempFault = new System.Windows.Forms.Label();
            this.LB_inCoilLoTempFault = new System.Windows.Forms.Label();
            this.groupBox20 = new System.Windows.Forms.GroupBox();
            this.panel10 = new System.Windows.Forms.Panel();
            this.LB_outErr = new System.Windows.Forms.Label();
            this.LB_inCoilHiTemp = new System.Windows.Forms.Label();
            this.LB_inCoilLowTemp = new System.Windows.Forms.Label();
            this.LB_outroomHiTemp = new System.Windows.Forms.Label();
            this.LB_disPressure = new System.Windows.Forms.Label();
            this.LB_outCoilHiTemp = new System.Windows.Forms.Label();
            this.panel9 = new System.Windows.Forms.Panel();
            this.LB_suctionTempPro = new System.Windows.Forms.Label();
            this.LB_comTopTempPro = new System.Windows.Forms.Label();
            this.LB_dishcharTempPro = new System.Windows.Forms.Label();
            this.LB_iacOver = new System.Windows.Forms.Label();
            this.LB_ipmHiTemp = new System.Windows.Forms.Label();
            this.groupBox17 = new System.Windows.Forms.GroupBox();
            this.LB_infanlimit = new System.Windows.Forms.Label();
            this.LB_dischargeHi = new System.Windows.Forms.Label();
            this.LB_outCoilHi = new System.Windows.Forms.Label();
            this.LB_inCoilHi = new System.Windows.Forms.Label();
            this.LB_inCoilLow = new System.Windows.Forms.Label();
            this.LB_CompOver = new System.Windows.Forms.Label();
            this.LB_VdcLimit = new System.Windows.Forms.Label();
            this.LB_IacLimit = new System.Windows.Forms.Label();
            this.groupBox26 = new System.Windows.Forms.GroupBox();
            this.TB_OpMode = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label86 = new System.Windows.Forms.Label();
            this.TB_sysTime = new System.Windows.Forms.TextBox();
            this.groupBox3.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox12.SuspendLayout();
            this.groupBox23.SuspendLayout();
            this.groupBox19.SuspendLayout();
            this.groupBox18.SuspendLayout();
            this.groupBox16.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox13.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.groupBox20.SuspendLayout();
            this.panel10.SuspendLayout();
            this.panel9.SuspendLayout();
            this.groupBox17.SuspendLayout();
            this.groupBox26.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label10);
            this.groupBox3.Controls.Add(this.label8);
            this.groupBox3.Controls.Add(this.TB_SetTemp);
            this.groupBox3.Controls.Add(this.TB_CoilMidTemp);
            this.groupBox3.Controls.Add(this.TB_roomTemp);
            this.groupBox3.Controls.Add(this.label7);
            this.groupBox3.Controls.Add(this.label35);
            this.groupBox3.Controls.Add(this.TB_OutTemp);
            this.groupBox3.Controls.Add(this.label34);
            this.groupBox3.Controls.Add(this.TB_outCoilMid);
            this.groupBox3.Controls.Add(this.label3);
            this.groupBox3.Controls.Add(this.TB_suctionTemp);
            this.groupBox3.Controls.Add(this.label49);
            this.groupBox3.Controls.Add(this.label33);
            this.groupBox3.Controls.Add(this.TB_IPMTemp);
            this.groupBox3.Controls.Add(this.TB_disCharTemp);
            this.groupBox3.Location = new System.Drawing.Point(3, 3);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(222, 292);
            this.groupBox3.TabIndex = 18;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "溫度";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(12, 28);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(77, 12);
            this.label10.TabIndex = 3;
            this.label10.Text = "室內環境溫度";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(12, 94);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(77, 12);
            this.label8.TabIndex = 17;
            this.label8.Text = "室內銅管溫度";
            // 
            // TB_SetTemp
            // 
            this.TB_SetTemp.Location = new System.Drawing.Point(106, 58);
            this.TB_SetTemp.Name = "TB_SetTemp";
            this.TB_SetTemp.Size = new System.Drawing.Size(100, 22);
            this.TB_SetTemp.TabIndex = 13;
            this.TB_SetTemp.Text = "TB_SetTemp";
            // 
            // TB_CoilMidTemp
            // 
            this.TB_CoilMidTemp.Location = new System.Drawing.Point(106, 91);
            this.TB_CoilMidTemp.Name = "TB_CoilMidTemp";
            this.TB_CoilMidTemp.Size = new System.Drawing.Size(100, 22);
            this.TB_CoilMidTemp.TabIndex = 14;
            this.TB_CoilMidTemp.Text = "TB_CoilMidTemp";
            // 
            // TB_roomTemp
            // 
            this.TB_roomTemp.Location = new System.Drawing.Point(106, 25);
            this.TB_roomTemp.Name = "TB_roomTemp";
            this.TB_roomTemp.Size = new System.Drawing.Size(100, 22);
            this.TB_roomTemp.TabIndex = 5;
            this.TB_roomTemp.Text = "TB_roomTemp";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(12, 61);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(65, 12);
            this.label7.TabIndex = 10;
            this.label7.Text = "室內設定溫";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(12, 127);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(77, 12);
            this.label35.TabIndex = 0;
            this.label35.Text = "室外環境溫度";
            // 
            // TB_OutTemp
            // 
            this.TB_OutTemp.Location = new System.Drawing.Point(106, 124);
            this.TB_OutTemp.Name = "TB_OutTemp";
            this.TB_OutTemp.Size = new System.Drawing.Size(100, 22);
            this.TB_OutTemp.TabIndex = 1;
            this.TB_OutTemp.Text = "TB_OutTemp";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(12, 161);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(77, 12);
            this.label34.TabIndex = 2;
            this.label34.Text = "室外銅管溫度";
            // 
            // TB_outCoilMid
            // 
            this.TB_outCoilMid.Location = new System.Drawing.Point(106, 157);
            this.TB_outCoilMid.Name = "TB_outCoilMid";
            this.TB_outCoilMid.Size = new System.Drawing.Size(100, 22);
            this.TB_outCoilMid.TabIndex = 3;
            this.TB_outCoilMid.Text = "TB_outCoilMid";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 193);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(89, 12);
            this.label3.TabIndex = 4;
            this.label3.Text = "壓縮機入口溫度";
            // 
            // TB_suctionTemp
            // 
            this.TB_suctionTemp.Location = new System.Drawing.Point(106, 190);
            this.TB_suctionTemp.Name = "TB_suctionTemp";
            this.TB_suctionTemp.Size = new System.Drawing.Size(100, 22);
            this.TB_suctionTemp.TabIndex = 9;
            this.TB_suctionTemp.Text = "TB_suctionTemp";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(12, 259);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(52, 12);
            this.label49.TabIndex = 4;
            this.label49.Text = "IPM 溫度";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(12, 226);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(89, 12);
            this.label33.TabIndex = 4;
            this.label33.Text = "壓縮機出口溫度";
            // 
            // TB_IPMTemp
            // 
            this.TB_IPMTemp.Location = new System.Drawing.Point(106, 256);
            this.TB_IPMTemp.Name = "TB_IPMTemp";
            this.TB_IPMTemp.Size = new System.Drawing.Size(100, 22);
            this.TB_IPMTemp.TabIndex = 9;
            this.TB_IPMTemp.Text = "TB_IPMTemp";
            // 
            // TB_disCharTemp
            // 
            this.TB_disCharTemp.Location = new System.Drawing.Point(106, 223);
            this.TB_disCharTemp.Name = "TB_disCharTemp";
            this.TB_disCharTemp.Size = new System.Drawing.Size(100, 22);
            this.TB_disCharTemp.TabIndex = 9;
            this.TB_disCharTemp.Text = "TB_disCharTemp";
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.label4);
            this.groupBox6.Controls.Add(this.TB_InFan);
            this.groupBox6.Controls.Add(this.label5);
            this.groupBox6.Controls.Add(this.TB_inFault);
            this.groupBox6.Location = new System.Drawing.Point(3, 296);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(222, 90);
            this.groupBox6.TabIndex = 21;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "室內機";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 28);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(77, 12);
            this.label4.TabIndex = 6;
            this.label4.Text = "室內風扇轉速";
            // 
            // TB_InFan
            // 
            this.TB_InFan.Location = new System.Drawing.Point(106, 25);
            this.TB_InFan.Name = "TB_InFan";
            this.TB_InFan.Size = new System.Drawing.Size(100, 22);
            this.TB_InFan.TabIndex = 7;
            this.TB_InFan.Text = "TB_InFan";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 61);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(74, 12);
            this.label5.TabIndex = 8;
            this.label5.Text = "錯誤 / 限頻碼";
            // 
            // TB_inFault
            // 
            this.TB_inFault.Location = new System.Drawing.Point(106, 58);
            this.TB_inFault.Name = "TB_inFault";
            this.TB_inFault.Size = new System.Drawing.Size(100, 22);
            this.TB_inFault.TabIndex = 11;
            this.TB_inFault.Text = "TB_inFault";
            // 
            // groupBox12
            // 
            this.groupBox12.Controls.Add(this.TB_OutFanSpd);
            this.groupBox12.Controls.Add(this.label44);
            this.groupBox12.Controls.Add(this.TB_OutFanCnt);
            this.groupBox12.Controls.Add(this.TB_OutFanState);
            this.groupBox12.Controls.Add(this.TB_MotoStateCnt);
            this.groupBox12.Controls.Add(this.label1);
            this.groupBox12.Controls.Add(this.label47);
            this.groupBox12.Controls.Add(this.label46);
            this.groupBox12.Controls.Add(this.label43);
            this.groupBox12.Controls.Add(this.TB_MotoState);
            this.groupBox12.Location = new System.Drawing.Point(3, 392);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Size = new System.Drawing.Size(222, 189);
            this.groupBox12.TabIndex = 23;
            this.groupBox12.TabStop = false;
            this.groupBox12.Text = "電機狀態";
            // 
            // TB_OutFanSpd
            // 
            this.TB_OutFanSpd.Location = new System.Drawing.Point(106, 124);
            this.TB_OutFanSpd.Name = "TB_OutFanSpd";
            this.TB_OutFanSpd.Size = new System.Drawing.Size(100, 22);
            this.TB_OutFanSpd.TabIndex = 2;
            this.TB_OutFanSpd.Text = "TB_OutFanSpd";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(12, 61);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(89, 12);
            this.label44.TabIndex = 1;
            this.label44.Text = "壓縮機狀態計數";
            // 
            // TB_OutFanCnt
            // 
            this.TB_OutFanCnt.Location = new System.Drawing.Point(106, 157);
            this.TB_OutFanCnt.Name = "TB_OutFanCnt";
            this.TB_OutFanCnt.Size = new System.Drawing.Size(100, 22);
            this.TB_OutFanCnt.TabIndex = 0;
            this.TB_OutFanCnt.Text = "TB_OutFanCnt";
            // 
            // TB_OutFanState
            // 
            this.TB_OutFanState.Location = new System.Drawing.Point(106, 91);
            this.TB_OutFanState.Name = "TB_OutFanState";
            this.TB_OutFanState.Size = new System.Drawing.Size(100, 22);
            this.TB_OutFanState.TabIndex = 0;
            this.TB_OutFanState.Text = "TB_OutFanState";
            // 
            // TB_MotoStateCnt
            // 
            this.TB_MotoStateCnt.Location = new System.Drawing.Point(106, 58);
            this.TB_MotoStateCnt.Name = "TB_MotoStateCnt";
            this.TB_MotoStateCnt.Size = new System.Drawing.Size(100, 22);
            this.TB_MotoStateCnt.TabIndex = 0;
            this.TB_MotoStateCnt.Text = "TB_MotoStateCnt";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 128);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(65, 12);
            this.label1.TabIndex = 1;
            this.label1.Text = "外風機轉速";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(12, 161);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(89, 12);
            this.label47.TabIndex = 1;
            this.label47.Text = "外風機狀態計數";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(12, 93);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(65, 12);
            this.label46.TabIndex = 1;
            this.label46.Text = "外風機狀態";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(12, 27);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(65, 12);
            this.label43.TabIndex = 1;
            this.label43.Text = "壓縮機狀態";
            // 
            // TB_MotoState
            // 
            this.TB_MotoState.Location = new System.Drawing.Point(106, 25);
            this.TB_MotoState.Name = "TB_MotoState";
            this.TB_MotoState.Size = new System.Drawing.Size(100, 22);
            this.TB_MotoState.TabIndex = 0;
            this.TB_MotoState.Text = "TB_MotoState";
            // 
            // groupBox23
            // 
            this.groupBox23.Controls.Add(this.TB_proresetTime);
            this.groupBox23.Controls.Add(this.TB_proFreqGrade);
            this.groupBox23.Controls.Add(this.TB_proNum);
            this.groupBox23.Controls.Add(this.label65);
            this.groupBox23.Controls.Add(this.label64);
            this.groupBox23.Controls.Add(this.label63);
            this.groupBox23.Location = new System.Drawing.Point(460, 447);
            this.groupBox23.Name = "groupBox23";
            this.groupBox23.Size = new System.Drawing.Size(222, 134);
            this.groupBox23.TabIndex = 36;
            this.groupBox23.TabStop = false;
            this.groupBox23.Text = "降頻保護";
            // 
            // TB_proresetTime
            // 
            this.TB_proresetTime.Location = new System.Drawing.Point(106, 95);
            this.TB_proresetTime.Name = "TB_proresetTime";
            this.TB_proresetTime.Size = new System.Drawing.Size(100, 22);
            this.TB_proresetTime.TabIndex = 38;
            this.TB_proresetTime.Text = "TB_proresetTime";
            // 
            // TB_proFreqGrade
            // 
            this.TB_proFreqGrade.Location = new System.Drawing.Point(106, 60);
            this.TB_proFreqGrade.Name = "TB_proFreqGrade";
            this.TB_proFreqGrade.Size = new System.Drawing.Size(100, 22);
            this.TB_proFreqGrade.TabIndex = 38;
            this.TB_proFreqGrade.Text = "TB_proFreqGrade";
            // 
            // TB_proNum
            // 
            this.TB_proNum.Location = new System.Drawing.Point(106, 25);
            this.TB_proNum.Name = "TB_proNum";
            this.TB_proNum.Size = new System.Drawing.Size(100, 22);
            this.TB_proNum.TabIndex = 38;
            this.TB_proNum.Text = "TB_proNum";
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Location = new System.Drawing.Point(13, 98);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(53, 12);
            this.label65.TabIndex = 35;
            this.label65.Text = "恢復時間";
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Location = new System.Drawing.Point(12, 63);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(53, 12);
            this.label64.TabIndex = 35;
            this.label64.Text = "頻率檔位";
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Location = new System.Drawing.Point(12, 28);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(77, 12);
            this.label63.TabIndex = 35;
            this.label63.Text = "降頻保護代碼";
            // 
            // groupBox19
            // 
            this.groupBox19.Controls.Add(this.TB_offTime);
            this.groupBox19.Controls.Add(this.TB_dlyTime);
            this.groupBox19.Controls.Add(this.TB_occuredCnt);
            this.groupBox19.Controls.Add(this.TB_compProCnt);
            this.groupBox19.Controls.Add(this.TB_starCnt);
            this.groupBox19.Controls.Add(this.TB_IPMCnt);
            this.groupBox19.Controls.Add(this.TB_FaultCode);
            this.groupBox19.Controls.Add(this.TB_FaultState);
            this.groupBox19.Controls.Add(this.label9);
            this.groupBox19.Controls.Add(this.label61);
            this.groupBox19.Controls.Add(this.label56);
            this.groupBox19.Controls.Add(this.label83);
            this.groupBox19.Controls.Add(this.label82);
            this.groupBox19.Controls.Add(this.label81);
            this.groupBox19.Controls.Add(this.label80);
            this.groupBox19.Controls.Add(this.label79);
            this.groupBox19.Location = new System.Drawing.Point(460, 136);
            this.groupBox19.Name = "groupBox19";
            this.groupBox19.Size = new System.Drawing.Size(222, 302);
            this.groupBox19.TabIndex = 35;
            this.groupBox19.TabStop = false;
            this.groupBox19.Text = "故障保護狀態";
            // 
            // TB_offTime
            // 
            this.TB_offTime.Location = new System.Drawing.Point(106, 270);
            this.TB_offTime.Name = "TB_offTime";
            this.TB_offTime.Size = new System.Drawing.Size(100, 22);
            this.TB_offTime.TabIndex = 38;
            this.TB_offTime.Text = "TB_offTime";
            // 
            // TB_dlyTime
            // 
            this.TB_dlyTime.Location = new System.Drawing.Point(106, 235);
            this.TB_dlyTime.Name = "TB_dlyTime";
            this.TB_dlyTime.Size = new System.Drawing.Size(100, 22);
            this.TB_dlyTime.TabIndex = 38;
            this.TB_dlyTime.Text = "TB_dlyTime";
            // 
            // TB_occuredCnt
            // 
            this.TB_occuredCnt.Location = new System.Drawing.Point(105, 200);
            this.TB_occuredCnt.Name = "TB_occuredCnt";
            this.TB_occuredCnt.Size = new System.Drawing.Size(100, 22);
            this.TB_occuredCnt.TabIndex = 38;
            this.TB_occuredCnt.Text = "TB_occuredCnt";
            // 
            // TB_compProCnt
            // 
            this.TB_compProCnt.Location = new System.Drawing.Point(106, 165);
            this.TB_compProCnt.Name = "TB_compProCnt";
            this.TB_compProCnt.Size = new System.Drawing.Size(100, 22);
            this.TB_compProCnt.TabIndex = 38;
            this.TB_compProCnt.Text = "TB_compProCnt";
            // 
            // TB_starCnt
            // 
            this.TB_starCnt.Location = new System.Drawing.Point(106, 130);
            this.TB_starCnt.Name = "TB_starCnt";
            this.TB_starCnt.Size = new System.Drawing.Size(100, 22);
            this.TB_starCnt.TabIndex = 38;
            this.TB_starCnt.Text = "TB_starCnt";
            // 
            // TB_IPMCnt
            // 
            this.TB_IPMCnt.Location = new System.Drawing.Point(106, 95);
            this.TB_IPMCnt.Name = "TB_IPMCnt";
            this.TB_IPMCnt.Size = new System.Drawing.Size(100, 22);
            this.TB_IPMCnt.TabIndex = 38;
            this.TB_IPMCnt.Text = "TB_IPMCnt";
            // 
            // TB_FaultCode
            // 
            this.TB_FaultCode.Location = new System.Drawing.Point(106, 60);
            this.TB_FaultCode.Name = "TB_FaultCode";
            this.TB_FaultCode.Size = new System.Drawing.Size(100, 22);
            this.TB_FaultCode.TabIndex = 38;
            this.TB_FaultCode.Text = "TB_FaultCode";
            // 
            // TB_FaultState
            // 
            this.TB_FaultState.Location = new System.Drawing.Point(106, 25);
            this.TB_FaultState.Name = "TB_FaultState";
            this.TB_FaultState.Size = new System.Drawing.Size(100, 22);
            this.TB_FaultState.TabIndex = 38;
            this.TB_FaultState.Text = "TB_FaultState";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(12, 273);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(77, 12);
            this.label9.TabIndex = 35;
            this.label9.Text = "保護關機時間";
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Location = new System.Drawing.Point(12, 238);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(77, 12);
            this.label61.TabIndex = 35;
            this.label61.Text = "保護復位時間";
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Location = new System.Drawing.Point(12, 203);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(81, 12);
            this.label56.TabIndex = 35;
            this.label56.Text = "故障-保護次數";
            // 
            // label83
            // 
            this.label83.AutoSize = true;
            this.label83.Location = new System.Drawing.Point(12, 168);
            this.label83.Name = "label83";
            this.label83.Size = new System.Drawing.Size(77, 12);
            this.label83.TabIndex = 35;
            this.label83.Text = "驅動保護次數";
            // 
            // label82
            // 
            this.label82.AutoSize = true;
            this.label82.Location = new System.Drawing.Point(12, 133);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(77, 12);
            this.label82.TabIndex = 35;
            this.label82.Text = "啟動保護次數";
            // 
            // label81
            // 
            this.label81.AutoSize = true;
            this.label81.Location = new System.Drawing.Point(12, 98);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(73, 12);
            this.label81.TabIndex = 35;
            this.label81.Text = "IPM保護次數";
            // 
            // label80
            // 
            this.label80.AutoSize = true;
            this.label80.Location = new System.Drawing.Point(12, 63);
            this.label80.Name = "label80";
            this.label80.Size = new System.Drawing.Size(77, 12);
            this.label80.TabIndex = 35;
            this.label80.Text = "故障保護代碼";
            // 
            // label79
            // 
            this.label79.AutoSize = true;
            this.label79.Location = new System.Drawing.Point(12, 28);
            this.label79.Name = "label79";
            this.label79.Size = new System.Drawing.Size(77, 12);
            this.label79.TabIndex = 35;
            this.label79.Text = "故障保護狀態";
            // 
            // groupBox18
            // 
            this.groupBox18.Controls.Add(this.label55);
            this.groupBox18.Controls.Add(this.label54);
            this.groupBox18.Controls.Add(this.TB_inFanFreGMax);
            this.groupBox18.Controls.Add(this.TB_oTempFreGMax);
            this.groupBox18.Controls.Add(this.label59);
            this.groupBox18.Controls.Add(this.label58);
            this.groupBox18.Controls.Add(this.label57);
            this.groupBox18.Controls.Add(this.TB_freqGradeMax);
            this.groupBox18.Controls.Add(this.label75);
            this.groupBox18.Controls.Add(this.label27);
            this.groupBox18.Controls.Add(this.TB_fgCtrlTimer);
            this.groupBox18.Controls.Add(this.TB_DTGREAD_State);
            this.groupBox18.Controls.Add(this.TB_tempGradeOld);
            this.groupBox18.Controls.Add(this.TB_tempGradeNow);
            this.groupBox18.Controls.Add(this.label52);
            this.groupBox18.Controls.Add(this.label16);
            this.groupBox18.Controls.Add(this.TB_rsDeltaTemp);
            this.groupBox18.Controls.Add(this.TB_freqGradeOut);
            this.groupBox18.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox18.Location = new System.Drawing.Point(232, 259);
            this.groupBox18.Name = "groupBox18";
            this.groupBox18.Size = new System.Drawing.Size(222, 322);
            this.groupBox18.TabIndex = 34;
            this.groupBox18.TabStop = false;
            this.groupBox18.Text = "溫控邏輯";
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Location = new System.Drawing.Point(12, 292);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(89, 12);
            this.label55.TabIndex = 43;
            this.label55.Text = "室內風最大頻率";
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Location = new System.Drawing.Point(12, 259);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(89, 12);
            this.label54.TabIndex = 44;
            this.label54.Text = "室外溫最大頻率";
            // 
            // TB_inFanFreGMax
            // 
            this.TB_inFanFreGMax.Location = new System.Drawing.Point(107, 289);
            this.TB_inFanFreGMax.Name = "TB_inFanFreGMax";
            this.TB_inFanFreGMax.Size = new System.Drawing.Size(100, 22);
            this.TB_inFanFreGMax.TabIndex = 41;
            this.TB_inFanFreGMax.Text = "TB_inFanFreGMax";
            // 
            // TB_oTempFreGMax
            // 
            this.TB_oTempFreGMax.Location = new System.Drawing.Point(107, 256);
            this.TB_oTempFreGMax.Name = "TB_oTempFreGMax";
            this.TB_oTempFreGMax.Size = new System.Drawing.Size(100, 22);
            this.TB_oTempFreGMax.TabIndex = 42;
            this.TB_oTempFreGMax.Text = "TB_oTempFreGMax";
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Location = new System.Drawing.Point(12, 94);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(77, 12);
            this.label59.TabIndex = 40;
            this.label59.Text = "最大頻率等級";
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Location = new System.Drawing.Point(12, 61);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(77, 12);
            this.label58.TabIndex = 40;
            this.label58.Text = "區間保持時間";
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Location = new System.Drawing.Point(12, 28);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(77, 12);
            this.label57.TabIndex = 40;
            this.label57.Text = "溫度變化狀態";
            // 
            // TB_freqGradeMax
            // 
            this.TB_freqGradeMax.Location = new System.Drawing.Point(106, 91);
            this.TB_freqGradeMax.Name = "TB_freqGradeMax";
            this.TB_freqGradeMax.Size = new System.Drawing.Size(100, 22);
            this.TB_freqGradeMax.TabIndex = 15;
            this.TB_freqGradeMax.Text = "TB_freqGradeMax";
            // 
            // label75
            // 
            this.label75.AutoSize = true;
            this.label75.Location = new System.Drawing.Point(12, 226);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(77, 12);
            this.label75.TabIndex = 35;
            this.label75.Text = "上次溫度區間";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(12, 193);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(77, 12);
            this.label27.TabIndex = 35;
            this.label27.Text = "本次溫度區間";
            // 
            // TB_fgCtrlTimer
            // 
            this.TB_fgCtrlTimer.Location = new System.Drawing.Point(106, 58);
            this.TB_fgCtrlTimer.Name = "TB_fgCtrlTimer";
            this.TB_fgCtrlTimer.Size = new System.Drawing.Size(100, 22);
            this.TB_fgCtrlTimer.TabIndex = 15;
            this.TB_fgCtrlTimer.Text = "TB_fgCtrlTimer";
            // 
            // TB_DTGREAD_State
            // 
            this.TB_DTGREAD_State.Location = new System.Drawing.Point(106, 25);
            this.TB_DTGREAD_State.Name = "TB_DTGREAD_State";
            this.TB_DTGREAD_State.Size = new System.Drawing.Size(100, 22);
            this.TB_DTGREAD_State.TabIndex = 15;
            this.TB_DTGREAD_State.Text = "TB_DTGREAD_State";
            // 
            // TB_tempGradeOld
            // 
            this.TB_tempGradeOld.Location = new System.Drawing.Point(106, 223);
            this.TB_tempGradeOld.Name = "TB_tempGradeOld";
            this.TB_tempGradeOld.Size = new System.Drawing.Size(100, 22);
            this.TB_tempGradeOld.TabIndex = 34;
            this.TB_tempGradeOld.Text = "TB_tempGradeOld";
            // 
            // TB_tempGradeNow
            // 
            this.TB_tempGradeNow.Location = new System.Drawing.Point(106, 190);
            this.TB_tempGradeNow.Name = "TB_tempGradeNow";
            this.TB_tempGradeNow.Size = new System.Drawing.Size(100, 22);
            this.TB_tempGradeNow.TabIndex = 34;
            this.TB_tempGradeNow.Text = "TB_tempGradeNow";
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Location = new System.Drawing.Point(12, 160);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(41, 12);
            this.label52.TabIndex = 18;
            this.label52.Text = "溫度差";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(12, 127);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(53, 12);
            this.label16.TabIndex = 18;
            this.label16.Text = "頻率等級";
            // 
            // TB_rsDeltaTemp
            // 
            this.TB_rsDeltaTemp.Location = new System.Drawing.Point(106, 157);
            this.TB_rsDeltaTemp.Name = "TB_rsDeltaTemp";
            this.TB_rsDeltaTemp.Size = new System.Drawing.Size(100, 22);
            this.TB_rsDeltaTemp.TabIndex = 19;
            this.TB_rsDeltaTemp.Text = "TB_rsDeltaTemp";
            // 
            // TB_freqGradeOut
            // 
            this.TB_freqGradeOut.Location = new System.Drawing.Point(106, 124);
            this.TB_freqGradeOut.Name = "TB_freqGradeOut";
            this.TB_freqGradeOut.Size = new System.Drawing.Size(100, 22);
            this.TB_freqGradeOut.TabIndex = 19;
            this.TB_freqGradeOut.Text = "TB_freqGradeOut";
            // 
            // groupBox16
            // 
            this.groupBox16.Controls.Add(this.TB_AVG_Is);
            this.groupBox16.Controls.Add(this.TB_AVG_qCurrent);
            this.groupBox16.Controls.Add(this.TB_AVG_Vs);
            this.groupBox16.Controls.Add(this.TB_AVG_dCurrent);
            this.groupBox16.Controls.Add(this.TB_AVG_qVolt);
            this.groupBox16.Controls.Add(this.TB_AVG_dVolt);
            this.groupBox16.Controls.Add(this.label77);
            this.groupBox16.Controls.Add(this.label76);
            this.groupBox16.Controls.Add(this.label72);
            this.groupBox16.Controls.Add(this.label78);
            this.groupBox16.Controls.Add(this.label71);
            this.groupBox16.Controls.Add(this.label70);
            this.groupBox16.Location = new System.Drawing.Point(687, 352);
            this.groupBox16.Name = "groupBox16";
            this.groupBox16.Size = new System.Drawing.Size(222, 229);
            this.groupBox16.TabIndex = 33;
            this.groupBox16.TabStop = false;
            this.groupBox16.Text = "運轉資訊";
            // 
            // TB_AVG_Is
            // 
            this.TB_AVG_Is.Location = new System.Drawing.Point(106, 200);
            this.TB_AVG_Is.Name = "TB_AVG_Is";
            this.TB_AVG_Is.Size = new System.Drawing.Size(100, 22);
            this.TB_AVG_Is.TabIndex = 1;
            this.TB_AVG_Is.Text = "TB_AVG_Is";
            // 
            // TB_AVG_qCurrent
            // 
            this.TB_AVG_qCurrent.Location = new System.Drawing.Point(106, 165);
            this.TB_AVG_qCurrent.Name = "TB_AVG_qCurrent";
            this.TB_AVG_qCurrent.Size = new System.Drawing.Size(100, 22);
            this.TB_AVG_qCurrent.TabIndex = 1;
            this.TB_AVG_qCurrent.Text = "TB_AVG_qCurrent";
            // 
            // TB_AVG_Vs
            // 
            this.TB_AVG_Vs.Location = new System.Drawing.Point(106, 95);
            this.TB_AVG_Vs.Name = "TB_AVG_Vs";
            this.TB_AVG_Vs.Size = new System.Drawing.Size(100, 22);
            this.TB_AVG_Vs.TabIndex = 1;
            this.TB_AVG_Vs.Text = "TB_AVG_Vs";
            // 
            // TB_AVG_dCurrent
            // 
            this.TB_AVG_dCurrent.Location = new System.Drawing.Point(106, 130);
            this.TB_AVG_dCurrent.Name = "TB_AVG_dCurrent";
            this.TB_AVG_dCurrent.Size = new System.Drawing.Size(100, 22);
            this.TB_AVG_dCurrent.TabIndex = 1;
            this.TB_AVG_dCurrent.Text = "TB_AVG_dCurrent";
            // 
            // TB_AVG_qVolt
            // 
            this.TB_AVG_qVolt.Location = new System.Drawing.Point(106, 60);
            this.TB_AVG_qVolt.Name = "TB_AVG_qVolt";
            this.TB_AVG_qVolt.Size = new System.Drawing.Size(100, 22);
            this.TB_AVG_qVolt.TabIndex = 1;
            this.TB_AVG_qVolt.Text = "TB_AVG_qVolt";
            // 
            // TB_AVG_dVolt
            // 
            this.TB_AVG_dVolt.Location = new System.Drawing.Point(106, 25);
            this.TB_AVG_dVolt.Name = "TB_AVG_dVolt";
            this.TB_AVG_dVolt.Size = new System.Drawing.Size(100, 22);
            this.TB_AVG_dVolt.TabIndex = 1;
            this.TB_AVG_dVolt.Text = "TB_AVG_dVolt";
            // 
            // label77
            // 
            this.label77.AutoSize = true;
            this.label77.Location = new System.Drawing.Point(12, 203);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(37, 12);
            this.label77.TabIndex = 0;
            this.label77.Text = "Is電流";
            // 
            // label76
            // 
            this.label76.AutoSize = true;
            this.label76.Location = new System.Drawing.Point(12, 168);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(47, 12);
            this.label76.TabIndex = 0;
            this.label76.Text = "q軸電流";
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.Location = new System.Drawing.Point(12, 133);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(47, 12);
            this.label72.TabIndex = 0;
            this.label72.Text = "d軸電流";
            // 
            // label78
            // 
            this.label78.AutoSize = true;
            this.label78.Location = new System.Drawing.Point(12, 98);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(53, 12);
            this.label78.TabIndex = 0;
            this.label78.Text = "電壓輸出";
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.Location = new System.Drawing.Point(12, 63);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(47, 12);
            this.label71.TabIndex = 0;
            this.label71.Text = "q軸電壓";
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.Location = new System.Drawing.Point(12, 28);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(47, 12);
            this.label70.TabIndex = 0;
            this.label70.Text = "d軸電壓";
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.TB_defortTimeTemp);
            this.groupBox7.Controls.Add(this.TB_defortTimeCnt);
            this.groupBox7.Controls.Add(this.label50);
            this.groupBox7.Controls.Add(this.label29);
            this.groupBox7.Controls.Add(this.label28);
            this.groupBox7.Controls.Add(this.TB_defrostState);
            this.groupBox7.Location = new System.Drawing.Point(459, 3);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(222, 127);
            this.groupBox7.TabIndex = 32;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "除霜狀態";
            // 
            // TB_defortTimeTemp
            // 
            this.TB_defortTimeTemp.Location = new System.Drawing.Point(106, 95);
            this.TB_defortTimeTemp.Name = "TB_defortTimeTemp";
            this.TB_defortTimeTemp.Size = new System.Drawing.Size(100, 22);
            this.TB_defortTimeTemp.TabIndex = 38;
            this.TB_defortTimeTemp.Text = "TB_defortTimeTemp";
            // 
            // TB_defortTimeCnt
            // 
            this.TB_defortTimeCnt.Location = new System.Drawing.Point(106, 60);
            this.TB_defortTimeCnt.Name = "TB_defortTimeCnt";
            this.TB_defortTimeCnt.Size = new System.Drawing.Size(100, 22);
            this.TB_defortTimeCnt.TabIndex = 38;
            this.TB_defortTimeCnt.Text = "TB_defortTimeCnt";
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Location = new System.Drawing.Point(12, 98);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(53, 12);
            this.label50.TabIndex = 37;
            this.label50.Text = "除霜時間";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(12, 63);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(84, 12);
            this.label29.TabIndex = 37;
            this.label29.Text = "除霜-製熱 計時";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(12, 28);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(64, 12);
            this.label28.TabIndex = 36;
            this.label28.Text = "Deforst State";
            // 
            // TB_defrostState
            // 
            this.TB_defrostState.Location = new System.Drawing.Point(106, 25);
            this.TB_defrostState.Name = "TB_defrostState";
            this.TB_defrostState.Size = new System.Drawing.Size(100, 22);
            this.TB_defrostState.TabIndex = 35;
            this.TB_defrostState.Text = "TB_defrostState";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.TB_mainrelayState);
            this.groupBox5.Controls.Add(this.TB_forWayValveState);
            this.groupBox5.Controls.Add(this.TB_pfcState);
            this.groupBox5.Controls.Add(this.TB_POWER);
            this.groupBox5.Controls.Add(this.TB_VAC);
            this.groupBox5.Controls.Add(this.label48);
            this.groupBox5.Controls.Add(this.label40);
            this.groupBox5.Controls.Add(this.label39);
            this.groupBox5.Controls.Add(this.label62);
            this.groupBox5.Controls.Add(this.label32);
            this.groupBox5.Controls.Add(this.TB_IAC);
            this.groupBox5.Controls.Add(this.TB_VBUS);
            this.groupBox5.Controls.Add(this.label22);
            this.groupBox5.Controls.Add(this.label23);
            this.groupBox5.Controls.Add(this.TB_FactFreq);
            this.groupBox5.Controls.Add(this.TB_TargetFreq);
            this.groupBox5.Controls.Add(this.label15);
            this.groupBox5.Controls.Add(this.label14);
            this.groupBox5.Location = new System.Drawing.Point(688, 3);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(222, 343);
            this.groupBox5.TabIndex = 31;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "運轉狀態";
            // 
            // TB_mainrelayState
            // 
            this.TB_mainrelayState.Location = new System.Drawing.Point(106, 305);
            this.TB_mainrelayState.Name = "TB_mainrelayState";
            this.TB_mainrelayState.Size = new System.Drawing.Size(100, 22);
            this.TB_mainrelayState.TabIndex = 35;
            this.TB_mainrelayState.Text = "TB_mainrelayState";
            // 
            // TB_forWayValveState
            // 
            this.TB_forWayValveState.Location = new System.Drawing.Point(106, 270);
            this.TB_forWayValveState.Name = "TB_forWayValveState";
            this.TB_forWayValveState.Size = new System.Drawing.Size(100, 22);
            this.TB_forWayValveState.TabIndex = 35;
            this.TB_forWayValveState.Text = "TB_forWayValveState";
            // 
            // TB_pfcState
            // 
            this.TB_pfcState.Location = new System.Drawing.Point(106, 235);
            this.TB_pfcState.Name = "TB_pfcState";
            this.TB_pfcState.Size = new System.Drawing.Size(100, 22);
            this.TB_pfcState.TabIndex = 35;
            this.TB_pfcState.Text = "TB_pfcState";
            // 
            // TB_POWER
            // 
            this.TB_POWER.Location = new System.Drawing.Point(105, 200);
            this.TB_POWER.Name = "TB_POWER";
            this.TB_POWER.Size = new System.Drawing.Size(100, 22);
            this.TB_POWER.TabIndex = 35;
            this.TB_POWER.Text = "TB_POWER";
            // 
            // TB_VAC
            // 
            this.TB_VAC.Location = new System.Drawing.Point(106, 165);
            this.TB_VAC.Name = "TB_VAC";
            this.TB_VAC.Size = new System.Drawing.Size(100, 22);
            this.TB_VAC.TabIndex = 35;
            this.TB_VAC.Text = "TB_VAC";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(12, 308);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(77, 12);
            this.label48.TabIndex = 40;
            this.label48.Text = "主繼電器狀態";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(12, 273);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(65, 12);
            this.label40.TabIndex = 40;
            this.label40.Text = "四通閥狀態";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(12, 238);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(49, 12);
            this.label39.TabIndex = 40;
            this.label39.Text = "PFC狀態";
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Location = new System.Drawing.Point(12, 203);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(53, 12);
            this.label62.TabIndex = 40;
            this.label62.Text = "視在功率";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(12, 168);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(48, 12);
            this.label32.TabIndex = 40;
            this.label32.Text = "AC 電壓";
            // 
            // TB_IAC
            // 
            this.TB_IAC.Location = new System.Drawing.Point(106, 130);
            this.TB_IAC.Name = "TB_IAC";
            this.TB_IAC.Size = new System.Drawing.Size(100, 22);
            this.TB_IAC.TabIndex = 38;
            this.TB_IAC.Text = "TB_IAC";
            // 
            // TB_VBUS
            // 
            this.TB_VBUS.Location = new System.Drawing.Point(106, 95);
            this.TB_VBUS.Name = "TB_VBUS";
            this.TB_VBUS.Size = new System.Drawing.Size(100, 22);
            this.TB_VBUS.TabIndex = 39;
            this.TB_VBUS.Text = "TB_VBUS";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(12, 133);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(48, 12);
            this.label22.TabIndex = 36;
            this.label22.Text = "AC 電流";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(12, 98);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(48, 12);
            this.label23.TabIndex = 37;
            this.label23.Text = "DC 電壓";
            // 
            // TB_FactFreq
            // 
            this.TB_FactFreq.Location = new System.Drawing.Point(106, 60);
            this.TB_FactFreq.Name = "TB_FactFreq";
            this.TB_FactFreq.Size = new System.Drawing.Size(100, 22);
            this.TB_FactFreq.TabIndex = 16;
            this.TB_FactFreq.Text = "TB_FactFreq";
            // 
            // TB_TargetFreq
            // 
            this.TB_TargetFreq.Location = new System.Drawing.Point(106, 25);
            this.TB_TargetFreq.Name = "TB_TargetFreq";
            this.TB_TargetFreq.Size = new System.Drawing.Size(100, 22);
            this.TB_TargetFreq.TabIndex = 15;
            this.TB_TargetFreq.Text = "TB_TargetFreq";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(12, 63);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(53, 12);
            this.label15.TabIndex = 14;
            this.label15.Text = "實際頻率";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(12, 28);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(53, 12);
            this.label14.TabIndex = 13;
            this.label14.Text = "設定頻率";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.TB_freqState);
            this.groupBox4.Controls.Add(this.TB_sysState);
            this.groupBox4.Controls.Add(this.label42);
            this.groupBox4.Controls.Add(this.label20);
            this.groupBox4.Controls.Add(this.TB_runState);
            this.groupBox4.Controls.Add(this.label6);
            this.groupBox4.Controls.Add(this.label19);
            this.groupBox4.Controls.Add(this.TB_TestCmd);
            this.groupBox4.Controls.Add(this.TB_baseMod);
            this.groupBox4.Controls.Add(this.label18);
            this.groupBox4.Controls.Add(this.TB_SubRunMod);
            this.groupBox4.Controls.Add(this.label11);
            this.groupBox4.Controls.Add(this.label12);
            this.groupBox4.Controls.Add(this.TB_RunMod);
            this.groupBox4.Location = new System.Drawing.Point(231, 3);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(222, 250);
            this.groupBox4.TabIndex = 30;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "工作模式";
            // 
            // TB_freqState
            // 
            this.TB_freqState.Location = new System.Drawing.Point(106, 190);
            this.TB_freqState.Name = "TB_freqState";
            this.TB_freqState.Size = new System.Drawing.Size(100, 22);
            this.TB_freqState.TabIndex = 25;
            this.TB_freqState.Text = "TB_freqState";
            // 
            // TB_sysState
            // 
            this.TB_sysState.Location = new System.Drawing.Point(106, 157);
            this.TB_sysState.Name = "TB_sysState";
            this.TB_sysState.Size = new System.Drawing.Size(100, 22);
            this.TB_sysState.TabIndex = 25;
            this.TB_sysState.Text = "TB_sysState";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(12, 193);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(75, 12);
            this.label42.TabIndex = 24;
            this.label42.Text = "FREQ_STATE";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(12, 160);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(66, 12);
            this.label20.TabIndex = 24;
            this.label20.Text = "SYS_STATE";
            // 
            // TB_runState
            // 
            this.TB_runState.Location = new System.Drawing.Point(106, 124);
            this.TB_runState.Name = "TB_runState";
            this.TB_runState.Size = new System.Drawing.Size(100, 22);
            this.TB_runState.TabIndex = 23;
            this.TB_runState.Text = "TB_runState";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(12, 226);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(53, 12);
            this.label6.TabIndex = 9;
            this.label6.Text = "測試命令";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(12, 127);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(81, 12);
            this.label19.TabIndex = 22;
            this.label19.Text = "WORK_STATE";
            // 
            // TB_TestCmd
            // 
            this.TB_TestCmd.Location = new System.Drawing.Point(106, 223);
            this.TB_TestCmd.Name = "TB_TestCmd";
            this.TB_TestCmd.Size = new System.Drawing.Size(100, 22);
            this.TB_TestCmd.TabIndex = 12;
            this.TB_TestCmd.Text = "TB_TestCmd";
            // 
            // TB_baseMod
            // 
            this.TB_baseMod.Location = new System.Drawing.Point(106, 91);
            this.TB_baseMod.Name = "TB_baseMod";
            this.TB_baseMod.Size = new System.Drawing.Size(100, 22);
            this.TB_baseMod.TabIndex = 21;
            this.TB_baseMod.Text = "TB_baseMod";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(12, 94);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(79, 12);
            this.label18.TabIndex = 20;
            this.label18.Text = "WORK_MODE";
            // 
            // TB_SubRunMod
            // 
            this.TB_SubRunMod.Location = new System.Drawing.Point(106, 58);
            this.TB_SubRunMod.Name = "TB_SubRunMod";
            this.TB_SubRunMod.Size = new System.Drawing.Size(100, 22);
            this.TB_SubRunMod.TabIndex = 4;
            this.TB_SubRunMod.Text = "TB_SubRunMod";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(12, 61);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(65, 12);
            this.label11.TabIndex = 2;
            this.label11.Text = "子運行命令";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(12, 28);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(53, 12);
            this.label12.TabIndex = 1;
            this.label12.Text = "運行命令";
            // 
            // TB_RunMod
            // 
            this.TB_RunMod.Location = new System.Drawing.Point(106, 25);
            this.TB_RunMod.Name = "TB_RunMod";
            this.TB_RunMod.Size = new System.Drawing.Size(100, 22);
            this.TB_RunMod.TabIndex = 0;
            this.TB_RunMod.Text = "TB_RunMod";
            // 
            // groupBox13
            // 
            this.groupBox13.Controls.Add(this.panel8);
            this.groupBox13.Controls.Add(this.panel3);
            this.groupBox13.Controls.Add(this.panel2);
            this.groupBox13.Controls.Add(this.panel1);
            this.groupBox13.Location = new System.Drawing.Point(916, 3);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.Size = new System.Drawing.Size(328, 313);
            this.groupBox13.TabIndex = 37;
            this.groupBox13.TabStop = false;
            this.groupBox13.Text = "故障狀態";
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.label53);
            this.panel8.Controls.Add(this.LB_PfcLowVolt);
            this.panel8.Controls.Add(this.LB_PfcHiVolt);
            this.panel8.Controls.Add(this.LB_Pfcovercurrent);
            this.panel8.Location = new System.Drawing.Point(6, 259);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(310, 52);
            this.panel8.TabIndex = 4;
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label53.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label53.Location = new System.Drawing.Point(15, 10);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(80, 12);
            this.label53.TabIndex = 0;
            this.label53.Text = "PFC故障狀態";
            // 
            // LB_PfcLowVolt
            // 
            this.LB_PfcLowVolt.AutoSize = true;
            this.LB_PfcLowVolt.ForeColor = System.Drawing.SystemColors.ButtonShadow;
            this.LB_PfcLowVolt.Location = new System.Drawing.Point(165, 30);
            this.LB_PfcLowVolt.Name = "LB_PfcLowVolt";
            this.LB_PfcLowVolt.Size = new System.Drawing.Size(53, 12);
            this.LB_PfcLowVolt.TabIndex = 0;
            this.LB_PfcLowVolt.Text = "電壓過低";
            // 
            // LB_PfcHiVolt
            // 
            this.LB_PfcHiVolt.AutoSize = true;
            this.LB_PfcHiVolt.ForeColor = System.Drawing.SystemColors.ButtonShadow;
            this.LB_PfcHiVolt.Location = new System.Drawing.Point(90, 30);
            this.LB_PfcHiVolt.Name = "LB_PfcHiVolt";
            this.LB_PfcHiVolt.Size = new System.Drawing.Size(53, 12);
            this.LB_PfcHiVolt.TabIndex = 0;
            this.LB_PfcHiVolt.Text = "電壓過高";
            // 
            // LB_Pfcovercurrent
            // 
            this.LB_Pfcovercurrent.AutoSize = true;
            this.LB_Pfcovercurrent.ForeColor = System.Drawing.SystemColors.ButtonShadow;
            this.LB_Pfcovercurrent.Location = new System.Drawing.Point(15, 30);
            this.LB_Pfcovercurrent.Name = "LB_Pfcovercurrent";
            this.LB_Pfcovercurrent.Size = new System.Drawing.Size(53, 12);
            this.LB_Pfcovercurrent.TabIndex = 0;
            this.LB_Pfcovercurrent.Text = "電流過高";
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.label51);
            this.panel3.Controls.Add(this.LB_ICompOver);
            this.panel3.Controls.Add(this.LB_LoseSpeed);
            this.panel3.Controls.Add(this.LB_PhaseErr);
            this.panel3.Controls.Add(this.LB_ZeroSpeed);
            this.panel3.Controls.Add(this.LB_PhaseLose);
            this.panel3.Controls.Add(this.LB_StartUpErr);
            this.panel3.Location = new System.Drawing.Point(6, 190);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(310, 68);
            this.panel3.TabIndex = 3;
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label51.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label51.Location = new System.Drawing.Point(15, 10);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(96, 12);
            this.label51.TabIndex = 0;
            this.label51.Text = "壓縮機故障狀態";
            // 
            // LB_ICompOver
            // 
            this.LB_ICompOver.AutoSize = true;
            this.LB_ICompOver.ForeColor = System.Drawing.SystemColors.ButtonShadow;
            this.LB_ICompOver.Location = new System.Drawing.Point(90, 50);
            this.LB_ICompOver.Name = "LB_ICompOver";
            this.LB_ICompOver.Size = new System.Drawing.Size(53, 12);
            this.LB_ICompOver.TabIndex = 0;
            this.LB_ICompOver.Text = "過流保護";
            // 
            // LB_LoseSpeed
            // 
            this.LB_LoseSpeed.AutoSize = true;
            this.LB_LoseSpeed.ForeColor = System.Drawing.SystemColors.ButtonShadow;
            this.LB_LoseSpeed.Location = new System.Drawing.Point(15, 50);
            this.LB_LoseSpeed.Name = "LB_LoseSpeed";
            this.LB_LoseSpeed.Size = new System.Drawing.Size(53, 12);
            this.LB_LoseSpeed.TabIndex = 0;
            this.LB_LoseSpeed.Text = "失速保護";
            // 
            // LB_PhaseErr
            // 
            this.LB_PhaseErr.AutoSize = true;
            this.LB_PhaseErr.ForeColor = System.Drawing.SystemColors.ButtonShadow;
            this.LB_PhaseErr.Location = new System.Drawing.Point(165, 50);
            this.LB_PhaseErr.Name = "LB_PhaseErr";
            this.LB_PhaseErr.Size = new System.Drawing.Size(53, 12);
            this.LB_PhaseErr.TabIndex = 0;
            this.LB_PhaseErr.Text = "相序錯誤";
            // 
            // LB_ZeroSpeed
            // 
            this.LB_ZeroSpeed.AutoSize = true;
            this.LB_ZeroSpeed.ForeColor = System.Drawing.SystemColors.ButtonShadow;
            this.LB_ZeroSpeed.Location = new System.Drawing.Point(165, 30);
            this.LB_ZeroSpeed.Name = "LB_ZeroSpeed";
            this.LB_ZeroSpeed.Size = new System.Drawing.Size(53, 12);
            this.LB_ZeroSpeed.TabIndex = 0;
            this.LB_ZeroSpeed.Text = "零速保護";
            // 
            // LB_PhaseLose
            // 
            this.LB_PhaseLose.AutoSize = true;
            this.LB_PhaseLose.ForeColor = System.Drawing.SystemColors.ButtonShadow;
            this.LB_PhaseLose.Location = new System.Drawing.Point(90, 30);
            this.LB_PhaseLose.Name = "LB_PhaseLose";
            this.LB_PhaseLose.Size = new System.Drawing.Size(53, 12);
            this.LB_PhaseLose.TabIndex = 0;
            this.LB_PhaseLose.Text = "缺相保護";
            // 
            // LB_StartUpErr
            // 
            this.LB_StartUpErr.AutoSize = true;
            this.LB_StartUpErr.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.LB_StartUpErr.ForeColor = System.Drawing.SystemColors.ButtonShadow;
            this.LB_StartUpErr.Location = new System.Drawing.Point(15, 30);
            this.LB_StartUpErr.Name = "LB_StartUpErr";
            this.LB_StartUpErr.Size = new System.Drawing.Size(53, 12);
            this.LB_StartUpErr.TabIndex = 0;
            this.LB_StartUpErr.Text = "啟動故障";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.LB_IPMSensorErr);
            this.panel2.Controls.Add(this.LB_outfan_err);
            this.panel2.Controls.Add(this.label45);
            this.panel2.Controls.Add(this.LB_disCharTempFault);
            this.panel2.Controls.Add(this.LB_LowVoltFault);
            this.panel2.Controls.Add(this.LB_IPMFault);
            this.panel2.Controls.Add(this.LB_suctionFault);
            this.panel2.Controls.Add(this.LB_HighVoltFault);
            this.panel2.Controls.Add(this.LB_OutTempFault);
            this.panel2.Controls.Add(this.LB_CurrentSenFault);
            this.panel2.Controls.Add(this.LB_CoilMidTempFault);
            this.panel2.Location = new System.Drawing.Point(6, 83);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(310, 104);
            this.panel2.TabIndex = 2;
            // 
            // LB_IPMSensorErr
            // 
            this.LB_IPMSensorErr.AutoSize = true;
            this.LB_IPMSensorErr.ForeColor = System.Drawing.SystemColors.ButtonShadow;
            this.LB_IPMSensorErr.Location = new System.Drawing.Point(15, 90);
            this.LB_IPMSensorErr.Name = "LB_IPMSensorErr";
            this.LB_IPMSensorErr.Size = new System.Drawing.Size(112, 12);
            this.LB_IPMSensorErr.TabIndex = 2;
            this.LB_IPMSensorErr.Text = "IPM 溫度感測器故障";
            // 
            // LB_outfan_err
            // 
            this.LB_outfan_err.AutoSize = true;
            this.LB_outfan_err.ForeColor = System.Drawing.SystemColors.ButtonShadow;
            this.LB_outfan_err.Location = new System.Drawing.Point(240, 70);
            this.LB_outfan_err.Name = "LB_outfan_err";
            this.LB_outfan_err.Size = new System.Drawing.Size(65, 12);
            this.LB_outfan_err.TabIndex = 1;
            this.LB_outfan_err.Text = "外風機故障";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label45.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label45.Location = new System.Drawing.Point(15, 10);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(44, 12);
            this.label45.TabIndex = 0;
            this.label45.Text = "室外側";
            // 
            // LB_disCharTempFault
            // 
            this.LB_disCharTempFault.AutoSize = true;
            this.LB_disCharTempFault.ForeColor = System.Drawing.SystemColors.ButtonShadow;
            this.LB_disCharTempFault.Location = new System.Drawing.Point(15, 70);
            this.LB_disCharTempFault.Name = "LB_disCharTempFault";
            this.LB_disCharTempFault.Size = new System.Drawing.Size(125, 12);
            this.LB_disCharTempFault.TabIndex = 0;
            this.LB_disCharTempFault.Text = "壓縮機排氣溫度感測器";
            // 
            // LB_LowVoltFault
            // 
            this.LB_LowVoltFault.AutoSize = true;
            this.LB_LowVoltFault.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.LB_LowVoltFault.ForeColor = System.Drawing.SystemColors.ButtonShadow;
            this.LB_LowVoltFault.Location = new System.Drawing.Point(237, 50);
            this.LB_LowVoltFault.Name = "LB_LowVoltFault";
            this.LB_LowVoltFault.Size = new System.Drawing.Size(69, 12);
            this.LB_LowVoltFault.TabIndex = 0;
            this.LB_LowVoltFault.Text = "DC電壓過低";
            // 
            // LB_IPMFault
            // 
            this.LB_IPMFault.AutoSize = true;
            this.LB_IPMFault.ForeColor = System.Drawing.SystemColors.ButtonShadow;
            this.LB_IPMFault.Location = new System.Drawing.Point(153, 70);
            this.LB_IPMFault.Name = "LB_IPMFault";
            this.LB_IPMFault.Size = new System.Drawing.Size(73, 12);
            this.LB_IPMFault.TabIndex = 0;
            this.LB_IPMFault.Text = "IPM模組故障";
            // 
            // LB_suctionFault
            // 
            this.LB_suctionFault.AutoSize = true;
            this.LB_suctionFault.ForeColor = System.Drawing.SystemColors.ButtonShadow;
            this.LB_suctionFault.Location = new System.Drawing.Point(15, 50);
            this.LB_suctionFault.Name = "LB_suctionFault";
            this.LB_suctionFault.Size = new System.Drawing.Size(125, 12);
            this.LB_suctionFault.TabIndex = 0;
            this.LB_suctionFault.Text = "壓縮機吸氣溫度感測器";
            // 
            // LB_HighVoltFault
            // 
            this.LB_HighVoltFault.AutoSize = true;
            this.LB_HighVoltFault.ForeColor = System.Drawing.SystemColors.ButtonShadow;
            this.LB_HighVoltFault.Location = new System.Drawing.Point(153, 50);
            this.LB_HighVoltFault.Name = "LB_HighVoltFault";
            this.LB_HighVoltFault.Size = new System.Drawing.Size(69, 12);
            this.LB_HighVoltFault.TabIndex = 0;
            this.LB_HighVoltFault.Text = "DC電壓過高";
            // 
            // LB_OutTempFault
            // 
            this.LB_OutTempFault.AutoSize = true;
            this.LB_OutTempFault.ForeColor = System.Drawing.SystemColors.ButtonShadow;
            this.LB_OutTempFault.Location = new System.Drawing.Point(15, 30);
            this.LB_OutTempFault.Name = "LB_OutTempFault";
            this.LB_OutTempFault.Size = new System.Drawing.Size(89, 12);
            this.LB_OutTempFault.TabIndex = 0;
            this.LB_OutTempFault.Text = "環境溫度感測器";
            // 
            // LB_CurrentSenFault
            // 
            this.LB_CurrentSenFault.AutoSize = true;
            this.LB_CurrentSenFault.ForeColor = System.Drawing.SystemColors.ButtonShadow;
            this.LB_CurrentSenFault.Location = new System.Drawing.Point(240, 30);
            this.LB_CurrentSenFault.Name = "LB_CurrentSenFault";
            this.LB_CurrentSenFault.Size = new System.Drawing.Size(65, 12);
            this.LB_CurrentSenFault.TabIndex = 0;
            this.LB_CurrentSenFault.Text = "電流感測器";
            // 
            // LB_CoilMidTempFault
            // 
            this.LB_CoilMidTempFault.AutoSize = true;
            this.LB_CoilMidTempFault.ForeColor = System.Drawing.SystemColors.ButtonShadow;
            this.LB_CoilMidTempFault.Location = new System.Drawing.Point(130, 30);
            this.LB_CoilMidTempFault.Name = "LB_CoilMidTempFault";
            this.LB_CoilMidTempFault.Size = new System.Drawing.Size(89, 12);
            this.LB_CoilMidTempFault.TabIndex = 0;
            this.LB_CoilMidTempFault.Text = "銅管溫度感測器";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.LB_communicate_err);
            this.panel1.Controls.Add(this.label60);
            this.panel1.Controls.Add(this.LB_indoorTempFault);
            this.panel1.Controls.Add(this.LB_inCoilFault);
            this.panel1.Controls.Add(this.LB_inFanFault);
            this.panel1.Controls.Add(this.LB_inCoilHiTempFault);
            this.panel1.Controls.Add(this.LB_inCoilLoTempFault);
            this.panel1.Location = new System.Drawing.Point(6, 14);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(310, 68);
            this.panel1.TabIndex = 1;
            // 
            // LB_communicate_err
            // 
            this.LB_communicate_err.AutoSize = true;
            this.LB_communicate_err.ForeColor = System.Drawing.SystemColors.ButtonShadow;
            this.LB_communicate_err.Location = new System.Drawing.Point(240, 50);
            this.LB_communicate_err.Name = "LB_communicate_err";
            this.LB_communicate_err.Size = new System.Drawing.Size(53, 12);
            this.LB_communicate_err.TabIndex = 1;
            this.LB_communicate_err.Text = "通訊故障";
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label60.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label60.Location = new System.Drawing.Point(15, 10);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(44, 12);
            this.label60.TabIndex = 0;
            this.label60.Text = "室內側";
            // 
            // LB_indoorTempFault
            // 
            this.LB_indoorTempFault.AutoSize = true;
            this.LB_indoorTempFault.ForeColor = System.Drawing.SystemColors.ButtonShadow;
            this.LB_indoorTempFault.Location = new System.Drawing.Point(15, 30);
            this.LB_indoorTempFault.Name = "LB_indoorTempFault";
            this.LB_indoorTempFault.Size = new System.Drawing.Size(89, 12);
            this.LB_indoorTempFault.TabIndex = 0;
            this.LB_indoorTempFault.Text = "環境溫度感測器";
            // 
            // LB_inCoilFault
            // 
            this.LB_inCoilFault.AutoSize = true;
            this.LB_inCoilFault.ForeColor = System.Drawing.SystemColors.ButtonShadow;
            this.LB_inCoilFault.Location = new System.Drawing.Point(130, 30);
            this.LB_inCoilFault.Name = "LB_inCoilFault";
            this.LB_inCoilFault.Size = new System.Drawing.Size(89, 12);
            this.LB_inCoilFault.TabIndex = 0;
            this.LB_inCoilFault.Text = "銅管溫度感測器";
            // 
            // LB_inFanFault
            // 
            this.LB_inFanFault.AutoSize = true;
            this.LB_inFanFault.ForeColor = System.Drawing.SystemColors.ButtonShadow;
            this.LB_inFanFault.Location = new System.Drawing.Point(240, 30);
            this.LB_inFanFault.Name = "LB_inFanFault";
            this.LB_inFanFault.Size = new System.Drawing.Size(53, 12);
            this.LB_inFanFault.TabIndex = 0;
            this.LB_inFanFault.Text = "風機故障";
            // 
            // LB_inCoilHiTempFault
            // 
            this.LB_inCoilHiTempFault.AutoSize = true;
            this.LB_inCoilHiTempFault.ForeColor = System.Drawing.SystemColors.ButtonShadow;
            this.LB_inCoilHiTempFault.Location = new System.Drawing.Point(130, 50);
            this.LB_inCoilHiTempFault.Name = "LB_inCoilHiTempFault";
            this.LB_inCoilHiTempFault.Size = new System.Drawing.Size(77, 12);
            this.LB_inCoilHiTempFault.TabIndex = 0;
            this.LB_inCoilHiTempFault.Text = "銅管溫度過高";
            // 
            // LB_inCoilLoTempFault
            // 
            this.LB_inCoilLoTempFault.AutoSize = true;
            this.LB_inCoilLoTempFault.ForeColor = System.Drawing.SystemColors.ButtonShadow;
            this.LB_inCoilLoTempFault.Location = new System.Drawing.Point(15, 50);
            this.LB_inCoilLoTempFault.Name = "LB_inCoilLoTempFault";
            this.LB_inCoilLoTempFault.Size = new System.Drawing.Size(77, 12);
            this.LB_inCoilLoTempFault.TabIndex = 0;
            this.LB_inCoilLoTempFault.Text = "銅管溫度過低";
            // 
            // groupBox20
            // 
            this.groupBox20.Controls.Add(this.panel10);
            this.groupBox20.Controls.Add(this.panel9);
            this.groupBox20.Location = new System.Drawing.Point(915, 322);
            this.groupBox20.Name = "groupBox20";
            this.groupBox20.Size = new System.Drawing.Size(328, 120);
            this.groupBox20.TabIndex = 38;
            this.groupBox20.TabStop = false;
            this.groupBox20.Text = "保護狀態";
            // 
            // panel10
            // 
            this.panel10.Controls.Add(this.LB_outErr);
            this.panel10.Controls.Add(this.LB_inCoilHiTemp);
            this.panel10.Controls.Add(this.LB_inCoilLowTemp);
            this.panel10.Controls.Add(this.LB_outroomHiTemp);
            this.panel10.Controls.Add(this.LB_disPressure);
            this.panel10.Controls.Add(this.LB_outCoilHiTemp);
            this.panel10.Location = new System.Drawing.Point(6, 64);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(310, 52);
            this.panel10.TabIndex = 1;
            // 
            // LB_outErr
            // 
            this.LB_outErr.AutoSize = true;
            this.LB_outErr.ForeColor = System.Drawing.SystemColors.ButtonShadow;
            this.LB_outErr.Location = new System.Drawing.Point(205, 30);
            this.LB_outErr.Name = "LB_outErr";
            this.LB_outErr.Size = new System.Drawing.Size(77, 12);
            this.LB_outErr.TabIndex = 0;
            this.LB_outErr.Text = "室外系統異常";
            // 
            // LB_inCoilHiTemp
            // 
            this.LB_inCoilHiTemp.AutoSize = true;
            this.LB_inCoilHiTemp.ForeColor = System.Drawing.SystemColors.ButtonShadow;
            this.LB_inCoilHiTemp.Location = new System.Drawing.Point(110, 30);
            this.LB_inCoilHiTemp.Name = "LB_inCoilHiTemp";
            this.LB_inCoilHiTemp.Size = new System.Drawing.Size(77, 12);
            this.LB_inCoilHiTemp.TabIndex = 0;
            this.LB_inCoilHiTemp.Text = "室內銅管高溫";
            // 
            // LB_inCoilLowTemp
            // 
            this.LB_inCoilLowTemp.AutoSize = true;
            this.LB_inCoilLowTemp.ForeColor = System.Drawing.SystemColors.ButtonShadow;
            this.LB_inCoilLowTemp.Location = new System.Drawing.Point(15, 30);
            this.LB_inCoilLowTemp.Name = "LB_inCoilLowTemp";
            this.LB_inCoilLowTemp.Size = new System.Drawing.Size(77, 12);
            this.LB_inCoilLowTemp.TabIndex = 0;
            this.LB_inCoilLowTemp.Text = "室內銅管低溫";
            // 
            // LB_outroomHiTemp
            // 
            this.LB_outroomHiTemp.AutoSize = true;
            this.LB_outroomHiTemp.ForeColor = System.Drawing.SystemColors.ButtonShadow;
            this.LB_outroomHiTemp.Location = new System.Drawing.Point(205, 10);
            this.LB_outroomHiTemp.Name = "LB_outroomHiTemp";
            this.LB_outroomHiTemp.Size = new System.Drawing.Size(77, 12);
            this.LB_outroomHiTemp.TabIndex = 0;
            this.LB_outroomHiTemp.Text = "室外環溫過高";
            // 
            // LB_disPressure
            // 
            this.LB_disPressure.AutoSize = true;
            this.LB_disPressure.ForeColor = System.Drawing.SystemColors.ButtonShadow;
            this.LB_disPressure.Location = new System.Drawing.Point(15, 10);
            this.LB_disPressure.Name = "LB_disPressure";
            this.LB_disPressure.Size = new System.Drawing.Size(77, 12);
            this.LB_disPressure.TabIndex = 0;
            this.LB_disPressure.Text = "排氣高壓保護";
            // 
            // LB_outCoilHiTemp
            // 
            this.LB_outCoilHiTemp.AutoSize = true;
            this.LB_outCoilHiTemp.ForeColor = System.Drawing.SystemColors.ButtonShadow;
            this.LB_outCoilHiTemp.Location = new System.Drawing.Point(110, 10);
            this.LB_outCoilHiTemp.Name = "LB_outCoilHiTemp";
            this.LB_outCoilHiTemp.Size = new System.Drawing.Size(77, 12);
            this.LB_outCoilHiTemp.TabIndex = 0;
            this.LB_outCoilHiTemp.Text = "室外銅管高溫";
            // 
            // panel9
            // 
            this.panel9.Controls.Add(this.LB_suctionTempPro);
            this.panel9.Controls.Add(this.LB_comTopTempPro);
            this.panel9.Controls.Add(this.LB_dishcharTempPro);
            this.panel9.Controls.Add(this.LB_iacOver);
            this.panel9.Controls.Add(this.LB_ipmHiTemp);
            this.panel9.Location = new System.Drawing.Point(6, 14);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(310, 49);
            this.panel9.TabIndex = 0;
            // 
            // LB_suctionTempPro
            // 
            this.LB_suctionTempPro.AutoSize = true;
            this.LB_suctionTempPro.ForeColor = System.Drawing.SystemColors.ButtonShadow;
            this.LB_suctionTempPro.Location = new System.Drawing.Point(180, 30);
            this.LB_suctionTempPro.Name = "LB_suctionTempPro";
            this.LB_suctionTempPro.Size = new System.Drawing.Size(113, 12);
            this.LB_suctionTempPro.TabIndex = 0;
            this.LB_suctionTempPro.Text = "壓縮機吸氣溫度保護";
            // 
            // LB_comTopTempPro
            // 
            this.LB_comTopTempPro.AutoSize = true;
            this.LB_comTopTempPro.ForeColor = System.Drawing.SystemColors.ButtonShadow;
            this.LB_comTopTempPro.Location = new System.Drawing.Point(15, 30);
            this.LB_comTopTempPro.Name = "LB_comTopTempPro";
            this.LB_comTopTempPro.Size = new System.Drawing.Size(113, 12);
            this.LB_comTopTempPro.TabIndex = 0;
            this.LB_comTopTempPro.Text = "壓縮機頂部溫度保護";
            // 
            // LB_dishcharTempPro
            // 
            this.LB_dishcharTempPro.AutoSize = true;
            this.LB_dishcharTempPro.ForeColor = System.Drawing.SystemColors.ButtonShadow;
            this.LB_dishcharTempPro.Location = new System.Drawing.Point(180, 10);
            this.LB_dishcharTempPro.Name = "LB_dishcharTempPro";
            this.LB_dishcharTempPro.Size = new System.Drawing.Size(113, 12);
            this.LB_dishcharTempPro.TabIndex = 0;
            this.LB_dishcharTempPro.Text = "壓縮機排氣溫度保護";
            // 
            // LB_iacOver
            // 
            this.LB_iacOver.AutoSize = true;
            this.LB_iacOver.ForeColor = System.Drawing.SystemColors.ButtonShadow;
            this.LB_iacOver.Location = new System.Drawing.Point(90, 10);
            this.LB_iacOver.Name = "LB_iacOver";
            this.LB_iacOver.Size = new System.Drawing.Size(69, 12);
            this.LB_iacOver.TabIndex = 0;
            this.LB_iacOver.Text = "AC電流過大";
            // 
            // LB_ipmHiTemp
            // 
            this.LB_ipmHiTemp.AutoSize = true;
            this.LB_ipmHiTemp.ForeColor = System.Drawing.SystemColors.ButtonShadow;
            this.LB_ipmHiTemp.Location = new System.Drawing.Point(15, 10);
            this.LB_ipmHiTemp.Name = "LB_ipmHiTemp";
            this.LB_ipmHiTemp.Size = new System.Drawing.Size(49, 12);
            this.LB_ipmHiTemp.TabIndex = 0;
            this.LB_ipmHiTemp.Text = "IPM過熱";
            // 
            // groupBox17
            // 
            this.groupBox17.Controls.Add(this.LB_infanlimit);
            this.groupBox17.Controls.Add(this.LB_dischargeHi);
            this.groupBox17.Controls.Add(this.LB_outCoilHi);
            this.groupBox17.Controls.Add(this.LB_inCoilHi);
            this.groupBox17.Controls.Add(this.LB_inCoilLow);
            this.groupBox17.Controls.Add(this.LB_CompOver);
            this.groupBox17.Controls.Add(this.LB_VdcLimit);
            this.groupBox17.Controls.Add(this.LB_IacLimit);
            this.groupBox17.Location = new System.Drawing.Point(915, 444);
            this.groupBox17.Name = "groupBox17";
            this.groupBox17.Size = new System.Drawing.Size(328, 85);
            this.groupBox17.TabIndex = 39;
            this.groupBox17.TabStop = false;
            this.groupBox17.Text = "限頻狀態";
            // 
            // LB_infanlimit
            // 
            this.LB_infanlimit.AutoSize = true;
            this.LB_infanlimit.ForeColor = System.Drawing.SystemColors.ButtonShadow;
            this.LB_infanlimit.Location = new System.Drawing.Point(136, 60);
            this.LB_infanlimit.Name = "LB_infanlimit";
            this.LB_infanlimit.Size = new System.Drawing.Size(77, 12);
            this.LB_infanlimit.TabIndex = 30;
            this.LB_infanlimit.Text = "室內風速限頻";
            // 
            // LB_dischargeHi
            // 
            this.LB_dischargeHi.AutoSize = true;
            this.LB_dischargeHi.ForeColor = System.Drawing.SystemColors.ButtonShadow;
            this.LB_dischargeHi.Location = new System.Drawing.Point(15, 60);
            this.LB_dischargeHi.Name = "LB_dischargeHi";
            this.LB_dischargeHi.Size = new System.Drawing.Size(101, 12);
            this.LB_dischargeHi.TabIndex = 0;
            this.LB_dischargeHi.Text = "壓縮機出口溫過高";
            // 
            // LB_outCoilHi
            // 
            this.LB_outCoilHi.AutoSize = true;
            this.LB_outCoilHi.ForeColor = System.Drawing.SystemColors.ButtonShadow;
            this.LB_outCoilHi.Location = new System.Drawing.Point(220, 40);
            this.LB_outCoilHi.Name = "LB_outCoilHi";
            this.LB_outCoilHi.Size = new System.Drawing.Size(77, 12);
            this.LB_outCoilHi.TabIndex = 0;
            this.LB_outCoilHi.Text = "室外銅管過熱";
            // 
            // LB_inCoilHi
            // 
            this.LB_inCoilHi.AutoSize = true;
            this.LB_inCoilHi.ForeColor = System.Drawing.SystemColors.ButtonShadow;
            this.LB_inCoilHi.Location = new System.Drawing.Point(110, 40);
            this.LB_inCoilHi.Name = "LB_inCoilHi";
            this.LB_inCoilHi.Size = new System.Drawing.Size(77, 12);
            this.LB_inCoilHi.TabIndex = 0;
            this.LB_inCoilHi.Text = "室內銅管過熱";
            // 
            // LB_inCoilLow
            // 
            this.LB_inCoilLow.AutoSize = true;
            this.LB_inCoilLow.ForeColor = System.Drawing.SystemColors.ButtonShadow;
            this.LB_inCoilLow.Location = new System.Drawing.Point(15, 40);
            this.LB_inCoilLow.Name = "LB_inCoilLow";
            this.LB_inCoilLow.Size = new System.Drawing.Size(77, 12);
            this.LB_inCoilLow.TabIndex = 0;
            this.LB_inCoilLow.Text = "室內銅管過冷";
            // 
            // LB_CompOver
            // 
            this.LB_CompOver.AutoSize = true;
            this.LB_CompOver.ForeColor = System.Drawing.SystemColors.ButtonShadow;
            this.LB_CompOver.Location = new System.Drawing.Point(220, 20);
            this.LB_CompOver.Name = "LB_CompOver";
            this.LB_CompOver.Size = new System.Drawing.Size(77, 12);
            this.LB_CompOver.TabIndex = 0;
            this.LB_CompOver.Text = "壓縮機過負載";
            // 
            // LB_VdcLimit
            // 
            this.LB_VdcLimit.AutoSize = true;
            this.LB_VdcLimit.ForeColor = System.Drawing.SystemColors.ButtonShadow;
            this.LB_VdcLimit.Location = new System.Drawing.Point(110, 20);
            this.LB_VdcLimit.Name = "LB_VdcLimit";
            this.LB_VdcLimit.Size = new System.Drawing.Size(93, 12);
            this.LB_VdcLimit.TabIndex = 0;
            this.LB_VdcLimit.Text = "DC Bus 電壓限頻";
            // 
            // LB_IacLimit
            // 
            this.LB_IacLimit.AutoSize = true;
            this.LB_IacLimit.ForeColor = System.Drawing.SystemColors.ButtonShadow;
            this.LB_IacLimit.Location = new System.Drawing.Point(15, 20);
            this.LB_IacLimit.Name = "LB_IacLimit";
            this.LB_IacLimit.Size = new System.Drawing.Size(72, 12);
            this.LB_IacLimit.TabIndex = 0;
            this.LB_IacLimit.Text = "AC 電流限頻";
            // 
            // groupBox26
            // 
            this.groupBox26.Controls.Add(this.TB_OpMode);
            this.groupBox26.Controls.Add(this.label2);
            this.groupBox26.Controls.Add(this.label86);
            this.groupBox26.Controls.Add(this.TB_sysTime);
            this.groupBox26.Location = new System.Drawing.Point(915, 534);
            this.groupBox26.Name = "groupBox26";
            this.groupBox26.Size = new System.Drawing.Size(329, 47);
            this.groupBox26.TabIndex = 40;
            this.groupBox26.TabStop = false;
            this.groupBox26.Text = "資訊";
            // 
            // TB_OpMode
            // 
            this.TB_OpMode.Location = new System.Drawing.Point(88, 18);
            this.TB_OpMode.Name = "TB_OpMode";
            this.TB_OpMode.Size = new System.Drawing.Size(62, 22);
            this.TB_OpMode.TabIndex = 2;
            this.TB_OpMode.Text = "TB_OpMode";
            this.TB_OpMode.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(18, 22);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 12);
            this.label2.TabIndex = 1;
            this.label2.Text = "操作模式";
            // 
            // label86
            // 
            this.label86.AutoSize = true;
            this.label86.Location = new System.Drawing.Point(165, 22);
            this.label86.Name = "label86";
            this.label86.Size = new System.Drawing.Size(53, 12);
            this.label86.TabIndex = 1;
            this.label86.Text = "開機時間";
            // 
            // TB_sysTime
            // 
            this.TB_sysTime.Location = new System.Drawing.Point(227, 18);
            this.TB_sysTime.Name = "TB_sysTime";
            this.TB_sysTime.Size = new System.Drawing.Size(81, 22);
            this.TB_sysTime.TabIndex = 0;
            this.TB_sysTime.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // ProMonitorUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.groupBox26);
            this.Controls.Add(this.groupBox17);
            this.Controls.Add(this.groupBox20);
            this.Controls.Add(this.groupBox13);
            this.Controls.Add(this.groupBox23);
            this.Controls.Add(this.groupBox19);
            this.Controls.Add(this.groupBox18);
            this.Controls.Add(this.groupBox16);
            this.Controls.Add(this.groupBox7);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox12);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.groupBox3);
            this.DoubleBuffered = true;
            this.Name = "ProMonitorUI";
            this.Size = new System.Drawing.Size(1253, 601);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox12.ResumeLayout(false);
            this.groupBox12.PerformLayout();
            this.groupBox23.ResumeLayout(false);
            this.groupBox23.PerformLayout();
            this.groupBox19.ResumeLayout(false);
            this.groupBox19.PerformLayout();
            this.groupBox18.ResumeLayout(false);
            this.groupBox18.PerformLayout();
            this.groupBox16.ResumeLayout(false);
            this.groupBox16.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox13.ResumeLayout(false);
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.groupBox20.ResumeLayout(false);
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.groupBox17.ResumeLayout(false);
            this.groupBox17.PerformLayout();
            this.groupBox26.ResumeLayout(false);
            this.groupBox26.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox TB_SetTemp;
        private System.Windows.Forms.TextBox TB_CoilMidTemp;
        private System.Windows.Forms.TextBox TB_roomTemp;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.TextBox TB_OutTemp;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.TextBox TB_outCoilMid;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox TB_suctionTemp;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.TextBox TB_IPMTemp;
        private System.Windows.Forms.TextBox TB_disCharTemp;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox TB_InFan;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox TB_inFault;
        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.TextBox TB_OutFanSpd;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.TextBox TB_OutFanCnt;
        private System.Windows.Forms.TextBox TB_OutFanState;
        private System.Windows.Forms.TextBox TB_MotoStateCnt;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.TextBox TB_MotoState;
        private System.Windows.Forms.GroupBox groupBox23;
        private System.Windows.Forms.TextBox TB_proresetTime;
        private System.Windows.Forms.TextBox TB_proFreqGrade;
        private System.Windows.Forms.TextBox TB_proNum;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.GroupBox groupBox19;
        private System.Windows.Forms.TextBox TB_offTime;
        private System.Windows.Forms.TextBox TB_dlyTime;
        private System.Windows.Forms.TextBox TB_occuredCnt;
        private System.Windows.Forms.TextBox TB_compProCnt;
        private System.Windows.Forms.TextBox TB_starCnt;
        private System.Windows.Forms.TextBox TB_IPMCnt;
        private System.Windows.Forms.TextBox TB_FaultCode;
        private System.Windows.Forms.TextBox TB_FaultState;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Label label83;
        private System.Windows.Forms.Label label82;
        private System.Windows.Forms.Label label81;
        private System.Windows.Forms.Label label80;
        private System.Windows.Forms.Label label79;
        private System.Windows.Forms.GroupBox groupBox18;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.TextBox TB_inFanFreGMax;
        private System.Windows.Forms.TextBox TB_oTempFreGMax;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.TextBox TB_freqGradeMax;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.TextBox TB_fgCtrlTimer;
        private System.Windows.Forms.TextBox TB_DTGREAD_State;
        private System.Windows.Forms.TextBox TB_tempGradeOld;
        private System.Windows.Forms.TextBox TB_tempGradeNow;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox TB_rsDeltaTemp;
        private System.Windows.Forms.TextBox TB_freqGradeOut;
        private System.Windows.Forms.GroupBox groupBox16;
        private System.Windows.Forms.TextBox TB_AVG_Is;
        private System.Windows.Forms.TextBox TB_AVG_qCurrent;
        private System.Windows.Forms.TextBox TB_AVG_Vs;
        private System.Windows.Forms.TextBox TB_AVG_dCurrent;
        private System.Windows.Forms.TextBox TB_AVG_qVolt;
        private System.Windows.Forms.TextBox TB_AVG_dVolt;
        private System.Windows.Forms.Label label77;
        private System.Windows.Forms.Label label76;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.Label label78;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.TextBox TB_defortTimeTemp;
        private System.Windows.Forms.TextBox TB_defortTimeCnt;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox TB_defrostState;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.TextBox TB_mainrelayState;
        private System.Windows.Forms.TextBox TB_forWayValveState;
        private System.Windows.Forms.TextBox TB_pfcState;
        private System.Windows.Forms.TextBox TB_POWER;
        private System.Windows.Forms.TextBox TB_VAC;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.TextBox TB_IAC;
        private System.Windows.Forms.TextBox TB_VBUS;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox TB_FactFreq;
        private System.Windows.Forms.TextBox TB_TargetFreq;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox TB_freqState;
        private System.Windows.Forms.TextBox TB_sysState;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox TB_runState;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox TB_TestCmd;
        private System.Windows.Forms.TextBox TB_baseMod;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox TB_SubRunMod;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox TB_RunMod;
        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label LB_PfcLowVolt;
        private System.Windows.Forms.Label LB_PfcHiVolt;
        private System.Windows.Forms.Label LB_Pfcovercurrent;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label LB_ICompOver;
        private System.Windows.Forms.Label LB_LoseSpeed;
        private System.Windows.Forms.Label LB_PhaseErr;
        private System.Windows.Forms.Label LB_ZeroSpeed;
        private System.Windows.Forms.Label LB_PhaseLose;
        private System.Windows.Forms.Label LB_StartUpErr;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label LB_IPMSensorErr;
        private System.Windows.Forms.Label LB_outfan_err;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label LB_disCharTempFault;
        private System.Windows.Forms.Label LB_LowVoltFault;
        private System.Windows.Forms.Label LB_IPMFault;
        private System.Windows.Forms.Label LB_suctionFault;
        private System.Windows.Forms.Label LB_HighVoltFault;
        private System.Windows.Forms.Label LB_OutTempFault;
        private System.Windows.Forms.Label LB_CurrentSenFault;
        private System.Windows.Forms.Label LB_CoilMidTempFault;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label LB_communicate_err;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Label LB_indoorTempFault;
        private System.Windows.Forms.Label LB_inCoilFault;
        private System.Windows.Forms.Label LB_inFanFault;
        private System.Windows.Forms.Label LB_inCoilHiTempFault;
        private System.Windows.Forms.Label LB_inCoilLoTempFault;
        private System.Windows.Forms.GroupBox groupBox20;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Label LB_outErr;
        private System.Windows.Forms.Label LB_inCoilHiTemp;
        private System.Windows.Forms.Label LB_inCoilLowTemp;
        private System.Windows.Forms.Label LB_outroomHiTemp;
        private System.Windows.Forms.Label LB_disPressure;
        private System.Windows.Forms.Label LB_outCoilHiTemp;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Label LB_suctionTempPro;
        private System.Windows.Forms.Label LB_comTopTempPro;
        private System.Windows.Forms.Label LB_dishcharTempPro;
        private System.Windows.Forms.Label LB_iacOver;
        private System.Windows.Forms.Label LB_ipmHiTemp;
        private System.Windows.Forms.GroupBox groupBox17;
        private System.Windows.Forms.Label LB_infanlimit;
        private System.Windows.Forms.Label LB_dischargeHi;
        private System.Windows.Forms.Label LB_outCoilHi;
        private System.Windows.Forms.Label LB_inCoilHi;
        private System.Windows.Forms.Label LB_inCoilLow;
        private System.Windows.Forms.Label LB_CompOver;
        private System.Windows.Forms.Label LB_VdcLimit;
        private System.Windows.Forms.Label LB_IacLimit;
        private System.Windows.Forms.GroupBox groupBox26;
        private System.Windows.Forms.TextBox TB_OpMode;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label86;
        private System.Windows.Forms.TextBox TB_sysTime;
    }
}

﻿namespace CS6257_Monitor.UserUI
{
    partial class StateMachinInfoUI
    {
        /// <summary> 
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 元件設計工具產生的程式碼

        /// <summary> 
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器
        /// 修改這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.TB_ParaSYNState = new System.Windows.Forms.TextBox();
            this.TB_LinkState = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.TB_SetTemp = new System.Windows.Forms.TextBox();
            this.TB_CoilMidTemp = new System.Windows.Forms.TextBox();
            this.TB_roomTemp = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.TB_OutTemp = new System.Windows.Forms.TextBox();
            this.label34 = new System.Windows.Forms.Label();
            this.TB_outCoilMid = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.TB_suctionTemp = new System.Windows.Forms.TextBox();
            this.label49 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.TB_IPMTemp = new System.Windows.Forms.TextBox();
            this.TB_disCharTemp = new System.Windows.Forms.TextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.TB_InFan = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.TB_TestCmd = new System.Windows.Forms.TextBox();
            this.TB_SubRunMod = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.TB_RunMod = new System.Windows.Forms.TextBox();
            this.groupBox1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.panel3);
            this.groupBox1.Controls.Add(this.panel1);
            this.groupBox1.Controls.Add(this.panel2);
            this.groupBox1.Location = new System.Drawing.Point(3, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(364, 377);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "資訊";
            // 
            // panel3
            // 
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.button1);
            this.panel3.Controls.Add(this.TB_ParaSYNState);
            this.panel3.Controls.Add(this.TB_LinkState);
            this.panel3.Controls.Add(this.label11);
            this.panel3.Controls.Add(this.label10);
            this.panel3.Location = new System.Drawing.Point(6, 303);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(352, 68);
            this.panel3.TabIndex = 3;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(249, 21);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 37);
            this.button1.TabIndex = 2;
            this.button1.Text = "設定";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // TB_ParaSYNState
            // 
            this.TB_ParaSYNState.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.TB_ParaSYNState.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.TB_ParaSYNState.Font = new System.Drawing.Font("Consolas", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TB_ParaSYNState.Location = new System.Drawing.Point(134, 30);
            this.TB_ParaSYNState.Name = "TB_ParaSYNState";
            this.TB_ParaSYNState.ReadOnly = true;
            this.TB_ParaSYNState.Size = new System.Drawing.Size(91, 22);
            this.TB_ParaSYNState.TabIndex = 1;
            this.TB_ParaSYNState.Text = "UNKNOW";
            this.TB_ParaSYNState.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // TB_LinkState
            // 
            this.TB_LinkState.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.TB_LinkState.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.TB_LinkState.Font = new System.Drawing.Font("Consolas", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TB_LinkState.ForeColor = System.Drawing.SystemColors.WindowText;
            this.TB_LinkState.Location = new System.Drawing.Point(21, 30);
            this.TB_LinkState.Name = "TB_LinkState";
            this.TB_LinkState.ReadOnly = true;
            this.TB_LinkState.Size = new System.Drawing.Size(91, 22);
            this.TB_LinkState.TabIndex = 1;
            this.TB_LinkState.Text = "UNKNOW";
            this.TB_LinkState.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(134, 15);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(77, 12);
            this.label11.TabIndex = 0;
            this.label11.Text = "參數同步狀態";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(21, 15);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(53, 12);
            this.label10.TabIndex = 0;
            this.label10.Text = "連線狀態";
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.TB_SetTemp);
            this.panel1.Controls.Add(this.TB_CoilMidTemp);
            this.panel1.Controls.Add(this.TB_roomTemp);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.label35);
            this.panel1.Controls.Add(this.TB_OutTemp);
            this.panel1.Controls.Add(this.label34);
            this.panel1.Controls.Add(this.TB_outCoilMid);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.TB_suctionTemp);
            this.panel1.Controls.Add(this.label49);
            this.panel1.Controls.Add(this.label33);
            this.panel1.Controls.Add(this.TB_IPMTemp);
            this.panel1.Controls.Add(this.TB_disCharTemp);
            this.panel1.Location = new System.Drawing.Point(6, 109);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(352, 188);
            this.panel1.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(77, 12);
            this.label1.TabIndex = 21;
            this.label1.Text = "室內環境溫度";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(9, 49);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(77, 12);
            this.label8.TabIndex = 33;
            this.label8.Text = "室內銅管溫度";
            // 
            // TB_SetTemp
            // 
            this.TB_SetTemp.Location = new System.Drawing.Point(268, 12);
            this.TB_SetTemp.Name = "TB_SetTemp";
            this.TB_SetTemp.Size = new System.Drawing.Size(65, 22);
            this.TB_SetTemp.TabIndex = 31;
            this.TB_SetTemp.Text = "TB_SetTemp";
            this.TB_SetTemp.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // TB_CoilMidTemp
            // 
            this.TB_CoilMidTemp.Location = new System.Drawing.Point(92, 46);
            this.TB_CoilMidTemp.Name = "TB_CoilMidTemp";
            this.TB_CoilMidTemp.Size = new System.Drawing.Size(65, 22);
            this.TB_CoilMidTemp.TabIndex = 32;
            this.TB_CoilMidTemp.Text = "TB_CoilMidTemp";
            this.TB_CoilMidTemp.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // TB_roomTemp
            // 
            this.TB_roomTemp.Location = new System.Drawing.Point(92, 12);
            this.TB_roomTemp.Name = "TB_roomTemp";
            this.TB_roomTemp.Size = new System.Drawing.Size(65, 22);
            this.TB_roomTemp.TabIndex = 26;
            this.TB_roomTemp.Text = "TB_roomTemp";
            this.TB_roomTemp.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(185, 15);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(65, 12);
            this.label7.TabIndex = 30;
            this.label7.Text = "室內設定溫";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(9, 83);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(77, 12);
            this.label35.TabIndex = 18;
            this.label35.Text = "室外環境溫度";
            // 
            // TB_OutTemp
            // 
            this.TB_OutTemp.Location = new System.Drawing.Point(92, 80);
            this.TB_OutTemp.Name = "TB_OutTemp";
            this.TB_OutTemp.Size = new System.Drawing.Size(65, 22);
            this.TB_OutTemp.TabIndex = 19;
            this.TB_OutTemp.Text = "TB_OutTemp";
            this.TB_OutTemp.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(185, 83);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(77, 12);
            this.label34.TabIndex = 20;
            this.label34.Text = "室外銅管溫度";
            // 
            // TB_outCoilMid
            // 
            this.TB_outCoilMid.Location = new System.Drawing.Point(268, 80);
            this.TB_outCoilMid.Name = "TB_outCoilMid";
            this.TB_outCoilMid.Size = new System.Drawing.Size(65, 22);
            this.TB_outCoilMid.TabIndex = 22;
            this.TB_outCoilMid.Text = "TB_outCoilMid";
            this.TB_outCoilMid.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(9, 117);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 12);
            this.label3.TabIndex = 23;
            this.label3.Text = "入口溫度";
            // 
            // TB_suctionTemp
            // 
            this.TB_suctionTemp.Location = new System.Drawing.Point(92, 114);
            this.TB_suctionTemp.Name = "TB_suctionTemp";
            this.TB_suctionTemp.Size = new System.Drawing.Size(65, 22);
            this.TB_suctionTemp.TabIndex = 27;
            this.TB_suctionTemp.Text = "TB_suctionTemp";
            this.TB_suctionTemp.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(9, 151);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(52, 12);
            this.label49.TabIndex = 24;
            this.label49.Text = "IPM 溫度";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(185, 117);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(53, 12);
            this.label33.TabIndex = 25;
            this.label33.Text = "出口溫度";
            // 
            // TB_IPMTemp
            // 
            this.TB_IPMTemp.Location = new System.Drawing.Point(92, 148);
            this.TB_IPMTemp.Name = "TB_IPMTemp";
            this.TB_IPMTemp.Size = new System.Drawing.Size(65, 22);
            this.TB_IPMTemp.TabIndex = 28;
            this.TB_IPMTemp.Text = "TB_IPMTemp";
            this.TB_IPMTemp.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // TB_disCharTemp
            // 
            this.TB_disCharTemp.Location = new System.Drawing.Point(268, 114);
            this.TB_disCharTemp.Name = "TB_disCharTemp";
            this.TB_disCharTemp.Size = new System.Drawing.Size(65, 22);
            this.TB_disCharTemp.TabIndex = 29;
            this.TB_disCharTemp.Text = "TB_disCharTemp";
            this.TB_disCharTemp.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.TB_InFan);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.TB_TestCmd);
            this.panel2.Controls.Add(this.TB_SubRunMod);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.label12);
            this.panel2.Controls.Add(this.TB_RunMod);
            this.panel2.Location = new System.Drawing.Point(6, 21);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(352, 82);
            this.panel2.TabIndex = 2;
            // 
            // TB_InFan
            // 
            this.TB_InFan.Location = new System.Drawing.Point(268, 46);
            this.TB_InFan.Name = "TB_InFan";
            this.TB_InFan.Size = new System.Drawing.Size(66, 22);
            this.TB_InFan.TabIndex = 35;
            this.TB_InFan.Text = "TB_InFan";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(185, 49);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(77, 12);
            this.label4.TabIndex = 34;
            this.label4.Text = "室內風扇轉速";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(9, 49);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(53, 12);
            this.label6.TabIndex = 34;
            this.label6.Text = "測試命令";
            // 
            // TB_TestCmd
            // 
            this.TB_TestCmd.Location = new System.Drawing.Point(92, 46);
            this.TB_TestCmd.Name = "TB_TestCmd";
            this.TB_TestCmd.Size = new System.Drawing.Size(65, 22);
            this.TB_TestCmd.TabIndex = 35;
            this.TB_TestCmd.Text = "TB_TestCmd";
            // 
            // TB_SubRunMod
            // 
            this.TB_SubRunMod.Location = new System.Drawing.Point(268, 12);
            this.TB_SubRunMod.Name = "TB_SubRunMod";
            this.TB_SubRunMod.Size = new System.Drawing.Size(65, 22);
            this.TB_SubRunMod.TabIndex = 8;
            this.TB_SubRunMod.Text = "TB_SubRunMod";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(185, 15);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 12);
            this.label2.TabIndex = 7;
            this.label2.Text = "子運行命令";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(9, 15);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(53, 12);
            this.label12.TabIndex = 6;
            this.label12.Text = "運行命令";
            // 
            // TB_RunMod
            // 
            this.TB_RunMod.Location = new System.Drawing.Point(92, 12);
            this.TB_RunMod.Name = "TB_RunMod";
            this.TB_RunMod.Size = new System.Drawing.Size(65, 22);
            this.TB_RunMod.TabIndex = 5;
            this.TB_RunMod.Text = "TB_RunMod";
            // 
            // StateMachinInfoUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.groupBox1);
            this.Name = "StateMachinInfoUI";
            this.Size = new System.Drawing.Size(374, 382);
            this.groupBox1.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox TB_ParaSYNState;
        private System.Windows.Forms.TextBox TB_LinkState;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox TB_SetTemp;
        private System.Windows.Forms.TextBox TB_CoilMidTemp;
        private System.Windows.Forms.TextBox TB_roomTemp;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.TextBox TB_OutTemp;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.TextBox TB_outCoilMid;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox TB_suctionTemp;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.TextBox TB_IPMTemp;
        private System.Windows.Forms.TextBox TB_disCharTemp;
        private System.Windows.Forms.TextBox TB_SubRunMod;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox TB_RunMod;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox TB_TestCmd;
        private System.Windows.Forms.TextBox TB_InFan;
        private System.Windows.Forms.Label label4;
    }
}

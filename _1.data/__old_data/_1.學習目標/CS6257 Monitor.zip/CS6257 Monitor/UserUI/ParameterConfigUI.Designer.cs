﻿namespace CS6257_Monitor.UserUI
{
    partial class ParameterConfigUI
    {
        /// <summary> 
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 元件設計工具產生的程式碼

        /// <summary> 
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器
        /// 修改這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.panel13 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.num_PolePair = new System.Windows.Forms.NumericUpDown();
            this.panel9 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.num_Lq = new System.Windows.Forms.NumericUpDown();
            this.label10 = new System.Windows.Forms.Label();
            this.num_Ld = new System.Windows.Forms.NumericUpDown();
            this.label18 = new System.Windows.Forms.Label();
            this.num_Rs = new System.Windows.Forms.NumericUpDown();
            this.label33 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.num_maxFreq = new System.Windows.Forms.NumericUpDown();
            this.num_minFreq = new System.Windows.Forms.NumericUpDown();
            this.label19 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.num_incUp = new System.Windows.Forms.NumericUpDown();
            this.label9 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.Read_efd_button = new System.Windows.Forms.Button();
            this.Write_efd_button = new System.Windows.Forms.Button();
            this.SaveFile_button = new System.Windows.Forms.Button();
            this.OpenFile_button = new System.Windows.Forms.Button();
            this.Update_button = new System.Windows.Forms.Button();
            this.Reload_button = new System.Windows.Forms.Button();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.panel12 = new System.Windows.Forms.Panel();
            this.label56 = new System.Windows.Forms.Label();
            this.num_PhaseCurLimit = new System.Windows.Forms.NumericUpDown();
            this.label53 = new System.Windows.Forms.Label();
            this.panel11 = new System.Windows.Forms.Panel();
            this.num_VacMin = new System.Windows.Forms.NumericUpDown();
            this.label58 = new System.Windows.Forms.Label();
            this.num_VacMax = new System.Windows.Forms.NumericUpDown();
            this.label59 = new System.Windows.Forms.Label();
            this.label60 = new System.Windows.Forms.Label();
            this.label61 = new System.Windows.Forms.Label();
            this.panel10 = new System.Windows.Forms.Panel();
            this.label42 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.num_VbusMin = new System.Windows.Forms.NumericUpDown();
            this.label51 = new System.Windows.Forms.Label();
            this.num_VbusMax = new System.Windows.Forms.NumericUpDown();
            this.label41 = new System.Windows.Forms.Label();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.label54 = new System.Windows.Forms.Label();
            this.num_incDown = new System.Windows.Forms.NumericUpDown();
            this.label55 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.panel8 = new System.Windows.Forms.Panel();
            this.num_Freq_pwm = new System.Windows.Forms.NumericUpDown();
            this.label66 = new System.Windows.Forms.Label();
            this.num_DeadTime = new System.Windows.Forms.NumericUpDown();
            this.label67 = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.label65 = new System.Windows.Forms.Label();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.label62 = new System.Windows.Forms.Label();
            this.num_V_Sample_K = new System.Windows.Forms.NumericUpDown();
            this.label63 = new System.Windows.Forms.Label();
            this.num_I_Sample_K = new System.Windows.Forms.NumericUpDown();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.groupBox18 = new System.Windows.Forms.GroupBox();
            this.panel6 = new System.Windows.Forms.Panel();
            this.comboBox_FilterSelected = new System.Windows.Forms.ComboBox();
            this.num_K_OmC_StartUp = new System.Windows.Forms.NumericUpDown();
            this.label46 = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.num_K_THETA0_MAX = new System.Windows.Forms.NumericUpDown();
            this.label64 = new System.Windows.Forms.Label();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.panel16 = new System.Windows.Forms.Panel();
            this.label25 = new System.Windows.Forms.Label();
            this.num_E0_StartUp_2 = new System.Windows.Forms.NumericUpDown();
            this.num_Kslf_StartUp_2 = new System.Windows.Forms.NumericUpDown();
            this.label27 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.num_Kslide_StartUp_2 = new System.Windows.Forms.NumericUpDown();
            this.panel5 = new System.Windows.Forms.Panel();
            this.label24 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.num_E0_StartUp_1 = new System.Windows.Forms.NumericUpDown();
            this.num_Kslf_StartUp_1 = new System.Windows.Forms.NumericUpDown();
            this.label28 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.num_Kslide_StartUp_1 = new System.Windows.Forms.NumericUpDown();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.panel15 = new System.Windows.Forms.Panel();
            this.num_SynTime = new System.Windows.Forms.NumericUpDown();
            this.num_SynSpd = new System.Windows.Forms.NumericUpDown();
            this.num_Accrate = new System.Windows.Forms.NumericUpDown();
            this.label71 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.label73 = new System.Windows.Forms.Label();
            this.label72 = new System.Windows.Forms.Label();
            this.label70 = new System.Windows.Forms.Label();
            this.label69 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label16 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.num_baseFreq = new System.Windows.Forms.NumericUpDown();
            this.num_I_Start_Max = new System.Windows.Forms.NumericUpDown();
            this.label34 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.panel14 = new System.Windows.Forms.Panel();
            this.comboBox_StartUp_Mode = new System.Windows.Forms.ComboBox();
            this.label68 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.num_Count_StartUp_ST4_ADD = new System.Windows.Forms.NumericUpDown();
            this.label31 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.num_CurStart_ST1 = new System.Windows.Forms.NumericUpDown();
            this.label5 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.num_CurStart_ST2 = new System.Windows.Forms.NumericUpDown();
            this.num_Count_StartUp_ST2_ADD = new System.Windows.Forms.NumericUpDown();
            this.label13 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.num_CurStartOffset = new System.Windows.Forms.NumericUpDown();
            this.label22 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.num_Count_StartUp_ST3_ADD = new System.Windows.Forms.NumericUpDown();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.groupBox17 = new System.Windows.Forms.GroupBox();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.label74 = new System.Windows.Forms.Label();
            this.label75 = new System.Windows.Forms.Label();
            this.num_CurPID_KP_5 = new System.Windows.Forms.NumericUpDown();
            this.num_CurPID_KI_5 = new System.Windows.Forms.NumericUpDown();
            this.num_CurPID_KP_4 = new System.Windows.Forms.NumericUpDown();
            this.num_CurPID_KI_4 = new System.Windows.Forms.NumericUpDown();
            this.num_CurPID_KP_3 = new System.Windows.Forms.NumericUpDown();
            this.num_CurPID_KD_5 = new System.Windows.Forms.NumericUpDown();
            this.num_CurPID_KI_3 = new System.Windows.Forms.NumericUpDown();
            this.num_CurPID_KD_4 = new System.Windows.Forms.NumericUpDown();
            this.num_CurPID_KP_2 = new System.Windows.Forms.NumericUpDown();
            this.num_CurPID_KI_2 = new System.Windows.Forms.NumericUpDown();
            this.num_CurPID_KP_1 = new System.Windows.Forms.NumericUpDown();
            this.num_CurPID_KI_1 = new System.Windows.Forms.NumericUpDown();
            this.num_CurPID_KD_3 = new System.Windows.Forms.NumericUpDown();
            this.num_CurPID_KP_0 = new System.Windows.Forms.NumericUpDown();
            this.num_CurPID_KD_2 = new System.Windows.Forms.NumericUpDown();
            this.num_CurPID_KI_0 = new System.Windows.Forms.NumericUpDown();
            this.num_CurPID_KD_1 = new System.Windows.Forms.NumericUpDown();
            this.label82 = new System.Windows.Forms.Label();
            this.label81 = new System.Windows.Forms.Label();
            this.label80 = new System.Windows.Forms.Label();
            this.label79 = new System.Windows.Forms.Label();
            this.label78 = new System.Windows.Forms.Label();
            this.label77 = new System.Windows.Forms.Label();
            this.label76 = new System.Windows.Forms.Label();
            this.num_CurPID_KD_0 = new System.Windows.Forms.NumericUpDown();
            this.label40 = new System.Windows.Forms.Label();
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.label83 = new System.Windows.Forms.Label();
            this.label84 = new System.Windows.Forms.Label();
            this.num_SpdPID_KP_5 = new System.Windows.Forms.NumericUpDown();
            this.num_SpdPID_KI_5 = new System.Windows.Forms.NumericUpDown();
            this.num_SpdPID_KP_4 = new System.Windows.Forms.NumericUpDown();
            this.num_SpdPID_KI_4 = new System.Windows.Forms.NumericUpDown();
            this.num_SpdPID_KP_3 = new System.Windows.Forms.NumericUpDown();
            this.num_SpdPID_KD_5 = new System.Windows.Forms.NumericUpDown();
            this.num_SpdPID_KI_3 = new System.Windows.Forms.NumericUpDown();
            this.num_SpdPID_KD_4 = new System.Windows.Forms.NumericUpDown();
            this.num_SpdPID_KP_2 = new System.Windows.Forms.NumericUpDown();
            this.num_SpdPID_KI_2 = new System.Windows.Forms.NumericUpDown();
            this.num_SpdPID_KP_1 = new System.Windows.Forms.NumericUpDown();
            this.num_SpdPID_KI_1 = new System.Windows.Forms.NumericUpDown();
            this.num_SpdPID_KD_3 = new System.Windows.Forms.NumericUpDown();
            this.num_SpdPID_KP_0 = new System.Windows.Forms.NumericUpDown();
            this.num_SpdPID_KD_2 = new System.Windows.Forms.NumericUpDown();
            this.num_SpdPID_KI_0 = new System.Windows.Forms.NumericUpDown();
            this.num_SpdPID_KD_1 = new System.Windows.Forms.NumericUpDown();
            this.label85 = new System.Windows.Forms.Label();
            this.label86 = new System.Windows.Forms.Label();
            this.label87 = new System.Windows.Forms.Label();
            this.label88 = new System.Windows.Forms.Label();
            this.label89 = new System.Windows.Forms.Label();
            this.label90 = new System.Windows.Forms.Label();
            this.label91 = new System.Windows.Forms.Label();
            this.num_SpdPID_KD_0 = new System.Windows.Forms.NumericUpDown();
            this.groupBox14 = new System.Windows.Forms.GroupBox();
            this.label99 = new System.Windows.Forms.Label();
            this.label92 = new System.Windows.Forms.Label();
            this.num_SPD_Interval1_L = new System.Windows.Forms.NumericUpDown();
            this.num_SPD_Interval0_H = new System.Windows.Forms.NumericUpDown();
            this.num_SPD_Interval2_L = new System.Windows.Forms.NumericUpDown();
            this.num_SPD_Interval1_H = new System.Windows.Forms.NumericUpDown();
            this.num_SPD_Interval3_L = new System.Windows.Forms.NumericUpDown();
            this.num_SPD_Interval2_H = new System.Windows.Forms.NumericUpDown();
            this.num_SPD_Interval4_L = new System.Windows.Forms.NumericUpDown();
            this.num_SPD_Interval3_H = new System.Windows.Forms.NumericUpDown();
            this.num_SPD_Interval5_L = new System.Windows.Forms.NumericUpDown();
            this.num_SPD_Interval4_H = new System.Windows.Forms.NumericUpDown();
            this.label97 = new System.Windows.Forms.Label();
            this.label93 = new System.Windows.Forms.Label();
            this.label94 = new System.Windows.Forms.Label();
            this.label95 = new System.Windows.Forms.Label();
            this.label96 = new System.Windows.Forms.Label();
            this.label98 = new System.Windows.Forms.Label();
            this.PidCalc_Enable_checkBox1 = new System.Windows.Forms.CheckBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.label44 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.num_StartCurPID_KP = new System.Windows.Forms.NumericUpDown();
            this.num_StartCurPID_KI = new System.Windows.Forms.NumericUpDown();
            this.label49 = new System.Windows.Forms.Label();
            this.num_StartCurPID_KD = new System.Windows.Forms.NumericUpDown();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.num_ISQLimit = new System.Windows.Forms.NumericUpDown();
            this.label37 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.num_StartSpdPID_P = new System.Windows.Forms.NumericUpDown();
            this.num_StartSpdPID_I = new System.Windows.Forms.NumericUpDown();
            this.label43 = new System.Windows.Forms.Label();
            this.num_StartSpdPID_D = new System.Windows.Forms.NumericUpDown();
            this.groupBox15 = new System.Windows.Forms.GroupBox();
            this.groupBox16 = new System.Windows.Forms.GroupBox();
            this.richTextBox_Message = new System.Windows.Forms.RichTextBox();
            this.groupBox1.SuspendLayout();
            this.panel13.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.num_PolePair)).BeginInit();
            this.panel9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.num_Lq)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_Ld)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_Rs)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_maxFreq)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_minFreq)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_incUp)).BeginInit();
            this.groupBox7.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.panel12.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.num_PhaseCurLimit)).BeginInit();
            this.panel11.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.num_VacMin)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_VacMax)).BeginInit();
            this.panel10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.num_VbusMin)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_VbusMax)).BeginInit();
            this.groupBox9.SuspendLayout();
            this.groupBox10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.num_incDown)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBox11.SuspendLayout();
            this.panel8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.num_Freq_pwm)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_DeadTime)).BeginInit();
            this.panel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.num_V_Sample_K)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_I_Sample_K)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.groupBox18.SuspendLayout();
            this.panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.num_K_OmC_StartUp)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_K_THETA0_MAX)).BeginInit();
            this.groupBox6.SuspendLayout();
            this.panel16.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.num_E0_StartUp_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_Kslf_StartUp_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_Kslide_StartUp_2)).BeginInit();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.num_E0_StartUp_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_Kslf_StartUp_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_Kslide_StartUp_1)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.panel15.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.num_SynTime)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_SynSpd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_Accrate)).BeginInit();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.num_baseFreq)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_I_Start_Max)).BeginInit();
            this.panel14.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.num_Count_StartUp_ST4_ADD)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.num_CurStart_ST1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_CurStart_ST2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_Count_StartUp_ST2_ADD)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.num_CurStartOffset)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_Count_StartUp_ST3_ADD)).BeginInit();
            this.tabPage3.SuspendLayout();
            this.groupBox17.SuspendLayout();
            this.groupBox12.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.num_CurPID_KP_5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_CurPID_KI_5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_CurPID_KP_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_CurPID_KI_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_CurPID_KP_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_CurPID_KD_5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_CurPID_KI_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_CurPID_KD_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_CurPID_KP_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_CurPID_KI_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_CurPID_KP_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_CurPID_KI_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_CurPID_KD_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_CurPID_KP_0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_CurPID_KD_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_CurPID_KI_0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_CurPID_KD_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_CurPID_KD_0)).BeginInit();
            this.groupBox13.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.num_SpdPID_KP_5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_SpdPID_KI_5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_SpdPID_KP_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_SpdPID_KI_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_SpdPID_KP_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_SpdPID_KD_5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_SpdPID_KI_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_SpdPID_KD_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_SpdPID_KP_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_SpdPID_KI_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_SpdPID_KP_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_SpdPID_KI_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_SpdPID_KD_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_SpdPID_KP_0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_SpdPID_KD_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_SpdPID_KI_0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_SpdPID_KD_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_SpdPID_KD_0)).BeginInit();
            this.groupBox14.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.num_SPD_Interval1_L)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_SPD_Interval0_H)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_SPD_Interval2_L)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_SPD_Interval1_H)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_SPD_Interval3_L)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_SPD_Interval2_H)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_SPD_Interval4_L)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_SPD_Interval3_H)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_SPD_Interval5_L)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_SPD_Interval4_H)).BeginInit();
            this.groupBox5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.num_StartCurPID_KP)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_StartCurPID_KI)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_StartCurPID_KD)).BeginInit();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.num_ISQLimit)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_StartSpdPID_P)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_StartSpdPID_I)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_StartSpdPID_D)).BeginInit();
            this.groupBox15.SuspendLayout();
            this.groupBox16.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.panel13);
            this.groupBox1.Controls.Add(this.panel9);
            this.groupBox1.Location = new System.Drawing.Point(7, 6);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(320, 196);
            this.groupBox1.TabIndex = 9;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Motor Parameter Settings";
            // 
            // panel13
            // 
            this.panel13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel13.Controls.Add(this.label4);
            this.panel13.Controls.Add(this.num_PolePair);
            this.panel13.Location = new System.Drawing.Point(7, 131);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(302, 49);
            this.panel13.TabIndex = 39;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 16);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(50, 12);
            this.label4.TabIndex = 0;
            this.label4.Text = "Pole Pairs";
            // 
            // num_PolePair
            // 
            this.num_PolePair.Location = new System.Drawing.Point(144, 14);
            this.num_PolePair.Name = "num_PolePair";
            this.num_PolePair.Size = new System.Drawing.Size(101, 22);
            this.num_PolePair.TabIndex = 1;
            this.num_PolePair.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.num_PolePair.ValueChanged += new System.EventHandler(this.numic_ValueChanged);
            // 
            // panel9
            // 
            this.panel9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel9.Controls.Add(this.label1);
            this.panel9.Controls.Add(this.num_Lq);
            this.panel9.Controls.Add(this.label10);
            this.panel9.Controls.Add(this.num_Ld);
            this.panel9.Controls.Add(this.label18);
            this.panel9.Controls.Add(this.num_Rs);
            this.panel9.Controls.Add(this.label33);
            this.panel9.Controls.Add(this.label2);
            this.panel9.Controls.Add(this.label3);
            this.panel9.Location = new System.Drawing.Point(7, 21);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(302, 104);
            this.panel9.TabIndex = 40;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(10, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(112, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "Stator Resistance ( Rs )";
            // 
            // num_Lq
            // 
            this.num_Lq.DecimalPlaces = 2;
            this.num_Lq.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.num_Lq.Location = new System.Drawing.Point(142, 69);
            this.num_Lq.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.num_Lq.Name = "num_Lq";
            this.num_Lq.Size = new System.Drawing.Size(101, 22);
            this.num_Lq.TabIndex = 1;
            this.num_Lq.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.num_Lq.ValueChanged += new System.EventHandler(this.numic_ValueChanged);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(257, 16);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(26, 12);
            this.label10.TabIndex = 0;
            this.label10.Text = "ohm";
            // 
            // num_Ld
            // 
            this.num_Ld.DecimalPlaces = 2;
            this.num_Ld.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.num_Ld.Location = new System.Drawing.Point(142, 41);
            this.num_Ld.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.num_Ld.Name = "num_Ld";
            this.num_Ld.Size = new System.Drawing.Size(101, 22);
            this.num_Ld.TabIndex = 1;
            this.num_Ld.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.num_Ld.ValueChanged += new System.EventHandler(this.numic_ValueChanged);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(257, 43);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(22, 12);
            this.label18.TabIndex = 0;
            this.label18.Text = "mH";
            // 
            // num_Rs
            // 
            this.num_Rs.DecimalPlaces = 2;
            this.num_Rs.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.num_Rs.Location = new System.Drawing.Point(142, 13);
            this.num_Rs.Maximum = new decimal(new int[] {
            400,
            0,
            0,
            0});
            this.num_Rs.Name = "num_Rs";
            this.num_Rs.Size = new System.Drawing.Size(101, 22);
            this.num_Rs.TabIndex = 1;
            this.num_Rs.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.num_Rs.ValueChanged += new System.EventHandler(this.numic_ValueChanged);
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(257, 71);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(22, 12);
            this.label33.TabIndex = 0;
            this.label33.Text = "mH";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(10, 41);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(119, 12);
            this.label2.TabIndex = 0;
            this.label2.Text = "d Axis Inductance ( Ld )";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(10, 71);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(119, 12);
            this.label3.TabIndex = 0;
            this.label3.Text = "q Axis Inductance ( Lq )";
            // 
            // num_maxFreq
            // 
            this.num_maxFreq.Location = new System.Drawing.Point(138, 27);
            this.num_maxFreq.Name = "num_maxFreq";
            this.num_maxFreq.Size = new System.Drawing.Size(101, 22);
            this.num_maxFreq.TabIndex = 1;
            this.num_maxFreq.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.num_maxFreq.ValueChanged += new System.EventHandler(this.numic_ValueChanged);
            // 
            // num_minFreq
            // 
            this.num_minFreq.Location = new System.Drawing.Point(138, 55);
            this.num_minFreq.Name = "num_minFreq";
            this.num_minFreq.Size = new System.Drawing.Size(101, 22);
            this.num_minFreq.TabIndex = 1;
            this.num_minFreq.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.num_minFreq.ValueChanged += new System.EventHandler(this.numic_ValueChanged);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(253, 60);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(19, 12);
            this.label19.TabIndex = 0;
            this.label19.Text = "rps";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(253, 32);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(19, 12);
            this.label32.TabIndex = 0;
            this.label32.Text = "rps";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(6, 55);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(89, 12);
            this.label6.TabIndex = 0;
            this.label6.Text = "Min. Speed ( rps )";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(6, 27);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(91, 12);
            this.label7.TabIndex = 0;
            this.label7.Text = "Max. Speed ( rps )";
            // 
            // num_incUp
            // 
            this.num_incUp.DecimalPlaces = 2;
            this.num_incUp.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.num_incUp.Location = new System.Drawing.Point(140, 27);
            this.num_incUp.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.num_incUp.Name = "num_incUp";
            this.num_incUp.Size = new System.Drawing.Size(101, 22);
            this.num_incUp.TabIndex = 1;
            this.num_incUp.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.num_incUp.ValueChanged += new System.EventHandler(this.numic_ValueChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(8, 27);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(92, 12);
            this.label9.TabIndex = 0;
            this.label9.Text = "Acceleration Slope";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(255, 32);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(42, 12);
            this.label35.TabIndex = 0;
            this.label35.Text = "rps / sec";
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.Read_efd_button);
            this.groupBox7.Controls.Add(this.Write_efd_button);
            this.groupBox7.Location = new System.Drawing.Point(872, 494);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(229, 97);
            this.groupBox7.TabIndex = 13;
            this.groupBox7.TabStop = false;
            // 
            // Read_efd_button
            // 
            this.Read_efd_button.Image = global::CS6257_Monitor.Resource1._1431442199_memory;
            this.Read_efd_button.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Read_efd_button.Location = new System.Drawing.Point(112, 21);
            this.Read_efd_button.Name = "Read_efd_button";
            this.Read_efd_button.Size = new System.Drawing.Size(100, 53);
            this.Read_efd_button.TabIndex = 0;
            this.Read_efd_button.Text = "Read";
            this.Read_efd_button.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.Read_efd_button.UseVisualStyleBackColor = true;
            this.Read_efd_button.Click += new System.EventHandler(this.Read_efd_button_Click);
            // 
            // Write_efd_button
            // 
            this.Write_efd_button.Image = global::CS6257_Monitor.Resource1._1431442199_memory;
            this.Write_efd_button.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Write_efd_button.Location = new System.Drawing.Point(6, 21);
            this.Write_efd_button.Name = "Write_efd_button";
            this.Write_efd_button.Size = new System.Drawing.Size(100, 53);
            this.Write_efd_button.TabIndex = 0;
            this.Write_efd_button.Text = "Write";
            this.Write_efd_button.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.Write_efd_button.UseVisualStyleBackColor = true;
            this.Write_efd_button.Click += new System.EventHandler(this.Write_efd_button_Click);
            // 
            // SaveFile_button
            // 
            this.SaveFile_button.BackgroundImage = global::CS6257_Monitor.Resource1._1431440241_save;
            this.SaveFile_button.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.SaveFile_button.Location = new System.Drawing.Point(102, 21);
            this.SaveFile_button.Name = "SaveFile_button";
            this.SaveFile_button.Size = new System.Drawing.Size(75, 53);
            this.SaveFile_button.TabIndex = 1;
            this.SaveFile_button.UseVisualStyleBackColor = true;
            this.SaveFile_button.Click += new System.EventHandler(this.SaveFile_button_Click);
            // 
            // OpenFile_button
            // 
            this.OpenFile_button.BackgroundImage = global::CS6257_Monitor.Resource1._1431440286_folder_open;
            this.OpenFile_button.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.OpenFile_button.Location = new System.Drawing.Point(17, 21);
            this.OpenFile_button.Name = "OpenFile_button";
            this.OpenFile_button.Size = new System.Drawing.Size(75, 53);
            this.OpenFile_button.TabIndex = 1;
            this.OpenFile_button.UseVisualStyleBackColor = true;
            this.OpenFile_button.Click += new System.EventHandler(this.OpenFile_button_Click);
            // 
            // Update_button
            // 
            this.Update_button.BackgroundImage = global::CS6257_Monitor.Resource1._1431440170_file_download_red;
            this.Update_button.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.Update_button.Location = new System.Drawing.Point(264, 21);
            this.Update_button.Name = "Update_button";
            this.Update_button.Size = new System.Drawing.Size(75, 53);
            this.Update_button.TabIndex = 0;
            this.Update_button.UseVisualStyleBackColor = true;
            this.Update_button.Click += new System.EventHandler(this.Update_button_Click);
            // 
            // Reload_button
            // 
            this.Reload_button.BackgroundImage = global::CS6257_Monitor.Resource1._1431440216_file_upload;
            this.Reload_button.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.Reload_button.Location = new System.Drawing.Point(183, 21);
            this.Reload_button.Name = "Reload_button";
            this.Reload_button.Size = new System.Drawing.Size(75, 53);
            this.Reload_button.TabIndex = 0;
            this.Reload_button.UseVisualStyleBackColor = true;
            this.Reload_button.Click += new System.EventHandler(this.Reload_button_Click);
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.panel12);
            this.groupBox8.Controls.Add(this.panel11);
            this.groupBox8.Controls.Add(this.panel10);
            this.groupBox8.Location = new System.Drawing.Point(7, 204);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(320, 235);
            this.groupBox8.TabIndex = 11;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Protect Parameter Settings";
            // 
            // panel12
            // 
            this.panel12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel12.Controls.Add(this.label56);
            this.panel12.Controls.Add(this.num_PhaseCurLimit);
            this.panel12.Controls.Add(this.label53);
            this.panel12.Location = new System.Drawing.Point(7, 17);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(303, 52);
            this.panel12.TabIndex = 39;
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Location = new System.Drawing.Point(12, 18);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(120, 12);
            this.label56.TabIndex = 0;
            this.label56.Text = "Phase Current Limit  (A)";
            // 
            // num_PhaseCurLimit
            // 
            this.num_PhaseCurLimit.DecimalPlaces = 2;
            this.num_PhaseCurLimit.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.num_PhaseCurLimit.Location = new System.Drawing.Point(147, 13);
            this.num_PhaseCurLimit.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.num_PhaseCurLimit.Name = "num_PhaseCurLimit";
            this.num_PhaseCurLimit.Size = new System.Drawing.Size(101, 22);
            this.num_PhaseCurLimit.TabIndex = 1;
            this.num_PhaseCurLimit.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.num_PhaseCurLimit.ValueChanged += new System.EventHandler(this.numic_ValueChanged);
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Location = new System.Drawing.Point(262, 18);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(13, 12);
            this.label53.TabIndex = 0;
            this.label53.Text = "A";
            // 
            // panel11
            // 
            this.panel11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel11.Controls.Add(this.num_VacMin);
            this.panel11.Controls.Add(this.label58);
            this.panel11.Controls.Add(this.num_VacMax);
            this.panel11.Controls.Add(this.label59);
            this.panel11.Controls.Add(this.label60);
            this.panel11.Controls.Add(this.label61);
            this.panel11.Location = new System.Drawing.Point(7, 153);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(303, 75);
            this.panel11.TabIndex = 41;
            // 
            // num_VacMin
            // 
            this.num_VacMin.Location = new System.Drawing.Point(147, 41);
            this.num_VacMin.Maximum = new decimal(new int[] {
            500,
            0,
            0,
            0});
            this.num_VacMin.Name = "num_VacMin";
            this.num_VacMin.Size = new System.Drawing.Size(101, 22);
            this.num_VacMin.TabIndex = 1;
            this.num_VacMin.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.num_VacMin.ValueChanged += new System.EventHandler(this.numic_ValueChanged);
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Location = new System.Drawing.Point(15, 13);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(74, 12);
            this.label58.TabIndex = 0;
            this.label58.Text = "Max. AC Volt.";
            // 
            // num_VacMax
            // 
            this.num_VacMax.Location = new System.Drawing.Point(147, 13);
            this.num_VacMax.Maximum = new decimal(new int[] {
            500,
            0,
            0,
            0});
            this.num_VacMax.Name = "num_VacMax";
            this.num_VacMax.Size = new System.Drawing.Size(101, 22);
            this.num_VacMax.TabIndex = 1;
            this.num_VacMax.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.num_VacMax.ValueChanged += new System.EventHandler(this.numic_ValueChanged);
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Location = new System.Drawing.Point(262, 15);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(13, 12);
            this.label59.TabIndex = 0;
            this.label59.Text = "V";
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Location = new System.Drawing.Point(262, 43);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(13, 12);
            this.label60.TabIndex = 0;
            this.label60.Text = "V";
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Location = new System.Drawing.Point(15, 41);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(72, 12);
            this.label61.TabIndex = 0;
            this.label61.Text = "Min. AC Volt.";
            // 
            // panel10
            // 
            this.panel10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel10.Controls.Add(this.label42);
            this.panel10.Controls.Add(this.label52);
            this.panel10.Controls.Add(this.num_VbusMin);
            this.panel10.Controls.Add(this.label51);
            this.panel10.Controls.Add(this.num_VbusMax);
            this.panel10.Controls.Add(this.label41);
            this.panel10.Location = new System.Drawing.Point(7, 74);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(303, 75);
            this.panel10.TabIndex = 40;
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(15, 15);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(74, 12);
            this.label42.TabIndex = 0;
            this.label42.Text = "Max. DC Volt.";
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Location = new System.Drawing.Point(262, 20);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(13, 12);
            this.label52.TabIndex = 0;
            this.label52.Text = "V";
            // 
            // num_VbusMin
            // 
            this.num_VbusMin.Location = new System.Drawing.Point(147, 43);
            this.num_VbusMin.Maximum = new decimal(new int[] {
            500,
            0,
            0,
            0});
            this.num_VbusMin.Name = "num_VbusMin";
            this.num_VbusMin.Size = new System.Drawing.Size(101, 22);
            this.num_VbusMin.TabIndex = 1;
            this.num_VbusMin.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.num_VbusMin.ValueChanged += new System.EventHandler(this.numic_ValueChanged);
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Location = new System.Drawing.Point(262, 48);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(13, 12);
            this.label51.TabIndex = 0;
            this.label51.Text = "V";
            // 
            // num_VbusMax
            // 
            this.num_VbusMax.Location = new System.Drawing.Point(147, 15);
            this.num_VbusMax.Maximum = new decimal(new int[] {
            500,
            0,
            0,
            0});
            this.num_VbusMax.Name = "num_VbusMax";
            this.num_VbusMax.Size = new System.Drawing.Size(101, 22);
            this.num_VbusMax.TabIndex = 1;
            this.num_VbusMax.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.num_VbusMax.ValueChanged += new System.EventHandler(this.numic_ValueChanged);
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(15, 43);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(72, 12);
            this.label41.TabIndex = 0;
            this.label41.Text = "Min. DC Volt.";
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.groupBox10);
            this.groupBox9.Controls.Add(this.groupBox3);
            this.groupBox9.Location = new System.Drawing.Point(338, 6);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(679, 139);
            this.groupBox9.TabIndex = 37;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Speed  Control Settings";
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.num_incUp);
            this.groupBox10.Controls.Add(this.label9);
            this.groupBox10.Controls.Add(this.label54);
            this.groupBox10.Controls.Add(this.num_incDown);
            this.groupBox10.Controls.Add(this.label55);
            this.groupBox10.Controls.Add(this.label35);
            this.groupBox10.Location = new System.Drawing.Point(329, 29);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(317, 97);
            this.groupBox10.TabIndex = 39;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "Speed Ramp";
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Location = new System.Drawing.Point(8, 55);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(92, 12);
            this.label54.TabIndex = 0;
            this.label54.Text = "Deceleration Slope";
            // 
            // num_incDown
            // 
            this.num_incDown.DecimalPlaces = 2;
            this.num_incDown.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.num_incDown.Location = new System.Drawing.Point(140, 55);
            this.num_incDown.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.num_incDown.Name = "num_incDown";
            this.num_incDown.Size = new System.Drawing.Size(101, 22);
            this.num_incDown.TabIndex = 1;
            this.num_incDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.num_incDown.ValueChanged += new System.EventHandler(this.numic_ValueChanged);
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Location = new System.Drawing.Point(255, 60);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(42, 12);
            this.label55.TabIndex = 0;
            this.label55.Text = "rps / sec";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label7);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Controls.Add(this.num_minFreq);
            this.groupBox3.Controls.Add(this.label32);
            this.groupBox3.Controls.Add(this.label19);
            this.groupBox3.Controls.Add(this.num_maxFreq);
            this.groupBox3.Location = new System.Drawing.Point(6, 26);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(317, 100);
            this.groupBox3.TabIndex = 38;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Speed Limit";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Location = new System.Drawing.Point(6, 3);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1100, 485);
            this.tabControl1.TabIndex = 38;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.groupBox11);
            this.tabPage1.Controls.Add(this.groupBox1);
            this.tabPage1.Controls.Add(this.groupBox9);
            this.tabPage1.Controls.Add(this.groupBox8);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1092, 459);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Basic";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.panel8);
            this.groupBox11.Controls.Add(this.panel7);
            this.groupBox11.Location = new System.Drawing.Point(338, 151);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(570, 136);
            this.groupBox11.TabIndex = 38;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "Hardware Parameter Settings";
            // 
            // panel8
            // 
            this.panel8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel8.Controls.Add(this.num_Freq_pwm);
            this.panel8.Controls.Add(this.label66);
            this.panel8.Controls.Add(this.num_DeadTime);
            this.panel8.Controls.Add(this.label67);
            this.panel8.Location = new System.Drawing.Point(287, 21);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(264, 100);
            this.panel8.TabIndex = 7;
            // 
            // num_Freq_pwm
            // 
            this.num_Freq_pwm.DecimalPlaces = 1;
            this.num_Freq_pwm.Location = new System.Drawing.Point(144, 17);
            this.num_Freq_pwm.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.num_Freq_pwm.Name = "num_Freq_pwm";
            this.num_Freq_pwm.Size = new System.Drawing.Size(101, 22);
            this.num_Freq_pwm.TabIndex = 3;
            this.num_Freq_pwm.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Location = new System.Drawing.Point(18, 17);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(87, 12);
            this.label66.TabIndex = 2;
            this.label66.Text = "PWM freq. (kHz)";
            // 
            // num_DeadTime
            // 
            this.num_DeadTime.Location = new System.Drawing.Point(144, 45);
            this.num_DeadTime.Name = "num_DeadTime";
            this.num_DeadTime.Size = new System.Drawing.Size(101, 22);
            this.num_DeadTime.TabIndex = 3;
            this.num_DeadTime.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Location = new System.Drawing.Point(18, 47);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(77, 12);
            this.label67.TabIndex = 2;
            this.label67.Text = "Dead Time (us)";
            // 
            // panel7
            // 
            this.panel7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel7.Controls.Add(this.label65);
            this.panel7.Controls.Add(this.comboBox2);
            this.panel7.Controls.Add(this.label62);
            this.panel7.Controls.Add(this.num_V_Sample_K);
            this.panel7.Controls.Add(this.label63);
            this.panel7.Controls.Add(this.num_I_Sample_K);
            this.panel7.Location = new System.Drawing.Point(14, 21);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(264, 100);
            this.panel7.TabIndex = 6;
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Location = new System.Drawing.Point(15, 10);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(93, 12);
            this.label65.TabIndex = 4;
            this.label65.Text = "Cur. Sample Mode";
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(141, 7);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(101, 20);
            this.comboBox2.TabIndex = 5;
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Location = new System.Drawing.Point(15, 43);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(90, 12);
            this.label62.TabIndex = 2;
            this.label62.Text = "Volt. Sample Gain";
            // 
            // num_V_Sample_K
            // 
            this.num_V_Sample_K.Location = new System.Drawing.Point(141, 41);
            this.num_V_Sample_K.Maximum = new decimal(new int[] {
            32768,
            0,
            0,
            0});
            this.num_V_Sample_K.Name = "num_V_Sample_K";
            this.num_V_Sample_K.Size = new System.Drawing.Size(101, 22);
            this.num_V_Sample_K.TabIndex = 3;
            this.num_V_Sample_K.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Location = new System.Drawing.Point(15, 72);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(103, 12);
            this.label63.TabIndex = 2;
            this.label63.Text = "Current Sample Gain";
            // 
            // num_I_Sample_K
            // 
            this.num_I_Sample_K.Location = new System.Drawing.Point(141, 69);
            this.num_I_Sample_K.Maximum = new decimal(new int[] {
            32768,
            0,
            0,
            0});
            this.num_I_Sample_K.Name = "num_I_Sample_K";
            this.num_I_Sample_K.Size = new System.Drawing.Size(101, 22);
            this.num_I_Sample_K.TabIndex = 3;
            this.num_I_Sample_K.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.groupBox18);
            this.tabPage2.Controls.Add(this.groupBox6);
            this.tabPage2.Controls.Add(this.groupBox2);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1092, 459);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Sensorless";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // groupBox18
            // 
            this.groupBox18.Controls.Add(this.panel6);
            this.groupBox18.Location = new System.Drawing.Point(448, 207);
            this.groupBox18.Name = "groupBox18";
            this.groupBox18.Size = new System.Drawing.Size(408, 133);
            this.groupBox18.TabIndex = 44;
            this.groupBox18.TabStop = false;
            this.groupBox18.Text = "Filter Setting";
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.comboBox_FilterSelected);
            this.panel6.Controls.Add(this.num_K_OmC_StartUp);
            this.panel6.Controls.Add(this.label46);
            this.panel6.Controls.Add(this.label57);
            this.panel6.Controls.Add(this.num_K_THETA0_MAX);
            this.panel6.Controls.Add(this.label64);
            this.panel6.Location = new System.Drawing.Point(14, 21);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(386, 100);
            this.panel6.TabIndex = 43;
            // 
            // comboBox_FilterSelected
            // 
            this.comboBox_FilterSelected.FormattingEnabled = true;
            this.comboBox_FilterSelected.Items.AddRange(new object[] {
            "None",
            "Butterworth Filter",
            "Kalman Filter"});
            this.comboBox_FilterSelected.Location = new System.Drawing.Point(16, 46);
            this.comboBox_FilterSelected.Name = "comboBox_FilterSelected";
            this.comboBox_FilterSelected.Size = new System.Drawing.Size(101, 20);
            this.comboBox_FilterSelected.TabIndex = 2;
            // 
            // num_K_OmC_StartUp
            // 
            this.num_K_OmC_StartUp.DecimalPlaces = 1;
            this.num_K_OmC_StartUp.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.num_K_OmC_StartUp.Location = new System.Drawing.Point(138, 47);
            this.num_K_OmC_StartUp.Maximum = new decimal(new int[] {
            400,
            0,
            0,
            0});
            this.num_K_OmC_StartUp.Name = "num_K_OmC_StartUp";
            this.num_K_OmC_StartUp.Size = new System.Drawing.Size(101, 22);
            this.num_K_OmC_StartUp.TabIndex = 1;
            this.num_K_OmC_StartUp.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(136, 24);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(85, 12);
            this.label46.TabIndex = 0;
            this.label46.Text = "Cutoff freq. (Hz)";
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Location = new System.Drawing.Point(14, 24);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(59, 12);
            this.label57.TabIndex = 0;
            this.label57.Text = "Filter Select";
            // 
            // num_K_THETA0_MAX
            // 
            this.num_K_THETA0_MAX.DecimalPlaces = 2;
            this.num_K_THETA0_MAX.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.num_K_THETA0_MAX.Location = new System.Drawing.Point(260, 47);
            this.num_K_THETA0_MAX.Name = "num_K_THETA0_MAX";
            this.num_K_THETA0_MAX.Size = new System.Drawing.Size(101, 22);
            this.num_K_THETA0_MAX.TabIndex = 1;
            this.num_K_THETA0_MAX.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Location = new System.Drawing.Point(258, 24);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(126, 12);
            this.label64.TabIndex = 0;
            this.label64.Text = "Phase Compensation Gain";
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.panel16);
            this.groupBox6.Controls.Add(this.panel5);
            this.groupBox6.Location = new System.Drawing.Point(6, 206);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(436, 232);
            this.groupBox6.TabIndex = 40;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Sliding Mode Estimator Parameter Settings";
            // 
            // panel16
            // 
            this.panel16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel16.Controls.Add(this.label25);
            this.panel16.Controls.Add(this.num_E0_StartUp_2);
            this.panel16.Controls.Add(this.num_Kslf_StartUp_2);
            this.panel16.Controls.Add(this.label27);
            this.panel16.Controls.Add(this.label26);
            this.panel16.Controls.Add(this.label48);
            this.panel16.Controls.Add(this.num_Kslide_StartUp_2);
            this.panel16.Location = new System.Drawing.Point(19, 128);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(392, 95);
            this.panel16.TabIndex = 3;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(20, 40);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(40, 12);
            this.label25.TabIndex = 0;
            this.label25.Text = "Kslide2";
            // 
            // num_E0_StartUp_2
            // 
            this.num_E0_StartUp_2.DecimalPlaces = 5;
            this.num_E0_StartUp_2.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.num_E0_StartUp_2.Location = new System.Drawing.Point(265, 55);
            this.num_E0_StartUp_2.Name = "num_E0_StartUp_2";
            this.num_E0_StartUp_2.Size = new System.Drawing.Size(101, 22);
            this.num_E0_StartUp_2.TabIndex = 1;
            this.num_E0_StartUp_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // num_Kslf_StartUp_2
            // 
            this.num_Kslf_StartUp_2.DecimalPlaces = 5;
            this.num_Kslf_StartUp_2.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.num_Kslf_StartUp_2.Location = new System.Drawing.Point(141, 55);
            this.num_Kslf_StartUp_2.Name = "num_Kslf_StartUp_2";
            this.num_Kslf_StartUp_2.Size = new System.Drawing.Size(101, 22);
            this.num_Kslf_StartUp_2.TabIndex = 1;
            this.num_Kslf_StartUp_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(265, 40);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(30, 12);
            this.label27.TabIndex = 0;
            this.label27.Text = "E0_2";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(142, 40);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(33, 12);
            this.label26.TabIndex = 0;
            this.label26.Text = "Kslif2";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(15, 18);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(128, 12);
            this.label48.TabIndex = 0;
            this.label48.Text = "Operation Stage Parameter";
            // 
            // num_Kslide_StartUp_2
            // 
            this.num_Kslide_StartUp_2.DecimalPlaces = 5;
            this.num_Kslide_StartUp_2.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.num_Kslide_StartUp_2.Location = new System.Drawing.Point(20, 55);
            this.num_Kslide_StartUp_2.Name = "num_Kslide_StartUp_2";
            this.num_Kslide_StartUp_2.Size = new System.Drawing.Size(101, 22);
            this.num_Kslide_StartUp_2.TabIndex = 1;
            this.num_Kslide_StartUp_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // panel5
            // 
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel5.Controls.Add(this.label24);
            this.panel5.Controls.Add(this.label29);
            this.panel5.Controls.Add(this.num_E0_StartUp_1);
            this.panel5.Controls.Add(this.num_Kslf_StartUp_1);
            this.panel5.Controls.Add(this.label28);
            this.panel5.Controls.Add(this.label47);
            this.panel5.Controls.Add(this.num_Kslide_StartUp_1);
            this.panel5.Location = new System.Drawing.Point(19, 28);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(392, 94);
            this.panel5.TabIndex = 2;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(20, 40);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(40, 12);
            this.label24.TabIndex = 0;
            this.label24.Text = "Kslide1";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(265, 40);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(30, 12);
            this.label29.TabIndex = 0;
            this.label29.Text = "E0_1";
            // 
            // num_E0_StartUp_1
            // 
            this.num_E0_StartUp_1.DecimalPlaces = 5;
            this.num_E0_StartUp_1.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.num_E0_StartUp_1.Location = new System.Drawing.Point(265, 55);
            this.num_E0_StartUp_1.Name = "num_E0_StartUp_1";
            this.num_E0_StartUp_1.Size = new System.Drawing.Size(101, 22);
            this.num_E0_StartUp_1.TabIndex = 1;
            this.num_E0_StartUp_1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // num_Kslf_StartUp_1
            // 
            this.num_Kslf_StartUp_1.DecimalPlaces = 5;
            this.num_Kslf_StartUp_1.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.num_Kslf_StartUp_1.Location = new System.Drawing.Point(142, 55);
            this.num_Kslf_StartUp_1.Name = "num_Kslf_StartUp_1";
            this.num_Kslf_StartUp_1.Size = new System.Drawing.Size(101, 22);
            this.num_Kslf_StartUp_1.TabIndex = 1;
            this.num_Kslf_StartUp_1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(142, 40);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(33, 12);
            this.label28.TabIndex = 0;
            this.label28.Text = "Kslif1";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(18, 17);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(117, 12);
            this.label47.TabIndex = 0;
            this.label47.Text = "StartUp Stage Parameter";
            // 
            // num_Kslide_StartUp_1
            // 
            this.num_Kslide_StartUp_1.DecimalPlaces = 5;
            this.num_Kslide_StartUp_1.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.num_Kslide_StartUp_1.Location = new System.Drawing.Point(20, 55);
            this.num_Kslide_StartUp_1.Name = "num_Kslide_StartUp_1";
            this.num_Kslide_StartUp_1.Size = new System.Drawing.Size(101, 22);
            this.num_Kslide_StartUp_1.TabIndex = 1;
            this.num_Kslide_StartUp_1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.panel15);
            this.groupBox2.Controls.Add(this.panel4);
            this.groupBox2.Controls.Add(this.panel14);
            this.groupBox2.Controls.Add(this.panel3);
            this.groupBox2.Controls.Add(this.panel2);
            this.groupBox2.Controls.Add(this.panel1);
            this.groupBox2.Location = new System.Drawing.Point(6, 6);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(1080, 195);
            this.groupBox2.TabIndex = 39;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Motor StartUp Settings";
            // 
            // panel15
            // 
            this.panel15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel15.Controls.Add(this.num_SynTime);
            this.panel15.Controls.Add(this.num_SynSpd);
            this.panel15.Controls.Add(this.num_Accrate);
            this.panel15.Controls.Add(this.label71);
            this.panel15.Controls.Add(this.label50);
            this.panel15.Controls.Add(this.label73);
            this.panel15.Controls.Add(this.label72);
            this.panel15.Controls.Add(this.label70);
            this.panel15.Controls.Add(this.label69);
            this.panel15.Location = new System.Drawing.Point(529, 66);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(255, 123);
            this.panel15.TabIndex = 22;
            // 
            // num_SynTime
            // 
            this.num_SynTime.Location = new System.Drawing.Point(142, 70);
            this.num_SynTime.Maximum = new decimal(new int[] {
            65535,
            0,
            0,
            0});
            this.num_SynTime.Name = "num_SynTime";
            this.num_SynTime.Size = new System.Drawing.Size(70, 22);
            this.num_SynTime.TabIndex = 1;
            this.num_SynTime.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // num_SynSpd
            // 
            this.num_SynSpd.DecimalPlaces = 1;
            this.num_SynSpd.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.num_SynSpd.Location = new System.Drawing.Point(142, 41);
            this.num_SynSpd.Maximum = new decimal(new int[] {
            40,
            0,
            0,
            0});
            this.num_SynSpd.Name = "num_SynSpd";
            this.num_SynSpd.Size = new System.Drawing.Size(70, 22);
            this.num_SynSpd.TabIndex = 1;
            this.num_SynSpd.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // num_Accrate
            // 
            this.num_Accrate.DecimalPlaces = 1;
            this.num_Accrate.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.num_Accrate.Location = new System.Drawing.Point(142, 13);
            this.num_Accrate.Maximum = new decimal(new int[] {
            40,
            0,
            0,
            0});
            this.num_Accrate.Name = "num_Accrate";
            this.num_Accrate.Size = new System.Drawing.Size(70, 22);
            this.num_Accrate.TabIndex = 1;
            this.num_Accrate.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.Location = new System.Drawing.Point(10, 75);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(123, 12);
            this.label71.TabIndex = 0;
            this.label71.Text = "Synchronous Time ( ms )";
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Location = new System.Drawing.Point(218, 19);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(32, 12);
            this.label50.TabIndex = 0;
            this.label50.Text = "rps / s";
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.Location = new System.Drawing.Point(225, 44);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(19, 12);
            this.label73.TabIndex = 0;
            this.label73.Text = "rps";
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.Location = new System.Drawing.Point(225, 75);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(18, 12);
            this.label72.TabIndex = 0;
            this.label72.Text = "ms";
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.Location = new System.Drawing.Point(10, 44);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(131, 12);
            this.label70.TabIndex = 0;
            this.label70.Text = "Synchronous Speed ( rps ) ";
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.Location = new System.Drawing.Point(10, 16);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(92, 12);
            this.label69.TabIndex = 0;
            this.label69.Text = "Acceleration Slope";
            // 
            // panel4
            // 
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel4.Controls.Add(this.label16);
            this.panel4.Controls.Add(this.label36);
            this.panel4.Controls.Add(this.num_baseFreq);
            this.panel4.Controls.Add(this.num_I_Start_Max);
            this.panel4.Controls.Add(this.label34);
            this.panel4.Controls.Add(this.label8);
            this.panel4.Location = new System.Drawing.Point(790, 114);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(254, 75);
            this.panel4.TabIndex = 20;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(10, 14);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(117, 12);
            this.label16.TabIndex = 0;
            this.label16.Text = "Max. Starting Cur. ( A )";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(225, 19);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(13, 12);
            this.label36.TabIndex = 0;
            this.label36.Text = "A";
            // 
            // num_baseFreq
            // 
            this.num_baseFreq.Location = new System.Drawing.Point(143, 42);
            this.num_baseFreq.Name = "num_baseFreq";
            this.num_baseFreq.Size = new System.Drawing.Size(70, 22);
            this.num_baseFreq.TabIndex = 15;
            this.num_baseFreq.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // num_I_Start_Max
            // 
            this.num_I_Start_Max.DecimalPlaces = 2;
            this.num_I_Start_Max.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.num_I_Start_Max.Location = new System.Drawing.Point(143, 14);
            this.num_I_Start_Max.Maximum = new decimal(new int[] {
            40,
            0,
            0,
            0});
            this.num_I_Start_Max.Name = "num_I_Start_Max";
            this.num_I_Start_Max.Size = new System.Drawing.Size(70, 22);
            this.num_I_Start_Max.TabIndex = 1;
            this.num_I_Start_Max.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(225, 47);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(19, 12);
            this.label34.TabIndex = 13;
            this.label34.Text = "rps";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(10, 43);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(131, 12);
            this.label8.TabIndex = 14;
            this.label8.Text = "Basic Starting Speed ( rps )";
            // 
            // panel14
            // 
            this.panel14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel14.Controls.Add(this.comboBox_StartUp_Mode);
            this.panel14.Controls.Add(this.label68);
            this.panel14.Location = new System.Drawing.Point(6, 22);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(1038, 38);
            this.panel14.TabIndex = 21;
            // 
            // comboBox_StartUp_Mode
            // 
            this.comboBox_StartUp_Mode.FormattingEnabled = true;
            this.comboBox_StartUp_Mode.Items.AddRange(new object[] {
            "Normal",
            "I/f StartUp (Debug)",
            "I/f StartUp",
            "I/f StartUp (Cur. Loop) "});
            this.comboBox_StartUp_Mode.Location = new System.Drawing.Point(107, 10);
            this.comboBox_StartUp_Mode.Name = "comboBox_StartUp_Mode";
            this.comboBox_StartUp_Mode.Size = new System.Drawing.Size(149, 20);
            this.comboBox_StartUp_Mode.TabIndex = 1;
            this.comboBox_StartUp_Mode.SelectedIndexChanged += new System.EventHandler(this.comboBox_SelectedIndexChanged);
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Location = new System.Drawing.Point(10, 13);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(70, 12);
            this.label68.TabIndex = 0;
            this.label68.Text = "StartUp Mode";
            // 
            // panel3
            // 
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.num_Count_StartUp_ST4_ADD);
            this.panel3.Controls.Add(this.label31);
            this.panel3.Controls.Add(this.label15);
            this.panel3.Location = new System.Drawing.Point(790, 66);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(254, 45);
            this.panel3.TabIndex = 18;
            // 
            // num_Count_StartUp_ST4_ADD
            // 
            this.num_Count_StartUp_ST4_ADD.Location = new System.Drawing.Point(142, 14);
            this.num_Count_StartUp_ST4_ADD.Maximum = new decimal(new int[] {
            1215752192,
            23,
            0,
            0});
            this.num_Count_StartUp_ST4_ADD.Name = "num_Count_StartUp_ST4_ADD";
            this.num_Count_StartUp_ST4_ADD.Size = new System.Drawing.Size(70, 22);
            this.num_Count_StartUp_ST4_ADD.TabIndex = 1;
            this.num_Count_StartUp_ST4_ADD.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(225, 19);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(18, 12);
            this.label31.TabIndex = 0;
            this.label31.Text = "ms";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(10, 19);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(93, 12);
            this.label15.TabIndex = 0;
            this.label15.Text = "Start-Time 4 ( ms )";
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.num_CurStart_ST1);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.label20);
            this.panel2.Controls.Add(this.label21);
            this.panel2.Controls.Add(this.label11);
            this.panel2.Controls.Add(this.num_CurStart_ST2);
            this.panel2.Controls.Add(this.num_Count_StartUp_ST2_ADD);
            this.panel2.Controls.Add(this.label13);
            this.panel2.Controls.Add(this.label23);
            this.panel2.Location = new System.Drawing.Point(6, 66);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(256, 123);
            this.panel2.TabIndex = 17;
            // 
            // num_CurStart_ST1
            // 
            this.num_CurStart_ST1.DecimalPlaces = 2;
            this.num_CurStart_ST1.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.num_CurStart_ST1.Location = new System.Drawing.Point(142, 14);
            this.num_CurStart_ST1.Maximum = new decimal(new int[] {
            40,
            0,
            0,
            0});
            this.num_CurStart_ST1.Name = "num_CurStart_ST1";
            this.num_CurStart_ST1.Size = new System.Drawing.Size(70, 22);
            this.num_CurStart_ST1.TabIndex = 1;
            this.num_CurStart_ST1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(10, 19);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(113, 12);
            this.label5.TabIndex = 0;
            this.label5.Text = "StartUp Current 1 ( A )";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(225, 19);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(13, 12);
            this.label20.TabIndex = 0;
            this.label20.Text = "A";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(225, 47);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(13, 12);
            this.label21.TabIndex = 0;
            this.label21.Text = "A";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(10, 47);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(113, 12);
            this.label11.TabIndex = 0;
            this.label11.Text = "StartUp Current 2 ( A )";
            // 
            // num_CurStart_ST2
            // 
            this.num_CurStart_ST2.DecimalPlaces = 2;
            this.num_CurStart_ST2.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.num_CurStart_ST2.Location = new System.Drawing.Point(142, 42);
            this.num_CurStart_ST2.Maximum = new decimal(new int[] {
            40,
            0,
            0,
            0});
            this.num_CurStart_ST2.Name = "num_CurStart_ST2";
            this.num_CurStart_ST2.Size = new System.Drawing.Size(70, 22);
            this.num_CurStart_ST2.TabIndex = 1;
            this.num_CurStart_ST2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // num_Count_StartUp_ST2_ADD
            // 
            this.num_Count_StartUp_ST2_ADD.Location = new System.Drawing.Point(142, 70);
            this.num_Count_StartUp_ST2_ADD.Maximum = new decimal(new int[] {
            1215752192,
            23,
            0,
            0});
            this.num_Count_StartUp_ST2_ADD.Name = "num_Count_StartUp_ST2_ADD";
            this.num_Count_StartUp_ST2_ADD.Size = new System.Drawing.Size(70, 22);
            this.num_Count_StartUp_ST2_ADD.TabIndex = 1;
            this.num_Count_StartUp_ST2_ADD.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(10, 75);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(93, 12);
            this.label13.TabIndex = 0;
            this.label13.Text = "Start-Time 2 ( ms )";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(225, 75);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(18, 12);
            this.label23.TabIndex = 0;
            this.label23.Text = "ms";
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.num_CurStartOffset);
            this.panel1.Controls.Add(this.label22);
            this.panel1.Controls.Add(this.label12);
            this.panel1.Controls.Add(this.label14);
            this.panel1.Controls.Add(this.label30);
            this.panel1.Controls.Add(this.num_Count_StartUp_ST3_ADD);
            this.panel1.Location = new System.Drawing.Point(267, 66);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(256, 123);
            this.panel1.TabIndex = 16;
            // 
            // num_CurStartOffset
            // 
            this.num_CurStartOffset.DecimalPlaces = 2;
            this.num_CurStartOffset.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.num_CurStartOffset.Location = new System.Drawing.Point(142, 13);
            this.num_CurStartOffset.Maximum = new decimal(new int[] {
            40,
            0,
            0,
            0});
            this.num_CurStartOffset.Name = "num_CurStartOffset";
            this.num_CurStartOffset.Size = new System.Drawing.Size(70, 22);
            this.num_CurStartOffset.TabIndex = 1;
            this.num_CurStartOffset.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(225, 18);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(13, 12);
            this.label22.TabIndex = 0;
            this.label22.Text = "A";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(10, 16);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(113, 12);
            this.label12.TabIndex = 0;
            this.label12.Text = "StartUp Current 3 ( A )";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(10, 44);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(93, 12);
            this.label14.TabIndex = 0;
            this.label14.Text = "Start-Time 3 ( ms )";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(225, 46);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(18, 12);
            this.label30.TabIndex = 0;
            this.label30.Text = "ms";
            // 
            // num_Count_StartUp_ST3_ADD
            // 
            this.num_Count_StartUp_ST3_ADD.Location = new System.Drawing.Point(142, 41);
            this.num_Count_StartUp_ST3_ADD.Maximum = new decimal(new int[] {
            1215752192,
            23,
            0,
            0});
            this.num_Count_StartUp_ST3_ADD.Name = "num_Count_StartUp_ST3_ADD";
            this.num_Count_StartUp_ST3_ADD.Size = new System.Drawing.Size(70, 22);
            this.num_Count_StartUp_ST3_ADD.TabIndex = 1;
            this.num_Count_StartUp_ST3_ADD.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.groupBox17);
            this.tabPage3.Controls.Add(this.groupBox5);
            this.tabPage3.Controls.Add(this.groupBox4);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(1092, 459);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "PID Parameter";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // groupBox17
            // 
            this.groupBox17.Controls.Add(this.groupBox12);
            this.groupBox17.Controls.Add(this.label40);
            this.groupBox17.Controls.Add(this.groupBox13);
            this.groupBox17.Controls.Add(this.groupBox14);
            this.groupBox17.Controls.Add(this.PidCalc_Enable_checkBox1);
            this.groupBox17.Location = new System.Drawing.Point(6, 144);
            this.groupBox17.Name = "groupBox17";
            this.groupBox17.Size = new System.Drawing.Size(1080, 309);
            this.groupBox17.TabIndex = 48;
            this.groupBox17.TabStop = false;
            this.groupBox17.Text = "PID 參數區間調整";
            // 
            // groupBox12
            // 
            this.groupBox12.Controls.Add(this.label74);
            this.groupBox12.Controls.Add(this.label75);
            this.groupBox12.Controls.Add(this.num_CurPID_KP_5);
            this.groupBox12.Controls.Add(this.num_CurPID_KI_5);
            this.groupBox12.Controls.Add(this.num_CurPID_KP_4);
            this.groupBox12.Controls.Add(this.num_CurPID_KI_4);
            this.groupBox12.Controls.Add(this.num_CurPID_KP_3);
            this.groupBox12.Controls.Add(this.num_CurPID_KD_5);
            this.groupBox12.Controls.Add(this.num_CurPID_KI_3);
            this.groupBox12.Controls.Add(this.num_CurPID_KD_4);
            this.groupBox12.Controls.Add(this.num_CurPID_KP_2);
            this.groupBox12.Controls.Add(this.num_CurPID_KI_2);
            this.groupBox12.Controls.Add(this.num_CurPID_KP_1);
            this.groupBox12.Controls.Add(this.num_CurPID_KI_1);
            this.groupBox12.Controls.Add(this.num_CurPID_KD_3);
            this.groupBox12.Controls.Add(this.num_CurPID_KP_0);
            this.groupBox12.Controls.Add(this.num_CurPID_KD_2);
            this.groupBox12.Controls.Add(this.num_CurPID_KI_0);
            this.groupBox12.Controls.Add(this.num_CurPID_KD_1);
            this.groupBox12.Controls.Add(this.label82);
            this.groupBox12.Controls.Add(this.label81);
            this.groupBox12.Controls.Add(this.label80);
            this.groupBox12.Controls.Add(this.label79);
            this.groupBox12.Controls.Add(this.label78);
            this.groupBox12.Controls.Add(this.label77);
            this.groupBox12.Controls.Add(this.label76);
            this.groupBox12.Controls.Add(this.num_CurPID_KD_0);
            this.groupBox12.Location = new System.Drawing.Point(132, 33);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Size = new System.Drawing.Size(341, 270);
            this.groupBox12.TabIndex = 43;
            this.groupBox12.TabStop = false;
            this.groupBox12.Text = "Current Loop Parameters";
            // 
            // label74
            // 
            this.label74.AutoSize = true;
            this.label74.Location = new System.Drawing.Point(232, 25);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(21, 12);
            this.label74.TabIndex = 0;
            this.label74.Text = "KD";
            // 
            // label75
            // 
            this.label75.AutoSize = true;
            this.label75.Location = new System.Drawing.Point(146, 25);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(17, 12);
            this.label75.TabIndex = 0;
            this.label75.Text = "KI";
            // 
            // num_CurPID_KP_5
            // 
            this.num_CurPID_KP_5.DecimalPlaces = 3;
            this.num_CurPID_KP_5.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.num_CurPID_KP_5.Location = new System.Drawing.Point(61, 240);
            this.num_CurPID_KP_5.Name = "num_CurPID_KP_5";
            this.num_CurPID_KP_5.Size = new System.Drawing.Size(81, 22);
            this.num_CurPID_KP_5.TabIndex = 1;
            this.num_CurPID_KP_5.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // num_CurPID_KI_5
            // 
            this.num_CurPID_KI_5.DecimalPlaces = 3;
            this.num_CurPID_KI_5.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.num_CurPID_KI_5.Location = new System.Drawing.Point(148, 240);
            this.num_CurPID_KI_5.Name = "num_CurPID_KI_5";
            this.num_CurPID_KI_5.Size = new System.Drawing.Size(81, 22);
            this.num_CurPID_KI_5.TabIndex = 1;
            this.num_CurPID_KI_5.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // num_CurPID_KP_4
            // 
            this.num_CurPID_KP_4.DecimalPlaces = 3;
            this.num_CurPID_KP_4.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.num_CurPID_KP_4.Location = new System.Drawing.Point(61, 200);
            this.num_CurPID_KP_4.Name = "num_CurPID_KP_4";
            this.num_CurPID_KP_4.Size = new System.Drawing.Size(81, 22);
            this.num_CurPID_KP_4.TabIndex = 1;
            this.num_CurPID_KP_4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // num_CurPID_KI_4
            // 
            this.num_CurPID_KI_4.DecimalPlaces = 3;
            this.num_CurPID_KI_4.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.num_CurPID_KI_4.Location = new System.Drawing.Point(147, 200);
            this.num_CurPID_KI_4.Name = "num_CurPID_KI_4";
            this.num_CurPID_KI_4.Size = new System.Drawing.Size(81, 22);
            this.num_CurPID_KI_4.TabIndex = 1;
            this.num_CurPID_KI_4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // num_CurPID_KP_3
            // 
            this.num_CurPID_KP_3.DecimalPlaces = 3;
            this.num_CurPID_KP_3.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.num_CurPID_KP_3.Location = new System.Drawing.Point(60, 160);
            this.num_CurPID_KP_3.Name = "num_CurPID_KP_3";
            this.num_CurPID_KP_3.Size = new System.Drawing.Size(81, 22);
            this.num_CurPID_KP_3.TabIndex = 1;
            this.num_CurPID_KP_3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // num_CurPID_KD_5
            // 
            this.num_CurPID_KD_5.DecimalPlaces = 3;
            this.num_CurPID_KD_5.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.num_CurPID_KD_5.Location = new System.Drawing.Point(235, 240);
            this.num_CurPID_KD_5.Name = "num_CurPID_KD_5";
            this.num_CurPID_KD_5.Size = new System.Drawing.Size(81, 22);
            this.num_CurPID_KD_5.TabIndex = 1;
            this.num_CurPID_KD_5.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // num_CurPID_KI_3
            // 
            this.num_CurPID_KI_3.DecimalPlaces = 3;
            this.num_CurPID_KI_3.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.num_CurPID_KI_3.Location = new System.Drawing.Point(147, 160);
            this.num_CurPID_KI_3.Name = "num_CurPID_KI_3";
            this.num_CurPID_KI_3.Size = new System.Drawing.Size(81, 22);
            this.num_CurPID_KI_3.TabIndex = 1;
            this.num_CurPID_KI_3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // num_CurPID_KD_4
            // 
            this.num_CurPID_KD_4.DecimalPlaces = 3;
            this.num_CurPID_KD_4.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.num_CurPID_KD_4.Location = new System.Drawing.Point(235, 200);
            this.num_CurPID_KD_4.Name = "num_CurPID_KD_4";
            this.num_CurPID_KD_4.Size = new System.Drawing.Size(81, 22);
            this.num_CurPID_KD_4.TabIndex = 1;
            this.num_CurPID_KD_4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // num_CurPID_KP_2
            // 
            this.num_CurPID_KP_2.DecimalPlaces = 3;
            this.num_CurPID_KP_2.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.num_CurPID_KP_2.Location = new System.Drawing.Point(60, 120);
            this.num_CurPID_KP_2.Name = "num_CurPID_KP_2";
            this.num_CurPID_KP_2.Size = new System.Drawing.Size(81, 22);
            this.num_CurPID_KP_2.TabIndex = 1;
            this.num_CurPID_KP_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // num_CurPID_KI_2
            // 
            this.num_CurPID_KI_2.DecimalPlaces = 3;
            this.num_CurPID_KI_2.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.num_CurPID_KI_2.Location = new System.Drawing.Point(147, 120);
            this.num_CurPID_KI_2.Name = "num_CurPID_KI_2";
            this.num_CurPID_KI_2.Size = new System.Drawing.Size(81, 22);
            this.num_CurPID_KI_2.TabIndex = 1;
            this.num_CurPID_KI_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // num_CurPID_KP_1
            // 
            this.num_CurPID_KP_1.DecimalPlaces = 3;
            this.num_CurPID_KP_1.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.num_CurPID_KP_1.Location = new System.Drawing.Point(60, 80);
            this.num_CurPID_KP_1.Name = "num_CurPID_KP_1";
            this.num_CurPID_KP_1.Size = new System.Drawing.Size(81, 22);
            this.num_CurPID_KP_1.TabIndex = 1;
            this.num_CurPID_KP_1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // num_CurPID_KI_1
            // 
            this.num_CurPID_KI_1.DecimalPlaces = 3;
            this.num_CurPID_KI_1.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.num_CurPID_KI_1.Location = new System.Drawing.Point(148, 80);
            this.num_CurPID_KI_1.Name = "num_CurPID_KI_1";
            this.num_CurPID_KI_1.Size = new System.Drawing.Size(81, 22);
            this.num_CurPID_KI_1.TabIndex = 1;
            this.num_CurPID_KI_1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // num_CurPID_KD_3
            // 
            this.num_CurPID_KD_3.DecimalPlaces = 3;
            this.num_CurPID_KD_3.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.num_CurPID_KD_3.Location = new System.Drawing.Point(234, 160);
            this.num_CurPID_KD_3.Name = "num_CurPID_KD_3";
            this.num_CurPID_KD_3.Size = new System.Drawing.Size(81, 22);
            this.num_CurPID_KD_3.TabIndex = 1;
            this.num_CurPID_KD_3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // num_CurPID_KP_0
            // 
            this.num_CurPID_KP_0.DecimalPlaces = 3;
            this.num_CurPID_KP_0.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.num_CurPID_KP_0.Location = new System.Drawing.Point(60, 40);
            this.num_CurPID_KP_0.Name = "num_CurPID_KP_0";
            this.num_CurPID_KP_0.Size = new System.Drawing.Size(81, 22);
            this.num_CurPID_KP_0.TabIndex = 1;
            this.num_CurPID_KP_0.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // num_CurPID_KD_2
            // 
            this.num_CurPID_KD_2.DecimalPlaces = 3;
            this.num_CurPID_KD_2.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.num_CurPID_KD_2.Location = new System.Drawing.Point(235, 120);
            this.num_CurPID_KD_2.Name = "num_CurPID_KD_2";
            this.num_CurPID_KD_2.Size = new System.Drawing.Size(81, 22);
            this.num_CurPID_KD_2.TabIndex = 1;
            this.num_CurPID_KD_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // num_CurPID_KI_0
            // 
            this.num_CurPID_KI_0.DecimalPlaces = 3;
            this.num_CurPID_KI_0.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.num_CurPID_KI_0.Location = new System.Drawing.Point(147, 40);
            this.num_CurPID_KI_0.Name = "num_CurPID_KI_0";
            this.num_CurPID_KI_0.Size = new System.Drawing.Size(81, 22);
            this.num_CurPID_KI_0.TabIndex = 1;
            this.num_CurPID_KI_0.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // num_CurPID_KD_1
            // 
            this.num_CurPID_KD_1.DecimalPlaces = 3;
            this.num_CurPID_KD_1.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.num_CurPID_KD_1.Location = new System.Drawing.Point(234, 80);
            this.num_CurPID_KD_1.Name = "num_CurPID_KD_1";
            this.num_CurPID_KD_1.Size = new System.Drawing.Size(81, 22);
            this.num_CurPID_KD_1.TabIndex = 1;
            this.num_CurPID_KD_1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label82
            // 
            this.label82.AutoSize = true;
            this.label82.Location = new System.Drawing.Point(18, 240);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(11, 12);
            this.label82.TabIndex = 0;
            this.label82.Text = "5";
            // 
            // label81
            // 
            this.label81.AutoSize = true;
            this.label81.Location = new System.Drawing.Point(18, 160);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(11, 12);
            this.label81.TabIndex = 0;
            this.label81.Text = "3";
            // 
            // label80
            // 
            this.label80.AutoSize = true;
            this.label80.Location = new System.Drawing.Point(18, 200);
            this.label80.Name = "label80";
            this.label80.Size = new System.Drawing.Size(11, 12);
            this.label80.TabIndex = 0;
            this.label80.Text = "4";
            // 
            // label79
            // 
            this.label79.AutoSize = true;
            this.label79.Location = new System.Drawing.Point(18, 120);
            this.label79.Name = "label79";
            this.label79.Size = new System.Drawing.Size(11, 12);
            this.label79.TabIndex = 0;
            this.label79.Text = "2";
            // 
            // label78
            // 
            this.label78.AutoSize = true;
            this.label78.Location = new System.Drawing.Point(18, 80);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(11, 12);
            this.label78.TabIndex = 0;
            this.label78.Text = "1";
            // 
            // label77
            // 
            this.label77.AutoSize = true;
            this.label77.Location = new System.Drawing.Point(18, 40);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(11, 12);
            this.label77.TabIndex = 0;
            this.label77.Text = "0";
            // 
            // label76
            // 
            this.label76.AutoSize = true;
            this.label76.Location = new System.Drawing.Point(59, 25);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(19, 12);
            this.label76.TabIndex = 0;
            this.label76.Text = "KP";
            // 
            // num_CurPID_KD_0
            // 
            this.num_CurPID_KD_0.DecimalPlaces = 3;
            this.num_CurPID_KD_0.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.num_CurPID_KD_0.Location = new System.Drawing.Point(234, 40);
            this.num_CurPID_KD_0.Name = "num_CurPID_KD_0";
            this.num_CurPID_KD_0.Size = new System.Drawing.Size(81, 22);
            this.num_CurPID_KD_0.TabIndex = 1;
            this.num_CurPID_KD_0.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(6, 65);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(101, 84);
            this.label40.TabIndex = 47;
            this.label40.Text = "說明 : \r\n\r\nPID區間參數調整\r\n選擇點選後，馬達\r\n進入運轉狀態後將\r\n根據區間PID參數\r\n設定來進行調整。";
            // 
            // groupBox13
            // 
            this.groupBox13.Controls.Add(this.label83);
            this.groupBox13.Controls.Add(this.label84);
            this.groupBox13.Controls.Add(this.num_SpdPID_KP_5);
            this.groupBox13.Controls.Add(this.num_SpdPID_KI_5);
            this.groupBox13.Controls.Add(this.num_SpdPID_KP_4);
            this.groupBox13.Controls.Add(this.num_SpdPID_KI_4);
            this.groupBox13.Controls.Add(this.num_SpdPID_KP_3);
            this.groupBox13.Controls.Add(this.num_SpdPID_KD_5);
            this.groupBox13.Controls.Add(this.num_SpdPID_KI_3);
            this.groupBox13.Controls.Add(this.num_SpdPID_KD_4);
            this.groupBox13.Controls.Add(this.num_SpdPID_KP_2);
            this.groupBox13.Controls.Add(this.num_SpdPID_KI_2);
            this.groupBox13.Controls.Add(this.num_SpdPID_KP_1);
            this.groupBox13.Controls.Add(this.num_SpdPID_KI_1);
            this.groupBox13.Controls.Add(this.num_SpdPID_KD_3);
            this.groupBox13.Controls.Add(this.num_SpdPID_KP_0);
            this.groupBox13.Controls.Add(this.num_SpdPID_KD_2);
            this.groupBox13.Controls.Add(this.num_SpdPID_KI_0);
            this.groupBox13.Controls.Add(this.num_SpdPID_KD_1);
            this.groupBox13.Controls.Add(this.label85);
            this.groupBox13.Controls.Add(this.label86);
            this.groupBox13.Controls.Add(this.label87);
            this.groupBox13.Controls.Add(this.label88);
            this.groupBox13.Controls.Add(this.label89);
            this.groupBox13.Controls.Add(this.label90);
            this.groupBox13.Controls.Add(this.label91);
            this.groupBox13.Controls.Add(this.num_SpdPID_KD_0);
            this.groupBox13.Location = new System.Drawing.Point(480, 33);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.Size = new System.Drawing.Size(341, 270);
            this.groupBox13.TabIndex = 43;
            this.groupBox13.TabStop = false;
            this.groupBox13.Text = "Speed Loop Parameters";
            // 
            // label83
            // 
            this.label83.AutoSize = true;
            this.label83.Location = new System.Drawing.Point(232, 25);
            this.label83.Name = "label83";
            this.label83.Size = new System.Drawing.Size(21, 12);
            this.label83.TabIndex = 0;
            this.label83.Text = "KD";
            // 
            // label84
            // 
            this.label84.AutoSize = true;
            this.label84.Location = new System.Drawing.Point(146, 25);
            this.label84.Name = "label84";
            this.label84.Size = new System.Drawing.Size(17, 12);
            this.label84.TabIndex = 0;
            this.label84.Text = "KI";
            // 
            // num_SpdPID_KP_5
            // 
            this.num_SpdPID_KP_5.DecimalPlaces = 3;
            this.num_SpdPID_KP_5.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.num_SpdPID_KP_5.Location = new System.Drawing.Point(61, 240);
            this.num_SpdPID_KP_5.Name = "num_SpdPID_KP_5";
            this.num_SpdPID_KP_5.Size = new System.Drawing.Size(81, 22);
            this.num_SpdPID_KP_5.TabIndex = 1;
            this.num_SpdPID_KP_5.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // num_SpdPID_KI_5
            // 
            this.num_SpdPID_KI_5.DecimalPlaces = 3;
            this.num_SpdPID_KI_5.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.num_SpdPID_KI_5.Location = new System.Drawing.Point(148, 240);
            this.num_SpdPID_KI_5.Name = "num_SpdPID_KI_5";
            this.num_SpdPID_KI_5.Size = new System.Drawing.Size(81, 22);
            this.num_SpdPID_KI_5.TabIndex = 1;
            this.num_SpdPID_KI_5.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // num_SpdPID_KP_4
            // 
            this.num_SpdPID_KP_4.DecimalPlaces = 3;
            this.num_SpdPID_KP_4.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.num_SpdPID_KP_4.Location = new System.Drawing.Point(61, 200);
            this.num_SpdPID_KP_4.Name = "num_SpdPID_KP_4";
            this.num_SpdPID_KP_4.Size = new System.Drawing.Size(81, 22);
            this.num_SpdPID_KP_4.TabIndex = 1;
            this.num_SpdPID_KP_4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // num_SpdPID_KI_4
            // 
            this.num_SpdPID_KI_4.DecimalPlaces = 3;
            this.num_SpdPID_KI_4.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.num_SpdPID_KI_4.Location = new System.Drawing.Point(147, 200);
            this.num_SpdPID_KI_4.Name = "num_SpdPID_KI_4";
            this.num_SpdPID_KI_4.Size = new System.Drawing.Size(81, 22);
            this.num_SpdPID_KI_4.TabIndex = 1;
            this.num_SpdPID_KI_4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // num_SpdPID_KP_3
            // 
            this.num_SpdPID_KP_3.DecimalPlaces = 3;
            this.num_SpdPID_KP_3.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.num_SpdPID_KP_3.Location = new System.Drawing.Point(60, 160);
            this.num_SpdPID_KP_3.Name = "num_SpdPID_KP_3";
            this.num_SpdPID_KP_3.Size = new System.Drawing.Size(81, 22);
            this.num_SpdPID_KP_3.TabIndex = 1;
            this.num_SpdPID_KP_3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // num_SpdPID_KD_5
            // 
            this.num_SpdPID_KD_5.DecimalPlaces = 3;
            this.num_SpdPID_KD_5.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.num_SpdPID_KD_5.Location = new System.Drawing.Point(235, 240);
            this.num_SpdPID_KD_5.Name = "num_SpdPID_KD_5";
            this.num_SpdPID_KD_5.Size = new System.Drawing.Size(81, 22);
            this.num_SpdPID_KD_5.TabIndex = 1;
            this.num_SpdPID_KD_5.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // num_SpdPID_KI_3
            // 
            this.num_SpdPID_KI_3.DecimalPlaces = 3;
            this.num_SpdPID_KI_3.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.num_SpdPID_KI_3.Location = new System.Drawing.Point(147, 160);
            this.num_SpdPID_KI_3.Name = "num_SpdPID_KI_3";
            this.num_SpdPID_KI_3.Size = new System.Drawing.Size(81, 22);
            this.num_SpdPID_KI_3.TabIndex = 1;
            this.num_SpdPID_KI_3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // num_SpdPID_KD_4
            // 
            this.num_SpdPID_KD_4.DecimalPlaces = 3;
            this.num_SpdPID_KD_4.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.num_SpdPID_KD_4.Location = new System.Drawing.Point(235, 200);
            this.num_SpdPID_KD_4.Name = "num_SpdPID_KD_4";
            this.num_SpdPID_KD_4.Size = new System.Drawing.Size(81, 22);
            this.num_SpdPID_KD_4.TabIndex = 1;
            this.num_SpdPID_KD_4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // num_SpdPID_KP_2
            // 
            this.num_SpdPID_KP_2.DecimalPlaces = 3;
            this.num_SpdPID_KP_2.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.num_SpdPID_KP_2.Location = new System.Drawing.Point(60, 120);
            this.num_SpdPID_KP_2.Name = "num_SpdPID_KP_2";
            this.num_SpdPID_KP_2.Size = new System.Drawing.Size(81, 22);
            this.num_SpdPID_KP_2.TabIndex = 1;
            this.num_SpdPID_KP_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // num_SpdPID_KI_2
            // 
            this.num_SpdPID_KI_2.DecimalPlaces = 3;
            this.num_SpdPID_KI_2.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.num_SpdPID_KI_2.Location = new System.Drawing.Point(147, 120);
            this.num_SpdPID_KI_2.Name = "num_SpdPID_KI_2";
            this.num_SpdPID_KI_2.Size = new System.Drawing.Size(81, 22);
            this.num_SpdPID_KI_2.TabIndex = 1;
            this.num_SpdPID_KI_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // num_SpdPID_KP_1
            // 
            this.num_SpdPID_KP_1.DecimalPlaces = 3;
            this.num_SpdPID_KP_1.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.num_SpdPID_KP_1.Location = new System.Drawing.Point(60, 80);
            this.num_SpdPID_KP_1.Name = "num_SpdPID_KP_1";
            this.num_SpdPID_KP_1.Size = new System.Drawing.Size(81, 22);
            this.num_SpdPID_KP_1.TabIndex = 1;
            this.num_SpdPID_KP_1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // num_SpdPID_KI_1
            // 
            this.num_SpdPID_KI_1.DecimalPlaces = 3;
            this.num_SpdPID_KI_1.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.num_SpdPID_KI_1.Location = new System.Drawing.Point(148, 80);
            this.num_SpdPID_KI_1.Name = "num_SpdPID_KI_1";
            this.num_SpdPID_KI_1.Size = new System.Drawing.Size(81, 22);
            this.num_SpdPID_KI_1.TabIndex = 1;
            this.num_SpdPID_KI_1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // num_SpdPID_KD_3
            // 
            this.num_SpdPID_KD_3.DecimalPlaces = 3;
            this.num_SpdPID_KD_3.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.num_SpdPID_KD_3.Location = new System.Drawing.Point(234, 160);
            this.num_SpdPID_KD_3.Name = "num_SpdPID_KD_3";
            this.num_SpdPID_KD_3.Size = new System.Drawing.Size(81, 22);
            this.num_SpdPID_KD_3.TabIndex = 1;
            this.num_SpdPID_KD_3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // num_SpdPID_KP_0
            // 
            this.num_SpdPID_KP_0.DecimalPlaces = 3;
            this.num_SpdPID_KP_0.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.num_SpdPID_KP_0.Location = new System.Drawing.Point(60, 40);
            this.num_SpdPID_KP_0.Name = "num_SpdPID_KP_0";
            this.num_SpdPID_KP_0.Size = new System.Drawing.Size(81, 22);
            this.num_SpdPID_KP_0.TabIndex = 1;
            this.num_SpdPID_KP_0.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // num_SpdPID_KD_2
            // 
            this.num_SpdPID_KD_2.DecimalPlaces = 3;
            this.num_SpdPID_KD_2.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.num_SpdPID_KD_2.Location = new System.Drawing.Point(235, 120);
            this.num_SpdPID_KD_2.Name = "num_SpdPID_KD_2";
            this.num_SpdPID_KD_2.Size = new System.Drawing.Size(81, 22);
            this.num_SpdPID_KD_2.TabIndex = 1;
            this.num_SpdPID_KD_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // num_SpdPID_KI_0
            // 
            this.num_SpdPID_KI_0.DecimalPlaces = 3;
            this.num_SpdPID_KI_0.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.num_SpdPID_KI_0.Location = new System.Drawing.Point(147, 40);
            this.num_SpdPID_KI_0.Name = "num_SpdPID_KI_0";
            this.num_SpdPID_KI_0.Size = new System.Drawing.Size(81, 22);
            this.num_SpdPID_KI_0.TabIndex = 1;
            this.num_SpdPID_KI_0.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // num_SpdPID_KD_1
            // 
            this.num_SpdPID_KD_1.DecimalPlaces = 3;
            this.num_SpdPID_KD_1.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.num_SpdPID_KD_1.Location = new System.Drawing.Point(234, 80);
            this.num_SpdPID_KD_1.Name = "num_SpdPID_KD_1";
            this.num_SpdPID_KD_1.Size = new System.Drawing.Size(81, 22);
            this.num_SpdPID_KD_1.TabIndex = 1;
            this.num_SpdPID_KD_1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label85
            // 
            this.label85.AutoSize = true;
            this.label85.Location = new System.Drawing.Point(18, 240);
            this.label85.Name = "label85";
            this.label85.Size = new System.Drawing.Size(11, 12);
            this.label85.TabIndex = 0;
            this.label85.Text = "5";
            // 
            // label86
            // 
            this.label86.AutoSize = true;
            this.label86.Location = new System.Drawing.Point(18, 160);
            this.label86.Name = "label86";
            this.label86.Size = new System.Drawing.Size(11, 12);
            this.label86.TabIndex = 0;
            this.label86.Text = "3";
            // 
            // label87
            // 
            this.label87.AutoSize = true;
            this.label87.Location = new System.Drawing.Point(18, 200);
            this.label87.Name = "label87";
            this.label87.Size = new System.Drawing.Size(11, 12);
            this.label87.TabIndex = 0;
            this.label87.Text = "4";
            // 
            // label88
            // 
            this.label88.AutoSize = true;
            this.label88.Location = new System.Drawing.Point(18, 120);
            this.label88.Name = "label88";
            this.label88.Size = new System.Drawing.Size(11, 12);
            this.label88.TabIndex = 0;
            this.label88.Text = "2";
            // 
            // label89
            // 
            this.label89.AutoSize = true;
            this.label89.Location = new System.Drawing.Point(18, 80);
            this.label89.Name = "label89";
            this.label89.Size = new System.Drawing.Size(11, 12);
            this.label89.TabIndex = 0;
            this.label89.Text = "1";
            // 
            // label90
            // 
            this.label90.AutoSize = true;
            this.label90.Location = new System.Drawing.Point(18, 40);
            this.label90.Name = "label90";
            this.label90.Size = new System.Drawing.Size(11, 12);
            this.label90.TabIndex = 0;
            this.label90.Text = "0";
            // 
            // label91
            // 
            this.label91.AutoSize = true;
            this.label91.Location = new System.Drawing.Point(59, 25);
            this.label91.Name = "label91";
            this.label91.Size = new System.Drawing.Size(19, 12);
            this.label91.TabIndex = 0;
            this.label91.Text = "KP";
            // 
            // num_SpdPID_KD_0
            // 
            this.num_SpdPID_KD_0.DecimalPlaces = 3;
            this.num_SpdPID_KD_0.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.num_SpdPID_KD_0.Location = new System.Drawing.Point(234, 40);
            this.num_SpdPID_KD_0.Name = "num_SpdPID_KD_0";
            this.num_SpdPID_KD_0.Size = new System.Drawing.Size(81, 22);
            this.num_SpdPID_KD_0.TabIndex = 1;
            this.num_SpdPID_KD_0.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // groupBox14
            // 
            this.groupBox14.Controls.Add(this.label99);
            this.groupBox14.Controls.Add(this.label92);
            this.groupBox14.Controls.Add(this.num_SPD_Interval1_L);
            this.groupBox14.Controls.Add(this.num_SPD_Interval0_H);
            this.groupBox14.Controls.Add(this.num_SPD_Interval2_L);
            this.groupBox14.Controls.Add(this.num_SPD_Interval1_H);
            this.groupBox14.Controls.Add(this.num_SPD_Interval3_L);
            this.groupBox14.Controls.Add(this.num_SPD_Interval2_H);
            this.groupBox14.Controls.Add(this.num_SPD_Interval4_L);
            this.groupBox14.Controls.Add(this.num_SPD_Interval3_H);
            this.groupBox14.Controls.Add(this.num_SPD_Interval5_L);
            this.groupBox14.Controls.Add(this.num_SPD_Interval4_H);
            this.groupBox14.Controls.Add(this.label97);
            this.groupBox14.Controls.Add(this.label93);
            this.groupBox14.Controls.Add(this.label94);
            this.groupBox14.Controls.Add(this.label95);
            this.groupBox14.Controls.Add(this.label96);
            this.groupBox14.Controls.Add(this.label98);
            this.groupBox14.Location = new System.Drawing.Point(827, 33);
            this.groupBox14.Name = "groupBox14";
            this.groupBox14.Size = new System.Drawing.Size(245, 270);
            this.groupBox14.TabIndex = 44;
            this.groupBox14.TabStop = false;
            this.groupBox14.Text = "區間 上限/ 下限";
            // 
            // label99
            // 
            this.label99.AutoSize = true;
            this.label99.Location = new System.Drawing.Point(145, 25);
            this.label99.Name = "label99";
            this.label99.Size = new System.Drawing.Size(41, 12);
            this.label99.TabIndex = 0;
            this.label99.Text = "下限值";
            // 
            // label92
            // 
            this.label92.AutoSize = true;
            this.label92.Location = new System.Drawing.Point(58, 25);
            this.label92.Name = "label92";
            this.label92.Size = new System.Drawing.Size(41, 12);
            this.label92.TabIndex = 0;
            this.label92.Text = "上限值";
            // 
            // num_SPD_Interval1_L
            // 
            this.num_SPD_Interval1_L.DecimalPlaces = 1;
            this.num_SPD_Interval1_L.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.num_SPD_Interval1_L.Location = new System.Drawing.Point(147, 80);
            this.num_SPD_Interval1_L.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.num_SPD_Interval1_L.Name = "num_SPD_Interval1_L";
            this.num_SPD_Interval1_L.Size = new System.Drawing.Size(81, 22);
            this.num_SPD_Interval1_L.TabIndex = 1;
            this.num_SPD_Interval1_L.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // num_SPD_Interval0_H
            // 
            this.num_SPD_Interval0_H.DecimalPlaces = 1;
            this.num_SPD_Interval0_H.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.num_SPD_Interval0_H.Location = new System.Drawing.Point(60, 40);
            this.num_SPD_Interval0_H.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.num_SPD_Interval0_H.Name = "num_SPD_Interval0_H";
            this.num_SPD_Interval0_H.Size = new System.Drawing.Size(81, 22);
            this.num_SPD_Interval0_H.TabIndex = 1;
            this.num_SPD_Interval0_H.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // num_SPD_Interval2_L
            // 
            this.num_SPD_Interval2_L.DecimalPlaces = 1;
            this.num_SPD_Interval2_L.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.num_SPD_Interval2_L.Location = new System.Drawing.Point(148, 120);
            this.num_SPD_Interval2_L.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.num_SPD_Interval2_L.Name = "num_SPD_Interval2_L";
            this.num_SPD_Interval2_L.Size = new System.Drawing.Size(81, 22);
            this.num_SPD_Interval2_L.TabIndex = 1;
            this.num_SPD_Interval2_L.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // num_SPD_Interval1_H
            // 
            this.num_SPD_Interval1_H.DecimalPlaces = 1;
            this.num_SPD_Interval1_H.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.num_SPD_Interval1_H.Location = new System.Drawing.Point(60, 80);
            this.num_SPD_Interval1_H.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.num_SPD_Interval1_H.Name = "num_SPD_Interval1_H";
            this.num_SPD_Interval1_H.Size = new System.Drawing.Size(81, 22);
            this.num_SPD_Interval1_H.TabIndex = 1;
            this.num_SPD_Interval1_H.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // num_SPD_Interval3_L
            // 
            this.num_SPD_Interval3_L.DecimalPlaces = 1;
            this.num_SPD_Interval3_L.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.num_SPD_Interval3_L.Location = new System.Drawing.Point(147, 160);
            this.num_SPD_Interval3_L.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.num_SPD_Interval3_L.Name = "num_SPD_Interval3_L";
            this.num_SPD_Interval3_L.Size = new System.Drawing.Size(81, 22);
            this.num_SPD_Interval3_L.TabIndex = 1;
            this.num_SPD_Interval3_L.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // num_SPD_Interval2_H
            // 
            this.num_SPD_Interval2_H.DecimalPlaces = 1;
            this.num_SPD_Interval2_H.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.num_SPD_Interval2_H.Location = new System.Drawing.Point(61, 120);
            this.num_SPD_Interval2_H.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.num_SPD_Interval2_H.Name = "num_SPD_Interval2_H";
            this.num_SPD_Interval2_H.Size = new System.Drawing.Size(81, 22);
            this.num_SPD_Interval2_H.TabIndex = 1;
            this.num_SPD_Interval2_H.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // num_SPD_Interval4_L
            // 
            this.num_SPD_Interval4_L.DecimalPlaces = 1;
            this.num_SPD_Interval4_L.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.num_SPD_Interval4_L.Location = new System.Drawing.Point(148, 200);
            this.num_SPD_Interval4_L.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.num_SPD_Interval4_L.Name = "num_SPD_Interval4_L";
            this.num_SPD_Interval4_L.Size = new System.Drawing.Size(81, 22);
            this.num_SPD_Interval4_L.TabIndex = 1;
            this.num_SPD_Interval4_L.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // num_SPD_Interval3_H
            // 
            this.num_SPD_Interval3_H.DecimalPlaces = 1;
            this.num_SPD_Interval3_H.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.num_SPD_Interval3_H.Location = new System.Drawing.Point(60, 160);
            this.num_SPD_Interval3_H.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.num_SPD_Interval3_H.Name = "num_SPD_Interval3_H";
            this.num_SPD_Interval3_H.Size = new System.Drawing.Size(81, 22);
            this.num_SPD_Interval3_H.TabIndex = 1;
            this.num_SPD_Interval3_H.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // num_SPD_Interval5_L
            // 
            this.num_SPD_Interval5_L.DecimalPlaces = 1;
            this.num_SPD_Interval5_L.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.num_SPD_Interval5_L.Location = new System.Drawing.Point(148, 240);
            this.num_SPD_Interval5_L.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.num_SPD_Interval5_L.Name = "num_SPD_Interval5_L";
            this.num_SPD_Interval5_L.Size = new System.Drawing.Size(81, 22);
            this.num_SPD_Interval5_L.TabIndex = 1;
            this.num_SPD_Interval5_L.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // num_SPD_Interval4_H
            // 
            this.num_SPD_Interval4_H.DecimalPlaces = 1;
            this.num_SPD_Interval4_H.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.num_SPD_Interval4_H.Location = new System.Drawing.Point(61, 200);
            this.num_SPD_Interval4_H.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.num_SPD_Interval4_H.Name = "num_SPD_Interval4_H";
            this.num_SPD_Interval4_H.Size = new System.Drawing.Size(81, 22);
            this.num_SPD_Interval4_H.TabIndex = 1;
            this.num_SPD_Interval4_H.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label97
            // 
            this.label97.AutoSize = true;
            this.label97.Location = new System.Drawing.Point(18, 160);
            this.label97.Name = "label97";
            this.label97.Size = new System.Drawing.Size(11, 12);
            this.label97.TabIndex = 0;
            this.label97.Text = "3";
            // 
            // label93
            // 
            this.label93.AutoSize = true;
            this.label93.Location = new System.Drawing.Point(18, 40);
            this.label93.Name = "label93";
            this.label93.Size = new System.Drawing.Size(11, 12);
            this.label93.TabIndex = 0;
            this.label93.Text = "0";
            // 
            // label94
            // 
            this.label94.AutoSize = true;
            this.label94.Location = new System.Drawing.Point(18, 80);
            this.label94.Name = "label94";
            this.label94.Size = new System.Drawing.Size(11, 12);
            this.label94.TabIndex = 0;
            this.label94.Text = "1";
            // 
            // label95
            // 
            this.label95.AutoSize = true;
            this.label95.Location = new System.Drawing.Point(18, 120);
            this.label95.Name = "label95";
            this.label95.Size = new System.Drawing.Size(11, 12);
            this.label95.TabIndex = 0;
            this.label95.Text = "2";
            // 
            // label96
            // 
            this.label96.AutoSize = true;
            this.label96.Location = new System.Drawing.Point(18, 200);
            this.label96.Name = "label96";
            this.label96.Size = new System.Drawing.Size(11, 12);
            this.label96.TabIndex = 0;
            this.label96.Text = "4";
            // 
            // label98
            // 
            this.label98.AutoSize = true;
            this.label98.Location = new System.Drawing.Point(18, 240);
            this.label98.Name = "label98";
            this.label98.Size = new System.Drawing.Size(11, 12);
            this.label98.TabIndex = 0;
            this.label98.Text = "5";
            // 
            // PidCalc_Enable_checkBox1
            // 
            this.PidCalc_Enable_checkBox1.AutoSize = true;
            this.PidCalc_Enable_checkBox1.Location = new System.Drawing.Point(6, 36);
            this.PidCalc_Enable_checkBox1.Name = "PidCalc_Enable_checkBox1";
            this.PidCalc_Enable_checkBox1.Size = new System.Drawing.Size(120, 16);
            this.PidCalc_Enable_checkBox1.TabIndex = 0;
            this.PidCalc_Enable_checkBox1.Text = " PID 區間調整選擇";
            this.PidCalc_Enable_checkBox1.UseVisualStyleBackColor = true;
            this.PidCalc_Enable_checkBox1.CheckedChanged += new System.EventHandler(this.PidCalc_Enable_checkBox1_CheckedChanged);
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.label44);
            this.groupBox5.Controls.Add(this.label45);
            this.groupBox5.Controls.Add(this.num_StartCurPID_KP);
            this.groupBox5.Controls.Add(this.num_StartCurPID_KI);
            this.groupBox5.Controls.Add(this.label49);
            this.groupBox5.Controls.Add(this.num_StartCurPID_KD);
            this.groupBox5.Location = new System.Drawing.Point(14, 18);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(384, 101);
            this.groupBox5.TabIndex = 46;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Current Loop Parameters";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(260, 34);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(45, 12);
            this.label44.TabIndex = 0;
            this.label44.Text = "Cur_KD";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(137, 34);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(41, 12);
            this.label45.TabIndex = 0;
            this.label45.Text = "Cur_KI";
            // 
            // num_StartCurPID_KP
            // 
            this.num_StartCurPID_KP.DecimalPlaces = 5;
            this.num_StartCurPID_KP.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.num_StartCurPID_KP.Location = new System.Drawing.Point(17, 49);
            this.num_StartCurPID_KP.Name = "num_StartCurPID_KP";
            this.num_StartCurPID_KP.Size = new System.Drawing.Size(101, 22);
            this.num_StartCurPID_KP.TabIndex = 1;
            this.num_StartCurPID_KP.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // num_StartCurPID_KI
            // 
            this.num_StartCurPID_KI.DecimalPlaces = 5;
            this.num_StartCurPID_KI.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.num_StartCurPID_KI.Location = new System.Drawing.Point(139, 49);
            this.num_StartCurPID_KI.Name = "num_StartCurPID_KI";
            this.num_StartCurPID_KI.Size = new System.Drawing.Size(101, 22);
            this.num_StartCurPID_KI.TabIndex = 1;
            this.num_StartCurPID_KI.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(15, 34);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(43, 12);
            this.label49.TabIndex = 0;
            this.label49.Text = "Cur_KP";
            // 
            // num_StartCurPID_KD
            // 
            this.num_StartCurPID_KD.DecimalPlaces = 5;
            this.num_StartCurPID_KD.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.num_StartCurPID_KD.Location = new System.Drawing.Point(262, 49);
            this.num_StartCurPID_KD.Name = "num_StartCurPID_KD";
            this.num_StartCurPID_KD.Size = new System.Drawing.Size(101, 22);
            this.num_StartCurPID_KD.TabIndex = 1;
            this.num_StartCurPID_KD.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.num_ISQLimit);
            this.groupBox4.Controls.Add(this.label37);
            this.groupBox4.Controls.Add(this.label17);
            this.groupBox4.Controls.Add(this.label38);
            this.groupBox4.Controls.Add(this.label39);
            this.groupBox4.Controls.Add(this.num_StartSpdPID_P);
            this.groupBox4.Controls.Add(this.num_StartSpdPID_I);
            this.groupBox4.Controls.Add(this.label43);
            this.groupBox4.Controls.Add(this.num_StartSpdPID_D);
            this.groupBox4.Location = new System.Drawing.Point(408, 18);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(384, 123);
            this.groupBox4.TabIndex = 45;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Speed Loop Parameters";
            // 
            // num_ISQLimit
            // 
            this.num_ISQLimit.DecimalPlaces = 2;
            this.num_ISQLimit.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.num_ISQLimit.Location = new System.Drawing.Point(157, 92);
            this.num_ISQLimit.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.num_ISQLimit.Name = "num_ISQLimit";
            this.num_ISQLimit.Size = new System.Drawing.Size(101, 22);
            this.num_ISQLimit.TabIndex = 4;
            this.num_ISQLimit.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(272, 97);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(13, 12);
            this.label37.TabIndex = 2;
            this.label37.Text = "A";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(25, 92);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(106, 12);
            this.label17.TabIndex = 3;
            this.label17.Text = "Max. Iq Current ( A )";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(260, 34);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(47, 12);
            this.label38.TabIndex = 0;
            this.label38.Text = "SPD_KD";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(137, 34);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(43, 12);
            this.label39.TabIndex = 0;
            this.label39.Text = "SPD_KI";
            // 
            // num_StartSpdPID_P
            // 
            this.num_StartSpdPID_P.DecimalPlaces = 5;
            this.num_StartSpdPID_P.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.num_StartSpdPID_P.Location = new System.Drawing.Point(17, 49);
            this.num_StartSpdPID_P.Name = "num_StartSpdPID_P";
            this.num_StartSpdPID_P.Size = new System.Drawing.Size(101, 22);
            this.num_StartSpdPID_P.TabIndex = 1;
            this.num_StartSpdPID_P.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // num_StartSpdPID_I
            // 
            this.num_StartSpdPID_I.DecimalPlaces = 5;
            this.num_StartSpdPID_I.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.num_StartSpdPID_I.Location = new System.Drawing.Point(139, 49);
            this.num_StartSpdPID_I.Name = "num_StartSpdPID_I";
            this.num_StartSpdPID_I.Size = new System.Drawing.Size(101, 22);
            this.num_StartSpdPID_I.TabIndex = 1;
            this.num_StartSpdPID_I.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(15, 34);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(45, 12);
            this.label43.TabIndex = 0;
            this.label43.Text = "SPD_KP";
            // 
            // num_StartSpdPID_D
            // 
            this.num_StartSpdPID_D.DecimalPlaces = 5;
            this.num_StartSpdPID_D.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.num_StartSpdPID_D.Location = new System.Drawing.Point(262, 49);
            this.num_StartSpdPID_D.Name = "num_StartSpdPID_D";
            this.num_StartSpdPID_D.Size = new System.Drawing.Size(101, 22);
            this.num_StartSpdPID_D.TabIndex = 1;
            this.num_StartSpdPID_D.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // groupBox15
            // 
            this.groupBox15.Controls.Add(this.SaveFile_button);
            this.groupBox15.Controls.Add(this.OpenFile_button);
            this.groupBox15.Controls.Add(this.Update_button);
            this.groupBox15.Controls.Add(this.Reload_button);
            this.groupBox15.Location = new System.Drawing.Point(517, 494);
            this.groupBox15.Name = "groupBox15";
            this.groupBox15.Size = new System.Drawing.Size(349, 97);
            this.groupBox15.TabIndex = 39;
            this.groupBox15.TabStop = false;
            // 
            // groupBox16
            // 
            this.groupBox16.Controls.Add(this.richTextBox_Message);
            this.groupBox16.Location = new System.Drawing.Point(10, 494);
            this.groupBox16.Name = "groupBox16";
            this.groupBox16.Size = new System.Drawing.Size(501, 97);
            this.groupBox16.TabIndex = 40;
            this.groupBox16.TabStop = false;
            this.groupBox16.Text = "Message";
            // 
            // richTextBox_Message
            // 
            this.richTextBox_Message.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.richTextBox_Message.Location = new System.Drawing.Point(14, 17);
            this.richTextBox_Message.Name = "richTextBox_Message";
            this.richTextBox_Message.Size = new System.Drawing.Size(468, 74);
            this.richTextBox_Message.TabIndex = 0;
            this.richTextBox_Message.Text = "";
            // 
            // ParameterConfigUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.groupBox16);
            this.Controls.Add(this.groupBox15);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.groupBox7);
            this.Name = "ParameterConfigUI";
            this.Size = new System.Drawing.Size(1108, 599);
            this.groupBox1.ResumeLayout(false);
            this.panel13.ResumeLayout(false);
            this.panel13.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.num_PolePair)).EndInit();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.num_Lq)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_Ld)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_Rs)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_maxFreq)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_minFreq)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_incUp)).EndInit();
            this.groupBox7.ResumeLayout(false);
            this.groupBox8.ResumeLayout(false);
            this.panel12.ResumeLayout(false);
            this.panel12.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.num_PhaseCurLimit)).EndInit();
            this.panel11.ResumeLayout(false);
            this.panel11.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.num_VacMin)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_VacMax)).EndInit();
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.num_VbusMin)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_VbusMax)).EndInit();
            this.groupBox9.ResumeLayout(false);
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.num_incDown)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.groupBox11.ResumeLayout(false);
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.num_Freq_pwm)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_DeadTime)).EndInit();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.num_V_Sample_K)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_I_Sample_K)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.groupBox18.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.num_K_OmC_StartUp)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_K_THETA0_MAX)).EndInit();
            this.groupBox6.ResumeLayout(false);
            this.panel16.ResumeLayout(false);
            this.panel16.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.num_E0_StartUp_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_Kslf_StartUp_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_Kslide_StartUp_2)).EndInit();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.num_E0_StartUp_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_Kslf_StartUp_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_Kslide_StartUp_1)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.panel15.ResumeLayout(false);
            this.panel15.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.num_SynTime)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_SynSpd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_Accrate)).EndInit();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.num_baseFreq)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_I_Start_Max)).EndInit();
            this.panel14.ResumeLayout(false);
            this.panel14.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.num_Count_StartUp_ST4_ADD)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.num_CurStart_ST1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_CurStart_ST2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_Count_StartUp_ST2_ADD)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.num_CurStartOffset)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_Count_StartUp_ST3_ADD)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.groupBox17.ResumeLayout(false);
            this.groupBox17.PerformLayout();
            this.groupBox12.ResumeLayout(false);
            this.groupBox12.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.num_CurPID_KP_5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_CurPID_KI_5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_CurPID_KP_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_CurPID_KI_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_CurPID_KP_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_CurPID_KD_5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_CurPID_KI_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_CurPID_KD_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_CurPID_KP_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_CurPID_KI_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_CurPID_KP_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_CurPID_KI_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_CurPID_KD_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_CurPID_KP_0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_CurPID_KD_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_CurPID_KI_0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_CurPID_KD_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_CurPID_KD_0)).EndInit();
            this.groupBox13.ResumeLayout(false);
            this.groupBox13.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.num_SpdPID_KP_5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_SpdPID_KI_5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_SpdPID_KP_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_SpdPID_KI_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_SpdPID_KP_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_SpdPID_KD_5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_SpdPID_KI_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_SpdPID_KD_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_SpdPID_KP_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_SpdPID_KI_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_SpdPID_KP_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_SpdPID_KI_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_SpdPID_KD_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_SpdPID_KP_0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_SpdPID_KD_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_SpdPID_KI_0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_SpdPID_KD_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_SpdPID_KD_0)).EndInit();
            this.groupBox14.ResumeLayout(false);
            this.groupBox14.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.num_SPD_Interval1_L)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_SPD_Interval0_H)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_SPD_Interval2_L)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_SPD_Interval1_H)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_SPD_Interval3_L)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_SPD_Interval2_H)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_SPD_Interval4_L)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_SPD_Interval3_H)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_SPD_Interval5_L)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_SPD_Interval4_H)).EndInit();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.num_StartCurPID_KP)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_StartCurPID_KI)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_StartCurPID_KD)).EndInit();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.num_ISQLimit)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_StartSpdPID_P)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_StartSpdPID_I)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_StartSpdPID_D)).EndInit();
            this.groupBox15.ResumeLayout(false);
            this.groupBox16.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.NumericUpDown num_PolePair;
        private System.Windows.Forms.NumericUpDown num_Lq;
        private System.Windows.Forms.NumericUpDown num_Ld;
        private System.Windows.Forms.NumericUpDown num_Rs;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.NumericUpDown num_incUp;
        private System.Windows.Forms.NumericUpDown num_maxFreq;
        private System.Windows.Forms.NumericUpDown num_minFreq;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.Button Read_efd_button;
        private System.Windows.Forms.Button Update_button;
        private System.Windows.Forms.Button Reload_button;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.NumericUpDown num_VbusMin;
        private System.Windows.Forms.NumericUpDown num_VbusMax;
        private System.Windows.Forms.NumericUpDown num_PhaseCurLimit;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.NumericUpDown num_incDown;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.NumericUpDown num_VacMax;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.NumericUpDown num_VacMin;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.NumericUpDown num_baseFreq;
        private System.Windows.Forms.NumericUpDown num_I_Start_Max;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.NumericUpDown num_Count_StartUp_ST4_ADD;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.NumericUpDown num_CurStart_ST1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.NumericUpDown num_CurStart_ST2;
        private System.Windows.Forms.NumericUpDown num_Count_StartUp_ST2_ADD;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.NumericUpDown num_CurStartOffset;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.NumericUpDown num_Count_StartUp_ST3_ADD;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.NumericUpDown num_I_Sample_K;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.NumericUpDown num_V_Sample_K;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.NumericUpDown num_DeadTime;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.NumericUpDown num_Freq_pwm;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.ComboBox comboBox_FilterSelected;
        private System.Windows.Forms.NumericUpDown num_K_OmC_StartUp;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.NumericUpDown num_K_THETA0_MAX;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.NumericUpDown num_E0_StartUp_2;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.NumericUpDown num_Kslide_StartUp_1;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.NumericUpDown num_Kslide_StartUp_2;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.NumericUpDown num_Kslf_StartUp_2;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.NumericUpDown num_Kslf_StartUp_1;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.NumericUpDown num_E0_StartUp_1;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.NumericUpDown num_SynTime;
        private System.Windows.Forms.NumericUpDown num_SynSpd;
        private System.Windows.Forms.NumericUpDown num_Accrate;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.ComboBox comboBox_StartUp_Mode;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.GroupBox groupBox14;
        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.Label label83;
        private System.Windows.Forms.Label label84;
        private System.Windows.Forms.NumericUpDown num_SpdPID_KP_5;
        private System.Windows.Forms.NumericUpDown num_SpdPID_KI_5;
        private System.Windows.Forms.NumericUpDown num_SpdPID_KP_4;
        private System.Windows.Forms.NumericUpDown num_SpdPID_KI_4;
        private System.Windows.Forms.NumericUpDown num_SpdPID_KP_3;
        private System.Windows.Forms.NumericUpDown num_SpdPID_KD_5;
        private System.Windows.Forms.NumericUpDown num_SpdPID_KI_3;
        private System.Windows.Forms.NumericUpDown num_SpdPID_KD_4;
        private System.Windows.Forms.NumericUpDown num_SpdPID_KP_2;
        private System.Windows.Forms.NumericUpDown num_SpdPID_KI_2;
        private System.Windows.Forms.NumericUpDown num_SpdPID_KP_1;
        private System.Windows.Forms.NumericUpDown num_SpdPID_KI_1;
        private System.Windows.Forms.NumericUpDown num_SpdPID_KD_3;
        private System.Windows.Forms.NumericUpDown num_SpdPID_KP_0;
        private System.Windows.Forms.NumericUpDown num_SpdPID_KD_2;
        private System.Windows.Forms.NumericUpDown num_SpdPID_KI_0;
        private System.Windows.Forms.NumericUpDown num_SpdPID_KD_1;
        private System.Windows.Forms.Label label85;
        private System.Windows.Forms.Label label86;
        private System.Windows.Forms.Label label87;
        private System.Windows.Forms.Label label88;
        private System.Windows.Forms.Label label89;
        private System.Windows.Forms.Label label90;
        private System.Windows.Forms.Label label91;
        private System.Windows.Forms.NumericUpDown num_SpdPID_KD_0;
        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.NumericUpDown num_CurPID_KP_5;
        private System.Windows.Forms.NumericUpDown num_CurPID_KI_5;
        private System.Windows.Forms.NumericUpDown num_CurPID_KP_4;
        private System.Windows.Forms.NumericUpDown num_CurPID_KI_4;
        private System.Windows.Forms.NumericUpDown num_CurPID_KP_3;
        private System.Windows.Forms.NumericUpDown num_CurPID_KD_5;
        private System.Windows.Forms.NumericUpDown num_CurPID_KI_3;
        private System.Windows.Forms.NumericUpDown num_CurPID_KD_4;
        private System.Windows.Forms.NumericUpDown num_CurPID_KP_2;
        private System.Windows.Forms.NumericUpDown num_CurPID_KI_2;
        private System.Windows.Forms.NumericUpDown num_CurPID_KP_1;
        private System.Windows.Forms.NumericUpDown num_CurPID_KI_1;
        private System.Windows.Forms.NumericUpDown num_CurPID_KD_3;
        private System.Windows.Forms.NumericUpDown num_CurPID_KP_0;
        private System.Windows.Forms.NumericUpDown num_CurPID_KD_2;
        private System.Windows.Forms.NumericUpDown num_CurPID_KI_0;
        private System.Windows.Forms.NumericUpDown num_CurPID_KD_1;
        private System.Windows.Forms.Label label82;
        private System.Windows.Forms.Label label81;
        private System.Windows.Forms.Label label80;
        private System.Windows.Forms.Label label79;
        private System.Windows.Forms.Label label78;
        private System.Windows.Forms.Label label77;
        private System.Windows.Forms.Label label76;
        private System.Windows.Forms.NumericUpDown num_CurPID_KD_0;
        private System.Windows.Forms.CheckBox PidCalc_Enable_checkBox1;
        private System.Windows.Forms.Label label99;
        private System.Windows.Forms.Label label92;
        private System.Windows.Forms.NumericUpDown num_SPD_Interval1_L;
        private System.Windows.Forms.NumericUpDown num_SPD_Interval0_H;
        private System.Windows.Forms.NumericUpDown num_SPD_Interval2_L;
        private System.Windows.Forms.NumericUpDown num_SPD_Interval1_H;
        private System.Windows.Forms.NumericUpDown num_SPD_Interval3_L;
        private System.Windows.Forms.NumericUpDown num_SPD_Interval2_H;
        private System.Windows.Forms.NumericUpDown num_SPD_Interval4_L;
        private System.Windows.Forms.NumericUpDown num_SPD_Interval3_H;
        private System.Windows.Forms.NumericUpDown num_SPD_Interval5_L;
        private System.Windows.Forms.NumericUpDown num_SPD_Interval4_H;
        private System.Windows.Forms.Label label97;
        private System.Windows.Forms.Label label93;
        private System.Windows.Forms.Label label94;
        private System.Windows.Forms.Label label95;
        private System.Windows.Forms.Label label96;
        private System.Windows.Forms.Label label98;
        private System.Windows.Forms.Button SaveFile_button;
        private System.Windows.Forms.Button OpenFile_button;
        private System.Windows.Forms.GroupBox groupBox15;
        private System.Windows.Forms.Button Write_efd_button;
        private System.Windows.Forms.GroupBox groupBox16;
        private System.Windows.Forms.RichTextBox richTextBox_Message;
        private System.Windows.Forms.GroupBox groupBox18;
        private System.Windows.Forms.GroupBox groupBox17;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.NumericUpDown num_StartCurPID_KP;
        private System.Windows.Forms.NumericUpDown num_StartCurPID_KI;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.NumericUpDown num_StartCurPID_KD;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.NumericUpDown num_ISQLimit;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.NumericUpDown num_StartSpdPID_P;
        private System.Windows.Forms.NumericUpDown num_StartSpdPID_I;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.NumericUpDown num_StartSpdPID_D;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label50;


    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace CS6257_Monitor.UserUI
{
    public partial class MonitorUI_Lite : UserControl
    {
        public struct DATA
        {
            public int SetSpeed;            // 設定轉速 (rpm)
            public int RealSpeed;           // 實際轉速 (rpm)
            public int ACVoltage;           // AC 電壓
            public double ACCurrent;        // AC 電流
            public int DCVoltage;           // DC 電壓
            public double IqCurrent;        // 轉矩電流
            public double Power;            // 入電功率

            public int IPMTemp;             // IPM 溫度
            public int MotorState;          // 馬達狀態
            public int DCFanSpeed;          // DC風扇轉速
            public int PFCState;            // PFC 狀態
            public int FourWayValveState;   // 四通閥狀態
            public int OpMode;              // 操作模式
            public int FirmwareVersion;     // 韌體版本
        }

        private TransControl trans;
        public DATA Data;

        public MonitorUI_Lite()
        {
            InitializeComponent();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="trans_ref"></param>
        public void Init_UpdateMonitorUI(TransControl trans_ref)
        {
            trans = trans_ref;
        }

        /// <summary>
        /// 更新 Monitor 控制項
        /// </summary>
        /// <param name="trans"></param>
        public void UpdateMonitorUI()
        {
            this.SetSpeed = trans.Disp_Data.MotorRunInfo.SetSpeed_rpm;
            this.RealSpeed = trans.Disp_Data.MotorRunInfo.RealSpeed_rpm;
            this.ACVoltage = trans.Disp_Data.MotorRunInfo.ACVoltage;
            this.ACCurrent = trans.Disp_Data.MotorRunInfo.ACCurrent;
            this.DCVoltage = trans.Disp_Data.MotorRunInfo.DCVoltage;
            this.IqCurrent = trans.Disp_Data.MotorRunInfo.IqCurrent;
            this.Power = trans.Disp_Data.MotorRunInfo.Power;
            this.IPMTemp = trans.Disp_Data.MotorRunInfo.IPMTemp;
            this.PFCState = trans.Disp_Data.MotorRunInfo.PFCState;
            this.OpMode = trans.Disp_Data.MotorRunInfo.OpMode;

            SystemStateDisp();
            MotorStateDisp();

            UpdateSetSpeed();
            UpdateRealSpeed();
            UpdateACVoltageCurrent();
            UpdateDCVoltage();
            UpdateIqCurrent();
            UpdatePower();

            UpdateIPMTemp();

            // Error Disp
            PowerErrorState();
            IPMFaultState();
            MotorFault();
            SensorErrDisp();

            UpdateConectionStatus(this.TB_LinkState);
            UpdateParamSynStatus(this.TB_ParaSYNState);
        }


        /// <summary>
        /// 更新設定轉速
        /// </summary>
        private void UpdateSetSpeed()
        {
            int temp = Data.SetSpeed;
            if (temp < 100) temp = 0;   // JM
            this.TB_SetSpeed.Text = temp.ToString() + " rpm";
        }

        /// <summary>
        /// 更新實際轉速
        /// </summary>
        private void UpdateRealSpeed()
        {
            int temp = Data.RealSpeed;
            if (temp < 100) temp = 0;   // JM
            this.TB_RealSpeed.Text = temp.ToString() + " rpm";
            // Update Gauge
            this.aGauge_Speed.Value = temp;
        }

        /// <summary>
        /// 更新 AC 電壓、電流
        /// </summary>
        private void UpdateACVoltageCurrent()
        {
            this.TB_ACVoltage.Text = Data.ACVoltage.ToString() + " V";
            this.TB_ACCurrent.Text = Data.ACCurrent.ToString("#0.0") + " A";
            // Update Gauge
            this.aGauge_ACVoltage.Value = Data.ACVoltage;
            this.aGauge_ACCurrent.Value = (float)Data.ACCurrent;
        }


        /// <summary>
        /// 更新 DC 電壓
        /// </summary>
        private void UpdateDCVoltage()
        {
            this.TB_DCVoltage.Text = Data.DCVoltage.ToString() + " V";
            // Update Gauge
            this.aGauge_DCVoltage.Value = Data.DCVoltage;
        }

        /// <summary>
        /// 更新轉矩電流
        /// </summary>
        private void UpdateIqCurrent()
        {
            this.TB_IqCurrent.Text = Data.IqCurrent.ToString("#0.00") + " A";
            // Update Gauge
            this.aGauge_IqCurrent.Value = (float)Data.IqCurrent;
        }

        /// <summary>
        /// 更新入電功率
        /// </summary>
        private void UpdatePower()
        {
            this.TB_Power.Text = Data.Power.ToString("#0.0") + " W";
            // Update Gauge
            this.aGauge_Power.Value = (float)Data.Power;
        }

        /// <summary>
        /// 更新IPM溫度
        /// </summary>
        private void UpdateIPMTemp()
        {
            //this.TB_IPMTemp.Text = Data.IPMTemp.ToString() + " ℃";
        }

        #region 取得數值 Get Value

        /// <summary>
        /// 設定轉速
        /// </summary>
        public int SetSpeed
        {
            set { Data.SetSpeed = value; }
        }

        /// <summary>
        /// 實際轉速
        /// </summary>
        public int RealSpeed
        {
            set { Data.RealSpeed = value; }
        }

        /// <summary>
        /// AC 電壓
        /// </summary>
        public int ACVoltage
        {
            set { Data.ACVoltage = value; }
        }

        /// <summary>
        /// AC 電流
        /// </summary>
        public double ACCurrent
        {
            set { Data.ACCurrent = value; }
        }

        /// <summary>
        /// DC 電壓
        /// </summary>
        public int DCVoltage
        {
            set { Data.DCVoltage = value; }
        }

        /// <summary>
        /// 轉矩電流
        /// </summary>
        public double IqCurrent
        {
            set { Data.IqCurrent = value; }
        }

        /// <summary>
        /// 入電功率
        /// </summary>
        public double Power
        {
            set { Data.Power = value; }
        }

        /// <summary>
        /// IPM溫度
        /// </summary>
        public int IPMTemp
        {
            set { Data.IPMTemp = value; }
        }

        /// <summary>
        /// 馬達狀態
        /// </summary>
        public int MotorState
        {
            set { Data.MotorState = value; }
        }

        /// <summary>
        /// DC風扇轉速
        /// </summary>
        public int DCFanSpeed
        {
            set { Data.DCFanSpeed = value; }
        }

        /// <summary>
        /// PFC 狀態
        /// </summary>
        public int PFCState
        {
            set { Data.PFCState = value; }
        }

        /// <summary>
        /// 四通閥狀態
        /// </summary>
        public int FourWayValveState
        {
            set { Data.FourWayValveState = value; }
        }

        /// <summary>
        /// 操作模式
        /// </summary>
        public int OpMode
        {
            set { Data.OpMode = value; }
        }

        #endregion

        /// <summary>
        /// 更新連線狀態顯示
        /// </summary>
        public void UpdateConectionStatus(TextBox textbox)
        {
            if (trans.pcState.ComState == TransControl.COM_STATE.ESTABLISHED)
            {
                textbox.ForeColor = Color.Green;
                textbox.Text = "ESTABLISHED";
            }
            else if (trans.pcState.ComState == TransControl.COM_STATE.DISCONNECTED)
            {
                textbox.ForeColor = Color.Red;
                textbox.Text = "DISCONNECTED";
            }
        }

        /// <summary>
        /// 更新參數同步狀態顯示
        /// </summary>
        public void UpdateParamSynStatus(TextBox textbox)
        {
            switch (trans.pcState.ParamState)
            {
                case TransControl.PARAM_STATE.REQ:
                    textbox.Text = "REQ";
                    break;
                case TransControl.PARAM_STATE.RECV_CHECK:
                    textbox.Text = "RECV_CHECK";
                    break;
                case TransControl.PARAM_STATE.SEND_CHECK:
                    textbox.Text = "SEND_CHECK";
                    break;
                case TransControl.PARAM_STATE.GET:
                    textbox.Text = "GET";
                    break;
                case TransControl.PARAM_STATE.GET_WAIT:
                    textbox.Text = "GET_WAIT";
                    break;
                case TransControl.PARAM_STATE.SEND:
                    textbox.Text = "SEND";
                    break;
                case TransControl.PARAM_STATE.SEND_WAIT:
                    textbox.Text = "SEND_WAIT";
                    break;
                case TransControl.PARAM_STATE.ASY:
                    textbox.Text = "ASY";
                    break;
                case TransControl.PARAM_STATE.SYN:
                    textbox.Text = "SYN";
                    break;
                case TransControl.PARAM_STATE.DEFAULT:
                    textbox.Text = "DEFAULT";
                    break;
            }
        }

        #region 控制 Control

        /// <summary>
        /// 電動機啟動按鈕
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void motor_start_button_Click(object sender, EventArgs e)
        {
            trans.Send_Start_Motor_Cmd();
        }

        /// <summary>
        /// 電動機停止按鈕
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void motor_stop_button_Click(object sender, EventArgs e)
        {
            trans.Send_Stop_Motor_Cmd();
        }

        /// <summary>
        /// 轉速設定按鈕
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void motor_spd_cmd_button_Click(object sender, EventArgs e)
        {
            Int32 spd_rpm_cmd = (Int32)this.num_spd_rpm_cmd.Value;
            if (spd_rpm_cmd < 600)
            {
                this.Spd_Cmd_trackBar.Value = 600;
            }
            else if (spd_rpm_cmd > 7200)
            {
                this.Spd_Cmd_trackBar.Value = 7200;
            }
            else
            {
                this.Spd_Cmd_trackBar.Value = spd_rpm_cmd;
            }

            trans.Send_Motor_Spd_rpm_Cmd(spd_rpm_cmd);
        }

        private void num_spd_rps_cmd_ValueChanged(object sender, EventArgs e)
        {
            int value = (int)this.num_spd_rpm_cmd.Value;

            if (value > this.Spd_Cmd_trackBar.Minimum && value < this.Spd_Cmd_trackBar.Maximum)
                this.Spd_Cmd_trackBar.Value = value;
        }

        private void Spd_Cmd_trackBar_Scroll(object sender, EventArgs e)
        {
            this.num_spd_rpm_cmd.Value = this.Spd_Cmd_trackBar.Value;
            //this.num_spd_rpm_cmd.Text = (this.num_spd_rps_cmd.Value * 60).ToString();
        }

        #endregion

        #region 錯誤顯示

        /// <summary>
        /// 電源狀態
        /// </summary>
        private void PowerErrorState()
        {
            // DC 電壓異常狀態
            if (trans.Disp_Data.FaultInfo.vBusLo)
            {
                // DC 電壓過低
                this.TB_DCVoltageErr.BackColor = Color.Crimson;
            }
            else if (trans.Disp_Data.FaultInfo.vBusHi)
            {
                // DC 電壓過高
                this.TB_DCVoltageErr.BackColor = Color.Crimson;
            }
            else
            {
                this.TB_DCVoltageErr.BackColor = Color.Silver;
            }

            // AC 電壓過高
            if (trans.Disp_Data.FaultInfo.VacHi)
            {
                this.TB_ACVoltageErr.BackColor = Color.Crimson;
            }
            // AC 電壓過低
            else if (trans.Disp_Data.FaultInfo.VacLo)
            {
                this.TB_ACVoltageErr.BackColor = Color.Crimson;
            }
            else
            {
                this.TB_ACVoltageErr.BackColor = Color.Silver;
            }

            // AC電流過高
            if (trans.Disp_Data.FaultInfo.IacOver)
            {
                this.TB_ACOverCurrent.BackColor = Color.Crimson;
            }
            else
            {
                this.TB_ACOverCurrent.BackColor = Color.Silver;
            }
        }

        /// <summary>
        /// 功率模組狀態
        /// </summary>
        private void IPMFaultState()
        {
            // IPM 功率模組故障
            if (trans.Disp_Data.FaultInfo.IPMFault)
            {
                this.TB_IPMFault.BackColor = Color.Crimson;
            }
            else
            {
                this.TB_IPMFault.BackColor = Color.Silver;
            }
        }

        /// <summary>
        /// 電機故障狀態
        /// </summary>
        private void MotorFault()
        {
            switch(trans.Disp_Data.FaultInfo.MotorFault)
            {
                case ResolvePack2.MOTOR_FAULT.None:
                    this.TB_StartUpErr.BackColor = Color.Silver;
                    this.TB_LoseSpeed.BackColor = Color.Silver;
                    this.TB_LosePhase.BackColor = Color.Silver;
                    this.TB_OverCurrent.BackColor = Color.Silver;
                    break;
                case ResolvePack2.MOTOR_FAULT.StartUpErr:
                    this.TB_StartUpErr.BackColor = Color.Crimson;
                    this.TB_LoseSpeed.BackColor = Color.Silver;
                    this.TB_LosePhase.BackColor = Color.Silver;
                    this.TB_OverCurrent.BackColor = Color.Silver;
                    break;
                case ResolvePack2.MOTOR_FAULT.ICompOver:
                    this.TB_StartUpErr.BackColor = Color.Silver;
                    this.TB_LoseSpeed.BackColor = Color.Silver;
                    this.TB_LosePhase.BackColor = Color.Silver;
                    this.TB_OverCurrent.BackColor = Color.Crimson;
                    break;
                case ResolvePack2.MOTOR_FAULT.LoseSpeed:
                    this.TB_StartUpErr.BackColor = Color.Silver;
                    this.TB_LoseSpeed.BackColor = Color.Crimson;
                    this.TB_LosePhase.BackColor = Color.Silver;
                    this.TB_OverCurrent.BackColor = Color.Silver;
                    break;
                case ResolvePack2.MOTOR_FAULT.PhaseLose:
                    this.TB_StartUpErr.BackColor = Color.Silver;
                    this.TB_LoseSpeed.BackColor = Color.Silver;
                    this.TB_LosePhase.BackColor = Color.Crimson;
                    this.TB_OverCurrent.BackColor = Color.Silver;
                    break;
                case ResolvePack2.MOTOR_FAULT.PhaseErr:
                    break;
                default:
                    break;
            }
        }

        /// <summary>
        /// 取樣電路錯誤狀態顯示
        /// </summary>
        private void SensorErrDisp()
        {
            if (trans.Disp_Data.FaultInfo.CurSensorErr)
            {
                this.TB_CurSensorErr.BackColor = Color.Crimson;
            }
            else
            {
                this.TB_CurSensorErr.BackColor = Color.Silver;
            }
        }

        #endregion

        #region 狀態顯示

        /// <summary>
        /// 
        /// </summary>
        private void SystemStateDisp()
        {
            switch(trans.Disp_Data.state)
            {
                case ResolvePack2.SYS_STATE.SYS_POWERUP_DLY:
                    this.TB_SystemState.Text = "POWERUP_DLY";
                    break;
                case ResolvePack2.SYS_STATE.SYS_IDLE:
                    this.TB_SystemState.Text = "SYS_IDLE";
                    break;
                case ResolvePack2.SYS_STATE.SYS_RESET:
                    this.TB_SystemState.Text = "SYS_RESET";
                    break;
                case ResolvePack2.SYS_STATE.SYS_RUN:
                    this.TB_SystemState.Text = "SYS_RUN";
                    break;
                case ResolvePack2.SYS_STATE.SYS_PROTECT:
                    this.TB_SystemState.Text = "SYS_PROTECT";
                    break;
                case ResolvePack2.SYS_STATE.SYS_FAULT:
                    this.TB_SystemState.Text = "SYS_FAULT";
                    break;
                case ResolvePack2.SYS_STATE.SYS_OFF_DLY:
                    this.TB_SystemState.Text = "SYS_OFF_DLY";
                    break;
                default:
                    break;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        private void MotorStateDisp()
        {
            switch(trans.Disp_Data.motorState)
            {
                case ResolvePack2.MOTOR_STATE.MOTOR_RUN:
                    this.TB_MotorState.Text = "Running";
                    this.TB_MotorState.ForeColor = Color.Green;
                    break;
                case ResolvePack2.MOTOR_STATE.MOTOR_STARTUP:
                    this.TB_MotorState.Text = "StartUp";
                    this.TB_MotorState.ForeColor = Color.Orange;
                    break;
                case ResolvePack2.MOTOR_STATE.MOTOR_STOP:
                    this.TB_MotorState.Text = "Stop";
                    this.TB_MotorState.ForeColor = Color.Red;
                    break;
                default:
                    break;
            }
        }

        #endregion

    }
}

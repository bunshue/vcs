﻿namespace CS6257_Monitor.UserUI
{
    partial class ControlUI_Lite
    {
        /// <summary> 
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 元件設計工具產生的程式碼

        /// <summary> 
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器
        /// 修改這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.panel6 = new System.Windows.Forms.Panel();
            this.Spd_Cmd_trackBar = new System.Windows.Forms.TrackBar();
            this.motor_spd_cmd_button = new System.Windows.Forms.Button();
            this.label68 = new System.Windows.Forms.Label();
            this.label67 = new System.Windows.Forms.Label();
            this.num_spd_rpm_cmd = new System.Windows.Forms.NumericUpDown();
            this.num_spd_rps_cmd = new System.Windows.Forms.NumericUpDown();
            this.label66 = new System.Windows.Forms.Label();
            this.motor_start_button = new System.Windows.Forms.Button();
            this.motor_stop_button = new System.Windows.Forms.Button();
            this.panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Spd_Cmd_trackBar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_spd_rpm_cmd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_spd_rps_cmd)).BeginInit();
            this.SuspendLayout();
            // 
            // panel6
            // 
            this.panel6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel6.Controls.Add(this.motor_start_button);
            this.panel6.Controls.Add(this.motor_stop_button);
            this.panel6.Controls.Add(this.Spd_Cmd_trackBar);
            this.panel6.Controls.Add(this.motor_spd_cmd_button);
            this.panel6.Controls.Add(this.label68);
            this.panel6.Controls.Add(this.label67);
            this.panel6.Controls.Add(this.num_spd_rpm_cmd);
            this.panel6.Controls.Add(this.num_spd_rps_cmd);
            this.panel6.Controls.Add(this.label66);
            this.panel6.Location = new System.Drawing.Point(3, 0);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(207, 290);
            this.panel6.TabIndex = 36;
            // 
            // Spd_Cmd_trackBar
            // 
            this.Spd_Cmd_trackBar.LargeChange = 10;
            this.Spd_Cmd_trackBar.Location = new System.Drawing.Point(22, 41);
            this.Spd_Cmd_trackBar.Maximum = 120;
            this.Spd_Cmd_trackBar.Minimum = 20;
            this.Spd_Cmd_trackBar.Name = "Spd_Cmd_trackBar";
            this.Spd_Cmd_trackBar.Orientation = System.Windows.Forms.Orientation.Vertical;
            this.Spd_Cmd_trackBar.Size = new System.Drawing.Size(45, 234);
            this.Spd_Cmd_trackBar.SmallChange = 10;
            this.Spd_Cmd_trackBar.TabIndex = 27;
            this.Spd_Cmd_trackBar.TickFrequency = 10;
            this.Spd_Cmd_trackBar.Value = 20;
            // 
            // motor_spd_cmd_button
            // 
            this.motor_spd_cmd_button.Location = new System.Drawing.Point(105, 123);
            this.motor_spd_cmd_button.Name = "motor_spd_cmd_button";
            this.motor_spd_cmd_button.Size = new System.Drawing.Size(65, 33);
            this.motor_spd_cmd_button.TabIndex = 25;
            this.motor_spd_cmd_button.Text = "Set";
            this.motor_spd_cmd_button.UseVisualStyleBackColor = true;
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Location = new System.Drawing.Point(176, 90);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(19, 12);
            this.label68.TabIndex = 26;
            this.label68.Text = "rps";
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Location = new System.Drawing.Point(176, 51);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(24, 12);
            this.label67.TabIndex = 22;
            this.label67.Text = "rpm";
            // 
            // num_spd_rpm_cmd
            // 
            this.num_spd_rpm_cmd.Location = new System.Drawing.Point(92, 41);
            this.num_spd_rpm_cmd.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.num_spd_rpm_cmd.Name = "num_spd_rpm_cmd";
            this.num_spd_rpm_cmd.ReadOnly = true;
            this.num_spd_rpm_cmd.Size = new System.Drawing.Size(78, 22);
            this.num_spd_rpm_cmd.TabIndex = 24;
            // 
            // num_spd_rps_cmd
            // 
            this.num_spd_rps_cmd.Location = new System.Drawing.Point(92, 80);
            this.num_spd_rps_cmd.Maximum = new decimal(new int[] {
            200,
            0,
            0,
            0});
            this.num_spd_rps_cmd.Name = "num_spd_rps_cmd";
            this.num_spd_rps_cmd.Size = new System.Drawing.Size(78, 22);
            this.num_spd_rps_cmd.TabIndex = 23;
            this.num_spd_rps_cmd.Value = new decimal(new int[] {
            20,
            0,
            0,
            0});
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label66.ForeColor = System.Drawing.Color.Maroon;
            this.label66.Location = new System.Drawing.Point(20, 12);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(123, 12);
            this.label66.TabIndex = 21;
            this.label66.Text = "Motor Speed Control";
            // 
            // motor_start_button
            // 
            this.motor_start_button.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.motor_start_button.ForeColor = System.Drawing.Color.MediumSeaGreen;
            this.motor_start_button.Location = new System.Drawing.Point(107, 173);
            this.motor_start_button.Name = "motor_start_button";
            this.motor_start_button.Size = new System.Drawing.Size(63, 46);
            this.motor_start_button.TabIndex = 19;
            this.motor_start_button.Text = "Run";
            this.motor_start_button.UseVisualStyleBackColor = true;
            // 
            // motor_stop_button
            // 
            this.motor_stop_button.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.motor_stop_button.ForeColor = System.Drawing.Color.Crimson;
            this.motor_stop_button.Location = new System.Drawing.Point(107, 226);
            this.motor_stop_button.Name = "motor_stop_button";
            this.motor_stop_button.Size = new System.Drawing.Size(63, 46);
            this.motor_stop_button.TabIndex = 20;
            this.motor_stop_button.Text = "Stop";
            this.motor_stop_button.UseVisualStyleBackColor = true;
            // 
            // ControlUI_Lite
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.panel6);
            this.Name = "ControlUI_Lite";
            this.Size = new System.Drawing.Size(220, 302);
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Spd_Cmd_trackBar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_spd_rpm_cmd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_spd_rps_cmd)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.TrackBar Spd_Cmd_trackBar;
        private System.Windows.Forms.Button motor_spd_cmd_button;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.NumericUpDown num_spd_rpm_cmd;
        private System.Windows.Forms.NumericUpDown num_spd_rps_cmd;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.Button motor_start_button;
        private System.Windows.Forms.Button motor_stop_button;
    }
}

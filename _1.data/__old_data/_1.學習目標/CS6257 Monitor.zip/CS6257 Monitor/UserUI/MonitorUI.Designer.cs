﻿namespace CS6257_Monitor
{
    partial class MonitorUI
    {
        /// <summary> 
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 元件設計工具產生的程式碼

        /// <summary> 
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器
        /// 修改這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.TB_DCFanSpeed = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.TB_ACCurrent = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.TB_Power = new System.Windows.Forms.TextBox();
            this.TB_IqCurrent = new System.Windows.Forms.TextBox();
            this.TB_RealSpeed = new System.Windows.Forms.TextBox();
            this.TB_FourWayValveState = new System.Windows.Forms.TextBox();
            this.TB_PFCState = new System.Windows.Forms.TextBox();
            this.TB_FirmwareVer = new System.Windows.Forms.TextBox();
            this.TB_OpMode = new System.Windows.Forms.TextBox();
            this.TB_MotorState = new System.Windows.Forms.TextBox();
            this.TB_IPMTemp = new System.Windows.Forms.TextBox();
            this.TB_SetSpeed = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.TB_DCVoltage = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.TB_ACVoltage = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.groupBox3.Controls.Add(this.TB_DCFanSpeed);
            this.groupBox3.Controls.Add(this.label17);
            this.groupBox3.Controls.Add(this.TB_ACCurrent);
            this.groupBox3.Controls.Add(this.label10);
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Controls.Add(this.label4);
            this.groupBox3.Controls.Add(this.label3);
            this.groupBox3.Controls.Add(this.TB_Power);
            this.groupBox3.Controls.Add(this.TB_IqCurrent);
            this.groupBox3.Controls.Add(this.TB_RealSpeed);
            this.groupBox3.Controls.Add(this.TB_FourWayValveState);
            this.groupBox3.Controls.Add(this.TB_PFCState);
            this.groupBox3.Controls.Add(this.TB_FirmwareVer);
            this.groupBox3.Controls.Add(this.TB_OpMode);
            this.groupBox3.Controls.Add(this.TB_MotorState);
            this.groupBox3.Controls.Add(this.TB_IPMTemp);
            this.groupBox3.Controls.Add(this.TB_SetSpeed);
            this.groupBox3.Controls.Add(this.label11);
            this.groupBox3.Controls.Add(this.label16);
            this.groupBox3.Controls.Add(this.TB_DCVoltage);
            this.groupBox3.Controls.Add(this.label9);
            this.groupBox3.Controls.Add(this.label2);
            this.groupBox3.Controls.Add(this.label8);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Controls.Add(this.label7);
            this.groupBox3.Controls.Add(this.label12);
            this.groupBox3.Controls.Add(this.TB_ACVoltage);
            this.groupBox3.Controls.Add(this.label1);
            this.groupBox3.Location = new System.Drawing.Point(3, 3);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(1304, 191);
            this.groupBox3.TabIndex = 35;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "監控介面";
            // 
            // TB_DCFanSpeed
            // 
            this.TB_DCFanSpeed.BackColor = System.Drawing.Color.Green;
            this.TB_DCFanSpeed.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TB_DCFanSpeed.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.TB_DCFanSpeed.Font = new System.Drawing.Font("Consolas", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TB_DCFanSpeed.ForeColor = System.Drawing.Color.MediumSpringGreen;
            this.TB_DCFanSpeed.Location = new System.Drawing.Point(380, 128);
            this.TB_DCFanSpeed.Name = "TB_DCFanSpeed";
            this.TB_DCFanSpeed.ReadOnly = true;
            this.TB_DCFanSpeed.Size = new System.Drawing.Size(178, 51);
            this.TB_DCFanSpeed.TabIndex = 2;
            this.TB_DCFanSpeed.Text = "750 rpm";
            this.TB_DCFanSpeed.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("新細明體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label17.Location = new System.Drawing.Point(380, 112);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(85, 13);
            this.label17.TabIndex = 3;
            this.label17.Text = "外機風扇轉速";
            // 
            // TB_ACCurrent
            // 
            this.TB_ACCurrent.BackColor = System.Drawing.Color.Green;
            this.TB_ACCurrent.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TB_ACCurrent.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.TB_ACCurrent.Font = new System.Drawing.Font("Consolas", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TB_ACCurrent.ForeColor = System.Drawing.Color.MediumSpringGreen;
            this.TB_ACCurrent.Location = new System.Drawing.Point(565, 40);
            this.TB_ACCurrent.Name = "TB_ACCurrent";
            this.TB_ACCurrent.ReadOnly = true;
            this.TB_ACCurrent.Size = new System.Drawing.Size(178, 51);
            this.TB_ACCurrent.TabIndex = 0;
            this.TB_ACCurrent.Text = "10.5 A";
            this.TB_ACCurrent.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("新細明體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label10.Location = new System.Drawing.Point(1120, 24);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(59, 13);
            this.label10.TabIndex = 1;
            this.label10.Text = "入電功率";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("新細明體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label5.Location = new System.Drawing.Point(935, 24);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(59, 13);
            this.label5.TabIndex = 1;
            this.label5.Text = "轉矩電流";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("新細明體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label4.Location = new System.Drawing.Point(750, 24);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(53, 13);
            this.label4.TabIndex = 1;
            this.label4.Text = "DC 電壓";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("新細明體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label3.Location = new System.Drawing.Point(380, 24);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 13);
            this.label3.TabIndex = 1;
            this.label3.Text = "AC 電壓";
            // 
            // TB_Power
            // 
            this.TB_Power.BackColor = System.Drawing.Color.Green;
            this.TB_Power.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TB_Power.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.TB_Power.Font = new System.Drawing.Font("Consolas", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TB_Power.ForeColor = System.Drawing.Color.MediumSpringGreen;
            this.TB_Power.Location = new System.Drawing.Point(1120, 40);
            this.TB_Power.Name = "TB_Power";
            this.TB_Power.ReadOnly = true;
            this.TB_Power.Size = new System.Drawing.Size(178, 51);
            this.TB_Power.TabIndex = 0;
            this.TB_Power.Text = "2210.0 W";
            this.TB_Power.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // TB_IqCurrent
            // 
            this.TB_IqCurrent.BackColor = System.Drawing.Color.Green;
            this.TB_IqCurrent.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TB_IqCurrent.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.TB_IqCurrent.Font = new System.Drawing.Font("Consolas", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TB_IqCurrent.ForeColor = System.Drawing.Color.MediumSpringGreen;
            this.TB_IqCurrent.Location = new System.Drawing.Point(935, 40);
            this.TB_IqCurrent.Name = "TB_IqCurrent";
            this.TB_IqCurrent.ReadOnly = true;
            this.TB_IqCurrent.Size = new System.Drawing.Size(178, 51);
            this.TB_IqCurrent.TabIndex = 0;
            this.TB_IqCurrent.Text = "12.2 A";
            this.TB_IqCurrent.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // TB_RealSpeed
            // 
            this.TB_RealSpeed.BackColor = System.Drawing.Color.Green;
            this.TB_RealSpeed.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TB_RealSpeed.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.TB_RealSpeed.Font = new System.Drawing.Font("Consolas", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TB_RealSpeed.ForeColor = System.Drawing.Color.MediumSpringGreen;
            this.TB_RealSpeed.Location = new System.Drawing.Point(195, 40);
            this.TB_RealSpeed.Name = "TB_RealSpeed";
            this.TB_RealSpeed.ReadOnly = true;
            this.TB_RealSpeed.Size = new System.Drawing.Size(178, 51);
            this.TB_RealSpeed.TabIndex = 0;
            this.TB_RealSpeed.Text = "1200 rpm";
            this.TB_RealSpeed.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // TB_FourWayValveState
            // 
            this.TB_FourWayValveState.BackColor = System.Drawing.Color.Green;
            this.TB_FourWayValveState.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TB_FourWayValveState.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.TB_FourWayValveState.Font = new System.Drawing.Font("Consolas", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TB_FourWayValveState.ForeColor = System.Drawing.Color.OrangeRed;
            this.TB_FourWayValveState.Location = new System.Drawing.Point(750, 128);
            this.TB_FourWayValveState.Name = "TB_FourWayValveState";
            this.TB_FourWayValveState.ReadOnly = true;
            this.TB_FourWayValveState.Size = new System.Drawing.Size(178, 51);
            this.TB_FourWayValveState.TabIndex = 0;
            this.TB_FourWayValveState.Text = "OFF";
            this.TB_FourWayValveState.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // TB_PFCState
            // 
            this.TB_PFCState.BackColor = System.Drawing.Color.Green;
            this.TB_PFCState.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TB_PFCState.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.TB_PFCState.Font = new System.Drawing.Font("Consolas", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TB_PFCState.ForeColor = System.Drawing.Color.OrangeRed;
            this.TB_PFCState.Location = new System.Drawing.Point(565, 128);
            this.TB_PFCState.Name = "TB_PFCState";
            this.TB_PFCState.ReadOnly = true;
            this.TB_PFCState.Size = new System.Drawing.Size(178, 51);
            this.TB_PFCState.TabIndex = 0;
            this.TB_PFCState.Text = "OFF";
            this.TB_PFCState.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // TB_FirmwareVer
            // 
            this.TB_FirmwareVer.BackColor = System.Drawing.Color.SteelBlue;
            this.TB_FirmwareVer.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TB_FirmwareVer.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.TB_FirmwareVer.Font = new System.Drawing.Font("Consolas", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TB_FirmwareVer.ForeColor = System.Drawing.Color.AliceBlue;
            this.TB_FirmwareVer.Location = new System.Drawing.Point(1120, 128);
            this.TB_FirmwareVer.Name = "TB_FirmwareVer";
            this.TB_FirmwareVer.ReadOnly = true;
            this.TB_FirmwareVer.Size = new System.Drawing.Size(178, 51);
            this.TB_FirmwareVer.TabIndex = 0;
            this.TB_FirmwareVer.Text = "A1";
            this.TB_FirmwareVer.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // TB_OpMode
            // 
            this.TB_OpMode.BackColor = System.Drawing.Color.Green;
            this.TB_OpMode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TB_OpMode.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.TB_OpMode.Font = new System.Drawing.Font("Consolas", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TB_OpMode.ForeColor = System.Drawing.Color.MediumSpringGreen;
            this.TB_OpMode.Location = new System.Drawing.Point(935, 128);
            this.TB_OpMode.Name = "TB_OpMode";
            this.TB_OpMode.ReadOnly = true;
            this.TB_OpMode.Size = new System.Drawing.Size(178, 51);
            this.TB_OpMode.TabIndex = 0;
            this.TB_OpMode.Text = "Manual";
            this.TB_OpMode.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // TB_MotorState
            // 
            this.TB_MotorState.BackColor = System.Drawing.Color.Green;
            this.TB_MotorState.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TB_MotorState.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.TB_MotorState.Font = new System.Drawing.Font("Consolas", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TB_MotorState.ForeColor = System.Drawing.Color.MediumSpringGreen;
            this.TB_MotorState.Location = new System.Drawing.Point(195, 128);
            this.TB_MotorState.Name = "TB_MotorState";
            this.TB_MotorState.ReadOnly = true;
            this.TB_MotorState.Size = new System.Drawing.Size(178, 51);
            this.TB_MotorState.TabIndex = 0;
            this.TB_MotorState.Text = "RUNING";
            this.TB_MotorState.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // TB_IPMTemp
            // 
            this.TB_IPMTemp.BackColor = System.Drawing.Color.Green;
            this.TB_IPMTemp.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TB_IPMTemp.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.TB_IPMTemp.Font = new System.Drawing.Font("Consolas", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TB_IPMTemp.ForeColor = System.Drawing.Color.MediumSpringGreen;
            this.TB_IPMTemp.Location = new System.Drawing.Point(10, 128);
            this.TB_IPMTemp.Name = "TB_IPMTemp";
            this.TB_IPMTemp.ReadOnly = true;
            this.TB_IPMTemp.Size = new System.Drawing.Size(178, 51);
            this.TB_IPMTemp.TabIndex = 0;
            this.TB_IPMTemp.Text = "55 ℃";
            this.TB_IPMTemp.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // TB_SetSpeed
            // 
            this.TB_SetSpeed.BackColor = System.Drawing.Color.Green;
            this.TB_SetSpeed.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TB_SetSpeed.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.TB_SetSpeed.Font = new System.Drawing.Font("Consolas", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TB_SetSpeed.ForeColor = System.Drawing.Color.MediumSpringGreen;
            this.TB_SetSpeed.Location = new System.Drawing.Point(10, 40);
            this.TB_SetSpeed.Name = "TB_SetSpeed";
            this.TB_SetSpeed.ReadOnly = true;
            this.TB_SetSpeed.Size = new System.Drawing.Size(178, 51);
            this.TB_SetSpeed.TabIndex = 0;
            this.TB_SetSpeed.Text = "1200 rpm";
            this.TB_SetSpeed.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("新細明體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label11.Location = new System.Drawing.Point(1120, 112);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(78, 13);
            this.label11.TabIndex = 1;
            this.label11.Text = "Firmware Ver.";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("新細明體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label16.Location = new System.Drawing.Point(935, 112);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(59, 13);
            this.label16.TabIndex = 1;
            this.label16.Text = "操作模式";
            // 
            // TB_DCVoltage
            // 
            this.TB_DCVoltage.BackColor = System.Drawing.Color.Green;
            this.TB_DCVoltage.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TB_DCVoltage.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.TB_DCVoltage.Font = new System.Drawing.Font("Consolas", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TB_DCVoltage.ForeColor = System.Drawing.Color.MediumSpringGreen;
            this.TB_DCVoltage.Location = new System.Drawing.Point(750, 40);
            this.TB_DCVoltage.Name = "TB_DCVoltage";
            this.TB_DCVoltage.ReadOnly = true;
            this.TB_DCVoltage.Size = new System.Drawing.Size(178, 51);
            this.TB_DCVoltage.TabIndex = 0;
            this.TB_DCVoltage.Text = "220 V";
            this.TB_DCVoltage.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("新細明體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label9.Location = new System.Drawing.Point(750, 112);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(72, 13);
            this.label9.TabIndex = 1;
            this.label9.Text = "四通閥狀態";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("新細明體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label2.Location = new System.Drawing.Point(565, 24);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "AC 電流";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("新細明體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label8.Location = new System.Drawing.Point(565, 112);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(55, 13);
            this.label8.TabIndex = 1;
            this.label8.Text = "PFC狀態";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("新細明體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label6.Location = new System.Drawing.Point(195, 24);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(59, 13);
            this.label6.TabIndex = 1;
            this.label6.Text = "實際轉速";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("新細明體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label7.Location = new System.Drawing.Point(195, 112);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(72, 13);
            this.label7.TabIndex = 1;
            this.label7.Text = "壓縮機狀態";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("新細明體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label12.Location = new System.Drawing.Point(10, 112);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(58, 13);
            this.label12.TabIndex = 1;
            this.label12.Text = "IPM 溫度";
            // 
            // TB_ACVoltage
            // 
            this.TB_ACVoltage.BackColor = System.Drawing.Color.Green;
            this.TB_ACVoltage.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TB_ACVoltage.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.TB_ACVoltage.Font = new System.Drawing.Font("Consolas", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TB_ACVoltage.ForeColor = System.Drawing.Color.MediumSpringGreen;
            this.TB_ACVoltage.Location = new System.Drawing.Point(380, 40);
            this.TB_ACVoltage.Name = "TB_ACVoltage";
            this.TB_ACVoltage.ReadOnly = true;
            this.TB_ACVoltage.Size = new System.Drawing.Size(178, 51);
            this.TB_ACVoltage.TabIndex = 0;
            this.TB_ACVoltage.Text = "220 V";
            this.TB_ACVoltage.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("新細明體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label1.Location = new System.Drawing.Point(10, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(59, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "設定轉速";
            // 
            // MonitorUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.groupBox3);
            this.Name = "MonitorUI";
            this.Size = new System.Drawing.Size(1307, 197);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox TB_DCFanSpeed;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox TB_ACCurrent;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox TB_Power;
        private System.Windows.Forms.TextBox TB_IqCurrent;
        private System.Windows.Forms.TextBox TB_RealSpeed;
        private System.Windows.Forms.TextBox TB_FourWayValveState;
        private System.Windows.Forms.TextBox TB_PFCState;
        private System.Windows.Forms.TextBox TB_FirmwareVer;
        private System.Windows.Forms.TextBox TB_OpMode;
        private System.Windows.Forms.TextBox TB_MotorState;
        private System.Windows.Forms.TextBox TB_IPMTemp;
        private System.Windows.Forms.TextBox TB_SetSpeed;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox TB_DCVoltage;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox TB_ACVoltage;
        private System.Windows.Forms.Label label1;
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading;

namespace CS6257_Monitor
{
    class Recoder
    {
        private Thread recoder_thread;
        private FileStream fs;

        private bool FileOpen_Flag = false;
        private bool Record_Flag = false;

        private string folderpath;          // 紀錄資料夾路徑
        private string filename;            // 檔案名稱
        private string fullpath;

        private DateTime start_time;

        private TransControl baseclass;

        /// <summary>
        /// 建構函式
        /// </summary>
        public Recoder(TransControl bc_ptr)
        {
            baseclass = bc_ptr;
            folderpath = System.IO.Directory.GetCurrentDirectory();
            recoder_thread = new Thread(new ThreadStart(Record_DoWork));
            recoder_thread.IsBackground = true;
            recoder_thread.Start();
        }

        /// <summary>
        /// 
        /// </summary>
        private void Record_DoWork()
        {
            string str = string.Empty;
            byte[] b;
            while(true)
            {
                if (FileOpen_Flag)
                {
                    //stream_writer.WriteLine(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
                    str = string.Empty;
                    str = DateTime.Now.ToString("HH:mm:ss");
                    for (int ii = 0; ii < 130; ii++)
                    {
                        str += "\t" + baseclass.SciBuf.RxBuff[ii].ToString();
                        //str += "\t" + ii.ToString();
                    }
                    str += "\n";
                    b = Encoding.ASCII.GetBytes(str);
                    fs.Write(b, 0, b.Length);
                }
                Thread.Sleep(1000);
            }
        }

        /// <summary>
        /// 設定 / 取得紀錄資料夾路徑
        /// </summary>
        public string FilePath
        {
            get
            {
                return folderpath;
            }
            set
            {
                folderpath = value;
            }
        }

        /// <summary>
        /// 取得現在時間
        /// </summary>
        public string  NowTime
        {
            get
            {
                return DateTime.Now.ToString();
                //return DateTime.Now.Ticks.ToString();
            }
        }

        /// <summary>
        /// 取得開始記錄時間
        /// </summary>
        public string StartTime
        {
            get
            {
                return start_time.ToString();
            }
        }

        /// <summary>
        /// 取得紀錄時間
        /// </summary>
        public string RecoderTime
        {
            get
            {
                string str = string.Empty;
                TimeSpan span;
                if (Record_Flag == true)
                {
                    span = DateTime.Now - start_time;
                    str = span.ToString();
                    str = str.Substring(0, str.IndexOf("."));
                }
                else
                {
                    span = TimeSpan.Zero;
                    str = span.ToString();
                }
                return str;
            }
        }

        /// <summary>
        /// 取得紀錄狀態
        /// </summary>
        /// <returns></returns>
        public bool IsRecoder()
        {
            return Record_Flag;
        }

        /// <summary>
        /// 開始記錄
        /// </summary>
        public void StartRecord()
        {
            if (Record_Flag == false)
            {
                Record_Flag = true;
                start_time = DateTime.Now;

                CreateNewFile();

            }
            else
            {
                Record_Flag = false;
                CloseFile();
            }
            
        }

        /// <summary>
        /// 建立新檔案
        /// </summary>
        public void CreateNewFile()
        {
            if (FileOpen_Flag == false)
            {
                // 使用現在時間建立檔案名稱
                filename = DateTime.Now.Year.ToString();
                filename += DateTime.Now.Month.ToString("00");
                filename += DateTime.Now.Day.ToString("00");
                filename += DateTime.Now.Hour.ToString("00");
                filename += DateTime.Now.Minute.ToString("00");
                filename += DateTime.Now.Second.ToString("00");
                filename += ".txt";
                fullpath = folderpath + "\\" + filename;
                fs = File.Open(fullpath, FileMode.Create);
                //stream_writer = new StreamWriter(fs);
                FileOpen_Flag = true;
            }
        }

        /// <summary>
        /// 關閉檔案
        /// </summary>
        public void CloseFile()
        {
            if (FileOpen_Flag == true)
            {
                FileOpen_Flag = false;
                //stream_writer.Close();
                fs.Close();
            }
        }
    }
}

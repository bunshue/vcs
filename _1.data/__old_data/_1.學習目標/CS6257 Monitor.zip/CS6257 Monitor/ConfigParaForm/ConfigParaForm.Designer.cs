﻿namespace CS6257_Monitor
{
    partial class ConfigParaForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.UpdateParam_button = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.numericUpDown7 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown14 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown13 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown8 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown6 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown3 = new System.Windows.Forms.NumericUpDown();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.numericUpDown12 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown11 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown5 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown10 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown9 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown2 = new System.Windows.Forms.NumericUpDown();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.num_PolePair = new System.Windows.Forms.NumericUpDown();
            this.num_Lq = new System.Windows.Forms.NumericUpDown();
            this.num_Ld = new System.Windows.Forms.NumericUpDown();
            this.num_Rs = new System.Windows.Forms.NumericUpDown();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown4 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown15 = new System.Windows.Forms.NumericUpDown();
            this.label21 = new System.Windows.Forms.Label();
            this.numericUpDown16 = new System.Windows.Forms.NumericUpDown();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.numericUpDown17 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown18 = new System.Windows.Forms.NumericUpDown();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.numericUpDown19 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown20 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown21 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown22 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown23 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown24 = new System.Windows.Forms.NumericUpDown();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown3)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.num_PolePair)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_Lq)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_Ld)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_Rs)).BeginInit();
            this.groupBox5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown18)).BeginInit();
            this.groupBox6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown20)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown21)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown22)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown23)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown24)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Location = new System.Drawing.Point(12, 12);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(800, 562);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.groupBox6);
            this.tabPage1.Controls.Add(this.groupBox5);
            this.tabPage1.Controls.Add(this.groupBox4);
            this.tabPage1.Controls.Add(this.groupBox3);
            this.tabPage1.Controls.Add(this.groupBox2);
            this.tabPage1.Controls.Add(this.groupBox1);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(792, 536);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "參數調整";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.textBox1);
            this.groupBox4.Controls.Add(this.label10);
            this.groupBox4.Controls.Add(this.UpdateParam_button);
            this.groupBox4.Location = new System.Drawing.Point(400, 327);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(384, 203);
            this.groupBox4.TabIndex = 6;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "更新狀態";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(17, 49);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 22);
            this.textBox1.TabIndex = 8;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(15, 34);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(53, 12);
            this.label10.TabIndex = 0;
            this.label10.Text = "同步狀態";
            // 
            // UpdateParam_button
            // 
            this.UpdateParam_button.Location = new System.Drawing.Point(303, 156);
            this.UpdateParam_button.Name = "UpdateParam_button";
            this.UpdateParam_button.Size = new System.Drawing.Size(75, 41);
            this.UpdateParam_button.TabIndex = 7;
            this.UpdateParam_button.Text = "更新";
            this.UpdateParam_button.UseVisualStyleBackColor = true;
            this.UpdateParam_button.Click += new System.EventHandler(this.UpdateParam_button_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.numericUpDown7);
            this.groupBox3.Controls.Add(this.numericUpDown14);
            this.groupBox3.Controls.Add(this.numericUpDown13);
            this.groupBox3.Controls.Add(this.numericUpDown8);
            this.groupBox3.Controls.Add(this.numericUpDown6);
            this.groupBox3.Controls.Add(this.numericUpDown3);
            this.groupBox3.Controls.Add(this.label9);
            this.groupBox3.Controls.Add(this.label8);
            this.groupBox3.Controls.Add(this.label7);
            this.groupBox3.Controls.Add(this.label17);
            this.groupBox3.Controls.Add(this.label16);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Location = new System.Drawing.Point(6, 158);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(388, 203);
            this.groupBox3.TabIndex = 5;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "馬達運轉基本參數設定";
            // 
            // numericUpDown7
            // 
            this.numericUpDown7.Location = new System.Drawing.Point(266, 49);
            this.numericUpDown7.Name = "numericUpDown7";
            this.numericUpDown7.Size = new System.Drawing.Size(101, 22);
            this.numericUpDown7.TabIndex = 1;
            this.numericUpDown7.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // numericUpDown14
            // 
            this.numericUpDown14.DecimalPlaces = 2;
            this.numericUpDown14.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.numericUpDown14.Location = new System.Drawing.Point(143, 150);
            this.numericUpDown14.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.numericUpDown14.Name = "numericUpDown14";
            this.numericUpDown14.Size = new System.Drawing.Size(101, 22);
            this.numericUpDown14.TabIndex = 1;
            this.numericUpDown14.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // numericUpDown13
            // 
            this.numericUpDown13.DecimalPlaces = 2;
            this.numericUpDown13.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.numericUpDown13.Location = new System.Drawing.Point(21, 150);
            this.numericUpDown13.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.numericUpDown13.Name = "numericUpDown13";
            this.numericUpDown13.Size = new System.Drawing.Size(101, 22);
            this.numericUpDown13.TabIndex = 1;
            this.numericUpDown13.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // numericUpDown8
            // 
            this.numericUpDown8.DecimalPlaces = 2;
            this.numericUpDown8.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.numericUpDown8.Location = new System.Drawing.Point(21, 100);
            this.numericUpDown8.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.numericUpDown8.Name = "numericUpDown8";
            this.numericUpDown8.Size = new System.Drawing.Size(101, 22);
            this.numericUpDown8.TabIndex = 1;
            this.numericUpDown8.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // numericUpDown6
            // 
            this.numericUpDown6.Location = new System.Drawing.Point(143, 49);
            this.numericUpDown6.Name = "numericUpDown6";
            this.numericUpDown6.Size = new System.Drawing.Size(101, 22);
            this.numericUpDown6.TabIndex = 1;
            this.numericUpDown6.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // numericUpDown3
            // 
            this.numericUpDown3.Location = new System.Drawing.Point(21, 49);
            this.numericUpDown3.Name = "numericUpDown3";
            this.numericUpDown3.Size = new System.Drawing.Size(101, 22);
            this.numericUpDown3.TabIndex = 1;
            this.numericUpDown3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(19, 85);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(117, 12);
            this.label9.TabIndex = 0;
            this.label9.Text = "加速 / 減速斜率 ( rps )";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(264, 34);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(108, 12);
            this.label8.TabIndex = 0;
            this.label8.Text = "啟動基本轉速 ( rps )";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(141, 34);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(84, 12);
            this.label7.TabIndex = 0;
            this.label7.Text = "最大轉速 ( rps )";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(141, 135);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(102, 12);
            this.label17.TabIndex = 0;
            this.label17.Text = "最大轉矩電流 ( A )";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(19, 135);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(102, 12);
            this.label16.TabIndex = 0;
            this.label16.Text = "啟動最大電流 ( A )";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(24, 34);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(84, 12);
            this.label6.TabIndex = 0;
            this.label6.Text = "最小轉速 ( rps )";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.numericUpDown12);
            this.groupBox2.Controls.Add(this.numericUpDown11);
            this.groupBox2.Controls.Add(this.numericUpDown5);
            this.groupBox2.Controls.Add(this.numericUpDown10);
            this.groupBox2.Controls.Add(this.numericUpDown9);
            this.groupBox2.Controls.Add(this.numericUpDown2);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Location = new System.Drawing.Point(400, 6);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(384, 145);
            this.groupBox2.TabIndex = 4;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "馬達啟動參數調整";
            // 
            // numericUpDown12
            // 
            this.numericUpDown12.Location = new System.Drawing.Point(257, 98);
            this.numericUpDown12.Maximum = new decimal(new int[] {
            1215752192,
            23,
            0,
            0});
            this.numericUpDown12.Name = "numericUpDown12";
            this.numericUpDown12.Size = new System.Drawing.Size(101, 22);
            this.numericUpDown12.TabIndex = 1;
            this.numericUpDown12.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // numericUpDown11
            // 
            this.numericUpDown11.Location = new System.Drawing.Point(139, 98);
            this.numericUpDown11.Maximum = new decimal(new int[] {
            1215752192,
            23,
            0,
            0});
            this.numericUpDown11.Name = "numericUpDown11";
            this.numericUpDown11.Size = new System.Drawing.Size(101, 22);
            this.numericUpDown11.TabIndex = 1;
            this.numericUpDown11.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // numericUpDown5
            // 
            this.numericUpDown5.Location = new System.Drawing.Point(17, 98);
            this.numericUpDown5.Maximum = new decimal(new int[] {
            1215752192,
            23,
            0,
            0});
            this.numericUpDown5.Name = "numericUpDown5";
            this.numericUpDown5.Size = new System.Drawing.Size(101, 22);
            this.numericUpDown5.TabIndex = 1;
            this.numericUpDown5.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // numericUpDown10
            // 
            this.numericUpDown10.DecimalPlaces = 2;
            this.numericUpDown10.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.numericUpDown10.Location = new System.Drawing.Point(257, 45);
            this.numericUpDown10.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.numericUpDown10.Name = "numericUpDown10";
            this.numericUpDown10.Size = new System.Drawing.Size(101, 22);
            this.numericUpDown10.TabIndex = 1;
            this.numericUpDown10.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // numericUpDown9
            // 
            this.numericUpDown9.DecimalPlaces = 2;
            this.numericUpDown9.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.numericUpDown9.Location = new System.Drawing.Point(139, 45);
            this.numericUpDown9.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.numericUpDown9.Name = "numericUpDown9";
            this.numericUpDown9.Size = new System.Drawing.Size(101, 22);
            this.numericUpDown9.TabIndex = 1;
            this.numericUpDown9.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // numericUpDown2
            // 
            this.numericUpDown2.DecimalPlaces = 2;
            this.numericUpDown2.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.numericUpDown2.Location = new System.Drawing.Point(17, 45);
            this.numericUpDown2.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.numericUpDown2.Name = "numericUpDown2";
            this.numericUpDown2.Size = new System.Drawing.Size(101, 22);
            this.numericUpDown2.TabIndex = 1;
            this.numericUpDown2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(255, 30);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(87, 12);
            this.label12.TabIndex = 0;
            this.label12.Text = "啟動電流 3 ( A )";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(137, 30);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(87, 12);
            this.label11.TabIndex = 0;
            this.label11.Text = "啟動電流 2 ( A )";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(255, 83);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(119, 12);
            this.label15.TabIndex = 0;
            this.label15.Text = "啟動階段 3 時間 ( ms )";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(137, 83);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(119, 12);
            this.label14.TabIndex = 0;
            this.label14.Text = "啟動階段 2 時間 ( ms )";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(15, 83);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(119, 12);
            this.label13.TabIndex = 0;
            this.label13.Text = "啟動階段 1 時間 ( ms )";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(15, 30);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(87, 12);
            this.label5.TabIndex = 0;
            this.label5.Text = "啟動電流 1 ( A )";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.num_PolePair);
            this.groupBox1.Controls.Add(this.num_Lq);
            this.groupBox1.Controls.Add(this.num_Ld);
            this.groupBox1.Controls.Add(this.num_Rs);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(6, 6);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(388, 145);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "馬達參數調整";
            // 
            // num_PolePair
            // 
            this.num_PolePair.Location = new System.Drawing.Point(21, 98);
            this.num_PolePair.Name = "num_PolePair";
            this.num_PolePair.Size = new System.Drawing.Size(101, 22);
            this.num_PolePair.TabIndex = 1;
            this.num_PolePair.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // num_Lq
            // 
            this.num_Lq.DecimalPlaces = 5;
            this.num_Lq.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.num_Lq.Location = new System.Drawing.Point(266, 45);
            this.num_Lq.Name = "num_Lq";
            this.num_Lq.Size = new System.Drawing.Size(101, 22);
            this.num_Lq.TabIndex = 1;
            this.num_Lq.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // num_Ld
            // 
            this.num_Ld.DecimalPlaces = 5;
            this.num_Ld.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.num_Ld.Location = new System.Drawing.Point(143, 45);
            this.num_Ld.Name = "num_Ld";
            this.num_Ld.Size = new System.Drawing.Size(101, 22);
            this.num_Ld.TabIndex = 1;
            this.num_Ld.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // num_Rs
            // 
            this.num_Rs.DecimalPlaces = 5;
            this.num_Rs.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.num_Rs.Location = new System.Drawing.Point(21, 45);
            this.num_Rs.Name = "num_Rs";
            this.num_Rs.Size = new System.Drawing.Size(101, 22);
            this.num_Rs.TabIndex = 1;
            this.num_Rs.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(19, 83);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(85, 12);
            this.label4.TabIndex = 0;
            this.label4.Text = "極對數 Pole Pair";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(264, 30);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(103, 12);
            this.label3.TabIndex = 0;
            this.label3.Text = "定子Q軸電感 ( Lq )";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(141, 30);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(103, 12);
            this.label2.TabIndex = 0;
            this.label2.Text = "定子D軸電感 ( Ld )";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(19, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(82, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "定子電阻 ( Rs )";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.label20);
            this.groupBox5.Controls.Add(this.label19);
            this.groupBox5.Controls.Add(this.label23);
            this.groupBox5.Controls.Add(this.label22);
            this.groupBox5.Controls.Add(this.label21);
            this.groupBox5.Controls.Add(this.label18);
            this.groupBox5.Controls.Add(this.numericUpDown15);
            this.groupBox5.Controls.Add(this.numericUpDown4);
            this.groupBox5.Controls.Add(this.numericUpDown18);
            this.groupBox5.Controls.Add(this.numericUpDown17);
            this.groupBox5.Controls.Add(this.numericUpDown16);
            this.groupBox5.Controls.Add(this.numericUpDown1);
            this.groupBox5.Location = new System.Drawing.Point(6, 367);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(388, 139);
            this.groupBox5.TabIndex = 7;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "控制器參數";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(19, 32);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(45, 12);
            this.label18.TabIndex = 0;
            this.label18.Text = "IDQ_KP";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(141, 32);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(43, 12);
            this.label19.TabIndex = 0;
            this.label19.Text = "IDQ_KI";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(264, 32);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(47, 12);
            this.label20.TabIndex = 0;
            this.label20.Text = "IDQ_KD";
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.DecimalPlaces = 5;
            this.numericUpDown1.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.numericUpDown1.Location = new System.Drawing.Point(21, 47);
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(101, 22);
            this.numericUpDown1.TabIndex = 1;
            this.numericUpDown1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // numericUpDown4
            // 
            this.numericUpDown4.DecimalPlaces = 5;
            this.numericUpDown4.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.numericUpDown4.Location = new System.Drawing.Point(143, 47);
            this.numericUpDown4.Name = "numericUpDown4";
            this.numericUpDown4.Size = new System.Drawing.Size(101, 22);
            this.numericUpDown4.TabIndex = 1;
            this.numericUpDown4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // numericUpDown15
            // 
            this.numericUpDown15.DecimalPlaces = 5;
            this.numericUpDown15.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.numericUpDown15.Location = new System.Drawing.Point(266, 47);
            this.numericUpDown15.Name = "numericUpDown15";
            this.numericUpDown15.Size = new System.Drawing.Size(101, 22);
            this.numericUpDown15.TabIndex = 1;
            this.numericUpDown15.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(19, 80);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(45, 12);
            this.label21.TabIndex = 0;
            this.label21.Text = "SPD_KP";
            // 
            // numericUpDown16
            // 
            this.numericUpDown16.DecimalPlaces = 5;
            this.numericUpDown16.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.numericUpDown16.Location = new System.Drawing.Point(21, 95);
            this.numericUpDown16.Name = "numericUpDown16";
            this.numericUpDown16.Size = new System.Drawing.Size(101, 22);
            this.numericUpDown16.TabIndex = 1;
            this.numericUpDown16.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(141, 80);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(43, 12);
            this.label22.TabIndex = 0;
            this.label22.Text = "SPD_KI";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(264, 80);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(47, 12);
            this.label23.TabIndex = 0;
            this.label23.Text = "SPD_KD";
            // 
            // numericUpDown17
            // 
            this.numericUpDown17.DecimalPlaces = 5;
            this.numericUpDown17.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.numericUpDown17.Location = new System.Drawing.Point(142, 95);
            this.numericUpDown17.Name = "numericUpDown17";
            this.numericUpDown17.Size = new System.Drawing.Size(101, 22);
            this.numericUpDown17.TabIndex = 1;
            this.numericUpDown17.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // numericUpDown18
            // 
            this.numericUpDown18.DecimalPlaces = 5;
            this.numericUpDown18.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.numericUpDown18.Location = new System.Drawing.Point(266, 95);
            this.numericUpDown18.Name = "numericUpDown18";
            this.numericUpDown18.Size = new System.Drawing.Size(101, 22);
            this.numericUpDown18.TabIndex = 1;
            this.numericUpDown18.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.label29);
            this.groupBox6.Controls.Add(this.numericUpDown22);
            this.groupBox6.Controls.Add(this.label28);
            this.groupBox6.Controls.Add(this.numericUpDown19);
            this.groupBox6.Controls.Add(this.label27);
            this.groupBox6.Controls.Add(this.numericUpDown20);
            this.groupBox6.Controls.Add(this.label26);
            this.groupBox6.Controls.Add(this.numericUpDown21);
            this.groupBox6.Controls.Add(this.label25);
            this.groupBox6.Controls.Add(this.numericUpDown23);
            this.groupBox6.Controls.Add(this.label24);
            this.groupBox6.Controls.Add(this.numericUpDown24);
            this.groupBox6.Location = new System.Drawing.Point(400, 158);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(384, 163);
            this.groupBox6.TabIndex = 8;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "估測器參數";
            // 
            // numericUpDown19
            // 
            this.numericUpDown19.DecimalPlaces = 5;
            this.numericUpDown19.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.numericUpDown19.Location = new System.Drawing.Point(17, 49);
            this.numericUpDown19.Name = "numericUpDown19";
            this.numericUpDown19.Size = new System.Drawing.Size(101, 22);
            this.numericUpDown19.TabIndex = 1;
            this.numericUpDown19.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // numericUpDown20
            // 
            this.numericUpDown20.DecimalPlaces = 5;
            this.numericUpDown20.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.numericUpDown20.Location = new System.Drawing.Point(17, 97);
            this.numericUpDown20.Name = "numericUpDown20";
            this.numericUpDown20.Size = new System.Drawing.Size(101, 22);
            this.numericUpDown20.TabIndex = 1;
            this.numericUpDown20.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // numericUpDown21
            // 
            this.numericUpDown21.DecimalPlaces = 5;
            this.numericUpDown21.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.numericUpDown21.Location = new System.Drawing.Point(138, 97);
            this.numericUpDown21.Name = "numericUpDown21";
            this.numericUpDown21.Size = new System.Drawing.Size(101, 22);
            this.numericUpDown21.TabIndex = 1;
            this.numericUpDown21.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // numericUpDown22
            // 
            this.numericUpDown22.DecimalPlaces = 5;
            this.numericUpDown22.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.numericUpDown22.Location = new System.Drawing.Point(262, 97);
            this.numericUpDown22.Name = "numericUpDown22";
            this.numericUpDown22.Size = new System.Drawing.Size(101, 22);
            this.numericUpDown22.TabIndex = 1;
            this.numericUpDown22.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // numericUpDown23
            // 
            this.numericUpDown23.DecimalPlaces = 5;
            this.numericUpDown23.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.numericUpDown23.Location = new System.Drawing.Point(139, 49);
            this.numericUpDown23.Name = "numericUpDown23";
            this.numericUpDown23.Size = new System.Drawing.Size(101, 22);
            this.numericUpDown23.TabIndex = 1;
            this.numericUpDown23.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // numericUpDown24
            // 
            this.numericUpDown24.DecimalPlaces = 5;
            this.numericUpDown24.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.numericUpDown24.Location = new System.Drawing.Point(262, 49);
            this.numericUpDown24.Name = "numericUpDown24";
            this.numericUpDown24.Size = new System.Drawing.Size(101, 22);
            this.numericUpDown24.TabIndex = 1;
            this.numericUpDown24.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(15, 34);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(40, 12);
            this.label24.TabIndex = 0;
            this.label24.Text = "Kslide1";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(15, 82);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(40, 12);
            this.label25.TabIndex = 0;
            this.label25.Text = "Kslide2";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(137, 82);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(33, 12);
            this.label26.TabIndex = 0;
            this.label26.Text = "Kslif2";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(260, 82);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(30, 12);
            this.label27.TabIndex = 0;
            this.label27.Text = "E0_2";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(137, 34);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(33, 12);
            this.label28.TabIndex = 0;
            this.label28.Text = "Kslif1";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(260, 34);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(30, 12);
            this.label29.TabIndex = 0;
            this.label29.Text = "E0_1";
            // 
            // ConfigParaForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(829, 586);
            this.Controls.Add(this.tabControl1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "ConfigParaForm";
            this.Text = "ConfigParaForm";
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown3)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.num_PolePair)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_Lq)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_Ld)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_Rs)).EndInit();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown18)).EndInit();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown20)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown21)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown22)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown23)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown24)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button UpdateParam_button;
        private System.Windows.Forms.NumericUpDown numericUpDown2;
        private System.Windows.Forms.NumericUpDown num_Lq;
        private System.Windows.Forms.NumericUpDown num_Ld;
        private System.Windows.Forms.NumericUpDown num_Rs;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.NumericUpDown numericUpDown5;
        private System.Windows.Forms.NumericUpDown numericUpDown7;
        private System.Windows.Forms.NumericUpDown numericUpDown8;
        private System.Windows.Forms.NumericUpDown numericUpDown6;
        private System.Windows.Forms.NumericUpDown numericUpDown3;
        private System.Windows.Forms.NumericUpDown num_PolePair;
        private System.Windows.Forms.NumericUpDown numericUpDown14;
        private System.Windows.Forms.NumericUpDown numericUpDown13;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.NumericUpDown numericUpDown12;
        private System.Windows.Forms.NumericUpDown numericUpDown11;
        private System.Windows.Forms.NumericUpDown numericUpDown10;
        private System.Windows.Forms.NumericUpDown numericUpDown9;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.NumericUpDown numericUpDown22;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.NumericUpDown numericUpDown19;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.NumericUpDown numericUpDown20;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.NumericUpDown numericUpDown21;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.NumericUpDown numericUpDown23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.NumericUpDown numericUpDown24;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.NumericUpDown numericUpDown15;
        private System.Windows.Forms.NumericUpDown numericUpDown4;
        private System.Windows.Forms.NumericUpDown numericUpDown18;
        private System.Windows.Forms.NumericUpDown numericUpDown17;
        private System.Windows.Forms.NumericUpDown numericUpDown16;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
    }
}
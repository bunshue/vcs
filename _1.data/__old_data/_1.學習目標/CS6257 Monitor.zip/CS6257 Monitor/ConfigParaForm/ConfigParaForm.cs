﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CS6257_Monitor
{
    public partial class ConfigParaForm : Form
    {
        CS6257ParaUI cs6257paraUI;

        public ConfigParaForm(CS6257ParaUI cs6257paraUI_ref)
        {
            InitializeComponent();
            cs6257paraUI = cs6257paraUI_ref;
            Init_Form();
        }

        /// <summary>
        /// 
        /// </summary>
        public void Init_Form()
        {
            double temp = 0;
            // Rs
            temp = cs6257paraUI.GetListViewParam("Rs");
            this.num_Rs.Value = (decimal)(temp / 16777216.0);
            // Ld
            temp = cs6257paraUI.GetListViewParam("Ld");
            this.num_Ld.Value = (decimal)(temp / 16777216.0);
            // Lq
            temp = cs6257paraUI.GetListViewParam("Lq");
            this.num_Lq.Value = (decimal)(temp / 16777216.0);
            // PolePair
            temp = cs6257paraUI.GetListViewParam("PolePair");
            this.num_PolePair.Value = (decimal)temp;
        }

        /// <summary>
        /// 更新按鈕
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void UpdateParam_button_Click(object sender, EventArgs e)
        {
            double temp = 0;
            // Rs
            temp = (double)this.num_Rs.Value;
            temp = Math.Round(temp * 16777216);
            //cs6257paraUI.SetListViewParam("Rs", (int)temp);
        }
    }
}

﻿namespace CS6257_Monitor.GraphFrm
{
    partial class ConfigDialog
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Gra1_checkBox = new System.Windows.Forms.CheckBox();
            this.Gra2_checkBox = new System.Windows.Forms.CheckBox();
            this.Gra3_checkBox = new System.Windows.Forms.CheckBox();
            this.Close_button = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Gra1_checkBox
            // 
            this.Gra1_checkBox.AutoSize = true;
            this.Gra1_checkBox.Location = new System.Drawing.Point(26, 21);
            this.Gra1_checkBox.Name = "Gra1_checkBox";
            this.Gra1_checkBox.Size = new System.Drawing.Size(62, 16);
            this.Gra1_checkBox.TabIndex = 1;
            this.Gra1_checkBox.Text = "Graph 1";
            this.Gra1_checkBox.UseVisualStyleBackColor = true;
            this.Gra1_checkBox.CheckedChanged += new System.EventHandler(this.Gra1_checkBox_CheckedChanged);
            // 
            // Gra2_checkBox
            // 
            this.Gra2_checkBox.AutoSize = true;
            this.Gra2_checkBox.Location = new System.Drawing.Point(26, 54);
            this.Gra2_checkBox.Name = "Gra2_checkBox";
            this.Gra2_checkBox.Size = new System.Drawing.Size(62, 16);
            this.Gra2_checkBox.TabIndex = 1;
            this.Gra2_checkBox.Text = "Graph 2";
            this.Gra2_checkBox.UseVisualStyleBackColor = true;
            this.Gra2_checkBox.CheckedChanged += new System.EventHandler(this.Gra2_checkBox_CheckedChanged);
            // 
            // Gra3_checkBox
            // 
            this.Gra3_checkBox.AutoSize = true;
            this.Gra3_checkBox.Location = new System.Drawing.Point(26, 87);
            this.Gra3_checkBox.Name = "Gra3_checkBox";
            this.Gra3_checkBox.Size = new System.Drawing.Size(62, 16);
            this.Gra3_checkBox.TabIndex = 1;
            this.Gra3_checkBox.Text = "Graph 3";
            this.Gra3_checkBox.UseVisualStyleBackColor = true;
            this.Gra3_checkBox.CheckedChanged += new System.EventHandler(this.Gra3_checkBox_CheckedChanged);
            // 
            // Close_button
            // 
            this.Close_button.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.Close_button.Location = new System.Drawing.Point(69, 119);
            this.Close_button.Name = "Close_button";
            this.Close_button.Size = new System.Drawing.Size(75, 23);
            this.Close_button.TabIndex = 2;
            this.Close_button.Text = "OK";
            this.Close_button.UseVisualStyleBackColor = true;
            this.Close_button.Click += new System.EventHandler(this.Close_button_Click);
            // 
            // ConfigDialog
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(156, 154);
            this.Controls.Add(this.Close_button);
            this.Controls.Add(this.Gra3_checkBox);
            this.Controls.Add(this.Gra2_checkBox);
            this.Controls.Add(this.Gra1_checkBox);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "ConfigDialog";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.Text = "Graph Properties ";
            this.TopMost = true;
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.CheckBox Gra1_checkBox;
        private System.Windows.Forms.CheckBox Gra2_checkBox;
        private System.Windows.Forms.CheckBox Gra3_checkBox;
        private System.Windows.Forms.Button Close_button;

    }
}
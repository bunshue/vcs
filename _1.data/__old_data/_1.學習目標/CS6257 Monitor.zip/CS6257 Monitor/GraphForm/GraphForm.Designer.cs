﻿namespace CS6257_Monitor
{
    partial class GraphForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.chart1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.menuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.Close_toolStripButton = new System.Windows.Forms.ToolStripButton();
            this.Options_toolStripButton = new System.Windows.Forms.ToolStripButton();
            this.Clear_toolStripButton = new System.Windows.Forms.ToolStripButton();
            this.plotControl1 = new CS6257_Monitor.Osc.PlotControl();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).BeginInit();
            this.contextMenuStrip1.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // chart1
            // 
            this.chart1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.chart1.ContextMenuStrip = this.contextMenuStrip1;
            this.chart1.Location = new System.Drawing.Point(0, 28);
            this.chart1.Name = "chart1";
            this.chart1.Size = new System.Drawing.Size(1176, 539);
            this.chart1.TabIndex = 0;
            this.chart1.Text = "chart1";
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(120, 26);
            // 
            // menuToolStripMenuItem
            // 
            this.menuToolStripMenuItem.Name = "menuToolStripMenuItem";
            this.menuToolStripMenuItem.Size = new System.Drawing.Size(119, 22);
            this.menuToolStripMenuItem.Text = "Options";
            this.menuToolStripMenuItem.Click += new System.EventHandler(this.menuToolStripMenuItem_Click);
            // 
            // timer1
            // 
            this.timer1.Interval = 200;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Close_toolStripButton,
            this.Options_toolStripButton,
            this.Clear_toolStripButton});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(1176, 25);
            this.toolStrip1.TabIndex = 2;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // Close_toolStripButton
            // 
            this.Close_toolStripButton.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.Close_toolStripButton.Image = global::CS6257_Monitor.Resource1.close_box_red;
            this.Close_toolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.Close_toolStripButton.Name = "Close_toolStripButton";
            this.Close_toolStripButton.Size = new System.Drawing.Size(58, 22);
            this.Close_toolStripButton.Text = "Close";
            this.Close_toolStripButton.Click += new System.EventHandler(this.Close_toolStripButton_Click);
            // 
            // Options_toolStripButton
            // 
            this.Options_toolStripButton.Image = global::CS6257_Monitor.Resource1.settings;
            this.Options_toolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.Options_toolStripButton.Name = "Options_toolStripButton";
            this.Options_toolStripButton.Size = new System.Drawing.Size(72, 22);
            this.Options_toolStripButton.Text = "Options";
            this.Options_toolStripButton.Click += new System.EventHandler(this.Options_toolStripButton_Click);
            // 
            // Clear_toolStripButton
            // 
            this.Clear_toolStripButton.Image = global::CS6257_Monitor.Resource1.refresh_green;
            this.Clear_toolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.Clear_toolStripButton.Name = "Clear_toolStripButton";
            this.Clear_toolStripButton.Size = new System.Drawing.Size(56, 22);
            this.Clear_toolStripButton.Text = "Clear";
            this.Clear_toolStripButton.Click += new System.EventHandler(this.Clear_toolStripButton_Click);
            // 
            // plotControl1
            // 
            this.plotControl1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.plotControl1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.plotControl1.Location = new System.Drawing.Point(0, 573);
            this.plotControl1.Name = "plotControl1";
            this.plotControl1.Size = new System.Drawing.Size(1176, 91);
            this.plotControl1.TabIndex = 3;
            // 
            // GraphForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1176, 664);
            this.ControlBox = false;
            this.Controls.Add(this.plotControl1);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.chart1);
            this.Name = "GraphForm";
            this.Text = "GraphForm";
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).EndInit();
            this.contextMenuStrip1.ResumeLayout(false);
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataVisualization.Charting.Chart chart1;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem menuToolStripMenuItem;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton Close_toolStripButton;
        private System.Windows.Forms.ToolStripButton Clear_toolStripButton;
        private System.Windows.Forms.ToolStripButton Options_toolStripButton;
        private Osc.PlotControl plotControl1;
    }
}
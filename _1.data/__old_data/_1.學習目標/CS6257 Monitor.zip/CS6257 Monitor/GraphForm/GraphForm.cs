﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using System.IO;

using CS6257_Monitor.GraphFrm;

namespace CS6257_Monitor
{
    public partial class GraphForm : Form
    {
        private Osc.Oscilloscope Oscop;

        private TransControl trans;
        private ConfigDialog configdialog;

        /// <summary>
        /// 
        /// </summary>
        public GraphForm(TransControl trans_ref)
        {
            InitializeComponent();
            // Get refrence
            trans = trans_ref;
            Oscop = new Osc.Oscilloscope(this.chart1, trans);
            this.plotControl1.Init(Oscop);
            this.timer1.Enabled = true;
        }


        /// <summary>
        /// Timer
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void timer1_Tick(object sender, EventArgs e)
        {
            this.chart1.Series.SuspendUpdates();

            Oscop.UpdateChart();

            this.chart1.Series.ResumeUpdates();

        }

        /// <summary>
        /// 選單視窗
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void menuToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Call_OptionsDialog();
        }

        /// <summary>
        /// 選單視窗按鈕
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Options_toolStripButton_Click(object sender, EventArgs e)
        {
            //Call_OptionsDialog();
        }

        /// <summary>
        /// 隱藏視窗
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Close_toolStripButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            //this.Close();
        }

        /// <summary>
        /// 清除資料按鈕
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Clear_toolStripButton_Click(object sender, EventArgs e)
        {
            trans.ClearRecvRecordDispBuf();
        }

        /// <summary>
        /// 呼叫選單視窗
        /// </summary>
        public void Call_OptionsDialog()
        {
            if (configdialog == null)
            {
                configdialog = new ConfigDialog(this);
            }
            if (configdialog.IsDisposed == true)
            {
                configdialog = new ConfigDialog(this);
            }

            configdialog.Show();
        }

    }

}

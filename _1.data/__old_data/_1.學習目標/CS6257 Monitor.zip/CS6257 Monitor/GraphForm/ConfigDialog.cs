﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CS6257_Monitor.GraphFrm
{
    public partial class ConfigDialog : Form
    {
        GraphForm graphform;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="graphform_ref"></param>
        public ConfigDialog(GraphForm graphform_ref)
        {
            InitializeComponent();
            graphform = graphform_ref;

            //bool visible1 = graphform.Properties.Graph1Visible;
            //bool visible2 = graphform.Properties.Graph2Visible;
            //bool visible3 = graphform.Properties.Graph3Visible;

            //this.Gra1_checkBox.Checked = visible1;
            //this.Gra2_checkBox.Checked = visible2;
            //this.Gra3_checkBox.Checked = visible3;
        }

        private void Gra1_checkBox_CheckedChanged(object sender, EventArgs e)
        {
            //graphform.Properties.Graph1Visible = this.Gra1_checkBox.Checked;
            //graphform.RefreshAreas();
        }

        private void Gra2_checkBox_CheckedChanged(object sender, EventArgs e)
        {
            //graphform.Properties.Graph2Visible = this.Gra2_checkBox.Checked;
           // graphform.RefreshAreas();
        }

        private void Gra3_checkBox_CheckedChanged(object sender, EventArgs e)
        {
           // graphform.Properties.Graph3Visible = this.Gra3_checkBox.Checked;
           // graphform.RefreshAreas();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Close_button_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;
using System.Threading;
using System.Drawing;

using CS6257_Monitor.Osc;

namespace CS6257_Monitor.Osc
{
    public enum MODE { NORMAL, ROLL}
    public enum DIVX { DIVX10, DIVX5, DIVX4, DIVX2, DIVX1, DIVX05, DIVX02, DIVX01 };
    public enum DIVY { DIVY50, DIVY20, DIVY10, DIVY5, DIVY2, DIVY1, DIVY05, DIVY02, DIVY01 };
    public enum DATATYPE { DEFAULT, CURRENT, HZ, RPS, DEG }

    public class PROPERTIES
    {
        public bool[] GraphVisible;

        public MODE mode;

        // X - Axis
        public DIVX divX;
        public int xZero;
        public int xWidth;
        public int xInterval;
        public int xMax;

        // Y - Axis
        public DATATYPE[] dataType;
        public DIVY[] divY;
        public bool[] NegAxis;
        public double[] yMax;
        public double[] yMin;
        public double[] yInterval;

        public PROPERTIES(int n)
        {
            GraphVisible = new bool[n];
            dataType = new DATATYPE[n];
            divY = new DIVY[n];
            NegAxis = new bool[n];
            yMax = new double[n];
            yMin = new double[n];
            yInterval = new double[n];
        }
    }

    /// <summary>
    /// 
    /// </summary>
    public struct RECVData
    {
        public int index;
        public int data1;
        public int data2;
        public int data3;
    }

    public class Oscilloscope
    {
        public PROPERTIES Properties = new PROPERTIES(3);
        private TransControl trans;
        private Chart chart;
        private Thread thread;

        private RECVData[] rData;
        private RECVData[] rDataRT;
        private RECVData rDTemp = new RECVData();

        private List<DataSource> datasrc = new List<DataSource>();
        private List<DataSource> datasrcRT = new List<DataSource>();

        private string[] AreasName = { "Areas1", "Areas2", "Areas3" };
        private string[] SeriesName = { "Series1", "Series2", "Series3" };

        /// <summary>
        /// 
        /// </summary>
        /// <param name="chart_ref"></param>
        public Oscilloscope(Chart chart_ref, TransControl trans_ref)
        {
            chart = chart_ref;
            trans = trans_ref;
            //
            //
            Properties.divX = DIVX.DIVX10;
            Properties.xZero = 0;
            Properties.xMax = 10000;
            //
            Init_Chart();
            Init_Data();
            Init_RealTimeData();
            //
            thread = new Thread(new ThreadStart(OscDoWork));
            thread.Name = "OscDoWork Thread";
            thread.IsBackground = true;
            thread.Start();
        }

        /// <summary>
        /// 初始化設定
        /// </summary>
        public void Init_Chart()
        {
            Properties.GraphVisible[0] = true;
            Properties.GraphVisible[1] = true;
            Properties.GraphVisible[2] = true;

            // AreasName 0
            this.chart.ChartAreas.Add(AreasName[0]);
            this.chart.ChartAreas[AreasName[0]].AxisX.Title = " ";  // Time
            this.chart.ChartAreas[AreasName[0]].AxisY.Title = "Channel 1";
            this.chart.ChartAreas[AreasName[0]].Visible = Properties.GraphVisible[0];
            //
            // Grid
            this.chart.ChartAreas[AreasName[0]].AxisX.MajorGrid.LineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.Dash;
            this.chart.ChartAreas[AreasName[0]].AxisY.MajorGrid.LineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.Dash;
            //
            this.chart.ChartAreas[AreasName[0]].AxisX.Minimum = 0;
            this.chart.ChartAreas[AreasName[0]].AxisX.Maximum = 10000;
            this.chart.ChartAreas[AreasName[0]].AxisX.MajorGrid.Interval = 1000;
            this.chart.ChartAreas[AreasName[0]].AxisX.LabelStyle.Enabled = false;
            this.chart.ChartAreas[AreasName[0]].AxisY.Minimum = -35000;
            this.chart.ChartAreas[AreasName[0]].AxisY.Maximum = 35000;
            this.chart.ChartAreas[AreasName[0]].AxisY.MajorGrid.Interval = 5000;
            this.chart.ChartAreas[AreasName[0]].AxisY.LabelStyle.Enabled = true;
            //
            //
            this.chart.Series.Add(SeriesName[0]);
            this.chart.Series[SeriesName[0]].ChartArea = AreasName[0];
            this.chart.Series[SeriesName[0]].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            this.chart.Series[SeriesName[0]].XAxisType = System.Windows.Forms.DataVisualization.Charting.AxisType.Primary;
            this.chart.Series[SeriesName[0]].YAxisType = System.Windows.Forms.DataVisualization.Charting.AxisType.Primary;
            this.chart.Series[SeriesName[0]].Color = Color.Orange;
            this.chart.Series[SeriesName[0]].BorderWidth = 1;

            // AreasName 1
            this.chart.ChartAreas.Add(AreasName[1]);
            this.chart.Series.Add(SeriesName[1]);
            this.chart.ChartAreas[AreasName[1]].AxisX.Title = " ";  // Time
            this.chart.ChartAreas[AreasName[1]].AxisY.Title = "Channel 2";
            this.chart.ChartAreas[AreasName[1]].Visible = Properties.GraphVisible[1];
            //
            // Grid
            this.chart.ChartAreas[AreasName[1]].AxisX.MajorGrid.LineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.Dash;
            this.chart.ChartAreas[AreasName[1]].AxisY.MajorGrid.LineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.Dash;
            //
            this.chart.ChartAreas[AreasName[1]].AxisX.Minimum = 0;
            this.chart.ChartAreas[AreasName[1]].AxisX.Maximum = 10000;
            this.chart.ChartAreas[AreasName[1]].AxisX.MajorGrid.Interval = 1000;
            this.chart.ChartAreas[AreasName[1]].AxisX.LabelStyle.Enabled = false;
            this.chart.ChartAreas[AreasName[1]].AxisY.Minimum = -35000;
            this.chart.ChartAreas[AreasName[1]].AxisY.Maximum = 35000;
            this.chart.ChartAreas[AreasName[1]].AxisY.MajorGrid.Interval = 5000;
            this.chart.ChartAreas[AreasName[1]].AxisY.LabelStyle.Enabled = true;
            //
            this.chart.Series[SeriesName[1]].ChartArea = AreasName[1];
            this.chart.Series[SeriesName[1]].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            this.chart.Series[SeriesName[1]].XAxisType = System.Windows.Forms.DataVisualization.Charting.AxisType.Primary;
            this.chart.Series[SeriesName[1]].YAxisType = System.Windows.Forms.DataVisualization.Charting.AxisType.Primary;
            this.chart.Series[SeriesName[1]].Color = Color.Blue;
            this.chart.Series[SeriesName[1]].BorderWidth = 1;

            // AreasName 2
            this.chart.ChartAreas.Add(AreasName[2]);
            this.chart.Series.Add(SeriesName[2]);
            this.chart.ChartAreas[AreasName[2]].AxisX.Title = " ";  // Time
            this.chart.ChartAreas[AreasName[2]].AxisY.Title = "Channel 3";
            this.chart.ChartAreas[AreasName[2]].Visible = Properties.GraphVisible[2];
            //
            // Grid
            this.chart.ChartAreas[AreasName[2]].AxisX.MajorGrid.LineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.Dash;
            this.chart.ChartAreas[AreasName[2]].AxisY.MajorGrid.LineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.Dash;
            //
            this.chart.ChartAreas[AreasName[2]].AxisX.Minimum = 0;
            this.chart.ChartAreas[AreasName[2]].AxisX.Maximum = 10000;
            this.chart.ChartAreas[AreasName[2]].AxisX.MajorGrid.Interval = 1000;
            this.chart.ChartAreas[AreasName[2]].AxisX.LabelStyle.Enabled = false;
            this.chart.ChartAreas[AreasName[2]].AxisY.Minimum = -35000;
            this.chart.ChartAreas[AreasName[2]].AxisY.Maximum = 35000;
            this.chart.ChartAreas[AreasName[2]].AxisY.MajorGrid.Interval = 5000;
            this.chart.ChartAreas[AreasName[2]].AxisY.LabelStyle.Enabled = true;
            //
            this.chart.Series[SeriesName[2]].ChartArea = AreasName[2];
            this.chart.Series[SeriesName[2]].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            this.chart.Series[SeriesName[2]].XAxisType = System.Windows.Forms.DataVisualization.Charting.AxisType.Primary;
            this.chart.Series[SeriesName[2]].YAxisType = System.Windows.Forms.DataVisualization.Charting.AxisType.Primary;
            this.chart.Series[SeriesName[2]].Color = Color.Red;
            this.chart.Series[SeriesName[2]].BorderWidth = 1;

            //
            for (int ii = 0; ii < 1000; ii++)
            {
                chart.Series[SeriesName[0]].Points.AddXY(ii, 0);
                chart.Series[SeriesName[1]].Points.AddXY(ii, 0);
                chart.Series[SeriesName[2]].Points.AddXY(ii, 0);
            } 
        }

        /// <summary>
        /// 
        /// </summary>
        private void Init_Data()
        {
            int length = trans.DataBuf.RecordDisp_Buf.Length;
            rData = new RECVData[length];

            for (int ii = 0; ii < 3; ii++)
            {
                datasrc.Add(new DataSource(ref rData));
            }

            datasrc[0].config.Channel = 1;
            datasrc[1].config.Channel = 2;
            datasrc[2].config.Channel = 3;

            datasrc[0].config.divX = Properties.divX;
            datasrc[1].config.divX = Properties.divX;
            datasrc[2].config.divX = Properties.divX;

        }

        /// <summary>
        /// 
        /// </summary>
        private void Init_RealTimeData()
        {
            rDataRT = new RECVData[10000];   // length set 10000

            for (int ii = 0; ii < 2; ii++)
            {
                datasrcRT.Add(new DataSource(ref rDataRT));
                datasrcRT[ii].config.Channel = ii + 1;
                datasrcRT[ii].config.divX = Properties.divX;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        public void SetXAxis()
        {
            int RollxZero = 0;
            Properties.xInterval = 0;
            switch(Properties.divX)
            {
                case DIVX.DIVX10:
                    Properties.xWidth = 10000;
                    Properties.xInterval = 1000;
                    Properties.xZero = 0;
                    RollxZero = 0;
                    break;
                case DIVX.DIVX5:
                    Properties.xWidth = 5000;
                    Properties.xInterval = 500;
                    RollxZero = 5000;
                    break;
                case DIVX.DIVX4:
                    Properties.xWidth = 4000;
                    Properties.xInterval = 400;
                    RollxZero = 6000;
                    break;
                case DIVX.DIVX2:
                    Properties.xWidth = 2000;
                    Properties.xInterval = 200;
                    RollxZero = 8000;
                    break;
                case DIVX.DIVX1:
                    Properties.xWidth = 1000;
                    Properties.xInterval = 100;
                    RollxZero = 9000;
                    break;
                case DIVX.DIVX05:
                    Properties.xWidth = 500;
                    Properties.xInterval = 50;
                    RollxZero = 9500;
                    break;
                case DIVX.DIVX02:
                    Properties.xWidth = 200;
                    Properties.xInterval = 20;
                    RollxZero = 9800;
                    break;
                case DIVX.DIVX01:
                    Properties.xWidth = 100;
                    Properties.xInterval = 10;
                    RollxZero = 9900;
                    break;
                default:
                    Properties.xWidth = 1000;
                    Properties.xInterval = 100;
                    RollxZero = 9000;
                    break;
            }

            if (Properties.mode == MODE.ROLL)
            {
                Properties.xZero = RollxZero;
            }

            int xMin = Properties.xZero;
            int xMax = xMin + Properties.xWidth;

            if (xMax > rData.Length)
            {
                xMin = rData.Length - Properties.xWidth;
                Properties.xZero = xMin;
            }

            //
            //for (int ii = 0; ii < datasrc.Count; ii++)
            //{
            //    datasrc[ii].config.divX = Properties.divX;
            //    datasrc[ii].config.XZero = Properties.xZero;
            //}

            for(int ii = 0; ii < chart.ChartAreas.Count ; ii++)
            {
                chart.ChartAreas[AreasName[ii]].AxisX.Minimum = xMin;
                chart.ChartAreas[AreasName[ii]].AxisX.Maximum = xMax;

                chart.ChartAreas[AreasName[ii]].AxisX.MajorGrid.Interval = Properties.xInterval;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        public void SetYAxis()
        {
            for (int ii = 0; ii < Properties.divY.Length; ii++)
            {
                switch (Properties.divY[ii])
                {
                    case DIVY.DIVY50:
                        Properties.yMax[ii] = 50 * 5;
                        Properties.yInterval[ii] = 50;
                        break;
                    case DIVY.DIVY20:
                        Properties.yMax[ii] = 20 * 5;
                        Properties.yInterval[ii] = 20;
                        break;
                    case DIVY.DIVY10:
                        Properties.yMax[ii] = 10 * 5;
                        Properties.yInterval[ii] = 10;
                        break;
                    case DIVY.DIVY5:
                        Properties.yMax[ii] = 5 * 5;
                        Properties.yInterval[ii] = 5;
                        break;
                    case DIVY.DIVY2:
                        Properties.yMax[ii] = 2 * 5;
                        Properties.yInterval[ii] = 2;
                        break;
                    case DIVY.DIVY1:
                        Properties.yMax[ii] = 1 * 5;
                        Properties.yInterval[ii] = 1;
                        break;
                    case DIVY.DIVY05:
                        Properties.yMax[ii] = 0.5 * 5;
                        Properties.yInterval[ii] = 0.5;
                        break;
                    case DIVY.DIVY02:
                        Properties.yMax[ii] = 0.2 * 5;
                        Properties.yInterval[ii] = 0.2;
                        break;
                    case DIVY.DIVY01:
                        Properties.yMax[ii] = 0.1 * 5;
                        Properties.yInterval[ii] = 0.1;
                        break;
                }

                if (Properties.NegAxis[ii])
                {
                    Properties.yMin[ii] = -Properties.yMax[ii];
                    //Properties.yInterval[ii] *= 2;
                }
                else
                {
                    Properties.yMin[ii] = 0;
                }
            }

            for (int ii = 0; ii < chart.ChartAreas.Count; ii++)
            {
                chart.ChartAreas[AreasName[ii]].AxisY.Minimum = Properties.yMin[ii];
                chart.ChartAreas[AreasName[ii]].AxisY.Maximum = Properties.yMax[ii];
                chart.ChartAreas[AreasName[ii]].AxisY.MajorGrid.Interval = Properties.yInterval[ii];
            }
        }


        /// <summary>
        /// 
        /// </summary>
        public void UpdateChart()
        {
            double x = 0;
            double y = 0;

            //
            SetXAxis();
            SetYAxis();

            if (Properties.mode == MODE.NORMAL)
            {
                for (int ii = 0; ii < datasrc.Count; ii++)
                {
                    datasrc[ii].config.divX = Properties.divX;
                    datasrc[ii].config.xZero = Properties.xZero;
                    datasrc[ii].config.dataType = Properties.dataType[ii];

                    for (int jj = 0; jj < datasrc[ii].points.Length; jj++)
                    {
                        x = datasrc[ii].points[jj].x;
                        y = datasrc[ii].points[jj].y;
                        chart.Series[SeriesName[ii]].Points[jj].SetValueXY(x, y);
                    }
                }
            }
            else if (Properties.mode == MODE.ROLL)
            {
                for (int ii = 0; ii < datasrcRT.Count; ii++)
                {
                    datasrcRT[ii].config.divX = Properties.divX;
                    datasrcRT[ii].config.xZero = Properties.xZero;
                    datasrcRT[ii].config.dataType = Properties.dataType[ii];

                    for (int jj = 0; jj < datasrcRT[ii].points.Length; jj++)
                    {
                        x = datasrcRT[ii].points[jj].x;
                        y = datasrcRT[ii].points[jj].y;
                        chart.Series[SeriesName[ii]].Points[jj].SetValueXY(x, y);
                    }
                }
            }

            
        }

        /// <summary>
        /// 
        /// </summary>
        private void OscDoWork()
        {
            while(true)
            {
                if (Properties.mode == MODE.NORMAL)
                {
                    GetDataFromBuf();
                    for (int ii = 0; ii < datasrc.Count; ii++)
                    {
                        datasrc[ii].UpdatePoints();
                    }   
                }
                else if (Properties.mode == MODE.ROLL)
                {
                    GetRealTimeDataFromBuf();
                    for (int ii = 0; ii < datasrcRT.Count; ii++)
                    {
                        datasrcRT[ii].UpdatePoints();
                    }
                }
         
                Thread.Sleep(10);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        private void GetDataFromBuf()
        {
            int length = rData.Length;
            trans.CopyRecordDispBuf();
            int packlen = length / 10;

            int pCnt = 0;
            int s = 0;

            for (int ii = 0; ii < length; ii++)
            {
                switch (s)
                {
                    case 0:
                        break;
                    case 1:
                        rData[pCnt].index = Convert.ToInt32(trans.DataBuf.RecordDisp_Buf[ii] * 256);
                        break;
                    case 2:
                        rData[pCnt].index += Convert.ToInt32(trans.DataBuf.RecordDisp_Buf[ii]);
                        break;
                    case 3:
                        rData[pCnt].data1 = Convert.ToInt32(trans.DataBuf.RecordDisp_Buf[ii] * 256);
                        break;
                    case 4:
                        rData[pCnt].data1 += Convert.ToInt32(trans.DataBuf.RecordDisp_Buf[ii]);
                        break;
                    case 5:
                        rData[pCnt].data2 = Convert.ToInt32(trans.DataBuf.RecordDisp_Buf[ii] * 256);
                        break;
                    case 6:
                        rData[pCnt].data2 += Convert.ToInt32(trans.DataBuf.RecordDisp_Buf[ii]);
                        break;
                    case 7:
                        rData[pCnt].data3 = Convert.ToInt32(trans.DataBuf.RecordDisp_Buf[ii] * 256);
                        break;
                    case 8:
                        rData[pCnt].data3 += Convert.ToInt32(trans.DataBuf.RecordDisp_Buf[ii]);
                        break;
                    case 9:
                        // Checksum
                        break;
                }

                if (++s >= 10)
                {
                    s = 0;
                    pCnt++;
                    
                }
            }
        }

        /// <summary>
        /// 
        /// </summary>
        private void GetRealTimeDataFromBuf()
        {
            byte[] b = trans.ReadRealTimeDispBuf();
            if (b == null) return;
            if (b.Length >= 6)
            {
                int length = rDataRT.Length;
                int cnt = 0;
                
                for (int ii = 0; ii < b.Length; ii++)
                {
                    switch(cnt)
                    {
                        case 0:
                            break;
                        case 1:
                            rDTemp.data1 = Convert.ToInt32(b[ii]) * 256;
                            break;
                        case 2:
                            rDTemp.data1 += Convert.ToInt32(b[ii]);
                            break;
                        case 3:
                            rDTemp.data2 = Convert.ToInt32(b[ii]) * 256;
                            break;
                        case 4:
                            rDTemp.data2 += Convert.ToInt32(b[ii]);
                            break;
                        case 5:
                            break;
                    }
                    if (++cnt > 5)
                    {
                        cnt = 0;
                        for (int jj = 0; jj < rDataRT.Length - 1; jj++)
                        {
                            rDataRT[jj] = rDataRT[jj + 1];
                        }
                        rDataRT[length - 1] = rDTemp;
                    }
                }    
            

            }
        }

        /// <summary>
        /// 
        /// </summary>
        public void MoveLeft()
        {
            int step = GetMoveStep();

            if (Properties.xZero - step >= 0)
            {
                Properties.xZero -= step;
            }
            else
            {
                Properties.xZero = 0;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        public void MoveRight()
        {
            int step = GetMoveStep();

            if (Properties.xZero + step < Properties.xMax - Properties.xWidth)
            {
                Properties.xZero += step;
            }
            else
            {
                Properties.xZero = Properties.xMax - Properties.xWidth;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        private int GetMoveStep()
        {
            int step = 0;

            switch(Properties.divX)
            {
                case DIVX.DIVX10:
                    step = 1000;
                    break;
                case DIVX.DIVX5:
                    step = 500;
                    break;
                case DIVX.DIVX4:
                    step = 500;
                    break;
                case DIVX.DIVX2:
                    step = 200;
                    break;
                case DIVX.DIVX1:
                    step = 100;
                    break;
            }

            return step;
        }

        /// <summary>
        /// 
        /// </summary>
        public void ResetAreasVisible()
        {
            for (int ii = 0; ii < chart.ChartAreas.Count; ii++)
            {
                chart.ChartAreas[ii].Visible = Properties.GraphVisible[ii];
            }
        }
    }


    /// <summary>
    /// 
    /// </summary>
    public struct cPoint
    {
        public double x;
        public double y;
    }

    /// <summary>
    /// 
    /// </summary>
    public class DataSource
    {
        // 
        public struct CONFIG
        {
            public DIVX divX;
            public DATATYPE dataType;
            public int xZero;
            public int XSample;
            public int Channel;
        }

        private RECVData[] rData;
        public CONFIG config;

        public cPoint[] points = new cPoint[1000];
      
        /// <summary>
        /// 
        /// </summary>
        /// <param name="trans_ref"></param>
        public DataSource(ref RECVData[] rData_ref)
        {
            rData = rData_ref;
        }

        /// <summary>
        /// 
        /// </summary>
        public void UpdatePoints()
        {
            int sample = config.XSample;
            int Zero = config.xZero;
            int cur = 0;

            switch(config.divX)
            {
                case DIVX.DIVX10:
                    config.xZero = 0;
                    config.XSample = 10;
                    break;
                case DIVX.DIVX4:
                    config.XSample = 4;
                    break;
                case DIVX.DIVX2:
                    config.XSample = 2;
                    break;
                case DIVX.DIVX1:
                    config.XSample = 1;
                    break;
                case DIVX.DIVX05:
                    config.XSample = 1;
                    break;
                case DIVX.DIVX02:
                    config.XSample = 1;
                    break;
                case DIVX.DIVX01:
                    config.XSample = 1;
                    break;
            }

            if (config.xZero > (rData.Length - config.XSample * points.Length))
            {
                config.xZero = rData.Length - config.XSample * points.Length;
            }

            for (int ii = 0; ii < points.Length; ii++)
            {
                cur = config.xZero + config.XSample * ii;
                if (cur >= rData.Length)
                    break;
                points[ii].x = cur;//rData[cur].index;
                points[ii].y = GetYValue(rData[cur]);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="rd"></param>
        /// <returns></returns>
        public double GetYValue(RECVData rd)
        {
            double Out = 0;
            double value = 0;

            switch(config.Channel)
            {
                case 1:
                    value = rd.data1;
                    break;
                case 2:
                    value = rd.data2;
                    break;
                case 3:
                    value = rd.data3;
                    break;
                default:
                    value = 0;
                    break;
            }

            switch(config.dataType)
            {
                case DATATYPE.DEFAULT:
                    if (value > 32768) value -= 65536;
                    break;
                case DATATYPE.CURRENT:
                    if (value > 32768) value -= 65536;
                    Out = value / 65536.0 * 20.0;
                    break;
                case DATATYPE.HZ:
                    if (value > 32768) value -= 65536;
                    Out = value / 65536.0 * 400.0;
                    break;
                case DATATYPE.RPS:
                    break;
                case DATATYPE.DEG:
                    Out = value / 65536.0 * 10;
                    break;
            }

            return Out;
        }
    }
}

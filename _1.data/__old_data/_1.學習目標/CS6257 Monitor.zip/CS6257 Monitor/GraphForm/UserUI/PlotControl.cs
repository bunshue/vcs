﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CS6257_Monitor.Osc
{
    public partial class PlotControl : UserControl
    {
        private Oscilloscope Oscop;

        public PlotControl()
        {
            InitializeComponent();
            //
        }

        public void Init(Oscilloscope osc_ref)
        {
            // Get reference
            Oscop = osc_ref;

            string[] item1 = { "1s", "500ms", "400ms", "200ms", "100ms", "50ms", "20ms", "10ms" };
            string[] item2 = { "A", "Hz", "DEG" };

            string[] item3 = { "10", "5", "2", "1" };
            string[] item4 = { "50", "20", "10", "5", "2", "1", "0.5", "0.2", "0.1" };
            string[] item5 = { "ROLL", "NORMAL" };
            
            foreach (string str in item1)
            {
                this.XDiv_comboBox.Items.Add(str);
            }
            this.XDiv_comboBox.SelectedIndex = 0;

            foreach(string str in item2)
            {
                this.C1_Type_comboBox.Items.Add(str);
                this.C2_Type_comboBox.Items.Add(str);
                this.C3_Type_comboBox.Items.Add(str);
            }
            this.C1_Type_comboBox.SelectedIndex = 0;
            this.C2_Type_comboBox.SelectedIndex = 0;
            this.C3_Type_comboBox.SelectedIndex = 0;

            foreach(string str in item4)
            {
                this.C1YDiv_comboBox.Items.Add(str);
                this.C2YDiv_comboBox.Items.Add(str);
                this.C3YDiv_comboBox.Items.Add(str);
            }
            this.C1YDiv_comboBox.SelectedIndex = 0;
            this.C2YDiv_comboBox.SelectedIndex = 0;
            this.C3YDiv_comboBox.SelectedIndex = 0;

            this.Ena1_checkBox.Checked = true;
            this.Ena2_checkBox.Checked = true;
            this.Ena3_checkBox.Checked = true;

            foreach(string str in item5)
            {
                this.Mode_comboBox.Items.Add(str);
            }
            this.Mode_comboBox.SelectedIndex = 0;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void XDiv_comboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch(this.XDiv_comboBox.SelectedIndex)
            {
                case 0:
                    Oscop.Properties.divX = DIVX.DIVX10;
                    break;
                case 1:
                    Oscop.Properties.divX = DIVX.DIVX5;
                    break;
                case 2:
                    Oscop.Properties.divX = DIVX.DIVX4;
                    break;
                case 3:
                    Oscop.Properties.divX = DIVX.DIVX2;
                    break;
                case 4:
                    Oscop.Properties.divX = DIVX.DIVX1;
                    break;
                case 5:
                    Oscop.Properties.divX = DIVX.DIVX05;
                    break;
                case 6:
                    Oscop.Properties.divX = DIVX.DIVX02;
                    break;
                case 7:
                    Oscop.Properties.divX = DIVX.DIVX01;
                    break;
            }
        }

        private void Left_button_Click(object sender, EventArgs e)
        {
            Oscop.MoveLeft();
        }

        private void Right_button_Click(object sender, EventArgs e)
        {
            Oscop.MoveRight();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void C1_Type_comboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            TypeSelect(this.C1_Type_comboBox, 1);
            TypeSelect(this.C2_Type_comboBox, 2);
            TypeSelect(this.C3_Type_comboBox, 3);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void C1YDiv_comboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            DIVYSelect(this.C1YDiv_comboBox, 1);
            DIVYSelect(this.C2YDiv_comboBox, 2);
            DIVYSelect(this.C3YDiv_comboBox, 3);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Neg1_checkBox_CheckedChanged(object sender, EventArgs e)
        {
            EnableNegAxis(this.Neg1_checkBox, 1);
            EnableNegAxis(this.Neg2_checkBox, 2);
            EnableNegAxis(this.Neg3_checkBox, 3);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Ena1_checkBox_CheckedChanged(object sender, EventArgs e)
        {
            Oscop.Properties.GraphVisible[0] = this.Ena1_checkBox.Checked;
            Oscop.Properties.GraphVisible[1] = this.Ena2_checkBox.Checked;
            Oscop.Properties.GraphVisible[2] = this.Ena3_checkBox.Checked;

            Oscop.ResetAreasVisible();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Mode_comboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch(this.Mode_comboBox.SelectedIndex)
            {
                case 0:
                    Oscop.Properties.mode = MODE.ROLL;
                    break;
                case 1:
                    Oscop.Properties.mode = MODE.NORMAL;
                    break;
                default:
                    Oscop.Properties.mode = MODE.NORMAL;
                    break;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="comboBox"></param>
        private void TypeSelect(ComboBox comboBox, int Channel)
        {
            DATATYPE dataType;

            switch(comboBox.SelectedIndex)
            {
                case 0:
                    dataType = DATATYPE.CURRENT;
                    break;
                case 1:
                    dataType = DATATYPE.HZ;
                    break;
                case 2:
                    dataType = DATATYPE.DEG;
                    break;
                default:
                    dataType = DATATYPE.DEFAULT;
                    break;
            }

            switch(Channel)
            {
                case 1:
                    Oscop.Properties.dataType[0] = dataType;
                    break;
                case 2:
                    Oscop.Properties.dataType[1] = dataType;
                    break;
                case 3:
                    Oscop.Properties.dataType[2] = dataType;
                    break;
            }
        }

        private void DIVYSelect(ComboBox comboBox, int Channel)
        {
            DIVY divY;

            switch(comboBox.SelectedIndex)
            {
                case 0:
                    divY = DIVY.DIVY50;
                    break;
                case 1:
                    divY = DIVY.DIVY20;
                    break;
                case 2:
                    divY = DIVY.DIVY10;
                    break;
                case 3:
                    divY = DIVY.DIVY5;
                    break;
                case 4:
                    divY = DIVY.DIVY2;
                    break;
                case 5:
                    divY = DIVY.DIVY1;
                    break;
                case 6:
                    divY = DIVY.DIVY05;
                    break;
                case 7:
                    divY = DIVY.DIVY02;
                    break;
                case 8:
                    divY = DIVY.DIVY01;
                    break;
                default:
                    divY = DIVY.DIVY20;
                    break;
            }

            switch(Channel)
            {
                case 1:
                    Oscop.Properties.divY[0] = divY;
                    break;
                case 2:
                    Oscop.Properties.divY[1] = divY;
                    break;
                case 3:
                    Oscop.Properties.divY[2] = divY;
                    break;
            }
        }

        public void EnableNegAxis(CheckBox checkbox, int channel)
        {
            int ii = 0;
            switch(channel)
            {
                case 1:
                    ii = 0;
                    break;
                case 2:
                    ii = 1;
                    break;
                case 3:
                    ii = 2;
                    break;
            }
            Oscop.Properties.NegAxis[ii] = checkbox.Checked;
        }
    }
}

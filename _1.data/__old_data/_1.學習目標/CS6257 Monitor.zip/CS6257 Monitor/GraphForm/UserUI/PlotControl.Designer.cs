﻿namespace CS6257_Monitor.Osc
{
    partial class PlotControl
    {
        /// <summary> 
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 元件設計工具產生的程式碼

        /// <summary> 
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器
        /// 修改這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.Ena1_checkBox = new System.Windows.Forms.CheckBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.C1YDiv_comboBox = new System.Windows.Forms.ComboBox();
            this.C1_Type_comboBox = new System.Windows.Forms.ComboBox();
            this.Neg1_checkBox = new System.Windows.Forms.CheckBox();
            this.XDiv_comboBox = new System.Windows.Forms.ComboBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.C2YDiv_comboBox = new System.Windows.Forms.ComboBox();
            this.C2_Type_comboBox = new System.Windows.Forms.ComboBox();
            this.Ena2_checkBox = new System.Windows.Forms.CheckBox();
            this.Neg2_checkBox = new System.Windows.Forms.CheckBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.C3YDiv_comboBox = new System.Windows.Forms.ComboBox();
            this.C3_Type_comboBox = new System.Windows.Forms.ComboBox();
            this.Ena3_checkBox = new System.Windows.Forms.CheckBox();
            this.Neg3_checkBox = new System.Windows.Forms.CheckBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.Right_button = new System.Windows.Forms.Button();
            this.Left_button = new System.Windows.Forms.Button();
            this.panel6 = new System.Windows.Forms.Panel();
            this.Mode_comboBox = new System.Windows.Forms.ComboBox();
            this.label13 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel6.SuspendLayout();
            this.SuspendLayout();
            // 
            // Ena1_checkBox
            // 
            this.Ena1_checkBox.AutoSize = true;
            this.Ena1_checkBox.Location = new System.Drawing.Point(10, 38);
            this.Ena1_checkBox.Name = "Ena1_checkBox";
            this.Ena1_checkBox.Size = new System.Drawing.Size(56, 16);
            this.Ena1_checkBox.TabIndex = 0;
            this.Ena1_checkBox.Text = "Enable";
            this.Ena1_checkBox.UseVisualStyleBackColor = true;
            this.Ena1_checkBox.CheckedChanged += new System.EventHandler(this.Ena1_checkBox_CheckedChanged);
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.C1YDiv_comboBox);
            this.panel1.Controls.Add(this.C1_Type_comboBox);
            this.panel1.Controls.Add(this.Ena1_checkBox);
            this.panel1.Controls.Add(this.Neg1_checkBox);
            this.panel1.Location = new System.Drawing.Point(3, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(210, 85);
            this.panel1.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(77, 62);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(37, 12);
            this.label3.TabIndex = 2;
            this.label3.Text = "1 / Div";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(85, 36);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(29, 12);
            this.label2.TabIndex = 2;
            this.label2.Text = "Type";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(8, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 12);
            this.label1.TabIndex = 2;
            this.label1.Text = "Channel 1";
            // 
            // C1YDiv_comboBox
            // 
            this.C1YDiv_comboBox.FormattingEnabled = true;
            this.C1YDiv_comboBox.Location = new System.Drawing.Point(132, 59);
            this.C1YDiv_comboBox.Name = "C1YDiv_comboBox";
            this.C1YDiv_comboBox.Size = new System.Drawing.Size(64, 20);
            this.C1YDiv_comboBox.TabIndex = 1;
            this.C1YDiv_comboBox.SelectedIndexChanged += new System.EventHandler(this.C1YDiv_comboBox_SelectedIndexChanged);
            // 
            // C1_Type_comboBox
            // 
            this.C1_Type_comboBox.FormattingEnabled = true;
            this.C1_Type_comboBox.Location = new System.Drawing.Point(132, 33);
            this.C1_Type_comboBox.Name = "C1_Type_comboBox";
            this.C1_Type_comboBox.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.C1_Type_comboBox.Size = new System.Drawing.Size(64, 20);
            this.C1_Type_comboBox.TabIndex = 1;
            this.C1_Type_comboBox.SelectedIndexChanged += new System.EventHandler(this.C1_Type_comboBox_SelectedIndexChanged);
            // 
            // Neg1_checkBox
            // 
            this.Neg1_checkBox.AutoSize = true;
            this.Neg1_checkBox.Location = new System.Drawing.Point(132, 9);
            this.Neg1_checkBox.Name = "Neg1_checkBox";
            this.Neg1_checkBox.Size = new System.Drawing.Size(43, 16);
            this.Neg1_checkBox.TabIndex = 0;
            this.Neg1_checkBox.Text = "N/A";
            this.Neg1_checkBox.UseVisualStyleBackColor = true;
            this.Neg1_checkBox.CheckedChanged += new System.EventHandler(this.Neg1_checkBox_CheckedChanged);
            // 
            // XDiv_comboBox
            // 
            this.XDiv_comboBox.FormattingEnabled = true;
            this.XDiv_comboBox.Location = new System.Drawing.Point(63, 33);
            this.XDiv_comboBox.Name = "XDiv_comboBox";
            this.XDiv_comboBox.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.XDiv_comboBox.Size = new System.Drawing.Size(64, 20);
            this.XDiv_comboBox.TabIndex = 1;
            this.XDiv_comboBox.SelectedIndexChanged += new System.EventHandler(this.XDiv_comboBox_SelectedIndexChanged);
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.label11);
            this.panel2.Controls.Add(this.XDiv_comboBox);
            this.panel2.Controls.Add(this.label10);
            this.panel2.Location = new System.Drawing.Point(651, 3);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(143, 85);
            this.panel2.TabIndex = 2;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(20, 36);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(37, 12);
            this.label11.TabIndex = 3;
            this.label11.Text = "1 / Div";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(8, 10);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(37, 12);
            this.label10.TabIndex = 2;
            this.label10.Text = "X Axis";
            // 
            // panel3
            // 
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.label4);
            this.panel3.Controls.Add(this.label5);
            this.panel3.Controls.Add(this.label6);
            this.panel3.Controls.Add(this.C2YDiv_comboBox);
            this.panel3.Controls.Add(this.C2_Type_comboBox);
            this.panel3.Controls.Add(this.Ena2_checkBox);
            this.panel3.Controls.Add(this.Neg2_checkBox);
            this.panel3.Location = new System.Drawing.Point(219, 3);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(210, 85);
            this.panel3.TabIndex = 1;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(77, 62);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(37, 12);
            this.label4.TabIndex = 2;
            this.label4.Text = "1 / Div";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(85, 36);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(29, 12);
            this.label5.TabIndex = 2;
            this.label5.Text = "Type";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(8, 10);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(53, 12);
            this.label6.TabIndex = 2;
            this.label6.Text = "Channel 2";
            // 
            // C2YDiv_comboBox
            // 
            this.C2YDiv_comboBox.FormattingEnabled = true;
            this.C2YDiv_comboBox.Location = new System.Drawing.Point(132, 59);
            this.C2YDiv_comboBox.Name = "C2YDiv_comboBox";
            this.C2YDiv_comboBox.Size = new System.Drawing.Size(64, 20);
            this.C2YDiv_comboBox.TabIndex = 1;
            this.C2YDiv_comboBox.SelectedIndexChanged += new System.EventHandler(this.C1YDiv_comboBox_SelectedIndexChanged);
            // 
            // C2_Type_comboBox
            // 
            this.C2_Type_comboBox.FormattingEnabled = true;
            this.C2_Type_comboBox.Location = new System.Drawing.Point(132, 33);
            this.C2_Type_comboBox.Name = "C2_Type_comboBox";
            this.C2_Type_comboBox.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.C2_Type_comboBox.Size = new System.Drawing.Size(64, 20);
            this.C2_Type_comboBox.TabIndex = 1;
            this.C2_Type_comboBox.SelectedIndexChanged += new System.EventHandler(this.C1_Type_comboBox_SelectedIndexChanged);
            // 
            // Ena2_checkBox
            // 
            this.Ena2_checkBox.AutoSize = true;
            this.Ena2_checkBox.Location = new System.Drawing.Point(10, 37);
            this.Ena2_checkBox.Name = "Ena2_checkBox";
            this.Ena2_checkBox.Size = new System.Drawing.Size(56, 16);
            this.Ena2_checkBox.TabIndex = 0;
            this.Ena2_checkBox.Text = "Enable";
            this.Ena2_checkBox.UseVisualStyleBackColor = true;
            this.Ena2_checkBox.CheckedChanged += new System.EventHandler(this.Ena1_checkBox_CheckedChanged);
            // 
            // Neg2_checkBox
            // 
            this.Neg2_checkBox.AutoSize = true;
            this.Neg2_checkBox.Location = new System.Drawing.Point(132, 7);
            this.Neg2_checkBox.Name = "Neg2_checkBox";
            this.Neg2_checkBox.Size = new System.Drawing.Size(43, 16);
            this.Neg2_checkBox.TabIndex = 0;
            this.Neg2_checkBox.Text = "N/A";
            this.Neg2_checkBox.UseVisualStyleBackColor = true;
            this.Neg2_checkBox.CheckedChanged += new System.EventHandler(this.Neg1_checkBox_CheckedChanged);
            // 
            // panel4
            // 
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel4.Controls.Add(this.label7);
            this.panel4.Controls.Add(this.label8);
            this.panel4.Controls.Add(this.label9);
            this.panel4.Controls.Add(this.C3YDiv_comboBox);
            this.panel4.Controls.Add(this.C3_Type_comboBox);
            this.panel4.Controls.Add(this.Ena3_checkBox);
            this.panel4.Controls.Add(this.Neg3_checkBox);
            this.panel4.Location = new System.Drawing.Point(435, 3);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(210, 85);
            this.panel4.TabIndex = 1;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(77, 62);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(37, 12);
            this.label7.TabIndex = 2;
            this.label7.Text = "1 / Div";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(85, 36);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(29, 12);
            this.label8.TabIndex = 2;
            this.label8.Text = "Type";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(8, 10);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(53, 12);
            this.label9.TabIndex = 2;
            this.label9.Text = "Channel 3";
            // 
            // C3YDiv_comboBox
            // 
            this.C3YDiv_comboBox.FormattingEnabled = true;
            this.C3YDiv_comboBox.Location = new System.Drawing.Point(132, 59);
            this.C3YDiv_comboBox.Name = "C3YDiv_comboBox";
            this.C3YDiv_comboBox.Size = new System.Drawing.Size(64, 20);
            this.C3YDiv_comboBox.TabIndex = 1;
            this.C3YDiv_comboBox.SelectedIndexChanged += new System.EventHandler(this.C1YDiv_comboBox_SelectedIndexChanged);
            // 
            // C3_Type_comboBox
            // 
            this.C3_Type_comboBox.FormattingEnabled = true;
            this.C3_Type_comboBox.Location = new System.Drawing.Point(132, 33);
            this.C3_Type_comboBox.Name = "C3_Type_comboBox";
            this.C3_Type_comboBox.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.C3_Type_comboBox.Size = new System.Drawing.Size(64, 20);
            this.C3_Type_comboBox.TabIndex = 1;
            this.C3_Type_comboBox.SelectedIndexChanged += new System.EventHandler(this.C1_Type_comboBox_SelectedIndexChanged);
            // 
            // Ena3_checkBox
            // 
            this.Ena3_checkBox.AutoSize = true;
            this.Ena3_checkBox.Location = new System.Drawing.Point(10, 37);
            this.Ena3_checkBox.Name = "Ena3_checkBox";
            this.Ena3_checkBox.Size = new System.Drawing.Size(56, 16);
            this.Ena3_checkBox.TabIndex = 0;
            this.Ena3_checkBox.Text = "Enable";
            this.Ena3_checkBox.UseVisualStyleBackColor = true;
            this.Ena3_checkBox.CheckedChanged += new System.EventHandler(this.Ena1_checkBox_CheckedChanged);
            // 
            // Neg3_checkBox
            // 
            this.Neg3_checkBox.AutoSize = true;
            this.Neg3_checkBox.Location = new System.Drawing.Point(130, 7);
            this.Neg3_checkBox.Name = "Neg3_checkBox";
            this.Neg3_checkBox.Size = new System.Drawing.Size(43, 16);
            this.Neg3_checkBox.TabIndex = 0;
            this.Neg3_checkBox.Text = "N/A";
            this.Neg3_checkBox.UseVisualStyleBackColor = true;
            this.Neg3_checkBox.CheckedChanged += new System.EventHandler(this.Neg1_checkBox_CheckedChanged);
            // 
            // panel5
            // 
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel5.Controls.Add(this.Right_button);
            this.panel5.Controls.Add(this.Left_button);
            this.panel5.Location = new System.Drawing.Point(930, 3);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(175, 85);
            this.panel5.TabIndex = 4;
            // 
            // Right_button
            // 
            this.Right_button.BackgroundImage = global::CS6257_Monitor.Resource1.chevron_right;
            this.Right_button.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.Right_button.Location = new System.Drawing.Point(95, 18);
            this.Right_button.Name = "Right_button";
            this.Right_button.Size = new System.Drawing.Size(75, 49);
            this.Right_button.TabIndex = 0;
            this.Right_button.UseVisualStyleBackColor = true;
            this.Right_button.Click += new System.EventHandler(this.Right_button_Click);
            // 
            // Left_button
            // 
            this.Left_button.BackgroundImage = global::CS6257_Monitor.Resource1.chevron_left;
            this.Left_button.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.Left_button.Location = new System.Drawing.Point(3, 18);
            this.Left_button.Name = "Left_button";
            this.Left_button.Size = new System.Drawing.Size(75, 49);
            this.Left_button.TabIndex = 0;
            this.Left_button.UseVisualStyleBackColor = true;
            this.Left_button.Click += new System.EventHandler(this.Left_button_Click);
            // 
            // panel6
            // 
            this.panel6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel6.Controls.Add(this.Mode_comboBox);
            this.panel6.Controls.Add(this.label13);
            this.panel6.Location = new System.Drawing.Point(800, 3);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(127, 85);
            this.panel6.TabIndex = 2;
            // 
            // Mode_comboBox
            // 
            this.Mode_comboBox.FormattingEnabled = true;
            this.Mode_comboBox.Location = new System.Drawing.Point(10, 33);
            this.Mode_comboBox.Name = "Mode_comboBox";
            this.Mode_comboBox.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.Mode_comboBox.Size = new System.Drawing.Size(97, 20);
            this.Mode_comboBox.TabIndex = 1;
            this.Mode_comboBox.SelectedIndexChanged += new System.EventHandler(this.Mode_comboBox_SelectedIndexChanged);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(8, 10);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(32, 12);
            this.label13.TabIndex = 2;
            this.label13.Text = "Mode";
            // 
            // PlotControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel1);
            this.Name = "PlotControl";
            this.Size = new System.Drawing.Size(1108, 91);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.CheckBox Ena1_checkBox;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ComboBox C1_Type_comboBox;
        private System.Windows.Forms.ComboBox XDiv_comboBox;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox C1YDiv_comboBox;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox C2YDiv_comboBox;
        private System.Windows.Forms.ComboBox C2_Type_comboBox;
        private System.Windows.Forms.CheckBox Ena2_checkBox;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox C3YDiv_comboBox;
        private System.Windows.Forms.ComboBox C3_Type_comboBox;
        private System.Windows.Forms.CheckBox Neg3_checkBox;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Button Right_button;
        private System.Windows.Forms.Button Left_button;
        private System.Windows.Forms.CheckBox Neg1_checkBox;
        private System.Windows.Forms.CheckBox Neg2_checkBox;
        private System.Windows.Forms.CheckBox Ena3_checkBox;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.ComboBox Mode_comboBox;
        private System.Windows.Forms.Label label13;
    }
}

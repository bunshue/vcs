﻿namespace CS6257_Monitor
{
    partial class MotorCtrlForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MotorCtrlForm));
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripLabel1 = new System.Windows.Forms.ToolStripLabel();
            this.CB_COMPortName = new System.Windows.Forms.ToolStripComboBox();
            this.refresh_comport = new System.Windows.Forms.ToolStripButton();
            this.toolStripLabel2 = new System.Windows.Forms.ToolStripLabel();
            this.CB_BaudRate = new System.Windows.Forms.ToolStripComboBox();
            this.toolStripLabel3 = new System.Windows.Forms.ToolStripLabel();
            this.CB_Data = new System.Windows.Forms.ToolStripComboBox();
            this.toolStripLabel4 = new System.Windows.Forms.ToolStripLabel();
            this.CB_StopBits = new System.Windows.Forms.ToolStripComboBox();
            this.toolStripLabel5 = new System.Windows.Forms.ToolStripLabel();
            this.CB_ParityBits = new System.Windows.Forms.ToolStripComboBox();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.OpenComPortButton = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.Monitor_ON_OFF = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.Open_GraphForm_button = new System.Windows.Forms.ToolStripButton();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.monitorUI_Lite1 = new CS6257_Monitor.UserUI.MonitorUI_Lite();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.parameterConfigUI1 = new CS6257_Monitor.UserUI.ParameterConfigUI();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.cS6257ParaUI1 = new CS6257_Monitor.CS6257ParaUI();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.commandUI1 = new CS6257_Monitor.CommandUI();
            this.groupBox14 = new System.Windows.Forms.GroupBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.Clear_RxHexData_richtextBox_button = new System.Windows.Forms.Button();
            this.LB_RxHexDatarichText_buf = new System.Windows.Forms.Label();
            this.RxHexData_richtextBox = new System.Windows.Forms.RichTextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.Main_Rx_Data_richText = new System.Windows.Forms.RichTextBox();
            this.LB_Main_Rx_Data_richText_buf = new System.Windows.Forms.Label();
            this.Clear_Rx_Data_richtext_2 = new System.Windows.Forms.Button();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.LB_NowTime = new System.Windows.Forms.ToolStripStatusLabel();
            this.LB_ComportState = new System.Windows.Forms.ToolStripStatusLabel();
            this.LB_LinkState = new System.Windows.Forms.ToolStripStatusLabel();
            this.LB_ParaSYNState = new System.Windows.Forms.ToolStripStatusLabel();
            this.LB_RunParaState = new System.Windows.Forms.ToolStripStatusLabel();
            this.LB_EflashState = new System.Windows.Forms.ToolStripStatusLabel();
            this.LB_WorkState = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripProgressBar1 = new System.Windows.Forms.ToolStripProgressBar();
            this.LB_ProgressValue = new System.Windows.Forms.ToolStripStatusLabel();
            this.LB_ReadWriteState = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStrip1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.groupBox14.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel1.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripLabel1,
            this.CB_COMPortName,
            this.refresh_comport,
            this.toolStripLabel2,
            this.CB_BaudRate,
            this.toolStripLabel3,
            this.CB_Data,
            this.toolStripLabel4,
            this.CB_StopBits,
            this.toolStripLabel5,
            this.CB_ParityBits,
            this.toolStripSeparator1,
            this.OpenComPortButton,
            this.toolStripSeparator2,
            this.Monitor_ON_OFF,
            this.toolStripSeparator4,
            this.Open_GraphForm_button});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(1114, 25);
            this.toolStrip1.TabIndex = 4;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripLabel1
            // 
            this.toolStripLabel1.Name = "toolStripLabel1";
            this.toolStripLabel1.Size = new System.Drawing.Size(63, 22);
            this.toolStripLabel1.Text = "COM Port";
            // 
            // CB_COMPortName
            // 
            this.CB_COMPortName.Name = "CB_COMPortName";
            this.CB_COMPortName.Size = new System.Drawing.Size(121, 25);
            // 
            // refresh_comport
            // 
            this.refresh_comport.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.refresh_comport.Image = global::CS6257_Monitor.Resource1.refresh;
            this.refresh_comport.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.refresh_comport.Name = "refresh_comport";
            this.refresh_comport.Size = new System.Drawing.Size(23, 22);
            this.refresh_comport.Text = "Refresh";
            this.refresh_comport.Click += new System.EventHandler(this.refresh_comport_Click);
            // 
            // toolStripLabel2
            // 
            this.toolStripLabel2.Name = "toolStripLabel2";
            this.toolStripLabel2.Size = new System.Drawing.Size(65, 22);
            this.toolStripLabel2.Text = "Baud Rate";
            // 
            // CB_BaudRate
            // 
            this.CB_BaudRate.Enabled = false;
            this.CB_BaudRate.Name = "CB_BaudRate";
            this.CB_BaudRate.Size = new System.Drawing.Size(121, 25);
            // 
            // toolStripLabel3
            // 
            this.toolStripLabel3.Name = "toolStripLabel3";
            this.toolStripLabel3.Size = new System.Drawing.Size(34, 22);
            this.toolStripLabel3.Text = "Data";
            // 
            // CB_Data
            // 
            this.CB_Data.Enabled = false;
            this.CB_Data.Name = "CB_Data";
            this.CB_Data.Size = new System.Drawing.Size(75, 25);
            // 
            // toolStripLabel4
            // 
            this.toolStripLabel4.Name = "toolStripLabel4";
            this.toolStripLabel4.Size = new System.Drawing.Size(56, 22);
            this.toolStripLabel4.Text = "Stop Bits";
            // 
            // CB_StopBits
            // 
            this.CB_StopBits.Enabled = false;
            this.CB_StopBits.Name = "CB_StopBits";
            this.CB_StopBits.Size = new System.Drawing.Size(75, 25);
            // 
            // toolStripLabel5
            // 
            this.toolStripLabel5.Name = "toolStripLabel5";
            this.toolStripLabel5.Size = new System.Drawing.Size(60, 22);
            this.toolStripLabel5.Text = "Parity Bits";
            // 
            // CB_ParityBits
            // 
            this.CB_ParityBits.Name = "CB_ParityBits";
            this.CB_ParityBits.Size = new System.Drawing.Size(75, 25);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // OpenComPortButton
            // 
            this.OpenComPortButton.Image = global::CS6257_Monitor.Resource1.red_ball_icon;
            this.OpenComPortButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.OpenComPortButton.Name = "OpenComPortButton";
            this.OpenComPortButton.Size = new System.Drawing.Size(92, 22);
            this.OpenComPortButton.Text = "COM Open";
            this.OpenComPortButton.Click += new System.EventHandler(this.OpenComPortButton_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // Monitor_ON_OFF
            // 
            this.Monitor_ON_OFF.Image = global::CS6257_Monitor.Resource1.red_ball_icon;
            this.Monitor_ON_OFF.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.Monitor_ON_OFF.Name = "Monitor_ON_OFF";
            this.Monitor_ON_OFF.Size = new System.Drawing.Size(99, 22);
            this.Monitor_ON_OFF.Text = "Monitor ON ";
            this.Monitor_ON_OFF.Click += new System.EventHandler(this.Monitor_ON_OFF_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(6, 25);
            // 
            // Open_GraphForm_button
            // 
            this.Open_GraphForm_button.Image = global::CS6257_Monitor.Resource1.Chart_bar_icon;
            this.Open_GraphForm_button.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.Open_GraphForm_button.Name = "Open_GraphForm_button";
            this.Open_GraphForm_button.Size = new System.Drawing.Size(57, 22);
            this.Open_GraphForm_button.Text = "Chart";
            this.Open_GraphForm_button.Click += new System.EventHandler(this.Open_GraphForm_button_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Appearance = System.Windows.Forms.TabAppearance.FlatButtons;
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Location = new System.Drawing.Point(0, 28);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1114, 629);
            this.tabControl1.TabIndex = 5;
            this.tabControl1.SelectedIndexChanged += new System.EventHandler(this.tabControl1_SelectedIndexChanged);
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.monitorUI_Lite1);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1106, 600);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Monitor";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // monitorUI_Lite1
            // 
            this.monitorUI_Lite1.Location = new System.Drawing.Point(6, 6);
            this.monitorUI_Lite1.Name = "monitorUI_Lite1";
            this.monitorUI_Lite1.Size = new System.Drawing.Size(1092, 581);
            this.monitorUI_Lite1.TabIndex = 0;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.parameterConfigUI1);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1106, 600);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Parameter Config";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // parameterConfigUI1
            // 
            this.parameterConfigUI1.BackColor = System.Drawing.SystemColors.Control;
            this.parameterConfigUI1.Location = new System.Drawing.Point(-4, 0);
            this.parameterConfigUI1.Name = "parameterConfigUI1";
            this.parameterConfigUI1.Size = new System.Drawing.Size(1102, 597);
            this.parameterConfigUI1.TabIndex = 4;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.cS6257ParaUI1);
            this.tabPage3.Location = new System.Drawing.Point(4, 25);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(1106, 600);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Dev";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // cS6257ParaUI1
            // 
            this.cS6257ParaUI1.Location = new System.Drawing.Point(6, 6);
            this.cS6257ParaUI1.Name = "cS6257ParaUI1";
            this.cS6257ParaUI1.Size = new System.Drawing.Size(1094, 568);
            this.cS6257ParaUI1.TabIndex = 0;
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.commandUI1);
            this.tabPage4.Controls.Add(this.groupBox14);
            this.tabPage4.Location = new System.Drawing.Point(4, 25);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(1106, 600);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Dev 2";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // commandUI1
            // 
            this.commandUI1.Location = new System.Drawing.Point(575, 6);
            this.commandUI1.Name = "commandUI1";
            this.commandUI1.Size = new System.Drawing.Size(342, 583);
            this.commandUI1.TabIndex = 7;
            // 
            // groupBox14
            // 
            this.groupBox14.Controls.Add(this.panel5);
            this.groupBox14.Controls.Add(this.panel1);
            this.groupBox14.Location = new System.Drawing.Point(8, 6);
            this.groupBox14.Name = "groupBox14";
            this.groupBox14.Size = new System.Drawing.Size(561, 573);
            this.groupBox14.TabIndex = 6;
            this.groupBox14.TabStop = false;
            this.groupBox14.Text = "接收資料";
            // 
            // panel5
            // 
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel5.Controls.Add(this.Clear_RxHexData_richtextBox_button);
            this.panel5.Controls.Add(this.LB_RxHexDatarichText_buf);
            this.panel5.Controls.Add(this.RxHexData_richtextBox);
            this.panel5.Location = new System.Drawing.Point(7, 326);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(545, 241);
            this.panel5.TabIndex = 5;
            // 
            // Clear_RxHexData_richtextBox_button
            // 
            this.Clear_RxHexData_richtextBox_button.Location = new System.Drawing.Point(460, 5);
            this.Clear_RxHexData_richtextBox_button.Name = "Clear_RxHexData_richtextBox_button";
            this.Clear_RxHexData_richtextBox_button.Size = new System.Drawing.Size(75, 23);
            this.Clear_RxHexData_richtextBox_button.TabIndex = 2;
            this.Clear_RxHexData_richtextBox_button.Text = "Clear";
            this.Clear_RxHexData_richtextBox_button.UseVisualStyleBackColor = true;
            this.Clear_RxHexData_richtextBox_button.Click += new System.EventHandler(this.Clear_RxHexData_richtextBox_button_Click);
            // 
            // LB_RxHexDatarichText_buf
            // 
            this.LB_RxHexDatarichText_buf.AutoSize = true;
            this.LB_RxHexDatarichText_buf.Location = new System.Drawing.Point(332, 10);
            this.LB_RxHexDatarichText_buf.Name = "LB_RxHexDatarichText_buf";
            this.LB_RxHexDatarichText_buf.Size = new System.Drawing.Size(83, 12);
            this.LB_RxHexDatarichText_buf.TabIndex = 3;
            this.LB_RxHexDatarichText_buf.Text = "資料緩衝區 :  0";
            // 
            // RxHexData_richtextBox
            // 
            this.RxHexData_richtextBox.Location = new System.Drawing.Point(10, 34);
            this.RxHexData_richtextBox.Name = "RxHexData_richtextBox";
            this.RxHexData_richtextBox.Size = new System.Drawing.Size(525, 196);
            this.RxHexData_richtextBox.TabIndex = 1;
            this.RxHexData_richtextBox.Text = "";
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.Main_Rx_Data_richText);
            this.panel1.Controls.Add(this.LB_Main_Rx_Data_richText_buf);
            this.panel1.Controls.Add(this.Clear_Rx_Data_richtext_2);
            this.panel1.Location = new System.Drawing.Point(6, 21);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(546, 299);
            this.panel1.TabIndex = 4;
            // 
            // Main_Rx_Data_richText
            // 
            this.Main_Rx_Data_richText.Location = new System.Drawing.Point(10, 34);
            this.Main_Rx_Data_richText.Name = "Main_Rx_Data_richText";
            this.Main_Rx_Data_richText.Size = new System.Drawing.Size(526, 260);
            this.Main_Rx_Data_richText.TabIndex = 2;
            this.Main_Rx_Data_richText.Text = "";
            // 
            // LB_Main_Rx_Data_richText_buf
            // 
            this.LB_Main_Rx_Data_richText_buf.AutoSize = true;
            this.LB_Main_Rx_Data_richText_buf.Location = new System.Drawing.Point(333, 10);
            this.LB_Main_Rx_Data_richText_buf.Name = "LB_Main_Rx_Data_richText_buf";
            this.LB_Main_Rx_Data_richText_buf.Size = new System.Drawing.Size(122, 12);
            this.LB_Main_Rx_Data_richText_buf.TabIndex = 3;
            this.LB_Main_Rx_Data_richText_buf.Text = "資料緩衝區 : 00000000";
            // 
            // Clear_Rx_Data_richtext_2
            // 
            this.Clear_Rx_Data_richtext_2.Location = new System.Drawing.Point(461, 5);
            this.Clear_Rx_Data_richtext_2.Name = "Clear_Rx_Data_richtext_2";
            this.Clear_Rx_Data_richtext_2.Size = new System.Drawing.Size(75, 23);
            this.Clear_Rx_Data_richtext_2.TabIndex = 1;
            this.Clear_Rx_Data_richtext_2.Text = "Clear";
            this.Clear_Rx_Data_richtext_2.UseVisualStyleBackColor = true;
            this.Clear_Rx_Data_richtext_2.Click += new System.EventHandler(this.Clear_Rx_Data_richtext_2_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.LB_NowTime,
            this.LB_ComportState,
            this.LB_LinkState,
            this.LB_ParaSYNState,
            this.LB_RunParaState,
            this.LB_EflashState,
            this.LB_WorkState,
            this.toolStripProgressBar1,
            this.LB_ProgressValue,
            this.LB_ReadWriteState});
            this.statusStrip1.Location = new System.Drawing.Point(0, 660);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(1114, 22);
            this.statusStrip1.TabIndex = 6;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // LB_NowTime
            // 
            this.LB_NowTime.Name = "LB_NowTime";
            this.LB_NowTime.Size = new System.Drawing.Size(80, 17);
            this.LB_NowTime.Text = "LB_NowTime";
            // 
            // LB_ComportState
            // 
            this.LB_ComportState.Name = "LB_ComportState";
            this.LB_ComportState.Size = new System.Drawing.Size(100, 17);
            this.LB_ComportState.Text = "COM Port Status";
            // 
            // LB_LinkState
            // 
            this.LB_LinkState.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.LB_LinkState.Image = global::CS6257_Monitor.Resource1.green_ball_icon;
            this.LB_LinkState.Name = "LB_LinkState";
            this.LB_LinkState.Size = new System.Drawing.Size(74, 17);
            this.LB_LinkState.Text = "LINK_STATE";
            // 
            // LB_ParaSYNState
            // 
            this.LB_ParaSYNState.Name = "LB_ParaSYNState";
            this.LB_ParaSYNState.Size = new System.Drawing.Size(103, 17);
            this.LB_ParaSYNState.Text = "LB_ParaSYNState";
            // 
            // LB_RunParaState
            // 
            this.LB_RunParaState.Name = "LB_RunParaState";
            this.LB_RunParaState.Size = new System.Drawing.Size(101, 17);
            this.LB_RunParaState.Text = "LB_RunParaState";
            // 
            // LB_EflashState
            // 
            this.LB_EflashState.Name = "LB_EflashState";
            this.LB_EflashState.Size = new System.Drawing.Size(87, 17);
            this.LB_EflashState.Text = "LB_EflashState";
            // 
            // LB_WorkState
            // 
            this.LB_WorkState.Name = "LB_WorkState";
            this.LB_WorkState.Size = new System.Drawing.Size(66, 17);
            this.LB_WorkState.Text = "WorkState";
            this.LB_WorkState.Visible = false;
            // 
            // toolStripProgressBar1
            // 
            this.toolStripProgressBar1.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.toolStripProgressBar1.Name = "toolStripProgressBar1";
            this.toolStripProgressBar1.Size = new System.Drawing.Size(100, 16);
            this.toolStripProgressBar1.Step = 1;
            this.toolStripProgressBar1.Visible = false;
            // 
            // LB_ProgressValue
            // 
            this.LB_ProgressValue.Name = "LB_ProgressValue";
            this.LB_ProgressValue.Size = new System.Drawing.Size(89, 17);
            this.LB_ProgressValue.Text = "progress value";
            this.LB_ProgressValue.Visible = false;
            // 
            // LB_ReadWriteState
            // 
            this.LB_ReadWriteState.Name = "LB_ReadWriteState";
            this.LB_ReadWriteState.Size = new System.Drawing.Size(96, 17);
            this.LB_ReadWriteState.Text = "ReadWriteState";
            this.LB_ReadWriteState.Visible = false;
            // 
            // MotorCtrlForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1114, 682);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.toolStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "MotorCtrlForm";
            this.Text = "Motor Control Development Kits Beta v0.35";
            this.Load += new System.EventHandler(this.MotorCtrlForm_Load);
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.tabPage4.ResumeLayout(false);
            this.groupBox14.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripLabel toolStripLabel1;
        private System.Windows.Forms.ToolStripComboBox CB_COMPortName;
        private System.Windows.Forms.ToolStripButton refresh_comport;
        private System.Windows.Forms.ToolStripLabel toolStripLabel2;
        private System.Windows.Forms.ToolStripComboBox CB_BaudRate;
        private System.Windows.Forms.ToolStripLabel toolStripLabel3;
        private System.Windows.Forms.ToolStripComboBox CB_Data;
        private System.Windows.Forms.ToolStripLabel toolStripLabel4;
        private System.Windows.Forms.ToolStripComboBox CB_StopBits;
        private System.Windows.Forms.ToolStripLabel toolStripLabel5;
        private System.Windows.Forms.ToolStripComboBox CB_ParityBits;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton OpenComPortButton;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripButton Monitor_ON_OFF;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private UserUI.MonitorUI_Lite monitorUI_Lite1;
        private System.Windows.Forms.TabPage tabPage3;
        private CS6257ParaUI cS6257ParaUI1;
        private UserUI.ParameterConfigUI parameterConfigUI1;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel LB_NowTime;
        private System.Windows.Forms.ToolStripStatusLabel LB_ComportState;
        private System.Windows.Forms.ToolStripStatusLabel LB_LinkState;
        private System.Windows.Forms.ToolStripStatusLabel LB_WorkState;
        private System.Windows.Forms.ToolStripProgressBar toolStripProgressBar1;
        private System.Windows.Forms.ToolStripStatusLabel LB_ProgressValue;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.GroupBox groupBox14;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Button Clear_RxHexData_richtextBox_button;
        private System.Windows.Forms.Label LB_RxHexDatarichText_buf;
        private System.Windows.Forms.RichTextBox RxHexData_richtextBox;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.RichTextBox Main_Rx_Data_richText;
        private System.Windows.Forms.Label LB_Main_Rx_Data_richText_buf;
        private System.Windows.Forms.Button Clear_Rx_Data_richtext_2;
        private System.Windows.Forms.ToolStripButton Open_GraphForm_button;
        private System.Windows.Forms.ToolStripStatusLabel LB_ParaSYNState;
        private System.Windows.Forms.ToolStripStatusLabel LB_RunParaState;
        private System.Windows.Forms.ToolStripStatusLabel LB_EflashState;
        private System.Windows.Forms.ToolStripStatusLabel LB_ReadWriteState;
        private CommandUI commandUI1;
    }
}
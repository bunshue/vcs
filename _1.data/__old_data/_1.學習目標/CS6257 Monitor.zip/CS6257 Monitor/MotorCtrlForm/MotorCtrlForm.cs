﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;

namespace CS6257_Monitor
{
    public partial class MotorCtrlForm : Form
    {
        private delegate void Delegate_UpdateWindowsForm();
        private Delegate_UpdateWindowsForm D_UpdateWindowsForm;

        private Thread Update_Form_thread;      // 視窗更新執行緒

        // 繪圖視窗
        GraphForm graphform;

        private TransControl transCtrl = new TransControl();
        private ComPort comport;

        private struct SYS_FLAG
        {
            public bool MonitorState;
        }

        SYS_FLAG SysFlag;

        private int update_delay_cnt_100ms = 0;
        private int update_delay_cnt_1sec = 0;

        public MotorCtrlForm()
        {
            InitializeComponent();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void MotorCtrlForm_Load(object sender, EventArgs e)
        {
            // 初始 COM Port 設定
            Init_COMPort_Config();
            //
            this.cS6257ParaUI1.Init_CS6257ParaUI(transCtrl);
            this.monitorUI_Lite1.Init_UpdateMonitorUI(transCtrl);
            this.parameterConfigUI1.Init_ParameterConfigUI(transCtrl);
            //
            commandUI1.Init_CommandUI(transCtrl);
            //
            Set_Monitor_ON_OFF();
            // 初始委派函式
            D_UpdateWindowsForm = new Delegate_UpdateWindowsForm(UpdateWindowsForm_Method);
            // 建立視窗更新執行緒
            Update_Form_thread = new Thread(new ThreadStart(UpdateWindowsForm_DoWork));
            Update_Form_thread.Name = "MotorCtrlForm Thread";
            Update_Form_thread.IsBackground = true;
            Update_Form_thread.Start();

            //this.tabControl1.TabPages.Remove(this.tabPage3);
            //this.tabControl1.TabPages.Remove(this.tabPage4);
        }

        /// <summary>
        /// 視窗更新方法
        /// </summary>
        private void UpdateWindowsForm_Method()
        {
            // 顯示 COM Port 狀態
            Update_ComPortStatus();
            // 更新顯示時間
            this.LB_NowTime.Text = DateTime.Now.ToString();
            //
            UpdateConectionStatus(this.LB_LinkState);
            UpdateParamSynStatus(this.LB_ParaSYNState);
            UpdateRunParaState(this.LB_RunParaState);
            UpdateEflashState(this.LB_EflashState);
            // 進度條更新
            Update_ProgressBar();

            // delay 100 ms
            if (++update_delay_cnt_100ms > 10)
            {
                update_delay_cnt_100ms = 0;
                //
                this.cS6257ParaUI1.UpdateUI();
                this.monitorUI_Lite1.UpdateMonitorUI();
                transCtrl.UpdateMonitorData();
                //
                Update_RichTextBox();
                //
                Disp_RichTextBuffSize(this.LB_Main_Rx_Data_richText_buf, this.Main_Rx_Data_richText);
                Disp_RichTextBuffSize(this.LB_RxHexDatarichText_buf, this.RxHexData_richtextBox);

                Clear_RichTextBuff(this.Main_Rx_Data_richText);
                Clear_RichTextBuff(this.RxHexData_richtextBox);
            }

            // delay 1 sec
            if (++update_delay_cnt_1sec > 100)
            {
                update_delay_cnt_1sec = 0;
            }
        }

        /// <summary>
        /// 執行視窗更新工作
        /// </summary>
        private void UpdateWindowsForm_DoWork()
        {
            while(true)
            {
                this.Invoke(D_UpdateWindowsForm);
                Thread.Sleep(10);
            }
        }

        /// <summary>
        /// 進度條更新
        /// 說明 : 當資料傳送/接收時顯示進度條
        /// </summary>
        private void Update_ProgressBar()
        {
            // 
            if (transCtrl.progress != 0)
            {
                this.toolStripProgressBar1.Visible = true;
                this.toolStripProgressBar1.Value = transCtrl.progress;
                this.LB_WorkState.Visible = true;
                this.LB_ProgressValue.Visible = true;
                this.LB_ProgressValue.Text = transCtrl.progress.ToString();

                if (transCtrl.SciState.mode == Communication.WORKING_MODE.GET_PARAM ||
                    transCtrl.SciState.mode == Communication.WORKING_MODE.GET_MT_PARAM ||
                    transCtrl.SciState.mode == Communication.WORKING_MODE.GET_ST_PARAM)
                {
                    this.LB_WorkState.Text = "資料取得中";
                    this.LB_ReadWriteState.Visible = false;
                }
                else if (transCtrl.SciState.mode == Communication.WORKING_MODE.SEND_PARAM ||
                    transCtrl.SciState.mode == Communication.WORKING_MODE.SEND_MT_PARAM ||
                    transCtrl.SciState.mode == Communication.WORKING_MODE.SEND_ST_PARAM)
                {
                    this.LB_WorkState.Text = "資料發送中";
                    this.LB_ReadWriteState.Visible = false;
                }
            }
            else
            {
                this.toolStripProgressBar1.Visible = false;
                this.LB_WorkState.Visible = false;
                this.LB_ProgressValue.Visible = false;
            }
        }

        /// <summary>
        /// 更新 RichTextBox
        /// </summary>
        private void Update_RichTextBox()
        {
            if (transCtrl.receive_str != string.Empty)
            {
                this.Main_Rx_Data_richText.AppendText(transCtrl.receive_str);
                this.Main_Rx_Data_richText.ScrollToCaret();
                transCtrl.receive_str = string.Empty;
            }
            if (transCtrl.receive_hex_str != string.Empty)
            {
                this.RxHexData_richtextBox.AppendText(transCtrl.receive_hex_str + "\n");
                this.RxHexData_richtextBox.ScrollToCaret();
                transCtrl.receive_hex_str = string.Empty;
            }
        }

        /// <summary>
        /// 顯示 richtextbox資料緩衝區大小
        /// </summary>
        private void Disp_RichTextBuffSize(Label label, RichTextBox textbox)
        {
            string str_temp = string.Empty;
            str_temp = textbox.TextLength.ToString();
            label.Text = "資料緩衝區 : " + str_temp;
        }

        /// <summary>
        /// 當 RichText 字串過長時清除所有內容
        /// </summary>
        /// <param name="textbox"></param>
        private void Clear_RichTextBuff(RichTextBox textbox)
        {
            if (textbox.TextLength > 100000)
            {
                textbox.Clear();
            }
        }

        #region 功能開關 toolStrip

        /// <summary>
        /// 按下後開啟/關閉 COM Port
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void OpenComPortButton_Click(object sender, EventArgs e)
        {
            Open_Close_ComPort();
        }

        /// <summary>
        /// 更新可用的 COM Port
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void refresh_comport_Click(object sender, EventArgs e)
        {
            Refresh_COMPort();
        }

        /// <summary>
        /// Monitor 資料 傳送/接收 功能開啟/關閉
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Monitor_ON_OFF_Click(object sender, EventArgs e)
        {
            Set_Monitor_ON_OFF();
        }

        #endregion

        private void Set_Monitor_ON_OFF()
        {
            if (SysFlag.MonitorState)
            {
                SysFlag.MonitorState = false;
                //bc.SciFlag.ReqMonitorData = false;      // ??
                transCtrl.pcState.MonitorState = TransControl.MONITOR_STATE.OFF;
                this.Set_Button_Monitor_ON_OFF(false);
            }
            else
            {
                SysFlag.MonitorState = true;
                //bc.SciFlag.ReqMonitorData = true;       // ??
                transCtrl.pcState.MonitorState = TransControl.MONITOR_STATE.ON;
                this.Set_Button_Monitor_ON_OFF(true);
            }
        }

        /// <summary>
        /// 設定 Monitor功能開啟 / 關閉
        /// </summary>
        /// <param name="value"></param>
        private void Set_Button_Monitor_ON_OFF(bool value)
        {
            if (value)
            {
                // 開啟
                this.Monitor_ON_OFF.Text = "Monitor ON ";
                this.Monitor_ON_OFF.Image = Resource1.green_ball_icon;
            }
            else
            {
                // 關閉
                this.Monitor_ON_OFF.Text = "Monitor OFF";
                this.Monitor_ON_OFF.Image = Resource1.red_ball_icon;
            }
        }

        /// <summary>
        /// 開啟圖表顯示視窗
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Open_GraphForm_button_Click(object sender, EventArgs e)
        {
            try
            {
                graphform.Show();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
                graphform = new GraphForm(transCtrl);
                graphform.Show();
            }
        }

        /// <summary>
        /// 清除接收RichTextBox中的所有內容
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Clear_Rx_Data_richtext_2_Click(object sender, EventArgs e)
        {
            this.Main_Rx_Data_richText.Clear();
        }

        /// <summary>
        /// 清除接收 Hex RichTextBox中的所有內容
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Clear_RxHexData_richtextBox_button_Click(object sender, EventArgs e)
        {
            this.RxHexData_richtextBox.Clear();
        }

        /// <summary>
        /// 更新連線狀態顯示
        /// </summary>
        public void UpdateConectionStatus(ToolStripLabel label)
        {
            if (transCtrl.pcState.ComState == TransControl.COM_STATE.ESTABLISHED)
            {
                label.ForeColor = Color.Green;
                label.Text = "ESTABLISHED";
            }
            else if (transCtrl.pcState.ComState == TransControl.COM_STATE.DISCONNECTED)
            {
                label.ForeColor = Color.Red;
                label.Text = "DISCONNECTED";
            }
        }

        /// <summary>
        /// 更新參數同步狀態顯示
        /// </summary>
        public void UpdateParamSynStatus(ToolStripLabel label)
        {
            switch (transCtrl.pcState.ParamState)
            {
                case TransControl.PARAM_STATE.REQ:
                    label.Text = "REQ";
                    break;
                case TransControl.PARAM_STATE.RECV_CHECK:
                    label.Text = "RECV_CHECK";
                    break;
                case TransControl.PARAM_STATE.SEND_CHECK:
                    label.Text = "SEND_CHECK";
                    break;
                case TransControl.PARAM_STATE.GET:
                    label.Text = "GET";
                    break;
                case TransControl.PARAM_STATE.GET_WAIT:
                    label.Text = "GET_WAIT";
                    break;
                case TransControl.PARAM_STATE.SEND:
                    label.Text = "SEND";
                    break;
                case TransControl.PARAM_STATE.SEND_WAIT:
                    label.Text = "SEND_WAIT";
                    break;
                case TransControl.PARAM_STATE.ASY:
                    label.Text = "ASY";
                    break;
                case TransControl.PARAM_STATE.SYN:
                    label.Text = "SYN";
                    break;
                case TransControl.PARAM_STATE.DEFAULT:
                    label.Text = "DEFAULT";
                    break;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        public void UpdateRunParaState(ToolStripLabel label)
        {
            switch (transCtrl.pcState.RunParamState)
            {
                case TransControl.RUNPARAM_STATE.DEFAULE:
                    label.Text = "DEFAULT";
                    break;
                case TransControl.RUNPARAM_STATE.SEND:
                    label.Text = "SEND";
                    break;
                case TransControl.RUNPARAM_STATE.ACK:
                    label.Text = "ACK";
                    break;
                case TransControl.RUNPARAM_STATE.NACK:
                    label.Text = "NACK";
                    break;
                case TransControl.RUNPARAM_STATE.WAIT:
                    label.Text = "WAIT";
                    break;
            }
        }

        /// <summary>
        /// 更新Eflash傳輸狀態
        /// </summary>
        /// <param name="textbox"></param>
        public void UpdateEflashState(ToolStripLabel label)
        {
            switch (transCtrl.pcState.EfalshState)
            {
                case TransControl.EFLASH_STATE.READ:
                    label.Text = "READ";
                    break;
                case TransControl.EFLASH_STATE.WRITE:
                    label.Text = "WRITE";
                    break;
                case TransControl.EFLASH_STATE.ACK:
                    label.Text = "ACK";
                    break;
                case TransControl.EFLASH_STATE.NACK:
                    label.Text = "NACK";
                    break;
                case TransControl.EFLASH_STATE.DEFAULT:
                    label.Text = "DEFAULT";
                    break;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {
            //this.parameterConfigUI1.DispParameter();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;

namespace CS6257_Monitor
{
    public partial class MotorCtrlForm : Form
    {
        #region COM Port Config

        /// <summary>
        /// 初始化 COM Port 設定
        /// </summary>
        private void Init_COMPort_Config()
        {
            // 初始化 ComboBox
            this.CB_COMPortName.Text = "COM6";
            this.CB_BaudRate.Text = "115200";
            this.CB_BaudRate.Items.Add("19200");
            this.CB_BaudRate.Items.Add("115200");
            this.CB_Data.Text = "8";
            this.CB_StopBits.Text = "1";
            this.CB_ParityBits.Text = "None";

            // 取得ComPort物件
            comport = transCtrl.GetComPortObj();
            // 取得可開啟的COM Port
            comport.GetComPort(this.CB_COMPortName);
            if (this.CB_COMPortName.Items.Count > 0) this.CB_COMPortName.SelectedIndex = 0;
        }

        /// <summary>
        /// 顯示 COM Port 狀態
        /// </summary>
        private void Update_ComPortStatus()
        {
            if (comport.IsComPortOpen() == true)
            {
                this.LB_ComportState.Text = this.CB_COMPortName.Text + " OPEN";
                this.LB_ComportState.ForeColor = Color.DarkGreen;
            }
            else
            {
                this.LB_ComportState.Text = "COM CLOSE";
                this.LB_ComportState.ForeColor = Color.Red;
            }
        }

        /// <summary>
        /// 開啟 / 關閉 COM Port
        /// </summary>
        private void Open_Close_ComPort()
        {
            if (transCtrl.IsComPortOpen() == false)
            {
                // 開啟 COM Port
                comport.OpenComPort(this.CB_COMPortName.Text,
                                    this.CB_BaudRate.Text,
                                    this.CB_Data.Text,
                                    this.CB_StopBits.Text,
                                    this.CB_ParityBits.Text);
                if (comport.IsComPortOpen())
                {
                    this.OpenComPortButton.Text = "COM Close";
                    this.OpenComPortButton.Image = Resource1.green_ball_icon;
                }
            }
            else
            {
                // 關閉 COM Port
                comport.CloseComPort();
                if (comport.IsComPortOpen() == false)
                {
                    this.OpenComPortButton.Text = "COM Open";
                    this.OpenComPortButton.Image = Resource1.red_ball_icon;
                }
            }
        }

        /// <summary>
        /// 更新可用的COM Port
        /// </summary>
        private void Refresh_COMPort()
        {
            // 清除所有物件
            this.CB_COMPortName.Items.Clear();
            // 取得可開啟的COM Port
            comport.GetComPort(this.CB_COMPortName);
            if (this.CB_COMPortName.Items.Count > 0) this.CB_COMPortName.SelectedIndex = 0;
        }

        #endregion
    }
}

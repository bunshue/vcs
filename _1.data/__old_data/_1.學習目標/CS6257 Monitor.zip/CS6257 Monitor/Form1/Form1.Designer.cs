﻿namespace CS6257_Monitor
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器
        /// 修改這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripLabel1 = new System.Windows.Forms.ToolStripLabel();
            this.CB_COMPortName = new System.Windows.Forms.ToolStripComboBox();
            this.refresh_comport = new System.Windows.Forms.ToolStripButton();
            this.toolStripLabel2 = new System.Windows.Forms.ToolStripLabel();
            this.CB_BaudRate = new System.Windows.Forms.ToolStripComboBox();
            this.toolStripLabel3 = new System.Windows.Forms.ToolStripLabel();
            this.CB_Data = new System.Windows.Forms.ToolStripComboBox();
            this.toolStripLabel4 = new System.Windows.Forms.ToolStripLabel();
            this.CB_StopBits = new System.Windows.Forms.ToolStripComboBox();
            this.toolStripLabel5 = new System.Windows.Forms.ToolStripLabel();
            this.CB_ParityBits = new System.Windows.Forms.ToolStripComboBox();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.OpenComPortButton = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.Monitor_ON_OFF = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.Rec_ON_OFF = new System.Windows.Forms.ToolStripButton();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.stateMachinInfoUI1 = new CS6257_Monitor.UserUI.StateMachinInfoUI();
            this.errorDispUI1 = new CS6257_Monitor.ErrorDispUI();
            this.controlUI1 = new CS6257_Monitor.ControlUI();
            this.monitorUI1 = new CS6257_Monitor.MonitorUI();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.proMonitorUI1 = new CS6257_Monitor.ProMonitorUI();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.cS6257ParaUI1 = new CS6257_Monitor.CS6257ParaUI();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.commandUI1 = new CS6257_Monitor.CommandUI();
            this.groupBox14 = new System.Windows.Forms.GroupBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.Clear_RxHexData_richtextBox_button = new System.Windows.Forms.Button();
            this.LB_RxHexDatarichText_buf = new System.Windows.Forms.Label();
            this.RxHexData_richtextBox = new System.Windows.Forms.RichTextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.Main_Rx_Data_richText = new System.Windows.Forms.RichTextBox();
            this.LB_Main_Rx_Data_richText_buf = new System.Windows.Forms.Label();
            this.Clear_Rx_Data_richtext_2 = new System.Windows.Forms.Button();
            this.Monitordata_listview = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.D4_button = new System.Windows.Forms.Button();
            this.D3_button = new System.Windows.Forms.Button();
            this.debug_richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.D2_button = new System.Windows.Forms.Button();
            this.D1_button = new System.Windows.Forms.Button();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.LB_NowTime = new System.Windows.Forms.ToolStripStatusLabel();
            this.LB_ComportState = new System.Windows.Forms.ToolStripStatusLabel();
            this.LB_LinkState = new System.Windows.Forms.ToolStripStatusLabel();
            this.LB_WorkState = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripProgressBar1 = new System.Windows.Forms.ToolStripProgressBar();
            this.LB_ProgressValue = new System.Windows.Forms.ToolStripStatusLabel();
            this.LB_ReadWriteState = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStrip1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.groupBox14.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel1.SuspendLayout();
            this.tabPage6.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripLabel1,
            this.CB_COMPortName,
            this.refresh_comport,
            this.toolStripLabel2,
            this.CB_BaudRate,
            this.toolStripLabel3,
            this.CB_Data,
            this.toolStripLabel4,
            this.CB_StopBits,
            this.toolStripLabel5,
            this.CB_ParityBits,
            this.toolStripSeparator1,
            this.OpenComPortButton,
            this.toolStripSeparator2,
            this.Monitor_ON_OFF,
            this.toolStripSeparator4,
            this.Rec_ON_OFF});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(1325, 25);
            this.toolStrip1.TabIndex = 3;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripLabel1
            // 
            this.toolStripLabel1.Name = "toolStripLabel1";
            this.toolStripLabel1.Size = new System.Drawing.Size(63, 22);
            this.toolStripLabel1.Text = "COM Port";
            // 
            // CB_COMPortName
            // 
            this.CB_COMPortName.Name = "CB_COMPortName";
            this.CB_COMPortName.Size = new System.Drawing.Size(121, 25);
            // 
            // refresh_comport
            // 
            this.refresh_comport.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.refresh_comport.Image = global::CS6257_Monitor.Resource1.refresh;
            this.refresh_comport.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.refresh_comport.Name = "refresh_comport";
            this.refresh_comport.Size = new System.Drawing.Size(23, 22);
            this.refresh_comport.Text = "Refresh";
            this.refresh_comport.Click += new System.EventHandler(this.refresh_comport_Click);
            // 
            // toolStripLabel2
            // 
            this.toolStripLabel2.Name = "toolStripLabel2";
            this.toolStripLabel2.Size = new System.Drawing.Size(65, 22);
            this.toolStripLabel2.Text = "Baud Rate";
            // 
            // CB_BaudRate
            // 
            this.CB_BaudRate.Name = "CB_BaudRate";
            this.CB_BaudRate.Size = new System.Drawing.Size(121, 25);
            // 
            // toolStripLabel3
            // 
            this.toolStripLabel3.Name = "toolStripLabel3";
            this.toolStripLabel3.Size = new System.Drawing.Size(34, 22);
            this.toolStripLabel3.Text = "Data";
            // 
            // CB_Data
            // 
            this.CB_Data.Name = "CB_Data";
            this.CB_Data.Size = new System.Drawing.Size(75, 25);
            // 
            // toolStripLabel4
            // 
            this.toolStripLabel4.Name = "toolStripLabel4";
            this.toolStripLabel4.Size = new System.Drawing.Size(56, 22);
            this.toolStripLabel4.Text = "Stop Bits";
            // 
            // CB_StopBits
            // 
            this.CB_StopBits.Name = "CB_StopBits";
            this.CB_StopBits.Size = new System.Drawing.Size(75, 25);
            // 
            // toolStripLabel5
            // 
            this.toolStripLabel5.Name = "toolStripLabel5";
            this.toolStripLabel5.Size = new System.Drawing.Size(60, 22);
            this.toolStripLabel5.Text = "Parity Bits";
            // 
            // CB_ParityBits
            // 
            this.CB_ParityBits.Name = "CB_ParityBits";
            this.CB_ParityBits.Size = new System.Drawing.Size(75, 25);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // OpenComPortButton
            // 
            this.OpenComPortButton.Image = global::CS6257_Monitor.Resource1.red_ball_icon;
            this.OpenComPortButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.OpenComPortButton.Name = "OpenComPortButton";
            this.OpenComPortButton.Size = new System.Drawing.Size(51, 22);
            this.OpenComPortButton.Text = "關閉";
            this.OpenComPortButton.Click += new System.EventHandler(this.OpenComPortButton_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // Monitor_ON_OFF
            // 
            this.Monitor_ON_OFF.Image = global::CS6257_Monitor.Resource1.red_ball_icon;
            this.Monitor_ON_OFF.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.Monitor_ON_OFF.Name = "Monitor_ON_OFF";
            this.Monitor_ON_OFF.Size = new System.Drawing.Size(99, 22);
            this.Monitor_ON_OFF.Text = "Monitor ON ";
            this.Monitor_ON_OFF.Click += new System.EventHandler(this.Monitor_ON_OFF_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(6, 25);
            // 
            // Rec_ON_OFF
            // 
            this.Rec_ON_OFF.Image = global::CS6257_Monitor.Resource1.red_ball_icon;
            this.Rec_ON_OFF.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.Rec_ON_OFF.Name = "Rec_ON_OFF";
            this.Rec_ON_OFF.Size = new System.Drawing.Size(73, 22);
            this.Rec_ON_OFF.Text = "Rec OFF";
            this.Rec_ON_OFF.Visible = false;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Controls.Add(this.tabPage6);
            this.tabControl1.Location = new System.Drawing.Point(0, 28);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1325, 618);
            this.tabControl1.TabIndex = 4;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.panel2);
            this.tabPage1.Controls.Add(this.stateMachinInfoUI1);
            this.tabPage1.Controls.Add(this.errorDispUI1);
            this.tabPage1.Controls.Add(this.controlUI1);
            this.tabPage1.Controls.Add(this.monitorUI1);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1317, 592);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "監控介面";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.pictureBox1);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Location = new System.Drawing.Point(817, 514);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(483, 72);
            this.panel2.TabIndex = 39;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 35);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(149, 12);
            this.label2.TabIndex = 0;
            this.label2.Text = "世紀民生科技股份有限公司";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::CS6257_Monitor.Resource1._1104_22099815000;
            this.pictureBox1.Location = new System.Drawing.Point(243, 8);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(231, 56);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 38;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(85, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "版本資訊 : V1.5";
            // 
            // stateMachinInfoUI1
            // 
            this.stateMachinInfoUI1.Location = new System.Drawing.Point(432, 206);
            this.stateMachinInfoUI1.Name = "stateMachinInfoUI1";
            this.stateMachinInfoUI1.Size = new System.Drawing.Size(376, 380);
            this.stateMachinInfoUI1.TabIndex = 37;
            // 
            // errorDispUI1
            // 
            this.errorDispUI1.Location = new System.Drawing.Point(4, 206);
            this.errorDispUI1.Name = "errorDispUI1";
            this.errorDispUI1.Size = new System.Drawing.Size(435, 380);
            this.errorDispUI1.TabIndex = 36;
            // 
            // controlUI1
            // 
            this.controlUI1.Location = new System.Drawing.Point(814, 212);
            this.controlUI1.Name = "controlUI1";
            this.controlUI1.Size = new System.Drawing.Size(497, 303);
            this.controlUI1.TabIndex = 35;
            // 
            // monitorUI1
            // 
            this.monitorUI1.Location = new System.Drawing.Point(4, 6);
            this.monitorUI1.Name = "monitorUI1";
            this.monitorUI1.Size = new System.Drawing.Size(1313, 200);
            this.monitorUI1.TabIndex = 34;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.proMonitorUI1);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1317, 592);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "詳細監控介面";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // proMonitorUI1
            // 
            this.proMonitorUI1.Location = new System.Drawing.Point(3, 3);
            this.proMonitorUI1.Name = "proMonitorUI1";
            this.proMonitorUI1.Size = new System.Drawing.Size(1260, 583);
            this.proMonitorUI1.TabIndex = 0;
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.cS6257ParaUI1);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(1317, 592);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "工程用系統參數列表";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // cS6257ParaUI1
            // 
            this.cS6257ParaUI1.Location = new System.Drawing.Point(6, 3);
            this.cS6257ParaUI1.Name = "cS6257ParaUI1";
            this.cS6257ParaUI1.Size = new System.Drawing.Size(1180, 586);
            this.cS6257ParaUI1.TabIndex = 37;
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.commandUI1);
            this.tabPage5.Controls.Add(this.groupBox14);
            this.tabPage5.Controls.Add(this.Monitordata_listview);
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(1317, 592);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "工程監控介面";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // commandUI1
            // 
            this.commandUI1.Location = new System.Drawing.Point(576, 3);
            this.commandUI1.Name = "commandUI1";
            this.commandUI1.Size = new System.Drawing.Size(347, 583);
            this.commandUI1.TabIndex = 6;
            // 
            // groupBox14
            // 
            this.groupBox14.Controls.Add(this.panel5);
            this.groupBox14.Controls.Add(this.panel1);
            this.groupBox14.Location = new System.Drawing.Point(9, 11);
            this.groupBox14.Name = "groupBox14";
            this.groupBox14.Size = new System.Drawing.Size(561, 573);
            this.groupBox14.TabIndex = 5;
            this.groupBox14.TabStop = false;
            this.groupBox14.Text = "接收資料";
            // 
            // panel5
            // 
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel5.Controls.Add(this.Clear_RxHexData_richtextBox_button);
            this.panel5.Controls.Add(this.LB_RxHexDatarichText_buf);
            this.panel5.Controls.Add(this.RxHexData_richtextBox);
            this.panel5.Location = new System.Drawing.Point(7, 326);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(545, 241);
            this.panel5.TabIndex = 5;
            // 
            // Clear_RxHexData_richtextBox_button
            // 
            this.Clear_RxHexData_richtextBox_button.Location = new System.Drawing.Point(460, 5);
            this.Clear_RxHexData_richtextBox_button.Name = "Clear_RxHexData_richtextBox_button";
            this.Clear_RxHexData_richtextBox_button.Size = new System.Drawing.Size(75, 23);
            this.Clear_RxHexData_richtextBox_button.TabIndex = 2;
            this.Clear_RxHexData_richtextBox_button.Text = "Clear";
            this.Clear_RxHexData_richtextBox_button.UseVisualStyleBackColor = true;
            this.Clear_RxHexData_richtextBox_button.Click += new System.EventHandler(this.Clear_RxHexData_richtextBox_button_Click);
            // 
            // LB_RxHexDatarichText_buf
            // 
            this.LB_RxHexDatarichText_buf.AutoSize = true;
            this.LB_RxHexDatarichText_buf.Location = new System.Drawing.Point(332, 10);
            this.LB_RxHexDatarichText_buf.Name = "LB_RxHexDatarichText_buf";
            this.LB_RxHexDatarichText_buf.Size = new System.Drawing.Size(83, 12);
            this.LB_RxHexDatarichText_buf.TabIndex = 3;
            this.LB_RxHexDatarichText_buf.Text = "資料緩衝區 :  0";
            // 
            // RxHexData_richtextBox
            // 
            this.RxHexData_richtextBox.Location = new System.Drawing.Point(10, 34);
            this.RxHexData_richtextBox.Name = "RxHexData_richtextBox";
            this.RxHexData_richtextBox.Size = new System.Drawing.Size(525, 196);
            this.RxHexData_richtextBox.TabIndex = 1;
            this.RxHexData_richtextBox.Text = "";
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.Main_Rx_Data_richText);
            this.panel1.Controls.Add(this.LB_Main_Rx_Data_richText_buf);
            this.panel1.Controls.Add(this.Clear_Rx_Data_richtext_2);
            this.panel1.Location = new System.Drawing.Point(6, 21);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(546, 299);
            this.panel1.TabIndex = 4;
            // 
            // Main_Rx_Data_richText
            // 
            this.Main_Rx_Data_richText.Location = new System.Drawing.Point(10, 34);
            this.Main_Rx_Data_richText.Name = "Main_Rx_Data_richText";
            this.Main_Rx_Data_richText.Size = new System.Drawing.Size(526, 260);
            this.Main_Rx_Data_richText.TabIndex = 2;
            this.Main_Rx_Data_richText.Text = "";
            // 
            // LB_Main_Rx_Data_richText_buf
            // 
            this.LB_Main_Rx_Data_richText_buf.AutoSize = true;
            this.LB_Main_Rx_Data_richText_buf.Location = new System.Drawing.Point(333, 10);
            this.LB_Main_Rx_Data_richText_buf.Name = "LB_Main_Rx_Data_richText_buf";
            this.LB_Main_Rx_Data_richText_buf.Size = new System.Drawing.Size(122, 12);
            this.LB_Main_Rx_Data_richText_buf.TabIndex = 3;
            this.LB_Main_Rx_Data_richText_buf.Text = "資料緩衝區 : 00000000";
            // 
            // Clear_Rx_Data_richtext_2
            // 
            this.Clear_Rx_Data_richtext_2.Location = new System.Drawing.Point(461, 5);
            this.Clear_Rx_Data_richtext_2.Name = "Clear_Rx_Data_richtext_2";
            this.Clear_Rx_Data_richtext_2.Size = new System.Drawing.Size(75, 23);
            this.Clear_Rx_Data_richtext_2.TabIndex = 1;
            this.Clear_Rx_Data_richtext_2.Text = "Clear";
            this.Clear_Rx_Data_richtext_2.UseVisualStyleBackColor = true;
            this.Clear_Rx_Data_richtext_2.Click += new System.EventHandler(this.Clear_Rx_Data_richtext_2_Click);
            // 
            // Monitordata_listview
            // 
            this.Monitordata_listview.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3});
            this.Monitordata_listview.GridLines = true;
            this.Monitordata_listview.Location = new System.Drawing.Point(923, 6);
            this.Monitordata_listview.Name = "Monitordata_listview";
            this.Monitordata_listview.Size = new System.Drawing.Size(382, 578);
            this.Monitordata_listview.TabIndex = 3;
            this.Monitordata_listview.UseCompatibleStateImageBehavior = false;
            this.Monitordata_listview.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "No.";
            this.columnHeader1.Width = 45;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Value";
            this.columnHeader2.Width = 120;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Comment";
            this.columnHeader3.Width = 150;
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.groupBox2);
            this.tabPage6.Location = new System.Drawing.Point(4, 22);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage6.Size = new System.Drawing.Size(1317, 592);
            this.tabPage6.TabIndex = 5;
            this.tabPage6.Text = "DEBUG";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.D4_button);
            this.groupBox2.Controls.Add(this.D3_button);
            this.groupBox2.Controls.Add(this.debug_richTextBox1);
            this.groupBox2.Controls.Add(this.D2_button);
            this.groupBox2.Controls.Add(this.D1_button);
            this.groupBox2.Location = new System.Drawing.Point(8, 6);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(594, 580);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "DEBUG";
            // 
            // D4_button
            // 
            this.D4_button.Location = new System.Drawing.Point(469, 491);
            this.D4_button.Name = "D4_button";
            this.D4_button.Size = new System.Drawing.Size(88, 83);
            this.D4_button.TabIndex = 3;
            this.D4_button.Text = "D4";
            this.D4_button.UseVisualStyleBackColor = true;
            this.D4_button.Click += new System.EventHandler(this.D4_button_Click);
            // 
            // D3_button
            // 
            this.D3_button.Location = new System.Drawing.Point(374, 491);
            this.D3_button.Name = "D3_button";
            this.D3_button.Size = new System.Drawing.Size(88, 83);
            this.D3_button.TabIndex = 2;
            this.D3_button.Text = "D3";
            this.D3_button.UseVisualStyleBackColor = true;
            this.D3_button.Click += new System.EventHandler(this.D3_button_Click);
            // 
            // debug_richTextBox1
            // 
            this.debug_richTextBox1.Location = new System.Drawing.Point(6, 21);
            this.debug_richTextBox1.Name = "debug_richTextBox1";
            this.debug_richTextBox1.Size = new System.Drawing.Size(578, 388);
            this.debug_richTextBox1.TabIndex = 1;
            this.debug_richTextBox1.Text = "";
            // 
            // D2_button
            // 
            this.D2_button.Location = new System.Drawing.Point(280, 491);
            this.D2_button.Name = "D2_button";
            this.D2_button.Size = new System.Drawing.Size(88, 83);
            this.D2_button.TabIndex = 0;
            this.D2_button.Text = "D2";
            this.D2_button.UseVisualStyleBackColor = true;
            this.D2_button.Click += new System.EventHandler(this.D2_button_Click);
            // 
            // D1_button
            // 
            this.D1_button.Location = new System.Drawing.Point(186, 491);
            this.D1_button.Name = "D1_button";
            this.D1_button.Size = new System.Drawing.Size(88, 83);
            this.D1_button.TabIndex = 0;
            this.D1_button.Text = "D1";
            this.D1_button.UseVisualStyleBackColor = true;
            this.D1_button.Click += new System.EventHandler(this.D1_button_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.LB_NowTime,
            this.LB_ComportState,
            this.LB_LinkState,
            this.LB_WorkState,
            this.toolStripProgressBar1,
            this.LB_ProgressValue,
            this.LB_ReadWriteState});
            this.statusStrip1.Location = new System.Drawing.Point(0, 649);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(1325, 22);
            this.statusStrip1.TabIndex = 5;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // LB_NowTime
            // 
            this.LB_NowTime.Name = "LB_NowTime";
            this.LB_NowTime.Size = new System.Drawing.Size(80, 17);
            this.LB_NowTime.Text = "LB_NowTime";
            // 
            // LB_ComportState
            // 
            this.LB_ComportState.Name = "LB_ComportState";
            this.LB_ComportState.Size = new System.Drawing.Size(100, 17);
            this.LB_ComportState.Text = "COM Port Status";
            // 
            // LB_LinkState
            // 
            this.LB_LinkState.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.LB_LinkState.Image = global::CS6257_Monitor.Resource1.green_ball_icon;
            this.LB_LinkState.Name = "LB_LinkState";
            this.LB_LinkState.Size = new System.Drawing.Size(74, 17);
            this.LB_LinkState.Text = "LINK_STATE";
            // 
            // LB_WorkState
            // 
            this.LB_WorkState.Name = "LB_WorkState";
            this.LB_WorkState.Size = new System.Drawing.Size(66, 17);
            this.LB_WorkState.Text = "WorkState";
            this.LB_WorkState.Visible = false;
            // 
            // toolStripProgressBar1
            // 
            this.toolStripProgressBar1.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.toolStripProgressBar1.Name = "toolStripProgressBar1";
            this.toolStripProgressBar1.Size = new System.Drawing.Size(100, 16);
            this.toolStripProgressBar1.Step = 1;
            this.toolStripProgressBar1.Visible = false;
            // 
            // LB_ProgressValue
            // 
            this.LB_ProgressValue.Name = "LB_ProgressValue";
            this.LB_ProgressValue.Size = new System.Drawing.Size(89, 17);
            this.LB_ProgressValue.Text = "progress value";
            this.LB_ProgressValue.Visible = false;
            // 
            // LB_ReadWriteState
            // 
            this.LB_ReadWriteState.Name = "LB_ReadWriteState";
            this.LB_ReadWriteState.Size = new System.Drawing.Size(96, 17);
            this.LB_ReadWriteState.Text = "ReadWriteState";
            this.LB_ReadWriteState.Visible = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1325, 671);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.toolStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.Text = "MYSON 變頻空調監控程式 v1.6";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form1_FormClosed);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage4.ResumeLayout(false);
            this.tabPage5.ResumeLayout(false);
            this.groupBox14.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.tabPage6.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripLabel toolStripLabel1;
        private System.Windows.Forms.ToolStripComboBox CB_COMPortName;
        private System.Windows.Forms.ToolStripButton refresh_comport;
        private System.Windows.Forms.ToolStripLabel toolStripLabel2;
        private System.Windows.Forms.ToolStripComboBox CB_BaudRate;
        private System.Windows.Forms.ToolStripLabel toolStripLabel3;
        private System.Windows.Forms.ToolStripComboBox CB_Data;
        private System.Windows.Forms.ToolStripLabel toolStripLabel4;
        private System.Windows.Forms.ToolStripComboBox CB_StopBits;
        private System.Windows.Forms.ToolStripLabel toolStripLabel5;
        private System.Windows.Forms.ToolStripComboBox CB_ParityBits;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton OpenComPortButton;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripButton Monitor_ON_OFF;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripButton Rec_ON_OFF;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel LB_NowTime;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.Label LB_RxHexDatarichText_buf;
        private System.Windows.Forms.Button Clear_RxHexData_richtextBox_button;
        private System.Windows.Forms.RichTextBox RxHexData_richtextBox;
        private System.Windows.Forms.ListView Monitordata_listview;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ToolStripStatusLabel LB_ComportState;
        private System.Windows.Forms.ToolStripStatusLabel LB_WorkState;
        private System.Windows.Forms.ToolStripProgressBar toolStripProgressBar1;
        private System.Windows.Forms.ToolStripStatusLabel LB_ProgressValue;
        private System.Windows.Forms.ToolStripStatusLabel LB_ReadWriteState;
        private System.Windows.Forms.GroupBox groupBox14;
        private System.Windows.Forms.Label LB_Main_Rx_Data_richText_buf;
        private System.Windows.Forms.RichTextBox Main_Rx_Data_richText;
        private System.Windows.Forms.Button Clear_Rx_Data_richtext_2;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button D2_button;
        private System.Windows.Forms.Button D1_button;
        private MonitorUI monitorUI1;
        private ControlUI controlUI1;
        private CS6257ParaUI cS6257ParaUI1;
        private ErrorDispUI errorDispUI1;
        private CommandUI commandUI1;
        private System.Windows.Forms.RichTextBox debug_richTextBox1;
        private System.Windows.Forms.Button D3_button;
        private System.Windows.Forms.ToolStripStatusLabel LB_LinkState;
        private System.Windows.Forms.Button D4_button;
        private ProMonitorUI proMonitorUI1;
        private UserUI.StateMachinInfoUI stateMachinInfoUI1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
    }
}


﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Threading;

namespace CS6257_Monitor
{
    public partial class Form1 : Form
    {
        private struct SYS_FLAG
        {
            public bool MonitorState;
        }

        SYS_FLAG SysFlag;

        /// <summary>
        /// 
        /// </summary>
        private void Init_SysConfig()
        {
            SysFlag.MonitorState = false;

            // UI 初始化
            controlUI1.Init_ControlUI(bc);
            commandUI1.Init_CommandUI(bc);
            errorDispUI1.Init_ErrorDispUI(bc);
            cS6257ParaUI1.Init_CS6257ParaUI(bc);
            proMonitorUI1.Init_ProMonitorUI(bc);
            stateMachinInfoUI1.Init_StateMachinInfoUI(bc);
        }


        private void Set_Monitor_ON_OFF()
        {
            if (SysFlag.MonitorState)
            {
                SysFlag.MonitorState = false;
                //bc.SciFlag.ReqMonitorData = false;      // ??
                bc.pcState.MonitorState = TransControl.MONITOR_STATE.OFF;
                this.Set_Button_Monitor_ON_OFF(false);
            }
            else
            {
                SysFlag.MonitorState = true;
                //bc.SciFlag.ReqMonitorData = true;       // ??
                bc.pcState.MonitorState = TransControl.MONITOR_STATE.ON;
                this.Set_Button_Monitor_ON_OFF(true);
            }
        }

        /// <summary>
        /// 設定 Monitor功能開啟 / 關閉
        /// </summary>
        /// <param name="value"></param>
        private void Set_Button_Monitor_ON_OFF(bool value)
        {
            if (value)
            {
                // 開啟
                this.Monitor_ON_OFF.Text = "Monitor ON ";
                this.Monitor_ON_OFF.Image = Resource1.green_ball_icon;          
            }
            else
            {
                // 關閉
                this.Monitor_ON_OFF.Text = "Monitor OFF";
                this.Monitor_ON_OFF.Image = Resource1.red_ball_icon;
            }
        }
    }
}

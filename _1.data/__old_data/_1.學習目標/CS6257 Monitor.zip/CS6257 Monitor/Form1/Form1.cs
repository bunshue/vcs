﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Threading;

namespace CS6257_Monitor
{
    public partial class Form1 : Form
    {
        /// <summary>
        /// 主視窗初始化
        /// </summary>
        public Form1()
        {
            InitializeComponent();
        }

        // 繪圖視窗
        GraphForm graphform;
        // 參數更新視窗
        ConfigParaForm configparaform;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Form1_Load(object sender, EventArgs e)
        {
            // 初始化系統設定
            Init_SysConfig();

            // 初始化MonitorListView內容
            Init_MonitorListView(this.Monitordata_listview);

            // 初始化 COM Port 設定
            Init_COMPort_Config();

            Set_Monitor_ON_OFF();
            
            // 初始化視窗更新設定，建立新執行緒
            Init_Update_Form();
         
        }

        /// <summary>
        /// 主視窗關閉時執行
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            
        }

        #region 功能開關 toolStrip

        /// <summary>
        /// 按下後開啟/關閉 COM Port
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void OpenComPortButton_Click(object sender, EventArgs e)
        {
            Open_Close_ComPort();
        }

        /// <summary>
        /// 更新可用的COM Port
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void refresh_comport_Click(object sender, EventArgs e)
        {
            Refresh_COMPort();
        }

        /// <summary>
        /// Monitor 資料 傳送/接收 功能開啟/關閉
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Monitor_ON_OFF_Click(object sender, EventArgs e)
        {
            Set_Monitor_ON_OFF();
        }

        #endregion

        #region 工程介面 Engineering Mode
        /// <summary>
        /// 清除接收RichTextBox中的所有內容
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Clear_Rx_Data_richtext_2_Click(object sender, EventArgs e)
        {
            this.Main_Rx_Data_richText.Clear();
        }

        /// <summary>
        /// 清除接收 Hex RichTextBox中的所有內容
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Clear_RxHexData_richtextBox_button_Click(object sender, EventArgs e)
        {
            this.RxHexData_richtextBox.Clear();
        }

        // 工程模式

        #region Monitor 資料顯示

        /// <summary>
        /// 初始化 MonitorListView 內容
        /// </summary>
        /// <param name="listview"></param>
        private void Init_MonitorListView(ListView listview)
        {
            ListViewItem item;
            string[] info = new string[2];
            listview.Items.Clear();
            for (int ii = 0; ii < 150; ii++)
            {
                info[0] = ii.ToString();
                info[1] = String.Format("{0}", bc.SciBuf.RxBuff[ii]);
                item = new ListViewItem(info);
                listview.Items.Add(item);
            }
        }

        /// <summary>
        /// 更新 MonitorListView 內容
        /// </summary>
        /// <param name="listview"></param>
        private void UpdateMonitorListView(ListView listview)
        {
            string[] info = new string[2];
            for (int ii = 0; ii < 150; ii++)
            {
                info[1] = String.Format("{0}", bc.SciBuf.RxBuff[ii]);
                listview.Items[ii].SubItems[1].Text = info[1];
            }
        }

        #endregion

        #endregion

        #region DEBUG

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void D1_button_Click(object sender, EventArgs e)
        {
            //Debug1();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void D2_button_Click(object sender, EventArgs e)
        {
            //Debug2();
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void D3_button_Click(object sender, EventArgs e)
        {
            if (configparaform == null)
            {
                configparaform = new ConfigParaForm(this.cS6257ParaUI1);
            }
            else if (configparaform.IsDisposed)
            {
                configparaform = new ConfigParaForm(this.cS6257ParaUI1);
            }
            configparaform.Show();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void D4_button_Click(object sender, EventArgs e)
        {
            try
            {
                graphform.Show();
            }
            catch(Exception ex)
            {
                this.debug_richTextBox1.AppendText(ex.ToString());
                graphform = new GraphForm(bc);
                graphform.Show();
            }
            
        }

        #endregion
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Threading;

namespace CS6257_Monitor
{
    public partial class Form1 : Form
    {
        private delegate void Delegate_UpdateWindowsForm();
        private Delegate_UpdateWindowsForm D_UpdateWindowsForm;

        private Thread Update_Form_thread;      // 視窗更新執行緒

        private TransControl bc = new TransControl();

        private int update_delay_cnt_100ms = 0;
        private int update_delay_cnt_1sec = 0;

        /// <summary>
        /// 初始化視窗更新設定
        /// </summary>
        private void Init_Update_Form()
        {
            // 初始委派函式
            D_UpdateWindowsForm = new Delegate_UpdateWindowsForm(UpdateWindowsForm_Method);
            // 建立視窗更新執行緒
            Update_Form_thread = new Thread(new ThreadStart(UpdateWindowsForm_DoWork));
            Update_Form_thread.IsBackground = true;
            Update_Form_thread.Start();
        }

        /// <summary>
        /// 視窗更新方法
        /// </summary>
        private void UpdateWindowsForm_Method()
        {
            // 顯示 COM Port 狀態
            Update_ComPortStatus();
            // 更新顯示時間
            this.LB_NowTime.Text = DateTime.Now.ToString();
            //
            if (bc.pcState.ComState == TransControl.COM_STATE.DISCONNECTED)
            {
                this.LB_LinkState.ForeColor = Color.Red;
                this.LB_LinkState.Text = "DISCONNECTED ";
            }
            else if (bc.pcState.ComState == TransControl.COM_STATE.ESTABLISHED)
            {
                this.LB_LinkState.ForeColor = Color.Green;
                this.LB_LinkState.Text = "ESTABLISHED";
            }

            // 進度條更新
            Update_ProgressBar();

            // 延遲 100 ms
            if (++update_delay_cnt_100ms > 10)
            {
                update_delay_cnt_100ms = 0;
                //
                cS6257ParaUI1.UpdateUI();
                errorDispUI1.UpdateUI();
                proMonitorUI1.UpdateUI();
                stateMachinInfoUI1.UpdateUI();
                Update_RichTextBox();
                //
                Disp_RichTextBuffSize(this.LB_Main_Rx_Data_richText_buf, this.Main_Rx_Data_richText);
                Disp_RichTextBuffSize(this.LB_RxHexDatarichText_buf, this.RxHexData_richtextBox);
                //
                bc.UpdateMonitorData();
                this.monitorUI1.UpdateMonitorUI(bc.Monitor_Data);
            }

            // 延遲 1 秒
            if (++update_delay_cnt_1sec > 100)
            {
                //
                update_delay_cnt_1sec = 0;
                // 更新 MonitorListView 內容
                UpdateMonitorListView(this.Monitordata_listview);
                //
            }
        }

        /// <summary>
        /// 執行視窗更新工作
        /// </summary>
        private void UpdateWindowsForm_DoWork()
        {
            while(true)
            {
                this.Invoke(D_UpdateWindowsForm);
                Thread.Sleep(10);
            }
        }

        /// <summary>
        /// 顯示 COM Port 狀態
        /// </summary>
        private void Update_ComPortStatus()
        {
            if (comport.IsComPortOpen() == true)
            {
                this.LB_ComportState.Text = this.CB_COMPortName.Text + " OPEN";
                this.LB_ComportState.ForeColor = Color.DarkGreen;
            }
            else
            {
                this.LB_ComportState.Text = "COM CLOSE";
                this.LB_ComportState.ForeColor = Color.Red;
            }
        }

        /// <summary>
        /// 更新 RichTextBox
        /// </summary>
        private void Update_RichTextBox()
        {
            if (bc.receive_str != string.Empty)
            {
                this.Main_Rx_Data_richText.AppendText(bc.receive_str);
                this.Main_Rx_Data_richText.ScrollToCaret();
                bc.receive_str = string.Empty;
            }
            if (bc.receive_hex_str != string.Empty)
            {
                this.RxHexData_richtextBox.AppendText(bc.receive_hex_str + "\n");
                this.RxHexData_richtextBox.ScrollToCaret();
                bc.receive_hex_str = string.Empty;
            }
            if (this.RxHexData_richtextBox.TextLength > 100000)
            {
                this.RxHexData_richtextBox.Clear();
            }
        }

        /// <summary>
        /// 顯示 richtextbox資料緩衝區大小
        /// </summary>
        private void Disp_RichTextBuffSize(Label label, RichTextBox textbox)
        {
            string str_temp = string.Empty;
            str_temp = textbox.TextLength.ToString();
            label.Text = "資料緩衝區 : " + str_temp;
        }

        /// <summary>
        /// 進度條更新
        /// 說明 : 當資料傳送/接收時顯示進度條
        /// </summary>
        private void Update_ProgressBar()
        {
            // 
            if (bc.progress != 0)
            {
                this.toolStripProgressBar1.Visible = true;
                this.toolStripProgressBar1.Value = bc.progress;
                this.LB_WorkState.Visible = true;
                this.LB_ProgressValue.Visible = true;
                this.LB_ProgressValue.Text = bc.progress.ToString();

                if (bc.SciState.mode == Communication.WORKING_MODE.GET_PARAM ||
                    bc.SciState.mode == Communication.WORKING_MODE.GET_MT_PARAM ||
                    bc.SciState.mode == Communication.WORKING_MODE.GET_ST_PARAM)
                {
                    this.LB_WorkState.Text = "資料取得中";
                    this.LB_ReadWriteState.Visible = false;
                }
                else if (bc.SciState.mode == Communication.WORKING_MODE.SEND_PARAM ||
                    bc.SciState.mode == Communication.WORKING_MODE.SEND_MT_PARAM ||
                    bc.SciState.mode == Communication.WORKING_MODE.SEND_ST_PARAM)
                {
                    this.LB_WorkState.Text = "資料發送中";
                    this.LB_ReadWriteState.Visible = false;
                }
            }
            else
            {
                this.toolStripProgressBar1.Visible = false;
                this.LB_WorkState.Visible = false;
                this.LB_ProgressValue.Visible = false;
            }
        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;


namespace CS6257_Monitor
{
    public partial class Communication
    {
        /// <summary>
        /// SYN Request
        /// </summary>
        public bool SendSYN()
        {
            if (comport.IsComPortOpen())
            {
                Thread.Sleep(50);
                byte[] b = new byte[10];
                b[0] = 0xAB;
                b[1] = 0x01;
                b[2] = 0xCC;
                b[3] = 0x00;
                b[4] = 0x00;
                b[5] = 0x00;
                b[6] = 0x00;
                b[7] = 0x00;
                b[9] = 0x00;
                b[9] = CalcCheckSum(b, 9);
                comport.SendByte(b);
                Thread.Sleep(100);
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// 請求回覆馬達參數校驗狀態
        /// </summary>
        /// <returns></returns>
        public bool ReqMotorParaChkState()
        {
            return true;
        }

        /// <summary>
        /// 請求回覆溫控邏輯參數校驗狀態
        /// </summary>
        /// <returns></returns>
        public bool ReqStateMachineParaChkState()
        {
            return true;
        }

        /// <summary>
        /// 請求回覆馬達參數更新狀態
        /// </summary>
        /// <returns></returns>
        public bool ReqMotorParaUpdState()
        {
            return true;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace CS6257_Monitor
{
    public partial class Communication
    {
        public enum WORKING_MODE 
        {   MONITOR,
            GET_PARAM,
            GET_MT_PARAM,
            GET_ST_PARAM,
            SEND_PARAM,
            SEND_MT_PARAM,
            SEND_ST_PARAM,
            SYS, DEFAULT 
        }

        // 傳輸狀態
        public struct SCI_STATE
        {
            public WORKING_MODE mode;   // 傳輸模式
        }

        public SCI_STATE SciState;      

        public struct SCI_Flag
        {
            public bool ReqMonitorData;          // 發送請求監控資料
            public bool SendSimData;
            public bool UpdateListView;
        }

        public struct SCI_BUF
        {
            public byte[] TxBuff;
            public byte[] RxBuff;
            public byte[] RxBuff2;
            public byte[] MsgBuf;
        }

        public struct DATA_BUF
        {
            public bool Param_Updated;
            public byte[] Param_Data_Buf;
            public byte[] RecordDisp_Buf;
            public byte[] SIM_Data_Buf;
        }

        Thread receive_thread;          // 接收執行緒
        Thread send_thread;             // 傳送執行緒

        ComPort comport = new ComPort();
        Protocol protocol = new Protocol();

        public SCI_Flag SciFlag;
        public SCI_BUF SciBuf;
        public DATA_BUF DataBuf;

        public string receive_hex_str = string.Empty;
        public string receive_str = string.Empty;

        private byte dataNum = 0x00;            // 數據代碼
        private byte simdataNum = 0x00;         // 模擬資料數據代碼

        public int progress = 0;                // 傳送/接收進度

        /// <summary>
        /// 建構函式
        /// </summary>
        public Communication()
        {
            // 參數初始化
            SciFlag.ReqMonitorData = false;
            SciFlag.SendSimData = false;
            SciFlag.UpdateListView = false;
            //
            Init_ParamTransState();
            Init_ParamTable();
            //
            SciBuf.TxBuff = new byte[10];
            SciBuf.RxBuff = new byte[protocol.qRecvMonitor.buf.Length];
            SciBuf.RxBuff2 = new byte[protocol.qRecvMonitor2.buf.Length];
            SciBuf.MsgBuf = new byte[protocol.QMsg.Buf.Length];
            //
            DataBuf.Param_Data_Buf = new byte[protocol.qRecvParam.buf.Length];
            DataBuf.RecordDisp_Buf = new byte[protocol.qRecvRecordDisp.buf.Length];
            DataBuf.SIM_Data_Buf = new byte[5120];
            // 建立傳送/接收執行緒
            receive_thread = new Thread(new ThreadStart(Receive_DoWork));
            send_thread = new Thread(new ThreadStart(Send_DoWork));
            receive_thread.Name = "Receive Thread";
            receive_thread.IsBackground = true;
            send_thread.Name = "Send Thread";
            send_thread.IsBackground = true;
            receive_thread.Start();
            send_thread.Start();
        }

        /// <summary>
        /// 取得COM Port 開啟狀態
        /// </summary>
        /// <returns></returns>
        public bool IsComPortOpen()
        {
            return comport.IsComPortOpen();
        }

        /// <summary>
        /// 取得COM Port 物件
        /// </summary>
        /// <returns></returns>
        public ComPort GetComPortObj()
        {
            return comport;
        }

        #region 傳送/接收 Send / Receive
        /// <summary>
        /// 接收資料處理
        /// </summary>
        private void Receive_DoWork()
        {
            byte[] data;
            while (true)
            {
                if (comport.IsComPortOpen() == true)
                {
                    if (comport.BytesToRead > 0)
                    {
                        data = comport.GetReceiveData();
                        receive_str += protocol.GetSpyData(data, data.Length);
                        receive_hex_str += GetHexData(data);
                    }
                }
                Thread.Sleep(2);
            }
        }

        /// <summary>
        /// 傳送資料處理
        /// </summary>
        private void Send_DoWork()
        {
            while (true)
            {
                if (comport.IsComPortOpen() == true)
                {
                    switch (SciState.mode)
                    {
                        case WORKING_MODE.MONITOR:
                            ReqMonitorData();
                            if (SciFlag.ReqMonitorData == false)
                                SciState.mode = WORKING_MODE.DEFAULT;
                            break;

                        case WORKING_MODE.GET_PARAM:
                            Get_ParamFromMCU_Work();
                            SciState.mode = WORKING_MODE.DEFAULT;
                            CheckRecvParamCheckSum();         // 檢查接收的資料CheckSum是否正確
                            Update_ParamDB();         // JM
                            break;

                        case WORKING_MODE.GET_MT_PARAM:
                            Console.WriteLine("Get Motor Parameter...");
                            Get_Motor_ParamFromMCU_Work();
                            SciState.mode = WORKING_MODE.DEFAULT;
                            CheckRecvMotorParamCheckSum();           // 檢查接收的馬達參數資料CheckSum是否正確
                            Update_ParamDB();         // JM
                            break;

                        case WORKING_MODE.GET_ST_PARAM:
                            Get_StateMachine_ParamFromMCU_Work();
                            SciState.mode = WORKING_MODE.DEFAULT;
                            CheckRecvStateMachineParamCheckSum();     // 檢查接收的溫控邏輯參數資料CheckSum是否正確
                            Update_ParamDB();         // JM
                            break;

                        case WORKING_MODE.SEND_PARAM:
                            Send_ParamToMCU_Work();
                            SciState.mode = WORKING_MODE.DEFAULT;
                            break;

                        case WORKING_MODE.SEND_MT_PARAM:
                            Console.WriteLine("Send Motor Parameter...");
                            Send_Motor_ParamToMCU_Work();
                            SciState.mode = WORKING_MODE.DEFAULT;
                            break;

                        case WORKING_MODE.SEND_ST_PARAM:
                            Send_StateMachine_ParamToMCU_Work();
                            SciState.mode = WORKING_MODE.DEFAULT;
                            break;

                        case WORKING_MODE.DEFAULT:
                            //
                            if (SciFlag.ReqMonitorData)
                            {
                                SciState.mode = WORKING_MODE.MONITOR;
                            }
                            else
                            {
                                SciState.mode = WORKING_MODE.DEFAULT;
                            }
                            Thread.Sleep(10);
                            break;
                    }
                }
                else
                {
                    SciState.mode = WORKING_MODE.DEFAULT;
                    Thread.Sleep(10);
                }
            }
        }
        #endregion

        /// <summary>
        /// 取得監控資料
        /// </summary>
        private void ReqMonitorData()
        {
            byte[] b = new byte[10];
            if (++dataNum > 12) dataNum = 0;
            b[0] = 0xAA;
            b[1] = 0x10;
            b[2] = dataNum;
            b[9] = CalcCheckSum(b, 9);
            comport.SendByte(b);
            Thread.Sleep(200);
        }

        #region 基礎函式 Basic Function

        /// <summary>
        /// 取得校驗碼
        /// </summary>
        /// <param name="pData"></param>
        /// <param name="len"></param>
        /// <returns></returns>
        private byte CalcCheckSum(byte[] pData, int len)
        {
            byte sum = 0x00;
            short ii = 0;
            for (ii = 0; ii < len; ii++)
            {
                sum += pData[ii];
            }
            sum = (byte)((sum ^ 0xFF) + 1);
            return sum;
        }

        /// <summary>
        /// 取得16進制字串表示
        /// </summary>
        public string GetHexData(byte[] data)
        {
            string str_hexdata = string.Empty;
            for (int ii = 0; ii < data.Length; ii++)
            {
                if (data[ii] < 0x10)
                {
                    str_hexdata += "0" + String.Format("{0:X}", data[ii]) + " ";
                }
                else
                {
                    str_hexdata += String.Format("{0:X}", data[ii]) + " ";
                    //str_hexdata += Convert.ToString(data[ii], 16);
                }
            }

            str_hexdata += "\n";
            return str_hexdata;
        }

        #region 暫存器操作 Copy / Clear Buffer

        /// <summary>
        /// 複製接收暫存資料至RxBuff
        /// </summary>
        public void CopyRxBuff()
        {
            for (int ii = 0; ii < SciBuf.RxBuff.Length; ii++)
            {
                SciBuf.RxBuff[ii] = protocol.qRecvMonitor.buf[ii];
            }
        }

        /// <summary>
        /// 複製接收暫存資料至RxBuff2
        /// </summary>
        public void CopyRxBuff2()
        {
            for (int ii = 0; ii < SciBuf.RxBuff2.Length; ii++)
            {
                SciBuf.RxBuff2[ii] = protocol.qRecvMonitor2.buf[ii];
            }
        }

        /// <summary>
        /// 複製接收暫存資料至Param_Data_Buf
        /// </summary>
        public void CopyParamDataBuf()
        {
            for (int ii = 0; ii < DataBuf.Param_Data_Buf.Length; ii++)
            {
                //Eflash_Data_Buff[ii] = protocol.qParameflash.buf[ii];
                DataBuf.Param_Data_Buf[ii] = protocol.qRecvParam.buf[ii];
            }
        }

        /// <summary>
        /// 讀取 RealTime Disp Buff的值
        /// </summary>
        /// <returns></returns>
        public byte[] ReadRealTimeDispBuf()
        {
            byte[] b = null;

            while (true)
            {
                if (protocol.RealTimeBuf.Empty == true)
                {
                    break;
                }
                else if (protocol.RealTimeBuf.Busy == false)
                {
                    protocol.RealTimeBuf.Read = true;

                    b = new byte[protocol.RealTimeBuf.pCnt * 6];

                    //for (int cnt = 0; cnt < protocol.RealTimeBuf.pCnt - 1; cnt++)
                    //{
                    //    for (int ii = 0; ii < 6; ii++)
                    //    {
                    //        b[cnt * 6 + ii] = protocol.RealTimeBuf.buf[cnt * 6 + ii];
                    //    }
                    //}
                    for (int ii = 0; ii < b.Length; ii++)
                    {
                        b[ii] = protocol.RealTimeBuf.buf[ii];
                    }
                    
                    protocol.RealTimeBuf.pCnt = 0;

                    break;
                }
                Thread.Sleep(1);    // wait
            }

            protocol.RealTimeBuf.Read = false;

            return b;
        }

        /// <summary>
        /// 清除qRecvParam暫存器數值
        /// </summary>
        private void ClearRecvParam()
        {
            protocol.ClearqRecvParam();
        }

        /// <summary>
        /// 複製記錄暫存資料至 Record_Data_Buf
        /// </summary>
        public void CopyRecordDispBuf()
        {
            for (int ii = 0; ii < DataBuf.RecordDisp_Buf.Length; ii++)
            {
                DataBuf.RecordDisp_Buf[ii] = protocol.qRecvRecordDisp.buf[ii];
            }
        }

        /// <summary>
        /// 清除記錄暫存資料qRecvRecordDisp 暫存器數值
        /// </summary>
        public void ClearRecvRecordDispBuf()
        {
            protocol.ClearqRecvRecordDisp();
        }

        /// <summary>
        /// 複製 Msg 暫存器的值
        /// </summary>
        public void CopyMsgBuf()
        {
            for (int ii = 0; ii < SciBuf.MsgBuf.Length; ii++)
            {
                SciBuf.MsgBuf[ii] = protocol.QMsg.Buf[ii];
            }
        }

        /// <summary>
        /// 清除 Msg 暫存器的值
        /// </summary>
        public void ClearQMsgBuf()
        {
            protocol.ClearQMessageBuf();
        }
        #endregion

    }

    #endregion
}

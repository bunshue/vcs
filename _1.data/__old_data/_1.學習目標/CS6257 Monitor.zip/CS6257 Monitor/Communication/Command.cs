﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace CS6257_Monitor
{
    public partial class Communication
    {
        #region 命令控制 Control Command

        /// <summary>
        /// 發送 手動/自動 模式命令
        /// 說明 : 手動 (true) , 自動 (false)
        /// </summary>
        public void Send_Manual_Auto_Mode_Cmd(bool value)
        {
            byte[] b = new byte[10];

            b[0] = 0xAA;
            b[1] = 0x20;
            b[2] = 0x00;
            b[3] = 0x00;
            b[4] = 0x00;
            b[5] = 0x00;
            if (value)
            {   // Manual
                b[6] = 0x01;
            }
            else
            {   // Auto
                b[6] = 0x00;
            }
            b[7] = 0x00;
            b[8] = 0x00;
            b[9] = CalcCheckSum(b, 9);

            comport.SendByte(b);
        }

        /// <summary>
        /// 發送啟動壓縮機運轉命令
        /// </summary>
        public void Send_Start_Motor_Cmd()
        {
            byte[] b = new byte[10];

            b[0] = 0xAA;
            b[1] = 0x20;
            b[2] = 0x01;
            b[3] = 0x00;
            b[4] = 0x00;
            b[5] = 0x00;
            b[6] = 0x01;
            b[7] = 0x00;
            b[8] = 0x00;
            b[9] = CalcCheckSum(b, 9);

            comport.SendByte(b);
        }

        /// <summary>
        /// 發送停止壓縮機運轉命令
        /// </summary>
        public void Send_Stop_Motor_Cmd()
        {
            byte[] b = new byte[10];

            b[0] = 0xAA;
            b[1] = 0x20;
            b[2] = 0x01;
            b[3] = 0x00;
            b[4] = 0x00;
            b[5] = 0x00;
            b[6] = 0x00;
            b[7] = 0x00;
            b[8] = 0x00;
            b[9] = CalcCheckSum(b, 9);

            comport.SendByte(b);
        }

        /// <summary>
        /// 發送壓縮機轉速命令 (單位 : rpm )
        /// </summary>
        /// <param name="spd_rps_cmd"></param>
        public void Send_Motor_Spd_rpm_Cmd(Int32 spd_rpm_cmd)
        {
            byte[] b = new byte[10];

            b[0] = 0xAA;
            b[1] = 0x20;
            b[2] = 0x02;
            b[3] = Convert.ToByte((spd_rpm_cmd >> 24) & 0x000000FF);
            b[4] = Convert.ToByte((spd_rpm_cmd >> 16) & 0x000000FF);
            b[5] = Convert.ToByte((spd_rpm_cmd >> 8) & 0x000000FF);
            b[6] = Convert.ToByte(spd_rpm_cmd & 0x000000FF);
            b[7] = 0x00;
            b[8] = 0x00;
            b[9] = CalcCheckSum(b, 9);

            comport.SendByte(b);
        }

        /// <summary>
        /// 發送壓縮機轉速命令 (單位 : rps )
        /// </summary>
        /// <param name="spd_rps_cmd"></param>
        public void Send_Motor_Spd_Cmd(Int32 spd_rps_cmd)
        {
            byte[] b = new byte[10];

            b[0] = 0xAA;
            b[1] = 0x20;
            b[2] = 0x02;
            b[3] = 0x00;
            b[4] = 0x00;
            b[5] = 0x00;
            b[6] = Convert.ToByte(spd_rps_cmd & 0x000000FF);
            b[7] = 0x00;
            b[8] = 0x00;
            b[9] = CalcCheckSum(b, 9);

            comport.SendByte(b);
        }

        /// <summary>
        /// 發送設定室外風扇轉速
        /// </summary>
        /// <param name="spd_cmd"></param>
        public void Send_OutFan_Spd_Cmd(Int32 spd_cmd, Int16 mode)
        {
            // mode :  1-> duty 2-> speed
            byte[] b = new byte[10];

            b[0] = 0xAA;//0x10;
            b[1] = 0x20;
            switch (mode)
            {
                case 1:
                    b[2] = 0xA4;
                    b[7] = 0x01;
                    break;
                case 2:
                    b[2] = 0xA3;
                    b[7] = 0x00;
                    break;
            }
            b[3] = 0x00;
            b[4] = 0x00;
            b[5] = Convert.ToByte(spd_cmd >> 8);
            b[6] = Convert.ToByte(spd_cmd & 0x000000FF);

            //b[7] = 0x00;
            b[8] = 0x00;
            b[9] = CalcCheckSum(b, 9);

            comport.SendByte(b);
        }

        /// <summary>
        /// 發送PFC 開/關 命令
        /// </summary>
        /// <param name="value"></param>
        public void Send_PFC_ON_OFF_Cmd(bool value)
        {
            byte[] b = new byte[10];

            b[0] = 0xAA;
            b[1] = 0x20;
            b[2] = 0x07;
            b[3] = 0x00;
            b[4] = 0x00;
            b[5] = 0x00;
            if (value == true)
            {
                b[6] = 0x01;    // ON
            }
            else
            {
                b[6] = 0x00;    // OFF
            }
            b[7] = 0x00;
            b[8] = 0x00;
            b[9] = CalcCheckSum(b, 9);

            comport.SendByte(b);
        }

        /// <summary>
        /// 發送四通閥 開/關 命令
        /// </summary>
        /// <param name="value"></param>
        public void Send_FourWayValve_ON_OFF_Cmd(bool value)
        {
            byte[] b = new byte[10];

            b[0] = 0xAA;
            b[1] = 0x20;
            b[2] = 0x06;
            b[3] = 0x00;
            b[4] = 0x00;
            b[5] = 0x00;
            if (value)
            {   // ON
                b[6] = 0x01;
            }
            else
            {   // OFF
                b[6] = 0x00;
            }
            b[7] = 0x00;
            b[8] = 0x00;
            b[9] = CalcCheckSum(b, 9);

            comport.SendByte(b);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="b"></param>
        public void SendCmdByte(byte[] b)
        {
            int len = b.Length;
            b[len - 1] = CalcCheckSum(b, len - 1);
            comport.SendByte(b);
        }

        #endregion

        #region 溫控邏輯模擬 Simulation

        /// <summary>
        /// 發送模擬資訊
        /// </summary>
        public void Send_SIM_Data()
        {
            if (++simdataNum > 3) simdataNum = 1;
            byte[] b = new byte[10];

            b[0] = 0xAA;
            b[1] = 0x50;
            switch (simdataNum)
            {
                case 1:
                    b[2] = 0x01;
                    b[3] = DataBuf.SIM_Data_Buf[3];
                    b[4] = DataBuf.SIM_Data_Buf[4];
                    b[5] = DataBuf.SIM_Data_Buf[5];
                    b[6] = DataBuf.SIM_Data_Buf[6];
                    b[7] = DataBuf.SIM_Data_Buf[7];
                    b[8] = DataBuf.SIM_Data_Buf[8];
                    b[9] = CalcCheckSum(b, 9);
                    break;
                case 2:
                    b[2] = 0x02;
                    b[3] = DataBuf.SIM_Data_Buf[13];
                    b[4] = DataBuf.SIM_Data_Buf[14];
                    b[5] = DataBuf.SIM_Data_Buf[15];
                    b[6] = DataBuf.SIM_Data_Buf[16];
                    b[7] = DataBuf.SIM_Data_Buf[17];
                    b[8] = DataBuf.SIM_Data_Buf[18];
                    b[9] = CalcCheckSum(b, 9);
                    break;
                case 3:
                    b[2] = 0x03;
                    b[3] = DataBuf.SIM_Data_Buf[23];
                    b[4] = DataBuf.SIM_Data_Buf[24];
                    b[5] = DataBuf.SIM_Data_Buf[25];
                    b[6] = DataBuf.SIM_Data_Buf[26];
                    b[7] = DataBuf.SIM_Data_Buf[27];
                    b[8] = DataBuf.SIM_Data_Buf[28];
                    b[9] = CalcCheckSum(b, 9);
                    break;
                default:
                    break;
            }

            comport.SendByte(b);
        }
        #endregion

        #region 參數調整 Para

        /// <summary>
        /// 更新馬達運轉參數命令
        /// </summary>
        public void Send_UpdateMotorRun_Para()
        {
            byte[] b = new byte[10];

            b[0] = 0xAA;
            b[1] = 0xF0;
            b[2] = 0x05;
            b[3] = 0x00;
            b[4] = 0x00;
            b[5] = 0x00;
            b[6] = 0x00;
            b[7] = 0x00;
            b[8] = 0x00;
            b[9] = CalcCheckSum(b, 9);

            comport.SendByte(b);
        }

        /// <summary>
        /// 更新溫控邏輯運行參數命令
        /// </summary>
        public void Send_UpdateStateMachineRun_Para()
        {
            byte[] b = new byte[10];

            b[0] = 0xAA;
            b[1] = 0xF0;
            b[2] = 0x06;
            b[3] = 0x00;
            b[4] = 0x00;
            b[5] = 0x00;
            b[6] = 0x00;
            b[7] = 0x00;
            b[8] = 0x00;
            b[9] = CalcCheckSum(b, 9);

            comport.SendByte(b);
        }

        /// <summary>
        /// 發送讀取Eflash命令
        /// </summary>
        public void Send_ReadEflash_Cmd()
        {
            byte[] b = new byte[10];

            b[0] = 0xAA;
            b[1] = 0xF0;
            b[2] = 0x04;
            b[3] = 0x00;
            b[4] = 0x00;
            b[5] = 0x00;
            b[6] = 0x00;
            b[7] = 0x00;
            b[8] = 0x00;
            b[9] = CalcCheckSum(b, 9);

            comport.SendByte(b);
        }

        /// <summary>
        /// 發送寫入Eflash命令
        /// </summary>
        public void Send_WriteEflash_Cmd()
        {
            byte[] b = new byte[10];

            b[0] = 0xAA;
            b[1] = 0xF0;
            b[2] = 0x03;
            b[3] = 0x00;
            b[4] = 0x00;
            b[5] = 0x00;
            b[6] = 0x00;
            b[7] = 0x00;
            b[8] = 0x00;
            b[9] = CalcCheckSum(b, 9);

            comport.SendByte(b);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="para"></param>
        public void Send_ISD_REF_Para(int para)
        {
            byte[] b = new byte[10];

            b[0] = 0x03;
            b[1] = 0x01;
            b[2] = Convert.ToByte((para >> 24) & 0x000000FF);
            b[3] = Convert.ToByte((para >> 16) & 0x000000FF);
            b[4] = Convert.ToByte((para >> 8) & 0x000000FF);
            b[5] = Convert.ToByte(para & 0x000000FF);
            b[6] = 0x00;
            b[7] = 0x00;
            b[8] = 0x00;
            b[9] = CalcCheckSum(b, 9);

            comport.SendByte(b);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="para"></param>
        public void Send_RS_Para(int para)
        {
            byte[] b = new byte[10];

            b[0] = 0x03;
            b[1] = 0x02;
            b[2] = Convert.ToByte((para >> 24) & 0x000000FF);
            b[3] = Convert.ToByte((para >> 16) & 0x000000FF);
            b[4] = Convert.ToByte((para >> 8) & 0x000000FF);
            b[5] = Convert.ToByte(para & 0x000000FF);
            b[6] = 0x00;
            b[7] = 0x00;
            b[8] = 0x00;
            b[9] = CalcCheckSum(b, 9);

            comport.SendByte(b);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="para"></param>
        public void Send_LD_Para(int para)
        {
            byte[] b = new byte[10];

            b[0] = 0x03;
            b[1] = 0x03;
            b[2] = Convert.ToByte((para >> 24) & 0x000000FF);
            b[3] = Convert.ToByte((para >> 16) & 0x000000FF);
            b[4] = Convert.ToByte((para >> 8) & 0x000000FF);
            b[5] = Convert.ToByte(para & 0x000000FF);
            b[6] = 0x00;
            b[7] = 0x00;
            b[8] = 0x00;
            b[9] = CalcCheckSum(b, 9);

            comport.SendByte(b);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="para"></param>
        public void Send_LQ_Para(int para)
        {
            byte[] b = new byte[10];

            b[0] = 0x03;
            b[1] = 0x04;
            b[2] = Convert.ToByte((para >> 24) & 0x000000FF);
            b[3] = Convert.ToByte((para >> 16) & 0x000000FF);
            b[4] = Convert.ToByte((para >> 8) & 0x000000FF);
            b[5] = Convert.ToByte(para & 0x000000FF);
            b[6] = 0x00;
            b[7] = 0x00;
            b[8] = 0x00;
            b[9] = CalcCheckSum(b, 9);

            comport.SendByte(b);
        }
        #endregion
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace CS6257_Monitor
{
    public partial class Communication
    {
        public struct CHECKSUM_STATE
        {
            public bool MotorPara;
            public bool StateMachine;
        }

        public CHECKSUM_STATE CheckSumSYSState;         // 參數同步狀態
        public CHECKSUM_STATE ReceiveCheckSumState;     // 

        // CS6257 參數資料
        public int[] Param_Data = new int[512];

        /// <summary>
        /// 初始化
        /// </summary>
        public void Init_ParamTransState()
        {
            CheckSumSYSState.MotorPara = false;
            CheckSumSYSState.StateMachine = false;

            ReceiveCheckSumState.MotorPara = false;
            ReceiveCheckSumState.StateMachine = false;
        }

        #region Eflash  通訊碼
        ///<summary>
        /// 發送取得MCU Eflash參數資料通訊碼
        /// 說明 : 向MCU發送請求第N筆資料之通訊碼
        ///</summary>
        private void Get_ParamFromMCU_Work()
        {
            ClearRecvParam();    // JM DEBUG
            //請求MCU先計算 CheckSum以供校驗
            Get_MotorPara_CheckSum();
            Get_StateMachinePara_CheckSum();
            byte[] b = new byte[10];
            int ii = 0;
            b[0] = 0xAA;
            b[1] = 0xF0;                       // 數據識別碼
            if (comport.IsComPortOpen() == true)
            {
                while (ii < 512)
                {
                    b[2] = 0x01;                // 工作模式
                    b[3] = Convert.ToByte((ii >> 8) & 0x000000FF);  // 資料代碼高位
                    b[4] = Convert.ToByte(ii & 0x000000FF);         // 資料代碼低位
                    b[5] = 0;
                    b[6] = 0;
                    b[7] = 0;
                    b[8] = 0;
                    b[9] = CalcCheckSum(b, 9);
                    comport.SendByte(b);

                    ii++;
                    progress = (int)(((double)ii / (double)512.0) * 100);   // 更新進度
                    Thread.Sleep(3);
                }
                progress = 0;
            }
        }

        /// <summary>
        /// 發送取得MCU Eflash參數資料通訊碼
        /// 說明 : 向MCU發送請求第N筆資料之通訊碼 ( 取得所有馬達參數 )
        /// </summary>
        private void  Get_Motor_ParamFromMCU_Work()
        {
            ClearRecvParam();    // JM DEBUG
            //請求MCU先計算 CheckSum以供校驗
            Get_MotorPara_CheckSum();
            byte[] b = new byte[10];
            b[0] = 0xAA;
            b[1] = 0xF0;                       // 數據識別碼
            if (comport.IsComPortOpen() == true)
            {
                for (int ii = 0; ii < 256; ii++ )
                {
                    b[2] = 0x01;                // 工作模式
                    b[3] = Convert.ToByte((ii >> 8) & 0x000000FF);  // 資料代碼高位
                    b[4] = Convert.ToByte(ii & 0x000000FF);         // 資料代碼低位
                    b[5] = 0;
                    b[6] = 0;
                    b[7] = 0;
                    b[8] = 0;
                    b[9] = CalcCheckSum(b, 9);
                    comport.SendByte(b);

                    progress = (int)(((double)ii / (double)256.0) * 100);   // 更新進度
                    Thread.Sleep(5);
                }
                progress = 0;
            }
        }

        /// <summary>
        /// 發送取得MCU Eflash參數資料通訊碼
        /// 說明 : 向MCU發送請求第N筆資料之通訊碼 ( 取得溫控邏輯參數 )
        /// </summary>
        private void Get_StateMachine_ParamFromMCU_Work()
        {
            ClearRecvParam();    // JM DEBUG
            //請求MCU先計算 CheckSum以供校驗
            Get_StateMachinePara_CheckSum();
            byte[] b = new byte[10];;
            b[0] = 0xAA;
            b[1] = 0xF0;                       // 數據識別碼
            if (comport.IsComPortOpen() == true)
            {
                int cnt = 0;
                for (int ii = 256; ii < 512; ii++ )
                {
                    b[2] = 0x01;                // 工作模式
                    b[3] = Convert.ToByte((ii >> 8) & 0x000000FF);  // 資料代碼高位
                    b[4] = Convert.ToByte(ii & 0x000000FF);         // 資料代碼低位
                    b[5] = 0;
                    b[6] = 0;
                    b[7] = 0;
                    b[8] = 0;
                    b[9] = CalcCheckSum(b, 9);
                    comport.SendByte(b);
                    cnt++;
                    progress = (int)(((double)cnt / (double)256.0) * 100);   // 更新進度
                    Thread.Sleep(5);
                }
                progress = 0;
            }
        }

        /// <summary>
        /// 將PC參數資料傳送至MCU通訊碼
        /// 說明 : 將PC上之參數資料傳送至MCU
        /// </summary>
        private void Send_ParamToMCU_Work()
        {
            byte[] b = new byte[10];
            int ii = 0;
            b[0] = 0xAA;
            b[1] = 0xF0;                        // 數據識別碼
            if (comport.IsComPortOpen() == true)
            {
                int[] temp = new int[parmDB.Length];

                for (int jj = 0; ii < temp.Length; ii++)
                {
                    temp[jj] = parmDB[jj].Value;
                }
                // 計算 eflash 資料之 checksum 並儲存至 eflash_listView_Data[255&511]中供MCU校驗
                temp[255] = CalcEflashCheckSum(temp, 0, 254);
                temp[511] = CalcEflashCheckSum(temp, 256, 510);

                while (ii < 512)
                {
                    b[2] = 0x02;                // 工作模式
                    b[3] = Convert.ToByte((ii >> 8) & 0x000000FF);  // 資料代碼高位
                    b[4] = Convert.ToByte(ii & 0x000000FF);         // 資料代碼低位
                    b[5] = Convert.ToByte((temp[ii] >> 24) & 0x000000FF);
                    b[6] = Convert.ToByte((temp[ii] >> 16) & 0x000000FF);
                    b[7] = Convert.ToByte((temp[ii] >> 8) & 0x000000FF);
                    b[8] = Convert.ToByte((temp[ii] >> 0) & 0x000000FF);
                    b[9] = CalcCheckSum(b, 9);
                    comport.SendByte(b);
                    ii++;
                    progress = (int)(((double)ii / (double)512.0) * 100);
                    Thread.Sleep(10);
                }
                progress = 0;

                Thread.Sleep(200);  // 延遲等待接收完畢
            }
        }

        /// <summary>
        /// 將馬達參數資料發送給MCU
        /// </summary>
        private void Send_Motor_ParamToMCU_Work()
        {
            byte[] b = new byte[10];

            b[0] = 0xAA;
            b[1] = 0xF0;                        // 數據識別碼
            if (comport.IsComPortOpen() == true)
            {
                int[] temp = new int[parmDB.Length];

                for (int ii = 0; ii < temp.Length; ii++)
                {
                    temp[ii] = parmDB[ii].Value;
                }
                // 計算 eflash 資料之 checksum 並儲存至 eflash_listView_Data[255]中供MCU校驗
                temp[255] = CalcEflashCheckSum(temp, 0, 254);

                for (int ii = 0; ii < 256; ii++)
                {
                    b[2] = 0x02;                // 工作模式
                    b[3] = Convert.ToByte((ii >> 8) & 0x000000FF);  // 資料代碼高位
                    b[4] = Convert.ToByte(ii & 0x000000FF);         // 資料代碼低位
                    b[5] = Convert.ToByte((temp[ii] >> 24) & 0x000000FF);
                    b[6] = Convert.ToByte((temp[ii] >> 16) & 0x000000FF);
                    b[7] = Convert.ToByte((temp[ii] >> 8) & 0x000000FF);
                    b[8] = Convert.ToByte((temp[ii] >> 0) & 0x000000FF);
                    b[9] = CalcCheckSum(b, 9);
                    comport.SendByte(b);
                    progress = (int)(((double)ii / (double)256.0) * 100);
                    Thread.Sleep(3);
                }
                progress = 0;

                Thread.Sleep(200);  // 延遲等待接收完畢
            }
        }

        /// <summary>
        /// 將溫控邏輯資料發送給MCU
        /// </summary>
        private void Send_StateMachine_ParamToMCU_Work()
        {
            byte[] b = new byte[10];

            b[0] = 0xAA;
            b[1] = 0xF0;                        // 數據識別碼
            if (comport.IsComPortOpen() == true)
            {
                int[] temp = new int[parmDB.Length];

                for (int ii = 0; ii < temp.Length; ii++)
                {
                    temp[ii] = parmDB[ii].Value;
                }
                // 計算 eflash 資料之 checksum 並儲存至 eflash_listView_Data[511]中供MCU校驗
                temp[511] = CalcEflashCheckSum(temp, 256, 510);

                int cnt = 0;
                for (int ii = 256; ii < 512; ii++)
                {
                    b[2] = 0x02;                // 工作模式
                    b[3] = Convert.ToByte((ii >> 8) & 0x000000FF);  // 資料代碼高位
                    b[4] = Convert.ToByte(ii & 0x000000FF);         // 資料代碼低位
                    b[5] = Convert.ToByte((temp[ii] >> 24) & 0x000000FF);
                    b[6] = Convert.ToByte((temp[ii] >> 16) & 0x000000FF);
                    b[7] = Convert.ToByte((temp[ii] >> 8) & 0x000000FF);
                    b[8] = Convert.ToByte((temp[ii] >> 0) & 0x000000FF);
                    b[9] = CalcCheckSum(b, 9);
                    comport.SendByte(b);
                    cnt++;
                    progress = (int)(((double)cnt / (double)256.0) * 100);
                    Thread.Sleep(10);
                }
                progress = 0;

                Thread.Sleep(200);  // 延遲等待接收完畢
            }
        }

        /// <summary>
        /// 發送寫入資料至Eflash指令
        /// </summary>
        private void Send_Write_Eflash_Data()
        {
            byte[] b = new byte[10];
            b[0] = 0xAA;
            b[1] = 0xF0;
            b[2] = 0x03;
            b[3] = 0x00;
            b[4] = 0x00;
            b[5] = 0x00;
            b[6] = 0x00;
            b[7] = 0x00;
            b[8] = 0x00;
            b[9] = CalcCheckSum(b, 9);
            comport.SendByte(b);
        }

        /// <summary>
        /// 發送從Eflash讀取資料指令
        /// </summary>
        private void Send_Read_Eflash_Data()
        {
            byte[] b = new byte[10];
            b[0] = 0xAA;
            b[1] = 0xF0;
            b[2] = 0x04;
            b[3] = 0x00;
            b[4] = 0x00;
            b[5] = 0x00;
            b[6] = 0x00;
            b[7] = 0x00;
            b[8] = 0x00;
            b[9] = CalcCheckSum(b, 9);
            comport.SendByte(b);
        }

        /// <summary>
        /// 發送更新馬達運轉參數指令
        /// </summary>
        private void Send_Update_MotoPara_Cmd()
        {
            byte[] b = new byte[10];
            b[0] = 0xAA;
            b[1] = 0xF0;
            b[2] = 0x05;
            b[3] = 0x00;
            b[4] = 0x00;
            b[5] = 0x00;
            b[6] = 0x00;
            b[7] = 0x00;
            b[8] = 0x00;
            b[9] = CalcCheckSum(b, 9);
            comport.SendByte(b);
        }

        /// <summary>
        /// 發送更新溫控邏輯參數指令
        /// </summary>
        private void Send_Update_StateMachinePara_Cmd()
        {
            byte[] b = new byte[10];
            b[0] = 0xAA;
            b[1] = 0xF0;
            b[2] = 0x06;
            b[3] = 0x00;
            b[4] = 0x00;
            b[5] = 0x00;
            b[6] = 0x00;
            b[7] = 0x00;
            b[8] = 0x00;
            b[9] = CalcCheckSum(b, 9);
            comport.SendByte(b);
        }

        /// <summary>
        /// 發送計算馬達參數 CheckSum 指令並回傳 CheckSum值
        /// (不可連續發送 ， 需間隔時間 )
        /// </summary>
        private void Get_MotorPara_CheckSum()
        {
            byte[] b = new byte[10];
            b[0] = 0xAA;
            b[1] = 0xF0;
            b[2] = 0x07;
            b[3] = 0x00;
            b[4] = 0x00;
            b[5] = 0x00;
            b[6] = 0x00;
            b[7] = 0x00;
            b[8] = 0x00;
            b[9] = CalcCheckSum(b, 9);
            comport.SendByte(b);
            Thread.Sleep(500);
        }

        /// <summary>
        /// 發送計算溫控邏輯參數 CheckSum 指令並回傳 CheckSum值
        /// (不可連續發送 ， 需間隔時間 )
        /// </summary>
        private void Get_StateMachinePara_CheckSum()
        {
            byte[] b = new byte[10];
            b[0] = 0xAA;
            b[1] = 0xF0;
            b[2] = 0x08;
            b[3] = 0x00;
            b[4] = 0x00;
            b[5] = 0x00;
            b[6] = 0x00;
            b[7] = 0x00;
            b[8] = 0x00;
            b[9] = CalcCheckSum(b, 9);
            comport.SendByte(b);
            Thread.Sleep(500);
        }

        /// <summary>
        /// 發送線上更新馬達運轉參數指令
        /// 說明: 發送線上更新參數後執行更新命令
        /// </summary>
        private void Send_Online_Tune_Cmd()
        {
            //byte[] b = new byte[10];
            //// 更新參數索引值
            //int[] arr = { 3, 4, 5, 6, 7, 8, 9, 10 };
            //b[0] = 0xAA;
            //b[1] = 0xF0;
            //// 發送線上更新參數資料
            //for (int ii = 0; ii < arr.Length; ii++)
            //{
            //    b[2] = 0x02;                // 工作模式
            //    b[3] = Convert.ToByte((0 >> 8) & 0x000000FF);  // 資料代碼高位
            //    b[4] = Convert.ToByte(arr[ii] & 0x000000FF);         // 資料代碼低位
            //    b[5] = Convert.ToByte((Param_Data[arr[ii]] >> 24) & 0x000000FF);
            //    b[6] = Convert.ToByte((Param_Data[arr[ii]] >> 16) & 0x000000FF);
            //    b[7] = Convert.ToByte((Param_Data[arr[ii]] >> 8) & 0x000000FF);
            //    b[8] = Convert.ToByte((Param_Data[arr[ii]] >> 0) & 0x000000FF);
            //    b[9] = CalcCheckSum(b, 9);
            //    comport.SendByte(b);
            //    Thread.Sleep(20);
            //}

            //Thread.Sleep(500);

            //// 發送線上更新參數指令
            //b[0] = 0xAA;
            //b[1] = 0xF0;
            //b[2] = 0x06;
            //b[3] = 0x00;
            //b[4] = 0x00;
            //b[5] = 0x00;
            //b[6] = 0x00;
            //b[7] = 0x00;
            //b[8] = 0x00;
            //b[9] = CalcCheckSum(b, 9);
            //comport.SendByte(b);
        }

        #endregion

        /// <summary>
        /// 從暫存器中取出Parameter
        /// </summary>
        /// <returns></returns>
        public int[] GetParamFromBuf()
        {
            int[] paramData = new int[Param_Data.Length];
            int p = 0;

            // Copy Eflash Data buffer
            CopyParamDataBuf();

            for (int index = 0; index < 512; index++)
            {
                int value = 0;
                p = index * 10;
                value = Convert.ToInt32(DataBuf.Param_Data_Buf[p + 5]) << 24;
                value += Convert.ToInt32(DataBuf.Param_Data_Buf[p + 6]) << 16;
                value += Convert.ToInt32(DataBuf.Param_Data_Buf[p + 7]) << 8;
                value += Convert.ToInt32(DataBuf.Param_Data_Buf[p + 8]);
                paramData[index] = value;
            }
            return paramData;
        }


        #region CHECKSUM 確認
        /// <summary>
        /// 檢查接收的資料CheckSum是否正確
        /// </summary>
        private void CheckRecvParamCheckSum()
        {
            Thread.Sleep(1000);
            int[] receive_paramData = GetParamFromBuf();

            int sum1 = CalcEflashCheckSum(receive_paramData, 0, 254);
            int sum2 = CalcEflashCheckSum(receive_paramData, 256, 510);

            if (sum1 == receive_paramData[255])
            {
                ReceiveCheckSumState.MotorPara = true;
            }
            else
            {
                ReceiveCheckSumState.MotorPara = false;
            }

            if (sum2 == receive_paramData[511])
            {
                ReceiveCheckSumState.StateMachine = true;
            }
            else
            {
                ReceiveCheckSumState.StateMachine = false;
            }

            if (ReceiveCheckSumState.MotorPara && ReceiveCheckSumState.StateMachine)
            {
                DataBuf.Param_Updated = true;
            }
        }

        /// <summary>
        /// 檢查接收的馬達參數資料CheckSum是否正確
        /// </summary>
        private void CheckRecvMotorParamCheckSum()
        {
            Thread.Sleep(1000);
            int[] receive_paramData = GetParamFromBuf();

            int sum1 = CalcEflashCheckSum(receive_paramData, 0, 254);

            Console.WriteLine("Check Receive Motor Param. Correct");
            Console.WriteLine("receive_paramData[255] = {0}", receive_paramData[255].ToString());

            if (sum1 == receive_paramData[255])
            {
                ReceiveCheckSumState.MotorPara = true;
                DataBuf.Param_Updated = true;   // 參數已更新
                Console.WriteLine("Receive Data Check Sum [OK]");
            }
            else
            {
                ReceiveCheckSumState.MotorPara = false;
                Console.WriteLine("Receive Data Check Sum [ERROR]");
            }
        }

        /// <summary>
        /// 檢查接收的溫控邏輯參數資料CheckSum是否正確
        /// </summary>
        private void CheckRecvStateMachineParamCheckSum()
        {
            Thread.Sleep(1000);
            int[] receive_paramData = GetParamFromBuf();

            int sum2 = CalcEflashCheckSum(receive_paramData, 256, 510);

            if (sum2 == receive_paramData[511])
            {
                ReceiveCheckSumState.StateMachine = true;
                DataBuf.Param_Updated = true;   // 參數已更新
            }
            else
            {
                ReceiveCheckSumState.StateMachine = false;
            }
        }

        /// <summary>
        /// 檢查PC端CheckSum 是否和 MCU端相同
        /// </summary>
        public void CheckParamSYN()
        {
            Console.WriteLine("Check Param. SYN Status");

            // 計算 PC 端資料 CheckSum
            int[] temp = new int[parmDB.Length];

            for (int ii = 0; ii < temp.Length; ii++)
            {
                temp[ii] = parmDB[ii].Value;
            }

            temp[255] = CalcEflashCheckSum(temp, 0, 254);
            temp[511] = CalcEflashCheckSum(temp, 255, 510);

            // 取得接收 buffer 內的資料
            int[] receive_paramData = GetParamFromBuf();

            // 判斷 PC 端資料 CheckSum 是否和 MCU 端 CheckSum 相同
            // Motor Param
            if (temp[255] == receive_paramData[255])
            {
                Console.WriteLine("Motor Param. SYN CheckSum [OK]");
                CheckSumSYSState.MotorPara = true;
            }
            else
            {
                Console.WriteLine("Motor Param. SYN CheckSum [ERROR]");
                CheckSumSYSState.MotorPara = false;
            }
            // StateMachine Param
            if (temp[511] == receive_paramData[511])
            {
                CheckSumSYSState.StateMachine = true;
            }
            else
            {
                CheckSumSYSState.StateMachine = false;
            }
        }

        /// <summary>
        /// 取得MCU資料中之Checksum的值
        /// </summary>
        public void ReqMCUCheckSumData()
        {
            Console.WriteLine("Request MCU Parameter CheckSum Data.");
            // Clear Receive Buffer
            ClearRecvParam();
            //發送計算馬達參數 CheckSum 指令並回傳 CheckSum值
            Get_MotorPara_CheckSum();
            Thread.Sleep(50);
            //發送計算溫控邏輯參數 CheckSum 指令並回傳 CheckSum值
            Get_StateMachinePara_CheckSum();
            Thread.Sleep(50);

            //byte[] b = new byte[10];
            //int dataNum = 255;

            //b[0] = 0xAA;
            //b[1] = 0xF0;
            //b[2] = 0x01;
            //b[3] = Convert.ToByte((dataNum >> 8) & 0x000000FF);  // 資料代碼高位
            //b[4] = Convert.ToByte(dataNum & 0x000000FF);         // 資料代碼低位
            //b[5] = 0x00;
            //b[6] = 0x01;
            //b[7] = 0x00;
            //b[8] = 0x00;
            //b[9] = CalcCheckSum(b, 9);

            //comport.SendByte(b);

            //Thread.Sleep(10);

            //dataNum = 511;

            //b[0] = 0xAA;
            //b[1] = 0xF0;
            //b[2] = 0x01;
            //b[3] = Convert.ToByte((dataNum >> 8) & 0x000000FF);  // 資料代碼高位
            //b[4] = Convert.ToByte(dataNum & 0x000000FF);         // 資料代碼低位
            //b[5] = 0x00;
            //b[6] = 0x01;
            //b[7] = 0x00;
            //b[8] = 0x00;
            //b[9] = CalcCheckSum(b, 9);

            //comport.SendByte(b);

            //Thread.Sleep(100);
        }

        #endregion


        /// <summary>
        /// 計算Eflash Data 校驗碼
        /// </summary>
        /// <param name="pData"></param>
        /// <param name="len"></param>
        /// <returns></returns>
        private int CalcCheckSum_Eflash(int[] pData, int len)
        {
            int sum = 0x00;
            for (int ii = 0; ii < len; ii++)
            {
                sum += pData[ii];
            }
            //sum = (sum ^ 0xFF) + 1;
            return sum + 1;
        }

        /// <summary>
        /// 計算 Eflash Data 校驗碼
        /// </summary>
        /// <param name="pData"></param>
        /// <param name="start"></param>
        /// <param name="end"></param>
        /// <returns></returns>
        private int CalcEflashCheckSum(int[] pData, int start, int end)
        {
            int sum = 0x00;
            for (int ii = start; ii <= end; ii++)
            {
                sum += pData[ii];
            }
            return sum + 1;
        }
    }
}

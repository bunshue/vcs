﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.IO;

namespace CS6257_Monitor
{
    public class ParamDB
    {
        public int Number;
        public string Name;
        public int Value;
    }

    public partial class Communication
    {
        public ParamDB[] parmDB = new ParamDB[512];

        /// <summary>
        /// 
        /// </summary>
        private void Init_ParamTable()
        {
            string[] rowdata = new string[6];
            string context = string.Empty;
            int t1 = 0;
            int t2 = 0;

            // 建立 ParamDB 物件
            for (int ii = 0; ii < parmDB.Length; ii++)
            {
                parmDB[ii] = new ParamDB();
            }

            // 從 Resource 取得 List 文字檔
            string text = Resource1.Eflash_Para_List;
            MemoryStream stream = new MemoryStream();
            StreamWriter str_writer = new StreamWriter(stream);
            str_writer.Write(text);
            str_writer.Flush();
            stream.Position = 0;
            StreamReader str_reader = new StreamReader(stream);

            for(int ii = 0; ii < 512; ii++)
            {
                context = str_reader.ReadLine();
                t1 = t2 = 0;
                for (int jj = 0; jj < 3; jj++)
                {
                    t2 = context.IndexOf("\t", t1);
                    rowdata[jj] = context.Substring(t1, t2 - t1);
                    t1 = t2 + 1;
                }
                rowdata[3] = (double.Parse(rowdata[2]) / (double)16777216).ToString("0.0000000");
                rowdata[4] = "0x" + Int32.Parse(rowdata[2]).ToString("X8");
                rowdata[5] = "";

                parmDB[ii].Number = ii;
                parmDB[ii].Name = rowdata[1];
                parmDB[ii].Value = Int32.Parse(rowdata[2]);
            }
        }

        /// <summary>
        /// 從Receive buf 讀取資料並更新 ParamDB 資料
        /// </summary>
        public void Update_ParamDB()
        {
            int[] temp = GetParamFromBuf();

            for (int ii = 0; ii < parmDB.Length; ii ++)
            {
                parmDB[ii].Value = temp[ii];
            }
            SciFlag.UpdateListView = true;

            // Clear Receive buf data
            ClearRecvParam();
            Console.WriteLine("Move Param. Data From Buffer to parmDB Done.");
        }

        /// <summary>
        /// 設定 dataName 對應之參數值
        /// </summary>
        /// <param name="dataName"></param>
        /// <param name="value"></param>
        public void Set_ParamDBValue(string dataName, int value)
        {
            string str = string.Empty;

            for (int ii = 0; ii < parmDB.Length; ii++)
            {
                str = parmDB[ii].Name;
                if (str.CompareTo(dataName) == 0)
                {
                    parmDB[ii].Value = value;
                }
            }
            SciFlag.UpdateListView = true;
        }

        /// <summary>
        /// 取得 dataName 對應到之參數值
        /// </summary>
        /// <param name="dataName"></param>
        /// <returns></returns>
        public int Get_ParamDBValue(string dataName)
        {
            int value = 0;
            string str = string.Empty;
            for (int ii = 0; ii < parmDB.Length; ii++)
            {
                str = parmDB[ii].Name;
                if (str.CompareTo(dataName) == 0)
                {
                    value = parmDB[ii].Value;
                }
            }
            //Console.WriteLine("Get Parameter [{0}] = {1}", dataName, value.ToString());
            return value;
        }

        public void Clear_ParamDBValue()
        {
            for (int ii = 0; ii < parmDB.Length; ii++)
            {
                parmDB[ii].Value = 0;
            }
        }
    }
}

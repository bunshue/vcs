﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Threading;
using System.Diagnostics;

namespace CS6257_Monitor
{
    public class ComPort
    {
        System.IO.Ports.SerialPort serialport = new System.IO.Ports.SerialPort();

        Thread Receive_Thread;              // 接收執行緒
        Boolean receive_flag = false;       // 資料接收旗標

        ///<summary>
        ///名稱 : ComPort
        ///說明 : 建構函式
        ///</summary>
        public ComPort()
        {
            //
        }

        ///<summary>
        ///名稱 : GetComPort
        ///說明 : 取得COM Port 名稱
        ///</summary>
        public void GetComPort(ToolStripComboBox combobox)
        {
            foreach (string comportname in System.IO.Ports.SerialPort.GetPortNames())
            {
                // 取得所有可開啟連接埠並加入至combobox
                combobox.Items.Add(comportname);
            }
        }

        ///<summary>
        ///名稱 : IsComPortOpen
        ///說明 : 取得Com Port 開啟狀態
        ///</summary>
        public bool IsComPortOpen()
        {
            bool state = false;
            state = serialport.IsOpen;
            return state;
        }

        #region ComPort 開啟/關閉

        ///<summary>
        ///名稱 : OpenComPort
        ///說明 : 開啟通訊連接埠
        ///</summary>
        public void OpenComPort(string PortName, string BaudRate, string DataBits, string Stopbits, string Paritybits)
        {
            if (serialport.IsOpen == false)
            {
                try
                {
                    // 設定 COM Port 參數
                    serialport.PortName = PortName;
                    serialport.BaudRate = Int32.Parse(BaudRate);
                    serialport.DataBits = Int32.Parse(DataBits);
                    serialport.StopBits = System.IO.Ports.StopBits.One;
                    serialport.Parity = System.IO.Ports.Parity.None;
                    serialport.Encoding = Encoding.Default;
                    serialport.Open();                              // 開啟連接埠
                    receive_flag = true;                            // 開啟接收資料旗標
                    if (Receive_Thread == null)
                    {
                        // 建立接收執行緒
                        Receive_Thread = new Thread(new ThreadStart(DoReceive));
                        Receive_Thread.IsBackground = true;
                        Receive_Thread.Start();                         // 啟動接收執行緒
                    }
                    else if (Receive_Thread.IsAlive == false)
                    {
                        Receive_Thread = new Thread(new ThreadStart(DoReceive));
                        Receive_Thread.IsBackground = true;
                        Receive_Thread.Start();                         // 啟動接收執行緒
                        // 錯誤狀況
                    }

                }
                catch (Exception ex)
                {
                    // 例外處理程序
                    MessageBox.Show(ex.ToString());
                }
            }
        }

        ///<summary>
        ///名稱 : CloseComPort
        ///說明 : 關閉通訊連接埠
        ///</summary>
        public void CloseComPort()
        {
            if (serialport.IsOpen == true)
            {
                try
                {
                    receive_flag = false;                           // 關閉接收資料旗標
                    serialport.Close();                             // 關閉連接埠
                }
                catch (Exception ex)
                {
                    // 例外處理程序
                    MessageBox.Show(ex.ToString());
                }
            }
        }

        #endregion

        #region SerialPort 接收

        ///<summary>
        ///名稱 : DoReceive
        ///說明 : 由接收執行緒Receive_Thread執行serialport資料的接收
        ///</summary>
        public Byte[] receive_buffer = new Byte[2048];      // 接收資料緩衝區
        public int BytesToRead = 0;                         // 緩衝區內可接收資料數

        private void DoReceive()
        {
            Boolean readfullBuffer = false;
            int timeout_cnt = 0;
            while (receive_flag == true)
            {
                try
                {
                    if (BytesToRead == 0)
                    {
                        readfullBuffer = true;
                        while (serialport.BytesToRead < receive_buffer.Length)
                        {
                            Thread.Sleep(1);
                            if (++timeout_cnt > 100)
                            {
                                readfullBuffer = false;
                                break;
                            }
                        }
                        timeout_cnt = 0;  //??
                        if (readfullBuffer == true)
                        {
                            BytesToRead = serialport.Read(receive_buffer, 0, receive_buffer.Length);
                        }
                        else if (readfullBuffer == false)
                        {
                            for (int ii = 0; ii < receive_buffer.Length; ii++)
                            {
                                receive_buffer[ii] = 0;
                            }
                            BytesToRead = serialport.Read(receive_buffer, 0, (int)serialport.BytesToRead);
                        }
                    }
                    else
                    {
                        Thread.Sleep(10);
                    }
                }
                catch
                {
                    //
                }
            }
        }

        ///<summary>
        ///名稱 : GetReceiveData
        ///說明 : 
        ///</summary>
        /// <returns>返回接收Byte物件</returns>
        public Byte[] GetReceiveData()
        {
            if (BytesToRead > 0)
            {
                Byte[] data = new Byte[BytesToRead];
                for (int ii = 0; ii < BytesToRead; ii++)
                {
                    data[ii] = receive_buffer[ii];
                }
                BytesToRead = 0;
                return data;
            }
            else return null;
        }

        #endregion

        #region SerialPort 傳送

        ///<summary>
        ///名稱 : Send
        ///說明 : 傳送字串資料
        ///</summary>
        public void Send(string str)
        {
            try
            {
                if (serialport.IsOpen)
                {
                    serialport.Write(str);
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show("Error: Send()\n" + ex.ToString());
            }
            
        }

        ///<summary>
        ///名稱 : SendByte
        ///說明 : 傳送位元組資料
        ///</summary>
        public void SendByte(Byte[] data)
        {
            int retry = 10;
            while (--retry > 0)
            {
                try
                {
                    if (serialport.IsOpen)
                    {
                        serialport.Write(data, 0, data.Length);
                        break;
                    }
                    else
                    {
                        return;
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.ToString());
                }
                Thread.Sleep(25);
            }
        }

        #endregion
    }
}

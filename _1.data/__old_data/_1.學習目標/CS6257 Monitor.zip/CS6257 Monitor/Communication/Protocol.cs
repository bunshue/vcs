﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;


namespace CS6257_Monitor
{
    class Protocol
    {
        /// <summary>
        /// 序列傳輸狀態
        /// </summary>
        private enum SCI_STATE
        {
            SCI_IDLE, SCI_STAR, SCI_OVER, SCI_WAIT, SCI_FAULT
        }

        /// <summary>
        /// 通訊狀態
        /// </summary>
        private enum COMMUTE_STATE
        {
            COM_POWERUP, COM_RESET, COM_TX, COMTXWAIT, COM_RX, COM_RXWAIT, COM_FAULT
        }

        /// <summary>
        /// 
        /// </summary>
        private struct SCI_DATA
        {
            public int len;
            public int cnt;
            public SCI_STATE state;
            public byte[] buf;
        }

        /// <summary>
        /// 
        /// </summary>
        private struct CS_COMMUNICATE
        {
            public COMMUTE_STATE state;
            public SCI_DATA rx;
            public SCI_DATA tx;
            public short timeCnt;
            public short flagUpdate;
        }

        /// <summary>
        /// 
        /// </summary>
        public struct UN_RECVBUF
        {
            public byte[] buf;
        }

        /// <summary>
        /// 
        /// </summary>
        public struct UN_REALTIMEBUF
        {
            public bool Busy;
            public bool Read;
            public bool Empty;
            public int pCnt;
            public byte[] buf;
        }

        public struct QMESSAGE
        {
            public bool Ack;
            public byte[] Buf;
        }

        // 接收緩衝區大小
        private int PARAMBUF_LEN = 10240;
        // EFLASH 參數個數
        private const int NUMOFEFLASHPARAM = 512;       
        private int PARAMEFLASHBUF_LEN = NUMOFEFLASHPARAM * 10;
        // 紀錄接收緩衝區大小
        private const int RECORD_LEN = 10000 * 10;
        // 系統狀態訊息接收緩衝區大小
        private const int MESSAGE_LEN = 32;

        private byte[] rxBuf = new byte[50];
        private byte[] txBuf = new byte[50];

        private CS_COMMUNICATE communState;
        public UN_RECVBUF qRecvMonitor;
        public UN_RECVBUF qRecvMonitor2;
        public UN_RECVBUF qRecvParam;
        public UN_RECVBUF qRecvRecordDisp;

        public UN_REALTIMEBUF RealTimeBuf;

        public QMESSAGE QMsg;

        public string str_text = string.Empty;

        /// <summary>
        /// 
        /// </summary>
        public Protocol()
        {
            communState.state = COMMUTE_STATE.COM_POWERUP;
            communState.rx.len = 0;
            communState.rx.cnt = 0;
            communState.rx.state = SCI_STATE.SCI_IDLE;
            //
            communState.rx.buf = rxBuf;
            communState.tx.len = 0;
            communState.tx.cnt = 0;
            communState.tx.state = SCI_STATE.SCI_IDLE;
            communState.tx.buf = txBuf;
            //
            communState.timeCnt = 0;
            communState.flagUpdate = 0;
            //
            qRecvMonitor.buf = new byte[PARAMBUF_LEN];
            qRecvMonitor2.buf = new byte[PARAMBUF_LEN];
            qRecvParam.buf = new byte[PARAMEFLASHBUF_LEN];
            qRecvRecordDisp.buf = new byte[RECORD_LEN];
            //
            RealTimeBuf.buf = new byte[6 * 25600];
            RealTimeBuf.Busy = false;
            RealTimeBuf.Empty = true;
            RealTimeBuf.pCnt = 0;
            RealTimeBuf.Read = false;
            //
            QMsg.Ack = false;
            QMsg.Buf = new byte[MESSAGE_LEN];
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="rev_data"></param>
        /// <param name="bytenum"></param>
        /// <returns></returns>
        public string GetSpyData(byte[] rev_data, int bytenum)
        {
            string str = string.Empty;
            int ii = 0;

            for (ii = 0; ii < bytenum; ii++)
            {
                communState.rx.buf[communState.rx.cnt] = rev_data[ii];
                CommunRx();
            }
            str += str_text;
            str_text = string.Empty;
            return str;
        }


        /// <summary>
        /// 
        /// </summary>
        private void CommunRx()
        {
            // 接收到第一個數據，計算數據長度
            if (communState.rx.cnt == 0)
            {
                communState.rx.len = GetSciCmdLen(communState.rx.buf[0]);
                // 未知命令，丟棄
                if (communState.rx.len == 0)
                {
                    communState.rx.cnt = 0;
                    communState.rx.state = SCI_STATE.SCI_IDLE;
                }
                else
                {
                    communState.rx.state = SCI_STATE.SCI_STAR;
                }
            }

            // SCI_STAR
            if (communState.rx.state == SCI_STATE.SCI_STAR)
            {
                communState.rx.cnt++;
                if (communState.rx.cnt >= communState.rx.len)
                {
                    if (communState.rx.buf[communState.rx.len - 1] == CalcCheckSum(communState.rx.buf, communState.rx.len - 1))
                    {
                        switch(communState.rx.buf[0])
                        {
                            case 0x55:
                                // 更新 Monitor 監控參數
                                QryMonitorUpdate();
                                break;
                            case 0x56:
                                // 更新 Monitor 2 監控參數
                                QryMonitorUpdate2();
                                break;
                            case 0x57:
                                // 更新 Parameter 傳輸資料
                                QryParamUpdate();
                                break;
                            case 0x63:
                                // 更新 Record 紀錄參數
                                QryRecordDispUpdate();
                                break;
                            case 0x65:
                                // Real Time Display
                                QryRealTimeDispUpdate();
                                break;
                            case 0xAB:
                                QryMessageUpdate();
                                break;
                            default: 
                                break;
                        }
                    }
                    else
                    {
                        byte[] b = new byte[communState.rx.len];
                        for (int ii = 0; ii < communState.rx.len; ii++)
                        {
                            b[ii] = communState.rx.buf[ii];  
                        }
                        str_text += Encoding.ASCII.GetString(b);
                    }

                    communState.rx.state = SCI_STATE.SCI_OVER;
                    communState.rx.cnt = 0;
                    communState.timeCnt = 0;
                }
            }
            else if (communState.rx.state == SCI_STATE.SCI_IDLE)
            {
                byte[] b = new byte[1];
                b[0] = communState.rx.buf[0];
                str_text += Encoding.ASCII.GetString(b);
            }
        }

        /// <summary>
        /// 根據標頭來判斷取得封包長度
        /// </summary>
        /// <param name="head"></param>
        /// <returns></returns>
        private int GetSciCmdLen(int head)
        {
            int len = 0;
            switch (head)
            {
                case 0xAA:
                    len = 50;
                    break;
                case 0x55:
                    // Monitor 監控參數
                    len = 10;
                    break;
                case 0x56:
                    // Monitor2 監控參數
                    len = 16;
                    break;
                case 0x57:
                    // Eflash 傳輸參數
                    len = 10;
                    break;
                case 0x63:
                    // RecordDisp 紀錄參數
                    len = 10;
                    break;
                case 0x65:
                    len = 6;
                    break;
                case 0xAB:
                    // Ack
                    len = 4;
                    break;
                default:
                    len = 0;
                    break;
            }

            return len;
        }

        /// <summary>
        /// 取得 qRecvMonitor 的值
        /// </summary>
        private void QryMonitorUpdate()
        {
            int t = communState.rx.buf[1] * 10;
            if (t < qRecvMonitor.buf.Length - 10)
            {
                for (int ii = 0; ii < 10; ii++)
                {
                    qRecvMonitor.buf[t + ii] = communState.rx.buf[ii];
                }
            }
        }

        /// <summary>
        /// 取得 qRecvMonitor2 的值
        /// </summary>
        private void QryMonitorUpdate2()
        {
            for (int ii = 0; ii < 16; ii ++)
            {
                qRecvMonitor2.buf[ii] = communState.rx.buf[ii];
            }
        }

        /// <summary>
        /// 取得 qRecvParam 的值
        /// </summary>
        private void QryParamUpdate()
        {
            byte b = communState.rx.buf[1];
            if (b == 0xF1)
            {
                int t = ((communState.rx.buf[3] << 8) + (communState.rx.buf[4])) * 10;
                for (int ii = 0; ii < 10; ii++)
                {
                    qRecvParam.buf[t + ii] = communState.rx.buf[ii];
                }
            }
        }

        /// <summary>
        /// 取得 qRecvRecordDisp 的值
        /// </summary>
        private void QryRecordDispUpdate()
        {
            // 說明 :
            // 封包格式
            //  0       1       2       3       4       5       6       7       8       9
            //  0X63    num_H   num_L   D1_H    D1_L    D2_H    D2_L    D3_H    D3_L    Checksum
            int t = ((communState.rx.buf[1] << 8) + (communState.rx.buf[2])) * 10;
            for (int ii = 0; ii < 10; ii++)
            {
                if ((t + ii) < qRecvRecordDisp.buf.Length)
                {
                    qRecvRecordDisp.buf[t + ii] = communState.rx.buf[ii];
                }
            }
        }

        /// <summary>
        /// Real Time Display
        /// </summary>
        private void QryRealTimeDispUpdate()
        {
            while(true)
            {
                if (RealTimeBuf.Read == false)
                {
                    RealTimeBuf.Busy = true;
                    for (int ii = 0; ii < 6; ii++)
                    {
                        RealTimeBuf.buf[RealTimeBuf.pCnt * 6 + ii] = communState.rx.buf[ii];
                    }
                    if (RealTimeBuf.pCnt < 25600-1) RealTimeBuf.pCnt++;
                    break;
                }
                Thread.Sleep(1);    // wait
            }

            if (RealTimeBuf.pCnt > 0)
            {
                RealTimeBuf.Empty = false;
            }

            RealTimeBuf.Busy = false;
        }

        /// <summary>
        /// 取得 Message
        /// </summary>
        private void QryMessageUpdate()
        {
            // 說明 :
            // 封包格式
            // 0        1           2       3
            // 0xAB     dataType    Data    Checksum
            int t = communState.rx.buf[1];
            switch(t)
            {
                case 0x01:
                    t = 0;
                    break;
                case 0x02:
                    t = 4;
                    break;
                case 0x03:
                    t = 8;
                    break;
                case 0x04:
                    t = 12;
                    break;
                case 0x05:
                    t = 16;
                    break;
                case 0x06:
                    t = 20;
                    break;
                case 0x07:
                    t = 24;
                    break;
                case 0x08:
                    t = 28;
                    break;
                default:
                    break;
            }

            for (int ii = 0; ii< 4; ii++)
            {
                if ((t+ii) < QMsg.Buf.Length)
                    QMsg.Buf[t + ii] = communState.rx.buf[ii];
            }
        }

        /// <summary>
        /// 清除 qRecvMonitor 暫存器的值
        /// </summary>
        public void ClearqRecvMonitor()
        {
            for (int ii = 0; ii < qRecvMonitor.buf.Length; ii++)
            {
                qRecvMonitor.buf[ii] = 0;
            }
        }

        /// <summary>
        /// 清除 qRecvMonitor2 暫存器的值
        /// </summary>
        public void ClearqRecvMonitor2()
        {
            for(int ii = 0; ii < qRecvMonitor2.buf.Length; ii++)
            {
                qRecvMonitor2.buf[ii] = 0;
            }
        }

        /// <summary>
        /// 清除 qRecvParam 暫存器的值
        /// </summary>
        public void ClearqRecvParam()
        {
            for (int ii = 0; ii < qRecvParam.buf.Length; ii++)
            {
                qRecvParam.buf[ii] = 0;
            }
        }

        /// <summary>
        /// 清除 qRecvRecordDisp 暫存器的值
        /// </summary>
        public void ClearqRecvRecordDisp()
        {
            for (int ii = 0; ii < qRecvRecordDisp.buf.Length; ii++)
            {
                qRecvRecordDisp.buf[ii] = 0;
            }
        }

        /// <summary>
        /// 清除 Msg 暫存器的值
        /// </summary>
        public void ClearQMessageBuf()
        {
            for (int ii = 0; ii < QMsg.Buf.Length; ii++)
            {
                QMsg.Buf[ii] = 0;
            }
        }

        /// <summary>
        /// 檢查校驗碼
        /// </summary>
        /// <param name="pData"></param>
        /// <param name="len"></param>
        /// <returns></returns>
        private byte CalcCheckSum(byte[] pData, int len)
        {
            byte sum = 0x00;
            short ii = 0;
            for (ii = 0; ii < len; ii++)
            {
                sum += pData[ii];
            }
            sum = (byte)((sum ^ 0xFF) + 1);
            return sum;
        }

    }
}

import turtle
turtle.forward(100)
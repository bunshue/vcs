import turtle
length = 10
angle = 90
turtle.forward(length)
turtle.left(angle)
length = length + 10

turtle.forward(length)
turtle.left(angle)
length = length + 10

turtle.forward(length)
turtle.left(angle)
length = length + 10

turtle.forward(length)
turtle.left(angle)
length = length + 10

turtle.forward(length)
turtle.left(angle)
length = length + 10

turtle.forward(length)
turtle.left(angle)
length = length + 10

turtle.forward(length)
turtle.left(angle)
length = length + 10

turtle.forward(length)
turtle.left(angle)
length = length + 10

turtle.forward(length)
turtle.left(angle)
length = length + 10

turtle.forward(length)
turtle.left(angle)
length = length + 10

turtle.forward(length)
turtle.left(angle)
length = length + 10

turtle.forward(length)
turtle.left(angle)
length = length + 10

turtle.forward(length)
turtle.left(angle)
length = length + 10
turtle.forward(length)
turtle.left(angle)
length = length + 10

turtle.forward(length)
turtle.left(angle)
length = length + 10

turtle.forward(length)
turtle.left(angle)
length = length + 10

turtle.forward(length)
turtle.left(angle)
length = length + 10
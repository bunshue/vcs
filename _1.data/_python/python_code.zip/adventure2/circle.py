import turtle
repeats = 0
while repeats <= 360:
    turtle.forward(1)
    turtle.right(1)
    repeats = repeats + 1
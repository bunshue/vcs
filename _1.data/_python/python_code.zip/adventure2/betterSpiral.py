import turtle
length = 0
angle = 90
while length < 200:
    turtle.forward(length)
    turtle.left(angle)
    length = length + 10
hasBiscuits = raw_input("Do you have any biscuits? ")
if hasBiscuits == "yes":
    print "They look delicious"
else:
    print "I don't believe you"
while True:
    print "I'm in space"
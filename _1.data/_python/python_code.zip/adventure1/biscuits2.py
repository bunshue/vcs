hasBiscuits = raw_input("Do you have any biscuits? ")
if hasBiscuits == "yes":
    print "They look delicious"
    willShare = raw_input("Can I have one? ")
    if willShare == "yes":
        print "Thank you!"
    else:
        print "I guess computers don't eat biscuits anyway..."
else:
    print "I don't believe you"
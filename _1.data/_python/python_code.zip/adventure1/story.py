personName = raw_input("Enter a name: ")
anObject = raw_input("Enter an object: ")
place = raw_input("Enter a place: ")
story = personName + " was walking through " + place + ". " + place + " was not usually very interesting. " + personName + " spotted a small " + anObject + ". Suddenly the " + anObject + " jumped up and ran away. " + personName + " decided not to go to " + place + " again."
print story
yourName = raw_input("What is your name? ")
print "Hello " + yourName
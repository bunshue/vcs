﻿using System;

class ForLoop
{
    public static void Main()
    {
        int i;
        for (i = 1; i < 11; i = i + 1)
        {
            Console.WriteLine("Hello mum");
        }
    }
}






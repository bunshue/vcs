﻿using System;

class CastDemo
{
    static void Main()
    {
        int i = 3, j = 2;
        float fraction;
        fraction = (float)i / (float)j;
        Console.WriteLine("fraction : " + fraction);
    }
}



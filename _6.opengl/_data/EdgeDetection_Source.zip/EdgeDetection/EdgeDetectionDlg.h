// EdgeDetectionDlg.h : header file
//

#pragma once

#include "GLSetup.h"
#include "GLTexture.h"
#include "GLVertexBuffer.h"
#include "GLExtension.h"
#include "GLSLShader.h"

typedef
enum {
    RUN_IN_GPU,
    RUN_IN_CPU
} RUN_IN;


// CEdgeDetectionDlg dialog
class CEdgeDetectionDlg : public CDialog
{
// Construction
public:
	CEdgeDetectionDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	enum { IDD = IDD_EDGEDETECTION_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support


// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	virtual BOOL OnInitDialog();
    virtual void OnCancel();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
    afx_msg void OnBnClickedLoadBMP();

private:
    bool LoadBitmap( CString csFileName_i, GLTexture& Texture_io );
    bool LoadBitmap( const int nResID_i, GLTexture& Texture_io );
    void SetShaderParam();
    void EdgeDetectInCPU();

private:
    GLSetup     m_glSetup; // For initialisation and display with Opengl.
    GLTexture   m_ImageTexture;
    GLTexture   m_EdgeTexture;
    GLSLShader* m_pPixelShader;
    GLVertexBuffer m_VertexBuffer;
    int m_nImageWidth;
    int m_nImageHeight;
    bool m_bCartoonEffect;

    RUN_IN m_nRunIn;
    bool   m_bGPUOk;
public:
//    afx_msg void OnTimeChange();
    afx_msg void OnTimer(UINT_PTR nIDEvent);
    afx_msg void OnBnClickedButton1();
    afx_msg void OnBnClickedRadioCpu();
    afx_msg void OnBnClickedRadioGpu();
    afx_msg void OnBnClickedButton2();
    afx_msg void OnBnClickedCheckCartooneffect();
};

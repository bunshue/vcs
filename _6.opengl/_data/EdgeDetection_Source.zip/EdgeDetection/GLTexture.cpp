#include "StdAfx.h"
#include "GLTexture.h"
#include "GL\Glu.h"

GLTexture::GLTexture(void)
{
	m_nTextureID = 0;
}

GLTexture::~GLTexture(void)
{
	Delete();
}
bool GLTexture::Create(int nWidth, int nHeight, void *pbyData)
{
	if( 0 != m_nTextureID )
	{
		// if this texture already exists then delete it.
		Delete();
	}
	if( 0 == pbyData )
	{
		return false;
	}
	glEnable( GL_TEXTURE_2D );
	glGenTextures( 1, &m_nTextureID );

	glBindTexture( GL_TEXTURE_2D, m_nTextureID );

	glTexParameteri( GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER, GL_LINEAR );
	glTexParameteri( GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER, GL_LINEAR );

	glTexImage2D( GL_TEXTURE_2D, 0, 3, nWidth, nHeight, 0,
		GL_BGR_EXT, GL_UNSIGNED_BYTE, pbyData );

	return ( GL_NO_ERROR == glGetError() );
}

bool GLTexture::GetData( BYTE*& pbyData )
{
    if( m_nTextureID )
    {
        glBindTexture( GL_TEXTURE_2D, m_nTextureID );
        glGetTexImage( GL_TEXTURE_2D, 0,GL_BGR_EXT, GL_UNSIGNED_BYTE, pbyData );
        return true;
    }
    return false;
}
void GLTexture::Delete()
{
	if( 0 != m_nTextureID )
	{
		glDeleteTextures( 1, &m_nTextureID );
		m_nTextureID = 0;
	}
}

void GLTexture::Enable()
{
    glEnable( GL_TEXTURE_2D );
    glBindTexture( GL_TEXTURE_2D, m_nTextureID );
}
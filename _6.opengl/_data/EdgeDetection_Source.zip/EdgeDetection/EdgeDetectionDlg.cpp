// EdgeDetectionDlg.cpp : implementation file
//

#include "stdafx.h"
#include "EdgeDetection.h"
#include "EdgeDetectionDlg.h"
#include "BMPLoader.h"
#include "EdgeDetectCPU.h"
#include "math.h"
#include "AppError.h"
#include "gdiplus.h"
#include "GdiplusImaging.h"
#include "Gdipluspixelformats.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	enum { IDD = IDD_ABOUTBOX };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Implementation
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
END_MESSAGE_MAP()


// CEdgeDetectionDlg dialog




CEdgeDetectionDlg::CEdgeDetectionDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CEdgeDetectionDlg::IDD, pParent)
{
    m_pPixelShader = 0;
    m_bCartoonEffect = true;
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CEdgeDetectionDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CEdgeDetectionDlg, CDialog)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
    ON_BN_CLICKED(IDOK, &CEdgeDetectionDlg::OnBnClickedLoadBMP)
//    ON_WM_TIMECHANGE()
ON_WM_TIMER()
ON_BN_CLICKED(IDC_BUTTON1, &CEdgeDetectionDlg::OnBnClickedButton1)
ON_BN_CLICKED(IDC_RADIO_CPU, &CEdgeDetectionDlg::OnBnClickedRadioCpu)
ON_BN_CLICKED(IDC_RADIO_GPU, &CEdgeDetectionDlg::OnBnClickedRadioGpu)
ON_BN_CLICKED(IDC_BUTTON2, &CEdgeDetectionDlg::OnBnClickedButton2)
ON_BN_CLICKED(IDC_CHECK_CARTOONEFFECT, &CEdgeDetectionDlg::OnBnClickedCheckCartooneffect)
END_MESSAGE_MAP()

ULONG_PTR m_gdiplusToken;
// CEdgeDetectionDlg message handlers

BOOL CEdgeDetectionDlg::OnInitDialog()
{
    Gdiplus::GdiplusStartupInput gdiplusStartupInput;
    Gdiplus::GdiplusStartup(&m_gdiplusToken, &gdiplusStartupInput, NULL);

    m_nRunIn = RUN_IN_GPU;
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

    


    // Setup of Opengl.
    m_glSetup.InitGL( GetDlgItem( IDC_STATIC_RENDER )->m_hWnd );

    if( !m_glSetup.CheckExtension( "GL_ARB_fragment_shader" ))
    {
        AfxMessageBox( L"Your Machine not supports Opengls GL_ARB_fragment_shader" );
        m_nRunIn = RUN_IN_CPU;
    }
    if( !m_glSetup.CheckExtension( "GL_ARB_vertex_shader" ))
    {
        AfxMessageBox( L"Your Machine not supports Opengls GL_ARB_vertex_shader" );
        m_nRunIn = RUN_IN_CPU;
    }
    // After Initialisation of Opegnl, Extensions are loaded.
    TCHAR* pFailedFunction = 0;
    if( !GLExtension::GetInstance()->GetWglProcAddress( pFailedFunction ))
    {
        // Any function pointer is not available.
        if( 0 != pFailedFunction )
        {
            AfxMessageBox( CString( L"wglGetProc failed for :") + pFailedFunction );
            m_nRunIn = RUN_IN_CPU;
        }
    }

    glClearColor( 0.0f, 0.0f, 0.0f, 1.0f );
    glMatrixMode( GL_PROJECTION );
    glLoadIdentity();

    glMatrixMode( GL_MODELVIEW );
    glLoadIdentity();

    // Setup Vertexbuffer.
    m_VertexBuffer.Create( 4 );
    m_VertexBuffer.SetAt( 0, -1.0f,1.0f, 0.0f, 0.0f,0.0f); // Left Top  corner
    m_VertexBuffer.SetAt( 1, -1.0f,-1.0f, 0.0f, 1.0f,0.0f), // Left Bottom
    m_VertexBuffer.SetAt( 2, 1.0f , -1.0f, 0.0f, 1.0f,1.0f); // Right bottom
    m_VertexBuffer.SetAt( 3, 1.0f, 1.0f,  0.0f, 0.0f,1.0f); // Right top

    if( RUN_IN_GPU == m_nRunIn  )
    {
        m_pPixelShader = new GLSLShader();
        if( !m_pPixelShader->CreateProgram( IDR_PIXEL_SHADER, GL_FRAGMENT_PROGRAM_ARB ))
        {
            CString csErrorMessage;
            if( AppError::GetError( csErrorMessage ))
            {
                AfxMessageBox( csErrorMessage );
            }
            else
            {
                AfxMessageBox( L"Unknown Error" );
            }
            m_nRunIn = RUN_IN_CPU;
        }
    }

    // Creating textures from resource.
    LoadBitmap( IDB_BITMAP_TAJ, m_ImageTexture );

    // Create a time for 20 fps display.
    SetTimer( 0, 50, 0 );
    if( RUN_IN_GPU == m_nRunIn )
    {
        ((CButton*)(GetDlgItem( IDC_RADIO_GPU )))->SetCheck( BST_CHECKED );
        SetShaderParam();
    }
    else
    {
        // If GPU not supports, shader then disable radio buttons.
        GetDlgItem( IDC_RADIO_CPU )->EnableWindow( false );
        GetDlgItem( IDC_RADIO_GPU )->EnableWindow( false );
        EdgeDetectInCPU();
        // Convert bitmap to EdgeDetection.
    }
    ((CButton*) GetDlgItem( IDC_CHECK_CARTOONEFFECT ))->SetCheck( BST_CHECKED );
    return TRUE;  // return TRUE  unless you set the focus to a control
}

void CEdgeDetectionDlg::OnCancel()
{
    delete m_pPixelShader;

    GLExtension::DeleteInstance();
    
    CDialog::OnCancel();
}

void CEdgeDetectionDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CEdgeDetectionDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CEdgeDetectionDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}


void CEdgeDetectionDlg::OnBnClickedLoadBMP()
{
    // Create a file open Dialog for openging .bmp file.
    CFileDialog FileOpenDlg( true, 0,L"*.bmp;*.jpg;*.png",4|2, L"*.bmp;*.jpg;*.png" );
    if( IDOK == FileOpenDlg.DoModal())
    {
        CString csFileName = FileOpenDlg.GetPathName();
        LoadBitmap( csFileName, m_ImageTexture );
        if( RUN_IN_CPU == m_nRunIn )
        {
            EdgeDetectInCPU();
        }
    }
}


bool CEdgeDetectionDlg::LoadBitmap( CString csFileName_i, GLTexture& Texture_io )
{
    int nWidth = 0;
    int nHeight = 0;
    BYTE* pbyData = 0;
    BMPLoader BMPLoaderObj;
    if( !BMPLoaderObj.LoadBMP( csFileName_i.GetBuffer( 0 ), nWidth, nHeight, pbyData ))
    {
        AfxMessageBox( L"BMP Loading failed" );
        return false;
    }
    if( 0 == pbyData )
    {
        AfxMessageBox( L"Memory Allocation failed." );
        return FALSE;
    }
    m_nImageWidth = nWidth;
    m_nImageHeight = nHeight;
    if( !Texture_io.Create( nWidth, nHeight, pbyData ))
    {
        AfxMessageBox( L"Texture loading failed" );
        return FALSE;
    }
    delete[] pbyData;
    return true;
}


bool CEdgeDetectionDlg::LoadBitmap( const int nResID_i, GLTexture& Texture_io )
{
    int nWidth = 0;
    int nHeight = 0;
    BYTE* pbyData = 0;
    BMPLoader BMPLoaderObj;
    if( !BMPLoaderObj.LoadBMP( nResID_i, nWidth, nHeight, pbyData ))
    {
        return false;
    }

    m_nImageWidth = nWidth;
    m_nImageHeight = nHeight;
    if( !Texture_io.Create( nWidth, nHeight, pbyData ))
    {
        AfxMessageBox( L"Texture loading failed" );
        return FALSE;
    }
    delete[] pbyData;
    return true;
}


void CEdgeDetectionDlg::OnTimer(UINT_PTR nIDEvent)
{
    // Drawing with gl setup.
    glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );
    m_VertexBuffer.DrawVertexBuffer( GL_QUADS );

    m_glSetup.Draw(); // swap buffers.
    CDialog::OnTimer(nIDEvent);
}

void CEdgeDetectionDlg::OnBnClickedButton1()
{
    CAboutDlg dlg;
    dlg.DoModal();
}

void CEdgeDetectionDlg::OnBnClickedRadioCpu()
{
    if( m_nRunIn == RUN_IN_GPU )
    {
        m_nRunIn = RUN_IN_CPU;
        EdgeDetectInCPU();
    }
}

void CEdgeDetectionDlg::EdgeDetectInCPU()
{
    int nWrappedPixelWidth = ceil( ( (float)m_nImageWidth * 3 ) / 4.0 ) * 4;
    BYTE* pbyImage = new BYTE[nWrappedPixelWidth * m_nImageHeight ];
    m_ImageTexture.GetData( pbyImage );
    if( nWrappedPixelWidth != m_nImageWidth * 3 )
    {
        BYTE* pbyWrapRemovedBuffer = new BYTE[m_nImageWidth * m_nImageHeight * 3 ];
        BYTE* pbyDst = pbyWrapRemovedBuffer;
        BYTE* pbySrc = pbyImage;
        // Need to remove unwanted image at right end.
        for( int nY = 0; nY < m_nImageHeight; nY++ )
        {
            memcpy( pbyDst, pbySrc, m_nImageWidth * 3 );
            pbyDst += m_nImageWidth * 3;
            pbySrc += nWrappedPixelWidth;
        }
        delete[] pbyImage;
        pbyImage = pbyWrapRemovedBuffer;
    }
    EdgeDetectCPU EdgeDetect;
    EdgeDetect.SetCartoonEffect( m_bCartoonEffect );
    EdgeDetect.EdgeDetect( m_nImageWidth, m_nImageHeight, pbyImage );
    if( nWrappedPixelWidth != m_nImageWidth * 3 )
    {
        BYTE* pbyWrapRemovedBuffer = new BYTE[nWrappedPixelWidth * m_nImageHeight ];
        BYTE* pbyDst = pbyWrapRemovedBuffer;
        BYTE* pbySrc = pbyImage;
        // Need to remove unwanted image at right end.
        for( int nY = 0; nY < m_nImageHeight; nY++ )
        {
            memcpy( pbyDst, pbySrc, m_nImageWidth * 3 );
            pbyDst += nWrappedPixelWidth;
            pbySrc += m_nImageWidth * 3;
        }
        delete[] pbyImage;
        pbyImage = pbyWrapRemovedBuffer;
    }
    m_EdgeTexture.Create( m_nImageWidth, m_nImageHeight, pbyImage );
    if( m_pPixelShader )
    {
        m_pPixelShader->DisableShader();
        GLExtension::GetInstance()->glActiveTexture( GL_TEXTURE0 );
    }
    m_EdgeTexture.Enable();
    delete[] pbyImage;
}
void CEdgeDetectionDlg::OnBnClickedRadioGpu()
{
    if( m_nRunIn == RUN_IN_CPU )
    {
        m_nRunIn = RUN_IN_GPU;
        SetShaderParam();
    }
}



void CEdgeDetectionDlg::SetShaderParam()
{
    if( 0 == m_pPixelShader )
    {
        return ;
    }
    m_pPixelShader->EnableShader();
    if( !m_pPixelShader->SetTexture( "ImageTexture", m_ImageTexture.GetTextureID()))
    {
        // AfxMessageBox( L"SetTexture failed" );
    }
    if( !m_pPixelShader->SetParam( "fWidth", m_nImageWidth ))
    {
        //AfxMessageBox( L"SetTexture failed" );
    }

    if( !m_pPixelShader->SetParam( "fHeight", m_nImageHeight ))
    {
        //AfxMessageBox( L"SetTexture failed" );
    }
    if( !m_pPixelShader->SetParam( "fCartoonEffect", (int)m_bCartoonEffect ))
    {
        //AfxMessageBox( L"SetTexture failed" );
    }
}
void CEdgeDetectionDlg::OnBnClickedButton2()
{
    BYTE* pbyData = 0;
    static int nCPUCount = 0;
    static int nGPUCount = 0;
    CString csFileName;
    // This one create different names in CPU mode and GPU mode.
    csFileName.Format( L"EdgeDetection_%s_%d.bmp", ( RUN_IN_CPU == m_nRunIn ) ? L"CPU" : L"GPU",
                                                    ( RUN_IN_CPU == m_nRunIn ) ? ++nCPUCount : ++nGPUCount );
    CFileDialog SaveDlg( false, L"*.bmp", csFileName );
    if( IDOK == SaveDlg.DoModal())
    {
        RECT stImageArea;
        CString csFileName = SaveDlg.GetPathName();
        (GetDlgItem( IDC_STATIC_RENDER ))->GetClientRect( &stImageArea );
        stImageArea.right = ceil( (float)stImageArea.right / 4.0 ) * 4;
        pbyData = new BYTE[stImageArea.bottom * stImageArea.right  * 3];
        if( 0 == pbyData )
        {
            AfxMessageBox( L"Memory Allocation failed" );
            return;
        }
        glReadPixels( 0, 0, stImageArea.right, stImageArea.bottom, GL_BGR_EXT, GL_UNSIGNED_BYTE, pbyData );
        BMPLoader SaveBmp;
        SaveBmp.SaveBMP( csFileName, stImageArea.right, stImageArea.bottom, pbyData );
    }
}

void CEdgeDetectionDlg::OnBnClickedCheckCartooneffect()
{
    m_bCartoonEffect = ((CButton*) GetDlgItem( IDC_CHECK_CARTOONEFFECT ))->GetCheck() == BST_CHECKED;
    if( RUN_IN_CPU == m_nRunIn )
    {
        EdgeDetectInCPU();
    }
    else
    {
        // GPU
        SetShaderParam();
    }
}

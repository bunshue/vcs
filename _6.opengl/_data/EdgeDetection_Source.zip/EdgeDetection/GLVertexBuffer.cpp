#include "StdAfx.h"
#include "GLVertexBuffer.h"


GLVertexBuffer::GLVertexBuffer(void)
{
	m_pVertexBuffer = 0;
	m_nCount = 0;
}

GLVertexBuffer::~GLVertexBuffer(void)
{
	Delete();
}

bool GLVertexBuffer::Create( int nCount_i )
{
	// Delete if already exists.
	Delete();

	m_nCount = nCount_i;
	m_pVertexBuffer = new GLVertex[nCount_i];
	if( 0 == m_pVertexBuffer )
	{
		return false;
	}
	memset( m_pVertexBuffer, 0, sizeof( GLVertex ) * m_nCount );
	return true;

}
void GLVertexBuffer::Delete()
{
	if( m_pVertexBuffer )
	{
		delete[] m_pVertexBuffer;
		m_pVertexBuffer = 0;
	}
}

// Here change vertex information of a particular index.
bool GLVertexBuffer::SetAt( int nIndex_i, float fX_i, float fY_i, float fZ_i, float fTu_i, float fTv_i )
{
	if( nIndex_i >= m_nCount  )
	{
		return false;
	}
	m_pVertexBuffer[nIndex_i].x = fX_i;
	m_pVertexBuffer[nIndex_i].y = fY_i;
	m_pVertexBuffer[nIndex_i].z = fZ_i;
	m_pVertexBuffer[nIndex_i].tu = fTu_i;
	m_pVertexBuffer[nIndex_i].tv = fTv_i;
	return true;
}

void GLVertexBuffer::DrawVertexBuffer( GLenum eDrawPrimitive_i )
{
	glBegin( eDrawPrimitive_i );
	for( int nIndex = 0; nIndex < m_nCount; ++nIndex )
	{
		GLVertex& Temp = m_pVertexBuffer[nIndex];
		glVertex3f( Temp.x, Temp.y, Temp.z );
		glTexCoord2f( Temp.tu, Temp.tv );
	}
	glEnd();
}


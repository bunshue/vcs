#pragma once

#include "GL\gl.h"
// Handle texture related opertions in this class.
class GLTexture
{
public:
	GLTexture(void);
	~GLTexture(void);
	bool Create( int nWidth, int nHeight, void* pbyData );
    bool GetData( BYTE*& pbyData );
	void Delete();
	void Enable();
	void Disable();
    int GetTextureID()
    {
        return m_nTextureID;
    }

private:
	GLuint m_nTextureID;
};

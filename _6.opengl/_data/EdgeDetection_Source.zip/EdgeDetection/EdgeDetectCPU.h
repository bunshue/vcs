#pragma once


struct ImageInfo_t
{
    ImageInfo_t()
    {
        nRows = nCols = 0;
        pData = 0;
    }
    ~ImageInfo_t()
    {
        if( pData )
        {
            delete[] pData;
            pData = 0;
        }
    }
    int nRows; int nCols; unsigned char* pData;
} ;

class EdgeDetectCPU
{
public:
    EdgeDetectCPU(void);
    ~EdgeDetectCPU(void);
    void SetCartoonEffect( const bool bCartoonEffect_i )
    {
        m_bCartoonEffect = bCartoonEffect_i;
    }
    void EdgeDetect( int nWidth, int nHeight, BYTE* pbyBMP_io );

private:

    void FindEdge( ImageInfo_t& stOriginalImage_i, ImageInfo_t& stEdgeImage_o );

    bool m_bCartoonEffect;
};

#include "StdAfx.h"
#include "EdgeDetectCPU.h"
#include "math.h"

EdgeDetectCPU::EdgeDetectCPU(void)
{
    m_bCartoonEffect = false;
}

EdgeDetectCPU::~EdgeDetectCPU(void)
{
}

void EdgeDetectCPU::EdgeDetect( int nWidth, int nHeight, BYTE* pbyBMP_io )
{
    ImageInfo_t originalImageR;
    ImageInfo_t originalImageG;
    ImageInfo_t originalImageB;
    ImageInfo_t OutputRed;
    ImageInfo_t OutputGreen;
    ImageInfo_t OutputBlue;

    originalImageR.nRows = nHeight;
    originalImageR.nCols = nWidth;
    originalImageR.pData = new byte[nWidth * nHeight];

    originalImageG.nRows = nHeight;
    originalImageG.nCols = nWidth;
    originalImageG.pData = new byte[nWidth * nHeight];

    originalImageB.nRows = nHeight;
    originalImageB.nCols = nWidth;
    originalImageB.pData = new byte[nWidth * nHeight];

    // Extract each component[R,G,B] to separate buffer to find gradient in 
    // each component.
    BYTE* pbyTemp = pbyBMP_io;
    for (int n= 0; n < nWidth * nHeight; n++)
    {
        originalImageR.pData[n] = *pbyTemp++; // Blue
        originalImageG.pData[n] = *pbyTemp++; // Green
        originalImageB.pData[n] = *pbyTemp++; // Red
    }

    // Find Gradient of each component separately.
    FindEdge( originalImageR, OutputRed );
    FindEdge( originalImageG, OutputGreen );
    FindEdge( originalImageB, OutputBlue );

    // Combine RGB gradient information to a output buffer.
    pbyTemp = pbyBMP_io;
    for (int n= 0; n < nWidth * nHeight; n++)
    {
        *pbyTemp++ = OutputRed.pData[n];
        *pbyTemp++ = OutputGreen.pData[n];
        *pbyTemp++ = OutputBlue.pData[n];
    }
}

void EdgeDetectCPU::FindEdge( ImageInfo_t& stOriginalImage_i, ImageInfo_t& stEdgeImage_o )
{
    int		nX, nY,I, J;
    long			sumX, sumY;
    int			nColors, SUM;
    int			GX[3][3];
    int			GY[3][3];
    // Allocate output buffer
    stEdgeImage_o.pData = new BYTE[stOriginalImage_i.nCols * stOriginalImage_i.nRows];

    // X Directional Gradient matrix.
    GX[0][0] = -1; GX[0][1] = 0; GX[0][2] = 1;
    GX[1][0] = -2; GX[1][1] = 0; GX[1][2] = 2;
    GX[2][0] = -1; GX[2][1] = 0; GX[2][2] = 1;

    // Y Directional Gradient matrix.
    GY[0][0] =  1; GY[0][1] =  2; GY[0][2] =  1;
    GY[1][0] =  0; GY[1][1] =  0; GY[1][2] =  0;
    GY[2][0] = -1; GY[2][1] = -2; GY[2][2] = -1;

    // Iterate each pixels in the image.
    for(nY=0; nY<=(stOriginalImage_i.nRows-1); nY++)
    {
        for(nX=0; nX<=(stOriginalImage_i.nCols-1); nX++)
        {
            sumX = 0;
            sumY = 0;

            SUM = 0;
            // Skip top,bottom, left and right pixels.
            if( !(nX==0 || nX==stOriginalImage_i.nCols-1 || nY==0 || nY==stOriginalImage_i.nRows-1))
            {
                // Looping to findout change in X direction
                for(I=-1; I<=1; I++)
                {
                    for(J=-1; J<=1; J++)
                    {
                        sumX = sumX + (int)( (*(stOriginalImage_i.pData + nX + I + 
                            (nY + J)*stOriginalImage_i.nCols)) * GX[I+1][J+1]);
                    }
                }

                // Looping to find out change in Y direction
                for(I=-1; I<=1; I++)
                {
                    for(J=-1; J<=1; J++)
                    {
                        sumY = sumY + (int)( (*(stOriginalImage_i.pData + nX + I + 
                            (nY + J)*stOriginalImage_i.nCols)) * GY[I+1][J+1]);
                    }
                }
                SUM =  sqrt(double(sumX * sumX) + double(sumY * sumY));
            }

            if(SUM>255) SUM=255;
            if(SUM<0) SUM=0;
            int nOut = 0;
            // Checking Cartoon Effect flag to create final image.
            if( m_bCartoonEffect )
            {
                // Make Cartoon effect by combining edge information and original image.
                nOut = (SUM * 0.5) + (*(stOriginalImage_i.pData + nX + nY * stOriginalImage_i.nCols) * 0.5);
            }
            else
            {
                // Creating displayable edge data.
                nOut = 255 - (unsigned char)(SUM);
            }
            *(stEdgeImage_o.pData + nX + nY * stOriginalImage_i.nCols) = nOut;
        }
    }
}
/*
** Prototypes
*/

extern GLenum fontCreateStroke(GLuint);
extern GLenum fontCreateOutline(GLuint);
extern GLenum fontCreateFilled(GLuint);
extern GLenum fontCreateBitmap(GLuint);
extern void fontDrawStr(GLuint, char *);

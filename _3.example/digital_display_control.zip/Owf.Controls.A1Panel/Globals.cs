using System;
using System.Collections.Generic;
using System.Text;

namespace Owf.Controls
{
	internal class A1PanelGlobals
	{
		public const string A1Category = "A1";
	}
}

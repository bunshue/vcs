OSWALD = 'Oswald'
CENTER = 'center'

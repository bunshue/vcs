using System;
using System.Management;
using System.Reflection;
using System.Diagnostics;
using EasyWMI.Controllers;
namespace EasyWMI.Models.root.CIMV2
{
    
    
    public class Win32_AutochkSetting : WMIBase
    {
        
        private string m_Caption;
        
        private string m_Description;
        
        private string m_SettingID;
        
        private uint m_UserInputDelay;
        
        private string m_MyPath;
        
        public Win32_AutochkSetting()
        {
        }
        
        public string Caption
        {
            get
            {
                return this.m_Caption;
            }
            set
            {
                this.m_Caption = value;
            }
        }
        
        public string Description
        {
            get
            {
                return this.m_Description;
            }
            set
            {
                this.m_Description = value;
            }
        }
        
        public string SettingID
        {
            get
            {
                return this.m_SettingID;
            }
            set
            {
                this.m_SettingID = value;
            }
        }
        
        public uint UserInputDelay
        {
            get
            {
                return this.m_UserInputDelay;
            }
            set
            {
                this.m_UserInputDelay = value;
            }
        }
        
        public string MyPath
        {
            get
            {
                return this.m_MyPath;
            }
            set
            {
                this.m_MyPath = value;
            }
        }
    }
}

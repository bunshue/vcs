using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace TimerDemo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            timer1_Tick(this, null);
            timer1.Interval = 1000; // �]�w�C��Ĳ�o�@��
            timer1.Enabled = true; // �Ұ� Timer
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            DateTime time = DateTime.Now;
//            label1.Text = time.TimeOfDay.ToString();
            label1.Text = time.Hour + ":" + time.Minute + ":" + time.Second;
        }
    }
}
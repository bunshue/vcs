namespace Tester
{
	partial class Form1
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			this.timer1 = new System.Windows.Forms.Timer(this.components);
			this.vistaProgressBar3 = new Owf.Controls.VistaProgressBar();
			this.vistaProgressBar2 = new Owf.Controls.VistaProgressBar();
			this.vistaProgressBar1 = new Owf.Controls.VistaProgressBar();
			this.SuspendLayout();
			// 
			// timer1
			// 
			this.timer1.Enabled = true;
			this.timer1.Interval = 10;
			this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
			// 
			// vistaProgressBar3
			// 
			this.vistaProgressBar3.BackColor = System.Drawing.Color.Transparent;
			this.vistaProgressBar3.Location = new System.Drawing.Point(53, 104);
			this.vistaProgressBar3.Name = "vistaProgressBar3";
			this.vistaProgressBar3.Size = new System.Drawing.Size(351, 16);
			this.vistaProgressBar3.TabIndex = 0;
			this.vistaProgressBar3.Theme = Owf.Controls.VistaProgressBarTheme.Blue;
			this.vistaProgressBar3.Value = 70F;
			// 
			// vistaProgressBar2
			// 
			this.vistaProgressBar2.BackColor = System.Drawing.Color.Transparent;
			this.vistaProgressBar2.Location = new System.Drawing.Point(53, 52);
			this.vistaProgressBar2.Name = "vistaProgressBar2";
			this.vistaProgressBar2.Size = new System.Drawing.Size(351, 16);
			this.vistaProgressBar2.TabIndex = 0;
			this.vistaProgressBar2.Theme = Owf.Controls.VistaProgressBarTheme.Green;
			this.vistaProgressBar2.Value = 50F;
			// 
			// vistaProgressBar1
			// 
			this.vistaProgressBar1.BackColor = System.Drawing.Color.Transparent;
			this.vistaProgressBar1.Location = new System.Drawing.Point(53, 78);
			this.vistaProgressBar1.Name = "vistaProgressBar1";
			this.vistaProgressBar1.Size = new System.Drawing.Size(351, 16);
			this.vistaProgressBar1.TabIndex = 0;
			this.vistaProgressBar1.Theme = Owf.Controls.VistaProgressBarTheme.Red;
			this.vistaProgressBar1.Value = 30F;
			// 
			// Form1
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.White;
			this.ClientSize = new System.Drawing.Size(483, 203);
			this.Controls.Add(this.vistaProgressBar3);
			this.Controls.Add(this.vistaProgressBar2);
			this.Controls.Add(this.vistaProgressBar1);
			this.Name = "Form1";
			this.Text = "Form1";
			this.Load += new System.EventHandler(this.Form1_Load);
			this.ResumeLayout(false);

		}

		#endregion

		private Owf.Controls.VistaProgressBar vistaProgressBar1;
		private System.Windows.Forms.Timer timer1;
		private Owf.Controls.VistaProgressBar vistaProgressBar2;
		private Owf.Controls.VistaProgressBar vistaProgressBar3;
	}
}


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Tester
{
	public partial class Form1 : Form
	{
		public Form1()
		{
			InitializeComponent();
		}

		private void Form1_Load(object sender, EventArgs e)
		{

		}

		private void timer1_Tick(object sender, EventArgs e)
		{
			Do();
		}

		void Do()
		{
			if (this.InvokeRequired)
			{
				this.Invoke(new MethodInvoker(Do));
			}
			else
			{
				if (this.vistaProgressBar1.Value >= 100)
					this.vistaProgressBar1.Value = 1;

				if (this.vistaProgressBar2.Value >= 100)
					this.vistaProgressBar2.Value = 1;

				if (this.vistaProgressBar3.Value >= 100)
					this.vistaProgressBar3.Value = 1;

				this.vistaProgressBar1.Value += 0.1F;
				this.vistaProgressBar2.Value += 0.1F;
				this.vistaProgressBar3.Value += 0.1F;
			}
		}
	}
}
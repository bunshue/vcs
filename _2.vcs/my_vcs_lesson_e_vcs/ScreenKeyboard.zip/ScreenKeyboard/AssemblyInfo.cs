﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Screen Keyboard")]
[assembly: AssemblyDescription("Screen Keyboard, developed by \r\n\r\n优哉＠游哉")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("http://www.cnblogs.com/Youzai")]
[assembly: AssemblyProduct("Screen Keyboard")]
[assembly: AssemblyCopyright("Copyright (C) 优哉＠游哉 2008")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: ComVisible(false)]

[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Runtime.InteropServices;
using System.IO;
using System.Drawing.Imaging;

namespace howto_backer
{
    public partial class Form1 : Form
    {
        [DllImport("user32.dll", SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        static extern bool SystemParametersInfo(uint uiAction, uint uiParam, String pvParam, uint fWinIni);

        private const uint SPI_SETDESKWALLPAPER = 0x14;
        private const uint SPIF_UPDATEINIFILE = 0x1;
        private const uint SPIF_SENDWININICHANGE = 0x2;

        public Form1()
        {
            InitializeComponent();
        }

        // The list of files we will pick from.
        private List<string> FileNames = new List<string>();

        // Get ready.
        private void Form1_Load(object sender, EventArgs e)
        {
            // Restore the previous settings.
            if (Properties.Settings.Default.PictureDirectory == "")
                txtDirectory.Text = Application.StartupPath;
            else
                txtDirectory.Text = Properties.Settings.Default.PictureDirectory;
            chkUpdateRegistry.Checked = Properties.Settings.Default.UpdateRegistry;
            Location = Properties.Settings.Default.Location;
            Size = Properties.Settings.Default.Size;
            txtDelay.Text = Properties.Settings.Default.Delay.ToString();

            // Give the ellipsis button's image a transparent background.
            MakeButtonTransparent(btnPickDirectory);
        }

        // Save settings.
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            SaveSettings();
        }

        // Give the button a transparent background.
        private void MakeButtonTransparent(Button btn)
        {
            Bitmap bm = (Bitmap)btn.Image;
            bm.MakeTransparent(bm.GetPixel(0, 0));
            btn.Image = bm;
        }

        // See: Search for files that match multiple patterns in C#
        //      http://csharphelper.com/blog/2015/06/find-files-that-match-multiple-patterns-in-c/
        // Search for files matching the patterns.
        private List<string> FindFiles(string dir_name, string patterns, bool search_subdirectories)
        {
            // Make the result list.
            List<string> files = new List<string>();

            // Get the patterns.
            string[] pattern_array = patterns.Split(';');

            // Search.
            SearchOption search_option = SearchOption.TopDirectoryOnly;
            if (search_subdirectories) search_option = SearchOption.AllDirectories;
            foreach (string pattern in pattern_array)
            {
                foreach (string filename in Directory.GetFiles(dir_name, pattern, search_option))
                {
                    if (!files.Contains(filename)) files.Add(filename);
                }
            }

            // Sort.
            files.Sort();

            // Return the result.
            return files;
        }

        // Apply the current settings.
        private void btnApply_Click(object sender, EventArgs e)
        {
            // Save the current settings.
            SaveSettings();

            // Load the list of files.
            if (Directory.Exists(txtDirectory.Text))
                FileNames = FindFiles(txtDirectory.Text,
                    "*.bmp;*.png;*.jpg;*.tif;*.gif", false);
            else
                FileNames = new List<string>();

            // Set the Timer's Interval.
            int delay = int.Parse(txtDelay.Text);
            tmrNewImage.Interval = 1000 * delay;
            tmrNewImage.Enabled = (FileNames.Count > 0);

            // Display the first picture.
            if (tmrNewImage.Enabled) ChangeDesktopPicture();
        }

        // Save the current settings.
        private void SaveSettings()
        {
            Properties.Settings.Default.PictureDirectory = txtDirectory.Text;
            Properties.Settings.Default.UpdateRegistry = chkUpdateRegistry.Checked;
            Properties.Settings.Default.Location = Location;
            Properties.Settings.Default.Size = Size;

            int delay;
            if (!int.TryParse(txtDelay.Text, out delay)) delay = 120;
            if (delay < 0) delay = 120;
            txtDelay.Text = delay.ToString();
            Properties.Settings.Default.Delay = delay;

            Properties.Settings.Default.Save();
        }

        // Display a random image.
        private Random Rand = new Random();
        private void tmrNewImage_Tick(object sender, EventArgs e)
        {
            ChangeDesktopPicture();
        }

        // Display a random image.
        private void ChangeDesktopPicture()
        {
            // Repeat until we succeed or run out of files.
            for (; ; )
            {
                // Pick a random image.
                int file_num = Rand.Next(FileNames.Count);

                // Try to use that image.
                try
                {
                    DisplayPicture(FileNames[file_num], chkUpdateRegistry.Checked);
                    break;
                }
                catch
                {
                    // This file doesn't work. Remove it from the list.
                    FileNames.RemoveAt(file_num);

                    // If there are no more files, stop trying.
                    if (FileNames.Count == 0)
                    {
                        tmrNewImage.Enabled = false;
                        break;
                    }
                }
            }
        }

        // Display the file on the desktop.
        private void DisplayPicture(string file_name, bool update_registry)
        {
            // If we should update the registry,
            // set the appropriate flags.
            uint flags = 0;
            if (update_registry)
                flags = SPIF_UPDATEINIFILE | SPIF_SENDWININICHANGE;

            // Set the desktop background to this file.
            if (!SystemParametersInfo(SPI_SETDESKWALLPAPER,
                0, file_name, flags))
            {
                MessageBox.Show("SystemParametersInfo failed.",
                    "Error", MessageBoxButtons.OK,
                    MessageBoxIcon.Exclamation);
            }
        }

        // Let the user select a picture directory.
        private void btnPickDirectory_Click(object sender, EventArgs e)
        {
            fbdDirectory.SelectedPath = txtDirectory.Text;
            if (fbdDirectory.ShowDialog() == DialogResult.OK)
                txtDirectory.Text = fbdDirectory.SelectedPath;
        }
    }
}

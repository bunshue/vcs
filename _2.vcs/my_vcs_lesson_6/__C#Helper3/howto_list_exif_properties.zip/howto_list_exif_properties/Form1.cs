﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_list_exif_properties
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void mnuFileOpen_Click(object sender, EventArgs e)
        {
            if (ofdFile.ShowDialog() == DialogResult.OK)
            {
                // Open the file.
                using (Bitmap bm = new Bitmap(ofdFile.FileName))
                {
                    // Get EXIF property data.
                    List<ExifStuff.ExifPropertyData> property_data
                        = ExifStuff.GetExifProperties(bm);

                    // Display the property information.
                    List<string> results = new List<string>();
                    foreach (ExifStuff.ExifPropertyData data in property_data)
                    {
                        ListViewItem item = lvwProperties.Items.Add(
                            data.PropertyType.ToString());
                        item.SubItems.Add(data.Id.ToString());
                        item.SubItems.Add(data.DataType.ToString());
                        item.SubItems.Add(data.DataLength.ToString());
                        item.SubItems.Add(data.DataString);
                    }
                }
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Drawing.Drawing2D;

namespace howto_line_filled_ellipse
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Drawing objects.
        private const int EllipseMargin = 10;
        private int EllipseCx, EllipseCy, EllipseWidth, EllipseHeight;
        private List<PointF> LinePoints = null;

        // Redraw on resize.
        private void Form1_Load(object sender, EventArgs e)
        {
            this.ResizeRedraw = true;

            // Make the initial drawing objects.
            MakeDrawingObjects();
        }

        // The form has resized. Generate the drawing objects.
        private void Form1_Resize(object sender, EventArgs e)
        {
            MakeDrawingObjects();
        }

        // Make the drawing objects.
        private void MakeDrawingObjects()
        {
            // Calculate the ellipse parameters.
            EllipseWidth = this.ClientSize.Width - 2 * EllipseMargin;
            EllipseHeight = this.ClientSize.Height - 2 * EllipseMargin;

            // Make random lines connecting points
            // on the edge of the ellipse.
            EllipseCx = this.ClientSize.Width / 2;
            EllipseCy = this.ClientSize.Height / 2;
            Random rand = new Random();
            double circumference = 2 * Math.PI * Math.Sqrt(
                (EllipseWidth * EllipseWidth + EllipseHeight * EllipseHeight) / 2);
            int num_points = (int)(circumference / 40);
            LinePoints = new List<PointF>();
            for (int i = 0; i < num_points; i++)
            {
                double theta1 = 2 * Math.PI * rand.NextDouble();
                float x1 = (float)(EllipseCx + Math.Cos(theta1) * EllipseWidth / 2);
                float y1 = (float)(EllipseCy + Math.Sin(theta1) * EllipseHeight / 2);
                LinePoints.Add(new PointF(x1, y1));

                double theta2 = 2 * Math.PI * rand.NextDouble();
                float x2 = (float)(EllipseCx + Math.Cos(theta2) * EllipseWidth / 2);
                float y2 = (float)(EllipseCy + Math.Sin(theta2) * EllipseHeight / 2);
                LinePoints.Add(new PointF(x2, y2));
            }
        }

        // Draw the ellipse and lines.
        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            if ((EllipseWidth <= 0) || (EllipseHeight <= 0)) return;

            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;

            // Fill and outline the ellipse.
            e.Graphics.FillEllipse(Brushes.LightBlue,
                EllipseMargin, EllipseMargin, EllipseWidth, EllipseHeight);
            e.Graphics.DrawEllipse(Pens.Blue,
                EllipseMargin, EllipseMargin, EllipseWidth, EllipseHeight);

            // Draw the lines.
            e.Graphics.DrawLines(Pens.Blue, LinePoints.ToArray());
        }
    }
}

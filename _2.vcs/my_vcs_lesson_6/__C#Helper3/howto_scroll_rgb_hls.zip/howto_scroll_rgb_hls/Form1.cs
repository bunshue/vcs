﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_scroll_rgb_hls
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            scrRGB_Scroll(null, null);
        }

        // Select a new RGB color.
        private void scrRGB_Scroll(object sender, ScrollEventArgs e)
        {
            // Save the selected color and display a sample.
            int R = scrR.Value;
            int G = scrG.Value;
            int B = scrB.Value;
            picSample.BackColor = Color.FromArgb(R, G, B);

            // Convert to HLS.
            double H, L, S;
            ColorStuff.RgbToHls(R, G, B, out H, out L, out S);

            // Display HLS values.
            scrH.Value = (int)H;
            scrL.Value = (int)(L * 1000);
            scrS.Value = (int)(S * 1000);

            ShowNumericValues(R, G, B, H, L, S);
        }

        // Select a new HLS color.
        private void scrHLS_Scroll(object sender, ScrollEventArgs e)
        {
            // Convert into RGB.
            double H = scrH.Value;
            double L = scrL.Value / 1000.0;
            double S = scrS.Value / 1000.0;
            int R, G, B;
            ColorStuff.HlsToRgb(H, L, S, out R, out G, out B);

            // Display RGB values.
            scrR.Value = R;
            scrG.Value = G;
            scrB.Value = B;

            // Save the selected color and display a sample.
            picSample.BackColor = Color.FromArgb(R, G, B);

            ShowNumericValues(R, G, B, H, L, S);
        }

        private void ShowNumericValues(int R, int G, int B, double H, double L, double S)
        {
            txtR.Text = R.ToString();
            txtG.Text = G.ToString();
            txtB.Text = B.ToString();
            txtH.Text = H.ToString("0");
            txtL.Text = L.ToString("0.00");
            txtS.Text = S.ToString("0.00");
        }
    }
}

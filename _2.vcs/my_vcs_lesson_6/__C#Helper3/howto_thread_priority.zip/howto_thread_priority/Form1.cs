﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Threading;

namespace howto_thread_priority
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Start threads with different priorities.
        private void btnRunThreads_Click(object sender, EventArgs e)
        {
            int num_low = int.Parse(txtNumLow.Text);
            for (int i = 0; i < num_low; i++)
                MakeThread("Low" + i.ToString(),
                    ThreadPriority.BelowNormal);

            int num_normal = int.Parse(txtNumNormal.Text);
            for (int i = 0; i < num_normal; i++)
                MakeThread("Normal" + i.ToString(),
                    ThreadPriority.Normal);

            int num_high = int.Parse(txtNumHigh.Text);
            for (int i = 0; i < num_high; i++)
                MakeThread("High" + i.ToString(),
                    ThreadPriority.AboveNormal);
        }

        // Make a thread with the indicated priority.
        private void MakeThread(string thread_name, ThreadPriority thread_priority)
        {
            // Initialize the thread.
            Counter new_counter = new Counter(thread_name);
            Thread thread = new Thread(new_counter.Run);
            thread.Priority = thread_priority;
            thread.IsBackground = true;
            thread.Name = thread_name;

            // Start the thread.
            thread.Start();
        }
    }
}

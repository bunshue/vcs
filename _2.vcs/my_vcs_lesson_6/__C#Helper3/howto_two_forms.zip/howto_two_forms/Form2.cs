﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_two_forms
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        // A variable that refers to the instance of Form2.
        // Note that it's public.
        public Form1 TheForm1;

        // Switch to TheForm1.
        private void btnForm1_Click(object sender, EventArgs e)
        {
            this.Hide();
            TheForm1.Show();
        }

        private void Form2_FormClosing(object sender, FormClosingEventArgs e)
        {
            // Approach 1: Close the startup form.
            //TheForm1.Close();

            // Approach 2: Hide this form instead of closing it.
            this.Hide();
            TheForm1.Show();
            e.Cancel = true;
        }
    }
}

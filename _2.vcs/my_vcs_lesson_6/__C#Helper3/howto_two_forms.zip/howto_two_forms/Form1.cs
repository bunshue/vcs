﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_two_forms
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // A variable that refers to the instance of Form2.
        private Form2 TheForm2;

        // Initialize the form variables.
        private void Form1_Load(object sender, EventArgs e)
        {
            // Make the Form2.
            TheForm2 = new Form2();

            // Initialize the Form2's variable.
            TheForm2.TheForm1 = this;

            // Make both forms stay on top.
            this.TopMost = true;
            TheForm2.TopMost = true;
        }

        // Switch to the Form2.
        private void btnForm2_Click(object sender, EventArgs e)
        {
            this.Hide();
            TheForm2.Show();
        }
    }
}

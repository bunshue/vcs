﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Drawing.Drawing2D;

namespace howto_drag_scroll_image
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void mnuFileExit_Click(object sender, EventArgs e)
        {
            Close();
        }

        private Bitmap OriginalImage;
        private float CurrentScale;
        private Bitmap VisibleImage = null;
        private Graphics VisibleGraphics = null;

        // Upper left corner of the image in the PictureBox.
        private int PicX = 0, PicY = 0;

        // Initially display at full scale.
        private void Form1_Load(object sender, EventArgs e)
        {
            // Use a grabbing hand cursor.
            picMap.Cursor = new Cursor("hand2.cur");

            // Get the map image.
            OriginalImage = Properties.Resources.Map;

            // Get ready to draw.
            PrepareGraphics();

            // Start at full scale.
            mnuScale_Click(mnuScaleFull, null);
        }

        // Make a display Bitmap and Graphics.
        private void Form1_Resize(object sender, EventArgs e)
        {
            PrepareGraphics();
            DrawMap();
        }

        private void PrepareGraphics()
        {
            // Skip it if we've been minimized.
            if ((picMap.ClientSize.Width == 0) ||
                (picMap.ClientSize.Height == 0)) return;

            // Free old resources.
            if (VisibleGraphics != null)
            {
                picMap.Image = null;
                VisibleGraphics.Dispose();
                VisibleImage.Dispose();
            }

            // Make the new Bitmap and Graphics.
            VisibleImage = new Bitmap(
                picMap.ClientSize.Width,
                picMap.ClientSize.Height);
            VisibleGraphics = Graphics.FromImage(VisibleImage);
            VisibleGraphics.InterpolationMode = InterpolationMode.High;

            // Display the Bitmap.
            picMap.Image = VisibleImage;
        }

        // Set the scale.
        private void mnuScale_Click(object sender, EventArgs e)
        {
            // Check the selected scale item.
            ToolStripMenuItem item = sender as ToolStripMenuItem;
            foreach (ToolStripMenuItem menu_item in mnuScale.DropDownItems)
                menu_item.Checked = (menu_item == item);

            // Set the selected scale.
            CurrentScale = float.Parse(item.Tag.ToString());

            // Draw.
            DrawMap();
        }

        // Set the PictureBox's position.
        private void SetOrigin()
        {
            // Keep x and y within bounds.
            float scaled_width = CurrentScale * OriginalImage.Width;
            int xmin = (int)(picMap.ClientSize.Width - scaled_width);
            if (xmin > 0) xmin = 0;
            if (PicX < xmin) PicX = xmin;
            else if (PicX > 0) PicX = 0;

            float scaled_height = CurrentScale * OriginalImage.Height;
            int ymin = (int)(picMap.ClientSize.Height - scaled_height);
            if (ymin > 0) ymin = 0;
            if (PicY < ymin) PicY = ymin;
            else if (PicY > 0) PicY = 0;
        }

        // Draw the image at the correct scale and location.
        private void DrawMap()
        {
            // Validate PicX and PicY.
            SetOrigin();

            // Get the destination area.
            float scaled_width = CurrentScale * OriginalImage.Width;
            float scaled_height = CurrentScale * OriginalImage.Height;
            PointF[] dest_points =
            {
                new PointF(PicX, PicY),
                new PointF(PicX + scaled_width, PicY),
                new PointF(PicX, PicY + scaled_height),
            };

            // Draw the whole image.
            RectangleF source_rect = new RectangleF(
                0, 0, OriginalImage.Width, OriginalImage.Height);

            // Draw.
            VisibleGraphics.Clear(picMap.BackColor);
            VisibleGraphics.DrawImage(OriginalImage,
                dest_points, source_rect, GraphicsUnit.Pixel);

            // Update the display.
            picMap.Refresh();
        }
    
        // Let the user drag the image around.
        private bool Dragging = false;
        private int LastX, LastY;

        private void picMap_MouseDown(object sender, MouseEventArgs e)
        {
            LastX = e.X;
            LastY = e.Y;
            Dragging = true;
        }

        private void picMap_MouseMove(object sender, MouseEventArgs e)
        {
            if (!Dragging) return;
            
            PicX += e.X - LastX;
            PicY += e.Y - LastY;
            LastX = e.X;
            LastY = e.Y;

            DrawMap();
        }

        private void picMap_MouseUp(object sender, MouseEventArgs e)
        {
            Dragging = false;
        }
    }
}

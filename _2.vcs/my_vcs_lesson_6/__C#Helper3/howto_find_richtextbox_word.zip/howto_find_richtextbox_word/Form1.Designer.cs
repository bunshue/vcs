﻿namespace howto_find_richtextbox_word
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtWord = new System.Windows.Forms.TextBox();
            this.rchText = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // txtWord
            // 
            this.txtWord.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtWord.Location = new System.Drawing.Point(12, 84);
            this.txtWord.Name = "txtWord";
            this.txtWord.Size = new System.Drawing.Size(310, 20);
            this.txtWord.TabIndex = 3;
            // 
            // rchText
            // 
            this.rchText.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.rchText.Location = new System.Drawing.Point(12, 12);
            this.rchText.Name = "rchText";
            this.rchText.Size = new System.Drawing.Size(310, 66);
            this.rchText.TabIndex = 2;
            this.rchText.Text = "Outside of a dog, a book is man\'s best friend. Inside of a dog it\'s too dark to r" +
                "ead. -- Groucho Marx";
            this.rchText.MouseMove += new System.Windows.Forms.MouseEventHandler(this.rchText_MouseMove);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(334, 116);
            this.Controls.Add(this.txtWord);
            this.Controls.Add(this.rchText);
            this.Name = "Form1";
            this.Text = "howto_find_richtextbox_word";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtWord;
        private System.Windows.Forms.RichTextBox rchText;
    }
}


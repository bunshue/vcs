﻿// #define DEBUGGING

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_cannon_game
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // http://hyperphysics.phy-astr.gsu.edu/hbase/traj.html#tra4
        // Distance: 2 * V^2 * Sin(T) * Cos(T) / g = V^2 * Sin(2*T) / g

        private const int XMAX = 500;
        private const int YMAX = 500;

        private const int HOUSE_HGT = 10;
        private const int HOUSE_WID = 14;
        private const int OVERHANG = 4;
        private const int CANNON_LEN = 20;
        private const int CANNON_HGT = 7;

        private int HouseX, HouseY;
        private double Theta, BulletX, BulletY, Vx, Vy;

        private const int TICKS_PER_SECOND = 10;

        // Acceleration in meters per tick squared.
        private const double YAcceleration =
            9.8 / (TICKS_PER_SECOND * TICKS_PER_SECOND);

        // Initialize.
        private void Form1_Load(object sender, EventArgs e)
        {
            tmrMoveShot.Enabled = false;
            tmrMoveShot.Interval = 1000 / TICKS_PER_SECOND;
            MoveHouse();

            DrawField(picCanvas.CreateGraphics());
        }

        // Launch a cannonball.
        private void btnShoot_Click(object sender, EventArgs e)
        {
            // Redraw.
            using (Graphics gr = picCanvas.CreateGraphics())
            {
                DrawField(gr);
            }

            // Get the speed.
            float speed;
            try
            {
                speed = float.Parse(txtSpeed.Text);
            }
            catch
            {
                MessageBox.Show("Invalid speed", "Invalid Speed",
                    MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
            if (speed < 1)
            {
                MessageBox.Show("Speed must be at least 1 mps",
                    "Invalid Speed", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }

            // Get the speed components in meters per tick.
            Vx = speed * Math.Cos(Theta) / TICKS_PER_SECOND;
            Vy = -speed * Math.Sin(Theta) / TICKS_PER_SECOND;   // Negative to go up.

            // Disable UI elements.
            btnShoot.Enabled = false;
            txtDegrees.Enabled = false;
            txtSpeed.Enabled = false;
            Cursor = Cursors.WaitCursor;
            Application.DoEvents();

#if DEBUGGING
            // Draw the location where the cannon ball
            // should pass the Y position where it started.
            // Distance = 2 * V^2 * Sin(T) * Cos(T) / g = V^2 * Sin(2*T) / g
            gr.DrawEllipse(Pens.Blue,
                (float)(BulletX + 2 * speed * speed * Math.Sin(Theta) * Math.Cos(Theta) / 9.8),
                (float)(BulletY), CANNON_HGT, CANNON_HGT);
#endif

            // Start moving the cannon ball.
            tmrMoveShot.Enabled = true;
        }

        private void picCanvas_Paint(object sender, PaintEventArgs e)
        {
            DrawField(e.Graphics);
        }

        // Draw the field.
        private void DrawField(Graphics gr)
        {
            gr.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            gr.Clear(picCanvas.BackColor);

            // Draw the house.
            Point[] pts = new Point[7];
            pts[0] = new Point(HouseX, HouseY);
            pts[1] = new Point(pts[0].X, pts[0].Y - HOUSE_HGT);
            pts[2] = new Point(pts[1].X - OVERHANG, pts[1].Y);
            pts[3] = new Point(pts[2].X + OVERHANG + HOUSE_WID / 2, pts[2].Y - OVERHANG - HOUSE_WID / 2);
            pts[4] = new Point(pts[3].X + OVERHANG + HOUSE_WID / 2, pts[2].Y);
            pts[5] = new Point(pts[4].X - OVERHANG, pts[1].Y);
            pts[6] = new Point(pts[5].X, pts[0].Y);
            gr.FillPolygon(Brushes.White, pts);
            gr.DrawPolygon(Pens.Blue, pts);

            // Draw the cannon.
            try
            {
                Theta = double.Parse(txtDegrees.Text) * Math.PI / 180;
            }
            catch
            {
                Theta = 0;
            }
            if (Theta > Math.PI / 2) Theta = Math.PI / 2;
            if (Theta < 0) Theta = 0;

            int cx = 10 + CANNON_HGT / 2;
            int cy = YMAX - 10 - CANNON_HGT / 2;

            pts = new Point[4];
            pts[0] = new Point(
                cx - (int)(CANNON_HGT * Math.Cos(Math.PI / 2 - Theta) / 2),
                cy - (int)(CANNON_HGT * Math.Sin(Math.PI / 2 - Theta) / 2));
            pts[1] = new Point(
                pts[0].X + (int)(CANNON_LEN * Math.Cos(Theta)),
                (int)(pts[0].Y - CANNON_LEN * Math.Sin(Theta)));
            pts[2] = new Point(
                pts[1].X + (int)(CANNON_HGT * Math.Cos(Math.PI / 2 - Theta)),
                pts[1].Y + (int)(CANNON_HGT * Math.Sin(Math.PI / 2 - Theta)));
            pts[3] = new Point(
                pts[2].X - (int)(CANNON_LEN * Math.Cos(Theta)),
                pts[2].Y + (int)(CANNON_LEN * Math.Sin(Theta)));
            gr.FillPolygon(Brushes.Gray, pts);
            gr.DrawPolygon(Pens.Black, pts);

            gr.FillPie(Brushes.Black,
                cx - CANNON_HGT,
                (float)(cy - CANNON_HGT / 2),
                CANNON_HGT * 2, CANNON_HGT * 2, 180, 180);

            BulletX = pts[1].X + CANNON_HGT * Math.Cos(Math.PI / 2 - Theta) / 2 + CANNON_HGT * Math.Cos(Theta) * 0.6;
            BulletY = pts[1].Y - CANNON_HGT * Math.Sin(Math.PI / 2 - Theta) / 2 - CANNON_HGT * Math.Sin(Theta) * 0.6;
        }

        private void MoveHouse()
        {
            Random rnd = new Random();
            HouseX = rnd.Next((XMAX * 2) / 3, (int)(XMAX - HOUSE_WID - OVERHANG));
            HouseY = rnd.Next((YMAX * 3) / 4, YMAX - 3);
        }

        private void tmrMoveShot_Tick(object sender, EventArgs e)
        {
            // Erase the cannon ball's previous position.
            using (Graphics gr = picCanvas.CreateGraphics())
            {
                using (Brush br = new SolidBrush(picCanvas.BackColor))
                {
                    gr.FillEllipse(br, (float)(BulletX), (float)(BulletY),
                        CANNON_HGT, CANNON_HGT);
                }

                // Move the cannon ball.
                Vy += YAcceleration;
                BulletX += Vx;
                BulletY += Vy;

                // Draw the new cannon ball.
                gr.FillEllipse(Brushes.Black,
                    (float)(BulletX), (float)(BulletY),
                    CANNON_HGT, CANNON_HGT);

                // See if we should stop.
                if ((BulletY > picCanvas.ClientRectangle.Height) ||
                    (BulletX > picCanvas.ClientRectangle.Width))
                {
                    // Stop running.
                    tmrMoveShot.Enabled = false;

                    // Re-enable UI elements.
                    btnShoot.Enabled = true;
                    txtDegrees.Enabled = true;
                    txtSpeed.Enabled = true;
                    Cursor = Cursors.Default;
                }
            }
        }

        private void txtDegrees_TextChanged(object sender, EventArgs e)
        {
            DrawField(picCanvas.CreateGraphics());
        }

        private void txtSpeed_TextChanged(object sender, EventArgs e)
        {
            DrawField(picCanvas.CreateGraphics());
        }
    }
}

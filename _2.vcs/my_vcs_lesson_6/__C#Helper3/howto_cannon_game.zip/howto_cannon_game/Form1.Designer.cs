﻿namespace howto_cannon_game
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.picCanvas = new System.Windows.Forms.PictureBox();
            this.tmrMoveShot = new System.Windows.Forms.Timer(this.components);
            this.btnShoot = new System.Windows.Forms.Button();
            this.Label1_1 = new System.Windows.Forms.Label();
            this.Label1_0 = new System.Windows.Forms.Label();
            this.txtSpeed = new System.Windows.Forms.TextBox();
            this.txtDegrees = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.picCanvas)).BeginInit();
            this.SuspendLayout();
            // 
            // picCanvas
            // 
            this.picCanvas.BackColor = System.Drawing.SystemColors.Control;
            this.picCanvas.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.picCanvas.Cursor = System.Windows.Forms.Cursors.Default;
            this.picCanvas.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.picCanvas.ForeColor = System.Drawing.SystemColors.ControlText;
            this.picCanvas.Location = new System.Drawing.Point(1, 50);
            this.picCanvas.Name = "picCanvas";
            this.picCanvas.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.picCanvas.Size = new System.Drawing.Size(493, 491);
            this.picCanvas.TabIndex = 23;
            this.picCanvas.TabStop = false;
            this.picCanvas.Paint += new System.Windows.Forms.PaintEventHandler(this.picCanvas_Paint);
            // 
            // tmrMoveShot
            // 
            this.tmrMoveShot.Tick += new System.EventHandler(this.tmrMoveShot_Tick);
            // 
            // btnShoot
            // 
            this.btnShoot.BackColor = System.Drawing.SystemColors.Control;
            this.btnShoot.Cursor = System.Windows.Forms.Cursors.Default;
            this.btnShoot.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnShoot.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnShoot.Location = new System.Drawing.Point(138, 11);
            this.btnShoot.Name = "btnShoot";
            this.btnShoot.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnShoot.Size = new System.Drawing.Size(49, 25);
            this.btnShoot.TabIndex = 22;
            this.btnShoot.Text = "Shoot";
            this.btnShoot.UseVisualStyleBackColor = false;
            this.btnShoot.Click += new System.EventHandler(this.btnShoot_Click);
            // 
            // Label1_1
            // 
            this.Label1_1.BackColor = System.Drawing.SystemColors.Control;
            this.Label1_1.Cursor = System.Windows.Forms.Cursors.Default;
            this.Label1_1.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label1_1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Label1_1.Location = new System.Drawing.Point(2, 30);
            this.Label1_1.Name = "Label1_1";
            this.Label1_1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.Label1_1.Size = new System.Drawing.Size(81, 17);
            this.Label1_1.TabIndex = 20;
            this.Label1_1.Text = "Speed (m/s)";
            // 
            // Label1_0
            // 
            this.Label1_0.BackColor = System.Drawing.SystemColors.Control;
            this.Label1_0.Cursor = System.Windows.Forms.Cursors.Default;
            this.Label1_0.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label1_0.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Label1_0.Location = new System.Drawing.Point(2, 4);
            this.Label1_0.Name = "Label1_0";
            this.Label1_0.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.Label1_0.Size = new System.Drawing.Size(88, 17);
            this.Label1_0.TabIndex = 18;
            this.Label1_0.Text = "Angle (degrees)";
            // 
            // txtSpeed
            // 
            this.txtSpeed.AcceptsReturn = true;
            this.txtSpeed.BackColor = System.Drawing.SystemColors.Window;
            this.txtSpeed.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtSpeed.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSpeed.ForeColor = System.Drawing.SystemColors.WindowText;
            this.txtSpeed.Location = new System.Drawing.Point(96, 27);
            this.txtSpeed.MaxLength = 0;
            this.txtSpeed.Name = "txtSpeed";
            this.txtSpeed.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.txtSpeed.Size = new System.Drawing.Size(33, 20);
            this.txtSpeed.TabIndex = 21;
            this.txtSpeed.Text = "50";
            this.txtSpeed.TextChanged += new System.EventHandler(this.txtSpeed_TextChanged);
            // 
            // txtDegrees
            // 
            this.txtDegrees.AcceptsReturn = true;
            this.txtDegrees.BackColor = System.Drawing.SystemColors.Window;
            this.txtDegrees.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtDegrees.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDegrees.ForeColor = System.Drawing.SystemColors.WindowText;
            this.txtDegrees.Location = new System.Drawing.Point(96, 1);
            this.txtDegrees.MaxLength = 0;
            this.txtDegrees.Name = "txtDegrees";
            this.txtDegrees.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.txtDegrees.Size = new System.Drawing.Size(33, 20);
            this.txtDegrees.TabIndex = 19;
            this.txtDegrees.Text = "45";
            this.txtDegrees.TextChanged += new System.EventHandler(this.txtDegrees_TextChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(495, 543);
            this.Controls.Add(this.picCanvas);
            this.Controls.Add(this.btnShoot);
            this.Controls.Add(this.Label1_1);
            this.Controls.Add(this.Label1_0);
            this.Controls.Add(this.txtSpeed);
            this.Controls.Add(this.txtDegrees);
            this.Name = "Form1";
            this.Text = "howto_cannon_game";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.picCanvas)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.PictureBox picCanvas;
        internal System.Windows.Forms.Timer tmrMoveShot;
        public System.Windows.Forms.Button btnShoot;
        public System.Windows.Forms.Label Label1_1;
        public System.Windows.Forms.Label Label1_0;
        public System.Windows.Forms.TextBox txtSpeed;
        public System.Windows.Forms.TextBox txtDegrees;
    }
}


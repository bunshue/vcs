﻿namespace howto_move_click_mouse
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnMoveClick = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnMoveClick
            // 
            this.btnMoveClick.Location = new System.Drawing.Point(12, 12);
            this.btnMoveClick.Name = "btnMoveClick";
            this.btnMoveClick.Size = new System.Drawing.Size(104, 32);
            this.btnMoveClick.TabIndex = 2;
            this.btnMoveClick.Text = "Move && Click";
            this.btnMoveClick.UseVisualStyleBackColor = true;
            this.btnMoveClick.Click += new System.EventHandler(this.btnMoveClick_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(333, 161);
            this.Controls.Add(this.btnMoveClick);
            this.Name = "Form1";
            this.Text = "howto_move_click_mouse";
            this.Paint += new System.Windows.Forms.PaintEventHandler(this.Form1_Paint);
            this.Click += new System.EventHandler(this.Form1_Click);
            this.ResumeLayout(false);

        }

        #endregion

        internal System.Windows.Forms.Button btnMoveClick;
    }
}


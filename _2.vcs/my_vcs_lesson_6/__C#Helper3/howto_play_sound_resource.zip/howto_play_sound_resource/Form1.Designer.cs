﻿namespace howto_play_sound_resource
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.radFrog = new System.Windows.Forms.RadioButton();
            this.radDog = new System.Windows.Forms.RadioButton();
            this.radChicks = new System.Windows.Forms.RadioButton();
            this.radBees = new System.Windows.Forms.RadioButton();
            this.radNo = new System.Windows.Forms.RadioButton();
            this.SuspendLayout();
            // 
            // radFrog
            // 
            this.radFrog.AutoSize = true;
            this.radFrog.Image = global::howto_play_sound_resource.Properties.Resources.Frog;
            this.radFrog.Location = new System.Drawing.Point(188, 136);
            this.radFrog.Name = "radFrog";
            this.radFrog.Size = new System.Drawing.Size(112, 66);
            this.radFrog.TabIndex = 9;
            this.radFrog.TabStop = true;
            this.radFrog.UseVisualStyleBackColor = true;
            this.radFrog.Click += new System.EventHandler(this.radFrog_Click);
            // 
            // radDog
            // 
            this.radDog.AutoSize = true;
            this.radDog.Image = global::howto_play_sound_resource.Properties.Resources.Dog;
            this.radDog.Location = new System.Drawing.Point(63, 122);
            this.radDog.Name = "radDog";
            this.radDog.Size = new System.Drawing.Size(104, 94);
            this.radDog.TabIndex = 8;
            this.radDog.TabStop = true;
            this.radDog.UseVisualStyleBackColor = true;
            this.radDog.Click += new System.EventHandler(this.radDog_Click);
            // 
            // radChicks
            // 
            this.radChicks.AutoSize = true;
            this.radChicks.Image = global::howto_play_sound_resource.Properties.Resources.Chicks;
            this.radChicks.Location = new System.Drawing.Point(238, 12);
            this.radChicks.Name = "radChicks";
            this.radChicks.Size = new System.Drawing.Size(114, 106);
            this.radChicks.TabIndex = 7;
            this.radChicks.TabStop = true;
            this.radChicks.UseVisualStyleBackColor = true;
            this.radChicks.Click += new System.EventHandler(this.radChicks_Click);
            // 
            // radBees
            // 
            this.radBees.AutoSize = true;
            this.radBees.Image = global::howto_play_sound_resource.Properties.Resources.Bees;
            this.radBees.Location = new System.Drawing.Point(118, 15);
            this.radBees.Name = "radBees";
            this.radBees.Size = new System.Drawing.Size(114, 101);
            this.radBees.TabIndex = 6;
            this.radBees.TabStop = true;
            this.radBees.UseVisualStyleBackColor = true;
            this.radBees.Click += new System.EventHandler(this.radBees_Click);
            // 
            // radNo
            // 
            this.radNo.Image = global::howto_play_sound_resource.Properties.Resources.No;
            this.radNo.Location = new System.Drawing.Point(12, 19);
            this.radNo.Name = "radNo";
            this.radNo.Size = new System.Drawing.Size(100, 93);
            this.radNo.TabIndex = 5;
            this.radNo.TabStop = true;
            this.radNo.UseVisualStyleBackColor = true;
            this.radNo.Click += new System.EventHandler(this.radNo_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(362, 224);
            this.Controls.Add(this.radNo);
            this.Controls.Add(this.radFrog);
            this.Controls.Add(this.radDog);
            this.Controls.Add(this.radChicks);
            this.Controls.Add(this.radBees);
            this.Name = "Form1";
            this.Text = "howto_play_sound_resource";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RadioButton radNo;
        private System.Windows.Forms.RadioButton radFrog;
        private System.Windows.Forms.RadioButton radDog;
        private System.Windows.Forms.RadioButton radChicks;
        private System.Windows.Forms.RadioButton radBees;


    }
}


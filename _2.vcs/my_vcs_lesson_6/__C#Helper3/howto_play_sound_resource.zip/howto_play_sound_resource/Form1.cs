﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Media;
using System.IO;

namespace howto_play_sound_resource
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // The player making the current sound.
        private SoundPlayer Player = null;

        private void radNo_Click(object sender, EventArgs e)
        {
            PlayWav(null, true);
        }

        private void radBees_Click(object sender, EventArgs e)
        {
            PlayWav(Properties.Resources.BeesSound, true);
        }

        private void radChicks_Click(object sender, EventArgs e)
        {
            PlayWav(Properties.Resources.ChicksSound, true);
        }

        private void radDog_Click(object sender, EventArgs e)
        {
            PlayWav(Properties.Resources.DogSound, false);
        }

        private void radFrog_Click(object sender, EventArgs e)
        {
            PlayWav(Properties.Resources.FrogSound, false);
        }

        // Dispose of the current player and
        // play the indicated WAV file.
        private void PlayWav(Stream stream, bool play_looping)
        {
            // Stop the player if it is running.
            if (Player != null)
            {
                Player.Stop();
                Player.Dispose();
                Player = null;
            }

            // If we have no stream, we're done.
            if (stream == null) return;

            // Make the new player for the WAV stream.
            Player = new SoundPlayer(stream);

            // Play.
            if (play_looping)
                Player.PlayLooping();
            else
                Player.Play();
        }
    }
}

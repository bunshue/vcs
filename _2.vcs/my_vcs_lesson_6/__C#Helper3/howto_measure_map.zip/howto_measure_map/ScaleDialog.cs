﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

// At design time, set txtScaleLength.Modifiers = Public.

namespace howto_measure_map
{
    public partial class ScaleDialog : Form
    {
        public ScaleDialog()
        {
            InitializeComponent();
        }
    }
}

﻿namespace howto_adjust_gamma
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.picOriginal = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.picAdjusted = new System.Windows.Forms.PictureBox();
            this.scrGamma = new System.Windows.Forms.HScrollBar();
            this.lblGamma = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.picOriginal)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picAdjusted)).BeginInit();
            this.SuspendLayout();
            // 
            // picOriginal
            // 
            this.picOriginal.Image = global::howto_adjust_gamma.Properties.Resources.JackOLanterns;
            this.picOriginal.Location = new System.Drawing.Point(12, 31);
            this.picOriginal.Name = "picOriginal";
            this.picOriginal.Size = new System.Drawing.Size(300, 400);
            this.picOriginal.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.picOriginal.TabIndex = 0;
            this.picOriginal.TabStop = false;
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(9, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(303, 19);
            this.label1.TabIndex = 1;
            this.label1.Text = "Original";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(315, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(303, 19);
            this.label2.TabIndex = 3;
            this.label2.Text = "Adjusted";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // picAdjusted
            // 
            this.picAdjusted.Image = global::howto_adjust_gamma.Properties.Resources.JackOLanterns;
            this.picAdjusted.Location = new System.Drawing.Point(318, 31);
            this.picAdjusted.Name = "picAdjusted";
            this.picAdjusted.Size = new System.Drawing.Size(300, 400);
            this.picAdjusted.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.picAdjusted.TabIndex = 2;
            this.picAdjusted.TabStop = false;
            // 
            // scrGamma
            // 
            this.scrGamma.Location = new System.Drawing.Point(318, 434);
            this.scrGamma.Maximum = 50;
            this.scrGamma.Minimum = 1;
            this.scrGamma.Name = "scrGamma";
            this.scrGamma.Size = new System.Drawing.Size(300, 17);
            this.scrGamma.TabIndex = 4;
            this.scrGamma.Value = 1;
            this.scrGamma.Scroll += new System.Windows.Forms.ScrollEventHandler(this.scrGamma_Scroll);
            // 
            // lblGamma
            // 
            this.lblGamma.Location = new System.Drawing.Point(315, 460);
            this.lblGamma.Name = "lblGamma";
            this.lblGamma.Size = new System.Drawing.Size(303, 19);
            this.lblGamma.TabIndex = 5;
            this.lblGamma.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(631, 487);
            this.Controls.Add(this.lblGamma);
            this.Controls.Add(this.scrGamma);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.picAdjusted);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.picOriginal);
            this.Name = "Form1";
            this.Text = "howto_adjust_gamma";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.picOriginal)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picAdjusted)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox picOriginal;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox picAdjusted;
        private System.Windows.Forms.HScrollBar scrGamma;
        private System.Windows.Forms.Label lblGamma;
    }
}


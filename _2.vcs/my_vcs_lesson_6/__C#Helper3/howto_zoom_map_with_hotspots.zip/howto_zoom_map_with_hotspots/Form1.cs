﻿// #define DRAW_HOTSPOTS

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Drawing.Drawing2D;

namespace howto_zoom_map_with_hotspots
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // The map.
        private Bitmap Map;

        // The hotspots.
        private List<Rectangle> Hotspots = new List<Rectangle>();

        // The current scale.
        private float MapScale;

        // Exit.
        private void mnuFileExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        // Prepare the map for first viewing.
        private void Form1_Load(object sender, EventArgs e)
        {
            // Initialize the hotspots.
            Hotspots.Add(new Rectangle(88, 509, 22, 22));
            Hotspots.Add(new Rectangle(140, 577, 20, 20));
            Hotspots.Add(new Rectangle(161, 609, 20, 20));
            Hotspots.Add(new Rectangle(630, 138, 20, 20));
            Hotspots.Add(new Rectangle(447, 626, 20, 20));
            Hotspots.Add(new Rectangle(966, 179, 20, 20));
            Hotspots.Add(new Rectangle(958, 214, 20, 20));
            Hotspots.Add(new Rectangle(1062, 301, 20, 20));
            Hotspots.Add(new Rectangle(1109, 581, 20, 20));
            Hotspots.Add(new Rectangle(1099, 621, 20, 20));
            Hotspots.Add(new Rectangle(1247, 262, 20, 16));
            Hotspots.Add(new Rectangle(1314, 224, 20, 20));
            Hotspots.Add(new Rectangle(1344, 651, 20, 20));
            Hotspots.Add(new Rectangle(1098, 753, 20, 20));
            Hotspots.Add(new Rectangle(655, 797, 20, 20));
            Hotspots.Add(new Rectangle(549, 846, 20, 20));
            Hotspots.Add(new Rectangle(449, 935, 20, 20));
            Hotspots.Add(new Rectangle(826, 876, 20, 20));
            Hotspots.Add(new Rectangle(991, 930, 20, 20));
            Hotspots.Add(new Rectangle(1095, 900, 20, 20));
            Hotspots.Add(new Rectangle(1249, 942, 20, 20));
            Hotspots.Add(new Rectangle(254, 1079, 20, 20));
            Hotspots.Add(new Rectangle(298, 1110, 20, 20));
            Hotspots.Add(new Rectangle(1234, 1076, 16, 18));

            // If we should draw the hotspots, add them to the map.
            Map = Properties.Resources.GCMap;

#if DRAW_HOTSPOTS
            using (Graphics gr = Graphics.FromImage(Map))
            {
                foreach (Rectangle hotspot in Hotspots)
                {
                    gr.FillRectangle(Brushes.Blue, hotspot);
                }
            }
#endif

            // Display the initial map.
            picMap.SizeMode = PictureBoxSizeMode.Zoom;
            picMap.Image = Map;

            // Start at small scale.
            SetMapScale(mnuScale4);
        }

        // Scale the map.
        private void mnuScaleMap_Click(object sender, EventArgs e)
        {
            SetMapScale(sender as ToolStripMenuItem);
        }
        private void SetMapScale(ToolStripMenuItem checked_item)
        {
            // Select the correct menu item.
            foreach (ToolStripMenuItem item in
                scaleToolStripMenuItem.DropDownItems)
                    item.Checked = (item == checked_item);

            // Scale the map.
            MapScale = float.Parse(checked_item.Tag.ToString());
            picMap.Size = new Size(
                (int)(Map.Width * MapScale),
                (int)(Map.Height * MapScale));
        }

        // See if we're over a hotspot.
        private void picMap_MouseMove(object sender, MouseEventArgs e)
        {
            // See if we're over a hotspot.
            if (HotspotAtPoint(e.Location) >= 0)
                picMap.Cursor = Cursors.Hand;
            else
                picMap.Cursor = Cursors.Default;
        }

        // See if we clicked a hotspot.
        private void picMap_MouseClick(object sender, MouseEventArgs e)
        {
            int i = HotspotAtPoint(e.Location);
            if (i >= 0) MessageBox.Show("You clicked hotspot " + i);
        }

        // Return the index of the hotspot at this point
        // or -1 if there is no hotspot there.
        private int HotspotAtPoint(Point mouse_point)
        {
            // Adjust for the current map scale.
            mouse_point = new Point(
                (int)(mouse_point.X / MapScale),
                (int)(mouse_point.Y / MapScale));

            // Check the hotspots.
            //return Hotspots.FindIndex(hotspot => hotspot.Contains(mouse_point));

            for (int i = 0; i < Hotspots.Count; i++)
                if (Hotspots[i].Contains(mouse_point)) return i;

            // We didn't find a hotspot that contains the point.
            return -1;
        }

        // Display a hotspot definition in the Output window.
        private void mnuMakeHotspot_Click(object sender, EventArgs e)
        {
            picMap.MouseMove -= picMap_MouseMove;
            picMap.MouseClick -= picMap_MouseClick;
            picMap.MouseDown += makeHotspot_MouseDown;
            picMap.Cursor = Cursors.Cross;
        }

        // Begin defining a hotspot.
        private Point HotspotStart, HotspotEnd;
        private Bitmap HotspotBm;
        private Graphics HotspotGr;
        private void makeHotspot_MouseDown(object sender, MouseEventArgs e)
        {
            HotspotStart = e.Location;
            picMap.MouseDown -= makeHotspot_MouseDown;
            picMap.MouseMove += makeHotspot_MouseMove;
            picMap.MouseUp += makeHotspot_MouseUp;

            // Get ready to draw a selection rectangle.
            HotspotBm = (Bitmap)Map.Clone();
            HotspotGr = Graphics.FromImage(HotspotBm);
            picMap.Image = HotspotBm;
        }

        // Draw a selection rectangle.
        private void makeHotspot_MouseMove(object sender, MouseEventArgs e)
        {
            // Save the new point.
            HotspotEnd = e.Location;

            // Draw the selection rectangle.
            HotspotGr.DrawImage(Map, 0, 0);
            float x = Math.Min(HotspotStart.X, HotspotEnd.X) * MapScale;
            float y = Math.Min(HotspotStart.Y, HotspotEnd.Y) * MapScale;
            float wid = Math.Abs(HotspotStart.X - HotspotEnd.X) * MapScale;
            float hgt = Math.Abs(HotspotStart.Y - HotspotEnd.Y) * MapScale;
            using (Pen thin_pen = new Pen(Color.Red, 1 * MapScale))
            {
                thin_pen.DashStyle = DashStyle.Dash;
                HotspotGr.DrawRectangle(thin_pen, x, y, wid, hgt);
            }

            picMap.Refresh();
        }

        // Finish defining a hotspot.
        private void makeHotspot_MouseUp(object sender, MouseEventArgs e)
        {
            // End hotspot definition mode.
            picMap.MouseMove -= makeHotspot_MouseMove;
            picMap.MouseUp -= makeHotspot_MouseUp;
            picMap.MouseMove += picMap_MouseMove;
            picMap.MouseClick += picMap_MouseClick;
            picMap.Image = Map;
            picMap.Cursor = Cursors.Default;
            picMap.Refresh();

            // Display the hotspot definition.
            float x = Math.Min(HotspotStart.X, HotspotEnd.X) * MapScale;
            float y = Math.Min(HotspotStart.Y, HotspotEnd.Y) * MapScale;
            float wid = Math.Abs(HotspotStart.X - HotspotEnd.X) * MapScale;
            float hgt = Math.Abs(HotspotStart.Y - HotspotEnd.Y) * MapScale;
            Console.WriteLine(
                "            Hotspots.Add(new Rectangle({0}, {1}, {2}, {3}));",
                (int)x, (int)y, (int)wid, (int)hgt);
        }
    }
}

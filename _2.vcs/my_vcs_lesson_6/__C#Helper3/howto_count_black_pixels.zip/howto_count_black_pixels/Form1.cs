﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_count_black_pixels
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Count the black and white pixels.
        private void btnCount_Click(object sender, EventArgs e)
        {
            Bitmap bm = new Bitmap(picImage.Image);
            int black_pixels = CountPixels(bm, Color.FromArgb(255, 0, 0, 0));
            int white_pixels = CountPixels(bm, Color.FromArgb(255, 255, 255, 255));
            lblBlack.Text = black_pixels + " black pixels";
            lblWhite.Text = white_pixels + " white pixels";
            lblTotal.Text = white_pixels + black_pixels + " total pixels";
        }

        // Return the number of matching pixels.
        private int CountPixels(Bitmap bm, Color target_color)
        {
            // Loop through the pixels.
            int matches = 0;
            for (int y = 0; y < bm.Height; y++)
            {
                for (int x = 0; x < bm.Width; x++)
                {
                    if (bm.GetPixel(x, y) == target_color) matches++;
                }
            }
            return matches;
        }
    }
}

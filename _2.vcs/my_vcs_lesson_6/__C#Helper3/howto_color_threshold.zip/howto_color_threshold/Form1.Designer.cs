﻿namespace howto_color_threshold
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.scrThreshold = new System.Windows.Forms.HScrollBar();
            this.label2 = new System.Windows.Forms.Label();
            this.picAdjusted = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.picOriginal = new System.Windows.Forms.PictureBox();
            this.lblThreshold = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.picAdjusted)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picOriginal)).BeginInit();
            this.SuspendLayout();
            // 
            // scrThreshold
            // 
            this.scrThreshold.Location = new System.Drawing.Point(9, 241);
            this.scrThreshold.Maximum = 109;
            this.scrThreshold.Name = "scrThreshold";
            this.scrThreshold.Size = new System.Drawing.Size(424, 17);
            this.scrThreshold.TabIndex = 22;
            this.scrThreshold.Value = 1;
            this.scrThreshold.Scroll += new System.Windows.Forms.ScrollEventHandler(this.scrThreshold_Scroll);
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(225, 8);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(208, 19);
            this.label2.TabIndex = 21;
            this.label2.Text = "Adjusted";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // picAdjusted
            // 
            this.picAdjusted.Location = new System.Drawing.Point(225, 30);
            this.picAdjusted.Name = "picAdjusted";
            this.picAdjusted.Size = new System.Drawing.Size(208, 208);
            this.picAdjusted.TabIndex = 20;
            this.picAdjusted.TabStop = false;
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(11, 8);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(208, 19);
            this.label1.TabIndex = 19;
            this.label1.Text = "Original";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // picOriginal
            // 
            this.picOriginal.Image = global::howto_color_threshold.Properties.Resources.Rod;
            this.picOriginal.Location = new System.Drawing.Point(11, 30);
            this.picOriginal.Name = "picOriginal";
            this.picOriginal.Size = new System.Drawing.Size(208, 208);
            this.picOriginal.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.picOriginal.TabIndex = 18;
            this.picOriginal.TabStop = false;
            // 
            // lblThreshold
            // 
            this.lblThreshold.Location = new System.Drawing.Point(8, 258);
            this.lblThreshold.Name = "lblThreshold";
            this.lblThreshold.Size = new System.Drawing.Size(425, 19);
            this.lblThreshold.TabIndex = 24;
            this.lblThreshold.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(443, 289);
            this.Controls.Add(this.lblThreshold);
            this.Controls.Add(this.scrThreshold);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.picAdjusted);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.picOriginal);
            this.Name = "Form1";
            this.Text = "howto_color_threshold";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.picAdjusted)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picOriginal)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.HScrollBar scrThreshold;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox picAdjusted;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox picOriginal;
        private System.Windows.Forms.Label lblThreshold;
    }
}


﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_transparent_button_background
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Give the second button's image a transparent background.
        private void Form1_Load(object sender, EventArgs e)
        {
            // Give three buttons transparent backgrounds.
            MakeButtonTransparent(btnTransparent1);
            MakeButtonTransparent(btnTransparent2);

            // Make the labels display only borders.
            lblRegular.Text = "";
            lblTransparent.Text = "";
            lblRegular.BackColor = Color.Transparent;
            lblTransparent.BackColor = Color.Transparent;

            // (Alternatively just hide them.)
            lblRegular.Visible = false;
            lblTransparent.Visible = false;
        }

        // Give the button a transparent background.
        private void MakeButtonTransparent(Button btn)
        {
            Bitmap bm = (Bitmap)btn.Image;
            bm.MakeTransparent(bm.GetPixel(0, 0));
        }

        // Draw sideways text.
        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            using (StringFormat string_format = new StringFormat())
            {
                string_format.Alignment = StringAlignment.Center;
                string_format.LineAlignment = StringAlignment.Center;

                e.Graphics.TextRenderingHint =
                    System.Drawing.Text.TextRenderingHint.AntiAliasGridFit;
                DrawSidewaysText(e.Graphics, Font, Brushes.Black,
                    lblRegular.Bounds, string_format, "Regular");
                DrawSidewaysText(e.Graphics, Font, Brushes.Black,
                    lblTransparent.Bounds, string_format, "Transparent");
            }
        }

        // Draw sideways text in the indicated rectangle.
        private void DrawSidewaysText(Graphics gr, Font font, Brush brush, Rectangle bounds, StringFormat string_format, string txt)
        {
            // Make a rotated rectangle at the origin.
            Rectangle rotated_bounds = new Rectangle(
                0, 0, bounds.Height, bounds.Width);

            // Rotate.
            gr.ResetTransform();
            gr.RotateTransform(-90);

            // Translate to move the rectangle to the correct position.
            gr.TranslateTransform(bounds.Left, bounds.Bottom, System.Drawing.Drawing2D.MatrixOrder.Append);

            // Draw the text.
            gr.DrawString(txt, font, brush, rotated_bounds, string_format);
        }
    }
}

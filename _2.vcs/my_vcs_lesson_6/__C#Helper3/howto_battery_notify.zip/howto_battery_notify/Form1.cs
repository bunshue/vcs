﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_battery_notify
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // The last displayed charge percent.
        private int Percent = -1;

        // Hide the form.
        private void Form1_Load(object sender, EventArgs e)
        {
            FormBorderStyle = FormBorderStyle.None;
            Size = new Size(0, 0);
            ShowInTaskbar = false;
            WindowState = FormWindowState.Minimized;
            Hide();

            ShowStatus();
        }

        private void tmrCheckStatus_Tick(object sender, EventArgs e)
        {
            ShowStatus();
        }

        // Update the battery status.
        private void ShowStatus()
        {
            // Get the current charge percent.
            PowerStatus status = SystemInformation.PowerStatus;
            int percent = (int)(status.BatteryLifePercent * 100);

            // If the percent is unchanged, do nothing.
            if (Percent == percent) return;
            Percent = percent;

            // Display the status in the NotifyIcon's text.
            niBatteryStatus.Text = percent.ToString() +
                "% " + status.PowerLineStatus.ToString();

            // Change the icon.
            // Draw the battery image.
            int wid = picIcon.ClientSize.Width / 2;
            int hgt = picIcon.ClientSize.Height;
            Bitmap battery_bm = BatteryStuff.DrawBattery(
                percent / 100f,
                wid, hgt,
                Color.Transparent, Color.Black,
                Color.Lime, Color.White,
                true);

            // Convert the battery image into a square icon.
            Bitmap square_bm = new Bitmap(hgt, hgt);
            using (Graphics gr = Graphics.FromImage(square_bm))
            {
                gr.Clear(Color.Transparent);
                Point[] dest =
                {
                    new Point((int)(0.5 * wid), 0),
                    new Point((int)(1.5 * wid), 0),
                    new Point((int)(0.5 * wid), hgt),
                };
                Rectangle source = new Rectangle(0, 0, wid, hgt);
                gr.DrawImage(battery_bm,
                    dest, source, GraphicsUnit.Pixel);
            }
            picIcon.Image = square_bm;

            // Convert the bitmap into an icon.
            Icon icon = Icon.FromHandle(square_bm.GetHicon());
            niBatteryStatus.Icon = icon;
        }

        private void ctxExit_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}

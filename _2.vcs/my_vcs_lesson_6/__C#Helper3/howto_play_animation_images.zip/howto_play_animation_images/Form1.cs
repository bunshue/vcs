﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_play_animation_images
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // The frame images.
        private Bitmap[] Frames;

        // The index of the current frame.
        private int FrameNum = 0;

        // Load the images.
        private void Form1_Load(object sender, EventArgs e)
        {
            // Load the frames.
            Frames = new Bitmap[18];
            for (int i = 0; i < 18; i++)
            {
                Frames[i] = new Bitmap("Frame" + i + ".png");
            }

            // Display the first frame.
            picFrame.Image = Frames[FrameNum];

            // Size the form to fit.
            ClientSize = new Size(
                picFrame.Right + picFrame.Left,
                picFrame.Bottom + picFrame.Left);
        }

        // Set the delay per frame.
        private void hscrFps_Scroll(object sender, ScrollEventArgs e)
        {
            tmrNextFrame.Interval = 1000 / hscrFps.Value;
            lblFps.Text = hscrFps.Value.ToString();
        }

        // Start or stop the animation.
        private void btnStartStop_Click(object sender, EventArgs e)
        {
            tmrNextFrame.Enabled = !tmrNextFrame.Enabled;
            if (tmrNextFrame.Enabled) btnStartStop.Text = "Stop";
            else btnStartStop.Text = "Start";
        }

        // Display the next image.
        private void tmrNextFrame_Tick(object sender, EventArgs e)
        {
            FrameNum = ++FrameNum % Frames.Length;
            picFrame.Image = Frames[FrameNum];
        }
    }
}

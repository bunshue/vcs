﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Media;

namespace howto_play_wav_files
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // The player making the current sound.
        private SoundPlayer Player = null;

        // Turn on the appropriate wav file.
        private void radNo_Click(object sender, EventArgs e)
        {
            PlayWav(null, false);
        }

        private void radBees_Click(object sender, EventArgs e)
        {
            PlayWav("Bees.wav", true);
        }

        private void radChicks_Click(object sender, EventArgs e)
        {
            PlayWav("Chicks.wav", true);
        }

        private void radDog_Click(object sender, EventArgs e)
        {
            PlayWav("Dog.wav", false);
        }

        private void radFrog_Click(object sender, EventArgs e)
        {
            PlayWav("Frog.wav", false);
        }

        // Dispose of the current player and
        // play the indicated WAV file.
        private void PlayWav(string filename, bool play_looping)
        {
            // Stop the player if it is running.
            if (Player != null)
            {
                Player.Stop();
                Player.Dispose();
                Player = null;
            }

            // If we have no file name, we're done.
            if (filename == null) return;
            if (filename.Length == 0) return;

            // Make the new player for the WAV file.
            Player = new SoundPlayer(filename);

            // Play.
            if (play_looping)
                Player.PlayLooping();
            else
                Player.Play();
        }
    }
}

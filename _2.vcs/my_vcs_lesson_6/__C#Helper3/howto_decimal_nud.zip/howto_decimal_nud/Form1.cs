﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Drawing.Drawing2D;

namespace howto_decimal_nud
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Redraw on resize.
        private void Form1_Load(object sender, EventArgs e)
        {
            ResizeRedraw = true;
            nudScale.Minimum = 0;
            nudScale.Maximum = 1;
            nudScale.DecimalPlaces = 2;
            nudScale.Increment = 0.01m;
        }

        // Redraw.
        private void nudScale_ValueChanged(object sender, EventArgs e)
        {
            Refresh();
        }

        // Draw an ellipse.
        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;

            // Get the ellipse's size as a fraction of the form's width and height.
            float width = (float)(ClientSize.Width * nudScale.Value);
            float height = (float)(ClientSize.Height * nudScale.Value);

            // Draw the ellipse.
            float x = (ClientSize.Width - width) / 2;
            float y = (ClientSize.Height - height) / 2;
            e.Graphics.DrawEllipse(Pens.Red, x, y, width, height);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Xml;

namespace howto_get_currency_rates
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Get the currency symbols.
        private void Form1_Load(object sender, EventArgs e)
        {
            string url = "http://finance.yahoo.com/webservice/" +
                "v1/symbols/allcurrencies/quote?format=xml";
            try
            {
                // Load the data.
                XmlDocument doc = new XmlDocument();
                doc.Load(url);

                // Process the resource nodes.
                XmlNode root = doc.DocumentElement;
                string xquery = "descendant::resource[@classname='Quote']";
                foreach (XmlNode node in root.SelectNodes(xquery))
                {
                    const string name_query = "descendant::field[@name='name']";
                    const string price_query = "descendant::field[@name='price']";
                    string name = node.SelectSingleNode(name_query).InnerText;
                    string price = node.SelectSingleNode(price_query).InnerText;
                    decimal inverse = 1m / decimal.Parse(price);

                    ListViewItem item = lvwPrices.Items.Add(name);
                    item.SubItems.Add(price);
                    item.SubItems.Add(inverse.ToString("f6"));
                }

                // Sort.
                lvwPrices.Sorting = SortOrder.Ascending;
                lvwPrices.FullRowSelect = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Read Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }
    }
}

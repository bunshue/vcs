﻿namespace howto_apollonian_gasket
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.picPacking = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.picPacking)).BeginInit();
            this.SuspendLayout();
            // 
            // picPacking
            // 
            this.picPacking.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.picPacking.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.picPacking.Location = new System.Drawing.Point(12, 12);
            this.picPacking.Name = "picPacking";
            this.picPacking.Size = new System.Drawing.Size(360, 360);
            this.picPacking.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.picPacking.TabIndex = 2;
            this.picPacking.TabStop = false;
            this.picPacking.SizeChanged += new System.EventHandler(this.picPacking_SizeChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(384, 384);
            this.Controls.Add(this.picPacking);
            this.Name = "Form1";
            this.Text = "howto_apollonian_gasket";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.picPacking)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox picPacking;
    }
}


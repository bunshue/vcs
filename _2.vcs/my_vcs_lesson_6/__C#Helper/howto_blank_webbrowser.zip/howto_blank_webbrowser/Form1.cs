﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_blank_webbrowser
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Enable the Blank button.
        private void wbrCSharpHelper_DocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
        {
            btnBlank.Enabled = true;
        }

        // Blank the WebBrowser.
        private void btnBlank_Click(object sender, EventArgs e)
        {
            wbrCSharpHelper.Navigate("about:blank");
        }
    }
}

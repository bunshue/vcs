﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Net.NetworkInformation;

namespace howto_check_internet_connected
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCheck_Click(object sender, EventArgs e)
        {
            if (IsInternetConnected())
                lblResult.Text = "The internet is available";
            else
                lblResult.Text = "The internet is not available";
        }

        // Return true if a ping to Google works.
        private bool IsInternetConnected()
        {
            return IsInternetConnected(1000);
        }
        private bool IsInternetConnected(int timeout)
        {
            try
            {
                Ping ping = new Ping();
                String host = "google.com";
                PingReply reply = ping.Send(host, timeout);
                return (reply.Status == IPStatus.Success);
            }
            catch
            {
                return false;
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Diagnostics;

namespace howto_use_stopwatch
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            Stopwatch stopwatch = new Stopwatch();
            stopwatch.Start();

            // Perform long calculations here.
            for (int i = 0; i < 100000000; i++)
            {
                double x = Math.Sqrt(i);
            }

            stopwatch.Stop();

            // Display the elapsed time.
            lblResult.Text = "Elapsed time: " +
                stopwatch.Elapsed.TotalSeconds.ToString("0.00") +
                " seconds";
        }
    }
}

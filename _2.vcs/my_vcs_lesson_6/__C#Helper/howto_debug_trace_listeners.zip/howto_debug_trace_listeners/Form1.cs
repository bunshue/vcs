﻿using System;
using System.Windows.Forms;

using System.Diagnostics;

namespace howto_debug_trace_listeners
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Make the listener.
        private void Form1_Load(object sender, EventArgs e)
        {
            string trace_file = Application.StartupPath + "//trace.txt";
            Trace.Listeners.Add(new TextWriterTraceListener(trace_file));
            Trace.AutoFlush = true;
        }

        // Send a message to the Debug listeners.
        private void btnDebug_Click(object sender, EventArgs e)
        {
            Debug.WriteLine(txtMessage.Text);
            txtMessage.Clear();
            txtMessage.Focus();
        }

        // Send a message to the Trace listeners.
        private void btnTrace_Click(object sender, EventArgs e)
        {
            Trace.WriteLine(txtMessage.Text);
            txtMessage.Clear();
            txtMessage.Focus();
        }
    }
}

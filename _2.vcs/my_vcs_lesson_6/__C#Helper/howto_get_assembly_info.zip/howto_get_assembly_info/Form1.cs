﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_get_assembly_info
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // Get the AssemblyInfo class.
            AssemblyInfo info = new AssemblyInfo();

            // Display the values.
            titleTextBox.Text = info.Title;
            descriptionTextBox.Text = info.Description;
            companyTextBox.Text = info.Company;
            productTextBox.Text = info.Product;
            copyrightTextBox.Text = info.Copyright;
            trademarkTextBox.Text = info.Trademark;
            assemblyVersionTextBox.Text = info.AssemblyVersion;
            fileVersionTextBox.Text = info.FileVersion;
            guidTextBox.Text = info.Guid;
            neutralLanguageTextBox.Text = info.NeutralLanguage;
            comVisibleTextBox.Text = info.IsComVisible.ToString();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace howto_named_parameters2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // Create a Person.
            Person person = new Person(name: "Rod Stephens", email: "RodStephens@CSharpHelper.com");

            // Display the Person's values.
            txtName.Text = person.Name;
            txtAddress.Text = person.Address;
            txtEmail.Text = person.Email;
            txtSms.Text = person.SmsPhone;
            txtVoice.Text = person.VoicePhone;
            txtFax.Text = person.Fax;

            txtName.Select(0, 0);
        }
    }
}

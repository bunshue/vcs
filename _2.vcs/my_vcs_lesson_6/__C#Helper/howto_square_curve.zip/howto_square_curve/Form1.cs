﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Drawing.Drawing2D;

namespace howto_square_curve
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnGraph_Click(object sender, EventArgs e)
        {
            // Make the Bitmap and associated Graphics object.
            int wid = picGraph.ClientSize.Width;
            int hgt = picGraph.ClientSize.Height;
            Bitmap bm = new Bitmap(wid, hgt);
            using (Graphics gr = Graphics.FromImage(bm))
            {
                gr.Clear(Color.White);

                // Set up a transformation to map
                // the region onto the  Bitmap.
                const float xmin = -1.6f;
                const float xmax = 1.6f;
                const float ymin = -1.6f;
                const float ymax = 1.6f;
                RectangleF rect = new RectangleF(xmin, ymin,
                    xmax - xmin, ymax - ymin);
                PointF[] pts =
                    {
                        new PointF(0, hgt),
                        new PointF(wid, hgt),
                        new PointF(0, 0),
                    };
                gr.Transform = new Matrix(rect, pts);
                gr.SmoothingMode = SmoothingMode.AntiAlias;

                using (Pen thin_pen = new Pen(Color.Blue, 0))
                {
                    // Draw the X and Y axes.
                    thin_pen.Color = Color.Blue;
                    gr.DrawLine(thin_pen, xmin, 0, xmax, 0);
                    const float big_tick = 0.1f;
                    const float small_tick = 0.05f;
                    for (float x = (int)xmin - 1; x <= xmax; x += 1)
                        gr.DrawLine(thin_pen, x, -big_tick, x, big_tick);
                    for (float x = (int)xmin - 0.5f; x <= xmax; x += 1)
                        gr.DrawLine(thin_pen, x, -small_tick, x, small_tick);

                    gr.DrawLine(thin_pen, 0, ymin, 0, ymax);
                    for (float y = (int)ymin - 1; y <= ymax; y += 1)
                        gr.DrawLine(thin_pen, -big_tick, y, big_tick, y);
                    for (float y = (int)ymin - 0.5f; y <= ymax; y += 1)
                        gr.DrawLine(thin_pen, -small_tick, y, small_tick, y);

                    // Draw a square.
                    //gr.DrawRectangle(thin_pen, -1, -1, 2, 2);

                    // Draw the graph.
                    thin_pen.Color = Color.Red;
                    DrawGraph(gr, thin_pen, xmin);
                }
            }

            // Display the result.
            picGraph.Image = bm;
        }

        // Draw the curve.
        private void DrawGraph(Graphics gr, Pen pen, float wxmin)
        {
            // Get the power.
            int power = int.Parse(txtPower.Text);
            float root = 1f / power;

            // Even integer power. -1 <= x, y <= 1
            List<PointF> points1 = new List<PointF>();
            List<PointF> points2 = new List<PointF>();
            for (float x = -1f; x <= 1f; x += 0.001f)
            {
                float y = -(float)Math.Pow(1 - Math.Pow(x, power), root);
                points1.Add(new PointF(x, y));
                points2.Add(new PointF(x, -y));
            }

            // Combine the lists.
            points2.Reverse();
            points1.AddRange(points2);

            // Draw the curve.
            gr.DrawPolygon(pen, points1.ToArray());
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Drawing.Drawing2D;

namespace howto_happy_numbers
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // The lengths of the numbers' happy loops.
        private PointF[] HappyLoopLengths = null;

        // The number of steps before detecting the happy loops.
        private PointF[] HappyLoopStarts = null;

        private void Form1_Load(object sender, EventArgs e)
        {
            lblMaxStart.Text = "";
            lblMaxLength.Text = "";
            lblSequence.Text = "";
        }

        // Return true if the number is prime.
        private bool IsPrime(int num)
        {
            // Handle 1 and 2 separately.
            if (num == 1) return false;
            if (num == 2) return true;
            if (num % 2 == 0) return false;

            // See if the number is divisible by odd values up to Sqrt(number).
            int sqrt = (int)(Math.Sqrt(num) + 1);
            for (int i = 3; i < sqrt; i++)
                if (num % i == 0) return false;

            // If we get here, the number is prime.
            return true;
        }

        // Calculate happy loops.
        private void btnGo_Click(object sender, EventArgs e)
        {
            int max = int.Parse(txtMax.Text);
            lvwResults.Items.Clear();
            lblMaxStart.Text = "";
            lblMaxLength.Text = "";
            lblSequence.Text = "";
            Cursor = Cursors.WaitCursor;
            Refresh();

            // Find the happy loop lengths and starts.
            HappyLoopLengths = new PointF[max];
            HappyLoopStarts = new PointF[max];
            int max_start = 0;
            int max_length = 0;
            for (int i = 1; i <= max; i++)
            {
                int loop_length, loop_start;
                FindHappyLoop(i, out loop_start, out loop_length);
                if (max_start < loop_start) max_start = loop_start;
                if (max_length < loop_length) max_length = loop_length;
                HappyLoopLengths[i - 1] = new PointF(i, loop_length);
                HappyLoopStarts[i - 1] = new PointF(i, loop_start);

                ListViewItem item = lvwResults.Items.Add(i.ToString());
                item.SubItems.Add(HappyLoopStarts[i - 1].Y.ToString());
                item.SubItems.Add(HappyLoopLengths[i - 1].Y.ToString());
                item.UseItemStyleForSubItems = false;
                item.SubItems[1].ForeColor = Color.Red;
                item.SubItems[2].ForeColor = Color.Blue;
                if (IsPrime(i))
                {
                    item.BackColor = Color.Pink;
                    item.SubItems[1].BackColor = Color.Pink;
                    item.SubItems[2].BackColor = Color.Pink;
                }
            }

            lblMaxStart.Text = HappyLoopStarts.Max(p => p.Y).ToString();
            lblMaxLength.Text = HappyLoopLengths.Max(p => p.Y).ToString();
            Console.WriteLine("Max Start: " + max_start);
            Console.WriteLine("Max Length: " + max_length);

            picGraph.Refresh();

            Cursor = Cursors.Default;
        }

        // Return the length and start position of the number's happy loop.
        private List<int> FindHappyLoop(int num, out int loop_start, out int loop_length)
        {
            List<int> list = new List<int>();
            list.Add(num);
            for (; ; )
            {
                string str = num.ToString();
                num = 0;
                foreach (char ch in str)
                {
                    int digit = int.Parse(ch.ToString());
                    num += digit * digit;
                }
                if (list.Contains(num))
                {
                    loop_start = list.IndexOf(num);
                    loop_length = list.Count - loop_start;
                    return list;
                }
                list.Add(num);
            }
        }

        // Draw the happy points.
        private void picGraph_Paint(object sender, PaintEventArgs e)
        {
            if (HappyLoopLengths == null) return;

            e.Graphics.Clear(picGraph.BackColor);
            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;

            // Map the world coordinates onto the PictureBox.
            float ymin = 0;
            float ymax = Math.Max(
                HappyLoopLengths.Max(p => p.Y),
                HappyLoopStarts.Max(p => p.Y));
            float xmin = 1;
            float xmax = HappyLoopLengths.Length;
            RectangleF world_rect = new RectangleF(
                xmin, ymin, xmax - xmin, ymax - ymin);
            const int margin = 10;
            PointF[] device_points =
            {
                new PointF(margin, picGraph.ClientSize.Height - margin),
                new PointF(picGraph.ClientSize.Width - margin, picGraph.ClientSize.Height - margin),
                new PointF(margin, margin),
            };
            e.Graphics.Transform = new Matrix(world_rect, device_points);

            // Draw.
            using (Pen pen = new Pen(Color.Red, 0))
            {
                e.Graphics.DrawLines(pen, HappyLoopStarts);
                pen.Color = Color.Blue;
                e.Graphics.DrawLines(pen, HappyLoopLengths);
            }
        }
        private void Form1_Resize(object sender, EventArgs e)
        {
            picGraph.Refresh();
        }
        
        // Display the selected number's happy sequence.
        private void lvwResults_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lvwResults.SelectedIndices.Count < 1) return;
            int num = lvwResults.SelectedIndices[0] + 1;
            int loop_start, loop_length;
            List<int> sequence = FindHappyLoop(num, out loop_start, out loop_length);
            sequence.Add(sequence[loop_start]);
            lblSequence.Text = string.Join(" ",
                sequence.ConvertAll(i => i.ToString()).ToArray());
        }
    }
}

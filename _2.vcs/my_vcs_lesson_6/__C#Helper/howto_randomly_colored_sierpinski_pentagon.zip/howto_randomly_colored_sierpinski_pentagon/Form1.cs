﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Drawing.Drawing2D;

namespace howto_randomly_colored_sierpinski_pentagon
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // The root of the Pentagon object hierarchy.
        private Pentagon Root = null;

        // Redraw.
        private void nudDepth_ValueChanged(object sender, EventArgs e)
        {
            MakePentagons();
        }

        // Make the Pentagon objects and redraw.
        private void MakePentagons()
        {
            // Build the Root.
            int depth = (int)nudDepth.Value;
            PointF center = new PointF(
                picPentagon.ClientSize.Width / 2,
                picPentagon.ClientSize.Height / 2);
            float radius = (float)Math.Min(center.X, center.Y);
            Root = MakePentagon(depth, center, radius);

            // Redraw.
            picPentagon.Refresh();
        }

        // Scale factor for moving to smaller pentagons.
        private float size_scale = (float)(1.0 / (2.0 * (1 + Math.Cos(Math.PI / 180 * 72))));

        // Recursively generate a Pentagon and its descendants.
        private Pentagon MakePentagon(int depth, PointF center, float radius)
        {
            // Make the Pentagon.
            Pentagon parent = new Pentagon(GetPentagonPoints(center, radius));

            // If we are not done recursing, make children.
            if (depth > 0)
            {
                // Find the smaller pentagons' centers.
                float d = radius - radius * size_scale;
                PointF[] centers = GetPentagonPoints(center, d);

                // Recursively draw the smaller pentagons.
                foreach (PointF point in centers)
                {
                    parent.Children.Add(MakePentagon(
                        depth - 1, point, radius * size_scale));
                }
            }

            return parent;
        }

        // Find the pentagon's corners.
        private PointF[] GetPentagonPoints(PointF center, float radius)
        {
            PointF[] points = new PointF[5];
            double theta = -Math.PI / 2.0;
            double dtheta = 2.0 * Math.PI / 5.0;
            for (int i = 0; i < 5; i++)
            {
                points[i] = new PointF(
                    center.X + (float)(radius * Math.Cos(theta)),
                    center.Y + (float)(radius * Math.Sin(theta)));
                theta += dtheta;
            }
            return points;
        }

        // Draw.
        private void picPentagon_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.Clear(picPentagon.BackColor);
            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
            if (Root == null) return;

            Root.Draw(e.Graphics);
        }

        // Draw the initial pentagon.
        private void Form1_Load(object sender, EventArgs e)
        {
            MakePentagons();
        }
    }
}

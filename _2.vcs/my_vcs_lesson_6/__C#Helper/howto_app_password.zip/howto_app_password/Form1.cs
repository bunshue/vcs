﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

// Set PasswordForm.btnOk.Modifiers = Public.

namespace howto_app_password
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Get the password from the user.
        private void Form1_Load(object sender, EventArgs e)
        {
            const string token = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
            const string encrypted = "0dbc23df7b4358281cbc83b89745db7a9da4a7e54c68c30965832908ea32a369";

            // Get the password from the user.
            PasswordForm frm = new PasswordForm();
            if (frm.ShowDialog() == DialogResult.Cancel) Close();

            // See if the password is correct.
            string password = frm.txtPassword.Text;
            if (token.Encrypt(password).ToHex() != encrypted) Close();
        }
    }
}

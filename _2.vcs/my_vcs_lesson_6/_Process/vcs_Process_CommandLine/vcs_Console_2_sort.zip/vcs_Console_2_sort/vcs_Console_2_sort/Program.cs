﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Threading;

namespace vcs_Console_2_sort
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, 這是我的第一個C#程式!");

            int len = args.Length;
            Console.WriteLine("共有 " + len.ToString() + " 個參數");

            int i;
            for (i = 0; i < len; i++)
            {
                Console.WriteLine("第 " + (i + 1).ToString() + " 個參數 : " + args[i]);
            }

            for (i = 0; i < 10; i++)
            {
                Thread.Sleep(1000);
                Console.WriteLine("i = " + i.ToString() + "aaaaaa");
            }
        }
    }
}


﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Drawing.Drawing2D;

namespace howto_curly_tree2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnDraw_Click(object sender, EventArgs e)
        {
            Cursor = Cursors.WaitCursor;
            try
            {
                float length_scaleA = float.Parse(txtLengthScale1.Text);
                float length_scaleB = float.Parse(txtLengthScale2.Text);
                float angleA = (float)((double)nudAngle1.Value * Math.PI / 180.0);
                float angleB = (float)((double)nudAngle2.Value * Math.PI / 180.0);
                picCanvas.Image = MakeTree(
                    picCanvas.ClientSize.Width,
                    picCanvas.ClientSize.Height,
                    (int)nudLevel.Value,
                    angleA, angleB,
                    length_scaleA, length_scaleB);
            }
            catch
            {
            }
            Cursor = Cursors.Default;
        }

        // Make the tree. The angles are in radians.
        private Bitmap MakeTree(int width, int height, int level,
            float angleA, float angleB,
            float length_scaleA, float length_scaleB)
        {
            // Get the tree's bounds.
            float xmin = 0;
            float xmax = 0;
            float ymin = 0;
            float ymax = 0;
            float start_length = picCanvas.ClientSize.Height * 0.33f;
            const float start_thickness = 10;
            const float start_direction = (float)(Math.PI * 0.5);
            FindBranchBounds(
                0, 0, start_direction, level, start_length,
                angleA, angleB, length_scaleA, length_scaleB,
                ref xmin, ref xmax, ref ymin, ref ymax);

            // Make the bitmap.
            Bitmap bm = new Bitmap(
                picCanvas.ClientSize.Width,
                picCanvas.ClientSize.Height);
            using (Graphics gr = Graphics.FromImage(bm))
            {
                gr.Clear(picCanvas.BackColor);
                gr.SmoothingMode = SmoothingMode.AntiAlias;

                // Map the tree onto the PictureBox.
                xmin -= start_thickness;
                xmax += start_thickness;
                ymin -= start_thickness;
                ymax += start_thickness;
                RectangleF world_rect = new RectangleF(
                    xmin, ymin, xmax - xmin, ymax - ymin);
                const int margin = 4;
                RectangleF device_rect = new RectangleF(
                    margin, margin,
                    picCanvas.ClientSize.Width - 2 * margin,
                    picCanvas.ClientSize.Height - 2 * margin);
                SetTransformationWithoutDisortion(gr,
                    world_rect, device_rect, false, true);

                // Draw the tree.
                using (Pen pen = new Pen(Color.Green, 1))
                {
                    DrawBranch(gr, pen,
                        0, 0, start_direction, level, start_length,
                        angleA, angleB, length_scaleA, length_scaleB);
                }

                //// Mark the root (for debugging).
                //float thickness = start_length / 10f;
                //gr.FillEllipse(Brushes.Red,
                //    0 - thickness,
                //    0 - thickness,
                //    2 * thickness,
                //    2 * thickness);
            }
            return bm;
        }

        // Calculate the distance between the points.
        private float Distance(PointF point1, PointF point2)
        {
            float dx = point1.X - point2.X;
            float dy = point1.Y - point2.Y;
            return (float)(Math.Sqrt(dx * dx + dy * dy));
        }

        // Find the bounds for this branch and its descendants.
        // The direction parameter is in radians.
        private void FindBranchBounds(
            float x, float y, float direction, int level,
            float length, float angleA, float angleB,
            float length_scaleA, float length_scaleB,
            ref float xmin, ref float xmax, ref float ymin, ref float ymax)
        {
            // Find the new segment.
            if (length < 0.1) return;
            x += (float)(length * Math.Cos(direction));
            if (xmin > x) xmin = x;
            if (xmax < x) xmax = x;

            y += (float)(length * Math.Sin(direction));
            if (ymin > y) ymin = y;
            if (ymax < y) ymax = y;

            if (level > 0)
            {
                FindBranchBounds(
                    x, y, direction + angleA, level - 1,
                    length * length_scaleA, angleA, angleB,
                    length_scaleA, length_scaleB,
                    ref xmin,ref xmax, ref ymin, ref ymax);
                FindBranchBounds(
                    x, y, direction + angleB, level - 1,
                    length * length_scaleB, angleA, angleB,
                    length_scaleA, length_scaleB,
                    ref xmin, ref xmax, ref ymin, ref ymax);
            }
        }

        // Draw this branch and its descendants.
        // The direction parameter is in radians.
        private void DrawBranch(Graphics gr, Pen pen,
            float x, float y, float direction, int level,
            float length, float angleA, float angleB,
            float length_scaleA, float length_scaleB)
        {
            if (length < 0.1) return;

            // Draw the new segment.
            PointF point1 = new PointF(x, y);
            x += (float)(length * Math.Cos(direction));
            y += (float)(length * Math.Sin(direction));
            PointF point2 = new PointF(x, y);
            
            pen.Width = Distance(point1, point2) / 10f;
            gr.DrawLine(pen, point1, point2);

            if (level > 0)
            {
                DrawBranch(gr, pen,
                    x, y, direction + angleA, level - 1,
                    length * length_scaleA, angleA, angleB,
                    length_scaleA, length_scaleB);
                DrawBranch(gr, pen,
                    x, y, direction + angleB, level - 1,
                    length * length_scaleB, angleA, angleB,
                    length_scaleA, length_scaleB);
            }
        }

        // Map from world coordinates to device coordinates
        // without distortion.
        private void SetTransformationWithoutDisortion(Graphics gr,
            RectangleF world_rect, RectangleF device_rect,
            bool invert_x, bool invert_y)
        {
            // Get the aspect ratios.
            float world_aspect = world_rect.Width / world_rect.Height;
            float device_aspect = device_rect.Width / device_rect.Height;

            // Asjust the world rectangle to maintain the aspect ratio.
            float world_cx = world_rect.X + world_rect.Width / 2f;
            float world_cy = world_rect.Y + world_rect.Height / 2f;
            if (world_aspect > device_aspect)
            {
                // The world coordinates are too short and width.
                // Make them taller.
                float world_height = world_rect.Width / device_aspect;
                world_rect = new RectangleF(
                    world_rect.Left,
                    world_cy - world_height / 2f,
                    world_rect.Width,
                    world_height);
            }
            else
            {
                // The world coordinates are too tall and thin.
                // Make them wider.
                float world_width = device_aspect * world_rect.Height;
                world_rect = new RectangleF(
                    world_cx - world_width / 2f,
                    world_rect.Top,
                    world_width,
                    world_rect.Height);
            }

            // Map the new world coordinates into the device coordinates.
            SetTransformation(gr, world_rect, device_rect,
                invert_x, invert_y);
        }

        // Map from world coordinates to device coordinates.
        private void SetTransformation(Graphics gr,
            RectangleF world_rect, RectangleF device_rect,
            bool invert_x, bool invert_y)
        {
            PointF[] device_points =
            {
                new PointF(device_rect.Left, device_rect.Top),      // Upper left.
                new PointF(device_rect.Right, device_rect.Top),     // Upper right.
                new PointF(device_rect.Left, device_rect.Bottom),   // Lower left.
            };

            if (invert_x)
            {
                device_points[0].X = device_rect.Right;
                device_points[1].X = device_rect.Left;
                device_points[2].X = device_rect.Right;
            }
            if (invert_y)
            {
                device_points[0].Y = device_rect.Bottom;
                device_points[1].Y = device_rect.Bottom;
                device_points[2].Y = device_rect.Top;
            }

            gr.Transform = new Matrix(world_rect, device_points);
        }
    }
}

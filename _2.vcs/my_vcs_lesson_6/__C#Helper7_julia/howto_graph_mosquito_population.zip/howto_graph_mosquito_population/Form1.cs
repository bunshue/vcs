﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Drawing.Drawing2D;

namespace howto_graph_mosquito_population
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Start or stop the simulation.
        private void btnStart_Click(object sender, EventArgs e)
        {
            tmrGeneration.Interval = int.Parse(txtInterval.Text);

            tmrGeneration.Enabled = !tmrGeneration.Enabled;
            if (tmrGeneration.Enabled)
            {
                // We just started.
                btnStart.Text = "Stop";
            }
            else
            {
                // We just stopped.
                btnStart.Text = "Start";
            }
        }

        // Reset the simulation.
        private void btnReset_Click(object sender, EventArgs e)
        {
            ResetData();
        }

        // Reset the data to the values in the TextBoxes.
        private void ResetData()
        {
            GenerationNumber = 0;
            NumFemales = int.Parse(txtNumFemales.Text);
            NumRegularMales = int.Parse(txtNumRegularMales.Text);
            NumModifiedMales = int.Parse(txtNumModifiedMales.Text);

            FemalePoints = new List<Point>();
            RegularMalePoints = new List<Point>();
            ModifiedMalePoints = new List<Point>();

            // Save points representing the initial values.
            FemalePoints.Add(new Point(GenerationNumber, NumFemales));
            RegularMalePoints.Add(new Point(GenerationNumber, NumRegularMales));
            ModifiedMalePoints.Add(new Point(GenerationNumber, NumModifiedMales));

            PopulationLimit = int.Parse(txtPopulationLimit.Text);
            EggsPerClutch = int.Parse(txtEggsPerClutch.Text);
            DisplayCurrentValues();
        }

        // Display the current values.
        private void DisplayCurrentValues()
        {
            lblGeneration.Text = "Generation: " + GenerationNumber;
            txtCurFemales.Text = NumFemales.ToString();
            txtCurRegularMales.Text = NumRegularMales.ToString();
            txtCurModifiedMales.Text = NumModifiedMales.ToString();

            // Graph the data.
            picGraph.Refresh();
        }

        // The generation number.
        private int GenerationNumber = 0;

        // The population limit.
        private double PopulationLimit;

        // The current numbers of each kind of mosquito.
        private int NumFemales = -1, NumRegularMales, NumModifiedMales, EggsPerClutch;

        // Data for the graph.
        private List<Point> FemalePoints,
            RegularMalePoints, ModifiedMalePoints;

        // Simulate a generation.
        private void tmrGeneration_Tick(object sender, EventArgs e)
        {
            // See if we need to start a new run.
            if (NumFemales == -1) ResetData();

            // Display the generation number.
            GenerationNumber++;
            lblGeneration.Text = "Gen: " + GenerationNumber;

            // Breed.
            double prob_regular =
                NumRegularMales / (double)(NumRegularMales + NumModifiedMales);
            Random rand = new Random();
            int num_baby_females = 0;
            int num_baby_regular_males = 0;
            int num_baby_modified_males = 0;
            for (int i = 0; i < NumFemales; i++)
            {
                // See if this female finds a regular male.
                if (rand.NextDouble() < prob_regular)
                {
                    // A regular male.
                    num_baby_females += EggsPerClutch / 2;
                    num_baby_regular_males += EggsPerClutch / 2;
                }
                else
                {
                    // A modified male.
                    num_baby_females += (int)(EggsPerClutch * 0.05);
                    num_baby_modified_males += (int)(EggsPerClutch * 0.95);
                }
            }

            // Update the totals.
            NumFemales = num_baby_females;
            NumRegularMales = num_baby_regular_males;
            NumModifiedMales = num_baby_modified_males;

            // Reduce to the population limit.
            double total_population = NumFemales +
                NumRegularMales + NumModifiedMales;
            if (total_population > PopulationLimit)
            {
                NumFemales = (int)(PopulationLimit *
                    NumFemales / total_population);
                NumRegularMales = (int)(PopulationLimit *
                    NumRegularMales / total_population);
                NumModifiedMales = (int)(PopulationLimit *
                    NumModifiedMales / total_population);
            }

            // Save points representing the new values.
            FemalePoints.Add(new Point(GenerationNumber, NumFemales));
            RegularMalePoints.Add(new Point(GenerationNumber, NumRegularMales));
            ModifiedMalePoints.Add(new Point(GenerationNumber, NumModifiedMales));

            // Display the current values.
            DisplayCurrentValues();
        }

        // Graph the data.
        private void picGraph_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.Clear(picGraph.BackColor);
            if (FemalePoints == null) return;
            if (FemalePoints.Count < 2) return;

            // Use the next multiple of 10 generations
            int num_generations =
                10 * (1 + (int)((GenerationNumber - 1) / 10.0));

            // Transform the graph.
            Rectangle source_rect = new Rectangle(
                0, 0, num_generations, (int)PopulationLimit);
            Point[] dest_points =
            {
                new Point(0, picGraph.ClientSize.Height),
                new Point(picGraph.ClientSize.Width, picGraph.ClientSize.Height),
                new Point(0, 0),
            };
            e.Graphics.Transform = new Matrix(
                source_rect, dest_points);

            using (Pen thin_pen = new Pen(Color.Gray, 0))
            {
                // Draw lines to show the generations.
                for (int i = 1; i < num_generations; i++)
                {
                    e.Graphics.DrawLine(thin_pen,
                        i, 0, i, (int)PopulationLimit);
                }

                // Draw the population data.
                thin_pen.Color = Color.Red;
                e.Graphics.DrawLines(thin_pen, FemalePoints.ToArray());
                thin_pen.Color = Color.Green;
                e.Graphics.DrawLines(thin_pen, RegularMalePoints.ToArray());
                thin_pen.Color = Color.Blue;
                e.Graphics.DrawLines(thin_pen, ModifiedMalePoints.ToArray());
            }
        }

        private void picGraph_Resize(object sender, EventArgs e)
        {
            picGraph.Refresh();
        }
    }
}

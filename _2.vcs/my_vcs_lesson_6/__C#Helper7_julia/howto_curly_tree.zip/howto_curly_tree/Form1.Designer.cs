﻿namespace howto_curly_tree
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.nudLevel = new System.Windows.Forms.NumericUpDown();
            this.nudAngle1 = new System.Windows.Forms.NumericUpDown();
            this.label2 = new System.Windows.Forms.Label();
            this.nudAngle2 = new System.Windows.Forms.NumericUpDown();
            this.label3 = new System.Windows.Forms.Label();
            this.picCanvas = new System.Windows.Forms.PictureBox();
            this.btnDraw = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.txtLengthScale1 = new System.Windows.Forms.TextBox();
            this.txtLengthScale2 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.nudLevel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudAngle1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudAngle2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCanvas)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 14);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(36, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Level:";
            // 
            // nudLevel
            // 
            this.nudLevel.Location = new System.Drawing.Point(101, 12);
            this.nudLevel.Minimum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.nudLevel.Name = "nudLevel";
            this.nudLevel.Size = new System.Drawing.Size(53, 20);
            this.nudLevel.TabIndex = 0;
            this.nudLevel.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.nudLevel.Value = new decimal(new int[] {
            16,
            0,
            0,
            0});
            // 
            // nudAngle1
            // 
            this.nudAngle1.Location = new System.Drawing.Point(101, 38);
            this.nudAngle1.Maximum = new decimal(new int[] {
            180,
            0,
            0,
            0});
            this.nudAngle1.Minimum = new decimal(new int[] {
            180,
            0,
            0,
            -2147483648});
            this.nudAngle1.Name = "nudAngle1";
            this.nudAngle1.Size = new System.Drawing.Size(53, 20);
            this.nudAngle1.TabIndex = 1;
            this.nudAngle1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.nudAngle1.Value = new decimal(new int[] {
            30,
            0,
            0,
            0});
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 40);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(47, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Angle A:";
            // 
            // nudAngle2
            // 
            this.nudAngle2.Location = new System.Drawing.Point(101, 90);
            this.nudAngle2.Maximum = new decimal(new int[] {
            180,
            0,
            0,
            0});
            this.nudAngle2.Minimum = new decimal(new int[] {
            180,
            0,
            0,
            -2147483648});
            this.nudAngle2.Name = "nudAngle2";
            this.nudAngle2.Size = new System.Drawing.Size(53, 20);
            this.nudAngle2.TabIndex = 3;
            this.nudAngle2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.nudAngle2.Value = new decimal(new int[] {
            90,
            0,
            0,
            -2147483648});
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 92);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(47, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Angle B:";
            // 
            // picCanvas
            // 
            this.picCanvas.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.picCanvas.BackColor = System.Drawing.Color.White;
            this.picCanvas.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.picCanvas.Location = new System.Drawing.Point(160, 12);
            this.picCanvas.Name = "picCanvas";
            this.picCanvas.Size = new System.Drawing.Size(279, 223);
            this.picCanvas.TabIndex = 6;
            this.picCanvas.TabStop = false;
            // 
            // btnDraw
            // 
            this.btnDraw.Location = new System.Drawing.Point(45, 160);
            this.btnDraw.Name = "btnDraw";
            this.btnDraw.Size = new System.Drawing.Size(75, 23);
            this.btnDraw.TabIndex = 5;
            this.btnDraw.Text = "Draw";
            this.btnDraw.UseVisualStyleBackColor = true;
            this.btnDraw.Click += new System.EventHandler(this.btnDraw_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 67);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(83, 13);
            this.label4.TabIndex = 8;
            this.label4.Text = "Length Scale A:";
            // 
            // txtLengthScale1
            // 
            this.txtLengthScale1.Location = new System.Drawing.Point(101, 64);
            this.txtLengthScale1.Name = "txtLengthScale1";
            this.txtLengthScale1.Size = new System.Drawing.Size(53, 20);
            this.txtLengthScale1.TabIndex = 2;
            this.txtLengthScale1.Text = "0.9";
            this.txtLengthScale1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtLengthScale2
            // 
            this.txtLengthScale2.Location = new System.Drawing.Point(101, 116);
            this.txtLengthScale2.Name = "txtLengthScale2";
            this.txtLengthScale2.Size = new System.Drawing.Size(53, 20);
            this.txtLengthScale2.TabIndex = 4;
            this.txtLengthScale2.Text = "0.5";
            this.txtLengthScale2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(12, 119);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(83, 13);
            this.label6.TabIndex = 12;
            this.label6.Text = "Length Scale B:";
            // 
            // Form1
            // 
            this.AcceptButton = this.btnDraw;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(451, 247);
            this.Controls.Add(this.txtLengthScale2);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtLengthScale1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.btnDraw);
            this.Controls.Add(this.picCanvas);
            this.Controls.Add(this.nudAngle2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.nudAngle1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.nudLevel);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "howto_curly_tree";
            ((System.ComponentModel.ISupportInitialize)(this.nudLevel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudAngle1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudAngle2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCanvas)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.NumericUpDown nudLevel;
        private System.Windows.Forms.NumericUpDown nudAngle1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.NumericUpDown nudAngle2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.PictureBox picCanvas;
        private System.Windows.Forms.Button btnDraw;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtLengthScale1;
        private System.Windows.Forms.TextBox txtLengthScale2;
        private System.Windows.Forms.Label label6;
    }
}


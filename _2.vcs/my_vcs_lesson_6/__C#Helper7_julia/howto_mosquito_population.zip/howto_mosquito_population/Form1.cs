﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_mosquito_population
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Start or stop the simulation.
        private void btnStart_Click(object sender, EventArgs e)
        {
            tmrGeneration.Interval = int.Parse(txtInterval.Text);

            tmrGeneration.Enabled = !tmrGeneration.Enabled;
            if (tmrGeneration.Enabled)
            {
                // We just started.
                btnStart.Text = "Stop";
            }
            else
            {
                // We just stopped.
                btnStart.Text = "Start";
            }
        }

        // Reset the simulation.
        private void btnReset_Click(object sender, EventArgs e)
        {
            ResetData();
        }

        // Reset the data to the values in the TextBoxes.
        private void ResetData()
        {
            GenerationNumber = 0;
            NumFemales = int.Parse(txtNumFemales.Text);
            NumRegularMales = int.Parse(txtNumRegularMales.Text);
            NumModifiedMales = int.Parse(txtNumModifiedMales.Text);
            PopulationLimit = int.Parse(txtPopulationLimit.Text);
            EggsPerClutch = int.Parse(txtEggsPerClutch.Text);
            DisplayCurrentValues();
        }

        // Display the current values.
        private void DisplayCurrentValues()
        {
            lblGeneration.Text = "Generation: " + GenerationNumber;
            txtCurFemales.Text = NumFemales.ToString();
            txtCurRegularMales.Text = NumRegularMales.ToString();
            txtCurModifiedMales.Text = NumModifiedMales.ToString();
        }

        // The generation number.
        private int GenerationNumber = 0;

        // The population limit.
        private double PopulationLimit;

        // The current numbers of each kind of mosquito.
        private int NumFemales = -1, NumRegularMales, NumModifiedMales, EggsPerClutch;

        // Simulate a generation.
        private void tmrGeneration_Tick(object sender, EventArgs e)
        {
            // See if we need to start a new run.
            if (NumFemales == -1) ResetData();

            // Display the generation number.
            GenerationNumber++;
            lblGeneration.Text = "Gen: " + GenerationNumber;

            // Breed.
            double prob_regular =
                NumRegularMales / (double)(NumRegularMales + NumModifiedMales);
            Random rand = new Random();
            int num_baby_females = 0;
            int num_baby_regular_males = 0;
            int num_baby_modified_males = 0;
            for (int i = 0; i < NumFemales; i++)
            {
                // See if this female finds a regular male.
                if (rand.NextDouble() < prob_regular)
                {
                    // A regular male.
                    num_baby_females += EggsPerClutch / 2;
                    num_baby_regular_males += EggsPerClutch / 2;
                }
                else
                {
                    // A modified male.
                    num_baby_females += (int)(EggsPerClutch * 0.05);
                    num_baby_modified_males += (int)(EggsPerClutch * 0.95);
                }
            }

            // Update the totals.
            NumFemales = num_baby_females;
            NumRegularMales = num_baby_regular_males;
            NumModifiedMales = num_baby_modified_males;

            // Reduce to the population limit.
            double total_population = NumFemales +
                NumRegularMales + NumModifiedMales;
            if (total_population > PopulationLimit)
            {
                NumFemales = (int)(PopulationLimit *
                    NumFemales / total_population);
                NumRegularMales = (int)(PopulationLimit *
                    NumRegularMales / total_population);
                NumModifiedMales = (int)(PopulationLimit *
                    NumModifiedMales / total_population);
            }

            // Display the current values.
            DisplayCurrentValues();
        }
    }
}

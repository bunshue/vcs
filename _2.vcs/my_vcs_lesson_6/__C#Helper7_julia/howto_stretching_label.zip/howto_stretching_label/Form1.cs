﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Drawing.Text;

namespace howto_stretching_label
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // The PictureBox's current size.
        private float StartWidth;
        private int StartHeight;
        private float EndWidth = 260;
        private float Dx, CurrentWidth;
        private int TicksToGo, TotalTicks;

        // Information about the string to draw.
        private const string LabelText = "C# Programming";
        private Font TextFont;
        private float[] CharacterWidths;
        private float TotalCharacterWidth;

        private void Form1_Load(object sender, EventArgs e)
        {
            // Set the initial size.
            StartWidth = picTitle2.Size.Width;
            StartHeight = picTitle2.Size.Height;
            CurrentWidth = StartWidth;

            // Stretch for 2 seconds.
            TotalTicks = 2 * 1000 / tmrResizePictureBox.Interval;
            Dx = (EndWidth - StartWidth) / TotalTicks;

            // Make the font and measure the characters.
            CharacterWidths = new float[LabelText.Length];
            TextFont = new Font("Times New Roman", 16);
            using (Graphics gr = this.CreateGraphics())
            {
                for (int i = 0; i < LabelText.Length; i++)
                {
                    SizeF ch_size = gr.MeasureString(LabelText.Substring(i, 1), TextFont);
                    CharacterWidths[i] = ch_size.Width;
                }
            }
            TotalCharacterWidth = CharacterWidths.Sum();
        }

        // Resize the PictureBox.
        private void btnAnimate_Click(object sender, EventArgs e)
        {
            btnAnimate.Enabled = false;
            CurrentWidth = StartWidth;
            picTitle2.Size = new Size((int)StartWidth, picTitle2.Size.Height);
            picTitle2.Refresh();
            TicksToGo = TotalTicks;

            tmrResizePictureBox.Enabled = true;
        }

        // Resize the PictureBox.
        private void tmrResizePictureBox_Tick(object sender, EventArgs e)
        {
            CurrentWidth += Dx;
            picTitle2.Size = new Size((int)CurrentWidth, StartHeight);
            picTitle2.Refresh();

            // If we're done moving, disable the Timer.
            if (--TicksToGo <= 0)
            {
                tmrResizePictureBox.Enabled = false;
                btnAnimate.Enabled = true;
            }
        }

        // Draw the text on the control.
        private void picTitle2_Paint(object sender, PaintEventArgs e)
        {
            // Use AntiAlias for the best result.
            e.Graphics.TextRenderingHint = TextRenderingHint.AntiAlias;
            e.Graphics.Clear(picTitle2.BackColor);

            SpaceTextToFit(e.Graphics, picTitle2.ClientRectangle,
                TextFont, Brushes.Red, LabelText);
        }

        // Draw text inserting space between characters
        // to make it fill the indicated width.
        private void SpaceTextToFit(Graphics gr, Rectangle rect, Font font, Brush brush, string text)
        {
            using (StringFormat string_format = new StringFormat())
            {
                string_format.Alignment = StringAlignment.Near;
                string_format.LineAlignment = StringAlignment.Near;

                // Calculate the spacing.
                float space = (rect.Width - TotalCharacterWidth) / (text.Length - 1);

                // Draw the characters.
                PointF point = new PointF(rect.X, rect.Y);
                for (int i = 0; i < text.Length; i++)
                {
                    gr.DrawString(text[i].ToString(), font, brush, point);
                    point.X += CharacterWidths[i] + space;
                }
            }
        }
    }
}

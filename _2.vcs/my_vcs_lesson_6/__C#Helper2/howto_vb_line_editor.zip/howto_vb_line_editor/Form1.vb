﻿Imports System.Drawing.Drawing2D

Public Class Form1
    ' Note: When the program starts, only the
    '  following event handlers should be registered:
    '       Form1_Load
    '       picCanvas_MouseDown
    '       picCanvas_MouseMove_NotDown
    '       picCanvas_Paint

    ' The "size" of an object for mouse over purposes.
    Private Const object_radius As Integer = 3

    ' We're over an object if the distance squared
    ' between the mouse and the object is less than this.
    Private Const over_dist_squared As Integer = object_radius * object_radius

    ' The points that make up the line segments.
    Private Pt1 As New List(Of Point)
    Private Pt2 As New List(Of Point)

    ' Points for the new line.
    Private IsDrawing As Boolean = False
    Private NewPt1, NewPt2 As Point

    ' Calculate the trash can dimensions.
    Private TrashWidth, TrashHeight As Integer
    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Const TrashScale As Single = 0.25F
        TrashWidth = Int(TrashScale * My.Resources.trash_empty.Width)
        TrashHeight = Int(TrashScale * My.Resources.trash_empty.Height)
    End Sub

    ' The mouse is up. See whether we're over an end point or segment.
    Private Sub picCanvas_MouseMove_NotDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles picCanvas.MouseMove
        Dim new_cursor As Cursor = Cursors.Cross

        ' See what we're over.
        Dim hit_point As Point
        Dim segment_number As Integer

        If (MouseIsOverEndpoint(e.Location, segment_number, hit_point)) Then
            new_cursor = Cursors.Arrow
        ElseIf (MouseIsOverSegment(e.Location, segment_number)) Then
            new_cursor = Cursors.Hand
        End If

        ' Set the new cursor.
        If (picCanvas.Cursor <> new_cursor) Then picCanvas.Cursor = new_cursor
    End Sub

    ' See what we're over and start doing whatever is appropriate.
    Private Sub picCanvas_MouseDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles picCanvas.MouseDown
        ' See what we're over.
        Dim hit_point As Point
        Dim segment_number As Integer

        If (MouseIsOverEndpoint(e.Location, segment_number, hit_point)) Then
            ' Start moving this end point.
            RemoveHandler picCanvas.MouseMove, AddressOf picCanvas_MouseMove_NotDown
            AddHandler picCanvas.MouseMove, AddressOf picCanvas_MouseMove_MovingEndPoint
            AddHandler picCanvas.MouseUp, AddressOf picCanvas_MouseUp_MovingEndPoint

            ' Remember the segment number.
            MovingSegment = segment_number

            ' See if we're moving the start end point.
            MovingStartEndPoint = (Pt1(segment_number).Equals(hit_point))

            ' Remember the offset from the mouse to the point.
            OffsetX = hit_point.X - e.X
            OffsetY = hit_point.Y - e.Y
        ElseIf (MouseIsOverSegment(e.Location, segment_number)) Then
            ' Start moving this segment.
            RemoveHandler picCanvas.MouseMove, AddressOf picCanvas_MouseMove_NotDown
            AddHandler picCanvas.MouseMove, AddressOf picCanvas_MouseMove_MovingSegment
            AddHandler picCanvas.MouseUp, AddressOf picCanvas_MouseUp_MovingSegment

            ' Remember the segment number.
            MovingSegment = segment_number

            ' Remember the offset from the mouse to the segment's first point.
            OffsetX = Pt1(segment_number).X - e.X
            OffsetY = Pt1(segment_number).Y - e.Y
        Else
            ' Start drawing a new segment.
            RemoveHandler picCanvas.MouseMove, AddressOf picCanvas_MouseMove_NotDown
            AddHandler picCanvas.MouseMove, AddressOf picCanvas_MouseMove_Drawing
            AddHandler picCanvas.MouseUp, AddressOf picCanvas_MouseUp_Drawing
            IsDrawing = True
            NewPt1 = New Point(e.X, e.Y)
            NewPt2 = New Point(e.X, e.Y)
        End If
    End Sub

#Region "Drawing"

    ' We're drawing a new segment.
    Private Sub picCanvas_MouseMove_Drawing(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs)
        ' Save the new point.
        NewPt2 = New Point(e.X, e.Y)

        ' Redraw.
        picCanvas.Refresh()
    End Sub

    ' Stop drawing.
    Private Sub picCanvas_MouseUp_Drawing(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs)
        IsDrawing = False

        ' Reset the event handlers.
        RemoveHandler picCanvas.MouseMove, AddressOf picCanvas_MouseMove_Drawing
        AddHandler picCanvas.MouseMove, AddressOf picCanvas_MouseMove_NotDown
        RemoveHandler picCanvas.MouseUp, AddressOf picCanvas_MouseUp_Drawing

        ' Create the new segment.
        Pt1.Add(NewPt1)
        Pt2.Add(NewPt2)

        ' Redraw.
        picCanvas.Refresh()
    End Sub

#End Region ' Drawing

#Region "Moving End Point"

    ' The segment we're moving or the segment whose end point we're moving.
    Private MovingSegment As Integer = -1

    ' The end point we're moving.
    Private MovingStartEndPoint As Boolean = False

    ' The offset from the mouse to the object being moved.
    Private OffsetX, OffsetY As Integer

    ' We're moving an end point.
    Private Sub picCanvas_MouseMove_MovingEndPoint(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs)
        ' Move the point to its new location.
        If (MovingStartEndPoint) Then
            Pt1(MovingSegment) = New Point(e.X + OffsetX, e.Y + OffsetY)
        Else
            Pt2(MovingSegment) = New Point(e.X + OffsetX, e.Y + OffsetY)
        End If

        ' Redraw.
        picCanvas.Refresh()
    End Sub

    ' Stop moving the end point.
    Private Sub picCanvas_MouseUp_MovingEndPoint(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs)
        ' Reset the event handlers.
        AddHandler picCanvas.MouseMove, AddressOf picCanvas_MouseMove_NotDown
        RemoveHandler picCanvas.MouseMove, AddressOf picCanvas_MouseMove_MovingEndPoint
        RemoveHandler picCanvas.MouseUp, AddressOf picCanvas_MouseUp_MovingEndPoint

        ' Redraw.
        picCanvas.Refresh()
    End Sub

#End Region ' Moving End Point

#Region "Moving Segment"

    ' We're moving a segment.
    Private Sub picCanvas_MouseMove_MovingSegment(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs)
        ' See how far the first point will move.
        Dim new_x1 As Integer = e.X + OffsetX
        Dim new_y1 As Integer = e.Y + OffsetY

        Dim dx As Integer = new_x1 - Pt1(MovingSegment).X
        Dim dy As Integer = new_y1 - Pt1(MovingSegment).Y

        If ((dx = 0) AndAlso (dy = 0)) Then Exit Sub

        ' Move the segment to its new location.
        Pt1(MovingSegment) = New Point(new_x1, new_y1)
        Pt2(MovingSegment) = New Point( _
            Pt2(MovingSegment).X + dx, _
            Pt2(MovingSegment).Y + dy)

        ' Redraw.
        picCanvas.Refresh()
    End Sub

    ' Stop moving the segment.
    Private Sub picCanvas_MouseUp_MovingSegment(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs)
        ' Reset the event handlers.
        AddHandler picCanvas.MouseMove, AddressOf picCanvas_MouseMove_NotDown
        RemoveHandler picCanvas.MouseMove, AddressOf picCanvas_MouseMove_MovingSegment
        RemoveHandler picCanvas.MouseUp, AddressOf picCanvas_MouseUp_MovingSegment

        ' See if the mouse is over the trash can.
        If ((e.X >= 0) AndAlso (e.X < TrashWidth) AndAlso _
                (e.Y >= 0) AndAlso (e.Y < TrashHeight)) _
        Then
            If (MessageBox.Show("Delete this segment?", _
                "Delete Segment?", MessageBoxButtons.YesNo) _
                    = DialogResult.Yes) _
            Then
                ' Delete the segment.
                Pt1.RemoveAt(MovingSegment)
                Pt2.RemoveAt(MovingSegment)
            End If
        End If

        ' Redraw.
        picCanvas.Refresh()
    End Sub

#End Region ' Moving Segment

    ' See if the mouse is over an end point.
    Private Function MouseIsOverEndpoint(ByVal mouse_pt As Point, ByRef segment_number As Integer, ByRef hit_pt As Point) As Boolean
        For i As Integer = 0 To Pt1.Count - 1
            ' Check the starting point.
            If (FindDistanceToPointSquared(mouse_pt, Pt1(i)) < over_dist_squared) Then
                ' We're over this point.
                segment_number = i
                hit_pt = Pt1(i)
                Return True
            End If

            ' Check the end point.
            If (FindDistanceToPointSquared(mouse_pt, Pt2(i)) < over_dist_squared) Then
                ' We're over this point.
                segment_number = i
                hit_pt = Pt2(i)
                Return True
            End If
        Next i

        segment_number = -1
        hit_pt = New Point(-1, -1)
        Return False
    End Function

    ' See if the mouse is over a line segment.
    Private Function MouseIsOverSegment(ByVal mouse_pt As Point, ByRef segment_number As Integer) As Boolean
        For i As Integer = 0 To Pt1.Count - 1
            ' See if we're over the segment.
            Dim closest As PointF
            If (FindDistanceToSegmentSquared( _
                mouse_pt, Pt1(i), Pt2(i), closest) _
                < over_dist_squared) _
            Then
                ' We're over this segment.
                segment_number = i
                Return True
            End If
        Next i

        segment_number = -1
        Return False
    End Function

    ' Calculate the distance squared between two points.
    Private Function FindDistanceToPointSquared(ByVal pt1 As Point, ByVal pt2 As Point) As Integer
        Dim dx As Integer = pt1.X - pt2.X
        Dim dy As Integer = pt1.Y - pt2.Y
        Return dx * dx + dy * dy
    End Function

    ' Calculate the distance squared between
    ' point pt and the segment p1 --> p2.
    Private Function FindDistanceToSegmentSquared(ByVal pt As Point, ByVal p1 As Point, ByVal p2 As Point, _
        ByRef closest As PointF) As Double
        Dim dx As Single = p2.X - p1.X
        Dim dy As Single = p2.Y - p1.Y
        If ((dx = 0) AndAlso (dy = 0)) Then
            ' It's a point not a line segment.
            closest = p1
            dx = pt.X - p1.X
            dy = pt.Y - p1.Y
            Return dx * dx + dy * dy
        End If

        ' Calculate the t that minimizes the distance.
        Dim t As Single = ((pt.X - p1.X) * dx + (pt.Y - p1.Y) * dy) / (dx * dx + dy * dy)

        ' See if this represents one of the segment's
        ' end points or a point in the middle.
        If (t < 0) Then
            closest = New PointF(p1.X, p1.Y)
            dx = pt.X - p1.X
            dy = pt.Y - p1.Y
        ElseIf (t > 1) Then
            closest = New PointF(p2.X, p2.Y)
            dx = pt.X - p2.X
            dy = pt.Y - p2.Y
        Else
            closest = New PointF(p1.X + t * dx, p1.Y + t * dy)
            dx = pt.X - closest.X
            dy = pt.Y - closest.Y
        End If

        Return dx * dx + dy * dy
    End Function

    ' Draw the lines.
    Private Sub picCanvas_Paint(ByVal sender As System.Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles picCanvas.Paint
        e.Graphics.SmoothingMode = SmoothingMode.AntiAlias

        ' Draw the segments.
        For i As Integer = 0 To Pt1.Count - 1
            ' Draw the segment.
            e.Graphics.DrawLine(Pens.Blue, Pt1(i), Pt2(i))
        Next i

        ' Draw the end points.
        For Each pt As Point In Pt1
            Dim rect As New Rectangle( _
                pt.X - object_radius, pt.Y - object_radius, _
                2 * object_radius + 1, 2 * object_radius + 1)
            e.Graphics.FillEllipse(Brushes.White, rect)
            e.Graphics.DrawEllipse(Pens.Black, rect)
        Next pt

        For Each pt As Point In Pt2
            Dim rect As New Rectangle( _
                pt.X - object_radius, pt.Y - object_radius, _
                2 * object_radius + 1, 2 * object_radius + 1)
            e.Graphics.FillEllipse(Brushes.White, rect)
            e.Graphics.DrawEllipse(Pens.Black, rect)
        Next pt

        ' If there's a new segment under constructions, draw it.
        If (IsDrawing) Then
            e.Graphics.DrawLine(Pens.Red, NewPt1, NewPt2)
        End If

        ' Draw the trash can.
        Dim trash_rect As New Rectangle(0, 0, _
                TrashWidth, TrashHeight)
        e.Graphics.DrawImage( _
            My.Resources.trash_empty, _
            trash_rect)
    End Sub
End Class

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_open_file_image_filter
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Use many filters.
        private void btnDifferentTypes_Click(object sender, EventArgs e)
        {
            ofdImage.Filter =
                "Image files|*.bmp;*.jpg;*.gif;*.png;*.tif|" +
                "Bitmaps|*.bmp|PNG files|*.png|" +
                "JPEG files|*.jpg|GIF files|*.gif|TIFF files|*.tif|" +
                "All files|*.*";
            ofdImage.FilterIndex = 0;
            if (ofdImage.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    picImage.Image = new Bitmap(ofdImage.FileName);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        // Use only the Image files and All files filters.
        private void btnAllImages_Click(object sender, EventArgs e)
        {
            ofdImage.Filter =
                "Image files|*.bmp;*.jpg;*.gif;*.png;*.tif|" +
                "All files|*.*";
            ofdImage.FilterIndex = 0;
            if (ofdImage.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    picImage.Image = new Bitmap(ofdImage.FileName);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }
    }
}

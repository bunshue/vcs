﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Drawing.Drawing2D;

namespace howto_fibonacci_phi
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // The Fibonacci values.
        private double[] Fibonacci;

        // Phi.
        private double Phi;

        // Make a list of Fibonacci numbers.
        private void Form1_Load(object sender, EventArgs e)
        {
            // Display phi.
            Phi = (1 + Math.Sqrt(5)) / 2;
            txtPhi.Text = Phi.ToString("n15");

            // Calculate Fibonacci values.
            Fibonacci = new double[45];
            Fibonacci[0] = 0;
            Fibonacci[1] = 1;
            for (int n = 2; n < Fibonacci.Length; n++)
            {
                Fibonacci[n] = Fibonacci[n - 1] + Fibonacci[n - 2];
            }

            // Display values.
            for (int n = 0; n < Fibonacci.Length; n++)
            {
                ListViewItem item = lvwValues.Items.Add(n.ToString());
                item.SubItems.Add(Fibonacci[n].ToString());
                if (n > 1)
                {
                    double ratio = Fibonacci[n] / Fibonacci[n - 1];
                    item.SubItems.Add(ratio.ToString("n15"));
                    double difference = ratio - Phi;
                    item.SubItems.Add(difference.ToString("e2"));
                }
            }

            lvwValues.AutoResizeColumns(ColumnHeaderAutoResizeStyle.ColumnContent);
        }

        // Draw the graph.
        private void picGraph_Paint(object sender, PaintEventArgs e)
        {
            DrawGraph(e.Graphics);
        }

        // Redraw the graph.
        private void picGraph_Resize(object sender, EventArgs e)
        {
            picGraph.Refresh();
        }

        // Draw the graph on a Graphics object.
        private void DrawGraph(Graphics gr)
        {
            gr.SmoothingMode = SmoothingMode.AntiAlias;
            using (Pen thin_pen = new Pen(Color.Black, 0))
            {
                // Make a trsnaformation matrix to make drawing easier.
                const float xmin = -0.1f;
                const float ymin = -0.1f;
                const float xmax = 9.1f;
                const float ymax = 2.2f;
                RectangleF src_rect = new RectangleF(
                    xmin, ymin, xmax - xmin, ymax - ymin);
                PointF[] pts = 
                {
                    new PointF(0, picGraph.ClientSize.Height),
                    new PointF(picGraph.ClientSize.Width, picGraph.ClientSize.Height),
                    new PointF(0, 0)
                };
                Matrix trans = new Matrix(src_rect, pts);

                // Draw numbers along the X-axis.
                List<PointF> x_pt_list = new List<PointF>();
                for (int x = (int)xmin; x <= xmax; x++)
                {
                    x_pt_list.Add(new PointF(x, 0.1f));
                }
                PointF[] x_pt_array = x_pt_list.ToArray();
                trans.TransformPoints(x_pt_array);
                using (StringFormat string_format = new StringFormat())
                {
                    string_format.Alignment = StringAlignment.Center;
                    string_format.LineAlignment = StringAlignment.Far;
                    int index = 0;
                    for (int x = (int)xmin; x <= xmax; x++)
                    {
                        gr.DrawString(x.ToString(), this.Font, Brushes.Black,
                            x_pt_array[index], string_format);
                        index++;
                    }
                }

                // Draw numbers along the Y-axis.
                List<PointF> y_pt_list = new List<PointF>();
                for (int y = (int)ymin; y <= ymax; y++)
                {
                    y_pt_list.Add(new PointF(0.2f, y));
                }
                PointF[] y_pt_array = y_pt_list.ToArray();
                trans.TransformPoints(y_pt_array);
                using (StringFormat string_format = new StringFormat())
                {
                    string_format.Alignment = StringAlignment.Near;
                    string_format.LineAlignment = StringAlignment.Center;
                    int index = 0;
                    for (int y = (int)ymin; y <= ymax; y++)
                    {
                        gr.DrawString(y.ToString(), this.Font, Brushes.Black,
                            y_pt_array[index], string_format);
                        index++;
                    }
                }

                // Transform the Graphics object for drawing.
                gr.Transform = new Matrix(src_rect, pts);

                // Draw the axes.
                gr.DrawLine(thin_pen, xmin, 0, xmax, 0);
                for (int y = (int)ymin; y <= ymax; y++)
                {
                    gr.DrawLine(thin_pen, -0.1f, y, 0.1f, y);
                }
                gr.DrawLine(thin_pen, 0, ymin, 0, ymax);
                for (int x = (int)xmin; x <= xmax; x++)
                {
                    gr.DrawLine(thin_pen, x, -0.1f, x, 0.1f);
                }

                // Draw phi.
                thin_pen.Color = Color.Green;
                gr.DrawLine(thin_pen, xmin, (float)Phi, xmax, (float)Phi);

                // Draw the points.
                List<PointF> fib_points = new List<PointF>();
                for (int n = 2; n <= xmax; n++)
                {
                    float ratio = (float)(Fibonacci[n] / Fibonacci[n - 1]);
                    fib_points.Add(new PointF(n, ratio));

                }
                thin_pen.Color = Color.Red;
                //gr.DrawLines(thin_pen, fib_points.ToArray());
                gr.DrawCurve(thin_pen, fib_points.ToArray());
            }
        }
    }
}

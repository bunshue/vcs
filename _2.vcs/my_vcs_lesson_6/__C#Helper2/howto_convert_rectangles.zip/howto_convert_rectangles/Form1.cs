﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_convert_rectangles
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.ResizeRedraw = true;
        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            // Make a rectangle.
            Rectangle rect1 = new Rectangle(20, 20,
                this.ClientSize.Width - 40,
                this.ClientSize.Height - 40);

            // Convert to RectangleF.
            RectangleF rectf = rect1;

            // Convert back to Rectangle.
            Rectangle rect2 = Rectangle.Round(rectf);
            //Rectangle rect2 = Rectangle.Truncate(rectf);

            // Draw them.
            using (Pen the_pen = new Pen(Color.Red, 20))
            {
                e.Graphics.DrawRectangle(the_pen, rect1);

                the_pen.Color = Color.Lime;
                the_pen.Width = 10;
                e.Graphics.DrawRectangle(the_pen,
                    rectf.X, rectf.Y, rectf.Width, rectf.Height);

                the_pen.Color = Color.Blue;
                the_pen.Width = 1;
                e.Graphics.DrawRectangle(the_pen, rect2);
            }
        }
    }
}

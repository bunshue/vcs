using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_tile_image
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Tile the image.
        private void picTile_Paint(object sender, PaintEventArgs e)
        {
            using (TextureBrush brush = new TextureBrush(Properties.Resources.Smiley))
            {
                e.Graphics.FillRectangle(brush, picTile.ClientRectangle);
            }
        }

        // Refresh the PictureBox.
        private void Form1_Resize(object sender, EventArgs e)
        {
            picTile.Refresh();
        }
    }
}

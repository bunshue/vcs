﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.IO;//@
using System.Drawing.Imaging;//@

namespace howto_animate_rainbow_colors
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // The currently selected color and its number.
        private Color SelectedColor;
        private float SelectedRainbowNumber;

        // The animation parameters.
        private const float ColorDelta = 0.02f;
        private int Interval = 20;

        // Start with red selected.
        private void Form1_Load(object sender, EventArgs e)
        {
            tmrMoveSample.Interval = Interval;
            SelectedColor = Color.Red;
            SelectedRainbowNumber = 0;
        }

        // Redraw the controls.
        private void picRainbow_Resize(object sender, EventArgs e)
        {
            picRainbow.Refresh();
        }
        private void picSample_Resize(object sender, EventArgs e)
        {
            picSample.Refresh();
        }

        // Draw the rainbow and the selected number.
        private void picRainbow_Paint(object sender, PaintEventArgs e)
        {
            // Draw the rainbow.
            using (Brush rainbow_brush = Rainbow.RainbowBrush(
                new Point(0, 0),
                new Point(picRainbow.ClientSize.Width, picRainbow.ClientSize.Height)))
            {
                e.Graphics.FillRectangle(rainbow_brush, picRainbow.ClientRectangle);
            }

            // Get and draw the selected location.
            int x = (int)(SelectedRainbowNumber * picRainbow.ClientSize.Width);
            Point[] pts =
            {
                new Point(x - 5, 0),
                new Point(x, 5),
                new Point(x + 5, 0)
            };
            e.Graphics.FillPolygon(Brushes.Black, pts);
        }

        // Draw the sample color.
        private void picSample_Paint(object sender, PaintEventArgs e)
        {
            picSample.BackColor = SelectedColor;
        }

        // Start or stop animating the rainbow colors.
        private void picRainbow_MouseClick(object sender, MouseEventArgs e)
        {
            // See if we should start or stop.
            if (tmrMoveSample.Enabled)
            {
                // Stop animating.
                tmrMoveSample.Enabled = false;
                return;
            }
            
            // Get the mouse position as a fraction
            // of the width of the PictureBox.
            float rainbow_color = e.X / (float)picRainbow.ClientSize.Width;

            // Convert into the corresponding color.
            SelectedColor = Rainbow.RainbowNumberToColor(rainbow_color);

            // Convert back into the corresponding number.
            SelectedRainbowNumber = Rainbow.ColorToRainbowNumber(SelectedColor);

            // Redraw.
            picRainbow.Refresh();
            picSample.Refresh();

            // Start animating.
            tmrMoveSample.Enabled = true;
        }

        // Continue animating the rainbow colors.
        private void tmrMoveSample_Tick(object sender, EventArgs e)
        {
            // Update the current color.
            SelectedRainbowNumber += ColorDelta;
            if (SelectedRainbowNumber > 1f)
                SelectedRainbowNumber = 0f;
            SelectedColor =
                Rainbow.RainbowNumberToColor(SelectedRainbowNumber);
           
            // Draw the new color.
            picRainbow.Refresh();
            picSample.Refresh();
        }
    }
}

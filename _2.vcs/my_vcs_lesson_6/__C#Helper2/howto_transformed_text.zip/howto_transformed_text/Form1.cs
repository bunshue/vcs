﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Drawing.Drawing2D;
using System.Drawing.Text;

namespace howto_transformed_text
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Draw some transformed text.
        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            // Transform.
            e.Graphics.ScaleTransform(1.5f, 1.5f, MatrixOrder.Append);
            e.Graphics.RotateTransform(25, MatrixOrder.Append);
            e.Graphics.TranslateTransform(80, 30, MatrixOrder.Append);

            // Make a font.
            using (Font the_font = new Font("Times New Roman", 20,
                FontStyle.Regular, GraphicsUnit.Pixel))
            {
                // See how big the text will be when drawn.
                string the_text = "WYSIWYG";
                SizeF text_size = e.Graphics.MeasureString(the_text, the_font);

                // Draw a rectangle and two ellipses.
                e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
                e.Graphics.DrawRectangle(Pens.Blue, 0, 0,
                    text_size.Width, text_size.Height);
                e.Graphics.DrawEllipse(Pens.Red, -3, -3, 6, 6);
                e.Graphics.DrawEllipse(Pens.Green,
                    text_size.Width - 3, text_size.Height - 3, 6, 6);

                // Draw the text.
                e.Graphics.TextRenderingHint =
                    TextRenderingHint.AntiAliasGridFit;
                e.Graphics.DrawString(the_text, the_font,
                    Brushes.Brown, 0, 0);
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Media;

// Pop sound file by Mike Koenig, courtesy of SoundBible.com
//      http://soundbible.com/533-Pop-Cork.html

namespace howto_grow_shrink_buttons
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // The sound effect.
        private SoundPlayer PopPlayer =
            new SoundPlayer(Properties.Resources.Pop);

        // The small and large button sizes.
        private Size SmallSize, LargeSize;
        private Font SmallFont, LargeFont;

        // Set the small and large sizes.
        private void Form1_Load(object sender, EventArgs e)
        {
            SmallSize = btnOpen.Size;
            LargeSize = new Size(
                (int)(1.5 * btnOpen.Size.Width),
                (int)(1.5 * btnOpen.Size.Height));

            SmallFont = btnOpen.Font;
            LargeFont = new Font(
                SmallFont.FontFamily,
                SmallFont.Size * 1.5f,
                FontStyle.Bold);
        }

        // Enlarge the button.
        private void btn_MouseEnter(object sender, EventArgs e)
        {
            Button btn = sender as Button;
            btn.Size = LargeSize;
            btn.Font = LargeFont;

            // Play the pop sound.
            PopPlayer.Play();
        }

        // Shrink the button.
        private void btn_MouseLeave(object sender, EventArgs e)
        {
            Button btn = sender as Button;
            btn.Size = SmallSize;
            btn.Font = SmallFont;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Media;

namespace howto_threading_countdown
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // The timer.
        System.Threading.Timer TheTimer = null;

        // Initialize information about the event.
        private DateTime EventDate = new DateTime(2017, 4, 1);

        private void Form1_Load(object sender, EventArgs e)
        {
            // Make the timer start now and tick every 500 ms.
            TheTimer = new System.Threading.Timer(
                this.Tick, null, 0, 500);
        }

        // The timer ticked.
        public void Tick(object info)
        {
            this.Invoke((Action)this.UpdateCountdown);
        }

        // Update the countdown on the UI thread.
        private void UpdateCountdown()
        {
            TimeSpan remaining = EventDate - DateTime.Now;
            if (remaining.TotalSeconds < 1)
            {
                TheTimer.Dispose();
                this.WindowState = FormWindowState.Maximized;
                this.TopMost = true;

                foreach (Control ctl in this.Controls)
                    ctl.Visible = (ctl == lblFinished);

                using (SoundPlayer player = new SoundPlayer(
                    Properties.Resources.tada))
                {
                    player.Play();
                }
            }
            else
            {
                lblDays.Text = remaining.Days + " days";
                lblHours.Text = remaining.Hours + " hours";
                lblMinutes.Text = remaining.Minutes + " minutes";
                lblSeconds.Text = remaining.Seconds + " seconds";
            }
        }

        // Stop the timer.
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (TheTimer != null) TheTimer.Dispose();
        }
    }
}

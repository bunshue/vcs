﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_list_controls
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // List all of the controls on the form.
        private void Form1_Load(object sender, EventArgs e)
        {
            // List the controls in a ListBox.
            ListControls(lstControls, this, 0);

            // List the controls in a TreeView.
            ListControls(trvControls.Nodes, this);
            trvControls.ExpandAll();
        }

        // List the controls in a ListBox.
        private void ListControls(ListBox lst, Object parent, int indent)
        {
            string spaces = new string(' ', indent);
            if (parent is ToolStrip)
            {
                // Note that a StatusStrip is also a ToolStrip.
                ToolStrip tool_strip = parent as ToolStrip;
                lst.Items.Add(spaces +
                    tool_strip.Name + " (" +
                    tool_strip.GetType().Name + ")");
                foreach (ToolStripItem item in tool_strip.Items)
                {
                    ListControls(lst, item, indent + 4);
                }
            }
            else if (parent is ToolStripDropDownButton)
            {
                // ToolStripDropDownButton inherits from ToolStripItem
                // so it must come first in this if-else-if sequence.
                ToolStripDropDownButton dropdown_button =
                    parent as ToolStripDropDownButton;
                lst.Items.Add(spaces +
                    dropdown_button.Name + " (" +
                    dropdown_button.GetType().Name + ")");
                ListControls(lst, dropdown_button.DropDown, indent + 4);
            }
            else if (parent is ToolStripSplitButton)
            {
                // ToolStripSplitButton inherits from ToolStripItem
                // so it must come first in this if-else-if sequence.
                ToolStripSplitButton split_button =
                    parent as ToolStripSplitButton;
                lst.Items.Add(spaces +
                    split_button.Name + " (" +
                    split_button.GetType().Name + ")");
                ListControls(lst, split_button.DropDown, indent + 4);
            }
            else if (parent is ToolStripMenuItem)
            {
                // ToolStripMenuItem inherits from ToolStripItem
                // so it must come first in this if-else-if sequence.
                ToolStripMenuItem item = parent as ToolStripMenuItem;
                lst.Items.Add(spaces +
                    item.Name + " (" +
                    item.GetType().Name + ")");
                ListControls(lst, item.DropDown, indent + 4);
            }
            else if (parent is ToolStripItem)
            {
                ToolStripItem item = parent as ToolStripItem;
                lst.Items.Add(spaces +
                    item.Name + " (" +
                    item.GetType().Name + ")");
            }
            else if (parent is Control)
            {
                Control control = parent as Control;
                lst.Items.Add(spaces +
                    control.Name + " (" +
                    control.GetType().Name + ")");
                foreach (Control child in control.Controls)
                {
                    ListControls(lst, child, indent + 4);
                }
            }
        }

        // List the controls in a TreeView.
        private void ListControls(TreeNodeCollection nodes, Object parent)
        {
            if (parent is ToolStrip)
            {
                // Note that a StatusStrip is also a ToolStrip.
                ToolStrip tool_strip = parent as ToolStrip;
                TreeNode new_node = nodes.Add(
                    tool_strip.Name + " (" +
                    tool_strip.GetType().Name + ")");
                foreach (ToolStripItem item in tool_strip.Items)
                {
                    ListControls(new_node.Nodes, item);
                }
            }
            else if (parent is ToolStripDropDownButton)
            {
                // ToolStripDropDownButton inherits from ToolStripItem
                // so it must come first in this if-else-if sequence.
                ToolStripDropDownButton dropdown_button =
                    parent as ToolStripDropDownButton;
                TreeNode new_node = nodes.Add(
                    dropdown_button.Name + " (" +
                    dropdown_button.GetType().Name + ")");
                ListControls(new_node.Nodes, dropdown_button.DropDown);
            }
            else if (parent is ToolStripSplitButton)
            {
                // ToolStripSplitButton inherits from ToolStripItem
                // so it must come first in this if-else-if sequence.
                ToolStripSplitButton split_button =
                    parent as ToolStripSplitButton;
                TreeNode new_node = nodes.Add(
                    split_button.Name + " (" +
                    split_button.GetType().Name + ")");
                ListControls(new_node.Nodes, split_button.DropDown);
            }
            else if (parent is ToolStripMenuItem)
            {
                // ToolStripMenuItem inherits from ToolStripItem
                // so it must come first in this if-else-if sequence.
                ToolStripMenuItem item = parent as ToolStripMenuItem;
                TreeNode new_node = nodes.Add(
                    item.Name + " (" +
                    item.GetType().Name + ")");
                ListControls(new_node.Nodes, item.DropDown);
            }
            else if (parent is ToolStripItem)
            {
                ToolStripItem item = parent as ToolStripItem;
                TreeNode new_node = nodes.Add(
                    item.Name + " (" +
                    item.GetType().Name + ")");
            }
            else if (parent is Control)
            {
                Control control = parent as Control;
                TreeNode new_node = nodes.Add(
                    control.Name + " (" +
                    control.GetType().Name + ")");
                foreach (Control child in control.Controls)
                {
                    ListControls(new_node.Nodes, child);
                }
            }
        }

        // Set a tool strip item's image to match the clicked tool.
        private void btnTool_Click(object sender, EventArgs e)
        {
            ToolStripMenuItem item = sender as ToolStripMenuItem;
            item.OwnerItem.Image = item.Image;
        }
    }
}

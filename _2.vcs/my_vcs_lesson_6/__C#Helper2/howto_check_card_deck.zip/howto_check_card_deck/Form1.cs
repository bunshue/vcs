﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_check_card_deck
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // The original image.
        private Bitmap OriginalImage = null;

        // Save the original image.
        private void Form1_Load(object sender, EventArgs e)
        {
            OriginalImage = picDeck.Image as Bitmap;
        }

        // Draw lines on the deck to show where the cards are.
        private void btnOutline_Click(object sender, EventArgs e)
        {
            int NumSuits = int.Parse(txtNumSuits.Text);
            int NumRanks = int.Parse(txtNumRanks.Text);

            Bitmap bm = new Bitmap(OriginalImage);
            using (Graphics gr = Graphics.FromImage(bm))
            {
                int wid = bm.Width / NumRanks;
                int hgt = bm.Height / NumSuits;
                for (int x = 0; x <= NumRanks; x++)
                    gr.DrawLine(Pens.Blue, x * wid, 0, x * wid, bm.Height);
                for (int y = 0; y <= NumSuits; y++)
                    gr.DrawLine(Pens.Blue, 0, y * hgt, bm.Width, y * hgt);
            }
            picDeck.Image = bm;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_stddev_extension
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Make some data.
        private void Form1_Load(object sender, EventArgs e)
        {
            // Make the values.
            Random rand = new Random();
            const int num_values = 100;

            // List version.
            List<int> values = new List<int>();
            for (int i = 0; i < num_values; i++)
            {
                values.Add(rand.Next(1, 7) + rand.Next(1, 7));
            }

            // Array version.
            //int[] values = new int[num_values];
            //for (int i = 0; i < num_values; i++)
            //{
            //    values[i] = rand.Next(1, 7) + rand.Next(1, 7);
            //}

            // Display the values.
            lstValues.DataSource = values;

            // Display statistics.
            txtAverage.Text = values.Average().ToString("0.00");
            txtStddevSample.Text = values.StdDev(true).ToString("0.00");
            txtStddevPopulation.Text = values.StdDev(false).ToString("0.00");

            // Make a simple histogram.
            Label[] labels = { lbl2, lbl3, lbl4, lbl5, lbl6, lbl7, lbl8, lbl9, lbl10, lbl11, lbl12 };
            int bottom = lbl2.Bottom;
            foreach (Label lbl in labels) lbl.Height = 1;
            const int pixel_scale = 10;
            for (int i = 0; i < num_values; i++)
            {
                int index = values[i] - 2;
                labels[index].Height += pixel_scale;
            }
            foreach (Label lbl in labels)
            {
                lbl.Top = bottom - lbl.Height;
            }
        }
    }
}

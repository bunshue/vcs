﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.IO;
using System.Drawing.Imaging;

namespace howto_make_light_transparent
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // The original image.
        Bitmap OriginalImage = null;

        // Load a file.
        private void mnuFileOpen_Click(object sender, EventArgs e)
        {
            if (ofdImage.ShowDialog() == DialogResult.OK)
            {
                OriginalImage = new Bitmap(ofdImage.FileName);
                ShowImage();
                mnuFileSave.Enabled = true;
            }
        }

        // Make magenta pixels transparent and save the result.
        private void mnuFileSave_Click(object sender, EventArgs e)
        {
            if (sfdImage.ShowDialog() == DialogResult.OK)
            {
                // Make a copy of the result image.
                using (Bitmap bm = (Bitmap)picResult.Image.Clone())
                {
                    bm.MakeTransparent(Color.Magenta);
                    
                    // Save the image.
                    SaveImage(bm, sfdImage.FileName);
                }
            }
        }

        private void mnuFileExit_Click(object sender, EventArgs e)
        {
            Close();
        }

        // Rebuild the image.
        private void scrBrightness_Scroll(object sender, ScrollEventArgs e)
        {
            lblBrightness.Text = scrBrightness.Value.ToString();
            ShowImage();
        }

        // Make an image setting pixels brighter
        // than the cutoff value to magenta.
        private void ShowImage()
        {
            if (OriginalImage == null) return;

            // Get the cutoff.
            int cutoff = scrBrightness.Value;

            // Prepare the ImageAttributes.
            Color low_color = Color.FromArgb(cutoff, cutoff, cutoff);
            Color high_color = Color.FromArgb(255, 255, 255);
            ImageAttributes image_attr = new ImageAttributes();
            image_attr.SetColorKey(low_color, high_color);

            // Make the result image.
            int wid = OriginalImage.Width;
            int hgt  = OriginalImage.Height;
            Bitmap bm = new Bitmap(wid, hgt);

            // Process the image.
            using (Graphics gr = Graphics.FromImage(bm))
            {
                // Fill with magenta.
                gr.Clear(Color.Magenta);

                // Copy the original image onto the result
                // image while using the ImageAttributes.
                Rectangle dest_rect = new Rectangle(0, 0, wid, hgt);
                gr.DrawImage(OriginalImage, dest_rect,
                    0, 0, wid, hgt, GraphicsUnit.Pixel, image_attr);
            }

            // Display the image.
            picResult.Image = bm;
        }

        // Save the file with the appropriate format.
        public void SaveImage(Image image, string filename)
        {
            string extension = Path.GetExtension(filename);
            switch (extension.ToLower())
            {
                case ".bmp":
                    image.Save(filename, ImageFormat.Bmp);
                    break;
                case ".exif":
                    image.Save(filename, ImageFormat.Exif);
                    break;
                case ".gif":
                    image.Save(filename, ImageFormat.Gif);
                    break;
                case ".jpg":
                case ".jpeg":
                    image.Save(filename, ImageFormat.Jpeg);
                    break;
                case ".png":
                    image.Save(filename, ImageFormat.Png);
                    break;
                case ".tif":
                case ".tiff":
                    image.Save(filename, ImageFormat.Tiff);
                    break;
                default:
                    throw new NotSupportedException(
                        "Unknown file extension " + extension);
            }
        }
    }
}

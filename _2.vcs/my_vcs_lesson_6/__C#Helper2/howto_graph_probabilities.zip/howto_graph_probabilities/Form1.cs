﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Drawing.Drawing2D;

namespace howto_graph_probabilities
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // The probability data.
        private PointF[] Points = { };

        // Calculate and display probabilities.
        private void btnGo_Click(object sender, EventArgs e)
        {
            // Make room for the probabilities.
            int num_events = int.Parse(txtMaxNumberEvents.Text);
            Points = new PointF[num_events + 1];

            // Get the event probability.
            double event_prob = double.Parse(txtEventProb.Text.Replace("%", ""));
            if (txtEventProb.Text.Contains("%")) event_prob /= 100.0;

            // Get the probability of the event not happening.
            double non_prob = 1.0 - event_prob;

            for (int i = 0; i <= num_events; i++)
            {
                Points[i].X = i;
                Points[i].Y = 100 * (float)(1.0 - Math.Pow(non_prob, i));
            }

            // Redraw.
            picGraph.Refresh();
        }

        // Draw the data.
        private void picGraph_Paint(object sender, PaintEventArgs e)
        {
            // Clear.
            e.Graphics.Clear(picGraph.BackColor);
            if (Points.Length < 2) return;
            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;

            // Transform from world coordinates to screen coordinates.
            RectangleF rect = new RectangleF(0, 0, Points.Length + 1, 100);
            PointF[] pts =
            {
                new PointF(0, picGraph.ClientSize.Height),
                new PointF(picGraph.ClientSize.Width, picGraph.ClientSize.Height),
                new PointF(0, 0)
            };
            Matrix transform = new Matrix(rect, pts);

            using (Pen pen = new Pen(Color.Gray, 0))
            {
                // Draw the axes.
                using (StringFormat sf = new StringFormat())
                {
                    sf.LineAlignment = StringAlignment.Center;
                    for (int i = 0; i <= 100; i += 10)
                    {
                        // See where this should be.
                        pts = new PointF[]
                        {
                            new PointF(0, i),
                            new PointF(Points.Length, i),
                        };
                        transform.TransformPoints(pts);
                        e.Graphics.DrawLine(pen, pts[0], pts[1]);
                        e.Graphics.DrawString(i.ToString(), this.Font,
                            Brushes.Green, pts[0], sf);
                    }

                    sf.Alignment = StringAlignment.Center;
                    sf.LineAlignment = StringAlignment.Far;
                    int skip = (int)(Points.Length / 10);
                    skip = 5 * (int)(skip / 5);
                    if (skip < 1) skip = 1;
                    for (int i = 0; i < Points.Length; i += skip)
                    {
                        // See where this should be.
                        pts = new PointF[]
                        {
                            new PointF(i, 0),
                            new PointF(i, 5),
                        };
                        transform.TransformPoints(pts);
                        e.Graphics.DrawLine(pen, pts[0], pts[1]);
                        e.Graphics.DrawString(i.ToString(), this.Font,
                            Brushes.Green, pts[0], sf);
                    }
                }

                // Draw the graph.
                pen.Color = Color.Blue;
                e.Graphics.Transform = transform;
                e.Graphics.DrawLines(pen, Points);
            }
        }

        private void picGraph_Resize(object sender, EventArgs e)
        {
            picGraph.Refresh();
        }
    }
}

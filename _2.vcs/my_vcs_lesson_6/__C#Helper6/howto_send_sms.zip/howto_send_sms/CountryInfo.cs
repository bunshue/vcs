﻿using System;
using System.Collections.Generic;

namespace howto_send_sms
{
    public class CountryInfo
    {
        public string CountryAbbreviation, CountryName;
        public List<CarrierInfo> Carriers = new List<CarrierInfo>();

        public override string ToString()
        {
            return CountryName;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

// Add a reference to System.Web.Extensions.dll.
using System.Web.Script.Serialization;

using System.IO;
using System.Net;
using System.Net.Mail;
using System.Web;

namespace howto_send_sms
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // Get the data file.
            const string url = "https://raw.github.com/cubiclesoft/email_sms_mms_gateways/master/sms_mms_gateways.txt";
            string serialization = GetTextFile(url);

            // Add a reference to System.Web.Extensions.dll.
            JavaScriptSerializer serializer = new JavaScriptSerializer();
            Dictionary<string, object> dict =
                (Dictionary<string, object>)serializer.DeserializeObject(serialization);

            // Get the countries.
            Dictionary<string, CountryInfo> country_infos = new Dictionary<string, CountryInfo>();
            Dictionary<string, object> countries = (Dictionary<string, object>)dict["countries"];
            foreach (KeyValuePair<string, object> pair in countries)
            {
                CountryInfo country_info = new CountryInfo() { CountryAbbreviation = pair.Key, CountryName = (string)pair.Value };
                country_infos.Add(country_info.CountryAbbreviation, country_info);
            }

            // Get the SMS carriers.
            Dictionary<string, object> sms_carriers = (Dictionary<string, object>)dict["sms_carriers"];
            foreach (KeyValuePair<string, object> pair in sms_carriers)
            {
                // Get the corresponding CountryInfo.
                CountryInfo country_info = country_infos[pair.Key];

                // Get the country's carriers.
                Dictionary<string, object> carriers = (Dictionary<string, object>)pair.Value;
                foreach (KeyValuePair<string, object> carrier_pair in carriers)
                {
                    // Create a CarrierInfo for this carrier.
                    CarrierInfo carrier_info = new CarrierInfo() { CarrierAbbreviation = carrier_pair.Key };
                    country_info.Carriers.Add(carrier_info);
                    object[] carrier_values = (object[])carrier_pair.Value;
                    carrier_info.CarrierName = (string)carrier_values[0];
                    for (int email_index = 1; email_index < carrier_values.Length; email_index++)
                    {
                        string email = (string)carrier_values[email_index];
                        carrier_info.Emails.Add(email.Replace("{number}@", ""));
                    }
                }
            }

            // Display the countries.
            cboCountry.Items.Clear();
            foreach (CountryInfo country in country_infos.Values)
            {
                cboCountry.Items.Add(country);
            }

            // Make an initial selection.
            cboCountry.SelectedIndex = 0;
        }

        // Get the text file at a given URL.
        private string GetTextFile(string url)
        {
            try
            {
                url = url.Trim();
                if (!url.ToLower().StartsWith("http")) url = "http://" + url;
                WebClient web_client = new WebClient();
                MemoryStream image_stream = new MemoryStream(web_client.DownloadData(url));
                StreamReader reader = new StreamReader(image_stream);
                string result = reader.ReadToEnd();
                reader.Close();
                return result;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error downloading file " +
                    url + '\n' + ex.Message,
                    "Download Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
            return "";
        }

        // Display the selected country's carriers.
        private void cboCountry_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cboCountry.SelectedIndex < 0)
            {
                cboCarrier.SelectedIndex = -1;
            }
            else
            {
                // Get the selected CountryInfo object.
                CountryInfo country = cboCountry.SelectedItem as CountryInfo;
                Console.WriteLine("Country: " + country.CountryAbbreviation + ": " + country.CountryName);

                // Display the CountryCarrier's carriers.
                cboCarrier.DataSource = country.Carriers;
            }
        }

        // Display the selected carrier's emails addresses.
        private void cboCarrier_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cboCarrier.SelectedIndex < 0)
            {
                cboEmail.SelectedIndex = -1;
            }
            else
            {
                // Get the selected CarrierInfo object.
                CarrierInfo carrier = cboCarrier.SelectedItem as CarrierInfo;
                Console.WriteLine("Carrier: " + carrier.CarrierName);

                // Display the Carrier's email addresses.
                cboEmail.DataSource = carrier.Emails;
            }
        }

        // Send the message.
        private void btnSend_Click(object sender, EventArgs e)
        {
            try
            {
                string carrier_email = cboEmail.SelectedItem.ToString();
                string phone = txtPhone.Text.Trim().Replace("-", "");
                phone = phone.Replace("(", "").Replace(")", "").Replace("+", "");
                string to_email = phone + "@" + carrier_email;

                SendEmail(txtToName.Text, to_email,
                    txtFromName.Text, txtFromEmail.Text,
                    txtHost.Text, int.Parse(txtPort.Text),
                    chkEnableSSL.Checked, txtPassword.Text,
                    txtSubject.Text, txtBody.Text);

                MessageBox.Show("Message sent");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        // Send an email message.
        private void SendEmail(string to_name, string to_email,
            string from_name, string from_email,
            string host, int port, bool enable_ssl, string password,
            string subject, string body)
        {
            // Make the mail message.
            MailAddress from_address = new MailAddress(from_email, from_name);
            MailAddress to_address = new MailAddress(to_email, to_name);
            MailMessage message = new MailMessage(from_address, to_address);
            message.Subject = subject;
            message.Body = body;

            // Get the SMTP client.
            SmtpClient client = new SmtpClient()
            {
                Host = host,
                Port = port,
                EnableSsl = enable_ssl,
                UseDefaultCredentials = false,
                Credentials = new NetworkCredential(from_address.Address, password),
            };

            // Send the message.
            client.Send(message);
        }
    }
}

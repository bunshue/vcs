﻿using System;
using System.Collections.Generic;

namespace howto_send_sms
{
    public class CarrierInfo
    {
        public string CarrierAbbreviation, CarrierName;
        public List<string> Emails = new List<string>();

        public override string ToString()
        {
            return CarrierName;
        }
    }
}

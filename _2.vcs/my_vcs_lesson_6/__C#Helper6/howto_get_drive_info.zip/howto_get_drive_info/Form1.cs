﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.IO;

namespace howto_get_drive_info
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Make a list of drives.
        private void Form1_Load(object sender, EventArgs e)
        {
            foreach (DriveInfo di in DriveInfo.GetDrives())
            {
                cboDrive.Items.Add(di.Name);
                cboDrive.SelectedIndex = 0;
            }
        }

        // Display information about the selected drive.
        private void cboDrive_SelectedIndexChanged(object sender, EventArgs e)
        {
            string drive_letter = cboDrive.Text.Substring(0, 1);
            DriveInfo di = new DriveInfo(drive_letter);
            lblIsReady.Text = di.IsReady.ToString();
            lblDriveType.Text = di.DriveType.ToString();
            lblName.Text = di.Name;
            lblRootDirectory.Text = di.RootDirectory.Name;
            if (di.IsReady)
            {
                lblDriveFormat.Text = di.DriveFormat;
                lblAvailableFreeSpace.Text = di.AvailableFreeSpace.ToString();
                lblTotalFreeSize.Text = di.TotalFreeSpace.ToString();
                lblTotalSize.Text = di.TotalSize.ToString();
                lblVolumeLabel.Text = di.VolumeLabel;
            }
            else
            {
                lblDriveFormat.Text = "";
                lblAvailableFreeSpace.Text = "";
                lblTotalFreeSize.Text = "";
                lblTotalSize.Text = "";
                lblVolumeLabel.Text = "";
            }
        }
    }
}

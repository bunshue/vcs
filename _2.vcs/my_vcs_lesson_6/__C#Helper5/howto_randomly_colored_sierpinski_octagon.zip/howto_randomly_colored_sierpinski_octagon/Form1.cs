﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Drawing.Drawing2D;

namespace howto_randomly_colored_sierpinski_octagon
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // The root of the Octagon object hierarchy.
        private Octagon Root = null;

        // Redraw.
        private void nudDepth_ValueChanged(object sender, EventArgs e)
        {
            MakeOctagons();
        }
        //Refresh
        private void button_refresh_Click(object sender, EventArgs e)
        {
            MakeOctagons();
        }


        // Make the Octagon objects and redraw.
        private void MakeOctagons()
        {
            // Build the Root.
            int depth = (int)nudDepth.Value;

            PointF center = new PointF(
                picCanvas.ClientSize.Width / 2,
                picCanvas.ClientSize.Height / 2);
            float radius = (float)Math.Min(center.X, center.Y);
            radius -= 5;
            Root = MakeOctagon(depth, center, radius);

            // Redraw.
            picCanvas.Refresh();
        }

        // Scale factor for moving to smaller octagons.
        private float size_scale = (float)(1.0 /
            (2.0 * (1 + Math.Cos(Math.PI / 180 * 45))));

        // Recursively generate a Octagon and its descendants.
        private Octagon MakeOctagon(int depth, PointF center, float radius)
        {
            // Make the Octagon.
            Octagon parent = new Octagon(GetOctagonPoints(center, radius));

            // If we are not done recursing, make children.
            if (depth > 0)
            {
                // Find the smaller octagons' centers.
                float d = radius - radius * size_scale;
                PointF[] centers = GetOctagonPoints(center, d);

                // Recursively draw the smaller octagons.
                foreach (PointF point in centers)
                {
                    parent.Children.Add(MakeOctagon(
                        depth - 1, point, radius * size_scale));
                }
            }

            return parent;
        }

        // Find the octagon's corners.
        private PointF[] GetOctagonPoints(PointF center, float radius)
        {
            PointF[] points = new PointF[8];
            double theta = -Math.PI / 2.0;
            double dtheta = 2.0 * Math.PI / 8.0;
            for (int i = 0; i < 8; i++)
            {
                points[i] = new PointF(
                    center.X + (float)(radius * Math.Cos(theta)),
                    center.Y + (float)(radius * Math.Sin(theta)));
                theta += dtheta;
            }
            return points;
        }

        // Draw.
        private void picCanvas_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.Clear(picCanvas.BackColor);
            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
            if (Root == null) return;

            Root.Draw(e.Graphics);
        }

        // Draw the initial octagon.
        private void Form1_Load(object sender, EventArgs e)
        {
            MakeOctagons();
        }       
    }
}

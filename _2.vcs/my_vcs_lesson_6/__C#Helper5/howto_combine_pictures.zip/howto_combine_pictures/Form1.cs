﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.IO;
using System.Drawing.Imaging;

namespace howto_combine_pictures
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            txtSourceDir.Text = Application.StartupPath + @"\Pictures";
            txtOutputFile.Text = Application.StartupPath + @"\Combined.jpg";
        }

        private void btnBrowseSourceDir_Click(object sender, EventArgs e)
        {
            fbdSource.SelectedPath = txtSourceDir.Text;
            if (fbdSource.ShowDialog() == DialogResult.OK)
                txtSourceDir.Text = fbdSource.SelectedPath;
        }

        private void btnBrowseOutputFile_Click(object sender, EventArgs e)
        {
            sfdCombined.FileName = txtOutputFile.Text;
            if (sfdCombined.ShowDialog() == DialogResult.OK)
                txtOutputFile.Text = sfdCombined.FileName;
        }

        private void btnGo_Click(object sender, EventArgs e)
        {
            Cursor = Cursors.WaitCursor;

            // Get the picture files in the source directory.
            List<string> files = new List<string>();
            foreach (string filename in Directory.GetFiles(txtSourceDir.Text))
            {
                int pos = filename.LastIndexOf('.');
                string extension = filename.Substring(pos).ToLower();
                if ((extension == ".bmp") ||
                    (extension == ".jpg") ||
                    (extension == ".jpeg") ||
                    (extension == ".png") ||
                    (extension == ".tif") ||
                    (extension == ".tiff") ||
                    (extension == ".gif"))
                        files.Add(filename);
            }

            int num_images = files.Count;
            if (num_images == 0)
            {
                Cursor = Cursors.Default;
                MessageBox.Show("Selected 0 files");
                return;
            }

            // Load the images.
            Bitmap[] images = new Bitmap[files.Count];
            for (int i = 0; i < num_images; i++)
                images[i] = new Bitmap(files[i]);

            // Find the largest width and height.
            int max_wid = 0;
            int max_hgt = 0;
            for (int i = 0; i < num_images; i++)
            {
                if (max_wid < images[i].Width) max_wid = images[i].Width;
                if (max_hgt < images[i].Height) max_hgt = images[i].Height;
            }

            // Make the result bitmap.
            int margin = int.Parse(txtMargin.Text);
            int num_cols = int.Parse(txtNumCols.Text);
            int num_rows = (int)Math.Ceiling(num_images / (float)num_cols);
            int wid = max_wid * num_cols + margin * (num_cols - 1);
            int hgt = max_hgt * num_rows + margin * (num_rows - 1);
            Bitmap bm = new Bitmap(wid, hgt);

            // Place the images on it.
            using (Graphics gr = Graphics.FromImage(bm))
            {
                gr.Clear(picBackground.BackColor);

                int x = 0;
                int y = 0;
                for (int i = 0; i < num_images; i++)
                {
                    gr.DrawImage(images[i], x, y);
                    x += max_wid + margin;
                    if (x >= wid)
                    {
                        y += max_hgt + margin;
                        x = 0;
                    }
                }
            }

            // Save the result.
            SaveImage(bm, txtOutputFile.Text);

            Cursor = Cursors.Default;
            MessageBox.Show("Done");
        }

        // Save the file with the appropriate format.
        public void SaveImage(Image image, string filename)
        {
            string extension = Path.GetExtension(filename);
            switch (extension.ToLower())
            {
                case ".bmp":
                    image.Save(filename, ImageFormat.Bmp);
                    break;
                case ".exif":
                    image.Save(filename, ImageFormat.Exif);
                    break;
                case ".gif":
                    image.Save(filename, ImageFormat.Gif);
                    break;
                case ".jpg":
                case ".jpeg":
                    image.Save(filename, ImageFormat.Jpeg);
                    break;
                case ".png":
                    image.Save(filename, ImageFormat.Png);
                    break;
                case ".tif":
                case ".tiff":
                    image.Save(filename, ImageFormat.Tiff);
                    break;
                default:
                    throw new NotSupportedException(
                        "Unknown file extension " + extension);
            }
        }

        private void picBackground_Click(object sender, EventArgs e)
        {
            cdBackground.Color = picBackground.BackColor;
            if (cdBackground.ShowDialog() == DialogResult.OK)
                picBackground.BackColor = cdBackground.Color;
        }
    }
}

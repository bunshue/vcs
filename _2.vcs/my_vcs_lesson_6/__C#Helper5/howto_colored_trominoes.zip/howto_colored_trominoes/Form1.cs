﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Drawing.Drawing2D;

namespace howto_colored_trominoes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // The quadrant that holds the square to be ignored.
        private enum Quadrants { NW, NE, SE, SW };

        // Brushes for the chairs.
        private Brush[] ChairBrushes =
        {
            Brushes.Red, Brushes.Blue,
            Brushes.Yellow, Brushes.Magenta,
        };

        private int SquaresPerSide = 0;
        private float SquareWidth, BoardWidth, Xmin, Ymin;

        // The location of the missing square.
        private int MissingX, MissingY;

        private List<Chair> Chairs;

        // Make and solve a new board.
        private void Form1_Load(object sender, EventArgs e)
        {
            MakeBoard();
        }
        private void btnTile_Click(object sender, EventArgs e)
        {
            MakeBoard();
        }
        private void MakeBoard()
        {
            int n = int.Parse(txtN.Text);
            SquaresPerSide = (int)Math.Pow(2, n);

            // Set board parameters.
            SquareWidth = (picBoard.ClientSize.Width - 10f) / SquaresPerSide;
            float hgt = (picBoard.ClientSize.Height - 10f) / SquaresPerSide;
            if (SquareWidth > hgt) SquareWidth = hgt;
            BoardWidth = SquareWidth * SquaresPerSide;
            Xmin = (picBoard.ClientSize.Width - BoardWidth) / 2;
            Ymin = (picBoard.ClientSize.Height - BoardWidth) / 2;

            // Pick a random empty square.
            Random rand = new Random();
            MissingX = rand.Next(SquaresPerSide);
            MissingY = rand.Next(SquaresPerSide);

            // Solve the board.
            Chairs = new List<Chair>();
            SolveBoard(
                0, SquaresPerSide - 1,
                0, SquaresPerSide - 1,
                MissingX, MissingY);

            // Redraw.
            picBoard.Refresh();
        }

        // Solve the board.
        private void SolveBoard(int imin, int imax, int jmin, int jmax,
            int imissing, int jmissing)
        {
            // See if this is a 2x2 square.
            if (imax - imin == 1)
            {
                // It is a 2x2 square. Make its chair.
                Chairs.Add(MakeChair(imin, imax, jmin, jmax,
                    imissing, jmissing));
                return;
            }

            // Not a 2x2 square. Divide into 4 pieces and recurse.
            int imid = (imin + imax) / 2;
            int jmid = (jmin + jmax) / 2;
            switch (QuadrantToIgnore(imin, imax, jmin, jmax,
                imissing, jmissing))
            {
                case Quadrants.NW:
                    // Make the chair in the middle.
                    Chairs.Add(MakeChair(imid, imid + 1, jmid, jmid + 1, imid, jmid));

                    // Recurse.
                    SolveBoard(imin, imid, jmin, jmid, imissing, jmissing);         // NW
                    SolveBoard(imid + 1, imax, jmin, jmid, imid + 1, jmid);         // NE
                    SolveBoard(imid + 1, imax, jmid + 1, jmax, imid + 1, jmid + 1); // SE
                    SolveBoard(imin, imid, jmid + 1, jmax, imid, jmid + 1);         // SW
                    break;
                case Quadrants.NE:
                    // Make the chair in the middle.
                    Chairs.Add(MakeChair(imid, imid + 1, jmid, jmid + 1, imid + 1, jmid));

                    // Recurse.
                    SolveBoard(imin, imid, jmin, jmid, imid, jmid);                 // NW
                    SolveBoard(imid + 1, imax, jmin, jmid, imissing, jmissing);     // NE
                    SolveBoard(imid + 1, imax, jmid + 1, jmax, imid + 1, jmid + 1); // SE
                    SolveBoard(imin, imid, jmid + 1, jmax, imid, jmid + 1);         // SW
                    break;
                case Quadrants.SE:
                    // Make the chair in the middle.
                    Chairs.Add(MakeChair(imid, imid + 1, jmid, jmid + 1, imid + 1, jmid + 1));

                    // Recurse.
                    SolveBoard(imin, imid, jmin, jmid, imid, jmid);                 // NW
                    SolveBoard(imid + 1, imax, jmin, jmid, imid + 1, jmid);         // NE
                    SolveBoard(imid + 1, imax, jmid + 1, jmax, imissing, jmissing); // SE
                    SolveBoard(imin, imid, jmid + 1, jmax, imid, jmid + 1);         // SW
                    break;
                case Quadrants.SW:
                    // Make the chair in the middle.
                    Chairs.Add(MakeChair(imid, imid + 1, jmid, jmid + 1, imid, jmid + 1));

                    // Recurse.
                    SolveBoard(imin, imid, jmin, jmid, imid, jmid);                 // NW
                    SolveBoard(imid + 1, imax, jmin, jmid, imid + 1, jmid);         // NE
                    SolveBoard(imid + 1, imax, jmid + 1, jmax, imid + 1, jmid + 1); // SE
                    SolveBoard(imin, imid, jmid + 1, jmax, imissing, jmissing);     // SW
                    break;
            }

            // Find a coloring.
            FindColoring();
        }

        // Make a chair polygon.
        private Chair MakeChair(int imin, int imax,
            int jmin, int jmax, int imissing, int jmissing)
        {
            // Make the Chair.
            Chair chair = new Chair();
            chair.Number = Chairs.Count;

            // Make the initial points.
            float xmin = Xmin + imin * SquareWidth;
            float ymin = Ymin + jmin * SquareWidth;
            PointF[] points =
            {
                new PointF(xmin, ymin),
                new PointF(xmin + SquareWidth, ymin),
                new PointF(xmin + SquareWidth * 2, ymin),
                new PointF(xmin + SquareWidth * 2, ymin + SquareWidth),
                new PointF(xmin + SquareWidth * 2, ymin + SquareWidth * 2),
                new PointF(xmin + SquareWidth, ymin + SquareWidth * 2),
                new PointF(xmin, ymin + SquareWidth * 2),
                new PointF(xmin, ymin + SquareWidth),
            };

            // Push in the appropriate corner.
            PointF middle = new PointF(
                xmin + SquareWidth,
                ymin + SquareWidth);
            switch (QuadrantToIgnore(imin, imax, jmin, jmax,
                imissing, jmissing))
            {
                case Quadrants.NW:
                    points[0] = middle;
                    chair.Squares.Add(new Point(imin, jmax));
                    chair.Squares.Add(new Point(imax, jmax));
                    chair.Squares.Add(new Point(imax, jmin));
                    break;
                case Quadrants.SW:
                    points[6] = middle;
                    chair.Squares.Add(new Point(imin, jmin));
                    chair.Squares.Add(new Point(imax, jmin));
                    chair.Squares.Add(new Point(imax, jmax));
                    break;
                case Quadrants.NE:
                    points[2] = middle;
                    chair.Squares.Add(new Point(imin, jmin));
                    chair.Squares.Add(new Point(imin, jmax));
                    chair.Squares.Add(new Point(imax, jmax));
                    break;
                case Quadrants.SE:
                    points[4] = middle;
                    chair.Squares.Add(new Point(imin, jmin));
                    chair.Squares.Add(new Point(imin, jmax));
                    chair.Squares.Add(new Point(imax, jmin));
                    break;
            }

            // Add the points to the Chair and return it.
            chair.Points = points;
            return chair;
        }

        // Draw the board.
        private void picBoard_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.Clear(picBoard.BackColor);
            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;

            // Draw the chairs.
            foreach (Chair chair in Chairs)
                chair.Draw(e.Graphics, false);

            // Draw the missing square.
            float x = Xmin + MissingX * SquareWidth;
            float y = Ymin + MissingY * SquareWidth;
            e.Graphics.FillRectangle(Brushes.Black,
                x, y, SquareWidth, SquareWidth);
        }

        // Return the quadrant holding the square to be ignored for this square.
        private Quadrants QuadrantToIgnore(int imin, int imax, int jmin, int jmax,
            int imissing, int jmissing)
        {
            int imid = (imin + imax) / 2;
            int jmid = (jmin + jmax) / 2;
            if (imissing <= imid)      // West.
            {
                if (jmissing <= jmid) return Quadrants.NW;
                return Quadrants.SW;
            }
            else                        // East.
            {
                if (jmissing <= jmid) return Quadrants.NE;
                return Quadrants.SE;
            }
        }

        // Find a coloring of the Chairs.
        private void FindColoring()
        {
            // Find the neighbors.
            FindNeighbors();

            // Give each Chair color number -1.
            foreach (Chair chair in Chairs) chair.BgBrushNum = -1;

            // Assign colors.
            if (!FindColoring(0))
                MessageBox.Show("Could not find coloring.");
        }

        // Find a coloring of the Chairs starting from Chair
        // number start_chair Return true if we find a coloring.
        private bool FindColoring(int start_chair)
        {
            // If we are beyond the end of the Chairs list, we are done.
            if (start_chair == Chairs.Count) return true;

            // Try each of the colors for this Chair.
            int num_colors = Chair.BgBrushes.Length;
            Chair this_chair = Chairs[start_chair];
            for (int color_num = 0; color_num < num_colors; color_num++)
            {
                if (this_chair.ColorAllowed(color_num))
                {
                    this_chair.BgBrushNum = color_num;
                    if (FindColoring(start_chair + 1)) return true;
                }
            }

            // We failed to find a coloring. Backtrack.
            this_chair.BgBrushNum = -1;
            return false;
        }

        // Find the Chairs' neighbors.
        private void FindNeighbors()
        {
            int num_chairs = Chairs.Count;

            // Create empty Neighbors lists.
            foreach (Chair chair in Chairs)
                chair.Neighbors = new List<Chair>();

            // Find neighbors.
            for (int i = 0; i < num_chairs - 1; i++)
            {
                for (int j = i + 1; j < num_chairs; j   ++)
                {
                    if (Chairs[i].IsNeighbor(Chairs[j]))
                    {
                        Chairs[i].Neighbors.Add(Chairs[j]);
                        Chairs[j].Neighbors.Add(Chairs[i]);
                    }
                }
            }
        }
    }
}

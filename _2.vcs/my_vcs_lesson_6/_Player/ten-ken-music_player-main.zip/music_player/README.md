# music_player
play music (一款小型的音乐播放器)

### 说明:
    基于AxWindowsMediaPlayer。
![输入图片说明](https://images.gitee.com/uploads/images/2020/1228/114845_b7c7347d_5556017.png "屏幕截图.png")
### 功能：
    1.歌词逐行展示
    2.基础的播放暂停下一曲上一期等功能
    3.字体设置 歌词显示/隐藏  
    4.音乐文件支持导入 删除 分别对应上方+ 和 — 按钮
    5.播放列表支持拖拽文件、 点击导入按钮 、复制粘贴三种方式
    6.背景音乐在.exe文件同一级目录的 **bgImages文件夹** 里面，可以自己根据需要放置图片，仅支持png/jpeg/jpg三种图片

### 页面展示
![主页面](https://images.gitee.com/uploads/images/2020/1228/114641_bdf5860a_5556017.png "屏幕截图.png")

![字体设置](https://images.gitee.com/uploads/images/2020/1228/114710_bac1c40c_5556017.png "屏幕截图.png")

![皮肤切换](https://images.gitee.com/uploads/images/2020/1228/114747_ac87c243_5556017.png "屏幕截图.png")
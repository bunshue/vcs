﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

// Enable the timer at design time.

namespace howto_show_gmt
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Update the clocks.
        private void tmrClock_Tick(object sender, EventArgs e)
        {
            // Display the local time.
            DateTime now = DateTime.Now;
            lblLocalTime.Text = now.ToLongTimeString();
            lblLocalDate.Text = now.ToShortDateString();

            // Display the GMT time.
            DateTimeOffset local_offset = new DateTimeOffset(now);
            DateTimeOffset utc_offset = local_offset.ToUniversalTime();
            lblGmtTime.Text = utc_offset.DateTime.ToLongTimeString();
            lblGmtDate.Text = utc_offset.DateTime.ToShortDateString();
        }
    }
}

﻿//#define DRAW_POINTS
//#define DRAW_LEVEL_MINUS_1

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

// http://en.wikipedia.org/wiki/Dragon_curve

namespace howto_heighway_dragon
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // The direction the curve should turn next.
        private enum Direction
        {
            Left,
            Right
        }

        // Redraw.
        private void btnDraw_Click(object sender, EventArgs e)
        {
            picDragon.Refresh();
        }
        private void picDragon_Resize(object sender, EventArgs e)
        {
            picDragon.Refresh();
        }

        // Draw the dragon.
        private void picDragon_Paint(object sender, PaintEventArgs e)
        {
            Cursor = Cursors.WaitCursor;
            e.Graphics.Clear(picDragon.BackColor);

            // Find the first control points.
            float dx = Math.Min(
                picDragon.ClientSize.Width / 1.5f,
                picDragon.ClientSize.Height) / 3f;

            // Try to center it a bit.
            float x0 = (picDragon.ClientSize.Width - dx * 1.5f) / 2f + dx / 3f;
            float y0 = (picDragon.ClientSize.Height - dx) / 2f + dx / 3f;

            // e.Graphics.DrawRectangle(Pens.Green, x1 - dx / 8f, y1 - dx / 8f, wid, hgt);

            // Recursively draw the lines.
            int level = (int)nudLevel.Value;
            DrawDragonLine(e.Graphics, level, Direction.Right, x0, y0, 2 * dx, 0);
            Cursor = Cursors.Default;
        }

        // Recursively draw the dragon curve between the two points.
        private void DrawDragonLine(Graphics gr, int level, Direction turn_towards, float x1, float y1, float dx, float dy)
        {
            if (level <= 0)
            {
                gr.DrawLine(Pens.Red, x1, y1, x1 + dx, y1 + dy);

#if DRAW_POINTS
                gr.DrawEllipse(Pens.Blue, x1 - 2, y1 - 2, 4, 4);
                gr.DrawEllipse(Pens.Blue, x1 + dx - 2, y1 + dy - 2, 4, 4);
#endif
            }
            else
            {
#if DRAW_LEVEL_MINUS_1
                if (level == 1)
                {
                    gr.DrawLine(Pens.Silver, x1, y1, x1 + dx, y1 + dy);
                }
#endif
                float nx = (float)(dx / 2);
                float ny = (float)(dy / 2);
                float dx2 = -ny + nx;
                float dy2 = nx + ny;
                if (turn_towards == Direction.Right)
                {
                    // Turn to the right.
                    DrawDragonLine(gr, level - 1, Direction.Right, x1, y1, dx2, dy2);
                    float x2 = x1 + dx2;
                    float y2 = y1 + dy2;
                    DrawDragonLine(gr, level - 1, Direction.Left, x2, y2, dy2, -dx2);
                }
                else
                {
                    // Turn to the left.
                    DrawDragonLine(gr, level - 1, Direction.Right, x1, y1, dy2, -dx2);
                    float x2 = x1 + dy2;
                    float y2 = y1 - dx2;
                    DrawDragonLine(gr, level - 1, Direction.Left, x2, y2, dx2, dy2);
                }
            }
        }
    }
}

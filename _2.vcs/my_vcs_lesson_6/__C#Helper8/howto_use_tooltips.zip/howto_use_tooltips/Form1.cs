﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_use_tooltips
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Add tooltips to the buttons.
        private void btnAddTips_Click(object sender, EventArgs e)
        {
            tipAddress.SetToolTip(btnAddTips, "Click to add tooltips to the buttons.");
            tipAddress.SetToolTip(btnRemoveTips, "Click to remove tooltips from the buttons.");
        }

        // Remove tooltips from the buttons.
        private void btnRemoveTips_Click(object sender, EventArgs e)
        {
            tipAddress.SetToolTip(btnAddTips, "");
            tipAddress.SetToolTip(btnRemoveTips, "");
        }
    }
}

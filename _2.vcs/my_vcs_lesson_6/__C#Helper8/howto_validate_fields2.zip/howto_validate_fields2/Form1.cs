﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Text.RegularExpressions;

namespace howto_validate_fields2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Validate a required field. Return true if the field is valid.
        private bool ValidateRequiredField(ErrorProvider err, TextBox txt)
        {
            if (txt.Text.Length > 0)
            {
                // Clear the error.
                err.SetError(txt, "");
                return false;
            }
            else
            {
                // Set the error.
                err.SetError(txt, CamelCaseToWords(txt.Name) + " must not be blank.");
                return true;
            }
        }

        // Validate fields.
        private void txtRequiredField_Validating(object sender, CancelEventArgs e)
        {
            TextBox txt = sender as TextBox;
            ValidateRequiredField(errField, txt);
        }

        // Split a string in camelCase, removing the prefix.
        private string CamelCaseToWords(string input)
        {
            // Insert a space in front of each capital letter.
            string result = "";
            foreach (char ch in input.ToCharArray())
            {
                if (char.IsUpper(ch)) result += " ";
                result += ch;
            }

            // Find the first space and remove everything before it.
            return result.Substring(result.IndexOf(" ") + 1);
        }

        // Validate the ZIP code.
        private void txtZip_Validating(object sender, CancelEventArgs e)
        {
            ValidateZipCode(errField, txtZip);
        }

        // Validate the ZIP code.
        private void ValidateZipCode(ErrorProvider err, TextBox txt)
        {
            // Check for missing value.
            if (ValidateRequiredField(err, txt)) return;

            // Check for correct format.
            Regex regex = new Regex(@"^(\d{5}|\d{5}-\d{4})$");
            if (regex.IsMatch(txt.Text))
            {
                // Clear the error.
                errField.SetError(txt, "");
            }
            else
            {
                // Set the error.
                errField.SetError(txt, "ZIP code must have format ##### or #####-####.");
            }
        }

        // The user accepted the values.
        private void btnOk_Click(object sender, EventArgs e)
        {
            // Validate all fields.
            ValidateRequiredField(errField, txtFirstName);
            ValidateRequiredField(errField, txtLastName);
            ValidateRequiredField(errField, txtStreet);
            ValidateRequiredField(errField, txtCity);
            ValidateRequiredField(errField, txtState);
            ValidateZipCode(errField, txtZip);

            // See if any field has an error message.
            foreach (Control ctl in Controls)
            {
                if (errField.GetError(ctl) != "")
                {
                    MessageBox.Show(errField.GetError(ctl));
                    return;
                }
            }

            MessageBox.Show("You entered:\n" +
                txtFirstName.Text + ' ' + txtLastName.Text + '\n' +
                txtStreet.Name + '\n' +
                txtCity.Name + '\t' + txtState.Text + '\t' + txtZip.Text);
        }

        // Close.
        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

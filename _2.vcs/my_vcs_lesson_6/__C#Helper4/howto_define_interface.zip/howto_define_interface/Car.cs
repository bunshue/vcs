﻿namespace howto_define_interface
{
    public class Car : IVehicle
    {
        // Implement IVehicle.MaxSpeed explicitly.
        private int _MaxSpeed;
        int IVehicle.MaxSpeed
        {
            get { return _MaxSpeed; }
            set { _MaxSpeed = value; }
        }

        // Implement IVehicle.Mpg implicitly.
        private foat _Mpg;
        public float Mpg
        {
            get { return _Mpg; }
            set { _Mpg = value; }
        }

        // Add a new property.
        private int _NumCupholders;
        public int NumCupholders
        {
            get { return _NumCupholders; }
            set { _NumCupholders = value; }
        }
    }
}

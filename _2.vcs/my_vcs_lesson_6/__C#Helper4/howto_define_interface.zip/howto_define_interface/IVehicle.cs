﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace howto_define_interface
{
    public interface IVehicle
    {
        int MaxSpeed { get; set; }
        float Mpg { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_define_interface
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Make an object.
        private void Form1_Load(object sender, EventArgs e)
        {
            // Make a Vehicle.
            // Set NumCupholders and Mpg but not MaxSpeed.
            Car car = new Car();
            car.NumCupholders = 5;
            car.MaxSpeed = 50;              // Fails.
            car.Mpg = 10;

            // Make an IVehicle.
            // Set MaxSpeed and Mpg but not NumCupholders.
            IVehicle ivehicle = new Car();
            ivehicle.NumCupholders = 5;     // Fails.
            ivehicle.MaxSpeed = 50;
            ivehicle.Mpg = 10;
        }
    }
}

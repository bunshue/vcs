﻿namespace howto_multiple_inheritance
{
    public class Vehicle : IVehicle
    {
        // Implement IVehicle.MaxSpeed
        private int _MaxSpeed;
        public int MaxSpeed
        {
            get { return _MaxSpeed; }
            set { _MaxSpeed = value; }
        }
    }
}

﻿namespace howto_multiple_inheritance
{
    public class Domicile
    {
        private int _SquareFeet;
        public int SquareFeet
        {
            get { return _SquareFeet; }
            set { _SquareFeet = value; }
        }
    }
}

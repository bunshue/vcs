﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_multiple_inheritance
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Make some objects.
        private void Form1_Load(object sender, EventArgs e)
        {
            // Make a HouseBoat.
            HouseBoat boat = new HouseBoat();
            boat.SquareFeet = 100;
            boat.MaxSpeed = 10;

            // Make an IVehicle variable.
            IVehicle ivehicle = boat;
            ivehicle.MaxSpeed = 15;
        }
    }
}

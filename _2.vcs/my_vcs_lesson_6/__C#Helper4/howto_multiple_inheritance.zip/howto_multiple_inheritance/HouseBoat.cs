﻿namespace howto_multiple_inheritance
{
    public class HouseBoat : Domicile, IVehicle
    {
        // Inherits the SquareFeet property from Domicile.

        // Delegate IVehicle features to a Vehicle object.
        private Vehicle _Vehicle = new Vehicle();
        public int MaxSpeed
        {
            get { return _Vehicle.MaxSpeed; }
            set { _Vehicle.MaxSpeed = value; }
        }
    }
}

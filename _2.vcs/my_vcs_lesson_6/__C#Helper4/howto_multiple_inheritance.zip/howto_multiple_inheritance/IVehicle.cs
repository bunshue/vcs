﻿namespace howto_multiple_inheritance
{
    public interface IVehicle
    {
        // Define a MaxSpeed property.
        int MaxSpeed { get; set; }
    }
}

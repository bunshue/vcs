﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Globalization;

namespace howto_monthly_investment
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Calculate the interest compounded monthly.
        private void btnGo_Click(object sender, EventArgs e)
        {
            // Get the parameters.
            decimal monthly_contribution = decimal.Parse(
                txtMonthlyContribution.Text, NumberStyles.Any);
            int num_months = int.Parse(txtNumMonths.Text);
            decimal interest_rate = decimal.Parse(
                txtInterestRate.Text.Replace("%", "")) / 100;
            interest_rate /= 12;

            // Calculate.
            lvwBalance.Items.Clear();
            decimal balance = 0;
            decimal total_interest = 0;
            decimal total_principle = 0;
            for (int i = 1; i <= num_months; i++)
            {
                // Display the month.
                ListViewItem new_item = lvwBalance.Items.Add(i.ToString());

                // Display the interest.
                decimal interest = balance * interest_rate;
                new_item.SubItems.Add(interest.ToString("c"));
                total_interest += interest;
                new_item.SubItems.Add(total_interest.ToString("c"));

                // Add the contribution.
                balance += monthly_contribution;
                total_principle += monthly_contribution;
                new_item.SubItems.Add(total_principle.ToString("c"));

                // Display the balance.
                balance += interest;
                new_item.SubItems.Add(balance.ToString("c"));
            }

            // Scroll to the last entry.
            lvwBalance.Items[lvwBalance.Items.Count - 1].EnsureVisible();
        }
    }
}

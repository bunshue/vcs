﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Drawing.Drawing2D;

namespace howto_resize_image_pixelated
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            cboScale.Text = "1";
        }

        // Display the image at the selected size.
        private void cboScale_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Get the scale.
            float scale = float.Parse(cboScale.Text);

            // Make a bitmap of the right size.
            int wid = (int)(picOriginal.Image.Width * scale);
            int hgt = (int)(picOriginal.Image.Height * scale);
            Bitmap bm = new Bitmap(wid, hgt);
            
            // Draw the image onto the new bitmap.
            using (Graphics gr = Graphics.FromImage(bm))
            {
                // No smoothing.
                gr.InterpolationMode = InterpolationMode.NearestNeighbor;

                Point[] dest =
                {
                    new Point(0, 0),
                    new Point(wid, 0),
                    new Point(0, hgt),
                };
                Rectangle source = new Rectangle(
                    0, 0,
                    picOriginal.Image.Width,
                    picOriginal.Image.Height);
                gr.DrawImage(picOriginal.Image,
                    dest, source, GraphicsUnit.Pixel);
            }

            // Display the result.
            picScaled.Image = bm;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.IO;

namespace howto_update_file_time
{
    class Program
    {
        static void Main(string[] args)
        {
            // Update each file's last access time.
            foreach (string filename in args)
            {
                File.SetLastAccessTime(filename, DateTime.Now);
                File.SetLastWriteTime(filename, DateTime.Now);
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_invert_matrix
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnInvert_Click(object sender, EventArgs e)
        {
            // Build the matrix.
            string[] matrix_rows = txtMatrix.Text.Split(
                new string[] { "\r\n" }, StringSplitOptions.RemoveEmptyEntries);
            int num_rows = matrix_rows.Length;
            double[,] matrix = new double[num_rows, num_rows];
            for (int row = 0; row < num_rows; row++)
            {
                char[] chars = { ' ' };
                string[] row_items =
                    matrix_rows[row].Split(chars, StringSplitOptions.RemoveEmptyEntries);

                for (int col = 0; col < num_rows; col++)
                {
                    matrix[row, col] = double.Parse(row_items[col]);
                }
            }

            // Find the inverse.
            double[,] inverse = InvertMatrix(matrix);

            if (inverse == null)
            {
                txtInverse.Text = "Null";
                txtProduct.Clear();
            }
            else
            {
                // Multiply the matrix by the inverse.
                double[,] product = MultiplyMatrices(matrix, inverse);

                // Display the results.
                txtInverse.Text = MatrixToString(inverse, "{0,8:F4}");
                txtProduct.Text = MatrixToString(product, "{0,8:F4}");
            }

        }

        // Return the matrix's inverse or null if it has none.
        private double[,] InvertMatrix(double[,] matrix)
        {
            const double tiny = 0.00001;

            // Build the augmented matrix.
            int num_rows = matrix.GetUpperBound(0) + 1;
            double[,] augmented = new double[num_rows, 2 * num_rows];
            for (int row = 0; row < num_rows; row++)
            {
                for (int col = 0; col < num_rows; col++)
                    augmented[row, col] = matrix[row, col];
                augmented[row, row + num_rows] = 1;
            }

            // num_cols is the number of the augmented matrix.
            int num_cols = 2 * num_rows;

            // Solve.
            for (int row = 0; row < num_rows; row++)
            {
                // Zero out all entries in column r after this row.
                // See if this row has a non-zero entry in column r.
                if (Math.Abs(augmented[row, row]) < tiny)
                {
                    // Too close to zero. Try to swap with a later row.
                    for (int r2 = row + 1; r2 < num_rows; r2++)
                    {
                        if (Math.Abs(augmented[r2, row]) > tiny)
                        {
                            // This row will work. Swap them.
                            for (int c = 0; c < num_cols; c++)
                            {
                                double tmp = augmented[row, c];
                                augmented[row, c] = augmented[r2, c];
                                augmented[r2, c] = tmp;
                            }
                            break;
                        }
                    }
                }

                // If this row has a non-zero entry in column r, use it.
                if (Math.Abs(augmented[row, row]) > tiny)
                {
                    // Divide the row by augmented[row, row] to make this entry 1.
                    for (int col = 0; col < num_cols; col++)
                        if (col != row)
                            augmented[row, col] /= augmented[row, row];
                    augmented[row, row] = 1;

                    // Subtract this row from the other rows.
                    for (int row2 = 0; row2 < num_rows; row2++)
                    {
                        if (row2 != row)
                        {
                            double factor = augmented[row2, row] / augmented[row, row];
                            for (int col = 0; col < num_cols; col++)
                                augmented[row2, col] -= factor * augmented[row, col];
                        }
                    }
                }
            }

            // See if we have a solution.
            if (augmented[num_rows - 1, num_rows - 1] == 0) return null;

            // Extract the inverse array.
            double[,] inverse = new double[num_rows, num_rows];
            for (int row = 0; row < num_rows; row++)
            {
                for (int col = 0; col < num_rows; col++)
                {
                    inverse[row, col] = augmented[row, col + num_rows];
                }
            }

            return inverse;
        }

        // Multiply two matrices.
        private double[,] MultiplyMatrices(double[,] m1, double[,] m2)
        {
            int num_rows = m1.GetUpperBound(0) + 1;
            double[,] result = new double[num_rows, num_rows];
            for (int row = 0; row < num_rows; row++)
            {
                for (int col = 0; col < num_rows; col++)
                {
                    double value = 0;
                    for (int i = 0; i < num_rows; i++)
                        value += m1[row, i] * m2[i, col];
                    result[row, col] = value;
                }
            }

            return result;
        }

        // Return a string representation of the matrix.
        private string MatrixToString(double[,] matrix, string format)
        {
            StringBuilder sb = new StringBuilder();
            int num_rows = matrix.GetUpperBound(0) + 1;
            int num_cols = matrix.GetUpperBound(1) + 1;
            for (int row = 0; row < num_rows; row++)
            {
                for (int col = 0; col < num_cols; col++)
                    sb.Append(string.Format(format, matrix[row, col]));
                if (row < num_rows - 1) sb.AppendLine();
            }
            return sb.ToString();
        }
    }
}

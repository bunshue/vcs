﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace howto_console_app
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(DateTime.Now.ToString());
            Console.Write("Press any key to continue");
            Console.ReadLine();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Drawing.Printing;
using System.IO;

namespace howto_print_text_file
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Populate the list of printers.
        private void Form1_Load(object sender, EventArgs e)
        {
            // Find all of the installed printers.
            foreach (string printer in PrinterSettings.InstalledPrinters)
            {
                cboPrinter.Items.Add(printer);
            }

            // Find and select the default printer.
            try
            {
                PrinterSettings settings = new PrinterSettings();
                cboPrinter.Text = settings.PrinterName;
            }
            catch
            {
            }

            // Initially select the source code file.
            string file_path = Application.StartupPath;
            if (file_path.EndsWith(@"\bin\Debug"))
                file_path = file_path.Substring(0, file_path.Length - 10);
            if (file_path.EndsWith(@"\bin\Release"))
                file_path = file_path.Substring(0, file_path.Length - 12);
            if (file_path.EndsWith(@"\"))
                file_path = file_path.Substring(0, file_path.Length - 1);
            file_path += @"\Form1.cs";
            txtFile.Text = file_path;
        }

        // Let the user select a file.
        private void btnSelectFile_Click(object sender, EventArgs e)
        {
            ofdTextFile.FileName = txtFile.Text;
            if (ofdTextFile.ShowDialog() == DialogResult.OK)
                txtFile.Text = ofdTextFile.FileName;
        }

        // The text contained in the file.
        private string FileContents;

        // Preview the selected file.
        private void btnPreview_Click(object sender, EventArgs e)
        {
            // Read the file's contents.
            try
            {
                FileContents = File.ReadAllText(txtFile.Text).Trim();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error reading file " + txtFile.Text +
                    ".\n" + ex.Message);
                return;
            }

            // Display the print preview dialog.
            ppdTextFile.ShowDialog();
        }

        // Print a page of the text file.
        private void pdocTextFile_PrintPage(object sender, PrintPageEventArgs e)
        {
            // Make a font for printing.
            using (Font font = new Font("Courier New", 10))
            {
                // Make a StringFormat to align text normally.
                using (StringFormat string_format = new StringFormat())
                {
                    // See how much of the remaining text will fit.
                    SizeF layout_area = new SizeF(
                        e.MarginBounds.Width, e.MarginBounds.Height);
                    int chars_fitted, lines_filled;
                    e.Graphics.MeasureString(FileContents, font,
                        layout_area, string_format,
                        out chars_fitted, out lines_filled);

                    // Print as much as will fit.
                    e.Graphics.DrawString(
                        FileContents.Substring(0, chars_fitted),
                        font, Brushes.Black, e.MarginBounds,
                        string_format);

                    // Remove the printed text from the string.
                    FileContents = FileContents.Substring(chars_fitted).Trim();
                }
            }

            // See if we are done.
            e.HasMorePages = FileContents.Length > 0;
        }
    }
}

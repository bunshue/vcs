﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Drawing.Printing;

namespace howto_set_print_document_name
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // Find all of the installed printers.
            foreach (string printer in PrinterSettings.InstalledPrinters)
            {
                cboPrinter.Items.Add(printer);
            }

            // Find and select the default printer.
            try
            {
                PrinterSettings settings = new PrinterSettings();
                cboPrinter.Text = settings.PrinterName;
            }
            catch
            {
            }
        }

        // Print the document.
        private void btnPrint_Click(object sender, EventArgs e)
        {
            // Select the printer.
            pdocFile.PrinterSettings.PrinterName = cboPrinter.Text;

            // Set the print document name.
            pdocFile.DocumentName = txtDocumentName.Text;

            // Print.
            pdocFile.Print();
        }

        // Just draw some sample text.
        private void pdocFile_PrintPage(object sender, PrintPageEventArgs e)
        {
            using (Font font = new Font("Times New Roman", 30))
            {
                e.Graphics.DrawString("Sample text", font, Brushes.Black,
                    e.MarginBounds.Left, e.MarginBounds.Top);
            }
            e.HasMorePages = false;
        }
    }
}

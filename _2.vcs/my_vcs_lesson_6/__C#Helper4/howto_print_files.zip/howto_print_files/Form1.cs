﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Drawing.Printing;
using System.IO;

namespace howto_print_files
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Populate the list of printers.
        private void Form1_Load(object sender, EventArgs e)
        {
            // Find all of the installed printers.
            foreach (string printer in PrinterSettings.InstalledPrinters)
            {
                cboPrinter.Items.Add(printer);
            }

            // Find and select the default printer.
            try
            {
                PrinterSettings settings = new PrinterSettings();
                cboPrinter.Text = settings.PrinterName;
            }
            catch
            {
            }

            // Start in the project directory.
            string file_path = Application.StartupPath;
            if (file_path.EndsWith(@"\bin\Debug"))
                file_path = file_path.Substring(0, file_path.Length - 10);
            if (file_path.EndsWith(@"\bin\Release"))
                file_path = file_path.Substring(0, file_path.Length - 12);
            if (!file_path.EndsWith(@"\")) file_path += @"\";
            txtDirectory.Text = file_path;

            // Check items when the user clicks on them.
            clbFiles.CheckOnClick = true;
        }

        // Let the user select the start directory.
        private void btnSelectDirectory_Click(object sender, EventArgs e)
        {
            fbdPath.SelectedPath = txtDirectory.Text;
            if (fbdPath.ShowDialog() == DialogResult.OK)
                txtDirectory.Text = fbdPath.SelectedPath;
        }

        // List matching files.
        private void btnListFiles_Click(object sender, EventArgs e)
        {
            clbFiles.Items.Clear();
            try
            {
                // See if we should search subdirectories.
                SearchOption search_option = SearchOption.TopDirectoryOnly;
                if (chkIncludeSubdirectories.Checked)
                    search_option = SearchOption.AllDirectories;

                // Search for files matching the pattern.
                DirectoryInfo dir_info = new DirectoryInfo(txtDirectory.Text);
                foreach (FileInfo file_info in dir_info.GetFiles(
                    txtPattern.Text, search_option))
                {
                    int index = clbFiles.Items.Add(file_info.FullName);
                    clbFiles.SetItemChecked(index, true);
                }
                lblNumFiles.Text = clbFiles.Items.Count + " files, " +
                    clbFiles.Items.Count + " selected";
                btnPrint.Enabled = clbFiles.CheckedIndices.Count > 0;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        // Disable the Print button.
        private void txtDirectory_TextChanged(object sender, EventArgs e)
        {
            btnPrint.Enabled = false;
        }

        // Update the number of files selected.
        private void clstFiles_ItemCheck(object sender, ItemCheckEventArgs e)
        {
            // Get the current number checked.
            int num_checked = clbFiles.CheckedItems.Count;

            // See if the item is being checked or unchecked.
            if ((e.CurrentValue != CheckState.Checked) &&
                (e.NewValue == CheckState.Checked))
                num_checked++;
            if ((e.CurrentValue == CheckState.Checked) &&
                (e.NewValue != CheckState.Checked))
                num_checked--;

            // Display the count.
            lblNumFiles.Text = clbFiles.Items.Count + " items, " +
                num_checked + " selected";

            // Enable the Print button if appropriate.
            btnPrint.Enabled = num_checked > 0;
        }

        // Print the selected files.
        private void btnPrint_Click(object sender, EventArgs e)
        {
            // Select the desired printer.
            pdocFile.PrinterSettings.PrinterName = cboPrinter.Text;

            // Print the checked files.
            foreach (string filename in clbFiles.CheckedItems)
            {
                Console.WriteLine("Printing: " + filename);

                // Get the file's name without the path.
                FileInfo file_into = new FileInfo(filename);
                string short_name = file_into.Name;

                // Set the PrintDocument's name for use by the printer queue.
                pdocFile.DocumentName = short_name;

                // Read the file's contents.
                try
                {
                    FileContents = File.ReadAllText(filename).Trim();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error reading file " + filename +
                        ".\n" + ex.Message);
                    return;
                }

                // Print.
                pdocFile.Print();
            }

            MessageBox.Show("Spooled " + clbFiles.CheckedItems.Count +
                " files for printing.");
        }

        // The text contained in the file that we are printing.
        private string FileContents;

        // Print a page of the text file.
        private void pdocTextFile_PrintPage(object sender, PrintPageEventArgs e)
        {
            // Make a font for printing.
            using (Font font = new Font("Courier New", 10))
            {
                // Make a StringFormat to align text normally.
                using (StringFormat string_format = new StringFormat())
                {
                    // See how much of the remaining text will fit.
                    SizeF layout_area = new SizeF(
                        e.MarginBounds.Width, e.MarginBounds.Height);
                    int chars_fitted, lines_filled;
                    e.Graphics.MeasureString(FileContents, font,
                        layout_area, string_format,
                        out chars_fitted, out lines_filled);

                    // Print as much as will fit.
                    e.Graphics.DrawString(
                        FileContents.Substring(0, chars_fitted),
                        font, Brushes.Black, e.MarginBounds,
                        string_format);

                    // Remove the printed text from the string.
                    FileContents = FileContents.Substring(chars_fitted).Trim();
                }
            }

            // See if we are done.
            e.HasMorePages = FileContents.Length > 0;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Globalization;
using System.Drawing.Drawing2D;

namespace howto_monthly_investment2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // The drawing transformation.
        private Matrix Transform;

        // The data points.
        private List<PointF> Contributions = new List<PointF>();
        private List<PointF> Interest = new List<PointF>();
        private List<PointF> Balance = new List<PointF>();

        // Display some initial data.
        private void Form1_Load(object sender, EventArgs e)
        {
            PerformCalculations();
        }

        // Calculate the interest compounded monthly.
        private void btnGo_Click(object sender, EventArgs e)
        {
            PerformCalculations();
        }

        // Perform the calculations.
        private void PerformCalculations()
        {
            // Get the parameters.
            decimal monthly_contribution = decimal.Parse(
                txtMonthlyContribution.Text, NumberStyles.Any);
            int num_months = int.Parse(txtNumMonths.Text);
            decimal interest_rate = decimal.Parse(
                txtInterestRate.Text.Replace("%", "")) / 100;
            interest_rate /= 12;

            // Start at 0.
            Contributions = new List<PointF>();
            Interest = new List<PointF>();
            Balance = new List<PointF>();
            decimal contributions = 0;
            decimal interest = 0;
            decimal balance = 0;

            // Calculate.
            for (int i = 0; i <= num_months; i++)
            {
                // Save the contributions, interest, and balance.
                Contributions.Add(new PointF(i, (float)contributions));
                Interest.Add(new PointF(i, (float)interest));
                Balance.Add(new PointF(i, (float)balance));

                // Calculate the values for next month.
                contributions += monthly_contribution;
                decimal new_interest = balance * interest_rate;
                interest += new_interest;
                balance += monthly_contribution + new_interest;
            }

            // Add points to close the polygons.
            Contributions.Add(new PointF(num_months, 0));
            Interest.Add(new PointF(num_months, 0));
            Balance.Add(new PointF(num_months, 0));

            // Redraw.
            picGraph.Refresh();
        }

        // Draw the graph.
        private void picGraph_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.Clear(picGraph.BackColor);
            if (Balance.Count < 2) return;

            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;

            // Scale to make the data fit.
            float xmin = -1;
            float xmax = Contributions.Count + 1;
            float ymax = Balance.Max(pt => pt.Y);
            float ymin = -ymax * 0.05f;
            RectangleF rect = new RectangleF(xmin, ymin, xmax - xmin, ymax - ymin);
            PointF[] pts =
            {
                new PointF(0, picGraph.ClientSize.Height),
                new PointF(picGraph.ClientSize.Width, picGraph.ClientSize.Height),
                new PointF(0, 0),
            };
            Transform = new Matrix(rect, pts);
            e.Graphics.Transform = Transform;

            // Draw the curves.
            e.Graphics.FillPolygon(Brushes.LightGreen, Balance.ToArray());
            e.Graphics.FillPolygon(Brushes.LightBlue, Contributions.ToArray());
            e.Graphics.FillPolygon(Brushes.Pink, Interest.ToArray());
            e.Graphics.DrawPolygon(Pens.Green, Balance.ToArray());
            e.Graphics.DrawPolygon(Pens.Blue, Contributions.ToArray());
            e.Graphics.DrawPolygon(Pens.Red, Interest.ToArray());
        }

        // Display the nearest data point's values.
        private const float max_dx = 5;

        private void picGraph_MouseMove(object sender, MouseEventArgs e)
        {
            if (Transform == null) return;
            if (Balance.Count < 3) return;

            // Find the data point closest to the mouse.
            string tip = "";
            if (tip == "") tip = GetDataTooltip(Balance, e.Location, "Balance");
            if (tip == "") tip = GetDataTooltip(Contributions, e.Location, "Contributions");
            if (tip == "") tip = GetDataTooltip(Interest, e.Location, "Interest");

            // Display the new tool tip.
            if (tip != tipAmount.GetToolTip(picGraph))
            {
                tipAmount.SetToolTip(picGraph, tip);
                Console.WriteLine("[" + tip + "]");
            }
        }

        // Find a tooltip for the given data points.
        private string GetDataTooltip(List<PointF> point_list, Point location, string type_name)
        {
            const float max_dist = 6;

            // Convert the points to screen coordinates.
            PointF[] points = point_list.ToArray();
            Transform.TransformPoints(points);

            // See if any of the points is close to the location,
            // skipping the last point that was used to close the polygon.
            for (int i = 0; i < point_list.Count - 1; i++)
            {
                // See if this point is close enough to the mouse.
                float dist =
                    Math.Abs(points[i].X - location.X) +
                    Math.Abs(points[i].Y - location.Y);
                if (dist < max_dist)
                {
                    return "Month: " + point_list[i].X.ToString() +
                        "\n" + type_name + ": " + point_list[i].Y.ToString("C");
                }
            }

            return "";
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.IO;

namespace howto_checkedlistbox_count
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // List the files in the startup directory.
        private void Form1_Load(object sender, EventArgs e)
        {
            // list the files.
            DirectoryInfo dir_info = new DirectoryInfo(Application.StartupPath);
            foreach (FileInfo file_info in dir_info.GetFiles())
                clbFiles.Items.Add(file_info.Name);

            // Display the count.
            lblCount.Text = clbFiles.Items.Count + " items, 0 selected";

            // Check items when the user clicks on them.
            clbFiles.CheckOnClick = true;
        }

        // Update the display of files checked.
        private void clbFiles_ItemCheck(object sender, ItemCheckEventArgs e)
        {
            // Get the current number checked.
            int num_checked = clbFiles.CheckedItems.Count;

            // See if the item is being checked or unchecked.
            if ((e.CurrentValue != CheckState.Checked) &&
                (e.NewValue == CheckState.Checked))
                num_checked++;
            if ((e.CurrentValue == CheckState.Checked) &&
                (e.NewValue != CheckState.Checked))
                num_checked--;

            // Display the count.
            lblCount.Text = clbFiles.Items.Count + " items, " +
                num_checked + " selected";
        }
    }
}

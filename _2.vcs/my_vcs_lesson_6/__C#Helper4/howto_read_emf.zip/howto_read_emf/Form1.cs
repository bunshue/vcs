﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.IO;
using System.Drawing.Imaging;
using System.Drawing.Drawing2D;

// Set the "Copy to Output Directory" property for
// the image files to "Copy if Newer."

namespace howto_read_emf
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Metafile mf1 = (Metafile)Metafile.FromFile("test.emf");
            picMetafile1.Image = mf1;
            picMetafile1Stretched.Image = mf1;

            Metafile mf2 = (Metafile)Metafile.FromFile("Volleyball.wmf");
            picMetafile2.Image = mf2;
            picMetafile2Stretched.Image = mf2;
        }
    }
}

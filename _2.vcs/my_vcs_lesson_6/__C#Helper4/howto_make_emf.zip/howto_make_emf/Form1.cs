﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Drawing.Imaging;
using System.Drawing.Drawing2D;

namespace howto_make_emf
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // Make a metafile.
            Metafile mf = MakeMetafile(100, 100, "test.emf");

            // Draw on the metafile.
            DrawOnMetafile(mf);

            // Convert the metafile into a bitmap.
            Bitmap bm = MetafileToBitmap(mf);

            // Display in various ways.
            picCanvas1.Image = bm;  // Original size.
            picCanvas2.Image = bm;  // Stretches pixelated.
            picCanvas3.Image = mf;  // Stretches smoothly.
        }

        // Return a metafile with the indicated size.
        private Metafile MakeMetafile(float width, float height, string filename)
        {
            // Make a reference bitmap.
            using (Bitmap bm = new Bitmap(16, 16))
            {
                using (Graphics gr = Graphics.FromImage(bm))
                {
                    RectangleF bounds = new RectangleF(0, 0, width, height);

                    Metafile mf;
                    if ((filename != null) && (filename.Length > 0))
                        mf = new Metafile(filename, gr.GetHdc(), bounds, MetafileFrameUnit.Pixel);
                    else
                        mf = new Metafile(gr.GetHdc(), bounds, MetafileFrameUnit.Pixel);

                    gr.ReleaseHdc();
                    return mf;
                }
            }
        }

        // Draw on the metafile.
        private void DrawOnMetafile(Metafile mf)
        {
            using (Graphics gr = Graphics.FromImage(mf))
            {
                gr.SmoothingMode = SmoothingMode.AntiAlias;
                using (Pen pen = new Pen(Color.Red, 5))
                {
                    gr.DrawEllipse(pen, 5, 5, 90, 90);
                }
                using (Brush brush = new SolidBrush(Color.FromArgb(255, 128, 255, 128)))
                {
                    gr.FillEllipse(brush, 5, 25, 90, 50);
                }
                using (Brush brush = new SolidBrush(Color.FromArgb(128, 128, 128, 255)))
                {
                    gr.FillEllipse(brush, 25, 5, 50, 90);
                }
                Point[] points =
                {
                    new Point(50, 5),
                    new Point(94, 50),
                    new Point(50, 94),
                    new Point(5, 50),
                };
                gr.DrawPolygon(Pens.Blue, points);
            }
        }

        // Draw the metafile onto a bitmap.
        private Bitmap MetafileToBitmap(Metafile mf)
        {
            Bitmap bm = new Bitmap(mf.Width, mf.Height);
            using (Graphics gr = Graphics.FromImage(bm))
            {
                GraphicsUnit unit = GraphicsUnit.Pixel;
                RectangleF source = mf.GetBounds(ref unit);

                PointF[] dest =
                {
                    new PointF(0, 0),
                    new PointF(source.Width, 0),
                    new PointF(0, source.Height),
                };
                gr.DrawImage(mf, dest, source, GraphicsUnit.Pixel);
            }
            return bm;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_picturebox_slider
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // The current value.
        private float SliderValue = 0.3f;

        // The minimum and maximum allowed values.
        private const float MinimumValue = 0.0f;
        private const float MaximumValue = 1.0f;

        // Move the needle to this position.
        private bool MouseIsDown = false;
        private void picSlider_MouseDown(object sender, MouseEventArgs e)
        {
            MouseIsDown = true;
            SetValue(XtoValue(e.X));
        }
        private void picSlider_MouseMove(object sender, MouseEventArgs e)
        {
            if (!MouseIsDown) return;
            SetValue(XtoValue(e.X));
        }
        private void picSlider_MouseUp(object sender, MouseEventArgs e)
        {
            MouseIsDown = false;
            tipValue.Hide(this);

            // Take action here if desired.
            lblResult.Text = SliderValue.ToString("0.00");
        }

        // Convert an X coordinate to a value.
        private float XtoValue(int x)
        {
            return MinimumValue + (MaximumValue - MinimumValue) *
                x / (float)(picSlider.ClientSize.Width - 1);
        }

        // Convert value to an X coordinate.
        private float ValueToX(float value)
        {
            return (picSlider.ClientSize.Width - 1) *
                (value - MinimumValue) / (float)(MaximumValue - MinimumValue);
        }

        // Draw the needle.
        private void picSlider_Paint(object sender, PaintEventArgs e)
        {
            // Calculate the needle's X coordinate.
            float x = ValueToX(SliderValue);

            // Draw it.
            using (Pen pen = new Pen(Color.Blue, 2))
            {
                e.Graphics.DrawLine(pen, x, 0,
                    x, picSlider.ClientSize.Height);
            }
        }

        // Set the slider's value. If the value has changed,
        // display the value tooltip.
        private void SetValue(float value)
        {
            // Make sure the new value is within bounds.
            if (value < MinimumValue) value = MinimumValue;
            if (value > MaximumValue) value = MaximumValue;

            // See if the value has changed.
            if (SliderValue == value) return;

            // Save the new value.
            SliderValue = value;

            // Redraw to show the new value.
            picSlider.Refresh();

            // Display the value tooltip.
            int tip_x = picSlider.Left + (int)ValueToX(SliderValue);
            int tip_y = picSlider.Top;
            tipValue.Show(SliderValue.ToString("0.00"), this, tip_x, tip_y, 3000);

            // Take action here if desired.
            lblResult.Text = SliderValue.ToString("0.00");
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_list_birthday_day_of_week
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Display the next 10 birthdays.
        private void btnGo_Click(object sender, EventArgs e)
        {
            // Get the month, day, and year of the entered birthday.
            DateTime birthday;
            if (!DateTime.TryParse(txtDate.Text, out birthday))
            {
                MessageBox.Show("Please enter a valid birthday.");
                return;
            }
            int month = birthday.Month;
            int day = birthday.Day;
            int year = birthday.Year;

            // Loop through the years.
            lstBirthDays.Items.Clear();
            for (int i = 0; i <= 10; i++)
            {
                DateTime new_birthday;
                try
                {
                    new_birthday = new DateTime(year + i, month, day);
                }
                catch
                {
                    new_birthday = new DateTime(year + i, month + 1, 1);
                }
                lstBirthDays.Items.Add(
                    new_birthday.ToShortDateString() + " : " +
                    new_birthday.DayOfWeek.ToString());
            }
        }
    }
}

For this project I am using Visual Studio 2012 Express Edition.
You can use any other version of VS.

Project video
https://www.youtube.com/watch?v=EYf3Teh0nqM


Have fun coding.

stay happy and keep smiling :-)

yusufshakeel

https://www.facebook.com/yusufshakeel
https://www.youtube.com/yusufshakeel
https://plus.google.com/+YusufShakeel
http://yusufshakeelblog.blogspot.in
https://github.com/yusufshakeel
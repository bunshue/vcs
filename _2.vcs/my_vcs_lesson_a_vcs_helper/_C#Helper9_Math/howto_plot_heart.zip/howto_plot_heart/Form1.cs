﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_plot_heart
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Plot the equations.
        private void Form1_Load(object sender, EventArgs e)
        {
            // Make the Bitmap.
            Bitmap bm = new Bitmap(picGraph.ClientSize.Width, picGraph.ClientSize.Height);
            using (Graphics gr = Graphics.FromImage(bm))
            {
                // Clear.
                gr.Clear(Color.White);
                gr.ScaleTransform(24f, -24f, System.Drawing.Drawing2D.MatrixOrder.Append);
                gr.TranslateTransform(bm.Width * 0.5f, bm.Height * 0.4f,
                    System.Drawing.Drawing2D.MatrixOrder.Append);

                // Draw axes.
                using (Pen axis_pen = new Pen(Color.Gray, 0))
                {
                    gr.DrawLine(axis_pen, -6, 0, 6, 0);
                    gr.DrawLine(axis_pen, 0, -6, 0, 6);
                    for (int i = -6; i <= 6; i++)
                    {
                        gr.DrawLine(axis_pen, i, -0.1f, i, 0.1f);
                        gr.DrawLine(axis_pen, -0.1f, i, 0.1f, i);
                    }
                }

                // Graph the equations.
                float dx = 2f / bm.Width;
                float dy = 2f / bm.Height;
                PlotFunction(gr, F1, dx, dy);
                PlotFunction(gr, F2, dx, dy);
                PlotFunction(gr, F3, dx, dy);
                PlotFunction(gr, F4, dx, dy);
                PlotFunction(gr, F5, dx, dy);
                PlotFunction(gr, F6, dx, dy);
            } // using gr.

            // Display the result.
            picGraph.Image = bm;
        }

        private delegate float FofXY(float x, float y);

        // Plot a function.
        private void PlotFunction(Graphics gr, FofXY func, float dx, float dy)
        {
            // Plot the function.
            using (Pen thin_pen = new Pen(Color.Black, 0))
            {
                // Horizontal comparisons.
                for (float x = -6f; x <= 6f; x += dx)
                {
                    float last_y = func(x, -6f);
                    for (float y = -6f + dy; y <= 6f; y += dy)
                    {
                        float next_y = func(x, y);
                        if (
                            ((last_y <= 0f) && (next_y >= 0f)) ||
                            ((last_y >= 0f) && (next_y <= 0f))
                           )
                        {
                            // Plot this point.
                            gr.DrawLine(thin_pen, x, y - dy, x, y);
                        }
                        last_y = next_y;
                    }
                } // Horizontal comparisons.

                // Vertical comparisons.
                for (float y = -6f + dy; y <= 6f; y += dy)
                {
                    float last_x = func(-6f, y);
                    for (float x = -6f; x <= 6f; x += dx)
                    {
                        float next_x = func(x, y);
                        if (
                            ((last_x <= 0f) && (next_x >= 0f)) ||
                            ((last_x >= 0f) && (next_x <= 0f))
                           )
                        {
                            // Plot this point.
                            gr.DrawLine(thin_pen, x - dx, y, x, y);
                        }
                        last_x = next_x;
                    }
                } // Vertical comparisons.
            } // using thin_pen.
        }

        // The functions.
        // x^2 + y^2 = 2.5^2
        // y = Sqrt(2.5^2 - x^2)
        // Offset x => x - 2.5
        private float F1(float x, float y)
        {
            return (float)(y - Math.Sqrt(2.5 * 2.5 - (x - 2.5) * (x - 2.5)));
        }
        // x^2 + y^2 = 2.5^2
        // y = Sqrt(2.5^2 - x^2)
        // Offset x => x + 2.5
        private float F2(float x, float y)
        {
            return (float)(y - Math.Sqrt(2.5 * 2.5 - (x + 2.5) * (x + 2.5)));
        }
        // x^2 + y^2 = 2.5^2
        // y = Sqrt(2.5^2 - x^2)
        // Add Sqrt(x) - Sqrt(x)    Defined for x > 0
        // Scale y => -y            Flip vertically
        // Offset x => x - 2.5      Translate 2.5 to the right
        private float F3(float x, float y)
        {
            return (float)(
                (-y - Math.Sqrt(2.5 * 2.5 - (x - 2.5) * (x - 2.5))) +
                Math.Sqrt(x - 2.5) - Math.Sqrt(x - 2.5)
            );
        }
        // x^2 + y^2 = 2.5^2
        // y = Sqrt(2.5^2 - x^2)
        // Add Sqrt(x) - Sqrt(x)    Defined for x > 0
        // Scale y => -y            Flip vertically
        // Scale x => -x            Flip horizontally
        // Offset x => x + 2.5      Translate 2.5 to the left
        private float F4(float x, float y)
        {
            return (float)(
                (-y - Math.Sqrt(2.5 * 2.5 - (-(x + 2.5)) * (-(x + 2.5)))) +
                Math.Sqrt(-(x + 2.5)) - Math.Sqrt(-(x + 2.5))
            );
        }
        // x^2 + y^2 = 2.5^2
        // y = Sqrt(2.5^2 - x^2)
        // Add Sqrt(x) - Sqrt(x)    Defined for x >= 0
        // Offset y => y + 5        Translate 5 down
        // Offset x => x + 2.5      Translate 2.5 to the left
        private float F5(float x, float y)
        {
            return (float)(
                ((y + 5) - Math.Sqrt(2.5 * 2.5 - (x + 2.5) * (x + 2.5))) +
                Math.Sqrt(x + 2.5) - Math.Sqrt(x + 2.5)
            );
        }
        // x^2 + y^2 = 2.5^2
        // y = Sqrt(2.5^2 - x^2)
        // Add Sqrt(-x) - Sqrt(-x)  Defined for x <= 0
        // Offset y => y + 5        Translate 5 down
        // Offset x => x - 2.5      Translate 2.5 to the right
        private float F6(float x, float y)
        {
            return (float)(
                ((y + 5) - Math.Sqrt(2.5 * 2.5 - ((x - 2.5)) * ((x - 2.5)))) +
                Math.Sqrt(-(x - 2.5)) - Math.Sqrt(-(x - 2.5))
            );
        }
    }
}

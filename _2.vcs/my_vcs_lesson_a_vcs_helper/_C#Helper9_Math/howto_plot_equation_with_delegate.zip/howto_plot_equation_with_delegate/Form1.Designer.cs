﻿namespace howto_plot_equation_with_delegate
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.picGraph = new System.Windows.Forms.PictureBox();
            this.radF1 = new System.Windows.Forms.RadioButton();
            this.radF2 = new System.Windows.Forms.RadioButton();
            this.radF4 = new System.Windows.Forms.RadioButton();
            this.radF3 = new System.Windows.Forms.RadioButton();
            ((System.ComponentModel.ISupportInitialize)(this.picGraph)).BeginInit();
            this.SuspendLayout();
            // 
            // picGraph
            // 
            this.picGraph.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.picGraph.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.picGraph.Location = new System.Drawing.Point(178, 12);
            this.picGraph.Name = "picGraph";
            this.picGraph.Size = new System.Drawing.Size(260, 260);
            this.picGraph.TabIndex = 4;
            this.picGraph.TabStop = false;
            // 
            // radF1
            // 
            this.radF1.AutoSize = true;
            this.radF1.Location = new System.Drawing.Point(12, 12);
            this.radF1.Name = "radF1";
            this.radF1.Size = new System.Drawing.Size(100, 17);
            this.radF1.TabIndex = 5;
            this.radF1.TabStop = true;
            this.radF1.Text = "x^2 + x*y - y = 0";
            this.radF1.UseVisualStyleBackColor = true;
            this.radF1.CheckedChanged += new System.EventHandler(this.radF1_CheckedChanged);
            // 
            // radF2
            // 
            this.radF2.AutoSize = true;
            this.radF2.Location = new System.Drawing.Point(12, 35);
            this.radF2.Name = "radF2";
            this.radF2.Size = new System.Drawing.Size(91, 17);
            this.radF2.TabIndex = 6;
            this.radF2.TabStop = true;
            this.radF2.Text = "y - 1 / x^2 = 0";
            this.radF2.UseVisualStyleBackColor = true;
            this.radF2.CheckedChanged += new System.EventHandler(this.radF2_CheckedChanged);
            // 
            // radF4
            // 
            this.radF4.AutoSize = true;
            this.radF4.Location = new System.Drawing.Point(12, 81);
            this.radF4.Name = "radF4";
            this.radF4.Size = new System.Drawing.Size(100, 17);
            this.radF4.TabIndex = 8;
            this.radF4.TabStop = true;
            this.radF4.Text = "y - 3 * Cos(x) / x";
            this.radF4.UseVisualStyleBackColor = true;
            this.radF4.CheckedChanged += new System.EventHandler(this.radF4_CheckedChanged);
            // 
            // radF3
            // 
            this.radF3.AutoSize = true;
            this.radF3.Location = new System.Drawing.Point(12, 58);
            this.radF3.Name = "radF3";
            this.radF3.Size = new System.Drawing.Size(127, 17);
            this.radF3.TabIndex = 7;
            this.radF3.TabStop = true;
            this.radF3.Text = "x^2 + (y/2)^2 - 49 = 0";
            this.radF3.UseVisualStyleBackColor = true;
            this.radF3.CheckedChanged += new System.EventHandler(this.radF3_CheckedChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(450, 284);
            this.Controls.Add(this.radF4);
            this.Controls.Add(this.radF3);
            this.Controls.Add(this.radF2);
            this.Controls.Add(this.radF1);
            this.Controls.Add(this.picGraph);
            this.Name = "Form1";
            this.Text = "howto_plot_equation_with_delegate";
            ((System.ComponentModel.ISupportInitialize)(this.picGraph)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox picGraph;
        private System.Windows.Forms.RadioButton radF1;
        private System.Windows.Forms.RadioButton radF2;
        private System.Windows.Forms.RadioButton radF4;
        private System.Windows.Forms.RadioButton radF3;
    }
}


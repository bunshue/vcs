﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_calculate_log_bases
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnFindLog_Click(object sender, EventArgs e)
        {
            double number = double.Parse(txtNumber.Text);
            double log_base = double.Parse(txtBase.Text);
            double result = Math.Log(number) / Math.Log(log_base);
            txtResult.Text = result.ToString();
            txtVerify.Text = Math.Pow(log_base, result).ToString();
        }

        // Calculate log(number) in the indicated log base.
        private double LogBase(double number, double log_base)
        {
            return Math.Log(number) / Math.Log(log_base);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_multiple_clipboard_formats
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Make some RichText to use.
        private void Form1_Load(object sender, EventArgs e)
        {
            string txt = "The quick brown fox jumps over the lazy dog.";
            rchSource.Text = txt;

            rchSource.Select(txt.IndexOf("quick"), "quick".Length);
            rchSource.SelectionFont = new Font(rchSource.SelectionFont, FontStyle.Italic);

            rchSource.Select(txt.IndexOf("brown"), "brown".Length);
            rchSource.SelectionFont = new Font(rchSource.SelectionFont, FontStyle.Bold);
            rchSource.SelectionColor = Color.Brown;

            rchSource.Select(txt.IndexOf("fox"), "fox".Length);
            rchSource.SelectionFont = new Font(rchSource.SelectionFont, FontStyle.Bold);
            rchSource.SelectionColor = Color.Red;

            rchSource.Select(txt.IndexOf("jumps over"), "jumps over".Length);
            rchSource.SelectionFont = new Font(rchSource.SelectionFont, FontStyle.Underline);

            rchSource.Select(txt.IndexOf("lazy"), "lazy".Length);
            rchSource.SelectionFont = new Font(rchSource.SelectionFont, FontStyle.Bold);

            rchSource.Select(txt.IndexOf("dog"), "dog".Length);
            rchSource.SelectionFont = new Font(rchSource.SelectionFont, FontStyle.Bold);
            rchSource.SelectionColor = Color.Blue;

            rchSource.Select(0, 0);
        }

        // Copy data to the clipboard in text, RTF, and HTML formats.
        private void btnCopy_Click(object sender, EventArgs e)
        {
            // Make a DataObject.
            DataObject data_object = new DataObject();

            // Add the data in various formats.
            data_object.SetData(DataFormats.Rtf, rchSource.Rtf);
            data_object.SetData(DataFormats.Text, rchSource.Text);

            string html_text;
            html_text = "<HTML>\r\n";
            html_text += "  <HEAD>The Quick Brown Fox</HEAD>\r\n";
            html_text += "  <BODY>\r\n";
            html_text += rchSource.Text + "\r\n";
            html_text += "  </BODY>\r\n";
            html_text += "</HTML>";
            data_object.SetData(DataFormats.Html, html_text);

            // Place the data in the Clipboard.
            Clipboard.SetDataObject(data_object);
        }

        // Paste data from the clipboard in text,
        // RTF, and HTML formats if they are available.
        private void btnPaste_Click(object sender, EventArgs e)
        {
            // Get the DataObject.
            IDataObject data_object = Clipboard.GetDataObject();

            if (data_object.GetDataPresent(DataFormats.Rtf))
            {
                rchRtf.Rtf = data_object.GetData(DataFormats.Rtf).ToString();
                txtRtfCode.Text = data_object.GetData(DataFormats.Rtf).ToString();
            }
            else
            {
                rchRtf.Clear();
                txtRtfCode.Clear();
            }

            if (data_object.GetDataPresent(DataFormats.Text))
            {
                txtText.Text = data_object.GetData(DataFormats.Text).ToString();
            }
            else
            {
                txtText.Clear();
            }

            if (data_object.GetDataPresent(DataFormats.Html))
            {
                txtHtml.Text = data_object.GetData(DataFormats.Html).ToString();
            }
            else
            {
                txtHtml.Clear();
            }
        }
    }
}

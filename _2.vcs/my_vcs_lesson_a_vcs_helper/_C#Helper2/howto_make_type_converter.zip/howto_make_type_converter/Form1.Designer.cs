﻿namespace howto_make_type_converter
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pgdPeople = new System.Windows.Forms.PropertyGrid();
            this.lstPeople = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // pgdPeople
            // 
            this.pgdPeople.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pgdPeople.Location = new System.Drawing.Point(136, 0);
            this.pgdPeople.Name = "pgdPeople";
            this.pgdPeople.Size = new System.Drawing.Size(283, 264);
            this.pgdPeople.TabIndex = 5;
            // 
            // lstPeople
            // 
            this.lstPeople.Dock = System.Windows.Forms.DockStyle.Left;
            this.lstPeople.FormattingEnabled = true;
            this.lstPeople.Location = new System.Drawing.Point(0, 0);
            this.lstPeople.Name = "lstPeople";
            this.lstPeople.Size = new System.Drawing.Size(136, 264);
            this.lstPeople.TabIndex = 4;
            this.lstPeople.SelectedIndexChanged += new System.EventHandler(this.lstPeople_SelectedIndexChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(419, 264);
            this.Controls.Add(this.pgdPeople);
            this.Controls.Add(this.lstPeople);
            this.Name = "Form1";
            this.Text = "hwoto_make_type_converter";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PropertyGrid pgdPeople;
        private System.Windows.Forms.ListBox lstPeople;
    }
}


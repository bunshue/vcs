﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_null_optional_parameters
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Draw two polygons.
        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;

            // Draw diamonds on the form.
            RectangleF rect1 = new RectangleF(4, 4,
                this.ClientSize.Width / 2 - 6,
                this.ClientSize.Height - 8);
            RectangleF rect2 = new RectangleF(
                rect1.Right + 4, 4,
                this.ClientSize.Width / 2 - 6,
                this.ClientSize.Height - 8);
            DrawDiamond(e.Graphics, rect1, null, Brushes.Yellow);
            DrawDiamond(e.Graphics, rect2, Pens.Blue, null);
        }

        // Draw a diamond, optionally filling it.
        private void DrawDiamond(Graphics gr, RectangleF bounds, Pen pen, Brush brush)
        {
            // Make the diamond's points.
            PointF[] points = new PointF[4];
            float xmid = (bounds.Left + bounds.Right) / 2;
            float ymid = (bounds.Top + bounds.Bottom) / 2;
            points[0] = new PointF(xmid, bounds.Top);
            points[1] = new PointF(bounds.Right, ymid);
            points[2] = new PointF(xmid, bounds.Bottom);
            points[3] = new PointF(bounds.Left, ymid);

            // Fill the diamond.
            if (brush != null) gr.FillPolygon(brush, points);

            // Draw the diamond.
            if (pen != null) gr.DrawPolygon(pen, points);
        }
    }
}

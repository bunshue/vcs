﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_datagridview_display_objects
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // Make some data items.
            OrderItem[] order_items = 
            {
                new OrderItem("Pencils, dozen", 1.24m, 4),
                new OrderItem("Cookies, box", 2.17m, 1),
                new OrderItem("Notebook", 1.95m, 2),
                new OrderItem("Paper, ream", 3.75m, 3),
                new OrderItem("Pencil sharpener", 12.95m, 1),
                new OrderItem("Paper clips, 100", 0.75m, 1),
            };

            // Add the items to the DataGridView.
            AddOrderItems(order_items);
 
            // Define a column style at run time.
            DataGridViewCellStyle cell_style = new DataGridViewCellStyle();
            cell_style.BackColor = Color.LightGreen;
            cell_style.Alignment = DataGridViewContentAlignment.MiddleRight;
            cell_style.Format = "C2";
            dgvValues.Columns[3].DefaultCellStyle = cell_style;
        }

        // Add the items to the DataGridView.
        private void AddOrderItems(OrderItem[] order_items)
        {
            foreach (OrderItem item in order_items)
            {
                dgvValues.Rows.Add(new object[]
                    {
                        item.Description,
                        item.UnitPrice,
                        item.Quantity,
                        item.TotalCost
                    }
                );
            }
        }
    }
}

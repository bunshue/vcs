﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_array_class_binary_search
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // The data values.
        private const int NumValues = 100;
        private int[] Values;

        // Make some random values.
        private void Form1_Load(object sender, EventArgs e)
        {
            // Generate random values.
            Random rand = new Random();
            Values = new int[NumValues];
            for (int i = 0; i < NumValues; i++)
            {
                Values[i] = rand.Next(0, 100);
            }

            // Sort the values.
            Array.Sort(Values);

            // Display the values.
            lstValues.DataSource = Values;
        }

        // Find a value.
        private void btnSearch_Click(object sender, EventArgs e)
        {
            // Get the target value.
            int target = int.Parse(txtValue.Text);

            // Try to find it.
            int index = Array.BinarySearch(Values, target);

            // Select the value.
            if (index >= 0)
            {
                // We found the target. Select it.
                lstValues.SelectedIndex = index;
            }
            else
            {
                // We didn't find the target. Select a nearby value.
                index = -index;
                if (index >= NumValues) index = NumValues - 1;
                lstValues.SelectedIndex = index;
            }
        }
    }
}

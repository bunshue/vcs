﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_datagridview_column_style
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // Make some data items.
            dgvValues.Rows.Add(new object[] { "Pencils, dozen", 1.24m, 4, 4 * 1.24m });
            dgvValues.Rows.Add(new object[] { "Cookies, box", 2.17m, 1, 2.17m });
            dgvValues.Rows.Add(new object[] { "Notebook", 1.95m, 2, 2 * 1.95m });
            dgvValues.Rows.Add(new object[] { "Paper, ream", 3.75m, 2, 2 * 3.75m });
            dgvValues.Rows.Add(new object[] { "Pencil sharpener", 12.95m, 1, 1 * 12.95m });
            dgvValues.Rows.Add(new object[] { "Paper clips, 100", 0.75m, 1, 1 * 0.75m });

            // Define a column style at run time.
            DataGridViewCellStyle cell_style = new DataGridViewCellStyle();
            cell_style.BackColor = Color.LightGreen;
            cell_style.Alignment = DataGridViewContentAlignment.MiddleRight;
            cell_style.Format = "C2";
            dgvValues.Columns[3].DefaultCellStyle = cell_style;
        }
    }
}

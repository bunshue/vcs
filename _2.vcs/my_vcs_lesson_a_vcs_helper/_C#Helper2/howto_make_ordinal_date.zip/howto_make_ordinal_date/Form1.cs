﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_make_ordinal_date
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Display an initial date.
        private void Form1_Load(object sender, EventArgs e)
        {
            txtDate.Text = "8/20/2020";
        }

        // Display the date in an ordinal format.
        private void txtDate_TextChanged(object sender, EventArgs e)
        {
            // Parse the date and display it in ordinal format.
            try
            {
                DateTime value = DateTime.Parse(txtDate.Text);
                txtResult.Text = value.ToOrdinal();
            }
            catch
            {
                txtResult.Clear();
            }
        }
    }
}

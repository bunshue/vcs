﻿namespace howto_evaluate_expressions
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnEvaluate = new System.Windows.Forms.Button();
            this.txtResult = new System.Windows.Forms.TextBox();
            this.Label4 = new System.Windows.Forms.Label();
            this.GroupBox1 = new System.Windows.Forms.GroupBox();
            this.txtValue4 = new System.Windows.Forms.TextBox();
            this.txtName4 = new System.Windows.Forms.TextBox();
            this.txtValue3 = new System.Windows.Forms.TextBox();
            this.txtName3 = new System.Windows.Forms.TextBox();
            this.txtValue2 = new System.Windows.Forms.TextBox();
            this.txtName2 = new System.Windows.Forms.TextBox();
            this.Label3 = new System.Windows.Forms.Label();
            this.txtValue1 = new System.Windows.Forms.TextBox();
            this.Label2 = new System.Windows.Forms.Label();
            this.txtName1 = new System.Windows.Forms.TextBox();
            this.txtExpression = new System.Windows.Forms.TextBox();
            this.Label1 = new System.Windows.Forms.Label();
            this.GroupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnEvaluate
            // 
            this.btnEvaluate.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.btnEvaluate.Location = new System.Drawing.Point(128, 198);
            this.btnEvaluate.Name = "btnEvaluate";
            this.btnEvaluate.Size = new System.Drawing.Size(72, 24);
            this.btnEvaluate.TabIndex = 15;
            this.btnEvaluate.Text = "Evaluate";
            this.btnEvaluate.Click += new System.EventHandler(this.btnEvaluate_Click);
            // 
            // txtResult
            // 
            this.txtResult.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtResult.Location = new System.Drawing.Point(6, 246);
            this.txtResult.Name = "txtResult";
            this.txtResult.ReadOnly = true;
            this.txtResult.Size = new System.Drawing.Size(313, 20);
            this.txtResult.TabIndex = 14;
            // 
            // Label4
            // 
            this.Label4.Location = new System.Drawing.Point(6, 230);
            this.Label4.Name = "Label4";
            this.Label4.Size = new System.Drawing.Size(72, 16);
            this.Label4.TabIndex = 13;
            this.Label4.Text = "Result";
            // 
            // GroupBox1
            // 
            this.GroupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.GroupBox1.Controls.Add(this.txtValue4);
            this.GroupBox1.Controls.Add(this.txtName4);
            this.GroupBox1.Controls.Add(this.txtValue3);
            this.GroupBox1.Controls.Add(this.txtName3);
            this.GroupBox1.Controls.Add(this.txtValue2);
            this.GroupBox1.Controls.Add(this.txtName2);
            this.GroupBox1.Controls.Add(this.Label3);
            this.GroupBox1.Controls.Add(this.txtValue1);
            this.GroupBox1.Controls.Add(this.Label2);
            this.GroupBox1.Controls.Add(this.txtName1);
            this.GroupBox1.Location = new System.Drawing.Point(6, 54);
            this.GroupBox1.Name = "GroupBox1";
            this.GroupBox1.Size = new System.Drawing.Size(312, 136);
            this.GroupBox1.TabIndex = 12;
            this.GroupBox1.TabStop = false;
            this.GroupBox1.Text = "Primatives";
            // 
            // txtValue4
            // 
            this.txtValue4.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txtValue4.Location = new System.Drawing.Point(164, 104);
            this.txtValue4.Name = "txtValue4";
            this.txtValue4.Size = new System.Drawing.Size(120, 20);
            this.txtValue4.TabIndex = 8;
            // 
            // txtName4
            // 
            this.txtName4.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txtName4.Location = new System.Drawing.Point(36, 104);
            this.txtName4.Name = "txtName4";
            this.txtName4.Size = new System.Drawing.Size(120, 20);
            this.txtName4.TabIndex = 7;
            // 
            // txtValue3
            // 
            this.txtValue3.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txtValue3.Location = new System.Drawing.Point(164, 80);
            this.txtValue3.Name = "txtValue3";
            this.txtValue3.Size = new System.Drawing.Size(120, 20);
            this.txtValue3.TabIndex = 6;
            // 
            // txtName3
            // 
            this.txtName3.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txtName3.Location = new System.Drawing.Point(36, 80);
            this.txtName3.Name = "txtName3";
            this.txtName3.Size = new System.Drawing.Size(120, 20);
            this.txtName3.TabIndex = 5;
            // 
            // txtValue2
            // 
            this.txtValue2.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txtValue2.Location = new System.Drawing.Point(164, 56);
            this.txtValue2.Name = "txtValue2";
            this.txtValue2.Size = new System.Drawing.Size(120, 20);
            this.txtValue2.TabIndex = 4;
            // 
            // txtName2
            // 
            this.txtName2.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txtName2.Location = new System.Drawing.Point(36, 56);
            this.txtName2.Name = "txtName2";
            this.txtName2.Size = new System.Drawing.Size(120, 20);
            this.txtName2.TabIndex = 3;
            // 
            // Label3
            // 
            this.Label3.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.Label3.Location = new System.Drawing.Point(164, 16);
            this.Label3.Name = "Label3";
            this.Label3.Size = new System.Drawing.Size(72, 16);
            this.Label3.TabIndex = 3;
            this.Label3.Text = "Value";
            // 
            // txtValue1
            // 
            this.txtValue1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txtValue1.Location = new System.Drawing.Point(164, 32);
            this.txtValue1.Name = "txtValue1";
            this.txtValue1.Size = new System.Drawing.Size(120, 20);
            this.txtValue1.TabIndex = 2;
            this.txtValue1.Text = "3.14159265";
            // 
            // Label2
            // 
            this.Label2.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.Label2.Location = new System.Drawing.Point(36, 16);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(72, 16);
            this.Label2.TabIndex = 1;
            this.Label2.Text = "Name";
            // 
            // txtName1
            // 
            this.txtName1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txtName1.Location = new System.Drawing.Point(36, 32);
            this.txtName1.Name = "txtName1";
            this.txtName1.Size = new System.Drawing.Size(120, 20);
            this.txtName1.TabIndex = 1;
            this.txtName1.Text = "Pi";
            // 
            // txtExpression
            // 
            this.txtExpression.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtExpression.Location = new System.Drawing.Point(6, 22);
            this.txtExpression.Name = "txtExpression";
            this.txtExpression.Size = new System.Drawing.Size(313, 20);
            this.txtExpression.TabIndex = 10;
            this.txtExpression.Text = "Cos(Pi/4)^2";
            // 
            // Label1
            // 
            this.Label1.Location = new System.Drawing.Point(6, 6);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(72, 16);
            this.Label1.TabIndex = 11;
            this.Label1.Text = "Expression";
            // 
            // Form1
            // 
            this.AcceptButton = this.btnEvaluate;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(325, 273);
            this.Controls.Add(this.btnEvaluate);
            this.Controls.Add(this.txtResult);
            this.Controls.Add(this.Label4);
            this.Controls.Add(this.GroupBox1);
            this.Controls.Add(this.txtExpression);
            this.Controls.Add(this.Label1);
            this.Name = "Form1";
            this.Text = "howto_evaluate_expressions";
            this.GroupBox1.ResumeLayout(false);
            this.GroupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.Button btnEvaluate;
        internal System.Windows.Forms.TextBox txtResult;
        internal System.Windows.Forms.Label Label4;
        internal System.Windows.Forms.GroupBox GroupBox1;
        internal System.Windows.Forms.TextBox txtValue4;
        internal System.Windows.Forms.TextBox txtName4;
        internal System.Windows.Forms.TextBox txtValue3;
        internal System.Windows.Forms.TextBox txtName3;
        internal System.Windows.Forms.TextBox txtValue2;
        internal System.Windows.Forms.TextBox txtName2;
        internal System.Windows.Forms.Label Label3;
        internal System.Windows.Forms.TextBox txtValue1;
        internal System.Windows.Forms.Label Label2;
        internal System.Windows.Forms.TextBox txtName1;
        internal System.Windows.Forms.TextBox txtExpression;
        internal System.Windows.Forms.Label Label1;
    }
}


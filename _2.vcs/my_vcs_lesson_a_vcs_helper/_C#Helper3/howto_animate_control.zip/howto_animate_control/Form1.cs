﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_animate_control
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private ControlSprite ButtonSprite, LabelSprite;

        // Make the control sprites.
        private void Form1_Load(object sender, EventArgs e)
        {
            ButtonSprite = new ControlSprite(btnStart);
            ButtonSprite.Done += ButtonSprite_Done;
            LabelSprite = new ControlSprite(lblMessage);
        }

        // Start or stop.
        private void btnStart_Click(object sender, EventArgs e)
        {
            const int PixelsPerSecond = 200;

            if (btnStart.Text == "Start")
            {
                // Start button. Change the caption to Stop.
                btnStart.Text = "Stop";

                // See where we are.
                if (btnStart.Location.X == 12)
                {
                    // Move the button down and right.
                    ButtonSprite.Start(197, 229, PixelsPerSecond);
                    LabelSprite.Start(12, 232, PixelsPerSecond);
                }
                else if (btnStart.Location.X == 197)
                {
                    // Move the button up and left.
                    ButtonSprite.Start(12, 12, PixelsPerSecond);
                    LabelSprite.Start(186, 12, PixelsPerSecond);
                }
                else
                {
                    // Continue the button's previous move.
                    ButtonSprite.Start();
                    LabelSprite.Start();
                }
            }
            else
            {
                // Stop button. Change the caption to Start.
                btnStart.Text = "Start";

                // Stop moving.
                ButtonSprite.Stop();
                LabelSprite.Stop();
            }
        }

        // The button is done moving.
        public void ButtonSprite_Done(object sender)
        {
            btnStart.Text = "Start";
        }
    }
}

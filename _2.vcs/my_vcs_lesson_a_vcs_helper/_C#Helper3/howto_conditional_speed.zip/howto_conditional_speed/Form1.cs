﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Globalization;
using System.Diagnostics;

namespace howto_conditional_speed
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Perform the trials.
        private void btnGo_Click(object sender, EventArgs e)
        {
            long num_trials = long.Parse(txtNumTrials.Text, NumberStyles.Any);
            lblIfTime.Text = "";
            lblConditionalTime.Text = "";
            Cursor = Cursors.WaitCursor;
            Refresh();

            Stopwatch watch = new Stopwatch();
            long x;

            // Trials using if.
            x = 1;
            watch.Start();
            for (long i = 0; i < num_trials; i++)
            {
                if (x % 2 == 0) x = x + 1;
                else x = x + 3;
            }
            watch.Stop();
            lblIfTime.Text =
                watch.Elapsed.TotalSeconds.ToString("0.00") +
                " seconds";
            Refresh();

            // Trials using ?:.
            x = 1;
            watch.Reset();
            watch.Start();
            for (long i = 0; i < num_trials; i++)
            {
                x = (x % 2 == 0) ? x + 1 : x + 3;
            }
            watch.Stop();
            lblConditionalTime.Text =
                watch.Elapsed.TotalSeconds.ToString("0.00") +
                " seconds";

            Cursor = Cursors.Default;
        }
    }
}

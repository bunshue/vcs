﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_biggest_font_label_wrapped
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void txtSample_TextChanged(object sender, EventArgs e)
        {
            ShowSample();
        }
        private void lblSample_Resize(object sender, EventArgs e)
        {
            ShowSample();
        }

        // Display the sample text as large as possible.
        private void ShowSample()
        {
            string text = txtSample.Text;
            if (text.Length == 0) return;

            float font_size = GetFontSize(
                lblSample, text, 10, 1, 1000);
            lblFontSize.Text = font_size.ToString("0.0");
            lblSample.Font = new Font(lblSample.Font.FontFamily, font_size);
            lblSample.Text = text;
        }

        // Return the largest font size that lets the text fit in the Label.
        private float GetFontSize(Label label, string text,
            int margin, float min_size, float max_size)
        {
            // Only bother if there's text.
            if (text.Length == 0) return min_size;

            // See how much room we have, allowing a bit
            // for the Label's internal margin.
            int wid = label.DisplayRectangle.Width - margin;
            int hgt = label.DisplayRectangle.Height - margin;

            // Make a Graphics object to measure the text.
            using (Graphics gr = label.CreateGraphics())
            {
                while (max_size - min_size > 0.1f)
                {
                    float pt = (min_size + max_size) / 2f;
                    using (Font test_font = new Font(label.Font.FontFamily, pt))
                    {
                        // See if this font is too big.
                        SizeF text_size = gr.MeasureString(text, test_font, wid);
                        if ((text_size.Width > wid) || (text_size.Height > hgt))
                            max_size = pt;
                        else
                            min_size = pt;
                    }
                }
                return min_size;
            }
        }
    }
}

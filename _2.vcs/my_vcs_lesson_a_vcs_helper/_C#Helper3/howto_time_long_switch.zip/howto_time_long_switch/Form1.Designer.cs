﻿namespace howto_time_long_switch
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.numTrialsTextBox = new System.Windows.Forms.TextBox();
            this.goButton = new System.Windows.Forms.Button();
            this.txtIf10 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtSwitch10 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtSwitch20 = new System.Windows.Forms.TextBox();
            this.txtIf20 = new System.Windows.Forms.TextBox();
            this.txtSwitch30 = new System.Windows.Forms.TextBox();
            this.txtIf30 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtDiff30 = new System.Windows.Forms.TextBox();
            this.txtDiff20 = new System.Windows.Forms.TextBox();
            this.txtDiff10 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtDiff50 = new System.Windows.Forms.TextBox();
            this.txtDiff40 = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.txtSwitch50 = new System.Windows.Forms.TextBox();
            this.txtIf50 = new System.Windows.Forms.TextBox();
            this.txtSwitch40 = new System.Windows.Forms.TextBox();
            this.txtIf40 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 17);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(45, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "# Trials:";
            // 
            // numTrialsTextBox
            // 
            this.numTrialsTextBox.Location = new System.Drawing.Point(76, 14);
            this.numTrialsTextBox.Name = "numTrialsTextBox";
            this.numTrialsTextBox.Size = new System.Drawing.Size(100, 20);
            this.numTrialsTextBox.TabIndex = 1;
            this.numTrialsTextBox.Text = "10,000,000";
            this.numTrialsTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // goButton
            // 
            this.goButton.Location = new System.Drawing.Point(182, 12);
            this.goButton.Name = "goButton";
            this.goButton.Size = new System.Drawing.Size(75, 23);
            this.goButton.TabIndex = 2;
            this.goButton.Text = "Go";
            this.goButton.UseVisualStyleBackColor = true;
            this.goButton.Click += new System.EventHandler(this.goButton_Click);
            // 
            // txtIf10
            // 
            this.txtIf10.Location = new System.Drawing.Point(76, 69);
            this.txtIf10.Name = "txtIf10";
            this.txtIf10.ReadOnly = true;
            this.txtIf10.Size = new System.Drawing.Size(100, 20);
            this.txtIf10.TabIndex = 4;
            this.txtIf10.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 72);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(37, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "if-else:";
            // 
            // txtSwitch10
            // 
            this.txtSwitch10.Location = new System.Drawing.Point(76, 95);
            this.txtSwitch10.Name = "txtSwitch10";
            this.txtSwitch10.ReadOnly = true;
            this.txtSwitch10.Size = new System.Drawing.Size(100, 20);
            this.txtSwitch10.TabIndex = 6;
            this.txtSwitch10.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 98);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(40, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "switch:";
            // 
            // txtSwitch20
            // 
            this.txtSwitch20.Location = new System.Drawing.Point(182, 95);
            this.txtSwitch20.Name = "txtSwitch20";
            this.txtSwitch20.ReadOnly = true;
            this.txtSwitch20.Size = new System.Drawing.Size(100, 20);
            this.txtSwitch20.TabIndex = 8;
            this.txtSwitch20.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtIf20
            // 
            this.txtIf20.Location = new System.Drawing.Point(182, 69);
            this.txtIf20.Name = "txtIf20";
            this.txtIf20.ReadOnly = true;
            this.txtIf20.Size = new System.Drawing.Size(100, 20);
            this.txtIf20.TabIndex = 7;
            this.txtIf20.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtSwitch30
            // 
            this.txtSwitch30.Location = new System.Drawing.Point(288, 95);
            this.txtSwitch30.Name = "txtSwitch30";
            this.txtSwitch30.ReadOnly = true;
            this.txtSwitch30.Size = new System.Drawing.Size(100, 20);
            this.txtSwitch30.TabIndex = 10;
            this.txtSwitch30.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtIf30
            // 
            this.txtIf30.Location = new System.Drawing.Point(288, 69);
            this.txtIf30.Name = "txtIf30";
            this.txtIf30.ReadOnly = true;
            this.txtIf30.Size = new System.Drawing.Size(100, 20);
            this.txtIf30.TabIndex = 9;
            this.txtIf30.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(76, 49);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(100, 17);
            this.label4.TabIndex = 11;
            this.label4.Text = "10 Values";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label5
            // 
            this.label5.Location = new System.Drawing.Point(182, 49);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(100, 17);
            this.label5.TabIndex = 12;
            this.label5.Text = "20 Values";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label6
            // 
            this.label6.Location = new System.Drawing.Point(288, 49);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(100, 17);
            this.label6.TabIndex = 13;
            this.label6.Text = "30 Values";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtDiff30
            // 
            this.txtDiff30.Location = new System.Drawing.Point(288, 121);
            this.txtDiff30.Name = "txtDiff30";
            this.txtDiff30.ReadOnly = true;
            this.txtDiff30.Size = new System.Drawing.Size(100, 20);
            this.txtDiff30.TabIndex = 17;
            this.txtDiff30.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtDiff20
            // 
            this.txtDiff20.Location = new System.Drawing.Point(182, 121);
            this.txtDiff20.Name = "txtDiff20";
            this.txtDiff20.ReadOnly = true;
            this.txtDiff20.Size = new System.Drawing.Size(100, 20);
            this.txtDiff20.TabIndex = 16;
            this.txtDiff20.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtDiff10
            // 
            this.txtDiff10.Location = new System.Drawing.Point(76, 121);
            this.txtDiff10.Name = "txtDiff10";
            this.txtDiff10.ReadOnly = true;
            this.txtDiff10.Size = new System.Drawing.Size(100, 20);
            this.txtDiff10.TabIndex = 15;
            this.txtDiff10.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(12, 124);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(37, 13);
            this.label7.TabIndex = 14;
            this.label7.Text = "% Diff:";
            // 
            // txtDiff50
            // 
            this.txtDiff50.Location = new System.Drawing.Point(500, 121);
            this.txtDiff50.Name = "txtDiff50";
            this.txtDiff50.ReadOnly = true;
            this.txtDiff50.Size = new System.Drawing.Size(100, 20);
            this.txtDiff50.TabIndex = 25;
            this.txtDiff50.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtDiff40
            // 
            this.txtDiff40.Location = new System.Drawing.Point(394, 121);
            this.txtDiff40.Name = "txtDiff40";
            this.txtDiff40.ReadOnly = true;
            this.txtDiff40.Size = new System.Drawing.Size(100, 20);
            this.txtDiff40.TabIndex = 24;
            this.txtDiff40.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label8
            // 
            this.label8.Location = new System.Drawing.Point(500, 49);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(100, 17);
            this.label8.TabIndex = 23;
            this.label8.Text = "50 Values";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label9
            // 
            this.label9.Location = new System.Drawing.Point(394, 49);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(100, 17);
            this.label9.TabIndex = 22;
            this.label9.Text = "40 Values";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtSwitch50
            // 
            this.txtSwitch50.Location = new System.Drawing.Point(500, 95);
            this.txtSwitch50.Name = "txtSwitch50";
            this.txtSwitch50.ReadOnly = true;
            this.txtSwitch50.Size = new System.Drawing.Size(100, 20);
            this.txtSwitch50.TabIndex = 21;
            this.txtSwitch50.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtIf50
            // 
            this.txtIf50.Location = new System.Drawing.Point(500, 69);
            this.txtIf50.Name = "txtIf50";
            this.txtIf50.ReadOnly = true;
            this.txtIf50.Size = new System.Drawing.Size(100, 20);
            this.txtIf50.TabIndex = 20;
            this.txtIf50.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtSwitch40
            // 
            this.txtSwitch40.Location = new System.Drawing.Point(394, 95);
            this.txtSwitch40.Name = "txtSwitch40";
            this.txtSwitch40.ReadOnly = true;
            this.txtSwitch40.Size = new System.Drawing.Size(100, 20);
            this.txtSwitch40.TabIndex = 19;
            this.txtSwitch40.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtIf40
            // 
            this.txtIf40.Location = new System.Drawing.Point(394, 69);
            this.txtIf40.Name = "txtIf40";
            this.txtIf40.ReadOnly = true;
            this.txtIf40.Size = new System.Drawing.Size(100, 20);
            this.txtIf40.TabIndex = 18;
            this.txtIf40.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Form1
            // 
            this.AcceptButton = this.goButton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(612, 154);
            this.Controls.Add(this.txtDiff50);
            this.Controls.Add(this.txtDiff40);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.txtSwitch50);
            this.Controls.Add(this.txtIf50);
            this.Controls.Add(this.txtSwitch40);
            this.Controls.Add(this.txtIf40);
            this.Controls.Add(this.txtDiff30);
            this.Controls.Add(this.txtDiff20);
            this.Controls.Add(this.txtDiff10);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtSwitch30);
            this.Controls.Add(this.txtIf30);
            this.Controls.Add(this.txtSwitch20);
            this.Controls.Add(this.txtIf20);
            this.Controls.Add(this.txtSwitch10);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtIf10);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.goButton);
            this.Controls.Add(this.numTrialsTextBox);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "howto_time_long_switch";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox numTrialsTextBox;
        private System.Windows.Forms.Button goButton;
        private System.Windows.Forms.TextBox txtIf10;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtSwitch10;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtSwitch20;
        private System.Windows.Forms.TextBox txtIf20;
        private System.Windows.Forms.TextBox txtSwitch30;
        private System.Windows.Forms.TextBox txtIf30;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtDiff30;
        private System.Windows.Forms.TextBox txtDiff20;
        private System.Windows.Forms.TextBox txtDiff10;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtDiff50;
        private System.Windows.Forms.TextBox txtDiff40;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtSwitch50;
        private System.Windows.Forms.TextBox txtIf50;
        private System.Windows.Forms.TextBox txtSwitch40;
        private System.Windows.Forms.TextBox txtIf40;
    }
}


﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Globalization;
using System.Diagnostics;

namespace howto_time_long_switch
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void goButton_Click(object sender, EventArgs e)
        {
            foreach (Control ctl in Controls)
            {
                if ((ctl is TextBox) && (ctl != numTrialsTextBox))
                    ctl.Text = "";
            }
            Cursor = Cursors.WaitCursor;
            Refresh();

            int num_trials = int.Parse(numTrialsTextBox.Text, NumberStyles.Any);
            RunTrials(10, num_trials, txtIf10, txtSwitch10, txtDiff10);
            RunTrials(20, num_trials, txtIf20, txtSwitch20, txtDiff20);
            RunTrials(30, num_trials, txtIf30, txtSwitch30, txtDiff30);
            RunTrials(40, num_trials, txtIf40, txtSwitch40, txtDiff40);
            RunTrials(50, num_trials, txtIf50, txtSwitch50, txtDiff50);

            Cursor = Cursors.Default;
        }

        // Run trials with a given number of values.
        Stopwatch Watch = new Stopwatch();
        Random Rand = new Random();
        private void RunTrials(int num_values, int num_trials, TextBox txtIf, TextBox txtSwitch, TextBox txtDiff)
        {
            Stopwatch watch = new Stopwatch();

            // if-then-else.
            Watch.Reset();
            Watch.Start();
            for (int trial = 0; trial < num_trials; trial++)
            {
                int result = -1;
                int value = Rand.Next(0, num_values);
                if (value == 0) result = 0;
                else if (value == 1) result = 1;
                else if (value == 2) result = 2;
                else if (value == 3) result = 3;
                else if (value == 4) result = 4;
                else if (value == 5) result = 5;
                else if (value == 6) result = 6;
                else if (value == 7) result = 7;
                else if (value == 8) result = 8;
                else if (value == 9) result = 9;
                else if (value == 10) result = 10;
                else if (value == 11) result = 11;
                else if (value == 12) result = 12;
                else if (value == 13) result = 13;
                else if (value == 14) result = 14;
                else if (value == 15) result = 15;
                else if (value == 16) result = 16;
                else if (value == 17) result = 17;
                else if (value == 18) result = 18;
                else if (value == 19) result = 19;
                else if (value == 20) result = 20;
                else if (value == 21) result = 21;
                else if (value == 22) result = 22;
                else if (value == 23) result = 23;
                else if (value == 24) result = 24;
                else if (value == 25) result = 25;
                else if (value == 26) result = 26;
                else if (value == 27) result = 27;
                else if (value == 28) result = 28;
                else if (value == 29) result = 29;
                else if (value == 30) result = 30;
                else if (value == 31) result = 31;
                else if (value == 32) result = 32;
                else if (value == 33) result = 33;
                else if (value == 34) result = 34;
                else if (value == 35) result = 35;
                else if (value == 36) result = 36;
                else if (value == 37) result = 37;
                else if (value == 38) result = 38;
                else if (value == 39) result = 39;
                else if (value == 40) result = 40;
                else if (value == 41) result = 41;
                else if (value == 42) result = 42;
                else if (value == 43) result = 43;
                else if (value == 44) result = 44;
                else if (value == 45) result = 45;
                else if (value == 46) result = 46;
                else if (value == 47) result = 47;
                else if (value == 48) result = 48;
                else if (value == 49) result = 49;
                value = result;
            }
            Watch.Stop();
            double if_seconds = Watch.Elapsed.TotalSeconds;
            txtIf.Text = if_seconds.ToString("0.0000");
            txtIf.Refresh();

            // if-then-else.
            Watch.Reset();
            Watch.Start();
            for (int trial = 0; trial < num_trials; trial++)
            {
                int result = -1;
                int value = Rand.Next(0, num_values);
                switch (value)
                {
                    case 0: result = 0; break;
                    case 1: result = 1; break;
                    case 2: result = 2; break;
                    case 3: result = 3; break;
                    case 4: result = 4; break;
                    case 5: result = 5; break;
                    case 6: result = 6; break;
                    case 7: result = 7; break;
                    case 8: result = 8; break;
                    case 9: result = 9; break;
                    case 10: result = 10; break;
                    case 11: result = 11; break;
                    case 12: result = 12; break;
                    case 13: result = 13; break;
                    case 14: result = 14; break;
                    case 15: result = 15; break;
                    case 16: result = 16; break;
                    case 17: result = 17; break;
                    case 18: result = 18; break;
                    case 19: result = 19; break;
                    case 20: result = 20; break;
                    case 21: result = 21; break;
                    case 22: result = 22; break;
                    case 23: result = 23; break;
                    case 24: result = 24; break;
                    case 25: result = 25; break;
                    case 26: result = 26; break;
                    case 27: result = 27; break;
                    case 28: result = 28; break;
                    case 29: result = 29; break;
                    case 30: result = 30; break;
                    case 31: result = 31; break;
                    case 32: result = 32; break;
                    case 33: result = 33; break;
                    case 34: result = 34; break;
                    case 35: result = 35; break;
                    case 36: result = 36; break;
                    case 37: result = 37; break;
                    case 38: result = 38; break;
                    case 39: result = 39; break;
                    case 40: result = 40; break;
                    case 41: result = 41; break;
                    case 42: result = 42; break;
                    case 43: result = 43; break;
                    case 44: result = 44; break;
                    case 45: result = 45; break;
                    case 46: result = 46; break;
                    case 47: result = 47; break;
                    case 48: result = 48; break;
                    case 49: result = 49; break;
                }
                value = result;
            }
            Watch.Stop();
            double switch_seconds = Watch.Elapsed.TotalSeconds;
            txtSwitch.Text = switch_seconds.ToString("0.0000");
            txtSwitch.Refresh();

            double diff = 100.0 * (if_seconds - switch_seconds) / if_seconds;
            txtDiff.Text = diff.ToString("0.0000");
            txtDiff.Refresh();
        }
    }
}

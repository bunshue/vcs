﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Drawing.Imaging;

namespace howto_watermark_image2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Bitmap result_bm = new Bitmap(picImage.Image);

            using (Bitmap watermark_bm = new Bitmap(picWatermark.Image))
            {
                int x = (result_bm.Width - watermark_bm.Width) / 2;
                int y = (result_bm.Height - watermark_bm.Height) / 2;
                DrawWatermark(watermark_bm, result_bm, x, y);
            }

            picImage.Image = result_bm;
        }

        // Copy the watermark image over the result image.
        private void DrawWatermark(Bitmap watermark_bm, Bitmap result_bm, int x, int y)
        {
            // Make a ColorMatrix that multiplies
            // the alpha component by 0.5.
            ColorMatrix color_matrix = new ColorMatrix();
            color_matrix.Matrix33 = 0.5f;

            // Make an ImageAttributes that uses the ColorMatrix.
            ImageAttributes image_attributes = new ImageAttributes();
            image_attributes.SetColorMatrices(color_matrix, null);

            // Make pixels that are the same color as the
            // one in the upper left transparent.
            watermark_bm.MakeTransparent(watermark_bm.GetPixel(0, 0));

            // Draw the image using the ColorMatrix.
            using (Graphics gr = Graphics.FromImage(result_bm))
            {
                Rectangle rect = new Rectangle(x, y, watermark_bm.Width, watermark_bm.Height);
                gr.DrawImage(watermark_bm, rect, 0, 0,
                    watermark_bm.Width, watermark_bm.Height,
                    GraphicsUnit.Pixel, image_attributes);
            }
        }
    }
}

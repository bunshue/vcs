﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_show_system_icons
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Draw samples.
        private const int column_width = 150;
        private const int row_height = 50;
        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            int x = 10;
            int y = 10;
            DrawIconSample(e.Graphics, ref x, y, SystemIcons.Application, "Application");
            DrawIconSample(e.Graphics, ref x, y, SystemIcons.Asterisk, "Asterisk");
            DrawIconSample(e.Graphics, ref x, y, SystemIcons.Error, "Error");
            x = 10;
            y += 50;
            DrawIconSample(e.Graphics, ref x, y, SystemIcons.Exclamation, "Exclamation");
            DrawIconSample(e.Graphics, ref x, y, SystemIcons.Hand, "Hand");
            DrawIconSample(e.Graphics, ref x, y, SystemIcons.Information, "Information");
            x = 10;
            y += row_height;
            DrawIconSample(e.Graphics, ref x, y, SystemIcons.Question, "Question");
            DrawIconSample(e.Graphics, ref x, y, SystemIcons.Shield, "Shield");
            DrawIconSample(e.Graphics, ref x, y, SystemIcons.Warning, "Warning");
            x = 10;
            y += 50;
            DrawIconSample(e.Graphics, ref x, y, SystemIcons.WinLogo, "WinLogo");

            this.ClientSize = new Size(3 * column_width, 4 * row_height);
        }

        // Draw a sample and its name.
        private void DrawIconSample(Graphics gr, ref int x, int y, Icon ico, string ico_name)
        {
            gr.DrawIconUnstretched(ico, new Rectangle(x, y, ico.Width, ico.Height));
            int text_y = y + (int)(ico.Height - gr.MeasureString(ico_name, this.Font).Height) / 2;
            gr.DrawString(ico_name, this.Font, Brushes.Black, x + ico.Width + 5, text_y);
            x += column_width;
        }
    }
}

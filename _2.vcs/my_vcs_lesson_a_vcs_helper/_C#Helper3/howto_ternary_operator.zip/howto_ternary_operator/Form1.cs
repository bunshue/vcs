﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_ternary_operator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Display a greeting.
        private void Form1_Load(object sender, EventArgs e)
        {
            lblGreeting.Text = (DateTime.Now.Hour < 12) ? "Good morning" : "Good afternoon";

            // Equivalent without the conditional operator:
            //if (DateTime.Now.Hour < 12)
            //    lblGreeting.Text = "Good morning";
            //else
            //    lblGreeting.Text = "Good afternoon";
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.IO;

namespace howto_read_write_text_file
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Initialize the File TextBox.
        private void Form1_Load(object sender, EventArgs e)
        {
            txtFile.Text=Application.StartupPath + "\\data.txt";
        }

        // Write the text values into the file.
        private void btnWrite_Click(object sender, EventArgs e)
        {
            StreamWriter stream_writer = new StreamWriter(txtFile.Text);
            stream_writer.WriteLine(txtName.Text);
            stream_writer.WriteLine(txtStreet.Text);
            stream_writer.WriteLine(txtCity.Text);
            stream_writer.WriteLine(txtState.Text);
            stream_writer.WriteLine(txtZip.Text);
            stream_writer.Close();  // Don't forget to close the file!

            // Clear the TextBoxes.
            txtName.Clear();
            txtStreet.Clear();
            txtCity.Clear();
            txtState.Clear();
            txtZip.Clear();
        }

        // Read the values back into the TextBoxes.
        private void btnRead_Click(object sender, EventArgs e)
        {
            StreamReader stream_reader = new StreamReader(txtFile.Text);

            txtName.Text = stream_reader.ReadLine();
            txtStreet.Text = stream_reader.ReadLine();
            txtCity.Text = stream_reader.ReadLine();
            txtState.Text = stream_reader.ReadLine();
            txtZip.Text = stream_reader.ReadLine();
            stream_reader.Close();
        }
    }
}

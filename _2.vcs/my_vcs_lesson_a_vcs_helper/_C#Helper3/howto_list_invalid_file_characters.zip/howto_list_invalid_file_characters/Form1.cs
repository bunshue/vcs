﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.IO;

namespace howto_list_invalid_file_characters
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string txt = "";
            foreach (char ch in Path.GetInvalidFileNameChars())
            {
                if (Char.IsWhiteSpace(ch) || Char.IsControl(ch))
                    txt += "<" + (int)ch + "> ";
                else
                    txt += ch + " ";
            }
            txtInvalidFileNameChars.Text = txt;

            txt = "";
            foreach (char ch in Path.GetInvalidPathChars())
            {
                if (Char.IsWhiteSpace(ch) || Char.IsControl(ch))
                    txt += "<" + (int)ch + "> ";
                else
                    txt += ch + " ";
            }
            txtInvalidPathChars.Text = txt;

            txtInvalidFileNameChars.Select(0, 0);
            txtInvalidPathChars.Select(0, 0);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Text.RegularExpressions;

namespace howto_calculate_earth_distances
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Some test values:
        //     Mumbai to Canberra           6238.51
        //     Beijing to Berlin            4667.81
        //     San Diego to Los Angeles      111.57
        //     San Diego to San Francisco    458.17
        //     Los Angeles to San Francisco  347.16

        // Locations of known cities.
        private CityData[] Cities =
        {
            new CityData("Rome 	41°48′N 12°36′E"),
            new CityData("Tokyo 	35°40′N 139°45′E"),
            new CityData("Mexico City 	19°24′N 99°09′W"),
            new CityData("London 	51°30′N 0°10′W"),
            new CityData("New York City 	40°43′N 74°00′W"),
            new CityData("Los Angeles 	34°03′N 118°15′W"),
            new CityData("Canberra 	35°17′S 149°08′E"),
            new CityData("Berlin 	52°32′N 13°25′E"),
            new CityData("Rome 	41°48′N 12°36′E"),
            new CityData("Cairo 	30°03′N 31°15′E"),
            new CityData("Beijing 	39°55′N 116°26′E"),
            new CityData("Moscow 	55°45′N 37°42′E"),
            new CityData("Rio de Janeiro 	22°54′S 43°14′W"),
            new CityData("Mumbai 	18°56′N 74°35′E"),
            new CityData("San Diego 	32°42′N 117°10′W"),
            new CityData("San Francisco 	37°47′N 122°26′W"),
        };

        // Load the list of cities.
        private void Form1_Load(object sender, EventArgs e)
        {
            var city_query =
                from CityData city_data in Cities
                orderby city_data.Name
                select city_data.Name;
            cboCityFrom.DataSource = city_query.ToArray();
            cboCityTo.DataSource = city_query.ToArray();
            cboCityTo.SelectedIndex = 1;
        }

        // Display the latitude and longitude for the selected city.
        private void cboCity_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Find the selected city.
            var city_query =
                from CityData city_data in Cities
                where (city_data.Name == cboCityFrom.Text)
                select city_data;

            // Display the latitude and longitude.
            CityData city = city_query.First();
            txtLatitudeFrom.Text = city.Latitude.ToString("0.0000");
            txtLongitudeFrom.Text = city.Longitude.ToString("0.0000");
        }
        private void cboCityTo_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Find the selected city.
            var city_query =
                from CityData city_data in Cities
                where (city_data.Name == cboCityTo.Text)
                select city_data;

            // Display the latitude and longitude.
            CityData city = city_query.First();
            txtLatitudeTo.Text = city.Latitude.ToString("0.0000");
            txtLongitudeTo.Text = city.Longitude.ToString("0.0000");
        }

        // Calculate the distances.
        private void btnCalculate_Click(object sender, EventArgs e)
        {
            // Get the entered latitudes and longitudes.
            double lat_from = double.Parse(txtLatitudeFrom.Text);
            if (lat_from < 0) lat_from += 360;

            double lon_from = double.Parse(txtLongitudeFrom.Text);
            if (lon_from < 0) lon_from += 360;

            double lat_to = double.Parse(txtLatitudeTo.Text);
            if (lat_to < 0) lat_to += 360;

            double lon_to = double.Parse(txtLongitudeTo.Text);
            if (lon_to < 0) lon_to += 360;

            // Calculate the differences in latitude and longitude.
            double dlat = Math.Abs(lat_from - lat_to);
            if (dlat > 180) dlat = 360 - dlat;

            double dlon = Math.Abs(lon_from - lon_to);
            if (dlon > 180) dlon = 360 - dlon;

            // Flat Earth.
            txtMethod1.Text = FlatEarth(lat_from, lon_from,
                lat_to, lon_to).ToString("0.0000");

            // Haversine.
            txtMethod2.Text = Haversine(lat_from, lon_from,
                lat_to, lon_to).ToString("0.0000");
        }

        // Methods for calculating distances.
        private const double EarthRadius = 3958.756;
        private double FlatEarth(double lat1, double lon1, double lat2, double lon2)
        {
            // Calculate the differences in latitude and longitude.
            double dlat = Math.Abs(lat1 - lat2);
            if (dlat > 180) dlat = 360 - dlat;

            double dlon = Math.Abs(lon1 - lon2);
            if (dlon > 180) dlon = 360 - dlon;

            double x = 69.1 * dlat;
            double y = 53.0 * dlon;
            return Math.Sqrt(x * x + y * y);
        }

        private double Haversine(double lat1, double lon1, double lat2, double lon2)
        {
            double dlat = DegreesToRadians(lat2 - lat1);
            double dlon = DegreesToRadians(lon2 - lon1);
            double a = Math.Sin(dlat / 2) * Math.Sin(dlat / 2) +
                Math.Cos(DegreesToRadians(lat1)) *
                Math.Cos(DegreesToRadians(lat2)) *
                Math.Sin(dlon / 2) * Math.Sin(dlon / 2);
            return 2 * Math.Atan2(Math.Sqrt(a), Math.Sqrt(1 - a)) * EarthRadius;
        }

        // Convert degrees into radians.
        private double DegreesToRadians(double degrees)
        {
            return degrees / 180 * Math.PI;
        }
    }
}

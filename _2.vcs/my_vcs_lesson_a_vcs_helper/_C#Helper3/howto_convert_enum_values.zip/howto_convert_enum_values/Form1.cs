﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_convert_enum_values
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // The enumerated type.
        private enum MealType
        {
            Breakfast,
            Brunch,
            Lunch,
            Luncheon = Lunch,
            Tiffin = Lunch,
            Tea,
            Nuncheon = Tea,
            Dinner,
            Supper
        }

        // Convert values to and from strings.
        private void Form1_Load(object sender, EventArgs e)
        {
            foreach (string value in Enum.GetNames(typeof(MealType)))
            {
                // Get the enumeration's value.
                MealType meal = (MealType)Enum.Parse(typeof(MealType), value);

                // Display the values.
                lstStringValues.Items.Add((int)meal + "\t" + value);
            }
        }
    }
}

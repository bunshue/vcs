﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Drawing.Drawing2D;
using System.Drawing.Text;

namespace howto_color_wheel_dialog
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // The selected colors.
        private Color Color1 = Color.FromArgb(128, 255, 0, 0);
        private Color Color2 = Color.FromArgb(128, 0, 0, 255);

        // Set color 1.
        private void btnColor1_Click(object sender, EventArgs e)
        {
            ColorWheelDialog dlg = new ColorWheelDialog();
            dlg.SelectedColor = Color1;
            if (dlg.ShowDialog() == DialogResult.OK)
                Color1 = dlg.SelectedColor;

            picSample.Refresh();
        }

        // Set color 2.
        private void btnColor2_Click(object sender, EventArgs e)
        {
            ColorWheelDialog dlg = new ColorWheelDialog();
            dlg.SelectedColor = Color2;
            if (dlg.ShowDialog() == DialogResult.OK)
                Color2 = dlg.SelectedColor;

            picSample.Refresh();
        }

        // Draw a sample to show the alpha component.
        private void picSample_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.Clear(Color.White);

            // Draw some lines.
            int wid = picSample.ClientSize.Width;
            int hgt = picSample.ClientSize.Height;
            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
            using (Pen pen = new Pen(Color.Black, 3))
            {
                for (int x = 10; x <= wid; x += 20)
                    e.Graphics.DrawLine(pen, x, 0, x, hgt);
                for (int y = 10; y <= hgt; y += 20)
                    e.Graphics.DrawLine(pen, 0, y, wid, y);
            }

            // Draw an ellipse.
            int third = picSample.ClientSize.Width / 3;
            using (Brush brush = new SolidBrush(Color1))
            {
                e.Graphics.FillEllipse(brush, 0, 0, 2 * third, hgt);
            }
            using (Brush brush = new SolidBrush(Color2))
            {
                e.Graphics.FillEllipse(brush, third, 0, 2 * third, hgt);
            }
        }

        private void picSample_Resize(object sender, EventArgs e)
        {
            picSample.Refresh();
        }
    }
}

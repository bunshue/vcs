﻿namespace howto_color_wheel_dialog
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnColor1 = new System.Windows.Forms.Button();
            this.btnColor2 = new System.Windows.Forms.Button();
            this.picSample = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.picSample)).BeginInit();
            this.SuspendLayout();
            // 
            // btnColor1
            // 
            this.btnColor1.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.btnColor1.ForeColor = System.Drawing.Color.Black;
            this.btnColor1.Location = new System.Drawing.Point(12, 30);
            this.btnColor1.Name = "btnColor1";
            this.btnColor1.Size = new System.Drawing.Size(91, 37);
            this.btnColor1.TabIndex = 0;
            this.btnColor1.Text = "Select Color 1";
            this.btnColor1.UseVisualStyleBackColor = true;
            this.btnColor1.Click += new System.EventHandler(this.btnColor1_Click);
            // 
            // btnColor2
            // 
            this.btnColor2.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.btnColor2.ForeColor = System.Drawing.Color.Black;
            this.btnColor2.Location = new System.Drawing.Point(12, 73);
            this.btnColor2.Name = "btnColor2";
            this.btnColor2.Size = new System.Drawing.Size(91, 37);
            this.btnColor2.TabIndex = 1;
            this.btnColor2.Text = "Select Color 2";
            this.btnColor2.UseVisualStyleBackColor = true;
            this.btnColor2.Click += new System.EventHandler(this.btnColor2_Click);
            // 
            // picSample
            // 
            this.picSample.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.picSample.Location = new System.Drawing.Point(109, 12);
            this.picSample.Name = "picSample";
            this.picSample.Size = new System.Drawing.Size(183, 116);
            this.picSample.TabIndex = 2;
            this.picSample.TabStop = false;
            this.picSample.Resize += new System.EventHandler(this.picSample_Resize);
            this.picSample.Paint += new System.Windows.Forms.PaintEventHandler(this.picSample_Paint);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(304, 141);
            this.Controls.Add(this.picSample);
            this.Controls.Add(this.btnColor2);
            this.Controls.Add(this.btnColor1);
            this.Name = "Form1";
            this.Text = "howto_color_wheel_dialog";
            ((System.ComponentModel.ISupportInitialize)(this.picSample)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnColor1;
        private System.Windows.Forms.Button btnColor2;
        private System.Windows.Forms.PictureBox picSample;
    }
}


﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_show_uac_shields
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // Add the shield to a button.
            UacStuff.AddShieldToButton(btnClickMe);

            // Add the shield to a menu item.
            mnuFileFormatHardDrive.ImageScaling = ToolStripItemImageScaling.None;
            mnuFileFormatHardDrive.Image = UacStuff.GetUacShieldImage();

            // Add the shield to a PictureBox and
            // move a LinkLabel next to it.
            picShield.Image = UacStuff.GetUacShieldImage();
            int y = ClientSize.Height - 8 - picShield.Height;
            llblDangerous.Location = new Point(
                btnClickMe.Right - llblDangerous.Width, y);
            picShield.Location = new Point(
                llblDangerous.Left - picShield.Width, y);
        }

        private void mnuFileExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void JustKidding(object sender, EventArgs e)
        {
            MessageBox.Show("Just kidding!", "Just Kidding", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Diagnostics;

namespace howto_time_checked
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnGo_Click(object sender, EventArgs e)
        {
            txtChecked.Clear();
            txtUnchecked.Clear();
            Cursor = Cursors.WaitCursor;
            Refresh();

            int num_trials = int.Parse(txtNumTrials.Text);
            Stopwatch watch = new Stopwatch();

            watch.Start();
            checked
            {
                for (int i = 0; i < num_trials; i++)
                {
                    for (int j = 0; j < 1000; j++)
                    {
                        int k = i - j;
                    }
                }
            }
            watch.Stop();
            txtChecked.Text =
                watch.Elapsed.TotalSeconds.ToString("0.00") +
                " seconds";
            txtChecked.Refresh();

            watch.Reset();
            watch.Start();
            unchecked
            {
                for (int i = 0; i < num_trials; i++)
                {
                    for (int j = 0; j < 1000; j++)
                    {
                        int k = i - j;
                    }
                }
            }
            watch.Stop();
            txtUnchecked.Text =
                watch.Elapsed.TotalSeconds.ToString("0.00") +
                " seconds";

            Cursor = Cursors.Default;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_bind_listbox
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Display data in the ListBoxes.
        private void Form1_Load(object sender, EventArgs e)
        {
            string[] animal_array = { "ape", "bear", "cat", "dolphin", "eagle", "fox", "giraffe" };
            List<string> animal_list = new List<string>(animal_array);

            lstArray.DataSource = animal_array;
            lstList.DataSource = animal_list;
        }
    }
}

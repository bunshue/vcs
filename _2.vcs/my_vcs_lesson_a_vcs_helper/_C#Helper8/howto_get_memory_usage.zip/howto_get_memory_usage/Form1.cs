﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Diagnostics;

namespace howto_get_memory_usage
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Display information about the current process's memory usage.
        private void Form1_Load(object sender, EventArgs e)
        {
            Process proc = Process.GetCurrentProcess();
            AddItem(lvMemory, "Min Working Set", ((double)proc.MinWorkingSet).ToFileSize());
            AddItem(lvMemory, "Max Working Set", ((double)proc.MaxWorkingSet).ToFileSize());
            AddItem(lvMemory, "Non-paged Memory Size", ((double)proc.NonpagedSystemMemorySize64).ToFileSize());
            AddItem(lvMemory, "Paged Memory Size", ((double)proc.PagedMemorySize64).ToFileSize());
            AddItem(lvMemory, "Paged System Memory Size", ((double)proc.PagedSystemMemorySize64).ToFileSize());
            AddItem(lvMemory, "Peak Paged Memory Size", ((double)proc.PeakPagedMemorySize64).ToFileSize());
            AddItem(lvMemory, "Peak Virtual Memory Size", ((double)proc.PeakVirtualMemorySize64).ToFileSize());
            AddItem(lvMemory, "Peak Working Set", ((double)proc.PeakWorkingSet64).ToFileSize());
            AddItem(lvMemory, "Virtual Memory Size", ((double)proc.VirtualMemorySize64).ToFileSize());
            AddItem(lvMemory, "Working Set", ((double)proc.WorkingSet64).ToFileSize());

            lvMemory.Columns[0].AutoResize(ColumnHeaderAutoResizeStyle.ColumnContent);
            lvMemory.Columns[1].AutoResize(ColumnHeaderAutoResizeStyle.ColumnContent);
        }

        // Add an item to the ListView.
        private void AddItem(ListView lv, string item_name, string item_value)
        {
            ListViewItem lv_item = lv.Items.Add(item_name);
            lv_item.SubItems.Add(item_value);
        }
    }
}

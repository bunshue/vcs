﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Drawing.Drawing2D;

namespace howto_shaped_button
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnClickMe_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Clicked!");
        }

        // Shape the button.
        private void Form1_Load(object sender, EventArgs e)
        {
            // Define the points in the polygonal path.
            Point[] pts = {
                new Point( 20,  60),
                new Point(140,  60),
                new Point(140,  20),
                new Point(220, 100),
                new Point(140, 180),
                new Point(140, 140),
                new Point( 20, 140)
            };

            // Make the GraphicsPath.
            GraphicsPath polygon_path = new GraphicsPath(FillMode.Winding);
            polygon_path.AddPolygon(pts);

            // Convert the GraphicsPath into a Region.
            Region polygon_region = new Region(polygon_path);

            // Constrain the button to the region.
            btnClickMe.Region = polygon_region;

            // Make the button big enough to hold the whole region.
            btnClickMe.SetBounds(
                btnClickMe.Location.X,
                btnClickMe.Location.Y,
                pts[3].X + 5, pts[4].Y + 5);
        }
    }
}

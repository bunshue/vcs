﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.IO;

namespace howto_search_files
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // If we launched from the Send To menu,
        // use the argument as our directory.
        private void Form1_Load(object sender, EventArgs e)
        {
            if (System.Environment.GetCommandLineArgs().Length > 1)
            {
                txtDirectory.Text = System.Environment.GetCommandLineArgs()[1];
                txtTarget.Focus();
            }
        }

        // Search.
        private void btnSearch_Click(object sender, EventArgs e)
        {
            lstResults.Items.Clear();
            DirectoryInfo dir_info = new DirectoryInfo(txtDirectory.Text);

            ListFiles(lstResults, cboPattern.Text, dir_info, txtTarget.Text);

            System.Media.SystemSounds.Beep.Play();
        }

        // Add the files in this directory's subtree 
        // that match the pattern to the ListBox.
        private void ListFiles(ListBox lst, string pattern, DirectoryInfo dir_info, string target)
        {
            // Get the files in this directory.
            FileInfo[] fs_infos = dir_info.GetFiles(pattern);
            foreach (FileInfo fs_info in fs_infos)
            {
                if (target.Length == 0)
                {
                    lstResults.Items.Add(fs_info.FullName);
                } 
                else
                {
                    string txt = File.ReadAllText(fs_info.FullName);
                    if (txt.IndexOf(target, StringComparison.OrdinalIgnoreCase) >= 0)
                    {
                        lstResults.Items.Add(fs_info.FullName);
                    }
                }
            }

            // Search subdirectories.
            DirectoryInfo[] subdirs = dir_info.GetDirectories();
            foreach (DirectoryInfo subdir in subdirs)
            {
                ListFiles(lst, pattern, subdir, target);
            }
        }
    }
}

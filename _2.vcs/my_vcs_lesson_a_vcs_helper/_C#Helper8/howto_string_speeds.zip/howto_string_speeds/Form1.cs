﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Diagnostics;

namespace howto_string_speeds
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnGo_Click(object sender, EventArgs e)
        {
            txtStringBuilder.Clear();
            txtConcat.Clear();
            txtPlus.Clear();
            this.Cursor = Cursors.WaitCursor;

            Stopwatch watch = new Stopwatch();
            long num_appends = long.Parse(txtNumAppends.Text);
            long num_trials = long.Parse(txtNumTrials.Text);
            string result;

            // StringBuilder.
            watch.Start();
            for (long trial = 1; trial <= num_trials; trial++)
            {
                StringBuilder sb = new StringBuilder();
                for (long i = 1; i <= num_appends; i++)
                    sb.Append("0123456789");
                result = sb.ToString();
            }
            watch.Stop();
            txtStringBuilder.Text = string.Format("{0:0.00} μ sec",
                watch.Elapsed.TotalSeconds * 1000000 / num_trials);

            // String.Append.
            watch.Reset();
            watch.Start();
            for (long trial = 1; trial <= num_trials; trial++)
            {
                result = "";
                for (long i = 1; i <= num_appends; i++)
                    result = string.Concat(result, "0123456789");
            }
            watch.Stop();
            txtConcat.Text = string.Format("{0:0.00} μ sec",
                watch.Elapsed.TotalSeconds * 1000000 / num_trials);

            // +=.
            watch.Reset();
            watch.Start();
            for (long trial = 1; trial <= num_trials; trial++)
            {
                result = "";
                for (long i = 1; i <= num_appends; i++)
                    result += "0123456789";
            }
            watch.Stop();
            txtPlus.Text = string.Format("{0:0.00} μ sec",
                watch.Elapsed.TotalSeconds * 1000000 / num_trials);

            this.Cursor = Cursors.Default;
        }
    }
}

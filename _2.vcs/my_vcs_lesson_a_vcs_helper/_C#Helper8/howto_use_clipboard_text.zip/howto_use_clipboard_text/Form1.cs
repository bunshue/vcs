﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_use_clipboard_text
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Copy text to the clipboard.
        private void btnCopy_Click(object sender, EventArgs e)
        {
            Clipboard.SetText(txtCopy.Text);
        }

        // Paste text from the clipboard.
        private void btnPaste_Click(object sender, EventArgs e)
        {
            txtPaste.Text = Clipboard.GetText();
        }
    }
}

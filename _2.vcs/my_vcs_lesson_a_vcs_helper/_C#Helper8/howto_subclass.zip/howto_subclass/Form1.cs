﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_subclass
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Override WndProc to watch for messages.
        protected override void WndProc(ref Message m)
        {
            Console.WriteLine(m.ToString());
            base.WndProc(ref m);
        }
    }
}

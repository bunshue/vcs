﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_form_fade_out
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Make the form disappear.
        private void btnClose_Click(object sender, EventArgs e)
        {
            tmrFade.Enabled = true;
        }

        // Decrease the form's Opacity.
        private void tmrFade_Tick(object sender, EventArgs e)
        {
            Opacity -= 0.05;
            if (Opacity <= 0) Close();
        }
    }
}

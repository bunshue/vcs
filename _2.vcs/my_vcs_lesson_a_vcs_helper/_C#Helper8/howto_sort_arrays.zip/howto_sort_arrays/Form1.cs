﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_sort_arrays
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            DisplayNumbers();
            DisplayPeople();
            DisplayPeopleLastNameFirst();
        }

        private void DisplayNumbers()
        {
            // Make an array of random numbers.
            Random rand = new Random();
            int[] numbers = new int[10];
            for (int i = 0; i < numbers.Length; i++)
            {
                numbers[i] = rand.Next(10, 99);
            }

            // Display the numbers unsorted.
            for (int i = 0; i < numbers.Length; i++)
            {
                lstNumbers.Items.Add(numbers[i]);
            }

            // Sort the numbers.
            Array.Sort(numbers);
            for (int i = 0; i < numbers.Length; i++)
            {
                lstSortedNumbers.Items.Add(numbers[i]);
            }
        }

        private void DisplayPeople()
        {
            Person[] people =
            {
                new Person() { FirstName="Ben", LastName="Holbrook"},
                new Person() { FirstName="Fred", LastName="Gill"},
                new Person() { FirstName="Ginny", LastName="Franklin"},
                new Person() { FirstName="Cindy", LastName="Carter"},
                new Person() { FirstName="Ann", LastName="Baker"},
                new Person() { FirstName="Jeff", LastName="Ivanova"},
                new Person() { FirstName="Irma", LastName="Archer"},
                new Person() { FirstName="Dan", LastName="Jerico"},
                new Person() { FirstName="Hal", LastName="Evans"},
                new Person() { FirstName="Edwina", LastName="Dolf"},
            };

            // Display the people unsorted.
            for (int i = 0; i < people.Length; i++)
            {
                lstPeople.Items.Add(people[i]);
            }

            // Sort the people.
            Array.Sort(people);
            for (int i = 0; i < people.Length; i++)
            {
                lstSortedPeople.Items.Add(people[i]);
            }
        }

        private void DisplayPeopleLastNameFirst()
        {
            Person[] people =
            {
                new Person() { FirstName="Ben", LastName="Holbrook"},
                new Person() { FirstName="Fred", LastName="Gill"},
                new Person() { FirstName="Ginny", LastName="Franklin"},
                new Person() { FirstName="Cindy", LastName="Carter"},
                new Person() { FirstName="Ann", LastName="Baker"},
                new Person() { FirstName="Jeff", LastName="Ivanova"},
                new Person() { FirstName="Irma", LastName="Archer"},
                new Person() { FirstName="Dan", LastName="Jerico"},
                new Person() { FirstName="Hal", LastName="Evans"},
                new Person() { FirstName="Edwina", LastName="Dolf"},
            };

            // Display the people unsorted.
            for (int i = 0; i < people.Length; i++)
            {
                lstLastNameFirst.Items.Add(people[i]);
            }

            // Sort the people.
            PersonComparer comparer = new PersonComparer();
            Array.Sort(people, comparer);
            for (int i = 0; i < people.Length; i++)
            {
                lstSortedLastNameFirst.Items.Add(people[i]);
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace howto_sort_arrays
{
    class PersonComparer : IComparer<Person>
    {
        // Compare two Persons.
        public int Compare(Person person1, Person person2)
        {
            string name1 = person1.LastName + "," + person1.FirstName;
            string name2 = person2.LastName + "," + person2.FirstName;
            return name1.CompareTo(name2);
        }
    }
}

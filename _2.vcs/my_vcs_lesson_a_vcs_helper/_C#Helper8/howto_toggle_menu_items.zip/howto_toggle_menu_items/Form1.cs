﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_toggle_menu_items
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Toggle the Inverted Colors feature.
        private void mnuAppearanceInverted_Click(object sender, EventArgs e)
        {
            if (mnuAppearanceInverted.Checked)
            {
                this.BackColor = SystemColors.ControlText;
                this.ForeColor = SystemColors.Control;
            }
            else
            {
                this.BackColor = SystemColors.Control;
                this.ForeColor = SystemColors.ControlText;
            }

            // The GroupBox doesn't automatically inherit ForeColor.
            groupBox1.ForeColor = this.ForeColor;
        }

        // Toggle the Bold feature.
        private void mnuAppearanceBold_Click(object sender, EventArgs e)
        {
            if (mnuAppearanceBold.Checked)
            {
                this.Font = new Font(this.Font, FontStyle.Bold);
            }
            else
            {
                this.Font = new Font(this.Font, FontStyle.Regular);
            }
        }

        // Toggle the Mistral feature.
        private void mnuAppearanceMistral_Click(object sender, EventArgs e)
        {
            if (mnuAppearanceMistral.Checked)
            {
                this.Font = new Font("Mistral", this.Font.Size, this.Font.Style);
            }
            else
            {
                this.Font = new Font("Microsoft Sans Serif", this.Font.Size, this.Font.Style);
            }
        }
    }
}

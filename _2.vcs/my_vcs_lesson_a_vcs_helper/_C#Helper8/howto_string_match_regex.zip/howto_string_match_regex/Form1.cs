﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_string_match_regex
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Validate a 7-digit US phone number.
        private void txt7Digit_TextChanged(object sender, EventArgs e)
        {
            if (txt7Digit.Text.Matches("^[2-9]{3}-\\d{4}$"))
            {
                txt7Digit.BackColor = Color.White;
            }
            else
            {
                txt7Digit.BackColor = Color.Yellow;
            }
        }

        // Validate a 10-digit US phone number.
        private void txt10Digit_TextChanged(object sender, EventArgs e)
        {
            if (txt10Digit.Text.Matches("^[2-9]{3}-[2-9]{3}-\\d{4}$"))
            {
                txt10Digit.BackColor = Color.White;
            }
            else
            {
                txt10Digit.BackColor = Color.Yellow;
            }
        }

        // Validate a 7- or 10-digit US phone number.
        private void txtEither_TextChanged(object sender, EventArgs e)
        {
            if (txtEither.Text.Matches("^([2-9]{3}-)?[2-9]{3}-\\d{4}$"))
            {
                txtEither.BackColor = Color.White;
            }
            else
            {
                txtEither.BackColor = Color.Yellow;
            }
        }

    }
}

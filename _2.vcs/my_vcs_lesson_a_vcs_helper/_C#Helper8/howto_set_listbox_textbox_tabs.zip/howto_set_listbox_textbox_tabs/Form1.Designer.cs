﻿namespace howto_set_listbox_textbox_tabs
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lstCars = new System.Windows.Forms.ListBox();
            this.txtCars = new System.Windows.Forms.TextBox();
            this.txtFormattedCars = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lstCars
            // 
            this.lstCars.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.lstCars.FormattingEnabled = true;
            this.lstCars.Location = new System.Drawing.Point(12, 12);
            this.lstCars.Name = "lstCars";
            this.lstCars.Size = new System.Drawing.Size(507, 147);
            this.lstCars.TabIndex = 0;
            // 
            // txtCars
            // 
            this.txtCars.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtCars.Location = new System.Drawing.Point(12, 165);
            this.txtCars.Multiline = true;
            this.txtCars.Name = "txtCars";
            this.txtCars.Size = new System.Drawing.Size(507, 147);
            this.txtCars.TabIndex = 1;
            // 
            // txtFormattedCars
            // 
            this.txtFormattedCars.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtFormattedCars.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFormattedCars.Location = new System.Drawing.Point(12, 318);
            this.txtFormattedCars.Multiline = true;
            this.txtFormattedCars.Name = "txtFormattedCars";
            this.txtFormattedCars.Size = new System.Drawing.Size(507, 169);
            this.txtFormattedCars.TabIndex = 2;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(531, 499);
            this.Controls.Add(this.txtFormattedCars);
            this.Controls.Add(this.txtCars);
            this.Controls.Add(this.lstCars);
            this.Name = "Form1";
            this.Text = "howto_set_listbox_textbox_tabs";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox lstCars;
        private System.Windows.Forms.TextBox txtCars;
        private System.Windows.Forms.TextBox txtFormattedCars;
    }
}


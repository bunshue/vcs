﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Runtime.InteropServices;

namespace howto_set_listbox_textbox_tabs
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // Set the ListBox tabs.
            SetListBoxTabs(lstCars, new int[] { 120, 170, 220 });
            SetListBoxTabs(lstCars, new int[] { 120, 170, 220 });
            
            // Set the TextBox tabs.
            SetTextBoxTabs(txtCars, new int[] { 120, 170, 220 });

            // Make some data.
            // Source: http://www.thesupercars.org/fastest-cars/fastest-cars-in-the-world-top-10-list.
            AddData("SSC Ultimate Aero", 257, 1183, 654400);
            AddData("Bugatti Veyron", 253, 1001, 1700000);
            AddData("Saleen S7 Twin-Turbo", 248, 750, 555000);
            AddData("Koenigsegg CCX", 245, 806, 545568);
            AddData("McLaren F1", 240, 637, 970000);
            AddData("Ferrari Enzo", 217, 660, 670000);
            AddData("Jaguar XJ220", 217, 542, 650000);
            AddData("Pagani Zonda F", 215, 650, 667321);
            AddData("Lamborghini Murcielago LP640", 211, 640, 430000);
            AddData("Porsche Carrera GT", 205, 612, 440000);
        }

        // Add some data to all three controls.
        private void AddData(string name, int mph, int hp, decimal price)
        {
            // Build a tab-delimited string.
            string txt = name + "\t" + mph.ToString() + " mph\t" +
                hp.ToString() + " hp\t" + price.ToString("C");

            // Display in the ListBox and first TextBox.
            lstCars.Items.Add(txt);
            txtCars.Text += txt + "\r\n";

            // Display formatted.
            txtFormattedCars.Text +=
                string.Format("{0,-30}{1,7} mph{2,7} hp{3,15:C}\r\n",
                name, mph, hp, price);
        }

        // Set tab stops inside a ListBox.
        private void SetListBoxTabs(ListBox lst, IEnumerable<int> tabs)
        {
            // Make sure the control will use them.
            lst.UseTabStops = true;
            lst.UseCustomTabOffsets = true;

            // Get the control's tab offset collection.
            ListBox.IntegerCollection offsets = lstCars.CustomTabOffsets;

            // Define the tabs.
            foreach (int tab in tabs)
            {
                offsets.Add(tab);
            }
        }

        [DllImport("user32.dll", CharSet = CharSet.Auto)]
        static extern IntPtr SendMessage(IntPtr hWnd, uint Msg, Int32 wParam, int[] lParam);
        private const uint EM_SETTABSTOPS = 0xCB;

        // Set tab stops inside a TextBox.
        private void SetTextBoxTabs(TextBox txt, int[] tabs)
        {
            SendMessage(txt.Handle, EM_SETTABSTOPS, tabs.Length, tabs);
        }
    }
}

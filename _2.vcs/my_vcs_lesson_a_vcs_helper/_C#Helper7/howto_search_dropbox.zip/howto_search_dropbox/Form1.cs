﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.IO;

namespace howto_search_dropbox
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Set the default dropbox directory.
        private void Form1_Load(object sender, EventArgs e)
        {
            string home = Environment.GetEnvironmentVariable("USERPROFILE");
            txtStart.Text = Path.Combine(home, "Dropbox");
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            trvFiles.Nodes.Clear();
            SearchDir(trvFiles.Nodes, txtStart.Text);
        }

        // List the files and subdirectories of this directory.
        private void SearchDir(TreeNodeCollection nodes, string dir_name)
        {
            TreeNode dir_node = nodes.Add(dir_name);
            foreach (string filename in Directory.GetFiles(dir_name))
                dir_node.Nodes.Add(filename);
            foreach (string subdir in Directory.GetDirectories(dir_name))
                SearchDir(dir_node.Nodes, subdir);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_limited_selections
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // The selected CheckBoxes.
        private int NumAllowedOptions = 2;
        private List<CheckBox> Selections = new List<CheckBox>();

        // Make sure we don't have too many options selected.
        private void chkOption_CheckedChanged(object sender, EventArgs e)
        {
            CheckBox chk = sender as CheckBox;
            if (chk.Checked)
            {
                // Add this selection.
                Selections.Add(chk);

                // Make sure we don't have too many.
                if (Selections.Count > NumAllowedOptions)
                {
                    // Remove the oldest selection.
                    Selections[0].Checked = false;
                }
            }
            else
            {
                // Remove this selection.
                Selections.Remove(chk);
            }
        }
    }
}

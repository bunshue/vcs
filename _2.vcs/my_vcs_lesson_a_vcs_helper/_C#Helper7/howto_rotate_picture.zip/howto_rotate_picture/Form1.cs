﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Drawing.Drawing2D;
using System.IO;
using System.Drawing.Imaging;

namespace howto_rotate_picture
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // The current scale.
        private float ImageScale = 1;

        // The original and rotated bitmaps.
        private Bitmap OriginalImage = null, RotatedImage = null;

        private void mnuFileOpen_Click(object sender, EventArgs e)
        {
            if (ofdPicture.ShowDialog() == DialogResult.OK)
            {
                using (Bitmap bm = new Bitmap(ofdPicture.FileName))
                {
                    OriginalImage = new Bitmap(bm);
                    mnuFileSaveAs.Enabled = true;
                }

                DisplayImage();
            }
        }

        // Save the rotated file.
        private void mnuFileSaveAs_Click(object sender, EventArgs e)
        {
            if (sfdPicture.ShowDialog() == DialogResult.OK)
            {
                SaveImage(RotatedImage, sfdPicture.FileName);
            }
        }

        // Save the file with the appropriate format.
        public void SaveImage(Image image, string filename)
        {
            string extension = Path.GetExtension(filename);
            switch (extension.ToLower())
            {
                case ".bmp":
                    image.Save(filename, ImageFormat.Bmp);
                    break;
                case ".exif":
                    image.Save(filename, ImageFormat.Exif);
                    break;
                case ".gif":
                    image.Save(filename, ImageFormat.Gif);
                    break;
                case ".jpg":
                case ".jpeg":
                    image.Save(filename, ImageFormat.Jpeg);
                    break;
                case ".png":
                    image.Save(filename, ImageFormat.Png);
                    break;
                case ".tif":
                case ".tiff":
                    image.Save(filename, ImageFormat.Tiff);
                    break;
                default:
                    throw new NotSupportedException(
                        "Unknown file extension " + extension);
            }
        }

        // Redisplay the image.
        private void txtAngle_TextChanged(object sender, EventArgs e)
        {
            DisplayImage();
        }

        // Display the image at the current rotation and scale.
        private void DisplayImage()
        {
            if (OriginalImage == null) return;
            RotatedImage = null;
            picRotatedImage.Visible = false;

            float angle;
            if (!float.TryParse(txtAngle.Text, out angle)) return;

            // Find the size of the image's rotated bounding box.
            Matrix rotation = new Matrix();
            rotation.Rotate(angle);
            int old_wid = OriginalImage.Width;
            int old_hgt = OriginalImage.Height;
            PointF[] points =
            {
                new PointF(0, 0),
                new PointF(old_wid, 0),
                new PointF(0, old_hgt),
                new PointF(old_wid, old_hgt),
            };
            rotation.TransformPoints(points);
            float[] xs = { points[0].X, points[1].X, points[2].X, points[3].X };
            float[] ys = { points[0].Y, points[1].Y, points[2].Y, points[3].Y };
            int new_wid = (int)(xs.Max() - xs.Min());
            int new_hgt = (int)(ys.Max() - ys.Min());

            // Make the rotated image.
            RotatedImage = new Bitmap(new_wid, new_hgt);
            using (Graphics gr = Graphics.FromImage(RotatedImage))
            {
                gr.TranslateTransform(-old_wid / 2, -old_hgt / 2,
                    MatrixOrder.Append);
                gr.RotateTransform(angle, MatrixOrder.Append);
                gr.TranslateTransform(new_wid / 2, new_hgt / 2,
                    MatrixOrder.Append);
                RectangleF source_rect = new RectangleF(0, 0,
                    OriginalImage.Width, OriginalImage.Height);
                PointF[] dest_points =
                {
                    new PointF(0, 0),
                    new PointF(OriginalImage.Width, 0),
                    new PointF(0, OriginalImage.Height),
                };
                gr.DrawImage(OriginalImage, dest_points, source_rect, GraphicsUnit.Pixel);

                // Uncomment to draw a red box around the image.
                //using (Pen pen = new Pen(Color.Red, 10))
                //{
                //    gr.DrawRectangle(pen, 0, 0,
                //        OriginalImage.Width - 1,
                //        OriginalImage.Height - 1);
                //}
            }

            // Scale the output PictureBox.
            SetPictureBoxSize();

            // Display the result.
            picRotatedImage.Image = RotatedImage;
            picRotatedImage.Visible = true;
        }

        // Change the scale.
        private void mnuScale_Click(object sender, EventArgs e)
        {
            // Check this Scale menu item and uncheck the others.
            ToolStripMenuItem[] menu_items =
            {
                mnuScale1_4, mnuScale1_2, mnuScale1,
                mnuScale2, mnuScale3, mnuScale4
            };
            foreach (ToolStripMenuItem mnu in menu_items)
                mnu.Checked = (mnu == sender);

            // Get the new scale.
            ToolStripMenuItem item = sender as ToolStripMenuItem;
            ImageScale = float.Parse(item.Tag.ToString());

            // If we have an image loaded, resize the PictureBox.
            SetPictureBoxSize();
        }

        // Set the PictureBox to display the image
        // at the desired scale.
        private void SetPictureBoxSize()
        {
            if (RotatedImage == null) return;
            picRotatedImage.ClientSize = new Size(
                (int)(RotatedImage.Width * ImageScale),
                (int)(RotatedImage.Height * ImageScale));
        }
    }
}

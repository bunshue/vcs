﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_tristate_checkbox_summary
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // True if we should ignore check change events.
        private bool IgnoreCheckChangeEvents = false;

        // Select or deselect all CheckBoxes.
        private void chkMeals_CheckStateChanged(object sender, EventArgs e)
        {
            if (IgnoreCheckChangeEvents) return;

            if (chkMeals.CheckState == CheckState.Indeterminate)
                chkMeals.CheckState = CheckState.Unchecked;

            CheckBox[] meal_boxes = { chkBreakfast, chkLunch, chkDinner };
            IgnoreCheckChangeEvents = true;
            foreach (CheckBox chk in meal_boxes)
                chk.Checked = chkMeals.Checked;
            IgnoreCheckChangeEvents = false;
        }

        // The user changed a meal type selection.
        // Update the chkMeals CheckBox.
        private void chkMealType_CheckedChanged(object sender, EventArgs e)
        {
            if (IgnoreCheckChangeEvents) return;

            // See how many meals are selected.
            int num_selected = 0;
            CheckBox[] meal_boxes = { chkBreakfast, chkLunch, chkDinner };
            foreach (CheckBox chk in meal_boxes)
                if (chk.Checked) num_selected++;

            // Set the chkMeals CheckBox appropriately.
            IgnoreCheckChangeEvents = true;
            if (num_selected == 3)
                chkMeals.CheckState = CheckState.Checked;
            else if (num_selected == 0)
                chkMeals.CheckState = CheckState.Unchecked;
            else
                chkMeals.CheckState = CheckState.Indeterminate;
            IgnoreCheckChangeEvents = false;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_tristate_checkbox
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Make lunch indeterminate.
        private void Form1_Load(object sender, EventArgs e)
        {
            chkLunch.CheckState = CheckState.Indeterminate;
        }

        // Display the CheckBox's current state.
        private void chkMeal_CheckStateChanged(object sender, EventArgs e)
        {
            CheckBox chk = sender as CheckBox;
            lstState.Items.Add(chk.Text + ": " + chk.CheckState);
        }
    }
}

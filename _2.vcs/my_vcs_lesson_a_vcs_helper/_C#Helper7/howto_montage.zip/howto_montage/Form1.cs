﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.IO;

namespace howto_montage
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // The loaded images.
        private List<ImageInfo> Images =
            new List<ImageInfo>();

        // Select images to add to the montage.
        // Note that I set the dialog's Multiselect property
        // to True at design time.
        private void mnuFileOpen_Click(object sender, EventArgs e)
        {
            if (ofdImage.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    foreach (string filename in ofdImage.FileNames)
                    {
                        ImageInfo image = new ImageInfo(filename);
                        Images.Add(image);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                picImages.Refresh();
            }
        }

        // Save the result in a file.
        private void mnuFileSaveAs_Click(object sender, EventArgs e)
        {
            if (sfdMontage.ShowDialog() == DialogResult.OK)
            {
                // Make a Bitmap to hold the result.
                using (Bitmap bm = new Bitmap(
                    picImages.ClientSize.Width,
                    picImages.ClientSize.Height))
                {
                    // Draw the pictures.
                    using (Graphics gr = Graphics.FromImage(bm))
                    {
                        DrawPictures(gr, false);
                    }

                    // Save the file.
                    try
                    {
                        SaveImage(bm, sfdMontage.FileName);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                }
            }
        }

        // Redraw the images.
        private void picImages_Paint(object sender, PaintEventArgs e)
        {
            DrawPictures(e.Graphics, true);
        }

        // Draw the pictures.
        private void DrawPictures(Graphics gr, bool with_border)
        {
            gr.InterpolationMode = InterpolationMode.High;
            gr.Clear(picImages.BackColor);
            foreach (ImageInfo info in Images)
                info.Draw(gr, with_border);
        }

        private void mnuFileExit_Click(object sender, EventArgs e)
        {
            Close();
        }

        // The type if drag in progress.
        private ImageInfo.HitTypes DragType = ImageInfo.HitTypes.None;

        // Variables to remember what the mouse is over.
        private ImageInfo MouseImage = null;
        private ImageInfo.HitTypes MouseHitType = ImageInfo.HitTypes.None;

        // The position where a drag started.
        private Point StartPoint;
        private Rectangle StartRect;

        // Return the image under the mouse and the hit type.
        private void FindImageAt(Point point, out ImageInfo image,
            out ImageInfo.HitTypes hit_type)
        {
            // See if we hit an image.
            for (int i = Images.Count - 1; i >= 0; i--)
            {
                hit_type = Images[i].HitType(point);
                if (hit_type != ImageInfo.HitTypes.None)
                {
                    image = Images[i];
                    return;
                }
            }

            image = null;
            hit_type = ImageInfo.HitTypes.None;
        }

        // Display an appropriate mouse pointer.
        private void picImages_MouseMove(object sender, MouseEventArgs e)
        {
            // See if a drag is in progress.
            if (DragType == ImageInfo.HitTypes.None)
            {
                // No drag is in progress. Set the appropriate cursor.
                SetMouseCursor(e.Location);
            }
            else
            {
                if (DragType == ImageInfo.HitTypes.Body)
                {
                    // Just move it.
                    int dx = e.X - StartPoint.X;
                    int dy = e.Y - StartPoint.Y;
                    MouseImage.DestRect.X = StartRect.X + dx;
                    MouseImage.DestRect.Y = StartRect.Y + dy;
                }
                else
                {
                    // Get the desired new width and height.
                    int new_wid, new_hgt;
                    if ((DragType == ImageInfo.HitTypes.NwCorner) ||
                        (DragType == ImageInfo.HitTypes.SwCorner))
                        new_wid = StartRect.Right - e.X;
                    else
                        new_wid = e.X - StartRect.Left;

                    if ((DragType == ImageInfo.HitTypes.NwCorner) ||
                        (DragType == ImageInfo.HitTypes.NeCorner))
                        new_hgt = StartRect.Bottom - e.Y;
                    else
                        new_hgt = e.Y - StartRect.Top;

                    // Fix the aspect ratio.
                    if (new_hgt != 0)
                    {
                        float orig_aspect =
                            MouseImage.SourceRect.Width /
                            (float)MouseImage.SourceRect.Height;
                        float new_aspect = new_wid / (float)new_hgt;

                        if (new_aspect > orig_aspect)
                        {
                            // Too short and wide. Make taller.
                            new_hgt = (int)(new_wid / orig_aspect);
                        }
                        else if (new_aspect < orig_aspect)
                        {
                            // Too tall and thin. Make wider.
                            new_wid = (int)(new_hgt * orig_aspect);
                        }
                    }

                    // Update the destination rectangle.
                    int right = MouseImage.DestRect.Right;
                    int bottom = MouseImage.DestRect.Bottom;
                    if ((DragType == ImageInfo.HitTypes.NwCorner) ||
                        (DragType == ImageInfo.HitTypes.SwCorner))
                        MouseImage.DestRect.X = right - new_wid;
                    if ((DragType == ImageInfo.HitTypes.NwCorner) ||
                        (DragType == ImageInfo.HitTypes.NeCorner))
                        MouseImage.DestRect.Y = bottom - new_hgt;
                    MouseImage.DestRect.Width = new_wid;
                    MouseImage.DestRect.Height = new_hgt;
                }

                // Redraw.
                picImages.Refresh();
            }
        }

        // Set the correct mouse cursor.
        private void SetMouseCursor(Point point)
        {
            // See if the mouse is over an image.
            FindImageAt(point, out MouseImage, out MouseHitType);

            switch (MouseHitType)
            {
                case ImageInfo.HitTypes.None:
                    picImages.Cursor = Cursors.Default;
                    break;
                case ImageInfo.HitTypes.Body:
                    picImages.Cursor = Cursors.SizeAll;
                    break;
                case ImageInfo.HitTypes.NwCorner:
                case ImageInfo.HitTypes.SeCorner:
                    picImages.Cursor = Cursors.SizeNWSE;
                    break;
                case ImageInfo.HitTypes.NeCorner:
                case ImageInfo.HitTypes.SwCorner:
                    picImages.Cursor = Cursors.SizeNESW;
                    break;
            }
        }

        // Start dragging a corner or an image.
        private void picImages_MouseDown(object sender, MouseEventArgs e)
        {
            // If we're not over anything, do nothing.
            if (MouseHitType == ImageInfo.HitTypes.None) return;

            // Bring the image to the top.
            Images.Remove(MouseImage);
            Images.Add(MouseImage);
            picImages.Refresh();

            // Save the location and drag type.
            StartPoint = e.Location;
            StartRect = MouseImage.DestRect;
            DragType = MouseHitType;
        }

        // Stop dragging.
        private void picImages_MouseUp(object sender, MouseEventArgs e)
        {
            DragType = ImageInfo.HitTypes.None;
        }

        // Save the file with the appropriate format.
        public void SaveImage(Image image, string filename)
        {
            string extension = Path.GetExtension(filename);
            switch (extension.ToLower())
            {
                case ".bmp":
                    image.Save(filename, ImageFormat.Bmp);
                    break;
                case ".exif":
                    image.Save(filename, ImageFormat.Exif);
                    break;
                case ".gif":
                    image.Save(filename, ImageFormat.Gif);
                    break;
                case ".jpg":
                case ".jpeg":
                    image.Save(filename, ImageFormat.Jpeg);
                    break;
                case ".png":
                    image.Save(filename, ImageFormat.Png);
                    break;
                case ".tif":
                case ".tiff":
                    image.Save(filename, ImageFormat.Tiff);
                    break;
                default:
                    throw new NotSupportedException(
                        "Unknown file extension " + extension);
            }
        }

        // Remove all images.
        private void mnuFileNew_Click(object sender, EventArgs e)
        {
            Images = new List<ImageInfo>();
            picImages.Refresh();
        }

        // Scale all images.
        private void mnuScale_Click(object sender, EventArgs e)
        {
            ToolStripMenuItem mnu = sender as ToolStripMenuItem;
            float scale = float.Parse(mnu.Tag.ToString());

            foreach (ImageInfo info in Images)
            {
                info.DestRect = new Rectangle(
                    info.DestRect.X,
                    info.DestRect.Y,
                    (int)(info.SourceRect.Width * scale),
                    (int)(info.SourceRect.Height * scale));
            }
            picImages.Refresh();
        }

        // Let the user set the PictureBox's background color.
        private void mnuColorBackground_Click(object sender, EventArgs e)
        {
            cdBackground.Color = picImages.BackColor;
            if (cdBackground.ShowDialog() == DialogResult.OK)
            {
                picImages.BackColor = cdBackground.Color;
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_string_trimming
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            ResizeRedraw = true;
        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            // A Mark Twain quote:
            const string quote =
                "The trouble ain't that there is too many fools, " +
                "but that the lightning ain't distributed right.";
            const int margin = 5;
            StringTrimming[] values =
                (StringTrimming[])Enum.GetValues(typeof(StringTrimming));
            int height = (ClientSize.Height - (values.Length + 1) * margin) / values.Length;
            int width = ClientSize.Width - 2 * margin;

            using (Font font = new Font("Times New Roman", 16))
            {
                using (StringFormat string_format = new StringFormat())
                {
                    int y = margin;
                    foreach (StringTrimming trimmming in values)
                    {
                        Rectangle rect = new Rectangle(margin, y, width, height);
                        e.Graphics.DrawRectangle(Pens.Black, rect);
                        string_format.Trimming = trimmming;
                        e.Graphics.DrawString(trimmming.ToString() +
                            ": " + quote, font, Brushes.Blue, rect, string_format);

                        y += height + margin;
                    }
                }
            }
        }
    }
}

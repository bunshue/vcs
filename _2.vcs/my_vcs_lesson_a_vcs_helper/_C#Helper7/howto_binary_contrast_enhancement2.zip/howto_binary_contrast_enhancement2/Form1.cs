﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.IO;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;

namespace howto_binary_contrast_enhancement2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Load an image and perform contrast enhancement.
        private void mnuFileOpen_Click(object sender, EventArgs e)
        {
            if (ofdImage.ShowDialog() == DialogResult.OK)
            {
                // Load the file
                picOriginal.Image = LoadBitmapUnlocked(ofdImage.FileName);

                // Show the image with contrast enhancement.
                PerformContrastEnhancement();
            }
        }

        // Perform binary contrast enhancement.
        private void PerformContrastEnhancement()
        {
            if (picOriginal.Image == null) return;
            Cursor = Cursors.WaitCursor;

            // Perform contrast enhancement.
            Bitmap bm = new Bitmap(picOriginal.Image);

            BinaryContrast(bm, 3 * hscrCutoff.Value);

            // Display the result.
            picOriginal.Visible = true;

            if (picResult.Image != null) picResult.Image.Dispose();
            picResult.Image = bm;
            picResult.Left = picOriginal.Right + 4;
            picResult.Visible = true;
            Cursor = Cursors.Default;
        }

        // Perform binary contrast enhancement on the bitmap.
        private void BinaryContrast(Bitmap bm, int cutoff)
        {
            for (int y = 0; y < bm.Height; y++)
            {
                for (int x = 0; x < bm.Width; x++)
                {
                    Color clr = bm.GetPixel(x, y);
                    if (clr.R + clr.G + clr.B > cutoff)
                        bm.SetPixel(x, y, Color.White);
                    else
                        bm.SetPixel(x, y, Color.Black);
                }
            }
        }

        // Save the file.
        private void mnuFileSaveAs_Click(object sender, EventArgs e)
        {
            if (sfdImage.ShowDialog() == DialogResult.OK)
            {
                SaveBitmapUsingExtension((Bitmap)picResult.Image, sfdImage.FileName);
            }
        }

        // Save the file with the appropriate format.
        // Throw a NotSupportedException if the file
        // has an unknown extension.
        public void SaveBitmapUsingExtension(Bitmap bm, string filename)
        {
            string extension = Path.GetExtension(filename);
            switch (extension.ToLower())
            {
                case ".bmp":
                    bm.Save(filename, ImageFormat.Bmp);
                    break;
                case ".exif":
                    bm.Save(filename, ImageFormat.Exif);
                    break;
                case ".gif":
                    bm.Save(filename, ImageFormat.Gif);
                    break;
                case ".jpg":
                case ".jpeg":
                    bm.Save(filename, ImageFormat.Jpeg);
                    break;
                case ".png":
                    bm.Save(filename, ImageFormat.Png);
                    break;
                case ".tif":
                case ".tiff":
                    bm.Save(filename, ImageFormat.Tiff);
                    break;
                default:
                    throw new NotSupportedException(
                        "Unknown file extension " + extension);
            }
        }

        private void mnuFileExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void hscrCutoff_Scroll(object sender, ScrollEventArgs e)
        {
            lblCutoff.Text = hscrCutoff.Value.ToString();

            // Show the image with contrast enhancement.
            PerformContrastEnhancement();
        }

        // Load a bitmap without locking it.
        private Bitmap LoadBitmapUnlocked(string file_name)
        {
            using (Bitmap bm = new Bitmap(file_name))
            {
                return new Bitmap(bm);
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_move_between_listboxes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Move selected items to lstSelected.
        private void btnSelect_Click(object sender, EventArgs e)
        {
            MoveSelectedItems(lstUnselected, lstSelected);
        }

        // Move selected items to lstUnselected.
        private void btnDeselect_Click(object sender, EventArgs e)
        {
            MoveSelectedItems(lstSelected, lstUnselected);
        }

        // Move selected items from one ListBox to another.
        private void MoveSelectedItems(ListBox lstFrom, ListBox lstTo)
        {
            while (lstFrom.SelectedItems.Count > 0)
            {
                string item = (string)lstFrom.SelectedItems[0];
                lstTo.Items.Add(item);
                lstFrom.Items.Remove(item);
            }
            SetButtonsEditable();
        }

        // Move all items to lstSelected.
        private void btnSelectAll_Click(object sender, EventArgs e)
        {
            MoveAllItems(lstUnselected, lstSelected);
        }

        // Move all items to lstUnselected.
        private void btnDeselectAll_Click(object sender, EventArgs e)
        {
            MoveAllItems(lstSelected, lstUnselected);
        }

        // Move all items from one ListBox to another.
        private void MoveAllItems(ListBox lstFrom, ListBox lstTo)
        {
            lstTo.Items.AddRange(lstFrom.Items);
            lstFrom.Items.Clear();
            SetButtonsEditable();
        }

        // Enable and disable buttons.
        private void lst_SelectedIndexChanged(object sender, EventArgs e)
        {
            SetButtonsEditable();
        }

        // Enable and disable buttons.
        private void SetButtonsEditable()
        {
            btnSelect.Enabled = (lstUnselected.SelectedItems.Count > 0);
            btnSelectAll.Enabled = (lstUnselected.Items.Count > 0);
            btnDeselect.Enabled = (lstSelected.SelectedItems.Count > 0);
            btnDeselectAll.Enabled = (lstSelected.Items.Count > 0);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            SetButtonsEditable();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Drawing.Drawing2D;

namespace howto_point_over_pie
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // The pie chart's center.
        private Point EllipseCenter;

        // The pie chart's drawing area.
        private Rectangle EllipseRect;

        // The ellipse's X and Y radii.
        private float EllipseRx, EllipseRy;

        // The slices' ending angles in degrees.
        // The first angle is 0 and marks the start of the first slice.
        private float[] Angles = { 0, 45, 80, 110, 130, 170, 220, 245, 300, 360 };

        // The slices' colors.
        private Brush[] ChartBrushes =
        {
            Brushes.Red, Brushes.LightGreen, Brushes.LightBlue,
            Brushes.Yellow, Brushes.Orange, Brushes.White,
            Brushes.Cyan, Brushes.Pink, Brushes.Black,
        };

        // Initialize the pie chart data.
        private void Form1_Load(object sender, EventArgs e)
        {
            const int margin = 10;
            int wid = picPie.ClientSize.Width - 2 * margin;
            int hgt = picPie.ClientSize.Height - 2 * margin;
            EllipseRect = new Rectangle(margin, margin, wid, hgt);
            EllipseRx = wid / 2;
            EllipseRy = hgt / 2;
            EllipseCenter = new Point(
                picPie.ClientSize.Width / 2,
                picPie.ClientSize.Height / 2);
        }

        // Draw the pie slices.
        private void picPie_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;

            e.Graphics.FillEllipse(Brushes.Blue, EllipseRect);
            for (int i = 1; i < Angles.Length; i++)
            {
                e.Graphics.FillPie(ChartBrushes[i - 1],
                    EllipseRect, Angles[i], Angles[i - 1] - Angles[i]);
            }
            e.Graphics.DrawEllipse(Pens.Blue, EllipseRect);
        }

        // Display the number of the slice under the mouse.
        private void picPie_MouseMove(object sender, MouseEventArgs e)
        {
            // Get the slice number.
            int slice_number = GetSliceNumber(EllipseRect, Angles, e.Location);

            // Display the slice number.
            if (slice_number == -1) lblSliceNumber.Text = "";
            else lblSliceNumber.Text = slice_number.ToString();
        }

        // Return the slice number or -1 if the 
        // mouse isn't over a slice.
        private int GetSliceNumber(Rectangle rect, float[] angles, Point point)
        {
            // Get the position relative to the ellipse's center.
            float rx = rect.Width / 2;
            float ry = rect.Height / 2;
            float cx = rect.X + rx;
            float cy = rect.Y + ry;
            float dx = point.X - cx;
            float dy = point.Y - cy;
            float value =
                dx * dx / rx / rx +
                dy * dy / ry / ry;

            // See if the mouse is at the center.
            if (value < 0.0001) return -1;

            // See if the point is outside of the ellipse.
            if (value > 1) return -1;

            // The point is inside the ellipse.
            // Get the angle.
            double angle = Math.Atan2(dy, dx);
            if (angle < 0) angle += 2 * Math.PI;

            // Convert the angle into degrees.
            angle = angle * 180 / Math.PI;

            // Get the slice number.
            for (int i = 0; i < Angles.Length - 1; i++)
                if (angle <= Angles[i + 1]) return i;

            throw new Exception("Cannot find angle " + angle);
        }
    }
}

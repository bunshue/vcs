﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_drag_drop_images
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Set the drop target PictureBox's AllowDrop property at run time.
        // It is unavailable in the Properties window and doesn't
        // even show up in IntelliSense!
        private void Form1_Load(object sender, EventArgs e)
        {
            picDropTarget.AllowDrop = true;
        }

        // Start the drag.
        private void picDragSource_MouseDown(object sender, MouseEventArgs e)
        {
            // Start the drag if it's the right mouse button.
            if (e.Button == MouseButtons.Right)
            {
                picDragSource.DoDragDrop(picDragSource.Image, DragDropEffects.Copy);
            }
        }

        // Allow a copy of an image.
        private void picDropTarget_DragEnter(object sender, DragEventArgs e)
        {
            // See if this is a copy and the data includes an image.
            if (e.Data.GetDataPresent(DataFormats.Bitmap) &&
                (e.AllowedEffect & DragDropEffects.Copy) != 0)
            {
                // Allow this.
                e.Effect = DragDropEffects.Copy;
            }
            else
            {
                // Don't allow any other drop.
                e.Effect = DragDropEffects.None;
            }
        }

        // Accept the drop.
        private void picDropTarget_DragDrop(object sender, DragEventArgs e)
        {
            picDropTarget.Image = (Bitmap)e.Data.GetData(DataFormats.Bitmap, true);
        }
    }
}

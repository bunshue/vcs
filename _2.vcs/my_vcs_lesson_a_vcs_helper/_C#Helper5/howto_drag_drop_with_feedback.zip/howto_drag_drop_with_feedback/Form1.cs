﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_drag_drop_with_feedback
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Start a copy or move drag of text.
        private void lblDragSource_MouseDown(object sender, MouseEventArgs e)
        {
            // Start the drag if it's the right mouse button.
            if (e.Button == MouseButtons.Right)
            {
                if (lblDragSource.DoDragDrop("Here's some text!",
                    DragDropEffects.Copy | DragDropEffects.Move)
                        == DragDropEffects.Move)
                {
                    // The recipient moved the text.
                    // Remove it from here.
                    lblDragSource.Text = "";
                }
            }
        }

        // Indicate that we can accept a move or copy of text.
        private void lblDropTarget_DragEnter(object sender, DragEventArgs e)
        {
            // See if this is a copy and the data includes text.
            if (e.Data.GetDataPresent(DataFormats.Text) &&
                ((e.AllowedEffect & DragDropEffects.Copy) != 0 ||
                 (e.AllowedEffect & DragDropEffects.Move) != 0))
            {
                // Allow this.
                e.Effect = DragDropEffects.Copy | DragDropEffects.Move;

                // Display a highlighted background.
                lblDropTarget.BackColor = Color.LightYellow;
            }
            else
            {
                // Don't allow any other drop.
                e.Effect = DragDropEffects.None;
            }
        }

        // Check the key state. Allow copy if Shift is pressed.
        private void lblDropTarget_DragOver(object sender, DragEventArgs e)
        {
            const int KEY_SHIFT = 4;
            
            if ((e.KeyState & KEY_SHIFT) != 0)
            {
                // Shift is pressed. Allow move.
                e.Effect = DragDropEffects.Move;
            }
            else
            {
                // Shift is not pressed. Allow copy.
                e.Effect = DragDropEffects.Copy;
            }
        }

        // Remove the background color highlight.
        private void lblDropTarget_DragLeave(object sender, EventArgs e)
        {
            lblDropTarget.BackColor = SystemColors.Control;
        }

        // Accept the drop.
        private void lblDropTarget_DragDrop(object sender, DragEventArgs e)
        {
            // Accept the data.
            lblDropTarget.Text = (string)e.Data.GetData(DataFormats.Text);
            lblDropTarget.BackColor = SystemColors.Control;
        }
    }
}

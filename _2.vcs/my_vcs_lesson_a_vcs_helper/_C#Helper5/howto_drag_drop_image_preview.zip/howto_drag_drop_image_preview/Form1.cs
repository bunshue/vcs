﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_drag_drop_image_preview
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Set the drop target PictureBox's AllowDrop property at run time.
        // It is unavailable in the Properties window and doesn't
        // even show up in IntelliSense!
        private void Form1_Load(object sender, EventArgs e)
        {
            picDropTarget.AllowDrop = true;
        }

        // Start the drag.
        private void picDragSource_MouseDown(object sender, MouseEventArgs e)
        {
            // Start the drag if it's the right mouse button.
            if (e.Button == MouseButtons.Right)
            {
                PictureBox source = sender as PictureBox;
                picDragSource.DoDragDrop(source.Image, DragDropEffects.Copy);
            }
        }

        // The current image during a drag.
        private Image OldImage = null;

        // Allow a copy of an image.
        private void picDropTarget_DragEnter(object sender, DragEventArgs e)
        {
            // See if this is a copy and the data includes an image.
            if (e.Data.GetDataPresent(DataFormats.Bitmap) &&
                (e.AllowedEffect & DragDropEffects.Copy) != 0)
            {
                // Allow this.
                e.Effect = DragDropEffects.Copy;

                // Save the current image.
                OldImage = picDropTarget.Image;

                // Display the preview image.
                Bitmap bm = (Bitmap)e.Data.GetData(DataFormats.Bitmap, true);
                Bitmap copy_bm = (Bitmap)bm.Clone();
                using (Graphics gr = Graphics.FromImage(copy_bm))
                {
                    // Cover with translucent white.
                    using (SolidBrush br = new SolidBrush(Color.FromArgb(128, 255, 255, 255)))
                    {
                        gr.FillRectangle(br, 0, 0, bm.Width, bm.Height);
                    }
                }
                picDropTarget.Image = copy_bm;
            }
            else
            {
                // Don't allow any other drop.
                e.Effect = DragDropEffects.None;
            }
        }

        // Remove the drag enter image.
        private void picDropTarget_DragLeave(object sender, EventArgs e)
        {
            // Restore the saved image.
            picDropTarget.Image = OldImage;
        }

        // Accept the drop.
        private void picDropTarget_DragDrop(object sender, DragEventArgs e)
        {
            Bitmap bm = (Bitmap)e.Data.GetData(DataFormats.Bitmap, true);
            picDropTarget.Image = bm;
        }
    }
}

﻿namespace howto_drag_drop_image_preview
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.picDragSource2 = new System.Windows.Forms.PictureBox();
            this.picDropTarget = new System.Windows.Forms.PictureBox();
            this.picDragSource = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.picDragSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picDropTarget)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picDragSource)).BeginInit();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 176);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(67, 13);
            this.label2.TabIndex = 7;
            this.label2.Text = "Drop Target:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(75, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = "Drag Sources:";
            // 
            // picDragSource2
            // 
            this.picDragSource2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.picDragSource2.Image = global::howto_drag_drop_image_preview.Properties.Resources.dog_small;
            this.picDragSource2.Location = new System.Drawing.Point(292, 25);
            this.picDragSource2.Name = "picDragSource2";
            this.picDragSource2.Size = new System.Drawing.Size(210, 139);
            this.picDragSource2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.picDragSource2.TabIndex = 8;
            this.picDragSource2.TabStop = false;
            this.picDragSource2.MouseDown += new System.Windows.Forms.MouseEventHandler(this.picDragSource_MouseDown);
            // 
            // picDropTarget
            // 
            this.picDropTarget.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.picDropTarget.Location = new System.Drawing.Point(12, 192);
            this.picDropTarget.Name = "picDropTarget";
            this.picDropTarget.Size = new System.Drawing.Size(100, 100);
            this.picDropTarget.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.picDropTarget.TabIndex = 6;
            this.picDropTarget.TabStop = false;
            this.picDropTarget.DragDrop += new System.Windows.Forms.DragEventHandler(this.picDropTarget_DragDrop);
            this.picDropTarget.DragLeave += new System.EventHandler(this.picDropTarget_DragLeave);
            this.picDropTarget.DragEnter += new System.Windows.Forms.DragEventHandler(this.picDropTarget_DragEnter);
            // 
            // picDragSource
            // 
            this.picDragSource.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.picDragSource.Image = global::howto_drag_drop_image_preview.Properties.Resources.banner;
            this.picDragSource.Location = new System.Drawing.Point(12, 25);
            this.picDragSource.Name = "picDragSource";
            this.picDragSource.Size = new System.Drawing.Size(274, 88);
            this.picDragSource.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.picDragSource.TabIndex = 4;
            this.picDragSource.TabStop = false;
            this.picDragSource.MouseDown += new System.Windows.Forms.MouseEventHandler(this.picDragSource_MouseDown);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(513, 349);
            this.Controls.Add(this.picDragSource2);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.picDropTarget);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.picDragSource);
            this.Name = "Form1";
            this.Text = "howto_drag_drop_image_preview";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.picDragSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picDropTarget)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picDragSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox picDropTarget;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox picDragSource;
        private System.Windows.Forms.PictureBox picDragSource2;
    }
}


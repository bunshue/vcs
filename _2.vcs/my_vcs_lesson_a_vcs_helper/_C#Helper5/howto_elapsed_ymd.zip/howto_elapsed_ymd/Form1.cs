﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Diagnostics;

namespace howto_elapsed_ymd
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Clear any previous results.
        private void txtDate_TextChanged(object sender, EventArgs e)
        {
            txtElapsed.Clear();
        }

        // Display the elapsed time.
        private void btnCalculate_Click(object sender, EventArgs e)
        {
            txtElapsed.Clear();

            DateTime start_date, end_date;
            if (!DateTime.TryParse(txtStartDate.Text, out start_date)) return;
            if (!DateTime.TryParse(txtEndDate.Text, out end_date)) return;

            int years, months, days, hours, minutes, seconds, milliseconds;

            GetElapsedTime(start_date, end_date, out years, out months,
                out days, out hours, out minutes, out seconds, out milliseconds);

            // Display the result.
            string txt = "";
            if (years != 0) txt += ", " + years.ToString() + " years";
            if (months != 0) txt += ", " + months.ToString() + " months";
            if (days != 0) txt += ", " + days.ToString() + " days";
            if (hours != 0) txt += ", " + hours.ToString() + " hours";
            if (minutes != 0) txt += ", " + minutes.ToString() + " minutes";
            if (seconds != 0) txt += ", " + seconds.ToString() + " seconds";
            if (milliseconds != 0) txt += ", " + milliseconds.ToString() + " milliseconds";
            if (txt.Length > 0) txt = txt.Substring(2);
            if (txt.Length == 0) txt = "Same";
            txtElapsed.Text = txt;
        }

        // Return the number of years, months, days, hours, minutes, seconds,
        // and milliseconds you need to add to from_date to get to_date.
        private void GetElapsedTime(DateTime from_date, DateTime to_date, 
            out int years, out int months, out int days, out int hours,
            out int minutes, out int seconds, out int milliseconds)
        {
            // If from_date > to_date, switch them around.
            if (from_date > to_date)
            {
                GetElapsedTime(to_date, from_date,
                    out years, out months, out days, out hours,
                    out minutes, out seconds, out milliseconds);
                years = -years;
                months = -months;
                days = -days;
                hours = -hours;
                minutes = -minutes;
                seconds = -seconds;
                milliseconds = -milliseconds;
            }
            else
            {
                // Handle the years.
                years = to_date.Year - from_date.Year;

                // See if we went too far.
                DateTime test_date = from_date.AddMonths(12 * years);
                if (test_date > to_date)
                {
                    years--;
                    test_date = from_date.AddMonths(12 * years);
                }

                // Add months until we go too far.
                months = 0;
                while (test_date <= to_date)
                {
                    months++;
                    test_date = from_date.AddMonths(12 * years + months);
                }
                months--;

                // Subtract to see how many more days,
                // hours, minutes, etc. we need.
                from_date = from_date.AddMonths(12 * years + months);
                TimeSpan remainder = to_date - from_date;
                days = remainder.Days;
                hours = remainder.Hours;
                minutes = remainder.Minutes;
                seconds = remainder.Seconds;
                milliseconds = remainder.Milliseconds;
            }
        }
    }
}

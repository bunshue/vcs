﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_enumerate_pairs
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // Display the original values.
            string[] value_array =
            {
                "Ankylosaurus", "Brachiosaurus", "Caenagnathus",
                "Diplodocus", "Enigmosaurus","Fabrosaurus",
            };
            lstValues.DataSource = value_array;

            // Display pairs from the array.
            foreach (PairsTools.Pair<string> pair in value_array.Pairs())
                lstFromArray.Items.Add(pair);

            // Make a list holding the values.
            List<string> value_list = new List<string>();
            foreach (string value in value_array) value_list.Add(value);

            // Display pairs from the list.
            foreach (PairsTools.Pair<string> pair in value_list.Pairs())
                lstFromIEnumerable.Items.Add(pair);
        }
    }
}

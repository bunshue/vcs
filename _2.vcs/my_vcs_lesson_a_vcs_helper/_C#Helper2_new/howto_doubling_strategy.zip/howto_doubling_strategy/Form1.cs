﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_doubling_strategy
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private int Round;
        private decimal MaxBet, CurrentBank, MaxBank, LastBet;
        private bool LastWon;
        private Random Rand = new Random();
        private int StopAt = 0;

        private void btnGo_Click(object sender, EventArgs e)
        {
            if (tmrBet.Enabled)
            {
                tmrBet.Enabled = false;
                tmrBet.Tag = "Go";
            }
            else
            {
                tmrBet.Tag = "Stop";
                Round = 0;
                MaxBet = 0;
                StopAt = int.Parse(txtStopAt.Text);
                CurrentBank = decimal.Parse(txtCurrentBank.Text);
                MaxBank = CurrentBank;
                LastBet = 0;
                LastWon = true;
                tmrBet.Enabled = true;
            }
        }

        private void tmrBet_Tick(object sender, EventArgs e)
        {
            decimal current_bet;
            if (LastWon) current_bet = 1;
            else current_bet = LastBet * 2;

            Round++;
            txtRound.Text = Round.ToString();

            txtCurrentBet.Text = current_bet.ToString();

            if (StopAt < CurrentBank)
            {
                tmrBet.Enabled = false;
                return;
            }

            if (current_bet > CurrentBank)
            {
                tmrBet.Enabled = false;
                return;
            }

            LastBet = current_bet;
            if (MaxBet < current_bet)
            {
                MaxBet = current_bet;
                txtMaxBet.Text = MaxBet.ToString();
            }

            int spin = Rand.Next(37);
            LastWon = ((spin != 0) && (spin % 2 == 0));
            if (LastWon)
            {
                CurrentBank += current_bet;
                txtWinLoss.Text = "WIN";
            }
            else
            {
                CurrentBank -= current_bet;
                txtWinLoss.Text = "LOSS";
            }

            txtCurrentBank.Text = CurrentBank.ToString();
            if (MaxBank < CurrentBank)
            {
                MaxBank = CurrentBank;
                txtMaxBank.Text = MaxBank.ToString();
            }

            if (CurrentBank < 1) tmrBet.Enabled = false;
        }
    }
}

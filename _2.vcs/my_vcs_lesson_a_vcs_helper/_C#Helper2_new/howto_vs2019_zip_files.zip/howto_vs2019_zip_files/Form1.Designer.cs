﻿
namespace howto_vs2019_zip_files
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.mnuFile = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuFileAddFiles = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuFileRemoveFiles = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.mnuFileSaveZipFile = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.mnuFileExit = new System.Windows.Forms.ToolStripMenuItem();
            this.lstFiles = new System.Windows.Forms.ListBox();
            this.ofdFiles = new System.Windows.Forms.OpenFileDialog();
            this.sfdZipFile = new System.Windows.Forms.SaveFileDialog();
            this.picRemoveFiles = new System.Windows.Forms.PictureBox();
            this.picAddFiles = new System.Windows.Forms.PictureBox();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picRemoveFiles)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picAddFiles)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuFile});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(284, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // mnuFile
            // 
            this.mnuFile.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuFileAddFiles,
            this.mnuFileRemoveFiles,
            this.toolStripSeparator1,
            this.mnuFileSaveZipFile,
            this.toolStripMenuItem1,
            this.mnuFileExit});
            this.mnuFile.Name = "mnuFile";
            this.mnuFile.Size = new System.Drawing.Size(37, 20);
            this.mnuFile.Text = "&File";
            // 
            // mnuFileAddFiles
            // 
            this.mnuFileAddFiles.Name = "mnuFileAddFiles";
            this.mnuFileAddFiles.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.A)));
            this.mnuFileAddFiles.Size = new System.Drawing.Size(188, 22);
            this.mnuFileAddFiles.Text = "&Add Files...";
            this.mnuFileAddFiles.Click += new System.EventHandler(this.mnuFileAddFiles_Click);
            // 
            // mnuFileRemoveFiles
            // 
            this.mnuFileRemoveFiles.Enabled = false;
            this.mnuFileRemoveFiles.Name = "mnuFileRemoveFiles";
            this.mnuFileRemoveFiles.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.R)));
            this.mnuFileRemoveFiles.Size = new System.Drawing.Size(188, 22);
            this.mnuFileRemoveFiles.Text = "&Remove Files";
            this.mnuFileRemoveFiles.Click += new System.EventHandler(this.mnuFileRemoveFiles_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(185, 6);
            // 
            // mnuFileSaveZipFile
            // 
            this.mnuFileSaveZipFile.Enabled = false;
            this.mnuFileSaveZipFile.Name = "mnuFileSaveZipFile";
            this.mnuFileSaveZipFile.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.S)));
            this.mnuFileSaveZipFile.Size = new System.Drawing.Size(188, 22);
            this.mnuFileSaveZipFile.Text = "&Save Zip File...";
            this.mnuFileSaveZipFile.Click += new System.EventHandler(this.mnuFileSaveZipFile_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(185, 6);
            // 
            // mnuFileExit
            // 
            this.mnuFileExit.Name = "mnuFileExit";
            this.mnuFileExit.Size = new System.Drawing.Size(188, 22);
            this.mnuFileExit.Text = "E&xit";
            this.mnuFileExit.Click += new System.EventHandler(this.mnuFileExit_Click);
            // 
            // lstFiles
            // 
            this.lstFiles.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lstFiles.FormattingEnabled = true;
            this.lstFiles.IntegralHeight = false;
            this.lstFiles.Location = new System.Drawing.Point(12, 27);
            this.lstFiles.Name = "lstFiles";
            this.lstFiles.Size = new System.Drawing.Size(234, 222);
            this.lstFiles.TabIndex = 1;
            this.lstFiles.SelectedIndexChanged += new System.EventHandler(this.lstFiles_SelectedIndexChanged);
            // 
            // sfdZipFile
            // 
            this.sfdZipFile.DefaultExt = "zip";
            this.sfdZipFile.Filter = "Zip Files|*.zip|All Files|*.*";
            // 
            // picRemoveFiles
            // 
            this.picRemoveFiles.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.picRemoveFiles.Image = global::howto_vs2019_zip_files.Properties.Resources.delete_disabled;
            this.picRemoveFiles.Location = new System.Drawing.Point(252, 53);
            this.picRemoveFiles.Name = "picRemoveFiles";
            this.picRemoveFiles.Size = new System.Drawing.Size(20, 20);
            this.picRemoveFiles.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.picRemoveFiles.TabIndex = 3;
            this.picRemoveFiles.TabStop = false;
            this.picRemoveFiles.Click += new System.EventHandler(this.picRemoveFiles_Click);
            // 
            // picAddFiles
            // 
            this.picAddFiles.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.picAddFiles.Image = global::howto_vs2019_zip_files.Properties.Resources.add;
            this.picAddFiles.Location = new System.Drawing.Point(252, 27);
            this.picAddFiles.Name = "picAddFiles";
            this.picAddFiles.Size = new System.Drawing.Size(20, 20);
            this.picAddFiles.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.picAddFiles.TabIndex = 2;
            this.picAddFiles.TabStop = false;
            this.picAddFiles.Click += new System.EventHandler(this.picAddFiles_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 261);
            this.Controls.Add(this.picRemoveFiles);
            this.Controls.Add(this.picAddFiles);
            this.Controls.Add(this.lstFiles);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "howto_vs2019_zip_files";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picRemoveFiles)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picAddFiles)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem mnuFile;
        private System.Windows.Forms.ToolStripMenuItem mnuFileAddFiles;
        private System.Windows.Forms.ToolStripMenuItem mnuFileSaveZipFile;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem mnuFileExit;
        private System.Windows.Forms.ListBox lstFiles;
        private System.Windows.Forms.PictureBox picAddFiles;
        private System.Windows.Forms.PictureBox picRemoveFiles;
        private System.Windows.Forms.OpenFileDialog ofdFiles;
        private System.Windows.Forms.SaveFileDialog sfdZipFile;
        private System.Windows.Forms.ToolStripMenuItem mnuFileRemoveFiles;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
    }
}


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.IO;

// Use NuGet Manager to install System.IO.Compression.
// Add references to:
//      System.IO.Compression
//      System.IO.Compression.FileSystem
using System.IO.Compression;

namespace howto_vs2019_zip_files
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            ofdFiles.Multiselect = true;
            lstFiles.SelectionMode = SelectionMode.MultiExtended;
            lstFiles.HorizontalScrollbar = true;
        }

        private void mnuFileAddFiles_Click(object sender, EventArgs e)
        {
            AddFiles();
        }
        private void picAddFiles_Click(object sender, EventArgs e)
        {
            AddFiles();
        }
        private void AddFiles()
        {
            if (ofdFiles.ShowDialog() == DialogResult.OK)
            {
                foreach (string filename in ofdFiles.FileNames)
                    lstFiles.Items.Add(filename);
            }
            EnableMenuItems();
        }
        private void EnableMenuItems()
        {
            mnuFileSaveZipFile.Enabled = (lstFiles.Items.Count > 0);

            if (lstFiles.SelectedItems.Count > 0)
            {
                picRemoveFiles.Image = Properties.Resources.delete;
                mnuFileRemoveFiles.Enabled = true;
            }
            else
            {
                picRemoveFiles.Image = Properties.Resources.delete_disabled;
                mnuFileRemoveFiles.Enabled = false;
            }
        }

        private void mnuFileRemoveFiles_Click(object sender, EventArgs e)
        {
            RemoveFiles();
        }
        private void picRemoveFiles_Click(object sender, EventArgs e)
        {
            RemoveFiles();
        }
        private void RemoveFiles()
        {
            // Remove the first selected item by index until none are selected.
            while (lstFiles.SelectedIndices.Count > 0)
            {
                lstFiles.Items.RemoveAt(lstFiles.SelectedIndices[0]);
            }

            // Remove the first selected item as an object until none are selected.
            //while (lstFiles.SelectedItems.Count > 0)
            //{
            //    lstFiles.Items.Remove(lstFiles.SelectedItems[0]);
            //}

            // Remove the (first) selected item until none are selected.
            //while (lstFiles.SelectedItem != null)
            //{
            //    lstFiles.Items.Remove(lstFiles.SelectedItem);
            //}

            // Remove the selected items by index in reverse order.
            //for (int i = lstFiles.SelectedIndices.Count - 1; i >= 0; i--)
            //{
            //    lstFiles.Items.RemoveAt(i);
            //}
            EnableMenuItems();
        }

        private void mnuFileExit_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void mnuFileSaveZipFile_Click(object sender, EventArgs e)
        {
            SaveZipFile();
        }

        private void SaveZipFile()
        {
            // Get the Zip file name. If the user cancels, do nothing.
            if (sfdZipFile.ShowDialog() != DialogResult.OK) return;

            // If the file exists, delete it.
            // (The dialog made the user agree to that.)
            string zip_file_name = sfdZipFile.FileName;
            if (File.Exists(zip_file_name)) File.Delete(zip_file_name);

            Cursor = Cursors.WaitCursor;

            // Create the Zip archive for update.
            using (ZipArchive archive = ZipFile.Open(zip_file_name, ZipArchiveMode.Update))
            {
                // Add the files to the archive.
                for (int i = 0; i < lstFiles.Items.Count; i++)
                {
                    // Select the file in the list so the user can see progress.
                    lstFiles.SelectedIndex = i;
                    lstFiles.Refresh();

                    // Get the file's name without the path.
                    string filename = lstFiles.Items[i].ToString();
                    FileInfo file_info = new FileInfo(filename);

                    // Make an entry name for the file.
                    string entry_name = file_info.Name;
                    for (int version = 1; version < 10000; version++)
                    {
                        ZipArchiveEntry old_entry = archive.GetEntry(entry_name);
                        if (old_entry == null) break;
                        entry_name =
                            Path.GetFileNameWithoutExtension(file_info.Name) +
                            $"({version})" + file_info.Extension;
                    }

                    // Add the file to this entry.
                    archive.CreateEntryFromFile(filename, entry_name);
                }
            }

            lstFiles.SelectedIndex = -1;
            Cursor = Cursors.Default;
            MessageBox.Show("Done");
        }

        private void lstFiles_SelectedIndexChanged(object sender, EventArgs e)
        {
            EnableMenuItems();
        }
    }
}

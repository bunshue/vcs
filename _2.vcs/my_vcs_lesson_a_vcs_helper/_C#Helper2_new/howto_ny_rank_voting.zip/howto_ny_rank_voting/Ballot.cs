﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace howto_ny_rank_voting
{
    public class Ballot
    {
        // Choices holds the candidate numbers in ranked order.
        public int[] Choices;
        public Ballot(int num_candidates)
        {
            Choices = Extensions.RandomArrangement(num_candidates);
        }

        // Find this ballot's top non-disqualified choice.
        public int TopChoice(bool[] disqualified)
        {
            for (int i = 0; i < disqualified.Length; i++)
            {
                int candidate = Choices[i];
                if (!disqualified[candidate]) return candidate;
            }
            return -1;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_ny_rank_voting
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private Ballot[] Ballots = null;

        private void btnGenerateVotes_Click(object sender, EventArgs e)
        {
            int num_ballots = int.Parse(txtNumVoters.Text);
            int num_candidates = int.Parse(txtNumCandidates.Text);

            lvwVotes.Columns.Clear();
            lvwBallots.Columns.Clear();
            lvwBallots.Columns.Add("Voter");
            for (int i = 0; i < num_candidates; i++)
            {
                lvwBallots.Columns.Add("Choice " + (i + 1).ToString());
            }
            foreach (ColumnHeader header in lvwBallots.Columns)
            {
                header.TextAlign = HorizontalAlignment.Center;
            }
            lvwBallots.Items.Clear();

            Ballots = new Ballot[num_ballots];
            for (int voter = 0; voter < num_ballots; voter++)
            {
                Ballots[voter] = new Ballot(num_candidates);
                ListViewItem item = new ListViewItem((voter + 1).ToString());
                foreach (int choice in Ballots[voter].Choices)
                    item.SubItems.Add("Can " + choice.ToString());
                lvwBallots.Items.Add(item);
            }
        }

        private void btnTabulate_Click(object sender, EventArgs e)
        {
            int num_ballots = Ballots.Length;
            int num_candidates = Ballots[0].Choices.Length;
            int needed_to_win = (int)(num_ballots / 2.0 + 1);

            lvwVotes.Columns.Clear();
            lvwVotes.Columns.Add("Round");
            for (int i = 0; i < num_candidates; i++)
            {
                lvwVotes.Columns.Add("Can " + i.ToString());
            }
            lvwVotes.Columns.Add("Notes");
            lvwVotes.Items.Clear();

            // Make an array indicating which
            // candidates have been disqualified.
            bool[] disqualified = Enumerable.Repeat(false, num_candidates).ToArray();

            // Repeat rounds until we have a winner.
            // Note that there can be at most num_candidates - 1 rounds,
            // and round num_candidates - 1 could end in an exact tie.
            for (int round_num = 0; round_num < num_candidates - 1; round_num++)
            {
                // Count the votes.
                int[] votes = new int[num_candidates];
                foreach (Ballot ballot in Ballots)
                {
                    // Add to this ballot's top candidate's total.
                    votes[ballot.TopChoice(disqualified)]++;
                }

                // Display the totals.
                ListViewItem item = new ListViewItem(round_num.ToString());
                for (int candidate = 0; candidate < num_candidates; candidate++)
                {
                    if (disqualified[candidate])
                        item.SubItems.Add("---");
                    else
                        item.SubItems.Add(votes[candidate].ToString());
                }
                lvwVotes.Items.Add(item);

                // See if there is a winner.
                int winner = -1;
                for (int candidate = 0; candidate < num_candidates; candidate++)
                {
                    if (votes[candidate] >= needed_to_win)
                    {
                        winner = candidate;
                        break;
                    }
                }

                if (winner >= 0)
                {
                    // We have as winner!
                    item.SubItems.Add(winner.ToString() + " wins!");
                    break;
                }

                // Find the smallest vote total(s).
                string notes = "";
                int max_votes = int.MinValue;
                int min_votes = int.MaxValue;
                for (int i = 0; i < num_candidates; i++)
                {
                    if (!disqualified[i])
                    {
                        if (votes[i] < min_votes) min_votes = votes[i];
                        if (votes[i] > max_votes) max_votes = votes[i];
                    }
                }

                if (min_votes == max_votes)
                {
                    // We have a tie.
                    item.SubItems.Add("Tie");
                    break;
                }

                // Disqualify last place candidate(s).
                for (int i = 0; i < num_candidates; i++)
                {
                    if ((!disqualified[i]) && (votes[i] == min_votes))
                    {
                        disqualified[i] = true;
                        notes += ", x" + i.ToString();
                    }
                }
                notes = notes.Substring(2);

                item.SubItems.Add(notes);
            }
        }
    }
}

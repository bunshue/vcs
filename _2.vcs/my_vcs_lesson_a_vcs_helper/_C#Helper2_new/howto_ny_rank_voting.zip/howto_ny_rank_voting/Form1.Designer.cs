﻿namespace howto_ny_rank_voting
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txtNumCandidates = new System.Windows.Forms.TextBox();
            this.btnGenerateVotes = new System.Windows.Forms.Button();
            this.lvwBallots = new System.Windows.Forms.ListView();
            this.txtNumVoters = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.lvwVotes = new System.Windows.Forms.ListView();
            this.btnTabulate = new System.Windows.Forms.Button();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 41);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(73, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "# Candidates:";
            // 
            // txtNumCandidates
            // 
            this.txtNumCandidates.Location = new System.Drawing.Point(91, 38);
            this.txtNumCandidates.Name = "txtNumCandidates";
            this.txtNumCandidates.Size = new System.Drawing.Size(54, 20);
            this.txtNumCandidates.TabIndex = 1;
            this.txtNumCandidates.Text = "5";
            this.txtNumCandidates.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // btnGenerateVotes
            // 
            this.btnGenerateVotes.Location = new System.Drawing.Point(151, 16);
            this.btnGenerateVotes.Name = "btnGenerateVotes";
            this.btnGenerateVotes.Size = new System.Drawing.Size(75, 38);
            this.btnGenerateVotes.TabIndex = 2;
            this.btnGenerateVotes.Text = "Generate Votes";
            this.btnGenerateVotes.UseVisualStyleBackColor = true;
            this.btnGenerateVotes.Click += new System.EventHandler(this.btnGenerateVotes_Click);
            // 
            // lvwBallots
            // 
            this.lvwBallots.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lvwBallots.Location = new System.Drawing.Point(0, 0);
            this.lvwBallots.Name = "lvwBallots";
            this.lvwBallots.Size = new System.Drawing.Size(435, 126);
            this.lvwBallots.TabIndex = 3;
            this.lvwBallots.UseCompatibleStateImageBehavior = false;
            this.lvwBallots.View = System.Windows.Forms.View.Details;
            // 
            // txtNumVoters
            // 
            this.txtNumVoters.Location = new System.Drawing.Point(91, 12);
            this.txtNumVoters.Name = "txtNumVoters";
            this.txtNumVoters.Size = new System.Drawing.Size(54, 20);
            this.txtNumVoters.TabIndex = 0;
            this.txtNumVoters.Text = "5";
            this.txtNumVoters.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 15);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(50, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "# Voters:";
            // 
            // splitContainer1
            // 
            this.splitContainer1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.splitContainer1.Location = new System.Drawing.Point(12, 64);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.lvwBallots);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.lvwVotes);
            this.splitContainer1.Size = new System.Drawing.Size(435, 269);
            this.splitContainer1.SplitterDistance = 126;
            this.splitContainer1.TabIndex = 6;
            // 
            // lvwVotes
            // 
            this.lvwVotes.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lvwVotes.Location = new System.Drawing.Point(0, 0);
            this.lvwVotes.Name = "lvwVotes";
            this.lvwVotes.Size = new System.Drawing.Size(435, 139);
            this.lvwVotes.TabIndex = 4;
            this.lvwVotes.UseCompatibleStateImageBehavior = false;
            this.lvwVotes.View = System.Windows.Forms.View.Details;
            // 
            // btnTabulate
            // 
            this.btnTabulate.Location = new System.Drawing.Point(232, 16);
            this.btnTabulate.Name = "btnTabulate";
            this.btnTabulate.Size = new System.Drawing.Size(75, 38);
            this.btnTabulate.TabIndex = 7;
            this.btnTabulate.Text = "Tabulate";
            this.btnTabulate.UseVisualStyleBackColor = true;
            this.btnTabulate.Click += new System.EventHandler(this.btnTabulate_Click);
            // 
            // Form1
            // 
            this.AcceptButton = this.btnGenerateVotes;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(459, 345);
            this.Controls.Add(this.btnTabulate);
            this.Controls.Add(this.splitContainer1);
            this.Controls.Add(this.txtNumVoters);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnGenerateVotes);
            this.Controls.Add(this.txtNumCandidates);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "howto_ny_rank_voting";
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtNumCandidates;
        private System.Windows.Forms.Button btnGenerateVotes;
        private System.Windows.Forms.ListView lvwBallots;
        private System.Windows.Forms.TextBox txtNumVoters;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.Button btnTabulate;
        private System.Windows.Forms.ListView lvwVotes;
    }
}


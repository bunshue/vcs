﻿namespace howto_flash_cards
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuFileOpen = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.mnuFileExit = new System.Windows.Forms.ToolStripMenuItem();
            this.ofdDirectory = new System.Windows.Forms.OpenFileDialog();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.picASide = new System.Windows.Forms.PictureBox();
            this.picBSide = new System.Windows.Forms.PictureBox();
            this.btnWrong = new System.Windows.Forms.Button();
            this.btnCorrect = new System.Windows.Forms.Button();
            this.menuStrip1.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picASide)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBSide)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(384, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuFileOpen,
            this.toolStripMenuItem1,
            this.mnuFileExit});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "&File";
            // 
            // mnuFileOpen
            // 
            this.mnuFileOpen.Name = "mnuFileOpen";
            this.mnuFileOpen.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.O)));
            this.mnuFileOpen.Size = new System.Drawing.Size(155, 22);
            this.mnuFileOpen.Text = "&Open...";
            this.mnuFileOpen.Click += new System.EventHandler(this.mnuFileOpen_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(152, 6);
            // 
            // mnuFileExit
            // 
            this.mnuFileExit.Name = "mnuFileExit";
            this.mnuFileExit.Size = new System.Drawing.Size(155, 22);
            this.mnuFileExit.Text = "E&xit";
            this.mnuFileExit.Click += new System.EventHandler(this.mnuFileExit_Click);
            // 
            // ofdDirectory
            // 
            this.ofdDirectory.Title = "Pick a file in the card directory";
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.picASide, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.picBSide, 1, 0);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(12, 27);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 217F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(360, 217);
            this.tableLayoutPanel1.TabIndex = 2;
            // 
            // picASide
            // 
            this.picASide.BackColor = System.Drawing.Color.White;
            this.picASide.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.picASide.Dock = System.Windows.Forms.DockStyle.Fill;
            this.picASide.Enabled = false;
            this.picASide.Location = new System.Drawing.Point(3, 3);
            this.picASide.Margin = new System.Windows.Forms.Padding(3, 3, 3, 5);
            this.picASide.Name = "picASide";
            this.picASide.Size = new System.Drawing.Size(174, 209);
            this.picASide.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picASide.TabIndex = 0;
            this.picASide.TabStop = false;
            this.picASide.Click += new System.EventHandler(this.picASide_Click);
            // 
            // picBSide
            // 
            this.picBSide.BackColor = System.Drawing.Color.White;
            this.picBSide.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.picBSide.Dock = System.Windows.Forms.DockStyle.Fill;
            this.picBSide.Location = new System.Drawing.Point(185, 3);
            this.picBSide.Margin = new System.Windows.Forms.Padding(5, 3, 3, 3);
            this.picBSide.Name = "picBSide";
            this.picBSide.Size = new System.Drawing.Size(172, 211);
            this.picBSide.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picBSide.TabIndex = 0;
            this.picBSide.TabStop = false;
            // 
            // btnWrong
            // 
            this.btnWrong.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.btnWrong.Enabled = false;
            this.btnWrong.Image = global::howto_flash_cards.Properties.Resources.frown50x50;
            this.btnWrong.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnWrong.Location = new System.Drawing.Point(197, 250);
            this.btnWrong.Name = "btnWrong";
            this.btnWrong.Size = new System.Drawing.Size(60, 74);
            this.btnWrong.TabIndex = 3;
            this.btnWrong.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnWrong.UseVisualStyleBackColor = true;
            this.btnWrong.Click += new System.EventHandler(this.btnWrong_Click);
            // 
            // btnCorrect
            // 
            this.btnCorrect.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.btnCorrect.Enabled = false;
            this.btnCorrect.Image = global::howto_flash_cards.Properties.Resources.smile50x50;
            this.btnCorrect.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnCorrect.Location = new System.Drawing.Point(129, 250);
            this.btnCorrect.Name = "btnCorrect";
            this.btnCorrect.Size = new System.Drawing.Size(60, 74);
            this.btnCorrect.TabIndex = 1;
            this.btnCorrect.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnCorrect.UseVisualStyleBackColor = true;
            this.btnCorrect.Click += new System.EventHandler(this.btnCorrect_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(384, 336);
            this.Controls.Add(this.btnWrong);
            this.Controls.Add(this.btnCorrect);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "howto_flash_cards";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.tableLayoutPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.picASide)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBSide)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox picASide;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mnuFileOpen;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem mnuFileExit;
        private System.Windows.Forms.OpenFileDialog ofdDirectory;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.PictureBox picBSide;
        private System.Windows.Forms.Button btnCorrect;
        private System.Windows.Forms.Button btnWrong;
    }
}


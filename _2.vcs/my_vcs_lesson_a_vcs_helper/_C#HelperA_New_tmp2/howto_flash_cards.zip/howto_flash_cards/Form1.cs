﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.IO;

// Hiragana images from:
// https://www.tofugu.com/japanese/learn-hiragana/

namespace howto_flash_cards
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private List<Card> Cards = null;

        private void mnuFileOpen_Click(object sender, EventArgs e)
        {
            if (ofdDirectory.ShowDialog() == DialogResult.OK)
            {
                // Load the flash cards.
                LoadFiles(ofdDirectory.FileName);

                // Randomize the cards and start a session.
                Cards.Randomize();
                NumCorrect = 0;
                NumWrong = 0;
                RoundNumber = -1;

                ShowNextRound();
            }
        }

        private void LoadFiles(string filename)
        {
            DirectoryInfo dir_info = (new FileInfo(filename)).Directory;
            var a_query =
                from FileInfo file_info in dir_info.GetFiles("*_a.*")
                orderby file_info.Name
                select file_info;
            List<FileInfo> a_s = a_query.ToList();
            var b_query =
                from FileInfo file_info in dir_info.GetFiles("*_b.*")
                orderby file_info.Name
                select file_info;
            List<FileInfo> b_s = b_query.ToList();

            var card_query =
                from FileInfo a_info in a_s
                join FileInfo b_info in b_s
                  on a_info.Name.Replace("_a.", ".") equals
                     b_info.Name.Replace("_b.", ".")
                select new Card(a_info, b_info);
            Cards = card_query.ToList();

            btnCorrect.Text = "";
            btnWrong.Text = "";
            btnCorrect.Enabled = true;
            btnWrong.Enabled = false;
        }

        private void mnuFileExit_Click(object sender, EventArgs e)
        {
            Close();
        }
        
        private void picASide_Click(object sender, EventArgs e)
        {
            btnCorrect.Enabled = true;
            btnWrong.Enabled = true;
            picBSide.Image = Cards[RoundNumber].BSide;
        }

        private int NumCorrect, NumWrong, RoundNumber;

        // Record a correct answer.
        private void btnCorrect_Click(object sender, EventArgs e)
        {
            NumCorrect++;
            ShowNextRound();
        }

        // Record an incorrect answer.
        private void btnWrong_Click(object sender, EventArgs e)
        {
            NumWrong++;
            ShowNextRound();
        }

        private void ShowNextRound()
        {
            picBSide.Image = null;
            btnCorrect.Text = NumCorrect.ToString();
            btnWrong.Text = NumWrong.ToString();
            btnCorrect.Enabled = false;
            btnWrong.Enabled = false;

            RoundNumber++;
            if (RoundNumber < Cards.Count)
            {
                picASide.Image = Cards[RoundNumber].ASide;
                picASide.Enabled = true;
            }
            else
            {
                picASide.Image = null;
                picASide.Enabled = false;
                int total = NumCorrect + NumWrong;
                double percent = NumCorrect / (double)total;
                MessageBox.Show("You answered " +
                    NumCorrect.ToString() + " out of " +
                    total.ToString() +
                    " correctly for a score of " +
                    percent.ToString("P0"));
            }
        }
    }
}

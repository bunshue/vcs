﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Drawing;
using System.IO;

namespace howto_flash_cards
{
    public class Card
    {
        public Bitmap ASide, BSide;

        public Card(FileInfo a_info, FileInfo b_info)
        {
            ASide = LoadBitmapUnlocked(a_info.FullName);
            BSide = LoadBitmapUnlocked(b_info.FullName);
        }

        // Load a bitmap without locking it.
        private Bitmap LoadBitmapUnlocked(string file_name)
        {
            using (Bitmap bm = new Bitmap(file_name))
            {
                return new Bitmap(bm);
            }
        }
    }
}

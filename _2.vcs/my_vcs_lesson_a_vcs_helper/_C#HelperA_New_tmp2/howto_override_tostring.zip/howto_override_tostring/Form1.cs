﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_override_tostring
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Create and display a list of Person objects.
        private void Form1_Load(object sender, EventArgs e)
        {
            Person[] people =
            {
                new Person() { FirstName="Simon", LastName="Green" },
                new Person() { FirstName="Terry", LastName="Pratchett" },
                new Person() { FirstName="Eowin", LastName="Colfer" },
            };
            lstPeople.DataSource = people;

            Person2[] people2 =
            {
                new Person2() { FirstName="Simon", LastName="Green" },
                new Person2() { FirstName="Terry", LastName="Pratchett" },
                new Person2() { FirstName="Eowin", LastName="Colfer" },
            };
            lstPeople2.DataSource = people2;
        }
    }
}

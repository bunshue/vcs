﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.IO;

namespace howto_default_application
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Initialize the file name.
        private void Form1_Load(object sender, EventArgs e)
        {
            string filename = Path.Combine(Application.StartupPath, @"..\..\");
            filename = Path.GetFullPath(filename) + "test.txt";
            cboFile.Items.Add(filename);
            cboFile.Text = filename;
        }

        // "Start" the file.
        private void btnOpen_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start(cboFile.Text);
        }
    }
}

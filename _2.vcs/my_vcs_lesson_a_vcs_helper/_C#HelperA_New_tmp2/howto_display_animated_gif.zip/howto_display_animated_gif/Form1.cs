﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.IO;

namespace howto_display_animated_gif
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Switch GIFs.
        bool ButtonShowingPuppy = false;
        private void btnGif_Click(object sender, EventArgs e)
        {
            ButtonShowingPuppy = !ButtonShowingPuppy;
            if (ButtonShowingPuppy)
            {
                btnGif.Image = howto_display_animated_gif.Properties.Resources.puppy;
            }
            else
            {
                btnGif.Image = howto_display_animated_gif.Properties.Resources.under_construction;
            }
        }

        // Switch GIFs, loading from files.
        bool PictureBoxShowingPuppy = false;
        private void picGif_Click(object sender, EventArgs e)
        {
            PictureBoxShowingPuppy = !PictureBoxShowingPuppy;
            if (PictureBoxShowingPuppy)
            {
                picGif.Image = howto_display_animated_gif.Properties.Resources.puppy;
            }
            else
            {
                picGif.Image = howto_display_animated_gif.Properties.Resources.under_construction;
            }
        }

        // Switch GIFs.
        bool LabelShowingAlien = false;
        private void lblGif_Click(object sender, EventArgs e)
        {
            string filename = Path.GetFullPath(
                Path.Combine(Application.StartupPath, @"..\..\"));

            LabelShowingAlien = !LabelShowingAlien;
            if (LabelShowingAlien)
            {
                lblGif.Image = Image.FromFile(filename + "alien.gif");
            }
            else
            {
                lblGif.Image = Image.FromFile(filename + "under_construction.gif");
            }
        }
    }
}

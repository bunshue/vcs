﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_make_auto_properties
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Make some Persons and display them in the ListBox.
        private void Form1_Load(object sender, EventArgs e)
        {
            Person[] people = new Person[3];
            people[0] = new Person("Jethro", "Tull");
            people[1] = new Person("Pink", "Floyd");
            people[2] = new Person("Lynyrd", "Skynyrd");

            lstBands.DataSource = people;
        }
    }

    // A simple Person class.
    public class Person
    {
        private string _FirstName;
        public string FirstName
        {
            get { return _FirstName; }
            set { _FirstName = value; }
        }

        public string LastName { get; set; }

        public Person(string firstName, string lastName)
        {
            FirstName = firstName;
            LastName = lastName;
        }

        public override string ToString()
        {
            return FirstName + " " + LastName;
        }
    }
}

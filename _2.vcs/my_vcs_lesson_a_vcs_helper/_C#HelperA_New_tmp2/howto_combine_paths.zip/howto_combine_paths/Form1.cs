﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.IO;

namespace howto_combine_paths
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Use the startup path for Path 1.
        private void Form1_Load(object sender, EventArgs e)
        {
            txtPath1.Text = Application.StartupPath;
        }

        // Combine the paths.
        private void btnCombine_Click(object sender, EventArgs e)
        {
            txtResult.Text = Path.GetFullPath(
                Path.Combine(txtPath1.Text, txtPath2.Text));

            Console.WriteLine(Path.GetFullPath(
                Path.Combine(Application.StartupPath, "../..")));
        }
    }
}

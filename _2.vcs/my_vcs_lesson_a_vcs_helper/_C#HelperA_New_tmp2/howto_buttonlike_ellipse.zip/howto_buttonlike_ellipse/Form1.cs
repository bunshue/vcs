﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Drawing.Drawing2D;

namespace howto_buttonlike_ellipse
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Redraw on resize.
        private void Form1_Load(object sender, EventArgs e)
        {
            this.ResizeRedraw = true;
        }

        // Draw the button-like ellipse.
        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            // Clear.
            e.Graphics.Clear(this.BackColor);
            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;

            // Get the area we will fill.
            Rectangle rect = new Rectangle(30, 30,
                this.ClientSize.Width - 60,
                this.ClientSize.Height - 60);

            // Fill the ellipse.
            using (LinearGradientBrush br =
                new LinearGradientBrush(rect,
                    Color.Lime, Color.DarkGreen, 225f))
            {
                e.Graphics.FillEllipse(br, rect);
            }

            // Outline the ellipse.
            using (LinearGradientBrush br =
                new LinearGradientBrush(rect,
                    Color.Lime, Color.DarkGreen, 45f))
            {
                using (Pen pen = new Pen(br, 20f))
                {
                    // e.Graphics.DrawRectangle(Pens.Red, rect);
                    rect.X += 10;
                    rect.Y += 10;
                    rect.Width -= 20;
                    rect.Height -= 20;

                    e.Graphics.DrawEllipse(pen, rect);
                }
            }
        }
    }
}

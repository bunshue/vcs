﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;

// Add a reference to Microsoft.Advertising.Mobile.UI.

namespace Tipster
{
    public partial class MainPage : PhoneApplicationPage
    {
        // Constructor
        public MainPage()
        {
            InitializeComponent();
        }

        // The value so far without the $.
        private string Value = "";

        // Process a button click.
        private void ButtonClicked(object sender, RoutedEventArgs e)
        {
            // Process the button.
            Button button = e.OriginalSource as Button;
            string caption = button.Content.ToString();
            switch (caption)
            {
                case "Back":
                    if (Value.Length > 0)
                        Value = Value.Substring(0, Value.Length - 1);
                    break;
                case "Clear":
                    Value = "";
                    break;
                default:
                    if (Value.Length < 9) Value += caption;
                    txtSubtotal.Text = Value;
                    break;
            }

            // Display the value.
            DisplayValue();
        }

        // Display the subtotal value as currency.
        private void DisplayValue()
        {
            // Parse the current value.
            decimal subtotal;
            if (!decimal.TryParse(Value, out subtotal))
            {
                subtotal = 0;
                Value = "";
            }
            subtotal /= 100m;

            // Display the parsed currency amount.
            txtSubtotal.Text = subtotal.ToString("C");

            // Display the tip values.
            txt10Percent.Text = (subtotal * 0.10m).ToString("C");
            txt15Percent.Text = (subtotal * 0.15m).ToString("C");
            txt20Percent.Text = (subtotal * 0.20m).ToString("C");
            txt25Percent.Text = (subtotal * 0.25m).ToString("C");
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Net;

namespace howto_download_file
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string filename = Application.StartupPath;
            if (!filename.EndsWith("\\")) filename += "\\";
            txtLocalFile.Text = filename + "howto_download_file.zip";
        }

        private void btnDownload_Click(object sender, EventArgs e)
        {
            this.Cursor = Cursors.WaitCursor;
            Application.DoEvents();

            try
            {
                // Make a WebClient.
                WebClient web_client = new WebClient();

                // Download the file.
                web_client.DownloadFile(txtRemoteFile.Text, txtLocalFile.Text);

                MessageBox.Show("Done");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Download Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }

            this.Cursor = Cursors.Default;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Globalization;

namespace howto_list_locales
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // Make the ListBox use tabs.
            lstLocales.UseTabStops = true;
            lstLocales.UseCustomTabOffsets = true;

            // Define the tabs.
            ListBox.IntegerCollection offsets = lstLocales.CustomTabOffsets;
            offsets.Add(100);

            // Add the locale information.
            foreach (CultureInfo info in
                CultureInfo.GetCultures(CultureTypes.AllCultures))
            {
                lstLocales.Items.Add(
                    info.EnglishName + '\t' +
                    info.NativeName);
            }

            // Display the number of locales.
            lblNumLocales.Text = lstLocales.Items.Count.ToString() + " locales";
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Drawing.Drawing2D;

namespace howto_linear_gradient
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            // Define a brush with two points and their colors.
            using (LinearGradientBrush br = new LinearGradientBrush(
                new Point(10, 10), new Point(140, 50), Color.Red, Color.White))
            {
                e.Graphics.FillRectangle(br, 10, 10, 125, 50);
                e.Graphics.DrawRectangle(Pens.Black, 10, 10, 125, 50);
            }

            // Define a brush with a Rectangle, colors, and gradient mode.
            Rectangle rect = new Rectangle(145, 10, 125, 50);
            using (LinearGradientBrush br = new LinearGradientBrush(
                rect, Color.Blue, Color.White, LinearGradientMode.ForwardDiagonal))
            {
                e.Graphics.FillRectangle(br, rect);
                e.Graphics.DrawRectangle(Pens.Black, rect);
            }

            // Define a gradient with more than 2 colors.
            rect = new Rectangle(10, 70, 260, 50);
            using (LinearGradientBrush br = new LinearGradientBrush(
                rect, Color.Blue, Color.White, 0f))
            {
                // Create a ColorBlend object. Note that you
                // must initialize it before you save it in the
                // brush's InterpolationColors property.
                ColorBlend colorBlend = new ColorBlend();
                colorBlend.Colors = new Color[] 
                {
                    Color.Red,
                    Color.Orange,
                    Color.Yellow,
                    Color.Lime,
                    Color.Blue,
                    Color.Indigo,
                    Color.Violet,
                };
                colorBlend.Positions = new float[]
                {
                    0f, 1/6f, 2/6f, 3/6f, 4/6f, 5/6f, 1f
                };
                br.InterpolationColors = colorBlend;

                e.Graphics.FillRectangle(br, rect);
                e.Graphics.DrawRectangle(Pens.Black, rect);
            }
        }
    }
}

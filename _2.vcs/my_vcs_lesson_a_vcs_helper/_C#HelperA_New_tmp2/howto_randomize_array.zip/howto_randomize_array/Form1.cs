﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_randomize_array
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Randomize_Click(object sender, EventArgs e)
        {
            // Put the items in an array.
            string[] items = txtItems.Lines;

            // Randomize.
            Randomizer.Randomize(items);

            // Display the result.
            txtResult.Lines = items;
            txtResult.Select(0, 0);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Diagnostics;

namespace howto_measure_elapsed_time
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private DateTime StartTime, StopTime;
        Stopwatch StopWatch;
        Stopwatch TotalWatch = new Stopwatch();

        private void Form1_Load(object sender, EventArgs e)
        {
            txtFrequency.Text = Stopwatch.Frequency.ToString();
            txtNsPerTick.Text = (1000000000 / Stopwatch.Frequency).ToString();
            txtIsHighRes.Text = Stopwatch.IsHighResolution.ToString();
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            btnStart.Enabled = false;
            btnStop.Enabled = true;
            txtElapsed1.Clear();
            txtElapsed2.Clear();
            txtElapsed3.Clear();

            StopWatch = Stopwatch.StartNew();
            TotalWatch.Start();
            StartTime = DateTime.Now;
        }

        private void btnStop_Click(object sender, EventArgs e)
        {
            StopTime = DateTime.Now;
            StopWatch.Stop();
            TotalWatch.Stop();

            TimeSpan elapsed = StopTime.Subtract(StartTime);
            txtElapsed1.Text = elapsed.TotalSeconds.ToString("0.000000");

            txtElapsed2.Text = StopWatch.Elapsed.TotalSeconds.ToString("0.000000");

            txtElapsed3.Text = TotalWatch.Elapsed.TotalSeconds.ToString("0.000000");

            btnStart.Enabled = true;
            btnStop.Enabled = false;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_file_size_in_words
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // Set tabs.
            int[] tabs = { 75, 125, 175 };
            lstValues.SetTabs(tabs);

            // Display some sample values.
            double value = 12.345;
            for (int i = 1; i < 11; i++)
            {
                string txt = "";
                txt += value.ToString("E") + "\t" + value.ToFileSize();

                if (value <= long.MaxValue)
                {
                    long long_size = (long)value;
                    txt += "\t" + long_size.ToFileSizeApi();
                }

                lstValues.Items.Add(txt);

                value *= 1000;
            }

            string str = "";
            value = 1023;
            str += value.ToString("E") + "\t" + value.ToFileSize();
            long s2 = (long)value;
            str += "\t" + s2.ToFileSizeApi();
            lstValues.Items.Add(str);

            str = "";
            value = 1024;
            str += value.ToString("E") + "\t" + value.ToFileSize();
            s2 = (long)value;
            str += "\t" + s2.ToFileSizeApi();
            lstValues.Items.Add(str);
        }
    }
}

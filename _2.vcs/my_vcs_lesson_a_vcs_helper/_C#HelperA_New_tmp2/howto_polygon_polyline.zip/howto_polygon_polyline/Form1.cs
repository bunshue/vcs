﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Drawing.Drawing2D;

namespace howto_polygon_polyline
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // A series of points (not closed).
        private Point[] OpenPoints =
        {
            new Point(74, 20),
            new Point(97, 61),
            new Point(134, 41),
            new Point(100, 120),
            new Point(24, 87),
            new Point(9, 36),
            new Point(63, 57),
        };

        // Draw a polygon from a series of (not closed) points.
        private void picPolygon_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
            e.Graphics.FillPolygon(Brushes.Yellow, OpenPoints);

            using (Pen big_pen = new Pen(Color.Blue, 10))
            {
                e.Graphics.DrawPolygon(big_pen, OpenPoints);
            }
        }

        // Draw lines from a series of (not closed) points.
        private void picLines_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
            e.Graphics.FillPolygon(Brushes.Yellow, OpenPoints);

            using (Pen big_pen = new Pen(Color.Blue, 10))
            {
                e.Graphics.DrawLines(big_pen, OpenPoints);
            }
        }

        // A closed polygon.
        private Point[] ClosedPoints =
        {
            new Point(74, 20),
            new Point(97, 61),
            new Point(134, 41),
            new Point(100, 120),
            new Point(24, 87),
            new Point(9, 36),
            new Point(63, 57),
            new Point(74, 20),
        };

        // Draw a polygon from a series of (closed) points.
        private void picPolygon2_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
            e.Graphics.FillPolygon(Brushes.Yellow, ClosedPoints);

            using (Pen big_pen = new Pen(Color.Blue, 10))
            {
                e.Graphics.DrawPolygon(big_pen, ClosedPoints);
            }
        }

        // Draw lines from a series of (closed) points.
        private void picLines2_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
            e.Graphics.FillPolygon(Brushes.Yellow, ClosedPoints);

            using (Pen big_pen = new Pen(Color.Blue, 10))
            {
                e.Graphics.DrawLines(big_pen, ClosedPoints);
            }
        }
    }
}

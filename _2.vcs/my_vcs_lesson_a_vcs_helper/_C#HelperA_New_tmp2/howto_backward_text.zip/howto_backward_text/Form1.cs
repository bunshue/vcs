﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_backward_text
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Bitmap bm = new Bitmap(280, 100);
            using (Graphics gr = Graphics.FromImage(bm))
            {
                gr.TextRenderingHint =
                    System.Drawing.Text.TextRenderingHint.AntiAliasGridFit;
                gr.ScaleTransform(-1, 1);
                using (Font the_font = new Font("Comic Sans MS", 40))
                {
                    gr.DrawString("Backward", the_font, Brushes.Black, -280, 0);
                    picBackward.Image = bm;
                }
            }
        }
    }
}

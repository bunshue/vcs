﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_assign_people_to_groups
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Assign the people to groups.
        private void btnAssign_Click(object sender, EventArgs e)
        {
            // Get the names into an array.
            int numPeople = lstPeople.Items.Count;
            string[] names = new string[numPeople];
            lstPeople.Items.CopyTo(names, 0);

            // Randomize.
            Randomizer.Randomize<string>(names);

            // Divide the names into groups.
            int numGroups = int.Parse(txtNumGroups.Text);
            lstResult.Items.Clear();
            int groupNum = 0;
            for (int i = 0; i < numPeople; i++)
            {
                lstResult.Items.Add(groupNum.ToString() +
                    "    " + names[i]);
                groupNum = ++groupNum % numGroups;
            }
        }
    }
}

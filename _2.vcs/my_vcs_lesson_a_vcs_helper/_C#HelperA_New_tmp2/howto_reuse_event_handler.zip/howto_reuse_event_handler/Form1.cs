﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_reuse_event_handler
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // The user clicked one of the buttons.
        private void btnChoice_Click(object sender, EventArgs e)
        {
            // Get the sender as a Button.
            Button btn = sender as Button;

            // Do something with the Button.
            switch (btn.Text)
            {
                case "Yes":
                    MessageBox.Show("You clicked Yes");
                    break;
                case "No":
                    MessageBox.Show("You clicked No. You're so negative!");
                    break;
                case "Maybe":
                    MessageBox.Show("You clicked Maybe. A bit undecided?");
                    break;
            }
        }
    }
}

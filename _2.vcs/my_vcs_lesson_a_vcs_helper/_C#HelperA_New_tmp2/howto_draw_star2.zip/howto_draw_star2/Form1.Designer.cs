﻿namespace howto_draw_star2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.nudPoints = new System.Windows.Forms.NumericUpDown();
            this.nudSkip = new System.Windows.Forms.NumericUpDown();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.picStar = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.nudPoints)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudSkip)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picStar)).BeginInit();
            this.SuspendLayout();
            // 
            // nudPoints
            // 
            this.nudPoints.Location = new System.Drawing.Point(67, 12);
            this.nudPoints.Name = "nudPoints";
            this.nudPoints.Size = new System.Drawing.Size(42, 20);
            this.nudPoints.TabIndex = 0;
            this.nudPoints.Value = new decimal(new int[] {
            7,
            0,
            0,
            0});
            this.nudPoints.ValueChanged += new System.EventHandler(this.nudPoints_ValueChanged);
            // 
            // nudSkip
            // 
            this.nudSkip.Location = new System.Drawing.Point(67, 38);
            this.nudSkip.Maximum = new decimal(new int[] {
            3,
            0,
            0,
            0});
            this.nudSkip.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudSkip.Name = "nudSkip";
            this.nudSkip.Size = new System.Drawing.Size(42, 20);
            this.nudSkip.TabIndex = 1;
            this.nudSkip.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.nudSkip.ValueChanged += new System.EventHandler(this.nudSkip_ValueChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 14);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(49, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "# Points:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 40);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(31, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Skip:";
            // 
            // picStar
            // 
            this.picStar.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.picStar.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.picStar.Location = new System.Drawing.Point(115, 12);
            this.picStar.Name = "picStar";
            this.picStar.Size = new System.Drawing.Size(244, 240);
            this.picStar.TabIndex = 4;
            this.picStar.TabStop = false;
            this.picStar.Paint += new System.Windows.Forms.PaintEventHandler(this.picStar_Paint);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(371, 264);
            this.Controls.Add(this.picStar);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.nudSkip);
            this.Controls.Add(this.nudPoints);
            this.Name = "Form1";
            this.Text = "howto_draw_star2";
            ((System.ComponentModel.ISupportInitialize)(this.nudPoints)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudSkip)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picStar)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.NumericUpDown nudPoints;
        private System.Windows.Forms.NumericUpDown nudSkip;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox picStar;
    }
}


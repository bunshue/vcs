﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_why_is_form_closing
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Tell the user why the form is closing.
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            MessageBox.Show(e.CloseReason.ToString());
        }

        // Close the form.
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        // Invoke the application's Exit method.
        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        // Display the form as a dialog.
        private Form1 MyParent;
        private void btnDialog_Click(object sender, EventArgs e)
        {
            Form1 dlg = new Form1();
            dlg.btnClose.Visible = false;
            dlg.btnExit.Visible = false;
            dlg.btnDialog.Visible = false;
            dlg.btnCloseParent.Visible = true;

            dlg.MyParent = this;
            dlg.ShowDialog(this);
        }

        // Close the parent form.
        private void btnCloseParent_Click(object sender, EventArgs e)
        {
            MyParent.Close();
        }
    }
}

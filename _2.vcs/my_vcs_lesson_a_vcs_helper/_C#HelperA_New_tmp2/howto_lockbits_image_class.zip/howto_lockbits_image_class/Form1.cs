﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Diagnostics;

namespace howto_lockbits_image_class
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Display the initial image.
        private void Form1_Load(object sender, EventArgs e)
        {
            picVisible.Image = picHidden.Image.Clone() as Image;
        }

        // Display the original image.
        private void btnReset_Click(object sender, EventArgs e)
        {
            picVisible.Image = picHidden.Image.Clone() as Image;
        }

        private const int NUM_TRIALS = 10;

        // Invert the image without Lockbits.
        private void btnNoLockBits_Click(object sender, EventArgs e)
        {
            Cursor = Cursors.WaitCursor;
            Stopwatch watch = new Stopwatch();
            watch.Start();

            Bitmap bm = new Bitmap(picHidden.Image);
            for (int trial = 0; trial < NUM_TRIALS; trial++)
            {
                for (int Y = 0; Y < bm.Height; Y++)
                {
                    for (int X = 0; X < bm.Width; X++)
                    {
                        Color clr = bm.GetPixel(X, Y);
                        clr = Color.FromArgb(
                            255 - clr.R,
                            255 - clr.G,
                            255 - clr.B);
                        bm.SetPixel(X, Y, clr);
                    }
                }
            }
            picVisible.Image = bm;
            watch.Stop();
            Cursor = Cursors.Default;

            lblElapsed.Text = watch.Elapsed.TotalSeconds.ToString("0.000000") + " seconds";
        }

        // Invert the image using Lockbits.
        private void btnLockBits_Click(object sender, EventArgs e)
        {
            const byte BYTE_255 = 255;
            Bitmap bm = new Bitmap(picHidden.Image);
            Cursor = Cursors.WaitCursor;
            Stopwatch watch = new Stopwatch();
            watch.Start();

            for (int trial = 0; trial < NUM_TRIALS; trial++)
            {
                // Make a Bitmap24 object.
                Bitmap24 bm24 = new Bitmap24(bm);

                // Lock the bitmap.
                bm24.LockBitmap();

                // Invert the pixels.
                for (int i = 0; i < bm.Height * bm24.RowSizeBytes; i++)
                {
                    // bm24.ImageBytes[i] = Convert.ToByte(BYTE_255 - bm24.ImageBytes[i]);
                    bm24.ImageBytes[i] = (byte)(BYTE_255 - bm24.ImageBytes[i]);
                }

                // Unlock the bitmap.
                bm24.UnlockBitmap();
            }
            picVisible.Image = bm;

            DateTime stop_time = DateTime.Now;
            Cursor = Cursors.Default;

            watch.Stop();
            lblElapsed.Text = watch.Elapsed.TotalSeconds.ToString("0.000000") + " seconds";
        }
    }
}

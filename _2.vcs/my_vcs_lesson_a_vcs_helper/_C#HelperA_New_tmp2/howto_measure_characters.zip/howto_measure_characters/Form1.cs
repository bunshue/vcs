﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_measure_characters
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Redraw on resize.
        private void Form1_Load(object sender, EventArgs e)
        {
            this.ResizeRedraw = true;
        }

        // Draw a string with character bounds.
        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAliasGridFit;
            e.Graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;

            int wid = ClientSize.Width;
            int hgt = ClientSize.Height / 2;
            Rectangle rect = new Rectangle(0, 0, wid, hgt);
            using (Font font = new Font("Times New Roman", 60, FontStyle.Italic))
            {
                DrawStringWithCharacterBounds(e.Graphics, "C# Helper", font, rect);
            }

            wid /= 2;
            rect = new Rectangle(0, hgt, wid, hgt);
            using (Font font = new Font("Times New Roman", 60, FontStyle.Regular))
            {
                DrawStringWithCharacterBounds(e.Graphics, "jiffy", font, rect);
            }

            rect = new Rectangle(wid, hgt, wid, hgt);
            using (Font font = new Font("Times New Roman", 60, FontStyle.Italic))
            {
                DrawStringWithCharacterBounds(e.Graphics, "jiffy", font, rect);
            }
        }

        // Draw the string and the bounds for its characters.
        private void DrawStringWithCharacterBounds(Graphics gr, string text, Font font, Rectangle rect)
        {
            using (StringFormat string_format = new StringFormat())
            {
                string_format.Alignment = StringAlignment.Center;
                string_format.LineAlignment = StringAlignment.Center;

                // Draw the string.
                gr.DrawString(text, font, Brushes.Blue, rect, string_format);

                // Make a CharacterRange for the string's characters.
                List<CharacterRange> range_list = new List<CharacterRange>();
                for (int i = 0; i < text.Length; i++)
                {
                    range_list.Add(new CharacterRange(i, 1));
                }
                string_format.SetMeasurableCharacterRanges(range_list.ToArray());

                // Measure the string's character ranges.
                Region[] regions = gr.MeasureCharacterRanges(
                    text, font, rect, string_format);

                // Draw the character bounds.
                for (int i = 0; i < text.Length; i++)
                {
                    Rectangle char_rect = Rectangle.Round(regions[i].GetBounds(gr));
                    gr.DrawRectangle(Pens.Red, char_rect);
                }
            }
        }
    }
}

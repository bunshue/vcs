﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Diagnostics;

namespace howto_calculate_factorial
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnGo_Click(object sender, EventArgs e)
        {
            decimal N = decimal.Parse(txtN.Text);
            try
            {
                txtNFactorial.Text = Factorial(N).ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", 
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Exclamation);
            }
        }

        // Calculate N!
        private decimal Factorial(decimal N)
        {
            Debug.Assert(N >= 0);

            decimal result = 1;
            for (decimal i = 2; i <= N; i++) result *= i;            
            return result;
        }
    }
}

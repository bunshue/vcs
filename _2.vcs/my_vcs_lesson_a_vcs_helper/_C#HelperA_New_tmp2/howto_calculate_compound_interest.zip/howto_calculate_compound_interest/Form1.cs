﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_calculate_compound_interest
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Calculate and display interest for the following years.
        private void btnCalculate_Click(object sender, EventArgs e)
        {
            lstResults.Items.Clear();

            double principle = double.Parse(txtPrinciple.Text);
            double interestRate = double.Parse(txtInterestRate.Text);
            int numYears = int.Parse(txtNumYears.Text);
            for (int i = 1; i <= numYears; i++)
            {
                double balance = principle * Math.Pow(1 + interestRate, i);
                lstResults.Items.Add("Year " + i.ToString() + "\t" +
                    balance.ToString("C"));
            }
        }
    }
}

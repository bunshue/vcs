﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_align_drawn_text
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Draw text aligned in various ways.
        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            Rectangle rect = new Rectangle(5, 5,
                ClientSize.Width - 10, ClientSize.Height - 10);
            e.Graphics.DrawRectangle(Pens.Red, rect);

            using (Font font = new Font("Times New Roman", 16, GraphicsUnit.Pixel))
            {
                using (StringFormat sf = new StringFormat())
                {
                    // Top.
                    sf.LineAlignment = StringAlignment.Near;    // Top.

                    // Top/Left.
                    sf.Alignment = StringAlignment.Near;        // Left.
                    e.Graphics.DrawString("Top/Left", font, Brushes.Black, rect, sf);

                    // Top/Center.
                    sf.Alignment = StringAlignment.Center;      // Center.
                    e.Graphics.DrawString("Top/Center", font, Brushes.Black, rect, sf);

                    // Top/Right.
                    sf.Alignment = StringAlignment.Far;         // Right.
                    e.Graphics.DrawString("Top/Right", font, Brushes.Black, rect, sf);

                    // Middle.
                    sf.LineAlignment = StringAlignment.Center;  // Middle.

                    // Middle/Left.
                    sf.Alignment = StringAlignment.Near;        // Left.
                    e.Graphics.DrawString("Middle/Left", font, Brushes.Black, rect, sf);

                    // Middle/Center.
                    sf.Alignment = StringAlignment.Center;      // Center.
                    e.Graphics.DrawString("Middle/Center", font, Brushes.Black, rect, sf);

                    // Middle/Right.
                    sf.Alignment = StringAlignment.Far;         // Right.
                    e.Graphics.DrawString("Middle/Right", font, Brushes.Black, rect, sf);

                    // Bottom.
                    sf.LineAlignment = StringAlignment.Far;     // Bottom.

                    // Bottom/Left.
                    sf.Alignment = StringAlignment.Near;        // Left.
                    e.Graphics.DrawString("Bottom/Left", font, Brushes.Black, rect, sf);

                    // Bottom/Center.
                    sf.Alignment = StringAlignment.Center;      // Center.
                    e.Graphics.DrawString("Bottom/Center", font, Brushes.Black, rect, sf);

                    // Bottom/Right.
                    sf.Alignment = StringAlignment.Far;         // Right.
                    e.Graphics.DrawString("Bottom/Right", font, Brushes.Black, rect, sf);
                }
            }
        }

        private void Form1_Resize(object sender, EventArgs e)
        {
            Refresh();
        }
    }
}

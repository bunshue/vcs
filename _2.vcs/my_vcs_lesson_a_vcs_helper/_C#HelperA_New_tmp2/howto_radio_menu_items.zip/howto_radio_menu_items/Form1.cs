﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_radio_menu_items
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Check this menu item and uncheck the others.
        private void mnuViewOption_Click(object sender, EventArgs e)
        {
            // Check the menu item.
            ToolStripMenuItem item = sender as ToolStripMenuItem;
            CheckMenuItem(mnuView, item);

            // Do something with the menu selection.
            // You could use a switch statement here.
            // This example just displays the menu item's text.
            MessageBox.Show(item.Text);
        }

        // Uncheck all menu items in this menu except checked_item.
        private void CheckMenuItem(ToolStripMenuItem mnu, ToolStripMenuItem checked_item)
        {
            // Uncheck the menu items except checked_item.
            foreach (ToolStripItem item in mnu.DropDownItems)
            {
                if (item is ToolStripMenuItem)
                {
                    ToolStripMenuItem menu_item = item as ToolStripMenuItem;
                    menu_item.Checked = (menu_item == checked_item);
                }
            }
        }
    }
}

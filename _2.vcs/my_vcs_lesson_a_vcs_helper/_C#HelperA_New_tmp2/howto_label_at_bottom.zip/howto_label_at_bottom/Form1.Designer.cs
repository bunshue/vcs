﻿namespace howto_label_at_bottom
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lstFiles = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtFromDir = new System.Windows.Forms.TextBox();
            this.btnList = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.lblSample = new System.Windows.Forms.Label();
            this.btnPickFont = new System.Windows.Forms.Button();
            this.fdFont = new System.Windows.Forms.FontDialog();
            this.label3 = new System.Windows.Forms.Label();
            this.txtMessage = new System.Windows.Forms.TextBox();
            this.picImage = new System.Windows.Forms.PictureBox();
            this.txtMargin = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.radLR = new System.Windows.Forms.RadioButton();
            this.radLM = new System.Windows.Forms.RadioButton();
            this.radLL = new System.Windows.Forms.RadioButton();
            this.radMR = new System.Windows.Forms.RadioButton();
            this.radMM = new System.Windows.Forms.RadioButton();
            this.radML = new System.Windows.Forms.RadioButton();
            this.radUR = new System.Windows.Forms.RadioButton();
            this.radUM = new System.Windows.Forms.RadioButton();
            this.radUL = new System.Windows.Forms.RadioButton();
            this.label6 = new System.Windows.Forms.Label();
            this.picBg = new System.Windows.Forms.PictureBox();
            this.cdBackground = new System.Windows.Forms.ColorDialog();
            this.txtToDir = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.btnDraw = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.picImage)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picBg)).BeginInit();
            this.SuspendLayout();
            // 
            // lstFiles
            // 
            this.lstFiles.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)));
            this.lstFiles.FormattingEnabled = true;
            this.lstFiles.IntegralHeight = false;
            this.lstFiles.Location = new System.Drawing.Point(15, 66);
            this.lstFiles.Name = "lstFiles";
            this.lstFiles.Size = new System.Drawing.Size(120, 354);
            this.lstFiles.TabIndex = 0;
            this.lstFiles.SelectedIndexChanged += new System.EventHandler(this.lstFiles_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 17);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(78, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "From Directory:";
            // 
            // txtFromDir
            // 
            this.txtFromDir.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtFromDir.Location = new System.Drawing.Point(96, 14);
            this.txtFromDir.Name = "txtFromDir";
            this.txtFromDir.Size = new System.Drawing.Size(388, 20);
            this.txtFromDir.TabIndex = 2;
            // 
            // btnList
            // 
            this.btnList.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnList.Location = new System.Drawing.Point(490, 12);
            this.btnList.Name = "btnList";
            this.btnList.Size = new System.Drawing.Size(75, 23);
            this.btnList.TabIndex = 3;
            this.btnList.Text = "List";
            this.btnList.UseVisualStyleBackColor = true;
            this.btnList.Click += new System.EventHandler(this.btnList_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(141, 66);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(31, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Font:";
            // 
            // lblSample
            // 
            this.lblSample.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lblSample.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblSample.Font = new System.Drawing.Font("Segoe UI", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSample.Location = new System.Drawing.Point(203, 66);
            this.lblSample.Name = "lblSample";
            this.lblSample.Size = new System.Drawing.Size(281, 121);
            this.lblSample.TabIndex = 5;
            this.lblSample.Text = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
            // 
            // btnPickFont
            // 
            this.btnPickFont.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnPickFont.Image = global::howto_label_at_bottom.Properties.Resources.ellipsis;
            this.btnPickFont.Location = new System.Drawing.Point(509, 81);
            this.btnPickFont.Name = "btnPickFont";
            this.btnPickFont.Size = new System.Drawing.Size(33, 23);
            this.btnPickFont.TabIndex = 6;
            this.btnPickFont.UseVisualStyleBackColor = true;
            this.btnPickFont.Click += new System.EventHandler(this.btnPickFont_Click);
            // 
            // fdFont
            // 
            this.fdFont.ShowColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(141, 219);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 13);
            this.label3.TabIndex = 7;
            this.label3.Text = "Message:";
            // 
            // txtMessage
            // 
            this.txtMessage.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtMessage.Location = new System.Drawing.Point(203, 216);
            this.txtMessage.Name = "txtMessage";
            this.txtMessage.Size = new System.Drawing.Size(281, 20);
            this.txtMessage.TabIndex = 8;
            this.txtMessage.Text = "Test Message";
            // 
            // picImage
            // 
            this.picImage.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.picImage.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.picImage.Location = new System.Drawing.Point(249, 242);
            this.picImage.Name = "picImage";
            this.picImage.Size = new System.Drawing.Size(235, 178);
            this.picImage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picImage.TabIndex = 9;
            this.picImage.TabStop = false;
            // 
            // txtMargin
            // 
            this.txtMargin.Location = new System.Drawing.Point(203, 242);
            this.txtMargin.Name = "txtMargin";
            this.txtMargin.Size = new System.Drawing.Size(40, 20);
            this.txtMargin.TabIndex = 12;
            this.txtMargin.Text = "100";
            this.txtMargin.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(141, 245);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(50, 13);
            this.label4.TabIndex = 11;
            this.label4.Text = "Msg Hgt:";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.radLR);
            this.groupBox1.Controls.Add(this.radLM);
            this.groupBox1.Controls.Add(this.radLL);
            this.groupBox1.Controls.Add(this.radMR);
            this.groupBox1.Controls.Add(this.radMM);
            this.groupBox1.Controls.Add(this.radML);
            this.groupBox1.Controls.Add(this.radUR);
            this.groupBox1.Controls.Add(this.radUM);
            this.groupBox1.Controls.Add(this.radUL);
            this.groupBox1.Location = new System.Drawing.Point(144, 268);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(99, 78);
            this.groupBox1.TabIndex = 23;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Alignment";
            // 
            // radLR
            // 
            this.radLR.AutoSize = true;
            this.radLR.Location = new System.Drawing.Point(65, 54);
            this.radLR.Name = "radLR";
            this.radLR.Size = new System.Drawing.Size(14, 13);
            this.radLR.TabIndex = 8;
            this.radLR.UseVisualStyleBackColor = true;
            // 
            // radLM
            // 
            this.radLM.AutoSize = true;
            this.radLM.Location = new System.Drawing.Point(45, 54);
            this.radLM.Name = "radLM";
            this.radLM.Size = new System.Drawing.Size(14, 13);
            this.radLM.TabIndex = 7;
            this.radLM.UseVisualStyleBackColor = true;
            // 
            // radLL
            // 
            this.radLL.AutoSize = true;
            this.radLL.Location = new System.Drawing.Point(25, 54);
            this.radLL.Name = "radLL";
            this.radLL.Size = new System.Drawing.Size(14, 13);
            this.radLL.TabIndex = 6;
            this.radLL.UseVisualStyleBackColor = true;
            // 
            // radMR
            // 
            this.radMR.AutoSize = true;
            this.radMR.Location = new System.Drawing.Point(65, 35);
            this.radMR.Name = "radMR";
            this.radMR.Size = new System.Drawing.Size(14, 13);
            this.radMR.TabIndex = 5;
            this.radMR.UseVisualStyleBackColor = true;
            // 
            // radMM
            // 
            this.radMM.AutoSize = true;
            this.radMM.Checked = true;
            this.radMM.Location = new System.Drawing.Point(45, 35);
            this.radMM.Name = "radMM";
            this.radMM.Size = new System.Drawing.Size(14, 13);
            this.radMM.TabIndex = 4;
            this.radMM.TabStop = true;
            this.radMM.UseVisualStyleBackColor = true;
            // 
            // radML
            // 
            this.radML.AutoSize = true;
            this.radML.Location = new System.Drawing.Point(25, 35);
            this.radML.Name = "radML";
            this.radML.Size = new System.Drawing.Size(14, 13);
            this.radML.TabIndex = 3;
            this.radML.UseVisualStyleBackColor = true;
            // 
            // radUR
            // 
            this.radUR.AutoSize = true;
            this.radUR.Location = new System.Drawing.Point(65, 16);
            this.radUR.Name = "radUR";
            this.radUR.Size = new System.Drawing.Size(14, 13);
            this.radUR.TabIndex = 2;
            this.radUR.UseVisualStyleBackColor = true;
            // 
            // radUM
            // 
            this.radUM.AutoSize = true;
            this.radUM.Location = new System.Drawing.Point(45, 16);
            this.radUM.Name = "radUM";
            this.radUM.Size = new System.Drawing.Size(14, 13);
            this.radUM.TabIndex = 1;
            this.radUM.UseVisualStyleBackColor = true;
            // 
            // radUL
            // 
            this.radUL.AutoSize = true;
            this.radUL.Location = new System.Drawing.Point(25, 16);
            this.radUL.Name = "radUL";
            this.radUL.Size = new System.Drawing.Size(14, 13);
            this.radUL.TabIndex = 0;
            this.radUL.UseVisualStyleBackColor = true;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(141, 190);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(52, 13);
            this.label6.TabIndex = 26;
            this.label6.Text = "BG Color:";
            // 
            // picBg
            // 
            this.picBg.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picBg.Location = new System.Drawing.Point(203, 190);
            this.picBg.Name = "picBg";
            this.picBg.Size = new System.Drawing.Size(40, 20);
            this.picBg.TabIndex = 28;
            this.picBg.TabStop = false;
            this.picBg.Click += new System.EventHandler(this.picBg_Click);
            // 
            // txtToDir
            // 
            this.txtToDir.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtToDir.Location = new System.Drawing.Point(96, 40);
            this.txtToDir.Name = "txtToDir";
            this.txtToDir.Size = new System.Drawing.Size(388, 20);
            this.txtToDir.TabIndex = 30;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 43);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(68, 13);
            this.label5.TabIndex = 29;
            this.label5.Text = "To Directory:";
            // 
            // btnDraw
            // 
            this.btnDraw.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnDraw.Location = new System.Drawing.Point(490, 240);
            this.btnDraw.Name = "btnDraw";
            this.btnDraw.Size = new System.Drawing.Size(75, 23);
            this.btnDraw.TabIndex = 10;
            this.btnDraw.Text = "Draw";
            this.btnDraw.UseVisualStyleBackColor = true;
            this.btnDraw.Click += new System.EventHandler(this.btnDraw_Click);
            // 
            // btnSave
            // 
            this.btnSave.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnSave.Location = new System.Drawing.Point(490, 269);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 23);
            this.btnSave.TabIndex = 31;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(577, 432);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.txtToDir);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.picBg);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.txtMargin);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.btnDraw);
            this.Controls.Add(this.picImage);
            this.Controls.Add(this.txtMessage);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btnPickFont);
            this.Controls.Add(this.lblSample);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnList);
            this.Controls.Add(this.txtFromDir);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lstFiles);
            this.Name = "Form1";
            this.Text = "howto_label_at_bottom";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.picImage)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picBg)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox lstFiles;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtFromDir;
        private System.Windows.Forms.Button btnList;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblSample;
        private System.Windows.Forms.Button btnPickFont;
        private System.Windows.Forms.FontDialog fdFont;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtMessage;
        private System.Windows.Forms.PictureBox picImage;
        private System.Windows.Forms.TextBox txtMargin;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton radLR;
        private System.Windows.Forms.RadioButton radLM;
        private System.Windows.Forms.RadioButton radLL;
        private System.Windows.Forms.RadioButton radMR;
        private System.Windows.Forms.RadioButton radMM;
        private System.Windows.Forms.RadioButton radML;
        private System.Windows.Forms.RadioButton radUR;
        private System.Windows.Forms.RadioButton radUM;
        private System.Windows.Forms.RadioButton radUL;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.PictureBox picBg;
        private System.Windows.Forms.ColorDialog cdBackground;
        private System.Windows.Forms.TextBox txtToDir;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnDraw;
        private System.Windows.Forms.Button btnSave;
    }
}


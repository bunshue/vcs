﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.IO;
using System.Drawing.Imaging;
using System.Media;

namespace howto_label_at_bottom
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string src_dir = Path.Combine(Application.StartupPath, "..\\..");
            DirectoryInfo dir_info = new DirectoryInfo(src_dir);
            txtFromDir.Text = dir_info.FullName + "\\Images";
            txtToDir.Text = dir_info.FullName + "\\Labeled";
            picBg.BackColor = lblSample.BackColor;
        }

        private void btnList_Click(object sender, EventArgs e)
        {
            try
            {
                ListFiles();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void ListFiles()
        {
            lstFiles.Items.Clear();

            DirectoryInfo dir_info = new DirectoryInfo(txtFromDir.Text);
            foreach (FileInfo file_info in dir_info.GetFiles())
            {
                string extension = file_info.Extension.ToLower();
                if ((extension == ".png") ||
                    (extension == ".jpg") ||
                    (extension == ".gif") ||
                    (extension == ".tiff") ||
                    (extension == ".jpeg"))
                {
                    lstFiles.Items.Add(file_info);
                }
            }
        }

        private void btnPickFont_Click(object sender, EventArgs e)
        {
            fdFont.Font = lblSample.Font;
            fdFont.Color = lblSample.ForeColor;
            if (fdFont.ShowDialog() == DialogResult.OK)
            {
                lblSample.Font = fdFont.Font;
                lblSample.ForeColor = fdFont.Color;
            }
        }

        private void lstFiles_SelectedIndexChanged(object sender, EventArgs e)
        {
            FileInfo file_info = lstFiles.SelectedItem as FileInfo;
            picImage.Image = LoadBitmapUnlocked(file_info.FullName);
        }

        // Load a bitmap without locking it.
        private Bitmap LoadBitmapUnlocked(string file_name)
        {
            using (Bitmap bm = new Bitmap(file_name))
            {
                return new Bitmap(bm);
            }
        }

        // Save the file with the appropriate format.
        public void SaveImage(Image image, string filename)
        {
            string extension = Path.GetExtension(filename);
            switch (extension.ToLower())
            {
                case ".bmp":
                    image.Save(filename, ImageFormat.Bmp);
                    break;
                case ".exif":
                    image.Save(filename, ImageFormat.Exif);
                    break;
                case ".gif":
                    image.Save(filename, ImageFormat.Gif);
                    break;
                case ".jpg":
                case ".jpeg":
                    image.Save(filename, ImageFormat.Jpeg);
                    break;
                case ".png":
                    image.Save(filename, ImageFormat.Png);
                    break;
                case ".tif":
                case ".tiff":
                    image.Save(filename, ImageFormat.Tiff);
                    break;
                default:
                    throw new NotSupportedException(
                        "Unknown file extension " + extension);
            }
        }

        private void btnDraw_Click(object sender, EventArgs e)
        {
            ApplyLabel();
        }

        // Add the label to the image.
        private void ApplyLabel()
        {
            FileInfo file_info = lstFiles.SelectedItem as FileInfo;
            if (file_info == null) return;

            using (Bitmap bm = LoadBitmapUnlocked(file_info.FullName))
            {
                picImage.Image = LabelBitmap(bm);
            }
        }

        // Add the label to the image.
        private Bitmap LabelBitmap(Bitmap bm)
        {
            int label_height = 0;
            try
            {
                label_height = int.Parse(txtMargin.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return null;
            }

            Bitmap new_bm = new Bitmap(bm.Width, bm.Height + label_height);
            Rectangle rect = new Rectangle(
                0, bm.Height, bm.Width, label_height);
            using (StringFormat sf = GetStringFormat())
            {
                using (Graphics gr = Graphics.FromImage(new_bm))
                {
                    gr.DrawImage(bm, 0, 0);

                    using (SolidBrush brush = new SolidBrush(lblSample.BackColor))
                    {
                        gr.FillRectangle(brush,rect);

                        brush.Color = lblSample.ForeColor;
                        gr.DrawString(txtMessage.Text, lblSample.Font,
                            brush, rect, sf);
                    }
                }
            }

            return new_bm;
        }

        private StringFormat GetStringFormat()
        {
            StringFormat sf = new StringFormat();
            if (radUL.Checked || radUM.Checked || radUR.Checked)
                sf.LineAlignment = StringAlignment.Near;
            else if (radML.Checked || radMM.Checked || radMR.Checked)
                sf.LineAlignment = StringAlignment.Center;
            else if (radLL.Checked || radLM.Checked || radLR.Checked)
                sf.LineAlignment = StringAlignment.Far;

            if (radUL.Checked || radML.Checked || radLL.Checked)
                sf.Alignment = StringAlignment.Near;
            else if (radUM.Checked || radMM.Checked || radLM.Checked)
                sf.Alignment = StringAlignment.Center;
            else if (radUR.Checked || radMR.Checked || radLR.Checked)
                sf.Alignment = StringAlignment.Far;
            return sf;
        }

        // Let the user set the text's background color.
        private void picBg_Click(object sender, EventArgs e)
        {
            cdBackground.Color = lblSample.BackColor;
            if (cdBackground.ShowDialog() == DialogResult.OK)
            {
                lblSample.BackColor = cdBackground.Color;
            }
        }

        // Save the current image.
        private void btnSave_Click(object sender, EventArgs e)
        {
            if (picImage.Image == null) return;

            FileInfo file_info = lstFiles.SelectedItem as FileInfo;
            DirectoryInfo to_dir_info = new DirectoryInfo(txtToDir.Text);
            string filename = to_dir_info.FullName + "\\" + file_info.Name;
            SaveImage(picImage.Image, filename);
            SystemSounds.Beep.Play();
        }
    }
}

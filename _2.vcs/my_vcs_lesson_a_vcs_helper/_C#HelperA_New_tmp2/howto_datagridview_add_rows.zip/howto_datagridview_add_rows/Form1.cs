﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_datagridview_add_rows
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            // Create the new row.
            decimal price_each = decimal.Parse(txtPriceEach.Text);
            decimal quantity = decimal.Parse(txtQuantity.Text);
            decimal total = price_each * quantity;
            dgvValues.Rows.Add(txtItem.Text, price_each, quantity, total);

            // Get ready for the next entry.
            txtItem.Clear();
            txtPriceEach.Clear();
            txtQuantity.Clear();
            txtItem.Focus();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_initialize_arrays_and_lists
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Initialize some arrays and lists.
        private void Form1_Load(object sender, EventArgs e)
        {
            // Arrays implement IEnumerable so this syntax works.
            string[] fruits = 
            { 
                "Apple", 
                "Banana", 
                "Cherry" 
            };
            lstFruits.DataSource = fruits;

            // Lists implement IEnumerable so this syntax works.
            List<string> cookies = new List<string>() 
            { 
                "Chocolate Chip", 
                "Snickerdoodle", 
                "Peanut Butter" 
            };
            lstCookies.DataSource = cookies;

            // Classes such as Person don't implement IEnumerable
            // so you cannot simply list the property values inside
            // brackets. Instead use this syntax.
            Person[] people = 
            {
                new Person() { FirstName="Simon", LastName="Green" },
                new Person() { FirstName="Terry", LastName="Pratchett" },
                new Person() { FirstName="Eowin", LastName="Colfer" },
            };
            lstPeople.DataSource = people;
        }
    }

    // A simple Person class.
    public class Person
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }

        public override string ToString()
        {
            return FirstName + " " + LastName;
        }
    }
}

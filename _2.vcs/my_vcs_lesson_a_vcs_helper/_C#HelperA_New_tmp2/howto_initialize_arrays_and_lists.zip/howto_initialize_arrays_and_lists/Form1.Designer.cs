﻿namespace howto_initialize_arrays_and_lists
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lstPeople = new System.Windows.Forms.ListBox();
            this.lstCookies = new System.Windows.Forms.ListBox();
            this.lstFruits = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // lstPeople
            // 
            this.lstPeople.FormattingEnabled = true;
            this.lstPeople.IntegralHeight = false;
            this.lstPeople.Location = new System.Drawing.Point(264, 14);
            this.lstPeople.Name = "lstPeople";
            this.lstPeople.Size = new System.Drawing.Size(120, 95);
            this.lstPeople.TabIndex = 5;
            // 
            // lstCookies
            // 
            this.lstCookies.FormattingEnabled = true;
            this.lstCookies.IntegralHeight = false;
            this.lstCookies.Location = new System.Drawing.Point(138, 14);
            this.lstCookies.Name = "lstCookies";
            this.lstCookies.Size = new System.Drawing.Size(120, 95);
            this.lstCookies.TabIndex = 4;
            // 
            // lstFruits
            // 
            this.lstFruits.FormattingEnabled = true;
            this.lstFruits.IntegralHeight = false;
            this.lstFruits.Location = new System.Drawing.Point(12, 14);
            this.lstFruits.Name = "lstFruits";
            this.lstFruits.Size = new System.Drawing.Size(120, 95);
            this.lstFruits.TabIndex = 3;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(397, 123);
            this.Controls.Add(this.lstPeople);
            this.Controls.Add(this.lstCookies);
            this.Controls.Add(this.lstFruits);
            this.Name = "Form1";
            this.Text = "howto_initialize_arrays_and_lists";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox lstPeople;
        private System.Windows.Forms.ListBox lstCookies;
        private System.Windows.Forms.ListBox lstFruits;
    }
}


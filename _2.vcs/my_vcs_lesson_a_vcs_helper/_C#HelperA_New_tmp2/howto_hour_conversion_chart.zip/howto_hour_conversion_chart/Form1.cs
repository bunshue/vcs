﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

// Used by 
using System.Collections;

namespace howto_hour_conversion_chart
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Load the time zone lists.
        private void Form1_Load(object sender, EventArgs e)
        {
            // Select the current date.
            dtpDate.Value = DateTime.Now;

            // Initialize the time zone lists.
            foreach (TimeZoneInfo info in
                TimeZoneInfo.GetSystemTimeZones())
            {
                cboTimeZone1.Items.Add(info);
                cboTimeZone2.Items.Add(info);
            }

            // Select some defaults.
            cboTimeZone1.SelectedItem =
                FindItemContaining(cboTimeZone1.Items, "Mountain Time");
            cboTimeZone2.SelectedItem =
                FindItemContaining(cboTimeZone2.Items, "Tokyo");
        }

        // Make a conversion chart.
        private void btnMakeChart_Click(object sender, EventArgs e)
        {
            ppdChart.ShowDialog();
        }

        // Draw the chart.
        private void pdocChart_PrintPage(object sender,
            System.Drawing.Printing.PrintPageEventArgs e)
        {
            // Get the time zone information.
            TimeZoneInfo zone1 =
                cboTimeZone1.SelectedItem as TimeZoneInfo;
            TimeZoneInfo zone2 =
                cboTimeZone2.SelectedItem as TimeZoneInfo;

            // Make the chart.
            int y = e.MarginBounds.Top;
            int center_x = e.MarginBounds.Left + e.MarginBounds.Width / 2;
            int col1_left = e.MarginBounds.Left;
            int col1_right = center_x - 25;
            int col2_left = center_x + 25;
            int col2_right = e.MarginBounds.Right;
            int col_width = col1_right - col1_left;
            int col1_mid = col1_left + col_width / 2;
            int col2_mid = col2_left + col_width / 2;
            using (Font font = new Font("Times New Roman", 12, FontStyle.Bold))
            {
                // Compose the headers.
                string name1 = zone1.DisplayName;
                name1 = name1.Replace(") ", ")\n");
                name1 = name1.Replace(" (", "\n(");
                if (name1.EndsWith("\n")) name1 = 
                    name1.Substring(0, name1.Length - 1);
                string name2 = zone2.DisplayName;
                name2 = name2.Replace(") ", ")\n");
                name2 = name2.Replace(" (", "\n(");
                if (name2.EndsWith("\n")) name2 =
                    name2.Substring(0, name2.Length - 2);

                // See how big the headers will be.
                SizeF size1 = e.Graphics.MeasureString(
                    name1, font, col_width);
                SizeF size2 = e.Graphics.MeasureString(
                    name2, font, col_width);
                float header_height =
                    Math.Max(size1.Height, size2.Height);

                // Draw the headers.
                using (StringFormat sf = new StringFormat())
                {
                    sf.Alignment = StringAlignment.Center;
                    sf.LineAlignment = StringAlignment.Center;
                    RectangleF rect = new RectangleF(col1_left, y,
                        col_width, header_height);

                    e.Graphics.DrawString(name1,
                        font, Brushes.DarkBlue, rect, sf);
                    rect.X = col2_left;
                    e.Graphics.DrawString(name2,
                        font, Brushes.DarkBlue, rect, sf);
                }

                y += (int)(header_height + 10);
            }
            e.Graphics.DrawLine(Pens.Black, col1_left, y, col2_right, y);
            y += 10;

            // Draw the hour conversions.
            using (Font font = new Font("Times New Roman", 18, GraphicsUnit.Pixel))
            {
                using (StringFormat sf = new StringFormat())
                {
                    sf.Alignment = StringAlignment.Center;
                    sf.LineAlignment = StringAlignment.Near;

                    DateTime time1 = new DateTime(
                        DateTime.Now.Year,
                        DateTime.Now.Month,
                        DateTime.Now.Day,
                        0, 0, 0);
                    for (int hour = 1; hour <= 24; hour++)
                    {
                        e.Graphics.DrawString(time1.ToShortTimeString(),
                            font, Brushes.Black, col1_mid, y, sf);

                        DateTime time2 = TimeZoneInfo.ConvertTime(time1, zone1, zone2);
                        string text2 = time2.ToShortTimeString();
                        if (time1.Date < time2.Date) text2 += " (tomorrow)";
                        else if (time1.Date > time2.Date) text2 += " (yesterday)";

                        e.Graphics.DrawString(text2,
                            font, Brushes.Black, col2_mid, y, sf);
                        y += (int)(1.5f * font.Size);
                        e.Graphics.DrawLine(Pens.Black,
                            e.MarginBounds.Left, y,
                            e.MarginBounds.Right, y);
                        y += 5;
                        time1 = time1.AddHours(1);
                    }
                }
            }

            //// Draw vertical lines.
            //foreach (int x in new int[] { x1mid, x2mid, col1_left, col1_right, col2_left, col2_right })
            //{
            //    e.Graphics.DrawLine(Pens.Blue,
            //        x, e.MarginBounds.Top,
            //        x, e.MarginBounds.Bottom);
            //}
        }

        // Select an item containing the target string.
        private object FindItemContaining(IEnumerable items, string target)
        {
            foreach (object item in items)
                if (item.ToString().Contains(target))
                    return item;

            // Return null;
            return null;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Data.OleDb;

namespace howto_ad_hoc_db_commands
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // The connection object.
        private OleDbConnection Conn;

        // Prepare the connection to open later.
        private void Form1_Load(object sender, EventArgs e)
        {
            // Compose the database file name.
            // This assumes it's in the executable's directory.
            string file_name = Application.StartupPath + "\\Books.mdb";

            // Connect.
            Conn = new OleDbConnection(
                "Provider=Microsoft.ACE.OLEDB.12.0;" +
                "Data Source=" + file_name + ";" +
                "Mode=Share Deny None");

            // Select the first sample command.
            cboSamples.SelectedIndex = 0;
        }

        // Display a sample command.
        private void cboSamples_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (cboSamples.Text)
            {
                case "CREATE TABLE":
                    txtCommand.Text = "CREATE TABLE Employees(\r\n" +
                        "  FirstName TEXT(50),\r\n" +
                        "  LastName TEXT(50),\r\n" +
                        "  EmployeeId INTEGER\r\n" +
                        ")";
                    break;
                case "INSERT":
                    txtCommand.Text = "INSERT INTO Employees\r\n" +
                        "  (FirstName, LastName, EmployeeId)\r\n" +
                        "VALUES\r\n" +
                        "  ('Alice', 'Archer', 1001)";
                    break;
                case "DROP TABLE":
                    txtCommand.Text = "DROP TABLE Employees";
                    break;
            }
        }

        // Execute the command.
        private void btnExecute_Click(object sender, EventArgs e)
        {
            OleDbCommand cmd = new OleDbCommand();
            cmd.Connection = Conn;
            cmd.CommandText = txtCommand.Text;

            try
            {
                Conn.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show("Done");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error executing command.\n" + ex.Message);
            }
            finally
            {
                Conn.Close();
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_list_timezones
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Load the timezone information.
        private void Form1_Load(object sender, EventArgs e)
        {
            foreach (TimeZoneInfo info in TimeZoneInfo.GetSystemTimeZones())
                lstTimezones.Items.Add(info);
        }
    }
}

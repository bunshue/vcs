﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Drawing.Text;

namespace howto_list_fonts
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // List the installed fonts.
        private void Form1_Load(object sender, EventArgs e)
        {
            InstalledFontCollection fonts = new InstalledFontCollection();
            foreach (FontFamily font_family in fonts.Families)
            {
                lstFonts.Items.Add(font_family.Name);
            }

            // Select the first font.
            lstFonts.SelectedIndex = 0;
        }

        // Display a sample of the selected font.
        private void ShowSample()
        {
            // Compose the font style.
            FontStyle font_style = FontStyle.Regular;
            if (chkBold.Checked) font_style |= FontStyle.Bold;
            if (chkItalic.Checked) font_style |= FontStyle.Italic;
            if (chkUnderline.Checked) font_style |= FontStyle.Underline;
            if (chkStrikeout.Checked) font_style |= FontStyle.Strikeout;

            // Get the font size.
            float font_size = 8;
            try
            {
                font_size = float.Parse(txtSize.Text);
            }
            catch
            {
            }

            // Get the font family name.
            string family_name = "Times New Roman";
            if (!(lstFonts.SelectedItem == null))
                family_name = lstFonts.SelectedItem.ToString();

            // Set the sample's font.
            txtSample.Font = new Font(family_name, font_size, font_style);
        }

        // If something changes, display a new sample of the selected font.
        // This event handler catches all of the events for controls
        // that influence the font's properties.
        private void SomethingChanged(object sender, EventArgs e)
        {
            ShowSample();
        }
    }
}

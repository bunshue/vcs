﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Drawing.Text;

namespace howto_list_installed_fonts
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // List the available fonts.
        private void Form1_Load(object sender, EventArgs e)
        {
            // List the font families.
            InstalledFontCollection installedFonts = new InstalledFontCollection();
            foreach (FontFamily fontFamily in installedFonts.Families)
            {
                lstFonts.Items.Add(fontFamily.Name);
            }

            // Select the first font.
            lstFonts.SelectedIndex = 0;
        }

        // Display a sample of the selected font.
        private void lstFonts_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Display the font family's name.
            lblSample.Text = lstFonts.Text;

            // Use the font family.
            Font font = MakeFont(lstFonts.Text, 20, FontStyle.Regular);
            if (font == null) font = MakeFont(lstFonts.Text, 20, FontStyle.Bold);
            if (font == null) font = MakeFont(lstFonts.Text, 20, FontStyle.Italic);
            if (font == null) font = MakeFont(lstFonts.Text, 20, FontStyle.Strikeout);
            if (font == null) font = MakeFont(lstFonts.Text, 20, FontStyle.Underline);

            if (font != null) lblSample.Font = font;
        }

        // Make a font with the given family name, size, and style.
        private Font MakeFont(string family, float size, FontStyle style)
        {
            try
            {
                return new Font(family, size, style);
            }
            catch
            {
                return null;
            }
        }
    }
}

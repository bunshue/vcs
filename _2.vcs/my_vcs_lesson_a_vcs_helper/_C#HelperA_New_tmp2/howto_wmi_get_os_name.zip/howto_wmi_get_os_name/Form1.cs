﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

// Add a reference to System.Management.
using System.Management;

namespace howto_wmi_get_os_name
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Display the operating system's name.
        private void Form1_Load(object sender, EventArgs e)
        {
            // Get the OS information.
            // For more information from this query, see:
            //      http://msdn.microsoft.com/library/aa394239.aspx
            string os_query = "SELECT * FROM Win32_OperatingSystem";
            ManagementObjectSearcher os_searcher =
                new ManagementObjectSearcher(os_query);
            foreach (ManagementObject info in os_searcher.Get())
            {
                lblCaption.Text = info.Properties["Caption"].Value.ToString().Trim();
                lblVersion.Text = "Version " +
                    info.Properties["Version"].Value.ToString() +
                    " SP " +
                    info.Properties["ServicePackMajorVersion"].Value.ToString() + "." +
                    info.Properties["ServicePackMinorVersion"].Value.ToString();
            }

            // Get number of processors.
            // For more information from this query, see:
            //      http://msdn.microsoft.com/library/aa394373.aspx
            string cpus_query = "SELECT * FROM Win32_ComputerSystem";
            ManagementObjectSearcher cpus_searcher =
                new ManagementObjectSearcher(cpus_query);
            foreach (ManagementObject info in cpus_searcher.Get())
            {
                lblCpus.Text = info.Properties["NumberOfLogicalProcessors"].Value.ToString()
                    + " processors";
            }

            // Get 32- versus 64-bit.
            // For more information from this query, see:
            //      http://msdn.microsoft.com/library/aa394373.aspx
            string proc_query = "SELECT * FROM Win32_Processor";
            ManagementObjectSearcher proc_searcher =
                new ManagementObjectSearcher(proc_query);
            foreach (ManagementObject info in proc_searcher.Get())
            {
                lblBits.Text = info.Properties["AddressWidth"].Value.ToString() + "-bit";
            }
        }
    }
}

﻿namespace howto_product_signs
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.label1 = new System.Windows.Forms.Label();
            this.txtXmin = new System.Windows.Forms.TextBox();
            this.txtXmax = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btnPrint = new System.Windows.Forms.Button();
            this.pdocSigns = new System.Drawing.Printing.PrintDocument();
            this.ppdSigns = new System.Windows.Forms.PrintPreviewDialog();
            this.txtYmax = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtYmin = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.clbProducts = new System.Windows.Forms.CheckedListBox();
            this.btnAll = new System.Windows.Forms.Button();
            this.btnNone = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.radGrid = new System.Windows.Forms.RadioButton();
            this.radSpacedGrid = new System.Windows.Forms.RadioButton();
            this.radCutMarks = new System.Windows.Forms.RadioButton();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 287);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(33, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Xmin:";
            // 
            // txtXmin
            // 
            this.txtXmin.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.txtXmin.Location = new System.Drawing.Point(48, 284);
            this.txtXmin.Name = "txtXmin";
            this.txtXmin.Size = new System.Drawing.Size(42, 20);
            this.txtXmin.TabIndex = 1;
            this.txtXmin.Text = "0.5";
            this.txtXmin.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtXmax
            // 
            this.txtXmax.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.txtXmax.Location = new System.Drawing.Point(135, 284);
            this.txtXmax.Name = "txtXmax";
            this.txtXmax.Size = new System.Drawing.Size(42, 20);
            this.txtXmax.TabIndex = 2;
            this.txtXmax.Text = "10.5";
            this.txtXmax.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(96, 287);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(36, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Xmax:";
            // 
            // btnPrint
            // 
            this.btnPrint.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnPrint.Enabled = false;
            this.btnPrint.Location = new System.Drawing.Point(194, 295);
            this.btnPrint.Name = "btnPrint";
            this.btnPrint.Size = new System.Drawing.Size(75, 23);
            this.btnPrint.TabIndex = 5;
            this.btnPrint.Text = "Print";
            this.btnPrint.UseVisualStyleBackColor = true;
            this.btnPrint.Click += new System.EventHandler(this.btnPrint_Click);
            // 
            // pdocSigns
            // 
            this.pdocSigns.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.pdocSigns_PrintPage);
            this.pdocSigns.BeginPrint += new System.Drawing.Printing.PrintEventHandler(this.pdocSigns_BeginPrint);
            // 
            // ppdSigns
            // 
            this.ppdSigns.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.ppdSigns.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.ppdSigns.ClientSize = new System.Drawing.Size(400, 300);
            this.ppdSigns.Enabled = true;
            this.ppdSigns.Icon = ((System.Drawing.Icon)(resources.GetObject("ppdSigns.Icon")));
            this.ppdSigns.Name = "ppdSigns";
            this.ppdSigns.Visible = false;
            // 
            // txtYmax
            // 
            this.txtYmax.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.txtYmax.Location = new System.Drawing.Point(135, 310);
            this.txtYmax.Name = "txtYmax";
            this.txtYmax.Size = new System.Drawing.Size(42, 20);
            this.txtYmax.TabIndex = 4;
            this.txtYmax.Text = "6.0";
            this.txtYmax.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(96, 313);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(36, 13);
            this.label3.TabIndex = 7;
            this.label3.Text = "Ymax:";
            // 
            // txtYmin
            // 
            this.txtYmin.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.txtYmin.Location = new System.Drawing.Point(48, 310);
            this.txtYmin.Name = "txtYmin";
            this.txtYmin.Size = new System.Drawing.Size(42, 20);
            this.txtYmin.TabIndex = 3;
            this.txtYmin.Text = "1.0";
            this.txtYmin.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label4
            // 
            this.label4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(9, 313);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(33, 13);
            this.label4.TabIndex = 5;
            this.label4.Text = "Ymin:";
            // 
            // clbProducts
            // 
            this.clbProducts.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.clbProducts.CheckOnClick = true;
            this.clbProducts.FormattingEnabled = true;
            this.clbProducts.IntegralHeight = false;
            this.clbProducts.Location = new System.Drawing.Point(12, 12);
            this.clbProducts.Name = "clbProducts";
            this.clbProducts.Size = new System.Drawing.Size(179, 171);
            this.clbProducts.TabIndex = 6;
            this.clbProducts.ItemCheck += new System.Windows.Forms.ItemCheckEventHandler(this.clbProducts_ItemCheck);
            // 
            // btnAll
            // 
            this.btnAll.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnAll.Location = new System.Drawing.Point(197, 12);
            this.btnAll.Name = "btnAll";
            this.btnAll.Size = new System.Drawing.Size(75, 23);
            this.btnAll.TabIndex = 8;
            this.btnAll.Text = "All";
            this.btnAll.UseVisualStyleBackColor = true;
            this.btnAll.Click += new System.EventHandler(this.btnAll_Click);
            // 
            // btnNone
            // 
            this.btnNone.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnNone.Location = new System.Drawing.Point(197, 41);
            this.btnNone.Name = "btnNone";
            this.btnNone.Size = new System.Drawing.Size(75, 23);
            this.btnNone.TabIndex = 9;
            this.btnNone.Text = "None";
            this.btnNone.UseVisualStyleBackColor = true;
            this.btnNone.Click += new System.EventHandler(this.btnNone_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.Controls.Add(this.radCutMarks);
            this.groupBox1.Controls.Add(this.radSpacedGrid);
            this.groupBox1.Controls.Add(this.radGrid);
            this.groupBox1.Location = new System.Drawing.Point(12, 189);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(179, 89);
            this.groupBox1.TabIndex = 10;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Dividers";
            // 
            // radGrid
            // 
            this.radGrid.AutoSize = true;
            this.radGrid.Checked = true;
            this.radGrid.Location = new System.Drawing.Point(25, 19);
            this.radGrid.Name = "radGrid";
            this.radGrid.Size = new System.Drawing.Size(44, 17);
            this.radGrid.TabIndex = 0;
            this.radGrid.TabStop = true;
            this.radGrid.Text = "Grid";
            this.radGrid.UseVisualStyleBackColor = true;
            // 
            // radSpacedGrid
            // 
            this.radSpacedGrid.AutoSize = true;
            this.radSpacedGrid.Location = new System.Drawing.Point(25, 42);
            this.radSpacedGrid.Name = "radSpacedGrid";
            this.radSpacedGrid.Size = new System.Drawing.Size(84, 17);
            this.radSpacedGrid.TabIndex = 1;
            this.radSpacedGrid.TabStop = true;
            this.radSpacedGrid.Text = "Spaced Grid";
            this.radSpacedGrid.UseVisualStyleBackColor = true;
            // 
            // radCutMarks
            // 
            this.radCutMarks.AutoSize = true;
            this.radCutMarks.Location = new System.Drawing.Point(25, 65);
            this.radCutMarks.Name = "radCutMarks";
            this.radCutMarks.Size = new System.Drawing.Size(73, 17);
            this.radCutMarks.TabIndex = 2;
            this.radCutMarks.TabStop = true;
            this.radCutMarks.Text = "Cut Marks";
            this.radCutMarks.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AcceptButton = this.btnPrint;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 342);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnNone);
            this.Controls.Add(this.btnAll);
            this.Controls.Add(this.clbProducts);
            this.Controls.Add(this.txtYmax);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtYmin);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.btnPrint);
            this.Controls.Add(this.txtXmax);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtXmin);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "howto_product_signs";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtXmin;
        private System.Windows.Forms.TextBox txtXmax;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnPrint;
        private System.Drawing.Printing.PrintDocument pdocSigns;
        private System.Windows.Forms.PrintPreviewDialog ppdSigns;
        private System.Windows.Forms.TextBox txtYmax;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtYmin;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.CheckedListBox clbProducts;
        private System.Windows.Forms.Button btnAll;
        private System.Windows.Forms.Button btnNone;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton radGrid;
        private System.Windows.Forms.RadioButton radCutMarks;
        private System.Windows.Forms.RadioButton radSpacedGrid;
    }
}


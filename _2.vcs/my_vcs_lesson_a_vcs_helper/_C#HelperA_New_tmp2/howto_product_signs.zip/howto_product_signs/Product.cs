﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace howto_product_signs
{
    public class Product
    {
        public string Name;
        public decimal Price;
        public Product(string name, decimal price)
        {
            Name = name;
            Price = price;
        }

        public override string ToString()
        {
            return Name + " (" + Price.ToString("c") + ")";
        }
    }
}

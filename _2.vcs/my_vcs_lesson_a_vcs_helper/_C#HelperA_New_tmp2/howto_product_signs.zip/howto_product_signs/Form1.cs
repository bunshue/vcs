﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Drawing.Drawing2D;

namespace howto_product_signs
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private const int CELL_MARGIN = 5;
        private const float NAME_SIZE = 30;
        private const float PRICE_SIZE = 18;

        private List<Product> Products = new List<Product>();
        private int Xmin, Xmax, Ymin, Ymax, CellWid, CellHgt;
        private int NextProductNum = 0;

        // Load the data.
        private void Form1_Load(object sender, EventArgs e)
        {
            // Cake slices.
            string[] cakes =
            {
                "Black Forest Cake",
                "Strawberry Chocolate Mousse Cake",
                "Chocolate Mousse Cake",
                "Carrot Cake",
                "Raspberry Mousse Cake",
                "Chestnut Cream Cake",
                "Strawberry Vanilla Cake",
                "Coconut Mango Cake",
                "Chocolate Ganache Cake",
                "German Chocolate Cake",
                "Tres Leches Cake",
                "Jiggly Cheesecake",
                "Tiramisu",
                "Matcha Tiramisu",
            };
            foreach (string cake in cakes)
            {
                Products.Add(new Product(cake, 5.49m));
            }

            // Croissants.
            Products.Add(new Product("Plain Croissant", 2.49m));
            Products.Add(new Product("Mini Plain Croissant", 1.49m));
            Products.Add(new Product("Almond Croissant", 3.49m));
            Products.Add(new Product("Mini Almond Croissant", 2.49m));
            Products.Add(new Product("Chocolate Croissant", 3.49m));
            Products.Add(new Product("Mini Chocolate Croissant", 2.49m));
            Products.Add(new Product("Pecan Croissant", 3.49m));
            Products.Add(new Product("Mini Pecan Croissant", 2.49m));

            string[] fruits =
            {
                "Cherry",
                "Apple",
                "Pear",
                "Raspberry",
                "Strawberry Custard",
                "Raspberry Custard",
                "Blueberry Custard",
                "Strawberry Cream Cheese",
                "Raspberry Cream Cheese",
            };
            foreach (string fruit in fruits)
            {
                Products.Add(new Product(fruit + " Croissant", 3.99m));
            }
            Products.Add(new Product("Mini Fruit Croissant", 2.49m));

            // Rolls.
            Products.Add(new Product("Cinnamon Roll", 3.49m));
            Products.Add(new Product("Chicken Alfredo Croissant", 3.99m));

            // Savory croissants.
            Products.Add(new Product("Chicken Alfredo Croissant", 3.99m));
            Products.Add(new Product("Tomato Mozzarella Croissant", 3.99m));
            Products.Add(new Product("Spinach Mushroom Croissant", 3.99m));
            Products.Add(new Product("Ham, Egg, & Cheese Croissant", 3.99m));
            Products.Add(new Product("Sausage, Egg, & Cheese Croissant", 3.99m));
            Products.Add(new Product("Pork Bun", 3.99m));
            Products.Add(new Product("Curry Bun", 3.99m));

            // Cookies.
            Products.Add(new Product("Florentine (Almond Cookie)", 1.99m));
            Products.Add(new Product("Shortbread Cookie", 1.99m));
            Products.Add(new Product("Oreo Truffle", 1.99m));
            Products.Add(new Product("Macaron", 2.99m));

            // Other.
            Products.Add(new Product("Puff Pastry", 3.49m));
            Products.Add(new Product("Mini Puff Pastry", 1.99m));

            clbProducts.DataSource = Products;
        }

        private void btnPrint_Click(object sender, EventArgs e)
        {
            ppdSigns.Document = pdocSigns;
            ppdSigns.ClientSize = new Size(700, 600);
            ppdSigns.ShowDialog();
        }

        private void pdocSigns_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            DrawPage(e.Graphics);
            e.HasMorePages = (NextProductNum < clbProducts.CheckedItems.Count);
        }

        private void DrawPage(Graphics gr)
        {
            // Draw the products.
            DrawProduct(gr, 0);
            DrawProduct(gr, 1);
            DrawProduct(gr, 2);

            if (radGrid.Checked)
            {
                // Draw the grid.
                int x = Xmin;
                int y = Ymin;
                for (int i = 0; i < 3; i++)
                {
                    gr.DrawLine(Pens.Black, x, y, Xmax, y);
                    y += CellHgt;
                }
                for (int i = 0; i < 4; i++)
                {
                    gr.DrawLine(Pens.Black, x, Ymin, x, Ymax);
                    x += CellWid;
                }
            }
            else if (radSpacedGrid.Checked)
            {
                // Draw the spaced grid.
                for (int r = 0; r < 2; r++)
                {
                    int y = Ymin + r * CellHgt;
                    for (int c = 0; c < 3; c++)
                    {
                        int x = Xmin + c * CellWid;
                        Rectangle rect = new Rectangle(
                            x + CELL_MARGIN, y + CELL_MARGIN,
                            CellWid - 2 * CELL_MARGIN,
                            CellHgt - 2 * CELL_MARGIN);
                        gr.DrawRectangle(Pens.Black, rect);
                    }
                }
            }
            else
            {
                // Draw cut marks.
                const int tic = 5;
                for (int i = 0; i < 3; i++)
                {
                    float y = Ymin + i * CellHgt;
                    float[] xs = { Xmin, Xmin + CellWid, Xmin + 2 * CellWid, Xmax };
                    foreach (float x in xs)
                    {
                        gr.DrawLine(Pens.Black, x - tic, y, x + tic, y);
                    }
                }
                for (int i = 0; i < 4; i++)
                {
                    float x = Xmin + i * CellWid;
                    float[] ys = { Ymin, Ymin + CellHgt, Ymax };
                    foreach (float y in ys)
                    {
                        gr.DrawLine(Pens.Black, x, y - tic, x, y + tic);
                    }
                }
            }
        }

        // Draw this product.
        private void DrawProduct(Graphics gr, int col_num)
        {
            if (NextProductNum >= clbProducts.CheckedItems.Count) return;

            Product product =
                clbProducts.CheckedItems[NextProductNum] as Product;

            // *****************
            // Draw upside down.
            // *****************
            // Draw the price upside down.
            RectangleF rect;
            rect = new RectangleF(
                Xmin + col_num * CellWid,
                Ymin,
                CellWid, CellHgt * 0.25f);
            rect.Inflate(-CELL_MARGIN, -CELL_MARGIN);
            DrawText(gr, PRICE_SIZE, rect, 180,
                product.Price.ToString("c"));

            // Draw the name upside down.
            rect = new RectangleF(
                Xmin + col_num * CellWid,
                Ymin + CellHgt * 0.5f,
                CellWid, CellHgt * 0.5f);
            rect.Inflate(-CELL_MARGIN, -CELL_MARGIN);
            DrawText(gr, NAME_SIZE, rect, 180,
                product.Name);

            // Draw the divider upside down.
            rect = new RectangleF(
                Xmin + col_num * CellWid,
                Ymin + CellHgt * 0.25f,
                CellWid, CellHgt * 0.25f);
            DrawDivider(gr, rect, 180, Properties.Resources.divider);

            // *******************
            // Draw right-side up.
            // *******************
            // Draw the name right-side up.
            rect = new RectangleF(
                Xmin + col_num * CellWid,
                Ymin + CellHgt,
                CellWid, CellHgt * 0.5f);
            rect.Inflate(-CELL_MARGIN, -CELL_MARGIN);
            DrawText(gr, NAME_SIZE, rect, 0,
                product.Name);

            // Draw the price right-side up.
            rect = new RectangleF(
                Xmin + col_num * CellWid,
                Ymin + CellHgt + CellHgt * 0.75f,
                CellWid, CellHgt * 0.25f);
            rect.Inflate(-CELL_MARGIN, -CELL_MARGIN);
            DrawText(gr, PRICE_SIZE, rect, 0,
                product.Price.ToString("c"));

            // Draw the divider right-side up.
            rect = new RectangleF(
                Xmin + col_num * CellWid,
                Ymin + CellHgt + CellHgt * 0.5f,
                CellWid, CellHgt / 4);
            DrawDivider(gr, rect, 0, Properties.Resources.divider);

            // Prepare to draw the next product.
            NextProductNum++;
        }

        private void DrawText(Graphics gr, float font_size,
            RectangleF rect, float angle, string text)
        {
            using (StringFormat sf = new StringFormat())
            {
                sf.Alignment = StringAlignment.Center;
                sf.LineAlignment = StringAlignment.Center;

                GraphicsState state = gr.Save();
                gr.ResetTransform();

                RectangleF drawing_rect = new RectangleF(
                    -rect.Width / 2f, -rect.Height / 2f,
                    rect.Width, rect.Height);
                gr.RotateTransform(angle);
                gr.TranslateTransform(
                    rect.X + rect.Width / 2f,
                    rect.Y + rect.Height / 2f,
                    MatrixOrder.Append);

                // Try smaller fonts until the text fits.
                int wid = (int)rect.Width;
                for (float f_size = font_size; f_size > 6; f_size -= 0.5f)
                {
                    using (Font font = new Font("Times New Roman", f_size))
                    {
                        // See if the text will fit.
                        SizeF size = gr.MeasureString(text, font, wid, sf);
                        if (size.Height <= rect.Height)
                        {
                            gr.DrawString(text, font, Brushes.Black, drawing_rect, sf);
                            if (f_size < font_size)
                                Console.WriteLine("Font size: " + f_size.ToString());
                            break;
                        }
                    }
                }

                gr.Restore(state);
            }
        }

        private void DrawDivider(Graphics gr,
            RectangleF rect, float angle, Image image)
        {
            GraphicsState state = gr.Save();
            gr.ResetTransform();

            float wid = rect.Width;
            float hgt = rect.Height;
            if (wid / hgt > image.Width / image.Height)
            {
                // The rectangle is too short and wide. Make it narrower.
                wid = hgt * (image.Width / image.Height);
            }
            else
            {
                // The rectangle is too tall and thin. Make it shorter.
                hgt = wid / (image.Width / image.Height);
            }
            RectangleF dest_rect = new RectangleF(
                -wid / 2f, -hgt / 2f, wid, hgt);

            gr.RotateTransform(angle);
            gr.TranslateTransform(
                rect.X + rect.Width / 2f,
                rect.Y + rect.Height / 2f,
                MatrixOrder.Append);
            gr.DrawImage(image, dest_rect);

            gr.Restore(state);
        }

        private void pdocSigns_BeginPrint(object sender, System.Drawing.Printing.PrintEventArgs e)
        {
            float xmin = float.Parse(txtXmin.Text);
            float xmax = float.Parse(txtXmax.Text);
            float ymin = float.Parse(txtYmin.Text);
            float ymax = float.Parse(txtYmax.Text);
            Xmin = (int)(xmin * 100);
            Xmax = (int)(xmax * 100);
            Ymin = (int)(ymin * 100);
            Ymax = (int)(ymax * 100);
            CellWid = (int)(100 * (xmax - xmin) / 3f);
            CellHgt = (int)(100 * (ymax - ymin) / 2f);

            pdocSigns.DefaultPageSettings.Margins =
                new System.Drawing.Printing.Margins(50, 50, 50, 50);
            pdocSigns.DefaultPageSettings.Landscape = true;

            NextProductNum = 0;
        }

        private void btnAll_Click(object sender, EventArgs e)
        {
            CheckUncheckAll(true);
        }

        private void btnNone_Click(object sender, EventArgs e)
        {
            CheckUncheckAll(false);
        }

        private void CheckUncheckAll(bool check)
        {
            for (int i = 0; i < clbProducts.Items.Count; i++)
            {
                clbProducts.SetItemChecked(i, check);
            }
        }

        private void clbProducts_ItemCheck(object sender, ItemCheckEventArgs e)
        {
            if (clbProducts.CheckedItems.Count == 1 &&
                e.NewValue == CheckState.Unchecked)
            {
                // The collection is about to be empty.
                btnPrint.Enabled = false;
            }
            else
            {
                // The collection is about to be non-empty.
                btnPrint.Enabled = true;
            }
        }
    }
}

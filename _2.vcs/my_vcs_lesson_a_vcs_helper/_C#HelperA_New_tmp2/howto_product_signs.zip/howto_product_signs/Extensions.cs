﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Drawing;

namespace howto_product_signs
{
    public static class Extensions
    {
        public static void DrawRectangle(this Graphics graphics,
            Pen pen, RectangleF rectangle)
        {
            graphics.DrawRectangle(pen,
                rectangle.X, rectangle.Y,
                rectangle.Width, rectangle.Height);
        }
    }
}

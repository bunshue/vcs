﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Reflection;

namespace howto_invoke_method_by_name
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Invoke the method.
        private void btnInvoke_Click(object sender, EventArgs e)
        {
            try
            {
                Type this_type = this.GetType();
                MethodInfo method_info = this_type.GetMethod(txtMethodName.Text);
                method_info.Invoke(this, null);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        // The public methods to invoke.
        public void Method1()
        {
            MessageBox.Show("This is Method 1");
        }
        public void Method2()
        {
            MessageBox.Show("This is Method 2");
        }
    }
}

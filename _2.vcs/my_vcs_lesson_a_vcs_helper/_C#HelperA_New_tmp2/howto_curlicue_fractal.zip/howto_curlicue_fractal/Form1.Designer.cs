﻿namespace howto_curlicue_fractal
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Label1 = new System.Windows.Forms.Label();
            this.cboS = new System.Windows.Forms.ComboBox();
            this.btnGo = new System.Windows.Forms.Button();
            this.txtS = new System.Windows.Forms.TextBox();
            this.picCanvas = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.picCanvas)).BeginInit();
            this.SuspendLayout();
            // 
            // Label1
            // 
            this.Label1.Location = new System.Drawing.Point(5, 6);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(24, 16);
            this.Label1.TabIndex = 2;
            this.Label1.Text = "S =";
            // 
            // cboS
            // 
            this.cboS.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboS.Items.AddRange(new object[] {
            "Pi",
            "ln(2)",
            "e",
            "Sqrt(2)",
            "Sqrt(3)",
            "Sqrt(5)",
            "Lambda",
            "Golden Ratio",
            "Feigenbaum"});
            this.cboS.Location = new System.Drawing.Point(163, 3);
            this.cboS.Name = "cboS";
            this.cboS.Size = new System.Drawing.Size(112, 21);
            this.cboS.TabIndex = 7;
            this.cboS.SelectedIndexChanged += new System.EventHandler(this.cboS_SelectedIndexChanged);
            // 
            // btnGo
            // 
            this.btnGo.Location = new System.Drawing.Point(123, 3);
            this.btnGo.Name = "btnGo";
            this.btnGo.Size = new System.Drawing.Size(32, 23);
            this.btnGo.TabIndex = 6;
            this.btnGo.Text = "Go";
            this.btnGo.Click += new System.EventHandler(this.btnGo_Click);
            // 
            // txtS
            // 
            this.txtS.Location = new System.Drawing.Point(35, 3);
            this.txtS.Name = "txtS";
            this.txtS.Size = new System.Drawing.Size(80, 20);
            this.txtS.TabIndex = 5;
            this.txtS.Text = "3.14159265";
            // 
            // picCanvas
            // 
            this.picCanvas.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.picCanvas.BackColor = System.Drawing.Color.Black;
            this.picCanvas.Location = new System.Drawing.Point(12, 32);
            this.picCanvas.Name = "picCanvas";
            this.picCanvas.Size = new System.Drawing.Size(616, 641);
            this.picCanvas.TabIndex = 8;
            this.picCanvas.TabStop = false;
            this.picCanvas.Resize += new System.EventHandler(this.picCanvas_Resize);
            this.picCanvas.Paint += new System.Windows.Forms.PaintEventHandler(this.picCanvas_Paint);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(640, 685);
            this.Controls.Add(this.picCanvas);
            this.Controls.Add(this.cboS);
            this.Controls.Add(this.btnGo);
            this.Controls.Add(this.txtS);
            this.Controls.Add(this.Label1);
            this.Name = "Form1";
            this.Text = "howto_curlicue_fractal";
            ((System.ComponentModel.ISupportInitialize)(this.picCanvas)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.Label Label1;
        internal System.Windows.Forms.ComboBox cboS;
        internal System.Windows.Forms.Button btnGo;
        internal System.Windows.Forms.TextBox txtS;
        private System.Windows.Forms.PictureBox picCanvas;
    }
}


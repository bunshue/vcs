﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Drawing.Drawing2D;

// See "Curlicue Fractal" by Eric W. Weisstein.
// From MathWorld--A Wolfram Web Resource. http://mathworld.wolfram.com/CurlicueFractal.html 

namespace howto_curlicue_fractal
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Redraw.
        private void btnGo_Click(object sender, EventArgs e)
        {
            picCanvas.Invalidate();
        }

        // Redraw.
        private void picCanvas_Resize(object sender, EventArgs e)
        {
            picCanvas.Invalidate();
        }

        // Draw the curve.
        private void picCanvas_Paint(object sender, PaintEventArgs e)
        {
            DrawCurlicue(e.Graphics);
        }

        // Draw the newly selected curve.
        private void cboS_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (cboS.Text.ToLower())
            {
                case "pi":
                    txtS.Text = Math.PI.ToString();
                    break;
                case "ln(2)":
                    txtS.Text = Math.Log(2).ToString();
                    break;
                case "e":
                    txtS.Text = Math.E.ToString();
                    break;
                case "sqrt(2)":
                    txtS.Text = Math.Sqrt(2).ToString();
                    break;
                case "sqrt(3)":
                    txtS.Text = Math.Sqrt(3).ToString();
                    break;
                case "sqrt(5)":
                    txtS.Text = Math.Sqrt(5).ToString();
                    break;
                case "lambda":
                    txtS.Text = "0.577215664901532860606512090082402431042";
                    break;
                case "golden ratio":
                    txtS.Text = "1.618033988749894848204586834365638117720";
                    break;
                case "feigenbaum":
                    txtS.Text = "4.6692016091029906718532038204662016172581855774757686327456513430041343302113147371386897440239480138";
                    break;
            }
            picCanvas.Invalidate();
        }

        // Draw the curve.
        private void DrawCurlicue(Graphics gr)
        {
            const int scale = 2;
            gr.ScaleTransform(
                scale,
                scale,
                MatrixOrder.Append);
            gr.TranslateTransform(
                picCanvas.ClientSize.Width / 2,
                picCanvas.ClientSize.Width / 2,
                MatrixOrder.Append);

            double s = double.Parse(txtS.Text);
            double theta, phi, x0, y0, x1, y1;
            theta = 0;
            phi = 0;
            x0 = 0;
            y0 = 0;

            // Use a zero-width pen so it draws as thin as possible
            // even after scaling.
            using (Pen thin_pen = new Pen(Color.Red, 0))
            {
                for (int i = 1; i <= 10000; i++)
                {
                    x1 = x0 + Math.Cos(phi);
                    y1 = y0 + Math.Sin(phi);
                    gr.DrawLine(thin_pen, (float)x0, (float)-y0, (float)x1, (float)-y1);
                    x0 = x1;
                    y0 = y1;

                    phi = (theta + phi) % (2 * Math.PI);
                    theta = (theta + 2 * Math.PI * s) % (2 * Math.PI);
                }
            }
        }
    }
}

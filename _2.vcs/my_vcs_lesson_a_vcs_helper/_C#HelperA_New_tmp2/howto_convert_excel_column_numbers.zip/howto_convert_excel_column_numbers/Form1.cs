﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_convert_excel_column_numbers
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Convert to column number and back.
        private void txtLetter_TextChanged(object sender, EventArgs e)
        {
            // Don't bother if there's no text.
            if (txtLetter.Text.Length < 1) return;

            // Convert to a number.
            int col_num = ColumnNameToNumber(txtLetter.Text);

            // Convert back.
            string col_name = ColumnNumberToName(col_num);

            txtNumber.Text = col_num.ToString();
            txtNewLetter.Text = col_name;
        }

        // Return the column number for this column name.
        private int ColumnNameToNumber(string col_name)
        {
            int result = 0;

            // Process each letter.
            for (int i = 0; i < col_name.Length; i++)
            {
                result *= 26;
                char letter = col_name[i];

                // See if it's out of bounds.
                if (letter < 'A') letter = 'A';
                if (letter > 'Z') letter = 'Z';

                // Add in the value of this letter.
                result += (int)letter - (int)'A' + 1;
            }
            return result;
        }

        // Return the column name for this column number.
        private string ColumnNumberToName(int col_num)
        {
            // See if it's out of bounds.
            if (col_num < 1) return "A";

            // Calculate the letters.
            string result = "";
            while (col_num > 0)
            {
                // Get the least significant digit.
                col_num -= 1;
                int digit = col_num % 26;

                // Convert the digit into a letter.
                result = (char)((int)'A' + digit) + result;

                col_num = (int)(col_num / 26);
            }

            return result;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_radio_toolstrip_buttons
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Arrays of exclusive tools.
        private ToolStripButton[] ShapeTools, ColorTools;

        // Initialize the exclusive tool arrays.
        private void Form1_Load(object sender, EventArgs e)
        {
            // Prepare the shape tools.
            ShapeTools = new ToolStripButton[]
            {
                toolArrow,
                toolPolygon,
                toolCircle,
                toolDiamond
            };
            foreach (ToolStripButton btn in ShapeTools)
            {
                btn.Click += toolShape_Click;
            }

            // Prepare the color tools.
            ColorTools = new ToolStripButton[]
            {
                toolRed,
                toolBlue,
                toolYellow,
                toolLime
            };
            foreach (ToolStripButton btn in ColorTools)
            {
                btn.Click += toolColor_Click;
            }
        }

        // Allow only one shape selection at a time.
        private void toolShape_Click(object sender, EventArgs e)
        {
            SelectToolStripButton(sender as ToolStripButton, ShapeTools);
        }

        // Allow only one color selection at a time.
        private void toolColor_Click(object sender, EventArgs e)
        {
            SelectToolStripButton(sender as ToolStripButton, ColorTools);
        }

        // Select the indicated button and deselect the others.
        private void SelectToolStripButton(ToolStripButton selected_button, ToolStripButton[] buttons)
        {
            foreach (ToolStripButton test_button in buttons)
            {
                test_button.Checked = (test_button == selected_button);
            }
        }

        // Tool event handlers.
        private void tool_Click(object sender, EventArgs e)
        {
            ToolStripButton btn = sender as ToolStripButton;
            Console.WriteLine(btn.Text);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_visualize_odd_primes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnGo_Click(object sender, EventArgs e)
        {
            txtNumPrimes.Clear();
            picBitmap.Image = null;
            picBitmap.Refresh();
            Cursor = Cursors.WaitCursor;

            // Make a sieve.
            int num_rows = int.Parse(txtNumRows.Text);
            int num_cols = int.Parse(txtNumColumns.Text);
            if (num_cols % 2 != 0) num_cols++;  // Make it even.

            int length = 2 * num_rows * num_cols;
            bool[] is_prime = MakeSieve(length);

            // Make the bitmap.
            Bitmap bm = MakeBitmap(is_prime, num_cols, num_rows);

            // Display the result.
            picBitmap.Image = bm;

            // Display the number of primes.
            int num_primes = 0;
            for (int i = 3; i < length; i++)
                if (is_prime[i]) num_primes++;
            txtNumPrimes.Text = num_primes.ToString();

            Cursor = Cursors.Default;
        }

        // Build Euler's Sieve.
        private bool[] MakeSieve(int max)
        {
            // Make an array indicating whether numbers are prime.
            bool[] is_prime = new bool[max + 1];
            is_prime[2] = true;
            for (int i = 3; i <= max; i += 2) is_prime[i] = true;

            // Cross out multiples of odd primes.
            for (int p = 3; p <= max; p += 2)
            {
                // See if i is prime.
                if (is_prime[p])
                {
                    // Knock out multiples of p.
                    int max_q = max / p;
                    if (max_q % 2 == 0) max_q--;    // Make it odd.
                    for (int q = max_q; q >= p; q -= 2)
                    {
                        // Only use q if it is prime.
                        if (is_prime[q]) is_prime[p * q] = false;
                    }
                }
            }
            return is_prime;
        }

        // Make a bitmap showing the primes.
        private Bitmap MakeBitmap(bool[] is_prime, int wid, int hgt)
        {
            // Make the bitmap.
            Bitmap bm = new Bitmap(wid, hgt);

            // Set the pixels.
            int index = 1;
            for (int y = 0; y < hgt; y++)
            {
                for (int x = 0; x < wid; x++)
                {
                    if (is_prime[index])
                        bm.SetPixel(x, y, Color.Red);
                    else
                        bm.SetPixel(x, y, Color.Black);
                    index += 2;
                }
            }

            // Fix 1.
            bm.SetPixel(0, 0, Color.Blue);

            return bm;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_font_preview2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // At design time, set the dialog's ShowApply
        // property to true.

        // Display the dialog.
        private void btnSelectFont_Click(object sender, EventArgs e)
        {
            // Save the original font.
            Font original_font = this.Font;

            // Initialize the dialog.
            fdFont.Font = this.Font;

            // Display the dialog and check the result.
            if (fdFont.ShowDialog() == DialogResult.OK)
            {
                // Apply the selected font.
                if (!this.Font.ValueEquals(fdFont.Font))
                    this.Font = fdFont.Font;
            }
            else
            {
                // Restore the original font.
                if (!this.Font.ValueEquals(original_font))
                    this.Font = original_font;
            }
        }

        // Apply the font.
        private void fdFont_Apply(object sender, EventArgs e)
        {
            this.Font = fdFont.Font;
        }
    }
}

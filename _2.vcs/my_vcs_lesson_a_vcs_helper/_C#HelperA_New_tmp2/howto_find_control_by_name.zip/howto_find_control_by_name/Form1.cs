﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_find_control_by_name
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Find the indicated control and set its text.
        private void button1_Click(object sender, EventArgs e)
        {
            // Find the control.
            Control ctl = FindControl(this, textBox1.Text);
            if (ctl==null)
            {
                MessageBox.Show("Could not find control '" +
                    textBox1.Text + "'");
                return;                    
            }

            // Set its Text property.
            ctl.Text = textBox2.Text;
        }

        // Recursively find the named control.
        private Control FindControl(Control parent, string name)
        {
            // Check the parent.
            if (parent.Name == name) return parent;

            // Recursively search the parent's children.
            foreach (Control ctl in parent.Controls)
            {
                Control found = FindControl(ctl, name);
                if (found != null) return found;
            }

            // If we still haven't found it, it's not here.
            return null;
        }
    }
}

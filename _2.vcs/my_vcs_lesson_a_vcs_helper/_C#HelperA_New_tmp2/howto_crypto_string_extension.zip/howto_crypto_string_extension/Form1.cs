﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using CryptoStuffNamespace;

namespace howto_crypto_string_extension
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Encrypt the text.
        private void btnEncrypt_Click(object sender, EventArgs e)
        {
            byte[] bytes = txtPlaintext.Text.Encrypt(txtPassword.Text);
            txtCiphertext.Text = bytes.ToHex();
        }

        // Decrypt the text.
        private void btnDecrypt_Click(object sender, EventArgs e)
        {
            byte[] ciphertext = txtCiphertext.Text.ToBytes();
            txtDeciphered.Text = ciphertext.Decrypt(txtPassword.Text);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_adjust_splitter
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCloseLeft_Click(object sender, EventArgs e)
        {
            SplitContainer1.Panel1Collapsed = true;
        }

        private void btnLeft25_Click(object sender, EventArgs e)
        {
            SplitContainer1.Panel1Collapsed = false;
            SplitContainer1.Panel2Collapsed = false;
            SplitContainer1.SplitterDistance = (int)(SplitContainer1.ClientSize.Width * 0.25);
        }

        private void btnLeft50_Click(object sender, EventArgs e)
        {
            SplitContainer1.Panel1Collapsed = false;
            SplitContainer1.Panel2Collapsed = false;
            SplitContainer1.SplitterDistance = (int)(SplitContainer1.ClientSize.Width * 0.5);
        }

        private void btnRight25_Click(object sender, EventArgs e)
        {
            SplitContainer1.Panel1Collapsed = false;
            SplitContainer1.Panel2Collapsed = false;
            SplitContainer1.SplitterDistance = (int)(SplitContainer1.ClientSize.Width * 0.75);
        }

        private void btnCloseRight_Click(object sender, EventArgs e)
        {
            SplitContainer1.Panel2Collapsed = true;
        }
    }
}

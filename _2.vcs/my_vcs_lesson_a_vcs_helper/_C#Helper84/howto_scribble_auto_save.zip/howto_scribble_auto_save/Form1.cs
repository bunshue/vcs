﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Drawing.Drawing2D;
using System.Xml.Serialization;
using System.IO;

namespace howto_scribble_auto_save
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // The polylines we draw.
        private List<Polyline> Polylines = new List<Polyline>();

        // The new polyline we are drawing.
        private Polyline NewPolyline = null;

        // The currently selected drawing parameters.
        private Color DrawingColor = Color.Black;
        private int DrawingThickness = 1;
        private DashStyle DrawingDashStyle = DashStyle.Solid;

        // The auto-save file name.
        private string AutoSaveFile = Path.GetTempPath() + "scribble.tmp";

        // Look for an auto-save file.
        private void Form1_Load(object sender, EventArgs e)
        {
            Console.WriteLine(AutoSaveFile);

            // See if the file exists.
            if (File.Exists(AutoSaveFile))
            {
                // Ask the user if we should load this file.
                if (MessageBox.Show("An auto-save file exists. Do you want to load it?",
                    "Restore?", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
                    == DialogResult.Yes)
                {
                    // Load the file.
                    LoadFromFile(AutoSaveFile);
                }
            }
        }

        // Remove the auto-save file.
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (File.Exists(AutoSaveFile)) File.Delete(AutoSaveFile);
        }

        // Auto-save.
        private void AutoSave()
        {
            SaveIntoFile(AutoSaveFile);
        }

        // Halt immediately.
        private void toolBomb_Click(object sender, EventArgs e)
        {
            throw new Exception();
        }

        // Select the appropriate color.
        private void ColorTool_Click(object sender, EventArgs e)
        {
            ToolStripMenuItem tool = sender as ToolStripMenuItem;
            toolColor.Image = tool.Image;
            DrawingColor = tool.ForeColor;
        }

        // Select the line thickness.
        private void ThicknessTool_Click(object sender, EventArgs e)
        {
            ToolStripMenuItem tool = sender as ToolStripMenuItem;
            toolThick.Image = tool.Image;
            DrawingThickness = int.Parse(tool.Text);
        }

        // Select the dash style.
        private void StyleTool_Click(object sender, EventArgs e)
        {
            ToolStripMenuItem tool = sender as ToolStripMenuItem;
            toolStyle.Image = tool.Image;
            switch (tool.Text)
            {
                case "Solid":
                    DrawingDashStyle = DashStyle.Solid;
                    break;
                case "Dash":
                    DrawingDashStyle = DashStyle.Dash;
                    break;
                case "Dot":
                    DrawingDashStyle = DashStyle.Dot;
                    break;
                case "Custom":
                    DrawingDashStyle = DashStyle.Custom;
                    break;
            }
        }

        // Start drawing.
        private void picCanvas_MouseDown(object sender, MouseEventArgs e)
        {
            // Create the new polyline.
            NewPolyline = new Polyline();
            Polylines.Add(NewPolyline);

            // Initialize it and add the first point.
            NewPolyline.Color = DrawingColor;
            NewPolyline.Thickness = DrawingThickness;
            NewPolyline.DashStyle = DrawingDashStyle;
            NewPolyline.Points.Add(e.Location);
        }

        // Continue drawing.
        private void picCanvas_MouseMove(object sender, MouseEventArgs e)
        {
            if (NewPolyline == null) return;
            NewPolyline.Points.Add(e.Location);
            picCanvas.Refresh();
        }

        // Stop drawing.
        private void picCanvas_MouseUp(object sender, MouseEventArgs e)
        {
            if (NewPolyline == null) return;

            // See if the new polyline contains more than 1 point.
            if (NewPolyline.Points.Count < 2)
            {
                // Remove it.
                Polylines.RemoveAt(Polylines.Count - 1);
            }

            // Redraw.
            NewPolyline = null;
            picCanvas.Refresh();

            // Save a new snapshot in the undo list.
            SaveSnapshot(true);
        }

        // Redraw.
        private void picCanvas_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
            e.Graphics.Clear(picCanvas.BackColor);

            // Draw the polylines.
            foreach (Polyline polyline in Polylines)
            {
                polyline.Draw(e.Graphics);
            }
        }

        // Exit.
        private void mnuFileExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        // Start a new drawing.
        private void mnuFileNew_Click(object sender, EventArgs e)
        {
            Polylines = new List<Polyline>();
            picCanvas.Refresh();

            // Save a new snapshot in the undo list.
            UndoList = new Stack<string>();
            RedoList = new Stack<string>();
            SaveSnapshot(true);
        }

        // Save the drawing.
        private void mnuFileSaveAs_Click(object sender, EventArgs e)
        {
            if (sfdFile.ShowDialog() == DialogResult.OK)
            {
                SaveIntoFile(sfdFile.FileName);
            }
        }

        // Save the current picture into a file.
        private void SaveIntoFile(string filename)
        {
            XmlSerializer xml_serializer = new XmlSerializer(Polylines.GetType());
            using (StreamWriter stream_writer = new StreamWriter(filename))
            {
                xml_serializer.Serialize(stream_writer, Polylines);
                stream_writer.Close();
            }
        }

        // Open a saved drawing.
        private void mnuFileOpen_Click(object sender, EventArgs e)
        {
            if (ofdFile.ShowDialog() == DialogResult.OK)
            {
                LoadFromFile(ofdFile.FileName);
            }
        }

        // Load a saved picture from a file.
        private void LoadFromFile(string filename)
        {
            try
            {
                XmlSerializer xml_serializer = new XmlSerializer(Polylines.GetType());
                using (FileStream file_stream = new FileStream(filename, FileMode.Open))
                {
                    List<Polyline> new_polylines =
                        (List<Polyline>)xml_serializer.Deserialize(file_stream);
                    Polylines = new_polylines;
                    picCanvas.Refresh();

                    // Save a new snapshot in the undo list.
                    UndoList = new Stack<string>();
                    RedoList = new Stack<string>();
                    SaveSnapshot(false);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        // The undo and redo history lists.
        private Stack<string> UndoList = new Stack<string>();
        private Stack<string> RedoList = new Stack<string>();

        // Save a snapshot in the undo list.
        private void SaveSnapshot(bool auto_save)
        {
            // Save the snapshot.
            UndoList.Push(GetSnapshot());

            // Empty the redo list.
            if (RedoList.Count > 0) RedoList = new Stack<string>();

            // Enable or disable the Undo and Redo menu items.
            EnableUndo();

            // Auto-save.
            if (auto_save) AutoSave();
        }

        // Enable or disable the Undo and Redo menu items.
        private void EnableUndo()
        {
            mnuEditUndo.Enabled = (UndoList.Count > 0);
            mnuEditRedo.Enabled = (RedoList.Count > 0);
        }

        // Return an XML serialization of the current drawing.
        private string GetSnapshot()
        {
            XmlSerializer xml_serializer = new XmlSerializer(Polylines.GetType());
            using (StringWriter string_writer = new StringWriter())
            {
                xml_serializer.Serialize(string_writer, Polylines);
                return string_writer.ToString();
            }
        }

        // Use an XML serialization to load a drawing.
        private void RestoreTopUndoItem()
        {
            if (UndoList.Count == 0)
            {
                // The undo list is empty. Display a blank drawing.
                Polylines = new List<Polyline>();
            }
            else
            {
                // Restore the first serialization from the undo list.
                XmlSerializer xml_serializer = new XmlSerializer(Polylines.GetType());
                using (StringReader string_reader = new StringReader(UndoList.Peek()))
                {
                    List<Polyline> new_polylines =
                        (List<Polyline>)xml_serializer.Deserialize(string_reader);
                    Polylines = new_polylines;
                }
            }
            picCanvas.Refresh();

            // Auto-save.
            AutoSave();
        }

        // Undo.
        private void mnuEditUndo_Click(object sender, EventArgs e)
        {
            // Move the most recent change to the redo list.
            RedoList.Push(UndoList.Pop());

            // Restore the top item in the Undo list.
            RestoreTopUndoItem();

            // Enable or disable the Undo and Redo menu items.
            EnableUndo();
        }

        // Redo.
        private void mnuEditRedo_Click(object sender, EventArgs e)
        {
            // Move the most recently undone item back to the undo list.
            UndoList.Push(RedoList.Pop());

            // Restore the top item in the Undo list.
            RestoreTopUndoItem();

            // Enable or disable the Undo and Redo menu items.
            EnableUndo();
        }
    }
}

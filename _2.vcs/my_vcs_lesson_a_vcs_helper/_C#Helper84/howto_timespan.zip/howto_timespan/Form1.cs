﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_timespan
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Start with a sample date.
        private void Form1_Load(object sender, EventArgs e)
        {
            txtDate.Text = "1 April 2000, 23:45";
        }

        // If the text is a date, display
        // the elapsed time between then and now.
        private void txtDate_TextChanged(object sender, EventArgs e)
        {
            DateTime date;
            if (DateTime.TryParse(txtDate.Text, out date))
            {
                txtParsed.Text = date.ToString();

                TimeSpan elapsed = DateTime.Now - date;
                txtDays.Text = elapsed.TotalDays.ToString();
                txtHours.Text = elapsed.TotalHours.ToString();
                txtMinutes.Text = elapsed.TotalMinutes.ToString();
                txtSeconds.Text = elapsed.TotalSeconds.ToString();
            }
            else
            {
                txtParsed.Clear();
                txtDays.Clear();
                txtHours.Clear();
                txtMinutes.Clear();
                txtSeconds.Clear();
            }
        }
    }
}

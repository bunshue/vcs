﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_calculate_pi
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            txtActual.Text = Math.PI.ToString();
        }

        // Calculate Pi.
        private void btnCalculate_Click(object sender, EventArgs e)
        {
            txtCalculated.Clear();
            txtDifference.Clear();
            Refresh();

            double pi_over_4 = 0;
            int num_terms = int.Parse(txtNumTerms.Text);
            double sign = 1;
            for (int term = 0; term < num_terms; term++)
            {
                //Console.WriteLine(sign + " / " + (term * 2 + 1) + " = " +
                //    (1.0 / (term * 2 + 1)));
                pi_over_4 += sign / (term * 2 + 1);
                sign *= -1;
            }

            // Display the result.
            double pi = 4 * pi_over_4;
            txtCalculated.Text = pi.ToString();
            txtDifference.Text = (Math.PI - pi).ToString();
        }
    }
}

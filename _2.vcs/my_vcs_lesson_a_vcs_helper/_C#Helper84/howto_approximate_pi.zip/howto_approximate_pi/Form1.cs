﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_approximate_pi
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            int num_terms = int.Parse(txtNumTerms.Text);

            DisplayValue(Math.PI, txtMathPi, txtMathPiError);
            DisplayValue(GregoryLeibnizPi(num_terms), txtGregoryLeibniz, txtGregoryLeibnizError);
            DisplayValue(NilakanthaPi(num_terms), txtNilakantha, txtNilakanthaError);
            DisplayValue(NewtonPi(num_terms), txtNewton, txtNewtonError);
            DisplayValue(ArcsinePi(num_terms), txtArcsine, txtArcsineError);
            DisplayValue(355.0 / 113.0, txt355_113, txt355_113Error);
        }

        // Display a value for pi and its error from Math.PI.
        private void DisplayValue(double pi, TextBox txtValue, TextBox txtError)
        {
            txtValue.Text = pi.ToString("F15");
            double error = Math.PI - pi;
            txtError.Text = error.ToString("E");
        }

#region Gregory-Leibniz

        // Gregory-Leibniz series.
        // Pi/4 = Sum(-1^k/(2k+1))
        private double GregoryLeibnizPi(long num_terms)
        {
            double result = 0;
            double sign = 1;
            for (int term = 0; term < num_terms; term++)
            {
                result += sign / (term * 2 + 1);
                sign *= -1;
            }
            return 4 * result;
        }

#endregion

#region Newton

        // Newton series.
        // Pi/2 = Sum(k!/(2k+1)!!)
        private double NewtonPi(int num_terms)
        {
            double result = 0;
            for (int k = 0; k < num_terms; k++)
                result += Factorial(k) / OddProd(2 * k + 1);
            return result * 2;
        }

        // Return n!
        private double Factorial(long n)
        {
            double result = 1;
            for (long i = 2; i <= n; i++) result *= i;
            return result;
        }

        // Return the product of the odd integers up to the number.
        private double OddProd(long n)
        {
            double result = 1;
            for (long i = 3; i <= n; i += 2) result *= i;
            return result;
        }


#endregion Newton

#region Nilakantha

        // Nilakantha series.
        // Pi/2 = Sum(-1^k/(2k+2)(2k+3)(2k+4))
        private double NilakanthaPi(int num_terms)
        {
            double result = 0;
            double sign = 1;
            for (int i=0; i<num_terms; i++)
            {
                result += sign / (2 * i + 2) / (2 * i + 3) / (2 * i + 4);
                sign = -sign;
            }
            return 3 + result * 4;
        }

#endregion Nilakantha

#region Arcsine

        // Arcsine series.
        // Pi = Sum(3*(2n choose n) / 16^n (2*n+1))
        private double ArcsinePi(int num_terms)
        {
            double result = 0;
            for (int i = 0; i < num_terms; i++)
                result += 3 * Choose(2 * i, i)
                    / Math.Pow(16, i)
                    / (2 * i + 1);
            return result;
        }

        // Return n choose k.
        private double Choose(int n, int k)
        {
            double result = 1;
            for (int i = 1; i <= k; i++)
            {
                result *= n - (k - i);
                result /= i;
            }
            return result;
        }

#endregion Arcsine

        private double PiDigit(int d)
        {
            return d * Math.Pow(2, d) * Factorial(d) * Factorial(d)
                / Factorial(2 * d);
        }

    }
}

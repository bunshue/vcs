﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_hashset_operators
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Make some sets and perform operations on them.
        private void Form1_Load(object sender, EventArgs e)
        {
            Set<string> owns_a_car = new Set<string>();
            Set<string> owns_a_bike = new Set<string>();

            owns_a_bike.Add("Alice");
            owns_a_bike.Add("Bob");
            owns_a_bike.Add("Fred");
            owns_a_bike.Add("Dan");

            owns_a_car.Add("Cindy");
            owns_a_car.Add("Dan");
            owns_a_car.Add("Emma");
            owns_a_car.Add("Bob");
            owns_a_car.Add("Fred");

            txtOwnsABike.Text = string.Join(", ", owns_a_bike.ToArray());
            txtOwnsACar.Text = string.Join(", ", owns_a_car.ToArray());

            // Intersection.
            Set<string> owns_both = owns_a_car & owns_a_bike;
            txtOwnsBoth.Text = string.Join(", ", owns_both.ToArray());

            // Union.
            Set<string> owns_either = owns_a_car | owns_a_bike;
            txtOwnsEither.Text = string.Join(", ", owns_either.ToArray());

            // Xor.
            Set<string> owns_one = owns_a_car ^ owns_a_bike;
            txtOwnsOne.Text = string.Join(", ", owns_one.ToArray());

            // Subset.
            Set<string> set1 = new Set<string>();
            set1.Add("Cindy");
            set1.Add("Dan");
            txtSubset.Text = (set1 < owns_a_car).ToString();

            // Superset.
            Set<string> set2 = new Set<string>();
            set2.Add("Alice");
            set2.Add("Bob");
            set2.Add("Fred");
            set2.Add("Dan");
            set2.Add("Gina");
            txtSuperset.Text = (set2 > owns_a_bike).ToString();

            txtContainsAlice.Text = (owns_a_car > "Alice").ToString();
            txtContainsCindy.Text = (owns_a_car > "Cindy").ToString();
        }
    }
}

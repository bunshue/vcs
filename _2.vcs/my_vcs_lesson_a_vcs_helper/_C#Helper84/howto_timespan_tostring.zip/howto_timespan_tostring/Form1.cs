using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_timespan_tostring
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Start or stop the stopwatch.
        private DateTime StartTime;
        private void btnStart_Click(object sender, EventArgs e)
        {
            tmrClock.Enabled = !tmrClock.Enabled;
            btnStart.Text = tmrClock.Enabled ? "Stop" : "Start";
            StartTime = DateTime.Now;
        }

        // Display the new elapsed time.
        // For information on standard TimeSpan formats, see:
        //      http://msdn.microsoft.com/en-us/library/ee372286.aspx
        // For information on custom TimeSpan formats, see:
        //      http://msdn.microsoft.com/en-us/library/ee372287.aspx
        private void tmrClock_Tick(object sender, EventArgs e)
        {
            TimeSpan elapsed = DateTime.Now - StartTime;
            lblElapsed.Text = elapsed.ToString("h:mm:ss.ff");
        }
    }
}

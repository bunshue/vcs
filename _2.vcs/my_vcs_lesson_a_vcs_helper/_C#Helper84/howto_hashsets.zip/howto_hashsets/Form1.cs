﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_hashsets
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Make some sets and perform operations on them.
        private void Form1_Load(object sender, EventArgs e)
        {
            HashSet<string> owns_a_car = new HashSet<string>();
            HashSet<string> owns_a_bike = new HashSet<string>();

            owns_a_bike.Add("Alice");
            owns_a_bike.Add("Bob");
            owns_a_bike.Add("Fred");
            owns_a_bike.Add("Dan");

            owns_a_car.Add("Cindy");
            owns_a_car.Add("Dan");
            owns_a_car.Add("Emma");
            owns_a_car.Add("Bob");
            owns_a_car.Add("Fred");

            txtOwnsABike.Text = string.Join(", ", owns_a_bike.ToArray());
            txtOwnsACar.Text = string.Join(", ", owns_a_car.ToArray());

            // Intersection.
            HashSet<string> owns_both = new HashSet<string>(owns_a_car);
            owns_both.IntersectWith(owns_a_bike);
            txtOwnsBoth.Text = string.Join(", ", owns_both.ToArray());

            // Union.
            HashSet<string> owns_either = new HashSet<string>(owns_a_car);
            owns_either.UnionWith(owns_a_bike);
            txtOwnsEither.Text = string.Join(", ", owns_either.ToArray());

            // Xor.
            HashSet<string> owns_one = new HashSet<string>(owns_a_car);
            owns_one.SymmetricExceptWith(owns_a_bike);
            txtOwnsOne.Text = string.Join(", ", owns_one.ToArray());
        }
    }
}

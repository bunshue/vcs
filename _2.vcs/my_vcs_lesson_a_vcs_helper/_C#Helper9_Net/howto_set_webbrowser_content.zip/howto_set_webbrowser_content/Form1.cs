﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_set_webbrowser_content
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Start at home.
        private void Form1_Load(object sender, EventArgs e)
        {
            wbrDisplay.GoHome();
//            wbrDisplay.Navigate("about:blank");
        }

        // Set the HTML contents.
        private void btn_Click(object sender, EventArgs e)
        {
            HtmlDocument doc = wbrDisplay.Document;
            doc.Body.InnerHtml = txtHtml.Text;
        }
    }
}

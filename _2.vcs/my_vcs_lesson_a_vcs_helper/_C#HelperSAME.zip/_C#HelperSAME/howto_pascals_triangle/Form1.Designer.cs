﻿namespace howto_pascals_triangle
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.btnGo = new System.Windows.Forms.Button();
            this.ppdTriangle = new System.Windows.Forms.PrintPreviewDialog();
            this.pdocTriangle = new System.Drawing.Printing.PrintDocument();
            this.SuspendLayout();
            // 
            // btnGo
            // 
            this.btnGo.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnGo.Location = new System.Drawing.Point(105, 31);
            this.btnGo.Name = "btnGo";
            this.btnGo.Size = new System.Drawing.Size(75, 23);
            this.btnGo.TabIndex = 0;
            this.btnGo.Text = "Go";
            this.btnGo.UseVisualStyleBackColor = true;
            this.btnGo.Click += new System.EventHandler(this.btnGo_Click);
            // 
            // ppdTriangle
            // 
            this.ppdTriangle.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.ppdTriangle.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.ppdTriangle.ClientSize = new System.Drawing.Size(400, 300);
            this.ppdTriangle.Document = this.pdocTriangle;
            this.ppdTriangle.Enabled = true;
            this.ppdTriangle.Icon = ((System.Drawing.Icon)(resources.GetObject("ppdTriangle.Icon")));
            this.ppdTriangle.Name = "ppdTriangle";
            this.ppdTriangle.Visible = false;
            // 
            // pdocTriangle
            // 
            this.pdocTriangle.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.pdocTriangle_PrintPage);
            // 
            // Form1
            // 
            this.AcceptButton = this.btnGo;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 84);
            this.Controls.Add(this.btnGo);
            this.Name = "Form1";
            this.Text = "howto_pascals_triangle";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnGo;
        private System.Windows.Forms.PrintPreviewDialog ppdTriangle;
        private System.Drawing.Printing.PrintDocument pdocTriangle;
    }
}


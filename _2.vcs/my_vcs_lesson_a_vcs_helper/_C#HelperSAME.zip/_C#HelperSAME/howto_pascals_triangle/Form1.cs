﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_pascals_triangle
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Display the print preview.
        private void btnGo_Click(object sender, EventArgs e)
        {
            // pdocTriangle.PrinterSettings.PrinterName = "Dell Photo AIO Printer 926";

            pdocTriangle.DefaultPageSettings.Margins =
                new System.Drawing.Printing.Margins(50, 50, 50, 50);
            pdocTriangle.DefaultPageSettings.Landscape = true;
            ppdTriangle.ShowDialog();
        }

        // Draw the triangle.
        private void pdocTriangle_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            using (Font font = new Font("Courier New", 4))
            {
                using (StringFormat format = new StringFormat())
                {
                    // Center each line.
                    format.Alignment = StringAlignment.Center;

                    const float width_factor = 6.5f;
                    int num_wid = (int)(width_factor * e.Graphics.MeasureString("0", font).Width);
                    int num_hgt = (int)e.Graphics.MeasureString("0", font).Height;
                    int y = e.MarginBounds.Top;
                    int xmid = (e.MarginBounds.Left + e.MarginBounds.Right) / 2;

                    // Make the first row.
                    List<int> numbers = new List<int>();
                    numbers.Add(1);
  
                    // Display rows.
                    while (y < e.MarginBounds.Height)
                    {
                        int x = xmid - (num_wid * numbers.Count) / 2;
                        if (x < e.MarginBounds.Left) break;

                        // Display the current list of numbers.
                        foreach (int num in numbers)
                        {
                            e.Graphics.DrawString(num.ToString(),
                                font, Brushes.Black, x, y, format);
                            x += num_wid;
                        }

                        // Add the next number to the list.
                        List<int> new_numbers = new List<int>();
                        new_numbers.Add(1);
                        for (int i = 1; i < numbers.Count; i++)
                        {
                            new_numbers.Add(numbers[i - 1] + numbers[i]);
                        }
                        new_numbers.Add(1);
                        numbers = new_numbers;

                        y += num_hgt;
                    }
                }
            }
        }
    }
}

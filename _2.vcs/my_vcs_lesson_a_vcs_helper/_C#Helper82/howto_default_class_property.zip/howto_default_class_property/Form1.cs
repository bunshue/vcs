﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_default_class_property
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // Make a dictionary.
            DictionaryWithDefault<string, string> dict =
                new DictionaryWithDefault<string, string>("<Missing>");

            // Add some items to the dictionary.
            dict["Ann"] = "Archer";
            dict["Chuck"] = "Cider";
            dict["Dora"] = "Deevers";

            // Display some values.
            lstNames.Items.Add("Ann" + " " + dict["Ann"]);
            lstNames.Items.Add("Ben" + " " + dict["Ben"]);
            lstNames.Items.Add("Chuck" + " " + dict["Chuck"]);
            lstNames.Items.Add("Dora" + " " + dict["Dora"]);
            lstNames.Items.Add("Ed" + " " + dict["Ed"]);
        }
    }
}

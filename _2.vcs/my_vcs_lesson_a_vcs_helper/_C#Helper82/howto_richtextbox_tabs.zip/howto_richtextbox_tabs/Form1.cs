﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_richtextbox_tabs
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Set the tabs and enter some text.
        private void Form1_Load(object sender, EventArgs e)
        {
            rchItems.SelectionTabs = new int[] { 80, 160, 240 };
            rchItems.AcceptsTab = true;

            rchItems.Text =
                "Breakfast\tLunch\tDinner\n" +
                "Coffee\tSoda\tWine\n" +
                "Bagel\tSandwich\tSalad\n" +
                "Fruit\tChips\tTofuburger\n" +
                "\tCookie\tVeggies";
        }
    }
}

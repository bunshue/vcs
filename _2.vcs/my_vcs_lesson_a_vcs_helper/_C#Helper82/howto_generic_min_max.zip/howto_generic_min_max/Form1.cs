﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_generic_min_max
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private Random Rand = new Random();

        // Return the smallest of the values.
        private T Min<T>(params T[] values) where T : IComparable<T>
        {
            T min = values[0];
            for (int i = 1; i < values.Length; i++)
                if (values[i].CompareTo(min) < 0) min = values[i];
            return min;
        }

        // Return the largest of the values.
        private T Max<T>(params T[] values) where T : IComparable<T>
        {
            T max = values[0];
            for (int i = 1; i < values.Length; i++)
                if (values[i].CompareTo(max) > 0) max = values[i];
            return max;
        }

        private void goButton_Click(object sender, EventArgs e)
        {
            int A = Rand.Next(1, 100);
            int B = Rand.Next(1, 100);
            int C = Rand.Next(1, 100);
            int D = Rand.Next(1, 100);
            int E = Rand.Next(1, 100);

            txtValues.Text =
                A.ToString() + " " +
                B.ToString() + " " +
                C.ToString() + " " +
                D.ToString() + " " +
                E.ToString();
            txtMinimum.Text = Min(A, B, C, D, E).ToString();
            txtMaximum.Text = Max(A, B, C, D, E).ToString();
        }
    }
}

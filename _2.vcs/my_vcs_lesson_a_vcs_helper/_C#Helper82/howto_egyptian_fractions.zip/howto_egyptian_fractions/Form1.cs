﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_egyptian_fractions
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Calculate the Eqgyptian fraction representation
        // for the original fraction.
        private void btnGo_Click(object sender, EventArgs e)
        {
            // Get the fraction (and make it positive).
            Fraction frac = new Fraction(txtFraction.Text);
            if (frac < 0) frac = -frac;

            // Get the Egyptian fraction.
            List<Fraction> fractions = GetEgyptianFraction(frac);

            // Display the result as a string
            string result = "";
            foreach (Fraction unit_fraction in fractions)
            {
                result = result + unit_fraction.ToString() + " + ";
            }
            if (result.Length > 0) result = result.Substring(0, result.Length - 3);

            txtResult.Text = result;
        }

        // Return a string representation of the Egyptian fraction.
        private List<Fraction> GetEgyptianFraction(Fraction frac)
        {
            List<Fraction> result = new List<Fraction>();

            // Remove any whole number part.
            int whole_part = (int)(frac.Numerator / frac.Denominator);
            if (whole_part > 0)
            {
                result.Add(whole_part);
                frac = frac - whole_part;
            }

            // Pull out unit fractions.
            long denom = 2;
            while (frac > 0)
            {
                // Make the unit fraction smaller until it fits.
                Fraction unit_fraction = new Fraction(1, denom);
                while (unit_fraction > frac)
                {
                    denom++;
                    unit_fraction = new Fraction(1, denom);
                }

                // Remove the unit fraction.
                result.Add(unit_fraction);
                frac -= unit_fraction;
                denom++;
            }

            return result;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_format_richtextbox
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // Format RichTextBox1.
            richTextBox1.Select(4, 5);
            richTextBox1.SelectionColor = Color.Red;
            richTextBox1.Select(16, 3);
            richTextBox1.SelectionFont =
                new Font(richTextBox1.Font, FontStyle.Italic);
            richTextBox1.Select(35, 4);
            richTextBox1.SelectionBackColor = Color.Yellow;
            richTextBox1.SelectionColor = Color.Brown;
            richTextBox1.Select(0, 0);

            // Format RichTextBox2.
            SelectRichText(richTextBox2, "quick");
            richTextBox2.SelectionColor = Color.Red;
            SelectRichText(richTextBox2, "fox");
            richTextBox2.SelectionFont =
                new Font(richTextBox2.Font, FontStyle.Italic);
            SelectRichText(richTextBox2, "lazy");
            richTextBox2.SelectionBackColor = Color.Yellow;
            richTextBox2.SelectionColor = Color.Brown;
            richTextBox2.Select(0, 0);
        }

        // Select the indicated text.
        private void SelectRichText(RichTextBox rch, string target)
        {
            int pos = rch.Text.IndexOf(target);
            if (pos < 0)
            {
                // Not found. Select nothing.
                rch.Select(0, 0);
            }
            else
            {
                // Found the text. Select it.
                rch.Select(pos, target.Length);
            }
        }
    }
}

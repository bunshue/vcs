﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_copy_array
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Run the trials.
        private void btnGo_Click(object sender, EventArgs e)
        {
            lblForLoop.Text = "";
            lblArrayCopy.Text = "";
            Cursor = Cursors.WaitCursor;
            Application.DoEvents();

            int num_items = int.Parse(txtNumItems.Text);
            int num_trials = int.Parse(txtNumTrials.Text);

            int[] array1 = new int[num_items];
            int[] array2 = new int[num_items];

            // Initialize the first array.
            for (int i = 0; i < num_items; i++)
            {
                array1[i] = i;
            }
            DateTime start_time, stop_time;
            TimeSpan elapsed;

            // Use a for loop.
            start_time = DateTime.Now;
            for (int trial = 0; trial < num_trials; trial++)
            {
                for (int i = 0; i < num_items; i++)
                {
                    array2[i] = array1[i];
                }
            }
            stop_time = DateTime.Now;
            elapsed = stop_time - start_time;
            lblForLoop.Text = elapsed.TotalSeconds.ToString("0.00") + " seconds";
            Application.DoEvents();

            // Use Array.Copy.
            start_time = DateTime.Now;
            for (int trial = 0; trial < num_trials; trial++)
            {
                Array.Copy(array1, array2, array1.Length);
            }
            stop_time = DateTime.Now;
            elapsed = stop_time - start_time;
            lblArrayCopy.Text = elapsed.TotalSeconds.ToString("0.00") + " seconds";

            Cursor = Cursors.Default;
        }
    }
}

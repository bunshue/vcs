﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_infinite_menus
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // This menu item is opening.
        // Add an item to this item's submenu.
        private void mnuTools_DropDownOpening(object sender, EventArgs e)
        {
            Console.WriteLine("mnuTools_DropDownOpening");
            // Remove this item's event handler.
            ToolStripMenuItem menu = sender as ToolStripMenuItem;
            menu.DropDownOpening -= mnuTools_DropDownOpening;

            // Find the submenu.
            ToolStripMenuItem submenu = 
                (ToolStripMenuItem)menu.DropDownItems[0];

            // Add the sub-submenu item.
            ToolStripMenuItem new_item = new ToolStripMenuItem("&Tools");
            new_item.DropDownOpening += mnuTools_DropDownOpening;
            submenu.DropDownItems.Add(new_item);
        }
    }
}

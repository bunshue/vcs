﻿namespace howto_print_grid
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.btnPreview = new System.Windows.Forms.Button();
            this.pdocGrid = new System.Drawing.Printing.PrintDocument();
            this.ppdGrid = new System.Windows.Forms.PrintPreviewDialog();
            this.SuspendLayout();
            // 
            // btnPreview
            // 
            this.btnPreview.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.btnPreview.Location = new System.Drawing.Point(105, 43);
            this.btnPreview.Name = "btnPreview";
            this.btnPreview.Size = new System.Drawing.Size(75, 23);
            this.btnPreview.TabIndex = 0;
            this.btnPreview.Text = "Preview";
            this.btnPreview.UseVisualStyleBackColor = true;
            this.btnPreview.Click += new System.EventHandler(this.btnPreview_Click);
            // 
            // pdocGrid
            // 
            this.pdocGrid.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.pdocGrid_PrintPage);
            // 
            // ppdGrid
            // 
            this.ppdGrid.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.ppdGrid.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.ppdGrid.ClientSize = new System.Drawing.Size(400, 300);
            this.ppdGrid.Document = this.pdocGrid;
            this.ppdGrid.Enabled = true;
            this.ppdGrid.Icon = ((System.Drawing.Icon)(resources.GetObject("ppdGrid.Icon")));
            this.ppdGrid.Name = "ppdGrid";
            this.ppdGrid.Visible = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 108);
            this.Controls.Add(this.btnPreview);
            this.Name = "Form1";
            this.Text = "howto_print_grid";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnPreview;
        private System.Drawing.Printing.PrintDocument pdocGrid;
        private System.Windows.Forms.PrintPreviewDialog ppdGrid;
    }
}


﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_array_of_controls
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Arrays of controls.
        private CheckBox[] BreakfastControls, LunchControls, DinnerControls;

        // Initialize the arrays of controls.
        private void Form1_Load(object sender, EventArgs e)
        {
            BreakfastControls = new CheckBox[] { chkCereal, chkToast, chkOrangeJuice };
            LunchControls = new CheckBox[] { chkSandwhich, chkChips, chkSoda };
            DinnerControls = new CheckBox[] { chkSalad, chkTofuburger, chkWine };
        }

        // Reset the breakfast controls.
        private void btnResetBreakfast_Click(object sender, EventArgs e)
        {
            foreach (CheckBox chk in BreakfastControls)
            {
                chk.Checked = false;
            }
        }

        // Reset the lunch controls.
        private void btnResetLunch_Click(object sender, EventArgs e)
        {
            foreach (CheckBox chk in LunchControls)
            {
                chk.Checked = false;
            }
        }

        // Reset the dinner controls.
        private void btnResetDinner_Click(object sender, EventArgs e)
        {
            foreach (CheckBox chk in DinnerControls)
            {
                chk.Checked = false;
            }
        }
    }
}

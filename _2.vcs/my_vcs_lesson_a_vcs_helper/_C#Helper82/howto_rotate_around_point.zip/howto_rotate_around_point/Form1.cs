﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Drawing.Drawing2D;

namespace howto_rotate_around_point
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Draw an arrow normally and rotated around a point.
        private void picCanvas_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;

            // Draw the basic arrow.
            DrawArrow(Pens.Blue, e.Graphics);

            // Draw the point of rotation.
            Point center = new Point(50, 70);
            e.Graphics.FillEllipse(Brushes.Red, center.X - 3, center.Y - 3, 6, 6);

            // Rotate 30 degrees around the point.
            e.Graphics.Transform = RotateAroundPoint(30, center);

            // Draw the arrow rotated.
            DrawArrow(Pens.Green, e.Graphics);
        }

        // Draw an arrow.
        private void DrawArrow(Pen pen, Graphics gr)
        {
            Point[] pts = 
            {
                new Point( 50,  50),
                new Point(150,  50),
                new Point(150,  20),
                new Point(200,  70),
                new Point(150, 120),
                new Point(150,  90),
                new Point( 50,  90)
            };
            gr.DrawPolygon(pen, pts);
        }

        // Return a rotation matrix to rotate around a point.
        private Matrix RotateAroundPoint(float angle, Point center)
        {
            // Translate the point to the origin.
            Matrix result = new Matrix();
            result.RotateAt(angle, center);
            return result;
        }
    }
}

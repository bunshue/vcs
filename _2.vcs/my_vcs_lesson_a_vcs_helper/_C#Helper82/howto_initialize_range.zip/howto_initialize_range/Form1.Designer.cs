﻿namespace howto_initialize_range
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lstArrayRange = new System.Windows.Forms.ListBox();
            this.lstArrayRepeat = new System.Windows.Forms.ListBox();
            this.lstListRepeat = new System.Windows.Forms.ListBox();
            this.lstListRange = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // lstArrayRange
            // 
            this.lstArrayRange.FormattingEnabled = true;
            this.lstArrayRange.Location = new System.Drawing.Point(12, 12);
            this.lstArrayRange.Name = "lstArrayRange";
            this.lstArrayRange.Size = new System.Drawing.Size(120, 95);
            this.lstArrayRange.TabIndex = 0;
            // 
            // lstArrayRepeat
            // 
            this.lstArrayRepeat.FormattingEnabled = true;
            this.lstArrayRepeat.Location = new System.Drawing.Point(138, 12);
            this.lstArrayRepeat.Name = "lstArrayRepeat";
            this.lstArrayRepeat.Size = new System.Drawing.Size(120, 95);
            this.lstArrayRepeat.TabIndex = 1;
            // 
            // lstListRepeat
            // 
            this.lstListRepeat.FormattingEnabled = true;
            this.lstListRepeat.Location = new System.Drawing.Point(138, 113);
            this.lstListRepeat.Name = "lstListRepeat";
            this.lstListRepeat.Size = new System.Drawing.Size(120, 95);
            this.lstListRepeat.TabIndex = 3;
            // 
            // lstListRange
            // 
            this.lstListRange.FormattingEnabled = true;
            this.lstListRange.Location = new System.Drawing.Point(12, 113);
            this.lstListRange.Name = "lstListRange";
            this.lstListRange.Size = new System.Drawing.Size(120, 95);
            this.lstListRange.TabIndex = 2;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(270, 218);
            this.Controls.Add(this.lstListRepeat);
            this.Controls.Add(this.lstListRange);
            this.Controls.Add(this.lstArrayRepeat);
            this.Controls.Add(this.lstArrayRange);
            this.Name = "Form1";
            this.Text = "howto_initialize_range";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox lstArrayRange;
        private System.Windows.Forms.ListBox lstArrayRepeat;
        private System.Windows.Forms.ListBox lstListRepeat;
        private System.Windows.Forms.ListBox lstListRange;
    }
}


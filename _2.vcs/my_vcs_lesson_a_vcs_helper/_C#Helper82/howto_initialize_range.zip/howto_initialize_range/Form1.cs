﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_initialize_range
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // 101, 102, 103, ... 120.
            int[] array_range = Enumerable.Range(101, 20).ToArray<int>();
            lstArrayRange.DataSource = array_range;

            // 1001, 1002, 1003, ... 1020.
            List<int> list_range = Enumerable.Range(1001, 20).ToList<int>();
            lstListRange.DataSource = list_range;

            // 13, 13, 13, ... 13.
            int[] array_repeat = Enumerable.Repeat<int>(13, 20).ToArray();
            lstArrayRepeat.DataSource = array_repeat;

            // 1337, 1337, 1337, ... 1337.
            List<int> list_repeat = Enumerable.Repeat(1337, 20).ToList<int>();
            lstListRepeat.DataSource = list_repeat;
        }
    }
}

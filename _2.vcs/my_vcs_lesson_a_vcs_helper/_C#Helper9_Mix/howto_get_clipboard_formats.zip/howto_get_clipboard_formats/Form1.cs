﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_get_clipboard_formats
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            wbrSample.Navigate("about:blank");
        }

        // List the available formats.
        private void btnListFormats_Click(object sender, EventArgs e)
        {
            IDataObject data_object = Clipboard.GetDataObject();
            lstFormats.Items.Clear();
            foreach (string format in data_object.GetFormats())
                lstFormats.Items.Add(format);
            DisplayData();
        }

        // Display data if possible.
        private void DisplayData()
        {
            txtSample.Visible = false;
            rchSample.Visible = false;
            picSample.Visible = false;
            wbrSample.Visible = false;

            // Image.
            if (Clipboard.ContainsImage())
            {
                picSample.Image = Clipboard.GetImage();
                picSample.Visible = true;
            }

            // Text.
            if (Clipboard.ContainsText(TextDataFormat.UnicodeText))
            {
                txtSample.Text = Clipboard.GetText(TextDataFormat.UnicodeText);
                txtSample.Visible = true;
            }

            // HTML.
            if (Clipboard.ContainsText(TextDataFormat.Html))
            {
                HtmlDocument doc = wbrSample.Document;
                doc.Body.InnerHtml = Clipboard.GetText(TextDataFormat.Html);
                wbrSample.Visible = true;
            }

            // Rich Text.
            if (Clipboard.ContainsText(TextDataFormat.Rtf))
            {
                rchSample.Rtf = Clipboard.GetText(TextDataFormat.Rtf);
                rchSample.Visible = true;
            }
        }
    }
}

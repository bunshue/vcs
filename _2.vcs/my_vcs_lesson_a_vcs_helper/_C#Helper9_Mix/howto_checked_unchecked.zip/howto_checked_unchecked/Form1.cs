﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

// Checked and unchecked, even when obeyed,
// apply only to the directly enclosed code
// not code inside nested function calls.
//http://www.codeproject.com/KB/cs/overflow_checking.aspx

namespace howto_checked_unchecked
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnGo_Click(object sender, EventArgs e)
        {
            int N = int.Parse(txtN.Text);

            txtInteger.Text = IntFactorial(N);
            txtLong.Text = LongFactorial(N);
            txtDecimal.Text = DecimalFactorial(N);
            txtFloat.Text = FloatFactorial(N);
            txtDouble.Text = DoubleFactorial(N);

            txtIntegerChecked.Text = IntFactorialChecked(N);
            txtLongChecked.Text = LongFactorialChecked(N);
            txtDecimalChecked.Text = DecimalFactorialChecked(N);
            txtFloatChecked.Text = FloatFactorialChecked(N);
            txtDoubleChecked.Text = DoubleFactorialChecked(N);

            txtIntegerUnchecked.Text = IntFactorialUnchecked(N);
            txtLongUnchecked.Text = LongFactorialUnchecked(N);
            txtDecimalUnchecked.Text = DecimalFactorialUnchecked(N);
            txtFloatUnchecked.Text = FloatFactorialUnchecked(N);
            txtDoubleUnchecked.Text = DoubleFactorialUnchecked(N);
        }

        // Calculate factorials with different data types.
        private string IntFactorial(int N)
        {
            // Integer obeys checked and unchecked.
            try
            {
                int result = 1;
                for (int i = 2; i <= N; i++) result *= i;
                return result.ToString();
            }
            catch (Exception ex)
            {
                return ex.ToString();
            }
        }
        private string LongFactorial(long N)
        {
            // Long obeys checked and unchecked.
            try
            {
                long result = 1;
                for (long i = 2; i <= N; i++) result *= i;
                return result.ToString();
            }
            catch (Exception ex)
            {
                return ex.ToString();
            }
        }
        private string DecimalFactorial(decimal N)
        {
            // Decimal ignores checked and unchecked
            // and always throws OverflowException.
            try
            {
                decimal result = 1;
                for (decimal i = 2; i <= N; i++) result *= i;
                return result.ToString();
            }
            catch (Exception ex)
            {
                return ex.ToString();
            }
        }
        // Floats and doubles ignore checked and return Infinity.
        private string FloatFactorial(float N)
        {
            float result = 1;
            for (float i = 2; i <= N; i++) result *= i;
            if (float.IsInfinity(result)) return "Infinity";
            return result.ToString();
        }
        private string DoubleFactorial(double N)
        {
            double result = 1;
            for (double i = 2; i <= N; i++) result *= i;
            if (double.IsInfinity(result)) return "Infinity";
            return result.ToString();
        }

        private string IntFactorialChecked(int N)
        {
            // Integer obeys checked and unchecked.
            try
            {
                checked
                {
                    int result = 1;
                    for (int i = 2; i <= N; i++) result *= i;
                    return result.ToString();
                }
            }
            catch (Exception ex)
            {
                return ex.ToString();
            }
        }
        private string LongFactorialChecked(long N)
        {
            // Long obeys checked and unchecked.
            try
            {
                checked
                {
                    long result = 1;
                    for (long i = 2; i <= N; i++) result *= i;
                    return result.ToString();
                }
            }
            catch (Exception ex)
            {
                return ex.ToString();
            }
        }
        private string DecimalFactorialChecked(decimal N)
        {
            // Decimal ignores checked and unchecked
            // and always throws OverflowException.
            try
            {
                checked
                {
                    decimal result = 1;
                    for (decimal i = 2; i <= N; i++) result *= i;
                    return result.ToString();
                }
            }
            catch (Exception ex)
            {
                return ex.ToString();
            }
        }
        // Floats and doubles ignore checked and return Infinity.
        private string FloatFactorialChecked(float N)
        {
            checked
            {
                float result = 1;
                for (float i = 2; i <= N; i++) result *= i;
                if (float.IsInfinity(result)) return "Infinity";
                return result.ToString();
            }
        }
        private string DoubleFactorialChecked(double N)
        {
            checked
            {
                double result = 1;
                for (double i = 2; i <= N; i++) result *= i;
                if (double.IsInfinity(result)) return "Infinity";
                return result.ToString();
            }
        }

        private string IntFactorialUnchecked(int N)
        {
            // Integer obeys unchecked and ununchecked.
            try
            {
                unchecked
                {
                    int result = 1;
                    for (int i = 2; i <= N; i++) result *= i;
                    return result.ToString();
                }
            }
            catch (Exception ex)
            {
                return ex.ToString();
            }
        }
        private string LongFactorialUnchecked(long N)
        {
            // Long obeys unchecked and ununchecked.
            try
            {
                unchecked
                {
                    long result = 1;
                    for (long i = 2; i <= N; i++) result *= i;
                    return result.ToString();
                }
            }
            catch (Exception ex)
            {
                return ex.ToString();
            }
        }
        private string DecimalFactorialUnchecked(decimal N)
        {
            // Decimal ignores unchecked and ununchecked
            // and always throws OverflowException.
            try
            {
                unchecked
                {
                    decimal result = 1;
                    for (decimal i = 2; i <= N; i++) result *= i;
                    return result.ToString();
                }
            }
            catch (Exception ex)
            {
                return ex.ToString();
            }
        }
        // Floats and doubles ignore unchecked and return Infinity.
        private string FloatFactorialUnchecked(float N)
        {
            unchecked
            {
                float result = 1;
                for (float i = 2; i <= N; i++) result *= i;
                if (float.IsInfinity(result)) return "Infinity";
                return result.ToString();
            }
        }
        private string DoubleFactorialUnchecked(double N)
        {
            unchecked
            {
                double result = 1;
                for (double i = 2; i <= N; i++) result *= i;
                if (double.IsInfinity(result)) return "Infinity";
                return result.ToString();
            }
        }
    }
}

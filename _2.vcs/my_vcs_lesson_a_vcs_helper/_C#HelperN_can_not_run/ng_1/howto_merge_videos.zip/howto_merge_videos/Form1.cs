﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

// Add a references to:
//      Microsoft.Expression.Encoder
//      Microsoft.Expression.Encoder.Api2
//      Microsoft.Expression.Encoder.Types
//      Microsoft.Expression.Encoder.Utilities

using Microsoft.Expression.Encoder;
using System.IO;

namespace howto_merge_videos
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Let the user select a video to add to the file list.
        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (ofdVideo.ShowDialog() == DialogResult.OK)
            {
                lstFiles.Items.Add(ofdVideo.FileName);
                btnMerge.Enabled = (lstFiles.Items.Count >= 2);
            }
        }

        // Enable the Delete button if a file is selected.
        private void lstFiles_SelectedIndexChanged(object sender, EventArgs e)
        {
            btnRemove.Enabled = (lstFiles.SelectedIndex >= 0);
        }

        // Remove the selected file from the list.
        private void btnRemove_Click(object sender, EventArgs e)
        {
            lstFiles.Items.RemoveAt(lstFiles.SelectedIndex);
            btnMerge.Enabled = (lstFiles.Items.Count >= 2);
        }

        // Build the merged video.
        private void btnMerge_Click(object sender, EventArgs e)
        {
            if (sfdMerged.ShowDialog() != DialogResult.OK) return;
            Cursor = Cursors.WaitCursor;
            prgEncode.Value = 0;
            prgEncode.Visible = true;
            Refresh();

            try
            {
                // Create a job.
                using (Job job = new Job())
                {
                    // Make one MediaItem containing all of the sources.
                    MediaItem media_item = new MediaItem(lstFiles.Items[0].ToString());
                    job.MediaItems.Add(media_item);

                    for (int i = 1; i < lstFiles.Items.Count; i++)
                    {
                        media_item.Sources.Add(
                            new Source(lstFiles.Items[i].ToString()));
                    }

                    // Set the output directory.
                    FileInfo file_info = new FileInfo(sfdMerged.FileName);
                    job.OutputDirectory = file_info.DirectoryName;

                    // Set the output file name.
                    media_item.OutputFileName = file_info.Name;

                    // Don't create a subdirectory.
                    job.CreateSubfolder = false;

                    // Use the original size.
                    media_item.OutputFormat.VideoProfile.Size = media_item.OriginalVideoSize;

                    // Install the progress event handler.
                    job.EncodeProgress += job_EncodeProgress;

                    // Encode.
                    job.Encode();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            Cursor = Cursors.Default;
            prgEncode.Visible = false;
        }

        // Display progress.
        private void job_EncodeProgress(object sender, EncodeProgressEventArgs e)
        {
            prgEncode.Value = (int)e.Progress;
        }
    }
}


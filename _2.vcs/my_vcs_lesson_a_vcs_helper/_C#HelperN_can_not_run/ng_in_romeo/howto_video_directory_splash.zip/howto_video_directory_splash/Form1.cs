﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

// Add a references to:
//      Microsoft.Expression.Encoder
//      Microsoft.Expression.Encoder.Api2
//      Microsoft.Expression.Encoder.Types
//      Microsoft.Expression.Encoder.Utilities

using Microsoft.Expression.Encoder;
using Microsoft.Expression.Encoder.Profiles;
using System.IO;

namespace howto_video_directory_splash
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnList_Click(object sender, EventArgs e)
        {
            lstSplash.Items.Clear();
            try
            {
                foreach (string filename in Directory.GetFiles(
                    txtDirectory.Text, "* splash.wmv"))
                {
                    lstSplash.Items.Add(filename);
                }
                btnGo.Enabled = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnGo_Click(object sender, EventArgs e)
        {
            Cursor = Cursors.WaitCursor;
            Refresh();

            for (int i = 0; i < lstSplash.Items.Count; i++)
            {
                lstSplash.SelectedIndex = i;
                lstSplash.Refresh();
                MergeSplash(lstSplash.Items[i].ToString());
            }

            Cursor = Cursors.Default;
        }

        private void MergeSplash(string splash_file)
        {
            prgEncode.Value = 0;
            prgEncode.Visible = true;
            Refresh();

            try
            {
                // Create a job.
                using (Job job = new Job())
                {
                    // Make a MediaItem containing the splash video.
                    MediaItem media_item = new MediaItem(splash_file);
                    job.MediaItems.Add(media_item);

                    // Use the original size.
                    media_item.OutputFormat.VideoProfile.Size =
                        media_item.OriginalVideoSize;

                    // Restrict the splash video to 5 seconds.
                    media_item.Sources[0].Clips[0].EndTime =
                        new TimeSpan(0, 0, 5);

                    // Add the movie.
                    string base_name = splash_file.Replace(" splash", " base");
                    media_item.Sources.Add(new Source(base_name));

                    // Set the quality.
                    media_item.OutputFormat.VideoProfile.Bitrate =
                        new VariableQualityBitrate(90);

                    // Set the output directory.
                    FileInfo file_info = new FileInfo(splash_file);
                    job.OutputDirectory = file_info.DirectoryName;

                    // Set the output file name.
                    media_item.OutputFileName = file_info.Name.Replace(" splash", "");

                    // Don't create a subdirectory.
                    job.CreateSubfolder = false;

                    // Install the progress event handler.
                    job.EncodeProgress += job_EncodeProgress;

                    // Encode.
                    job.Encode();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            prgEncode.Visible = false;
        }

        // Display progress.
        private void job_EncodeProgress(object sender, EncodeProgressEventArgs e)
        {
            prgEncode.Value = (int)e.Progress;
        }
    }
}

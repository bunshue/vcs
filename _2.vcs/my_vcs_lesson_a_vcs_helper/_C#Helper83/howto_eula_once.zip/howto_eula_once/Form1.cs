﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_eula_once
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // See if the user has already accepted the EULA.
            if (RegistryTools.GetSetting(
                "howto_eula_once", "EulaIsAccepted", "False").ToString()
                    != "True")
            {
                // Display the EULA.
                EulaForm frm = new EulaForm();
                if (frm.ShowDialog() == DialogResult.OK)
                {
                    // Remember that the user accepted the EULA.
                    RegistryTools.SaveSetting(
                        "howto_eula_once", "EulaIsAccepted", "True");                
                }
                else
                {
                    // The user declined. Close the program.
                    this.Close();
                    return;
                }
            }

            // Perform other initialization stuff.

        }
    }
}

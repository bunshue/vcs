﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace howto_wpf_global_commands
{
    /// <summary>
    /// Interaction logic for SecondaryWindow.xaml
    /// </summary>
    public partial class SecondaryWindow : Window
    {
        public SecondaryWindow()
        {
            InitializeComponent();
        }

        public Window1 MainWindow;

        private void ToggleAllow_Click(object sender, RoutedEventArgs e)
        {
            MainWindow.AllowChangeBackground =
                !MainWindow.AllowChangeBackground;
        }
    }
}

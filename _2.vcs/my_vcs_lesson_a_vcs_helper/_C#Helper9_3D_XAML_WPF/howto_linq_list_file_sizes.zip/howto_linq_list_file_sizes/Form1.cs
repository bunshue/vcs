﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.IO;

namespace howto_linq_list_file_sizes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Start at the startup directory.
        private void Form1_Load(object sender, EventArgs e)
        {
            txtDirectory.Text = Application.StartupPath;
        }

        // List the files in the selected directory and their sizes.
        private void btnListFiles_Click(object sender, EventArgs e)
        {
            // Search for the files.
            DirectoryInfo dirinfo = new DirectoryInfo(txtDirectory.Text);
            var fileQuery =
                from FileInfo fileinfo in dirinfo.GetFiles()
                orderby fileinfo.Length descending
                select String.Format("{0,10}  {1}",
                    fileinfo.Length.ToFileSizeApi(), fileinfo.Name);

            // Display the result.
            lstFiles.DataSource = fileQuery.ToArray();
        }
    }
}

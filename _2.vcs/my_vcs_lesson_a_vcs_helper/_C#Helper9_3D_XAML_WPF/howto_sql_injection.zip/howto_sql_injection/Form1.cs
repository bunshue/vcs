﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Data.OleDb;

namespace howto_sql_injection
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // The connection object.
        private OleDbConnection Conn;

        // Create the connection object.
        private void Form1_Load(object sender, EventArgs e)
        {
            const string db_name = "Employees.mdb";
            Conn = new OleDbConnection(
                "Provider=Microsoft.ACE.OLEDB.12.0;" +
                "Data Source=" + db_name + ";" +
                "Mode=Share Deny None");
        }

        // Log in by using a composed query.
        private void btnQuery_Click(object sender, EventArgs e)
        {
            string user_name = txtUsername.Text;
            string password = txtPassword.Text;
            string query =
                "SELECT COUNT (*) FROM Employees WHERE " +
                "UserName='" + user_name +
                "' AND Password='" + password + "'";
            txtQuery.Text = query;
            OleDbCommand cmd = new OleDbCommand(query, Conn);
            Conn.Open();

            int count = 0;
            try
            {
                count = (int)cmd.ExecuteScalar();
            }
            catch (Exception)
            {
                count = 0;
            }

            Conn.Close();
            if (count != 0)
            {
                MessageBox.Show("Welcome " + txtUsername.Text);
            }
            else
            {
                MessageBox.Show("Invalid User Name/Password");
            }
        }

        // Use a query removing quotes within the fields.
        private void btnRemoveQuotes_Click(object sender, EventArgs e)
        {
            string user_name = txtUsername.Text.Replace("'", "");
            user_name = user_name.Replace("\"", "");
            string password = txtPassword.Text.Replace("'", "");
            password = password.Replace("\"", "");
            string query =
                "SELECT COUNT (*) FROM Employees WHERE " +
                "UserName='" + user_name +
                "' AND Password='" + password + "'";
            txtQuery.Text = query;
            OleDbCommand cmd = new OleDbCommand(query, Conn);
            Conn.Open();

            int count = 0;
            try
            {
                count = (int)cmd.ExecuteScalar();
            }
            catch (Exception)
            {
                count = 0;
            }

            Conn.Close();
            if (count != 0)
            {
                MessageBox.Show("Welcome " + txtUsername.Text);
            }
            else
            {
                MessageBox.Show("Invalid User Name/Password");
            }
        }

        // Use command parameters.
        private void btnParameters_Click(object sender, EventArgs e)
        {
            string user_name = txtUsername.Text;
            string password = txtPassword.Text;
            string query = "SELECT UserName, Password FROM Employees " +
                "WHERE UserName=? AND Password=?";
            txtQuery.Clear();

            OleDbCommand cmd = new OleDbCommand(query, Conn);
            cmd.Parameters.AddWithValue("UserName", user_name);
            cmd.Parameters.AddWithValue("Password", password);
            Conn.Open();

            bool login_ok = false;
            try
            {
                // Execute the command.
                OleDbDataReader reader  = cmd.ExecuteReader();

                // Read the first record.
                if (reader.Read())
                {
                    // Make sure the user name and password match.
                    if ((reader.GetValue(0).ToString() == user_name) &&
                        (reader.GetValue(1).ToString() == password))
                            login_ok = true;

                    // Make sure there's only one matching record.
                    if (reader.Read()) login_ok = false;
                }
            }
            catch (Exception)
            {
                login_ok = false;
            }

            Conn.Close();
            if (login_ok)
            {
                MessageBox.Show("Welcome " + txtUsername.Text);
            }
            else
            {
                MessageBox.Show("Invalid User Name/Password");
            }
        }
    }
}

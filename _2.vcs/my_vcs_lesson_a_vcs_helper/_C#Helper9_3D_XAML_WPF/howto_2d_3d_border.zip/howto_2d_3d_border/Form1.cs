﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_2d_3d_border
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Draw some borders.
        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            const int gap = 8;
            const int num_rows = 4;
            int wid = this.DisplayRectangle.Width / num_rows;
            int hgt = this.DisplayRectangle.Height / num_rows;

            for (int x = 0; x < num_rows; x++)
            {
                for (int y = 0; y < num_rows; y++)
                {
                    DrawBorder(e.Graphics,
                        new Rectangle(
                            x * wid + gap / 2,
                            y * hgt + gap / 2,
                            wid - gap, hgt - gap),
                        BorderStyle.Fixed3D,
                        y == x);
                }
            }
            DrawBorder(e.Graphics, this.DisplayRectangle, BorderStyle.Fixed3D);
        }

        // Draw a border inside this rectangle.
        private void DrawBorder(Graphics gr, Rectangle rect, BorderStyle border_style)
        {
            DrawBorder(gr, rect, border_style, true);
        }
        private void DrawBorder(Graphics gr, Rectangle rect, BorderStyle border_style, bool sunken)
        {
            if (border_style == BorderStyle.FixedSingle)
            {
                rect.Width -= 1;
                rect.Height -= 1;
                gr.DrawRectangle(Pens.Black, rect);
            }
            else if (border_style == BorderStyle.Fixed3D)
            {
                Color[] colors;
                if (sunken)
                {
                    colors = new Color[]
                    {
                        SystemColors.ControlDark,
                        SystemColors.ControlDarkDark,
                        SystemColors.ControlLightLight,
                        SystemColors.ControlLight
                    };
                }
                else
                {
                    colors = new Color[]
                    {
                        SystemColors.ControlLightLight,
                        SystemColors.ControlLight,
                        SystemColors.ControlDark,
                        SystemColors.ControlDarkDark
                    };
                }
                using (Pen p = new Pen(colors[0]))
                {
                    gr.DrawLine(p, rect.X, rect.Bottom - 1, rect.X, rect.Y);
                    gr.DrawLine(p, rect.X, rect.Y, rect.Right - 1, rect.Y);
                }
                using (Pen p = new Pen(colors[1]))
                {
                    gr.DrawLine(p, rect.X + 1, rect.Bottom - 2, rect.X + 1, rect.Y + 1);
                    gr.DrawLine(p, rect.X + 1, rect.Y + 1, rect.Right - 2, rect.Y + 1);
                }
                using (Pen p = new Pen(colors[2]))
                {
                    gr.DrawLine(p, rect.X, rect.Bottom - 1, rect.Right - 1, rect.Bottom - 1);
                    gr.DrawLine(p, rect.Right - 1, rect.Bottom - 1, rect.Right - 1, rect.Y);
                }
                using (Pen p = new Pen(colors[3]))
                {
                    gr.DrawLine(p, rect.X + 1, rect.Bottom - 2, rect.Right - 2, rect.Bottom - 2);
                    gr.DrawLine(p, rect.Right - 2, rect.Bottom - 2, rect.Right - 2, rect.Y + 1);
                }
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Drawing.Drawing2D;

namespace howto_linq_min_max
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // The points.
        private List<Point> Points = new List<Point>();

        // Add a point to the list.
        private void picCanvas_MouseClick(object sender, MouseEventArgs e)
        {
            Points.Add(e.Location);
            picCanvas.Refresh();
        }

        // Draw the points and the bounding box.
        private void picCanvas_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
            // Draw the points.
            foreach (Point point in Points)
                e.Graphics.DrawEllipse(Pens.Red,
                    point.X - 2, point.Y - 2, 5, 5);

            // Draw the bounding box.
            if (Points.Count > 1)
                e.Graphics.DrawRectangle(Pens.Green,
                    BoundingBox(Points));
        }

        // Find the list's bounding box.
        private Rectangle BoundingBox(IEnumerable<Point> points)
        {
            // Find the minimum and maximum X and Y values.
            // Note: You could find these values in a single step as in:
            //      float xmin = (from Point p in Values select p.X).Min();
            // But that would make the program build the list of X values twice.
            var x_query = from Point p in points select p.X;
            int xmin = x_query.Min();
            int xmax = x_query.Max();

            var y_query = from Point p in points select p.Y;
            int ymin = y_query.Min();
            int ymax = y_query.Max();

            return new Rectangle(xmin, ymin, xmax - xmin, ymax - ymin);
        }
    }
}

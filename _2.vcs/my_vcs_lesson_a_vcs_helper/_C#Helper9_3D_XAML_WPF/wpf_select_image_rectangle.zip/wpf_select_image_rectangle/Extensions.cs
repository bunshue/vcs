﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.IO;

namespace wpf_select_image_rectangle
{
    public static class Extensions
    {
        // Save an image of the element into a
        // graphic file with an appropriate file type.
        public static void SaveImage(
            this CroppedBitmap cropped_bitmap,
            string filename)
        {
            FileInfo file_info = new FileInfo(filename);
            BitmapEncoder encoder = null;
            switch (file_info.Extension.ToLower())
            {
                case ".bmp":
                    encoder = new BmpBitmapEncoder();
                    break;
                case ".gif":
                    encoder = new GifBitmapEncoder();
                    break;
                case ".jpg":
                case ".jpeg":
                    encoder = new JpegBitmapEncoder();
                    break;
                case ".png":
                    encoder = new PngBitmapEncoder();
                    break;
                case ".tif":
                    encoder = new TiffBitmapEncoder();
                    break;
            }
            encoder.Frames.Add(BitmapFrame.Create(cropped_bitmap));

            using (FileStream stream =
                new FileStream(filename, FileMode.Create))
            {
                encoder.Save(stream);
            }
        }
    }
}

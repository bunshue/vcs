﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Xml.Linq;

namespace howto_xml_literal
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // Read the XElement.
            XElement xelement = XElement.Parse(
@"<employees>
    <employee firstname=""Terry"" lastname=""Pratchett""/>
    <employee firstname='Glen' lastname='Cook'/>
    <employee firstname='Tom' lastname='Holt'/>
    <employee>
      <firstname>Rod</firstname>
      <lastname>Stephens</lastname>
    </employee>
  </employees>
");

            // Display the nodes.
            foreach (XNode node in xelement.Nodes())
                lstNodes.Items.Add(node.ToString());
        }
    }
}

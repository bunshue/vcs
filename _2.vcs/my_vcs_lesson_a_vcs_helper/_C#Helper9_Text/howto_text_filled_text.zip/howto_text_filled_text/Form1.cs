﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Drawing.Drawing2D;

namespace howto_text_filled_text
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Redraw on resize.
        private void Form1_Load(object sender, EventArgs e)
        {
            this.ResizeRedraw = true;
        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            // Make things smoother.
            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;

            // Create the text path.
            GraphicsPath path = new GraphicsPath(FillMode.Alternate);

            // Draw text using a StringFormat to center it on the form.
            using (FontFamily font_family = new FontFamily("Times New Roman"))
            {
                using (StringFormat sf = new StringFormat())
                {
                    sf.Alignment = StringAlignment.Center;
                    sf.LineAlignment = StringAlignment.Center;
                    path.AddString("Text", font_family,
                        (int)FontStyle.Bold, 200,
                        this.ClientRectangle, sf);
                }
            }

            // Make a bitmap containing the small brush's text.
            using (Font small_font = new Font("Times New Roman", 8))
            {
                // See how big the text will be.
                SizeF text_size = e.Graphics.MeasureString("Text", small_font);

                // Make a Bitmap to hold the text.
                Bitmap bm = new Bitmap(
                    (int)(2 * text_size.Width),
                    (int)(2 * text_size.Height));
                using (Graphics gr = Graphics.FromImage(bm))
                {
                    gr.Clear(Color.LightBlue);
                    gr.DrawString("Text", small_font, Brushes.Red, 0, 0);
                    gr.DrawString("Text", small_font, Brushes.Green, 
                        text_size.Width, 0);
                    gr.DrawString("Text", small_font, Brushes.Blue,
                        -text_size.Width / 2,
                        text_size.Height);
                    gr.DrawString("Text", small_font, Brushes.DarkOrange, 
                        text_size.Width / 2,
                        text_size.Height);
                    gr.DrawString("Text", small_font, Brushes.Blue,
                        1.5f * text_size.Width,
                        text_size.Height);
                }

                // Fill the path.
                using (TextureBrush br = new TextureBrush(bm))
                {
                    e.Graphics.FillPath(br, path);
                }
            }

            // Outline the path.
            using (Pen pen = new Pen(Color.Black, 3))
            {
                e.Graphics.DrawPath(pen, path);
            }
        }
    }
}

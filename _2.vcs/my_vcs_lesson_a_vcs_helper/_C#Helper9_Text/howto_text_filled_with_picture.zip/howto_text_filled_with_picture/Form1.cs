﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Drawing.Text;

namespace howto_text_filled_with_picture
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Make the image.
        private void Form1_Load(object sender, EventArgs e)
        {
            // Make the bitmap we will display.
            Bitmap bm = new Bitmap(this.ClientSize.Width, this.ClientSize.Height);
            using (Graphics gr = Graphics.FromImage(bm))
            {
                gr.TextRenderingHint = TextRenderingHint.AntiAliasGridFit;
                gr.Clear(this.BackColor);

                // Make text filled with a single big image.
                // Make a brush containing the picture.
                using (TextureBrush the_brush = new TextureBrush(Properties.Resources.ColoradoFlowers))
                {
                    // Draw the text.
                    using (Font the_font = new Font("Times New Roman", 150, FontStyle.Bold))
                    {
                        gr.DrawString("Flowers", the_font, the_brush, 0, 0);
                    }
                }

                // Make text filled with a tiled image.
                // Make a brush containing the picture.
                using (TextureBrush the_brush = new TextureBrush(Properties.Resources.Smiley))
                {
                    // Draw the text.
                    using (Font the_font = new Font("Times New Roman", 150, FontStyle.Bold))
                    {
                        gr.DrawString("Smile!", the_font, the_brush, 75, 175);
                    }
                }
            }

            // Display the result.
            this.BackgroundImage = bm;
        }
    }
}

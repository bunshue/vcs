﻿namespace howto_justify_text
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.picText = new System.Windows.Forms.PictureBox();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.chkLeft = new System.Windows.Forms.ToolStripButton();
            this.chkCenter = new System.Windows.Forms.ToolStripButton();
            this.chkRight = new System.Windows.Forms.ToolStripButton();
            this.chkFull = new System.Windows.Forms.ToolStripButton();
            ((System.ComponentModel.ISupportInitialize)(this.picText)).BeginInit();
            this.toolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // picText
            // 
            this.picText.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.picText.BackColor = System.Drawing.Color.White;
            this.picText.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.picText.Location = new System.Drawing.Point(12, 28);
            this.picText.Name = "picText";
            this.picText.Size = new System.Drawing.Size(260, 224);
            this.picText.TabIndex = 0;
            this.picText.TabStop = false;
            this.picText.Resize += new System.EventHandler(this.picText_Resize);
            this.picText.Paint += new System.Windows.Forms.PaintEventHandler(this.picText_Paint);
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.chkLeft,
            this.chkCenter,
            this.chkRight,
            this.chkFull});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(284, 25);
            this.toolStrip1.TabIndex = 1;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // chkLeft
            // 
            this.chkLeft.Checked = true;
            this.chkLeft.CheckOnClick = true;
            this.chkLeft.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkLeft.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.chkLeft.Image = ((System.Drawing.Image)(resources.GetObject("chkLeft.Image")));
            this.chkLeft.ImageTransparentColor = System.Drawing.Color.Red;
            this.chkLeft.Name = "chkLeft";
            this.chkLeft.Size = new System.Drawing.Size(23, 22);
            this.chkLeft.Text = "toolStripButton1";
            this.chkLeft.Click += new System.EventHandler(this.chkAlignment_Click);
            // 
            // chkCenter
            // 
            this.chkCenter.CheckOnClick = true;
            this.chkCenter.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.chkCenter.Image = ((System.Drawing.Image)(resources.GetObject("chkCenter.Image")));
            this.chkCenter.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.chkCenter.Name = "chkCenter";
            this.chkCenter.Size = new System.Drawing.Size(23, 22);
            this.chkCenter.Text = "toolStripButton2";
            this.chkCenter.Click += new System.EventHandler(this.chkAlignment_Click);
            // 
            // chkRight
            // 
            this.chkRight.CheckOnClick = true;
            this.chkRight.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.chkRight.Image = ((System.Drawing.Image)(resources.GetObject("chkRight.Image")));
            this.chkRight.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.chkRight.Name = "chkRight";
            this.chkRight.Size = new System.Drawing.Size(23, 22);
            this.chkRight.Text = "toolStripButton3";
            this.chkRight.Click += new System.EventHandler(this.chkAlignment_Click);
            // 
            // chkFull
            // 
            this.chkFull.CheckOnClick = true;
            this.chkFull.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.chkFull.Image = ((System.Drawing.Image)(resources.GetObject("chkFull.Image")));
            this.chkFull.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.chkFull.Name = "chkFull";
            this.chkFull.Size = new System.Drawing.Size(23, 22);
            this.chkFull.Text = "toolStripButton4";
            this.chkFull.Click += new System.EventHandler(this.chkAlignment_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 264);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.picText);
            this.Name = "Form1";
            this.Text = "howto_justify_text";
            ((System.ComponentModel.ISupportInitialize)(this.picText)).EndInit();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox picText;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton chkLeft;
        private System.Windows.Forms.ToolStripButton chkCenter;
        private System.Windows.Forms.ToolStripButton chkRight;
        private System.Windows.Forms.ToolStripButton chkFull;
    }
}


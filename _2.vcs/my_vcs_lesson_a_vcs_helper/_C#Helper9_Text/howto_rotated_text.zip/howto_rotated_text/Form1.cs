﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Drawing.Drawing2D;
using System.Drawing.Text;

namespace howto_rotated_text
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.TextRenderingHint = TextRenderingHint.AntiAliasGridFit;

            using (Font the_font = new Font("Comic Sans MS", 20))
            {
                const int dx = 50;
                int x = 20, y = 150;
                DrawRotatedTextAt(e.Graphics, -90, "January", x, y, the_font, Brushes.Red);
                x += dx;
                DrawRotatedTextAt(e.Graphics, -90, "February", x, y, the_font, Brushes.Red);
                x += dx;
                DrawRotatedTextAt(e.Graphics, -90, "March", x, y, the_font, Brushes.Red);
                x += dx;
                DrawRotatedTextAt(e.Graphics, -90, "April", x, y, the_font, Brushes.Red);
                x += dx;
                DrawRotatedTextAt(e.Graphics, -90, "May", x, y, the_font, Brushes.Red);
                x += dx;
                DrawRotatedTextAt(e.Graphics, -90, "June", x, y, the_font, Brushes.Red);
                x += dx;
                DrawRotatedTextAt(e.Graphics, -90, "July", x, y, the_font, Brushes.Red);
                x += dx;
                DrawRotatedTextAt(e.Graphics, -90, "August", x, y, the_font, Brushes.Red);
                x += dx;
                DrawRotatedTextAt(e.Graphics, -90, "September", x, y, the_font, Brushes.Red);
                x += dx;
                DrawRotatedTextAt(e.Graphics, -90, "October", x, y, the_font, Brushes.Red);
                x += dx;
                DrawRotatedTextAt(e.Graphics, -90, "November", x, y, the_font, Brushes.Red);
                x += dx;
                DrawRotatedTextAt(e.Graphics, -90, "December", x, y, the_font, Brushes.Red);
            }
        }

        // Draw a rotated string at a particular position.
        private void DrawRotatedTextAt(Graphics gr, float angle, string txt, int x, int y, Font the_font, Brush the_brush)
        {
            // Save the graphics state.
            GraphicsState state = gr.Save();
            gr.ResetTransform();

            // Rotate.
            gr.RotateTransform(angle);

            // Translate to desired position. Be sure to append
            // the rotation so it occurs after the rotation.
            gr.TranslateTransform(x, y, MatrixOrder.Append);

            // Draw the text at the origin.
            gr.DrawString(txt, the_font, the_brush, 0, 0);

            // Restore the graphics state.
            gr.Restore(state);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Drawing.Drawing2D;
using System.Drawing.Text;

namespace howto_rainbow_text
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Redraw on resize.
        private void Form1_Load(object sender, EventArgs e)
        {
            this.ResizeRedraw = true;
        }

        // Draw the rainbow text.
        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            const string Txt = "RAINBOW!";

            // Make the result smoother.
            e.Graphics.TextRenderingHint = TextRenderingHint.AntiAliasGridFit;

            // Make a font.
            using (Font the_font = new Font("Times New Roman", 75,
                FontStyle.Bold, GraphicsUnit.Pixel))
            {
                // Get the font's metrics.
                FontInfo font_info = new FontInfo(e.Graphics, the_font);

                // See how big the text is.
                SizeF text_size = e.Graphics.MeasureString(Txt, the_font);
                int x0 = (int)((this.ClientSize.Width - text_size.Width) / 2);
                int y0 = (int)((this.ClientSize.Height - text_size.Height) / 2);

                // Get the Y coordinates that the brush should span.
                int brush_y0 = (int)(y0 + font_info.InternalLeadingPixels);
                int brush_y1 = (int)(y0 + font_info.AscentPixels);

                // Fudge the brush down a smidgen.
                brush_y0 += (int)(font_info.InternalLeadingPixels);
                brush_y1 += 5;

                // Make a brush to color the area.
                using (LinearGradientBrush the_brush = new LinearGradientBrush(
                    new Point(x0, brush_y0),
                    new Point(x0, brush_y1),
                    Color.Red, Color.Violet))
                {
                    Color[] colors = new Color[]
                    {
                        Color.FromArgb(255, 0, 0),
                        Color.FromArgb(255, 0, 0),
                        Color.FromArgb(255, 128, 0),
                        Color.FromArgb(255, 255, 0),
                        Color.FromArgb(0, 255, 0),
                        Color.FromArgb(0, 255, 128),
                        Color.FromArgb(0, 255, 255),
                        Color.FromArgb(0, 128, 255),
                        Color.FromArgb(0, 0, 255),
                        Color.FromArgb(0, 0, 255),
                    };
                    int num_colors = colors.Length;
                    float[] blend_positions = new float[num_colors];
                    for (int i = 0; i < num_colors; i++)
                    {
                        blend_positions[i] = i / (num_colors - 1f);
                    }

                    ColorBlend color_blend = new ColorBlend();
                    color_blend.Colors = colors;
                    color_blend.Positions = blend_positions;
                    the_brush.InterpolationColors = color_blend;

                    // Draw the text.
                    e.Graphics.DrawString(Txt, the_font, the_brush, x0, y0);
                }
            }
        }
    }
}

﻿namespace howto_covid19_states
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.picGraph = new System.Windows.Forms.PictureBox();
            this.clbStates = new System.Windows.Forms.CheckedListBox();
            this.btnAll = new System.Windows.Forms.Button();
            this.btnNone = new System.Windows.Forms.Button();
            this.tipGraph = new System.Windows.Forms.ToolTip(this.components);
            this.radSortByName = new System.Windows.Forms.RadioButton();
            this.radSortByMaxCases = new System.Windows.Forms.RadioButton();
            this.txtAlignCases = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.btnNoDataSets = new System.Windows.Forms.Button();
            this.btnAllDataSets = new System.Windows.Forms.Button();
            this.chkDeathsPerResolution = new System.Windows.Forms.CheckBox();
            this.chkDeaths = new System.Windows.Forms.CheckBox();
            this.chkRecovered = new System.Windows.Forms.CheckBox();
            this.chkVentTotal = new System.Windows.Forms.CheckBox();
            this.chkVentNow = new System.Windows.Forms.CheckBox();
            this.chkIcuTotal = new System.Windows.Forms.CheckBox();
            this.chkIcuNow = new System.Windows.Forms.CheckBox();
            this.chkHospitalizedTotal = new System.Windows.Forms.CheckBox();
            this.chkPerMillion = new System.Windows.Forms.CheckBox();
            this.chkHospitalizedNow = new System.Windows.Forms.CheckBox();
            this.chkPending = new System.Windows.Forms.CheckBox();
            this.chkTotalNegative = new System.Windows.Forms.CheckBox();
            this.chkTotalPositive = new System.Windows.Forms.CheckBox();
            this.lblLoading = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.picGraph)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // picGraph
            // 
            this.picGraph.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.picGraph.BackColor = System.Drawing.SystemColors.Control;
            this.picGraph.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.picGraph.Location = new System.Drawing.Point(355, 65);
            this.picGraph.Name = "picGraph";
            this.picGraph.Size = new System.Drawing.Size(458, 364);
            this.picGraph.TabIndex = 3;
            this.picGraph.TabStop = false;
            this.picGraph.MouseMove += new System.Windows.Forms.MouseEventHandler(this.picGraph_MouseMove);
            this.picGraph.Paint += new System.Windows.Forms.PaintEventHandler(this.picGraph_Paint);
            // 
            // clbStates
            // 
            this.clbStates.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)));
            this.clbStates.CheckOnClick = true;
            this.clbStates.FormattingEnabled = true;
            this.clbStates.IntegralHeight = false;
            this.clbStates.Location = new System.Drawing.Point(266, 65);
            this.clbStates.Name = "clbStates";
            this.clbStates.Size = new System.Drawing.Size(83, 306);
            this.clbStates.TabIndex = 4;
            this.clbStates.ItemCheck += new System.Windows.Forms.ItemCheckEventHandler(this.clbCountries_ItemCheck);
            // 
            // btnAll
            // 
            this.btnAll.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnAll.Location = new System.Drawing.Point(266, 377);
            this.btnAll.Name = "btnAll";
            this.btnAll.Size = new System.Drawing.Size(83, 23);
            this.btnAll.TabIndex = 5;
            this.btnAll.Text = "All";
            this.btnAll.UseVisualStyleBackColor = true;
            this.btnAll.Click += new System.EventHandler(this.btnAll_Click);
            // 
            // btnNone
            // 
            this.btnNone.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnNone.Location = new System.Drawing.Point(266, 406);
            this.btnNone.Name = "btnNone";
            this.btnNone.Size = new System.Drawing.Size(83, 23);
            this.btnNone.TabIndex = 6;
            this.btnNone.Text = "None";
            this.btnNone.UseVisualStyleBackColor = true;
            this.btnNone.Click += new System.EventHandler(this.btnNone_Click);
            // 
            // radSortByName
            // 
            this.radSortByName.AutoSize = true;
            this.radSortByName.Location = new System.Drawing.Point(20, 19);
            this.radSortByName.Name = "radSortByName";
            this.radSortByName.Size = new System.Drawing.Size(53, 17);
            this.radSortByName.TabIndex = 8;
            this.radSortByName.TabStop = true;
            this.radSortByName.Text = "Name";
            this.radSortByName.UseVisualStyleBackColor = true;
            this.radSortByName.Click += new System.EventHandler(this.radSort_Click);
            // 
            // radSortByMaxCases
            // 
            this.radSortByMaxCases.AutoSize = true;
            this.radSortByMaxCases.Checked = true;
            this.radSortByMaxCases.Location = new System.Drawing.Point(79, 19);
            this.radSortByMaxCases.Name = "radSortByMaxCases";
            this.radSortByMaxCases.Size = new System.Drawing.Size(77, 17);
            this.radSortByMaxCases.TabIndex = 9;
            this.radSortByMaxCases.TabStop = true;
            this.radSortByMaxCases.Text = "Max Cases";
            this.radSortByMaxCases.UseVisualStyleBackColor = true;
            this.radSortByMaxCases.Click += new System.EventHandler(this.radSort_Click);
            // 
            // txtAlignCases
            // 
            this.txtAlignCases.Location = new System.Drawing.Point(20, 18);
            this.txtAlignCases.Name = "txtAlignCases";
            this.txtAlignCases.Size = new System.Drawing.Size(53, 20);
            this.txtAlignCases.TabIndex = 11;
            this.txtAlignCases.Text = "0";
            this.txtAlignCases.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtAlignCases.TextChanged += new System.EventHandler(this.txtAlignCases_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(79, 21);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(35, 13);
            this.label3.TabIndex = 13;
            this.label3.Text = "cases";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.radSortByName);
            this.groupBox1.Controls.Add(this.radSortByMaxCases);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(166, 47);
            this.groupBox1.TabIndex = 14;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Sort By";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.txtAlignCases);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Location = new System.Drawing.Point(184, 12);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(125, 47);
            this.groupBox2.TabIndex = 10;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Align At";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.btnNoDataSets);
            this.groupBox3.Controls.Add(this.btnAllDataSets);
            this.groupBox3.Controls.Add(this.chkDeathsPerResolution);
            this.groupBox3.Controls.Add(this.chkDeaths);
            this.groupBox3.Controls.Add(this.chkRecovered);
            this.groupBox3.Controls.Add(this.chkVentTotal);
            this.groupBox3.Controls.Add(this.chkVentNow);
            this.groupBox3.Controls.Add(this.chkIcuTotal);
            this.groupBox3.Controls.Add(this.chkIcuNow);
            this.groupBox3.Controls.Add(this.chkHospitalizedTotal);
            this.groupBox3.Controls.Add(this.chkPerMillion);
            this.groupBox3.Controls.Add(this.chkHospitalizedNow);
            this.groupBox3.Controls.Add(this.chkPending);
            this.groupBox3.Controls.Add(this.chkTotalNegative);
            this.groupBox3.Controls.Add(this.chkTotalPositive);
            this.groupBox3.Location = new System.Drawing.Point(13, 65);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(247, 365);
            this.groupBox3.TabIndex = 14;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Display";
            // 
            // btnNoDataSets
            // 
            this.btnNoDataSets.Location = new System.Drawing.Point(166, 90);
            this.btnNoDataSets.Name = "btnNoDataSets";
            this.btnNoDataSets.Size = new System.Drawing.Size(75, 23);
            this.btnNoDataSets.TabIndex = 16;
            this.btnNoDataSets.Text = "None";
            this.btnNoDataSets.UseVisualStyleBackColor = true;
            this.btnNoDataSets.Click += new System.EventHandler(this.btnNoDataSets_Click);
            // 
            // btnAllDataSets
            // 
            this.btnAllDataSets.Location = new System.Drawing.Point(166, 61);
            this.btnAllDataSets.Name = "btnAllDataSets";
            this.btnAllDataSets.Size = new System.Drawing.Size(75, 23);
            this.btnAllDataSets.TabIndex = 16;
            this.btnAllDataSets.Text = "All";
            this.btnAllDataSets.UseVisualStyleBackColor = true;
            this.btnAllDataSets.Click += new System.EventHandler(this.btnAllDataSets_Click);
            // 
            // chkDeathsPerResolution
            // 
            this.chkDeathsPerResolution.AutoSize = true;
            this.chkDeathsPerResolution.Location = new System.Drawing.Point(19, 341);
            this.chkDeathsPerResolution.Name = "chkDeathsPerResolution";
            this.chkDeathsPerResolution.Size = new System.Drawing.Size(132, 17);
            this.chkDeathsPerResolution.TabIndex = 21;
            this.chkDeathsPerResolution.Text = "Deaths Per Resolution";
            this.chkDeathsPerResolution.UseVisualStyleBackColor = true;
            this.chkDeathsPerResolution.CheckedChanged += new System.EventHandler(this.chkDataSet_CheckedChanged);
            // 
            // chkDeaths
            // 
            this.chkDeaths.AutoSize = true;
            this.chkDeaths.Location = new System.Drawing.Point(20, 295);
            this.chkDeaths.Name = "chkDeaths";
            this.chkDeaths.Size = new System.Drawing.Size(60, 17);
            this.chkDeaths.TabIndex = 18;
            this.chkDeaths.Text = "Deaths";
            this.chkDeaths.UseVisualStyleBackColor = true;
            this.chkDeaths.CheckedChanged += new System.EventHandler(this.chkDataSet_CheckedChanged);
            // 
            // chkRecovered
            // 
            this.chkRecovered.AutoSize = true;
            this.chkRecovered.Location = new System.Drawing.Point(20, 272);
            this.chkRecovered.Name = "chkRecovered";
            this.chkRecovered.Size = new System.Drawing.Size(79, 17);
            this.chkRecovered.TabIndex = 17;
            this.chkRecovered.Text = "Recovered";
            this.chkRecovered.UseVisualStyleBackColor = true;
            this.chkRecovered.CheckedChanged += new System.EventHandler(this.chkDataSet_CheckedChanged);
            // 
            // chkVentTotal
            // 
            this.chkVentTotal.AutoSize = true;
            this.chkVentTotal.Location = new System.Drawing.Point(20, 249);
            this.chkVentTotal.Name = "chkVentTotal";
            this.chkVentTotal.Size = new System.Drawing.Size(75, 17);
            this.chkVentTotal.TabIndex = 16;
            this.chkVentTotal.Text = "Vent Total";
            this.chkVentTotal.UseVisualStyleBackColor = true;
            this.chkVentTotal.CheckedChanged += new System.EventHandler(this.chkDataSet_CheckedChanged);
            // 
            // chkVentNow
            // 
            this.chkVentNow.AutoSize = true;
            this.chkVentNow.Location = new System.Drawing.Point(20, 226);
            this.chkVentNow.Name = "chkVentNow";
            this.chkVentNow.Size = new System.Drawing.Size(73, 17);
            this.chkVentNow.TabIndex = 15;
            this.chkVentNow.Text = "Vent Now";
            this.chkVentNow.UseVisualStyleBackColor = true;
            this.chkVentNow.CheckedChanged += new System.EventHandler(this.chkDataSet_CheckedChanged);
            // 
            // chkIcuTotal
            // 
            this.chkIcuTotal.AutoSize = true;
            this.chkIcuTotal.Location = new System.Drawing.Point(20, 203);
            this.chkIcuTotal.Name = "chkIcuTotal";
            this.chkIcuTotal.Size = new System.Drawing.Size(71, 17);
            this.chkIcuTotal.TabIndex = 14;
            this.chkIcuTotal.Text = "ICU Total";
            this.chkIcuTotal.UseVisualStyleBackColor = true;
            this.chkIcuTotal.CheckedChanged += new System.EventHandler(this.chkDataSet_CheckedChanged);
            // 
            // chkIcuNow
            // 
            this.chkIcuNow.AutoSize = true;
            this.chkIcuNow.Location = new System.Drawing.Point(20, 180);
            this.chkIcuNow.Name = "chkIcuNow";
            this.chkIcuNow.Size = new System.Drawing.Size(69, 17);
            this.chkIcuNow.TabIndex = 13;
            this.chkIcuNow.Text = "ICU Now";
            this.chkIcuNow.UseVisualStyleBackColor = true;
            this.chkIcuNow.CheckedChanged += new System.EventHandler(this.chkDataSet_CheckedChanged);
            // 
            // chkHospitalizedTotal
            // 
            this.chkHospitalizedTotal.AutoSize = true;
            this.chkHospitalizedTotal.Location = new System.Drawing.Point(20, 157);
            this.chkHospitalizedTotal.Name = "chkHospitalizedTotal";
            this.chkHospitalizedTotal.Size = new System.Drawing.Size(110, 17);
            this.chkHospitalizedTotal.TabIndex = 12;
            this.chkHospitalizedTotal.Text = "Hospitalized Total";
            this.chkHospitalizedTotal.UseVisualStyleBackColor = true;
            this.chkHospitalizedTotal.CheckedChanged += new System.EventHandler(this.chkDataSet_CheckedChanged);
            // 
            // chkPerMillion
            // 
            this.chkPerMillion.AutoSize = true;
            this.chkPerMillion.Location = new System.Drawing.Point(20, 19);
            this.chkPerMillion.Name = "chkPerMillion";
            this.chkPerMillion.Size = new System.Drawing.Size(74, 17);
            this.chkPerMillion.TabIndex = 11;
            this.chkPerMillion.Text = "Per Million";
            this.chkPerMillion.UseVisualStyleBackColor = true;
            this.chkPerMillion.CheckedChanged += new System.EventHandler(this.chkDataSet_CheckedChanged);
            // 
            // chkHospitalizedNow
            // 
            this.chkHospitalizedNow.AutoSize = true;
            this.chkHospitalizedNow.Location = new System.Drawing.Point(20, 134);
            this.chkHospitalizedNow.Name = "chkHospitalizedNow";
            this.chkHospitalizedNow.Size = new System.Drawing.Size(108, 17);
            this.chkHospitalizedNow.TabIndex = 10;
            this.chkHospitalizedNow.Text = "Hospitalized Now";
            this.chkHospitalizedNow.UseVisualStyleBackColor = true;
            this.chkHospitalizedNow.CheckedChanged += new System.EventHandler(this.chkDataSet_CheckedChanged);
            // 
            // chkPending
            // 
            this.chkPending.AutoSize = true;
            this.chkPending.Location = new System.Drawing.Point(20, 111);
            this.chkPending.Name = "chkPending";
            this.chkPending.Size = new System.Drawing.Size(65, 17);
            this.chkPending.TabIndex = 9;
            this.chkPending.Text = "Pending";
            this.chkPending.UseVisualStyleBackColor = true;
            this.chkPending.CheckedChanged += new System.EventHandler(this.chkDataSet_CheckedChanged);
            // 
            // chkTotalNegative
            // 
            this.chkTotalNegative.AutoSize = true;
            this.chkTotalNegative.Location = new System.Drawing.Point(20, 88);
            this.chkTotalNegative.Name = "chkTotalNegative";
            this.chkTotalNegative.Size = new System.Drawing.Size(96, 17);
            this.chkTotalNegative.TabIndex = 8;
            this.chkTotalNegative.Text = "Total Negative";
            this.chkTotalNegative.UseVisualStyleBackColor = true;
            this.chkTotalNegative.CheckedChanged += new System.EventHandler(this.chkDataSet_CheckedChanged);
            // 
            // chkTotalPositive
            // 
            this.chkTotalPositive.AutoSize = true;
            this.chkTotalPositive.Location = new System.Drawing.Point(20, 65);
            this.chkTotalPositive.Name = "chkTotalPositive";
            this.chkTotalPositive.Size = new System.Drawing.Size(90, 17);
            this.chkTotalPositive.TabIndex = 7;
            this.chkTotalPositive.Text = "Total Positive";
            this.chkTotalPositive.UseVisualStyleBackColor = true;
            this.chkTotalPositive.CheckedChanged += new System.EventHandler(this.chkDataSet_CheckedChanged);
            // 
            // lblLoading
            // 
            this.lblLoading.AutoSize = true;
            this.lblLoading.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLoading.ForeColor = System.Drawing.Color.Red;
            this.lblLoading.Location = new System.Drawing.Point(324, 28);
            this.lblLoading.Name = "lblLoading";
            this.lblLoading.Size = new System.Drawing.Size(70, 20);
            this.lblLoading.TabIndex = 15;
            this.lblLoading.Text = "Loading:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(825, 441);
            this.Controls.Add(this.lblLoading);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnNone);
            this.Controls.Add(this.btnAll);
            this.Controls.Add(this.clbStates);
            this.Controls.Add(this.picGraph);
            this.Name = "Form1";
            this.Text = "howto_covid19_states";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.picGraph)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox picGraph;
        private System.Windows.Forms.CheckedListBox clbStates;
        private System.Windows.Forms.Button btnAll;
        private System.Windows.Forms.Button btnNone;
        private System.Windows.Forms.ToolTip tipGraph;
        private System.Windows.Forms.RadioButton radSortByName;
        private System.Windows.Forms.RadioButton radSortByMaxCases;
        private System.Windows.Forms.TextBox txtAlignCases;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label lblLoading;
        public System.Windows.Forms.CheckBox chkDeathsPerResolution;
        public System.Windows.Forms.CheckBox chkDeaths;
        public System.Windows.Forms.CheckBox chkRecovered;
        public System.Windows.Forms.CheckBox chkVentTotal;
        public System.Windows.Forms.CheckBox chkVentNow;
        public System.Windows.Forms.CheckBox chkIcuTotal;
        public System.Windows.Forms.CheckBox chkIcuNow;
        public System.Windows.Forms.CheckBox chkHospitalizedTotal;
        public System.Windows.Forms.CheckBox chkPerMillion;
        public System.Windows.Forms.CheckBox chkHospitalizedNow;
        public System.Windows.Forms.CheckBox chkPending;
        public System.Windows.Forms.CheckBox chkTotalNegative;
        public System.Windows.Forms.CheckBox chkTotalPositive;
        private System.Windows.Forms.Button btnNoDataSets;
        private System.Windows.Forms.Button btnAllDataSets;
    }
}


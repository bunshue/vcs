﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_size_form_to_fit
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Change the form's size and size it to fit.
        private void btnClickMe_Click(object sender, EventArgs e)
        {
            // Move the button to a new location.
            if (btnClickMe.Location.X != 100)
            {
                btnClickMe.Location = new Point(100, 200);
            }
            else
            {
                btnClickMe.Location = new Point(250, 100);
            }

            // Make the form just big enough to hold the button.
            this.ClientSize = new Size(
                btnClickMe.Right,
                btnClickMe.Bottom);
        }
    }
}

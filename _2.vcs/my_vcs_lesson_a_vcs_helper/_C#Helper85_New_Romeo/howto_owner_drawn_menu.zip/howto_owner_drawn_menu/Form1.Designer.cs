﻿namespace howto_owner_drawn_menu
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.mnuMain = new System.Windows.Forms.MainMenu(this.components);
            this.MenuItem1 = new System.Windows.Forms.MenuItem();
            this.mnuFileSayHi = new System.Windows.Forms.MenuItem();
            this.mnuFileExit = new System.Windows.Forms.MenuItem();
            this.SuspendLayout();
            // 
            // mnuMain
            // 
            this.mnuMain.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
            this.MenuItem1});
            // 
            // MenuItem1
            // 
            this.MenuItem1.Index = 0;
            this.MenuItem1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
            this.mnuFileSayHi,
            this.mnuFileExit});
            this.MenuItem1.Text = "&File";
            // 
            // mnuFileSayHi
            // 
            this.mnuFileSayHi.Index = 0;
            this.mnuFileSayHi.OwnerDraw = true;
            this.mnuFileSayHi.Text = "SayHi";
            this.mnuFileSayHi.DrawItem += new System.Windows.Forms.DrawItemEventHandler(this.mnuFileSayHi_DrawItem);
            this.mnuFileSayHi.Click += new System.EventHandler(this.mnuFileSayHi_Click);
            this.mnuFileSayHi.MeasureItem += new System.Windows.Forms.MeasureItemEventHandler(this.mnuFileSayHi_MeasureItem);
            // 
            // mnuFileExit
            // 
            this.mnuFileExit.Index = 1;
            this.mnuFileExit.Text = "E&xit";
            this.mnuFileExit.Click += new System.EventHandler(this.mnuFileExit_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(334, 90);
            this.Menu = this.mnuMain;
            this.Name = "Form1";
            this.Text = "howto_owner_drawn_menu";
            this.ResumeLayout(false);

        }

        #endregion

        internal System.Windows.Forms.MainMenu mnuMain;
        internal System.Windows.Forms.MenuItem MenuItem1;
        internal System.Windows.Forms.MenuItem mnuFileSayHi;
        internal System.Windows.Forms.MenuItem mnuFileExit;
    }
}


﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Drawing.Drawing2D;

namespace howto_make_circle_partition
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // The circles.
        List<PointF> Centers = new List<PointF>();
        List<float> Radii = new List<float>();

        // The index of a new circle we are drawing.
        int NewCircle = -1;

        // Remove all circles.
        private void btnClear_Click(object sender, EventArgs e)
        {
            Centers = new List<PointF>();
            Radii = new List<float>();

            this.Invalidate();
        }

        // Draw the circles.
        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;

            // See if we are currently drawing a new circle.
            if (NewCircle < 0)
            {
                // We are not drawing a new circle.
                // Draw the regions.
                // Find the RegionInfos for the circles.
                List<RegionInfo> regioninfos = new List<RegionInfo>();
                for (int i = 0; i < Centers.Count; i++)
                {
                    // Make a RegionInfo for this circle.
                    RegionInfo new_regioninfo =
                        new RegionInfo(1, Centers[i], Radii[i]);

                    // Make intersections between the new RegionInfo
                    // and other RegionInfos already on the list.
                    new_regioninfo.MakeIntersections(e.Graphics, regioninfos);

                    // Add the new RegionInfo to the list.
                    regioninfos.Add(new_regioninfo);
                }

                // Find the largest RegionInfo.Count.
                int max_count = 0;
                foreach (RegionInfo regioninfo in regioninfos)
                {
                    if (max_count < regioninfo.Count)
                    {
                        max_count = regioninfo.Count;
                    }
                }

                // Draw the RegionInfos.
                foreach (RegionInfo regioninfo in regioninfos)
                {
                    regioninfo.Draw(e.Graphics, this.Font, max_count);
                }
            }

            // Draw the circles.
            for (int i = 0; i < Centers.Count; i++)
            {
                e.Graphics.DrawEllipse(Pens.Blue,
                    Centers[i].X - Radii[i], Centers[i].Y - Radii[i],
                    2 * Radii[i], 2 * Radii[i]);
            }
        }

        // Start drawing a new circle.
        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            Centers.Add(e.Location);
            Radii.Add(0);
            NewCircle = Centers.Count - 1;
        }

        // Update the new circle.
        private void Form1_MouseMove(object sender, MouseEventArgs e)
        {
            if (NewCircle < 0) return;
            float dx = e.X - Centers[NewCircle].X;
            float dy = e.Y - Centers[NewCircle].Y;
            Radii[NewCircle] = (float)Math.Sqrt(dx * dx + dy * dy);
            this.Invalidate();
        }

        // Finish drawing a new circle.
        private void Form1_MouseUp(object sender, MouseEventArgs e)
        {
            // If the radius is 0, remove the new circle.
            if (Radii[NewCircle] < 1)
            {
                Centers.RemoveAt(NewCircle);
                Radii.RemoveAt(NewCircle);
            }

            NewCircle = -1;
            this.Invalidate();
        }

        // Find the intersection of all of the circles.
        private Region FindCircleIntersections(List<PointF> centers, List<float> radii)
        {
            if (centers.Count < 1) return null;

            // Make a region.
            Region result_region = new Region();

            // Intersect the region with the circles.
            for (int i = 0; i < centers.Count; i++)
            {
                using (GraphicsPath circle_path = new GraphicsPath())
                {
                    circle_path.AddEllipse(
                        centers[i].X - radii[i], centers[i].Y - radii[i],
                        2 * radii[i], 2 * radii[i]);
                    result_region.Intersect(circle_path);
                }
            }

            return result_region;
        }
    }
}

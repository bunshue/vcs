﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_secret_santa_pick
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Make a random number generator.
        private Random Rand = new Random();

        private void btnPick_Click(object sender, EventArgs e)
        {
            // Find a random assignment.
            int N = int.Parse(txtNumPeople.Text);
            int num_tries;
            int[] assignments = SecretSantaAssignment(N, out num_tries);

            txtNumTries.Text = num_tries.ToString();
            lstAssignments.Items.Clear();
            for (int i = 0; i < N; i++)
            {
                lstAssignments.Items.Add(i.ToString() +
                    " --> " + assignments[i].ToString());
            }
        }

        // Generate a random derangement.
        private int[] SecretSantaAssignment(int N, out int num_tries)
        {
            // Make an array to hold the assignment.
            int[] assignments = new int[N];
            for (int i = 0; i < N; i++)
                assignments[i] = i;

            // Try random permutations until we find one that works.
            //Console.WriteLine();
            num_tries = 0;
            for (; ; )
            {
                // Randomize the assignment array.
                num_tries++;
                assignments.Randomize();

                // Display this permutation.
                //for (int i = 0; i < N; i++) Console.Write(assignments[i].ToString() + " ");
                //Console.WriteLine();

                // If this is an invalid assignment, try again.
                bool is_valid = true;
                for (int i = 0; i < N; i++)
                {
                    if (assignments[i] == i)
                    {
                        is_valid = false;
                        break;
                    }
                }

                // See if this is a valid assignment.
                if (is_valid) break;
            }

            return assignments;
        }
    }
}

﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace Access_Firewall
{
    public partial class frmMain : Form
    {
        public frmMain()
        {
            InitializeComponent();
        }

        private void btnQuit_Click(object sender, EventArgs e)
        {
            // End the program.
            Close();
        }

        private void btnCheck_Click(object sender, EventArgs e)
        {
            // Create the firewall type.
            Type FWManagerType = Type.GetTypeFromProgID("HNetCfg.FwMgr");

            // Use the firewall type to create a firewall manager object.
            dynamic FWManager = Activator.CreateInstance(FWManagerType);

            // Check the status of the firewall.
            MessageBox.Show("The firewall is turned on: " + 
                Convert.ToString(
                    FWManager.LocalPolicy.CurrentProfile.FirewallEnabled));
        }
    }
}

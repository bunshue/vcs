﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Net;
using System.Net.Mail;

namespace howto_send_email
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Send the message.
        private void btnSend_Click(object sender, EventArgs e)
        {
            try
            {
                SendEmail(txtToName.Text, txtToEmail.Text,
                    txtFromName.Text, txtFromEmail.Text,
                    txtHost.Text, int.Parse(txtPort.Text),
                    chkEnableSSL.Checked, txtPassword.Text,
                    txtSubject.Text, txtBody.Text);
                MessageBox.Show("Message sent");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        // Send an email message.
        private void SendEmail(string to_name, string to_email,
            string from_name, string from_email,
            string host, int port, bool enable_ssl, string password,
            string subject, string body)
        {
            // Make the mail message.
            MailAddress from_address = new MailAddress(from_email, from_name);
            MailAddress to_address = new MailAddress(to_email, to_name);
            MailMessage message = new MailMessage(from_address, to_address);
            message.Subject = subject;
            message.Body = body;

            // Get the SMTP client.
            SmtpClient client = new SmtpClient()
            {
                Host = host,
                Port = port,
                EnableSsl = enable_ssl,
                DeliveryMethod = SmtpDeliveryMethod.Network,
                UseDefaultCredentials = false,
                Credentials = new NetworkCredential(from_address.Address, password),
            };

            // Send the message.
            client.Send(message);
        }
    }
}

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Drawing.Drawing2D;

namespace howto_draw_on_bitmap
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Make and display a Bitmap.
        private void Form1_Load(object sender, EventArgs e)
        {
            picDrawing.SizeMode = PictureBoxSizeMode.AutoSize;
            picDrawing.Location = new Point(0, 0);

            Bitmap bm = new Bitmap(280, 110);
            using (Graphics gr = Graphics.FromImage(bm))
            {
                gr.SmoothingMode = SmoothingMode.AntiAlias;
                Rectangle rect = new Rectangle(10, 10, 260, 90);
                gr.FillEllipse(Brushes.LightGreen, rect);
                using (Pen thick_pen = new Pen(Color.Blue, 5))
                {
                    gr.DrawEllipse(thick_pen, rect);
                }
            }

            picDrawing.Image = bm;
        }
    }
}

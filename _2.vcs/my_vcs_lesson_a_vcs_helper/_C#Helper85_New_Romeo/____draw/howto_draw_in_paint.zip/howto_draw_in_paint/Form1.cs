﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Drawing.Drawing2D;

namespace howto_draw_in_paint
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Redraw on resize.
        private void Form1_Load(object sender, EventArgs e)
        {
            ResizeRedraw = true;
        }

        // Draw an ellipse.
        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.Clear(Color.White);
            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;

            Rectangle rect = new Rectangle(10, 10,
                this.ClientSize.Width - 20,
                this.ClientSize.Height - 20);
            e.Graphics.FillEllipse(Brushes.Yellow, rect);
            using (Pen thick_pen = new Pen(Color.Red, 5))
            {
                e.Graphics.DrawEllipse(thick_pen, rect);
            }
        }

        // Draw an ellipse on the PictureBox.
        private void picEllipse_Resize(object sender, EventArgs e)
        {
            picEllipse.Refresh();
        }
        private void picEllipse_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.Clear(Color.White);
            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;

            Rectangle rect = new Rectangle(10, 10,
                picEllipse.ClientSize.Width - 20,
                picEllipse.ClientSize.Height - 20);
            e.Graphics.FillEllipse(Brushes.Pink, rect);
            using (Pen thick_pen = new Pen(Color.Blue, 5))
            {
                e.Graphics.DrawEllipse(thick_pen, rect);
            }
        }
    }
}

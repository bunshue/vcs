﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Drawing.Drawing2D;

namespace howto_line_end_caps
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            ResizeRedraw = true;
        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.Clear(BackColor);
            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;

            const int line_width = 10;
            int y = 10;
            int x1 = 110;
            int x2 = ClientSize.Width - 2 * line_width;
            using (Pen pen = new Pen(Color.Blue, line_width))
            {
                LineCap[] caps = (LineCap[])Enum.GetValues(typeof(LineCap));
                foreach (LineCap cap in caps)
                {
                    e.Graphics.DrawString(cap.ToString(),
                        Font, Brushes.Black, 10, y);
                    pen.StartCap = cap;
                    pen.EndCap = cap;
                    e.Graphics.DrawLine(pen, x1, y, x2, y);
                    y += 2 * line_width;
                }
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.IO;

namespace howto_recursive_replace
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Restore previous settings.
        private void Form1_Load(object sender, EventArgs e)
        {
            txtStartDirectory.Text = Properties.Settings.Default.StartDirectory;
            cboPattern.Text = Properties.Settings.Default.Pattern;
        }

        // Save current settings.
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            Properties.Settings.Default.StartDirectory = txtStartDirectory.Text;
            Properties.Settings.Default.Pattern = cboPattern.Text;
            Properties.Settings.Default.Save();
        }

        // Let the user browse for a start directory.
        private void btnPickStartDirectory_Click(object sender, EventArgs e)
        {
            fbdStartDirectory.SelectedPath = txtStartDirectory.Text;
            if (fbdStartDirectory.ShowDialog() == DialogResult.OK)
            {
                txtStartDirectory.Text = fbdStartDirectory.SelectedPath;
            }
        }

        // If it's Ctrl+A, select all of the control's text.
        private void TextBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Control && e.KeyCode == Keys.A)
            {
                TextBox txt = sender as TextBox;
                txt.SelectAll();
                e.Handled = true;
            }
        }

        // Find files matching the pattern that contain the target string.
        // If the button is the Find and Replace button, make replacements.
        private void btnFind_Click(object sender, EventArgs e)
        {
            SearchForFiles(lstFiles, txtStartDirectory.Text,
                cboPattern.Text, txtFind.Text, null);
        }
        private void btnFindAndReplace_Click(object sender, EventArgs e)
        {
            SearchForFiles(lstFiles, txtStartDirectory.Text,
                cboPattern.Text, txtFind.Text, txtReplaceWith.Text);
        }

        // Find files matching the pattern that contain the target string
        // and make the replacement if appropriate.
        private void SearchForFiles(ListBox lst, string start_dir,
            string pattern, string from_string, string to_string)
        {
            try
            {
                // Clear the result ListBox.
                lstFiles.Items.Clear();

                // Parse the patterns.
                string[] patterns = ParsePatterns(pattern);

                // If from_string is blank, don't replace.
                if (from_string.Length < 1) from_string = null;

                DirectoryInfo dir_info = new DirectoryInfo(start_dir);
                SearchDirectory(lst, dir_info, patterns, from_string, to_string);

                if (from_string == null)
                {
                    MessageBox.Show("Found " + lst.Items.Count + " files.");
                }
                else
                {
                    MessageBox.Show("Made replacements in " + lst.Items.Count + " files.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        // Find files matching the pattern that contain the target string
        // and make the replacement if appropriate.
        private void SearchDirectory(ListBox lst, DirectoryInfo dir_info,
            string[] patterns, string from_string, string to_string)
        {
            // Search this directory.
            foreach (string pattern in patterns)
            {
                // Check this pattern.
                foreach (FileInfo file_info in dir_info.GetFiles(pattern))
                {
                    // Process this file.
                    ProcessFile(lst, file_info, from_string, to_string);
                }
            }

            // Search subdirectories.
            foreach (DirectoryInfo subdir_info in dir_info.GetDirectories())
            {
                SearchDirectory(lst, subdir_info, patterns, from_string, to_string);
            }
        }

        // Replace all occurrences of from_string with to_string.
        // Return true if there was a problem and we should stop.
        private void ProcessFile(ListBox lst, FileInfo file_info, string from_string, string to_string)
        {
            try
            {
                if (from_string == null)
                {
                    // Add the file to the list.
                    lst.Items.Add(file_info.FullName);
                }
                else
                {
                    // See if the file contains from_string.
                    string txt = File.ReadAllText(file_info.FullName);
                    if (txt.Contains(from_string))
                    {
                        // Add the file to the list.
                        lst.Items.Add(file_info.FullName);

                        // See if we should make a replacement.
                        if (to_string != null)
                        {
                            File.WriteAllText(file_info.FullName,
                                txt.Replace(from_string, to_string));
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error processing file " +
                    file_info.FullName + "\n" + ex.Message);
            }
        }

        // Take whatever is between parentheses (if there are any),
        // separate them, and return them in an array.
        private string[] ParsePatterns(string pattern_string)
        {
            // Take whatever is between the parentheses (if there are any).
            if (pattern_string.Contains("("))
            {
                pattern_string = TextBetween(pattern_string, "(", ")");
            }

            // Split the string at semi-colons.
            string[] result = pattern_string.Split(';');

            // Trim all of the patterns to remove extra space.
            for (int i = 0; i < result.Length; i++)
            {
                result[i] = result[i].Trim();
            }

            return result;
        }

        // Get the text between two delimiters.
        // Let the code throw an error if a delimiter is not found.
        private string TextBetween(string txt, string delimiter1, string delimiter2)
        {
            // Find the starting delimiter.
            int pos1 = txt.IndexOf(delimiter1);
            int text_start = pos1 + delimiter1.Length;
            int pos2 = txt.IndexOf(delimiter2, text_start);
            return txt.Substring(text_start, pos2 - text_start);
        }
    }
}

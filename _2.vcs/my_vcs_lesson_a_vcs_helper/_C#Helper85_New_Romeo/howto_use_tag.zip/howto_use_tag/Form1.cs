﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_use_tag
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Use the selected color for the form's background.
        private void btnColor_Click(object sender, EventArgs e)
        {
            // Get the sender as a button.
            Button btn = sender as Button;

            // Convert its Tag value into a color.
            this.BackColor = Color.FromName(btn.Tag.ToString());
        }
    }
}

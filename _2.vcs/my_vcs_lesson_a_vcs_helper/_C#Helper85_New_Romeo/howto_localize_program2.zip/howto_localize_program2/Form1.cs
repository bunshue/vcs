﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Threading;
using System.Globalization;

namespace howto_localize_program2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            // English.
            //Thread.CurrentThread.CurrentCulture =
            //    new CultureInfo("en-US", false);
            //Thread.CurrentThread.CurrentUICulture =
            //    new CultureInfo("en-US", false);

            // German.
            Thread.CurrentThread.CurrentCulture =
                new CultureInfo("de-DE", false);
            Thread.CurrentThread.CurrentUICulture =
                new CultureInfo("de-DE", false);

            InitializeComponent();
        }
    }
}

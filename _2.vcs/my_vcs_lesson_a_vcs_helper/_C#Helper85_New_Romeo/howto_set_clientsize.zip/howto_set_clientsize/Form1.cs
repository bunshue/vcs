﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Drawing.Drawing2D;

namespace howto_set_clientsize
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Draw a diamond of the appropriate size.
        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            int hgt, wid;
            if (rad200x300.Checked) { hgt = 300; wid = 200; }
            else                    { hgt = 200; wid = 300; }
            Point[] pts =
            {
                new Point(wid / 2, 0),
                new Point(wid, hgt / 2),
                new Point(wid / 2, hgt),
                new Point(0, hgt / 2),
            };

            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
            e.Graphics.DrawPolygon(Pens.Blue, pts);
        }

        // Change the size.
        private void rad200x300_CheckedChanged(object sender, EventArgs e)
        {
            if (rad200x300.Checked) ClientSize = new Size(200, 300);
            else ClientSize = new Size(300, 200);

            Refresh();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_generic_priority_queue
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // The priority queue.
        private PriorityQueue<string> Queue = new PriorityQueue<string>();

        // Add an item to the queue.
        private void btnEnqueue_Click(object sender, EventArgs e)
        {
            Queue.Enqueue(txtValue.Text, int.Parse(txtPriority.Text));
            txtValue.Clear();
            txtPriority.Clear();
            txtValue.Focus();
            btnDequeue.Enabled = true;
        }

        // Remove the highest priority item from the queue.
        private void btnDequeue_Click(object sender, EventArgs e)
        {
            string top_value;
            int top_priority;
            Queue.Dequeue(out top_value, out top_priority);
            txtValue.Text = top_value;
            txtPriority.Text = top_priority.ToString();
            btnDequeue.Enabled = (Queue.NumItems > 0);
        }
    }
}

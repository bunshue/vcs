﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Net;
using System.Net.Mail;

namespace howto_email_secret_santas
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Send the message.
        private void btnSend_Click(object sender, EventArgs e)
        {
            lstMessages.Items.Clear();
            Cursor = Cursors.WaitCursor;
            btnSend.Enabled = false;
            Refresh();

            // Get email parameters.
            string from_name = txtFromName.Text;
            string from_email = txtFromEmail.Text;
            string host = txtHost.Text;
            int port = int.Parse(txtPort.Text);
            bool enable_ssl = chkEnableSSL.Checked;
            string password = txtPassword.Text;
            string subject = "Secret Santa assignment";

            // Get the recipients.
            char[] separators = { '\n', '\r' };
            string[] people =
                txtPeople.Text.Split(separators,
                    StringSplitOptions.RemoveEmptyEntries);

            // Get the secret Santa assignments.
            int num_people = people.Length;
            int num_tries;
            int[] assignments =
                SecretSantaAssignment(num_people, out num_tries);

            // Send the emails.
            try
            {
                for (int i = 0; i < num_people; i++)
                {
                    // Send people[i] his or her assignment.
                    string to_name = people[i].Split(';')[0];
                    string to_email = people[i].Split(';')[1];
                    string body =
                        "Your Secret Santa assignment is " +
                        people[assignments[i]];

                    Console.WriteLine(
                        "Sending message to " + to_name);
                    lstMessages.Items.Add(
                        "Sending message to " + to_name);
                    lstMessages.Refresh();
                    Application.DoEvents();

                    SendEmail(to_name, to_email,
                        from_name, from_email, host, port,
                        enable_ssl, password, subject, body);
                }
                MessageBox.Show("Sent " + num_people + " messages");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            Cursor = Cursors.Default;
        }

        // Generate a random derangement.
        private int[] SecretSantaAssignment(int N, out int num_tries)
        {
            // Make an array to hold the assignment.
            int[] assignments = new int[N];
            for (int i = 0; i < N; i++)
                assignments[i] = i;

            // Try random permutations until we find one that works.
            //Console.WriteLine();
            num_tries = 0;
            for (; ; )
            {
                // Randomize the assignment array.
                num_tries++;
                assignments.Randomize();

                // Display this permutation.
                //for (int i = 0; i < N; i++) Console.Write(assignments[i].ToString() + " ");
                //Console.WriteLine();

                // If this is an invalid assignment, try again.
                bool is_valid = true;
                for (int i = 0; i < N; i++)
                {
                    if (assignments[i] == i)
                    {
                        is_valid = false;
                        break;
                    }
                }

                // See if this is a valid assignment.
                if (is_valid) break;
            }

            return assignments;
        }

        // Send an email message.
        private void SendEmail(string to_name, string to_email,
            string from_name, string from_email,
            string host, int port, bool enable_ssl, string password,
            string subject, string body)
        {
            // Make the mail message.
            MailAddress from_address = new MailAddress(from_email, from_name);
            MailAddress to_address = new MailAddress(to_email, to_name);
            MailMessage message = new MailMessage(from_address, to_address);
            message.Subject = subject;
            message.Body = body;

            // Get the SMTP client.
            SmtpClient client = new SmtpClient()
            {
                Host = host,
                Port = port,
                EnableSsl = enable_ssl,
                DeliveryMethod = SmtpDeliveryMethod.Network,
                UseDefaultCredentials = false,
                Credentials = new NetworkCredential(from_address.Address, password),
            };

            // Send the message.
            client.Send(message);
        }
    }
}

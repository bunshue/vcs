﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

// Needed to use DllImport.
using System.Runtime.InteropServices;
using System.IO;

namespace howto_long_short_file_names
{
    public partial class Form1 : Form
    {
        // Define GetShortPathName API function.
        [DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        static extern uint GetShortPathName(string lpszLongPath, char[] lpszShortPath, int cchBuffer);
        
        public Form1()
        {
            InitializeComponent();
        }

        // Display the executable's long and short file names.
        private void Form1_Load(object sender, EventArgs e)
        {
            txtLongName.Text = Application.ExecutablePath;
        }

        // Display the long file name.
        private void btnToLong_Click(object sender, EventArgs e)
        {
            txtLongName.Text = LongFileName(txtShortName.Text);
        }

        // Display the short file name.
        private void btnToShort_Click(object sender, EventArgs e)
        {
            txtShortName.Text = ShortFileName(txtLongName.Text);
        }

        // Return the short file name for a long file name.
        private string ShortFileName(string long_name)
        {
            char[] name_chars = new char[1024];
            long length = GetShortPathName(
                long_name, name_chars,
                name_chars.Length);

            string short_name = new string(name_chars);
            return short_name.Substring(0, (int)length);
        }

        // Return the long file name for a short file name.
        private string LongFileName(string short_name)
        {
            return new FileInfo(short_name).FullName;
        }
    }
}

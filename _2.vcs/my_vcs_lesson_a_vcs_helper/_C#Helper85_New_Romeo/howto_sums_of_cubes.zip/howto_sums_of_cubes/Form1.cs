﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_sums_of_cubes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnGo_Click(object sender, EventArgs e)
        {
            txtResult.Clear();
            this.Cursor = Cursors.WaitCursor;

            long A = long.Parse(txtNumber.Text);
            long max_B = (long)Math.Pow(A / 2.0, 1.0 / 3.0);
            if (2 * max_B * max_B * max_B < A) max_B++;

            // Try numbers up to the cube root of A.
            for (int B = 0; B <= max_B; B++)
            {
                long remainder = A - (B * B * B);
                long C = (long)Math.Round(Math.Pow(remainder, 1.0 / 3.0));
                if (C * C * C == remainder)
                {
                    txtResult.Text +=
                        B + "^3 + " +
                        C + "^3 = " +
                        (B * B * B) + " + " + (C * C * C) + "\r\n";
                    txtResult.Select(0, 0);
                    Application.DoEvents();
                }
            }

            System.Media.SystemSounds.Beep.Play();
            this.Cursor = Cursors.Default;
        }
    }
}

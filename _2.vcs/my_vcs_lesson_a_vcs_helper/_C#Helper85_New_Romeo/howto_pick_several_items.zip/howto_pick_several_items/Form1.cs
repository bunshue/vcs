﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_pick_several_items
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Pick some items.
        private void btnPick_Click(object sender, EventArgs e)
        {
            int num_values = int.Parse(txtNumSelections.Text);
            txtResults.Lines = txtNames.Lines.PickRandom(num_values).ToArray();
        }
    }
}

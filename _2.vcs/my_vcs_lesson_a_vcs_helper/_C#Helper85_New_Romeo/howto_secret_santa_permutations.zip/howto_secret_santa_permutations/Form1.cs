﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_secret_santa_permutations
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            Cursor = Cursors.WaitCursor;
            txtTotal.Clear();
            txtFound.Clear();
            txtPercentValid.Clear();
            txtSubfactorial.Clear();
            Refresh();

            int N = int.Parse(txtNumPeople.Text);

            // Calculate the total number of permutations.
            decimal total = -1;
            try
            {
                total = Factorial(N);
                txtTotal.Text = total.ToString("N0");
            }
            catch
            {
                txtTotal.Text = "<Too many>";
            }

            // Calculate the number of derangements.
            decimal subfactorial = -1;
            try
            {
                subfactorial = Subfactorial(N);
                txtSubfactorial.Text = subfactorial.ToString("N0");
            }
            catch
            {
                txtSubfactorial.Text = "<Too many>";
            }

            // Calculate the percentage of valid permutations.
            if ((total < 0) || (subfactorial < 0))
            {
                txtPercentValid.Text = "<Too many>";
            }
            else
            {
                decimal percent = subfactorial / total;
                txtPercentValid.Text = percent.ToString("P");
            }

            if (N > 10)
            {
                txtFound.Text = "<Too many>";
                Cursor = Cursors.Default;
                return;
            }

            // Get the valid permutations.
            List<List<int>> permutations =
                SecretSantaPermutations(N);

            int num_valid = permutations.Count;
            txtFound.Text = num_valid.ToString("N0");

            // Display up to 1,000 permutations.
            if (num_valid > 1001) num_valid = 1001;
            string[] results = new string[num_valid];
            for (int i = 0; i < num_valid; i++)
            {
                results[i] = "";
                for (int j = 0; j < permutations[i].Count; j++)
                    results[i] += permutations[i][j].ToString() + " ";
            }
            if (permutations.Count > num_valid)
                results[num_valid - 1] = "...";
            lstValid.DataSource = results;

            Cursor = Cursors.Default;
        }

        // Calculate the factorial.
        private decimal Factorial(decimal N)
        {
            decimal result = 1;
            for (int i = 2; i <= N; i++)
                result *= i;
            return result;
        }

        // Calculate the subfactorial.
        private decimal Subfactorial(decimal N)
        {
            if (N == 0) return 1;
            if (N == 1) return 0;
            return (N - 1) * (Subfactorial(N - 1) + Subfactorial(N - 2));
        }

        // Generate all valid permutations.
        List<List<int>> SecretSantaPermutations(int N)
        {
            // A test assignment.
            int[] assignments = new int[N];

            // is_assigned[i] = true if person i has been assigned.
            bool[] is_assigned = new bool[N];

            // The valid permutations.
            List<List<int>> permutations = new List<List<int>>();

            // Make the permutations.
            AssignPerson(permutations, 0, N, assignments, is_assigned);

            // Return the valid permutations.
            return permutations;
        }

        // Assign the next person to position pos.
        void AssignPerson(List<List<int>> valid,
            int pos, int N, int[] assignments, bool[] is_assigned)
        {
            // If pos >= N, then we have a complete assigment.
            if (pos >= N)
            {
                // Save this assignment.
                List<int> result = new List<int>();
                for (int i = 0; i < N; i++)
                    result.Add(assignments[i]);
                valid.Add(result);
            }
            else
            {
                // Assign people to position pos.
                for (int per = 0; per < N; per++)
                {
                    // See if person per has been assigned.
                    // Only make the assigment if per != pos.
                    if ((per != pos) && (!is_assigned[per]))
                    {
                        // Assign person per to position pos.
                        assignments[pos] = per;
                        is_assigned[per] = true;

                        // Recursively try other assignments.
                        AssignPerson(valid, pos + 1, N, assignments, is_assigned);

                        // Unassign person per from position pos.
                        is_assigned[per] = false;
                    }
                }
            }
        }
    }
}

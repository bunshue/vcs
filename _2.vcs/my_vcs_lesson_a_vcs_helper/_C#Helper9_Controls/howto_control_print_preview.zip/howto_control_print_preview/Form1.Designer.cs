﻿namespace howto_control_print_preview
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.btnPreview = new System.Windows.Forms.Button();
            this.pdocShapes = new System.Drawing.Printing.PrintDocument();
            this.ppdShapes = new System.Windows.Forms.PrintPreviewDialog();
            this.chkMaximized = new System.Windows.Forms.CheckBox();
            this.chkZoom100 = new System.Windows.Forms.CheckBox();
            this.chkAntiAlias = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // btnPreview
            // 
            this.btnPreview.Location = new System.Drawing.Point(152, 31);
            this.btnPreview.Name = "btnPreview";
            this.btnPreview.Size = new System.Drawing.Size(75, 23);
            this.btnPreview.TabIndex = 3;
            this.btnPreview.Text = "Preview";
            this.btnPreview.UseVisualStyleBackColor = true;
            this.btnPreview.Click += new System.EventHandler(this.btnPreview_Click);
            // 
            // pdocShapes
            // 
            this.pdocShapes.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.pdocShapes_PrintPage);
            this.pdocShapes.BeginPrint += new System.Drawing.Printing.PrintEventHandler(this.pdocShapes_BeginPrint);
            // 
            // ppdShapes
            // 
            this.ppdShapes.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.ppdShapes.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.ppdShapes.ClientSize = new System.Drawing.Size(400, 300);
            this.ppdShapes.Document = this.pdocShapes;
            this.ppdShapes.Enabled = true;
            this.ppdShapes.Icon = ((System.Drawing.Icon)(resources.GetObject("ppdShapes.Icon")));
            this.ppdShapes.Name = "ppdShapes";
            this.ppdShapes.Visible = false;
            // 
            // chkMaximized
            // 
            this.chkMaximized.AutoSize = true;
            this.chkMaximized.Location = new System.Drawing.Point(12, 12);
            this.chkMaximized.Name = "chkMaximized";
            this.chkMaximized.Size = new System.Drawing.Size(75, 17);
            this.chkMaximized.TabIndex = 11;
            this.chkMaximized.Text = "Maximized";
            this.chkMaximized.UseVisualStyleBackColor = true;
            // 
            // chkZoom100
            // 
            this.chkZoom100.AutoSize = true;
            this.chkZoom100.Location = new System.Drawing.Point(12, 35);
            this.chkZoom100.Name = "chkZoom100";
            this.chkZoom100.Size = new System.Drawing.Size(82, 17);
            this.chkZoom100.TabIndex = 12;
            this.chkZoom100.Text = "Zoom 100%";
            this.chkZoom100.UseVisualStyleBackColor = true;
            // 
            // chkAntiAlias
            // 
            this.chkAntiAlias.AutoSize = true;
            this.chkAntiAlias.Location = new System.Drawing.Point(12, 58);
            this.chkAntiAlias.Name = "chkAntiAlias";
            this.chkAntiAlias.Size = new System.Drawing.Size(69, 17);
            this.chkAntiAlias.TabIndex = 13;
            this.chkAntiAlias.Text = "Anti-Alias";
            this.chkAntiAlias.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AcceptButton = this.btnPreview;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(325, 92);
            this.Controls.Add(this.chkAntiAlias);
            this.Controls.Add(this.chkZoom100);
            this.Controls.Add(this.chkMaximized);
            this.Controls.Add(this.btnPreview);
            this.Name = "Form1";
            this.Text = "howto_control_print_preview";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnPreview;
        private System.Drawing.Printing.PrintDocument pdocShapes;
        private System.Windows.Forms.PrintPreviewDialog ppdShapes;
        private System.Windows.Forms.CheckBox chkMaximized;
        private System.Windows.Forms.CheckBox chkZoom100;
        private System.Windows.Forms.CheckBox chkAntiAlias;
    }
}


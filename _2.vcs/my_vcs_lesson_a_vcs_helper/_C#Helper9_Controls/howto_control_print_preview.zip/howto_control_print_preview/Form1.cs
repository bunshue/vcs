﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Diagnostics;

// At design time set:
//      ppdShapes.Document = pdocShapes

namespace howto_control_print_preview
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Display a print preview.
        private void btnPreview_Click(object sender, EventArgs e)
        {
            // Set the size.
            Form frm = ppdShapes as Form;
            if (chkMaximized.Checked)
            {
                // Display maximized.
                frm.WindowState = FormWindowState.Maximized;
            }
            else
            {
                // Make the client area 400 x 400.
                frm.WindowState = FormWindowState.Normal;
                frm.StartPosition = FormStartPosition.CenterScreen;
                ppdShapes.ClientSize = new Size(400, 400);
            }

            // Set the dialog's title.
            frm.Text = "Numbers";

            // Set the zoom level.
            if (chkZoom100.Checked)
            {
                // 100%.
                ppdShapes.PrintPreviewControl.Zoom = 1.0;
            }
            else
            {
                // Auto.
                ppdShapes.PrintPreviewControl.AutoZoom = true;
            }

            // Set anti-aliasing.
            ppdShapes.PrintPreviewControl.UseAntiAlias = chkAntiAlias.Checked;

            // Set other properties.
            ppdShapes.PrintPreviewControl.Columns = 3;
            ppdShapes.PrintPreviewControl.Rows = 3;
            ppdShapes.PrintPreviewControl.BackColor = Color.Orange; // Background color.
            ppdShapes.PrintPreviewControl.ForeColor = Color.Yellow; // Paper color.
            ppdShapes.PrintPreviewControl.StartPage = 3;            // Page 3 in the upper left.
            
            // Display the dialog.
            ppdShapes.ShowDialog();
        }

        // Print the document's pages.
        private int m_NextPage = 0;
        private void pdocShapes_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            // Draw the margins.
            using (Pen dashed_pen = new Pen(Color.Red, 5))
            {
                dashed_pen.DashPattern = new float[] { 10, 10 };
                e.Graphics.DrawRectangle(dashed_pen, e.MarginBounds);
            }

            // Draw an ellipse.
            e.Graphics.DrawEllipse(Pens.Blue, e.MarginBounds);

            // Draw the page number.
            // Center it inside the margins.
            StringFormat sf = new StringFormat();
            sf.Alignment = StringAlignment.Center;
            sf.LineAlignment = StringAlignment.Center;

            using (Font the_font = new Font("Times New Roman", 200, FontStyle.Bold))
            {
                using (Brush the_brush = new SolidBrush(Color.Black))
                {
                    e.Graphics.DrawString(String.Format("{0}", m_NextPage + 1),
                        the_font, the_brush, e.MarginBounds, sf);
                }
            }

            // Next time print the next page.
            m_NextPage += 1;

            // We have more pages if wee have not yet printed page 10.
            e.HasMorePages = (m_NextPage <= 10);
        }

        // Get ready to print.
        private void pdocShapes_BeginPrint(object sender, System.Drawing.Printing.PrintEventArgs e)
        {
            // Start with page 0.
            m_NextPage = 0;
        }
    }
}

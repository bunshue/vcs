﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_use_notify_icon
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Display the happy icon.
        private void radHappy_Click(object sender, EventArgs e)
        {
            if (!radHappy.Checked) radHappy.Checked = true;
            this.Icon = Properties.Resources.HappyIco;
            NotifyIcon1.Icon = Properties.Resources.HappySmallIco;
            NotifyIcon1.Text = "Happy";
        }

        // Display the sad icon.
        private void radSad_Click(object sender, EventArgs e)
        {
            if (!radSad.Checked) radSad.Checked = true;
            this.Icon = Properties.Resources.SadIco;
            NotifyIcon1.Icon = Properties.Resources.SadSmallIco;
            NotifyIcon1.Text = "Sad";
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_try_catch
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Perform the calculation.
        private void btnCalculate_Click(object sender, EventArgs e)
        {
            // Clear the result (in case the calculation fails).
            txtResult.Clear();

            try
            {
                // Perform the operations that might fail.
                int x = int.Parse(txtX.Text);
                int y = int.Parse(txtY.Text);
                float result = x / y;
                txtResult.Text = result.ToString();
            }
            catch (FormatException)
            {
                // A formatting error occurred.
                // Report the error to the user.
                MessageBox.Show(
                    "The input values must be integers.",
                    "Invalid Input Values",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                // Some other error occurred.
                // Report the error to the user.
                MessageBox.Show(ex.Message, "Calculation Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);

                // Record the kind of exception class so we can catch it specifically.
                Console.WriteLine(ex.GetType().Name);
            }
            finally
            {
                MessageBox.Show("Done", "Done", 
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_make_dialog
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Display the dialog.
        private void btnSetName_Click(object sender, EventArgs e)
        {
            // Create and initialize the dialog.
            NameDialog dlg = new NameDialog();
            dlg.txtFirstName.Text = txtFirstName.Text;
            dlg.txtLastName.Text = txtLastName.Text;

            // Display the dialog and check the result.
            if (dlg.ShowDialog() == DialogResult.OK)
            {
                // The user clicked OK. Save the values.
                txtFirstName.Text = dlg.txtFirstName.Text;
                txtLastName.Text = dlg.txtLastName.Text;
            }
        }
    }
}

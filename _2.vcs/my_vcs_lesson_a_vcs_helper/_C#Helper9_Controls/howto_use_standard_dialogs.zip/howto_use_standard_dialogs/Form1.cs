﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_use_standard_dialogs
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Select the open file.
        private void btnOpenFile_Click(object sender, EventArgs e)
        {
            // Initialize the dialog.
            ofdFile.FileName = txtOpenFile.Text;

            // Display and check result.
            if (ofdFile.ShowDialog() == DialogResult.OK)
            {
                // Take action.
                txtOpenFile.Text = ofdFile.FileName;
            }
        }

        // Select the save file.
        private void btnSaveFile_Click(object sender, EventArgs e)
        {
            // Initialize the dialog.
            sfdFile.FileName = txtSaveFile.Text;

            // Display and check result.
            if (sfdFile.ShowDialog() == DialogResult.OK)
            {
                // Take action.
                txtSaveFile.Text = sfdFile.FileName;
            }
        }

        // Select foreground color.
        private void btnForeColor_Click(object sender, EventArgs e)
        {
            // Initialize.
            cdColor.Color = this.ForeColor;

            // Display and check result.
            if (cdColor.ShowDialog() == DialogResult.OK)
            {
                // Take action.
                this.ForeColor = cdColor.Color;
            }
        }

        // Select background color.
        private void btnBackColor_Click(object sender, EventArgs e)
        {
            // Initialize.
            cdColor.Color = this.BackColor;

            // Display and check result.
            if (cdColor.ShowDialog() == DialogResult.OK)
            {
                // Take action.
                this.BackColor = cdColor.Color;
            }
        }

        // Select the font.
        private void btnFont_Click(object sender, EventArgs e)
        {
            // Initialize.
            fdFont.Font = this.Font;

            // Display and check result.
            if (fdFont.ShowDialog() == DialogResult.OK)
            {
                // Take action.
                this.Font = fdFont.Font;
            }
        }
    }
}

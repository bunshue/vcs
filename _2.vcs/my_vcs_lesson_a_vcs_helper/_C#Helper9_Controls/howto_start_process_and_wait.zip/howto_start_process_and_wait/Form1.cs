﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.IO;
using System.Diagnostics;

namespace howto_start_process_and_wait
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Load the previously saved file.
        private string Filename = "";
        private void Form1_Load(object sender, EventArgs e)
        {
            // Compose the file's name.
            Filename = Path.GetFullPath(
                Path.Combine(Application.StartupPath, @"..\..")) +
                @"\text.rtf";

            // If the file exists, load it.
            if (File.Exists(Filename)) rchText.LoadFile(Filename);
        }

        // Allow the user to edit the file with WordPad.
        private void btnEdit_Click(object sender, EventArgs e)
        {
            // Hide.
            this.ShowInTaskbar = false;
            this.Hide();

            // Save the current text into the file.
            rchText.SaveFile(Filename);

            // We will open Filename with wordpad.exe.
            ProcessStartInfo start_info =
                new ProcessStartInfo("wordpad.exe", Filename);
            start_info.WindowStyle = ProcessWindowStyle.Maximized;

            // Open wordpad.
            Process proc = new Process();
            proc.StartInfo = start_info;
            proc.Start();

            // Wait for wordpad to finish.
            proc.WaitForExit();

            // Reload the file.
            rchText.LoadFile(Filename);

            // Unhide.
            this.ShowInTaskbar = true;
            this.Show();
        }

        // Save the current text into the file.
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            rchText.SaveFile(Filename);
        }
    }
}

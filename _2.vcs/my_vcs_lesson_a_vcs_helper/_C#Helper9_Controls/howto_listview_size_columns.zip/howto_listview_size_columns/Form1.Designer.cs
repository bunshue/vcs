﻿namespace howto_listview_size_columns
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lvwBooks = new System.Windows.Forms.ListView();
            this.btnSize100 = new System.Windows.Forms.Button();
            this.btnSizeMinus1 = new System.Windows.Forms.Button();
            this.btnSizeMinus2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lvwBooks
            // 
            this.lvwBooks.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)));
            this.lvwBooks.Location = new System.Drawing.Point(12, 41);
            this.lvwBooks.Name = "lvwBooks";
            this.lvwBooks.Size = new System.Drawing.Size(765, 150);
            this.lvwBooks.TabIndex = 1;
            this.lvwBooks.UseCompatibleStateImageBehavior = false;
            // 
            // btnSize100
            // 
            this.btnSize100.Location = new System.Drawing.Point(12, 12);
            this.btnSize100.Name = "btnSize100";
            this.btnSize100.Size = new System.Drawing.Size(75, 23);
            this.btnSize100.TabIndex = 2;
            this.btnSize100.Text = "Size = 100";
            this.btnSize100.UseVisualStyleBackColor = true;
            this.btnSize100.Click += new System.EventHandler(this.btnSize100_Click);
            // 
            // btnSizeMinus1
            // 
            this.btnSizeMinus1.Location = new System.Drawing.Point(107, 12);
            this.btnSizeMinus1.Name = "btnSizeMinus1";
            this.btnSizeMinus1.Size = new System.Drawing.Size(75, 23);
            this.btnSizeMinus1.TabIndex = 3;
            this.btnSizeMinus1.Text = "Size = -1";
            this.btnSizeMinus1.UseVisualStyleBackColor = true;
            this.btnSizeMinus1.Click += new System.EventHandler(this.btnSizeMinus1_Click);
            // 
            // btnSizeMinus2
            // 
            this.btnSizeMinus2.Location = new System.Drawing.Point(202, 12);
            this.btnSizeMinus2.Name = "btnSizeMinus2";
            this.btnSizeMinus2.Size = new System.Drawing.Size(75, 23);
            this.btnSizeMinus2.TabIndex = 4;
            this.btnSizeMinus2.Text = "Size = -2";
            this.btnSizeMinus2.UseVisualStyleBackColor = true;
            this.btnSizeMinus2.Click += new System.EventHandler(this.btnSizeMinus2_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(789, 203);
            this.Controls.Add(this.btnSizeMinus2);
            this.Controls.Add(this.btnSizeMinus1);
            this.Controls.Add(this.btnSize100);
            this.Controls.Add(this.lvwBooks);
            this.Name = "Form1";
            this.Text = "howto_listview_size_columns";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListView lvwBooks;
        private System.Windows.Forms.Button btnSize100;
        private System.Windows.Forms.Button btnSizeMinus1;
        private System.Windows.Forms.Button btnSizeMinus2;
    }
}


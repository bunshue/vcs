﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Diagnostics;

namespace howto_debug_assert
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnAssertOk_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Average: " + Average(new float[] { 1, 2, 3, 4, 5 }));
        }

        private void btnAssertFails_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Average: " + Average(null));
        }

        // Return the average of the numbers.
        private float Average(float[] values)
        {
            Debug.Assert(values != null, "Values array cannot be null");
            Debug.Assert(values.Length > 0, "Values array cannot be empty");
            Debug.Assert(values.Length < 100, "Values array should not contain more than 100 items");

            // If there are no values, return NaN.
            if (values == null || values.Length < 1) return float.NaN;

            // Calculate the average.
            return values.Average();
        }
    }
}

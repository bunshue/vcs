﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.IO;

namespace howto_file_versions
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Get the basic file name.
        private string LogFileName;
        private void Form1_Load(object sender, EventArgs e)
        {
            LogFileName = Application.StartupPath;
            LogFileName = Path.GetFullPath(
                Path.Combine(LogFileName, "..\\..\\log.txt"));
        }

        // Write an entry into the log file.
        private void btnWrite_Click(object sender, EventArgs e)
        {
            WriteToLog(txtEntry.Text, LogFileName, 100, 3);
            txtEntry.Clear();
            txtEntry.Focus();
        }

        // If the file exceeds max_size bytes, move it to a new file
        // with .1 appended to the name and bump down older versions.
        // (E.g. log.txt.1, log.txt.2, etc.)
        // Then write the text into the main log file. 
        private void WriteToLog(string new_text, string file_name, long max_size, int num_backups)
        {
            // See if the file is too big.
            FileInfo file_info = new FileInfo(file_name);
            if (file_info.Exists && file_info.Length > max_size)
            {
                // Remove the oldest version if it exists.
                if (File.Exists(file_name + "." + num_backups.ToString()))
                {
                    File.Delete(file_name + "." + num_backups.ToString());
                }

                // Bump down earlier backups.
                for (int i = num_backups - 1; i > 0; i--)
                {
                    if (File.Exists(file_name + "." + i.ToString()))
                    {
                        // Move file i to file i + 1.
                        File.Move(file_name + "." + i.ToString(),
                             file_name + "." + (i + 1).ToString());
                    }
                }

                // Move the main log file.
                File.Move(file_name, file_name + ".1");
            }

            // Write the text.
            File.AppendAllText(file_name, new_text + '\n');
        }
    }
}

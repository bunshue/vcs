﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

// At design time set:
//      ppdShapes.Document = pdocShapes

namespace howto_print
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Display a print preview.
        private void btnPreview_Click(object sender, EventArgs e)
        {
            ppdShapes.ShowDialog();
        }

        // Print.
        private void btnPrint_Click(object sender, EventArgs e)
        {
            pdocShapes.Print();
        }

        // Print the document's pages.
        private int NextPageNum = 0;
        private void pdocShapes_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            // Draw a shape depending on the page we are printing.
            switch (NextPageNum)
            {
                case 0: // Draw an ellipse.
                    using (Pen the_pen = new Pen(Color.Red, 10))
                    {
                        e.Graphics.DrawEllipse(the_pen, e.MarginBounds);
                    }
                    break;
                case 1: // Draw a triangle.
                    using (Pen the_pen = new Pen(Color.Green, 10))
                    {
                        int xmid = (int)(e.MarginBounds.X + e.MarginBounds.Width / 2);
                        Point[] pts = 
                        {
                            new Point(xmid, e.MarginBounds.Top),
                            new Point(e.MarginBounds.Right, e.MarginBounds.Bottom),
                            new Point(e.MarginBounds.Left, e.MarginBounds.Bottom),
                        };
                        e.Graphics.DrawPolygon(the_pen, pts);
                    }
                    break;
                case 2: // Draw a rectangle.
                    using (Pen the_pen = new Pen(Color.Blue, 10))
                    {
                        e.Graphics.DrawRectangle(the_pen, e.MarginBounds);
                    }
                    break;
                case 3: // Draw a diamond.
                    using (Pen the_pen = new Pen(Color.Orange, 10))
                    {
                        int xmid = (int)(e.MarginBounds.X + e.MarginBounds.Width / 2);
                        int ymid = (int)(e.MarginBounds.Y + e.MarginBounds.Height / 2);
                        Point[] pts = 
                        {
                            new Point(xmid, e.MarginBounds.Top),
                            new Point(e.MarginBounds.Right, ymid),
                            new Point(xmid, e.MarginBounds.Bottom),
                            new Point(e.MarginBounds.Left, ymid),
                        };
                        e.Graphics.DrawPolygon(the_pen, pts);
                    }
                    break;
            }

            // Draw the page number centered.
            using (StringFormat sf = new StringFormat())
            {
                sf.Alignment = StringAlignment.Center;
                sf.LineAlignment = StringAlignment.Center;

                using (Font the_font = new Font("Times New Roman", 200, FontStyle.Bold))
                {
                    using (Brush the_brush = new SolidBrush(Color.Black))
                    {
                        e.Graphics.DrawString(String.Format("{0}", NextPageNum + 1),
                            the_font, the_brush, e.MarginBounds, sf);
                    }
                }
            }

            // Next time print the next page.
            NextPageNum += 1;

            // We have more pages if we have not yet printed page 3.
            e.HasMorePages = (NextPageNum <= 3);

            // If we have no more pages, reset for the next time we print.
            if (NextPageNum > 3) NextPageNum = 0;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.IO;

namespace howto_compare_directories
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string base_dir = Application.StartupPath;
            if (base_dir.EndsWith("\\bin\\Debug"))
            {
                base_dir = base_dir.Substring(0, base_dir.Length - 10);
            }

            txtDir1.Text = base_dir + "\\Dir1";
            txtDir2.Text = base_dir + "\\Dir2";

            SizeColumns();
        }

        private void Form1_Resize(object sender, EventArgs e)
        {
            SizeColumns();
        }

        private void SizeColumns()
        {
            int wid = (int)((dgvFiles.Width - 50) / 2);
            if (wid < 10) wid = 10;
            dgvFiles.Columns[0].Width = wid;
            dgvFiles.Columns[1].Width = wid;
        }

        // Compare the files in each directory.
        private void btnCompare_Click(object sender, EventArgs e)
        {
            // Clear previous results.
            dgvFiles.Rows.Clear();

            // Get sorted lists of files in the directories.
            string dir1 = txtDir1.Text;
            if (!dir1.EndsWith("\\")) dir1 += "\\";
            string[] file_names1 = Directory.GetFiles(dir1);
            for (int i = 0; i < file_names1.Length; i++)
            {
                file_names1[i] = file_names1[i].Replace(dir1, "");
            }
            Array.Sort(file_names1);

            string dir2 = txtDir2.Text;
            if (!dir2.EndsWith("\\")) dir2 += "\\";
            string[] file_names2 = Directory.GetFiles(dir2);
            for (int i = 0; i < file_names2.Length; i++)
            {
                file_names2[i] = file_names2[i].Replace(dir2, "");
            }
            Array.Sort(file_names2);

            // Compare.
            int i1 = 0, i2 = 0;
            while ((i1 < file_names1.Length) && (i2 < file_names2.Length))
            {
                if (file_names1[i1] == file_names2[i2])
                {
                    // They match. Display them both.
                    dgvFiles.Rows.Add(new Object[] { file_names1[i1], file_names2[i2] });
                    i1++;
                    i2++;
                }
                else if (file_names1[i1].CompareTo(file_names2[i2]) < 0)
                {
                    // Display the directory 1 file.
                    dgvFiles.Rows.Add(new Object[] { file_names1[i1], null });
                    i1++;
                }
                else
                {
                    // Display the directory 2 file.
                    dgvFiles.Rows.Add(new Object[] { null, file_names2[i2] });
                    i2++;
                }
            }

            // Display remaining directory 1 files.
            for (int i = i1; i < file_names1.Length; i++)
            {
                dgvFiles.Rows.Add(new Object[] { file_names1[i], null });
            }

            // Display remaining directory 2 files.
            for (int i = i2; i < file_names2.Length; i++)
            {
                dgvFiles.Rows.Add(new Object[] { null, file_names2[i] });
            }
        }
    }
}

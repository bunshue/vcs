﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_use_resources
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void radMercury_CheckedChanged(object sender, EventArgs e)
        {
            picPlanet.Image = Properties.Resources.Mercury;
        }

        private void radVenus_CheckedChanged(object sender, EventArgs e)
        {
            picPlanet.Image = Properties.Resources.Venus;
        }

        private void radEarth_CheckedChanged(object sender, EventArgs e)
        {
            picPlanet.Image = Properties.Resources.Earth;
        }

        private void radMars_CheckedChanged(object sender, EventArgs e)
        {
            picPlanet.Image = Properties.Resources.Mars;
        }

        private void radJupiter_CheckedChanged(object sender, EventArgs e)
        {
            picPlanet.Image = Properties.Resources.Jupiter;
        }

        private void radSaturn_CheckedChanged(object sender, EventArgs e)
        {
            picPlanet.Image = Properties.Resources.Saturn;
        }

        private void radUranus_CheckedChanged(object sender, EventArgs e)
        {
            picPlanet.Image = Properties.Resources.Uranus;
        }

        private void radNeptune_CheckedChanged(object sender, EventArgs e)
        {
            picPlanet.Image = Properties.Resources.Neptune;
        }

        private void radPulto_CheckedChanged(object sender, EventArgs e)
        {
            picPlanet.Image = Properties.Resources.Pluto;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_add_items_to_combobox
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Load saved ComboBox entries.
        private void Form1_Load(object sender, EventArgs e)
        {
            // Save the current ComboBox items.
            for (int i = 0; ; i++)
            {
                string animal = RegistryTools.GetSetting(
                    "howto_add_items_to_combobox",
                    "Animals", "Animal" + i.ToString(), "").ToString();
                if (animal == "") break;
                cboAnimal.Items.Add(animal);
            }

            // If we have any choices, select the first.
            if (cboAnimal.Items.Count > 0) cboAnimal.SelectedIndex = 0;
        }

        // Save the current ComboBox choices.
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            // Delete previous settings.
            RegistryTools.DeleteSettings("howto_add_items_to_combobox", "Animals");

            // Save the current ComboBox items.
            for (int i = 0; i < cboAnimal.Items.Count; i++)
            {
                RegistryTools.SaveSetting("howto_add_items_to_combobox",
                    "Animals", "Animal" + i.ToString(), cboAnimal.Items[i]);
            }
        }

        // Display the animal selected.
        private void btnOk_Click(object sender, EventArgs e)
        {
            MessageBox.Show("You selected " + cboAnimal.Text);
        }

        // When focus leaves the control, update its item list.
        private void cboAnimal_Leave(object sender, EventArgs e)
        {
            UpdateCombo(cboAnimal);
        }

        // If the ComboBox's current choice isn't in its list, add it.
        private void UpdateCombo(ComboBox cbo)
        {
            // See if the item is in the list.
            string new_text = cbo.Text;
            foreach (object value in cbo.Items)
            {
                // If the item is already in the list, we're done.
                if (new_text == value.ToString()) return;
            }

            // If we got this far, it's not in the list so add it.
            cbo.Items.Add(new_text);
        }
    }
}

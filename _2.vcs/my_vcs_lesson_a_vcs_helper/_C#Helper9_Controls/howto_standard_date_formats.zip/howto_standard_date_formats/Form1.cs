﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_standard_date_formats
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            DateTime now = DateTime.Now;
            lvwResults.Items.Add(new ListViewItem(new String[] { "Short date", "d", now.ToString("d") }, lvwResults.Groups[0]));
            lvwResults.Items.Add(new ListViewItem(new String[] { "Long date", "D", now.ToString("D") }, lvwResults.Groups[0]));
            lvwResults.Items.Add(new ListViewItem(new String[] { "Month/day", "M or m", now.ToString("m") }, lvwResults.Groups[0]));
            lvwResults.Items.Add(new ListViewItem(new String[] { "Year/month", "Y or y", now.ToString("y") }, lvwResults.Groups[0]));

            lvwResults.Items.Add(new ListViewItem(new String[] { "Short time", "t", now.ToString("t") }, lvwResults.Groups[1]));
            lvwResults.Items.Add(new ListViewItem(new String[] { "Long time", "T", now.ToString("T") }, lvwResults.Groups[1]));

            lvwResults.Items.Add(new ListViewItem(new String[] { "Full date/time (short time)", "f", now.ToString("f") }, lvwResults.Groups[2]));
            lvwResults.Items.Add(new ListViewItem(new String[] { "Full date/time (long time)", "F", now.ToString("F") }, lvwResults.Groups[2]));
            lvwResults.Items.Add(new ListViewItem(new String[] { "General date/time (short time)", "g", now.ToString("g") }, lvwResults.Groups[2]));
            lvwResults.Items.Add(new ListViewItem(new String[] { "General date/time (long time)", "G", now.ToString("G") }, lvwResults.Groups[2]));
            lvwResults.Items.Add(new ListViewItem(new String[] { "Round-trip date/time", "O or o", now.ToString("o") }, lvwResults.Groups[2]));
            lvwResults.Items.Add(new ListViewItem(new String[] { "RFC1123", "R or r", now.ToString("r") }, lvwResults.Groups[2]));
            lvwResults.Items.Add(new ListViewItem(new String[] { "Sortable date/time", "s", now.ToString("s") }, lvwResults.Groups[2]));
            lvwResults.Items.Add(new ListViewItem(new String[] { "Universal sortable date/time", "u", now.ToString("s") }, lvwResults.Groups[2]));
            lvwResults.Items.Add(new ListViewItem(new String[] { "Universal full date/time", "U", now.ToString("u") }, lvwResults.Groups[2]));

            // Generate code for an HTML table.
            Console.WriteLine(ListViewToHtmlTable(lvwResults, 1, 0, 5));
        }

        // Return an HTML table showing the ListView's contents.
        private string ListViewToHtmlTable(ListView lvw, int border, int cell_spacing, int cell_padding)
        {
            // Open the <table> element.
            string txt = "<table " +
                "border=\"" + border.ToString() + "\" " +
                "cellspacing=\"" + cell_spacing.ToString() + "\" " +
                "cellpadding=\"" + cell_padding.ToString() + "\">\n";

            // See how many columns there are.
            int num_cols = lvw.Columns.Count;

            // See if there are any non-grouped items.
            bool have_non_grouped_items = false;
            foreach (ListViewItem item in lvw.Items)
            {
                if (item.Group == null)
                {
                    have_non_grouped_items = true;
                    break;
                }
            }

            // Display non-grouped items.
            if (have_non_grouped_items)
            {
                // Display the column headers.
                txt += ListViewColumnHeaderHtml(lvw);

                // Display the non-grouped items.
                foreach (ListViewItem item in lvw.Items)
                {
                    if (item.Group == null)
                    {
                        // Display this item.
                        txt += ListViewItemHtml(item);
                    }
                }
            }

            // Process the groups.
            foreach (ListViewGroup grp in lvw.Groups)
            {
                // Display the header.
                txt += "  <tr><th " +
                    "colspan=\"" + num_cols + "\" " +
                    "align=\"" + grp.HeaderAlignment.ToString() + "\" " +
                    "bgcolor=\"LightBlue\">" +
                    grp.Header + "</th></tr>\n";

                // Display the column headers.
                txt += ListViewColumnHeaderHtml(lvw);

                // Display the items in the group.
                foreach (ListViewItem item in grp.Items)
                {
                    txt += ListViewItemHtml(item);
                }
            }
            txt += "</table>\n";
            return txt;
        }

        // Return a string representing ListView column headers.
        private string ListViewColumnHeaderHtml(ListView lvw)
        {
            // Display the column headers.
            string txt = "  <tr>";
            foreach (ColumnHeader col in lvw.Columns)
            {
                // Display this column header.
                txt += "<th bgcolor=\"#CCFFFF\"" +
                    "width=\"" + col.Width.ToString() + "\" " +
                    "align=\"" + col.TextAlign.ToString() + "\">" +
                    col.Text + "</th>";
            }
            txt += "</tr>\n";
            return txt;
        }

        // Return the HTML text representing this item's row.
        private string ListViewItemHtml(ListViewItem item)
        {
            string txt = "  <tr>";
            ListView lvw = item.ListView;
            for (int i = 0; i < item.SubItems.Count; i++)
            {
                txt += "<td " +
                    "align=\"" + lvw.Columns[i].TextAlign.ToString() + "\">" +
                    item.SubItems[i].Text + "</td>";
            }
            txt += "</tr>\n";
            return txt;
        }
    }
}

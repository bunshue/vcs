﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_custom_number_formats
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            lvwResults.Items.Add(new ListViewItem(new String[] { "Zero placeholder", "0", "A digit or 0 if no digit is present" }));
            lvwResults.Items.Add(new ListViewItem(new String[] { "Digit placeholder", "#", "A digit or nothing if no digit is present" }));
            lvwResults.Items.Add(new ListViewItem(new String[] { "Decimal separator", ".", "The decimal separator" }));
            lvwResults.Items.Add(new ListViewItem(new String[] { "Thousands separator", ",", "Thousands separator" }));
            lvwResults.Items.Add(new ListViewItem(new String[] { "Scaling", ",", "When placed at the end of the format string, divides by 1000" }));
            lvwResults.Items.Add(new ListViewItem(new String[] { "Percent placeholder", "%", "Multiplies by 100 and inserts a percent symbol" }));
            lvwResults.Items.Add(new ListViewItem(new String[] { "Per mille placeholder", "‰", "Multiplies by 100 and inserts a per mille symbol" }));
            lvwResults.Items.Add(new ListViewItem(new String[] { "Exponentiation", "E+0", "Exponentiation." }));
            lvwResults.Items.Add(new ListViewItem(new String[] { "Escape character", "\\", "The following character is not interpreted as a formatting character" }));
            lvwResults.Items.Add(new ListViewItem(new String[] { "Literal string", "'...'", "The characters in single or double quotes are displayed literally" }));
            lvwResults.Items.Add(new ListViewItem(new String[] { "Section separator", ";", "Creates up to three sections for values > 0, < 0, or = 0." }));

            lvwSamples.Items.Add(new ListViewItem(new String[] { "123(\"00000\")", 123.ToString("00000") }));
            lvwSamples.Items.Add(new ListViewItem(new String[] { "123(\"#####\")", 123.ToString("#####") }));
            lvwSamples.Items.Add(new ListViewItem(new String[] { "123.4567(\"0.00\")", 123.4567.ToString("0.00") }));
            lvwSamples.Items.Add(new ListViewItem(new String[] { "1234567890(\"#,#\")", 1234567890.ToString("#,#") }));
            lvwSamples.Items.Add(new ListViewItem(new String[] { "1234567890(\"#,#,,\")", 1234567890.ToString("#,#,,") }));
            lvwSamples.Items.Add(new ListViewItem(new String[] { "0.1234(\"#.#%\")", 0.1234.ToString("#.#%") }));
            lvwSamples.Items.Add(new ListViewItem(new String[] { "1234567890(\"#E000\")", 1234567890.ToString("#E000") }));
            lvwSamples.Items.Add(new ListViewItem(new String[] { "1234567890(\"#E+000\")", 1234567890.ToString("#E+000") }));
            lvwSamples.Items.Add(new ListViewItem(new String[] { "0.00001234(\"#E000\")", 0.00001234.ToString("#E000") }));
            lvwSamples.Items.Add(new ListViewItem(new String[] { "1.234(\"+0.00;<0.00>;-zero-\")", 1.234.ToString("+0.00;<0.00>;-zero-") }));
            lvwSamples.Items.Add(new ListViewItem(new String[] { "-1.234(\"+0.00;<0.00>;-zero-\")", (-1.234).ToString("+0.00;<0.00>;-zero-") }));
            lvwSamples.Items.Add(new ListViewItem(new String[] { "0(\"+0.00;<0.00>;-zero-\")", 0.ToString("+0.00;<0.00>;-zero-") }));

            // Generate code for an HTML tables.
            Console.WriteLine(ListViewToHtmlTable(lvwResults, 1, 0, 5));
            Console.WriteLine(ListViewToHtmlTable(lvwSamples, 1, 0, 5));
        }

        // Return an HTML table showing the ListView's contents.
        private string ListViewToHtmlTable(ListView lvw, int border, int cell_spacing, int cell_padding)
        {
            // Open the <table> element.
            string txt = "<table " +
                "border=\"" + border.ToString() + "\" " +
                "cellspacing=\"" + cell_spacing.ToString() + "\" " +
                "cellpadding=\"" + cell_padding.ToString() + "\">\n";

            // See how many columns there are.
            int num_cols = lvw.Columns.Count;

            // See if there are any non-grouped items.
            bool have_non_grouped_items = false;
            foreach (ListViewItem item in lvw.Items)
            {
                if (item.Group == null)
                {
                    have_non_grouped_items = true;
                    break;
                }
            }

            // Display non-grouped items.
            if (have_non_grouped_items)
            {
                // Display the column headers.
                txt += ListViewColumnHeaderHtml(lvw);

                // Display the non-grouped items.
                foreach (ListViewItem item in lvw.Items)
                {
                    if (item.Group == null)
                    {
                        // Display this item.
                        txt += ListViewItemHtml(item);
                    }
                }
            }

            // Process the groups.
            foreach (ListViewGroup grp in lvw.Groups)
            {
                // Display the header.
                txt += "  <tr><th " +
                    "colspan=\"" + num_cols + "\" " +
                    "align=\"" + grp.HeaderAlignment.ToString() + "\" " +
                    "bgcolor=\"LightBlue\">" +
                    grp.Header + "</th></tr>\n";

                // Display the column headers.
                txt += ListViewColumnHeaderHtml(lvw);

                // Display the items in the group.
                foreach (ListViewItem item in grp.Items)
                {
                    txt += ListViewItemHtml(item);
                }
            }
            txt += "</table>\n";
            return txt;
        }

        // Return a string representing ListView column headers.
        private string ListViewColumnHeaderHtml(ListView lvw)
        {
            // Display the column headers.
            string txt = "  <tr>";
            foreach (ColumnHeader col in lvw.Columns)
            {
                // Display this column header.
                txt += "<th bgcolor=\"#CCFFFF\"" +
                    "width=\"" + col.Width.ToString() + "\" " +
                    "align=\"" + col.TextAlign.ToString() + "\">" +
                    col.Text + "</th>";
            }
            txt += "</tr>\n";
            return txt;
        }

        // Return the HTML text representing this item's row.
        private string ListViewItemHtml(ListViewItem item)
        {
            string txt = "  <tr>";
            ListView lvw = item.ListView;
            for (int i = 0; i < item.SubItems.Count; i++)
            {
                txt += "<td " +
                    "align=\"" + lvw.Columns[i].TextAlign.ToString() + "\">" +
                    item.SubItems[i].Text + "</td>";
            }
            txt += "</tr>\n";
            return txt;
        }
    }
}

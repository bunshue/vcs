﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_size_richtextbox_to_fit
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Don't let the RichTextBox wrap long lines.
        private void Form1_Load(object sender, EventArgs e)
        {
            rchContents.WordWrap = false;
            rchContents.ScrollBars = RichTextBoxScrollBars.None;
        }

        // Make the RichTextBox fit its contents.
        private void rchContents_ContentsResized(object sender, ContentsResizedEventArgs e)
        {
            const int margin = 5;
            RichTextBox rch = sender as RichTextBox;
            rch.ClientSize = new Size(
                e.NewRectangle.Width + margin,
                e.NewRectangle.Height + margin);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_xml_comments
{
    public partial class Form1 : Form
    {
        /// <summary>
        /// Initialize the form. (Because this is automatically generated code
        /// you might think it would automatically generate the XML comment
        /// but it doesn't.)
        /// </summary>
        public Form1()
        {
            InitializeComponent();
        }

        // Make a TestScore object and see what grade the student would get.
        private void btnCalculate_Click(object sender, EventArgs e)
        {
            int test_number = int.Parse(txtTestNumber.Text);
            int score = int.Parse(txtScore.Text);
            TestScore test_score = new TestScore(test_number, score);
            MessageBox.Show(test_score.Grade(null, null));
        }
    }
}

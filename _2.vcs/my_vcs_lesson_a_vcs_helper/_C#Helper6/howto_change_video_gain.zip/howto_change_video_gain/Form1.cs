﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

// Add a references to:
//      Microsoft.Expression.Encoder
//      Microsoft.Expression.Encoder.Api2
//      Microsoft.Expression.Encoder.Types
//      Microsoft.Expression.Encoder.Utilities

using Microsoft.Expression.Encoder;
using Microsoft.Expression.Encoder.Profiles;
using System.IO;

namespace howto_change_video_gain
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void txtMovie_TextChanged(object sender, EventArgs e)
        {
            btnCreate.Enabled = File.Exists(txtMovie.Text);
        }

        private void btnMovie_Click(object sender, EventArgs e)
        {
            ofdMovie.FileName = txtMovie.Text;
            if (ofdMovie.ShowDialog() == DialogResult.OK)
                txtMovie.Text = ofdMovie.FileName;
        }

        private void btnCreate_Click(object sender, EventArgs e)
        {
            if (sfdMerged.ShowDialog() != DialogResult.OK) return;
            Cursor = Cursors.WaitCursor;
            prgEncode.Value = 0;
            prgEncode.Visible = true;
            Refresh();

            try
            {
                // Create a job.
                using (Job job = new Job())
                {
                    // Make a MediaItem containing the splash video.
                    MediaItem media_item = new MediaItem(txtMovie.Text);
                    job.MediaItems.Add(media_item);

                    // Use the original size.
                    media_item.OutputFormat.VideoProfile.Size =
                        media_item.OriginalVideoSize;

                    // Set the quality.
                    double gain;
                    if (trkGain.Value <= 0)
                        gain = (10.0 + trkGain.Value) / 10.0;
                    else
                        gain = trkGain.Value;
                    Console.WriteLine("Gain: " + gain);
                    media_item.AudioGainLevel = gain;

                    // Set the output directory.
                    FileInfo file_info = new FileInfo(sfdMerged.FileName);
                    job.OutputDirectory = file_info.DirectoryName;

                    // Set the output file name.
                    media_item.OutputFileName = file_info.Name;

                    // Don't create a subdirectory.
                    job.CreateSubfolder = false;

                    // Install the progress event handler.
                    job.EncodeProgress += job_EncodeProgress;

                    // Encode.
                    job.Encode();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            Cursor = Cursors.Default;
            prgEncode.Visible = false;
        }

        // Display progress.
        private void job_EncodeProgress(object sender, EncodeProgressEventArgs e)
        {
            prgEncode.Value = (int)e.Progress;
            Refresh();
        }

        private void trkGain_Scroll(object sender, EventArgs e)
        {
            txtQuality.Text = trkGain.Value.ToString();
        }
    }
}

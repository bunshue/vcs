﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.IO;
using System.Drawing.Imaging;

namespace howto_zoom_picture
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Set the menus' Tag values.
        private void Form1_Load(object sender, EventArgs e)
        {
            picZoom.SizeMode = PictureBoxSizeMode.StretchImage;

            mnuScale1_2.Tag = 0.5f;
            mnuScale1.Tag = 1f;
            mnuScale2.Tag = 2f;
            mnuScale4.Tag = 4f;
            mnuScale6.Tag = 6f;
        }

        // Exit the program.
        private void mnuFileExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        // Open a file.
        private void mnuFileOpen_Click(object sender, EventArgs e)
        {
            if (ofdPicture.ShowDialog() == DialogResult.OK)
            {
                Bitmap bm = LoadBitmapUnlocked(ofdPicture.FileName);
                picZoom.ClientSize = new Size(bm.Width, bm.Height);
                picZoom.Image = bm;

                CheckMenuItem(mnuScale1);

                picZoom.Visible = true;
            }
        }

        // Check this menu item and uncheck the others.
        private void CheckMenuItem(ToolStripMenuItem mnu)
        {
            ToolStripMenuItem[] items =
            {
                mnuScale1_2, mnuScale1, mnuScale2, mnuScale4, mnuScale6
            };
            foreach (ToolStripMenuItem item in items)
            {
                item.Checked = (item == mnu);
            }
        }

        // Save the current file.
        private void mnuFileSave_Click(object sender, EventArgs e)
        {
            if (sfdPicture.ShowDialog() == DialogResult.OK)
            {
                // Make a bitmap of the correct size.
                using (Bitmap bm = new Bitmap(
                    picZoom.ClientSize.Width,
                    picZoom.ClientSize.Height))
                {
                    // Copy the original image onto the new bitmap.
                    using (Graphics gr = Graphics.FromImage(bm))
                    {
                        Rectangle source_rect = new Rectangle(
                            0, 0, picZoom.Image.Width, picZoom.Image.Height);
                        Rectangle dest_rect = new Rectangle(
                            0, 0, bm.Width, bm.Height);
                        gr.DrawImage(picZoom.Image,
                            dest_rect, source_rect, GraphicsUnit.Pixel);
                    }

                    // Save the bitmap.
                    SaveImage(bm, sfdPicture.FileName);
                }
            }
        }

        // Save the file with the appropriate format.
        public void SaveImage(Image image, string filename)
        {
            string extension = Path.GetExtension(filename);
            switch (extension.ToLower())
            {
                case ".bmp":
                    image.Save(filename, ImageFormat.Bmp);
                    break;
                case ".exif":
                    image.Save(filename, ImageFormat.Exif);
                    break;
                case ".gif":
                    image.Save(filename, ImageFormat.Gif);
                    break;
                case ".jpg":
                case ".jpeg":
                    image.Save(filename, ImageFormat.Jpeg);
                    break;
                case ".png":
                    image.Save(filename, ImageFormat.Png);
                    break;
                case ".tif":
                case ".tiff":
                    image.Save(filename, ImageFormat.Tiff);
                    break;
                default:
                    throw new NotSupportedException(
                        "Unknown file extension " + extension);
            }
        }

        // Load a bitmap without locking it.
        private Bitmap LoadBitmapUnlocked(string file_name)
        {
            using (Bitmap bm = new Bitmap(file_name))
            {
                return new Bitmap(bm);
            }
        }

        // Scale the image.
        private void mnuScale_Click(object sender, EventArgs e)
        {
            ToolStripMenuItem mnu = sender as ToolStripMenuItem;
            float scale = (float)mnu.Tag;
            picZoom.ClientSize = new Size(
                (int)(scale * picZoom.Image.Width),
                (int)(scale * picZoom.Image.Height));
            CheckMenuItem(mnu);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_load_image_unlocked
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Load the image normally.
        private void btnLoadNormally_Click(object sender, EventArgs e)
        {
            if (picSample.Image != null) picSample.Image.Dispose();
            picSample.Image = new Bitmap("essential_algs_75.jpg");
        }

        // Load the bitmap without locking it.
        private void btnLoadUnlocked_Click(object sender, EventArgs e)
        {
            if (picSample.Image != null) picSample.Image.Dispose();
            picSample.Image = LoadBitmapUnlocked("essential_algs_75.jpg");
        }

        // Load a bitmap without locking it.
        private Bitmap LoadBitmapUnlocked(string file_name)
        {
            using (Bitmap bm = new Bitmap(file_name))
            {
                return new Bitmap(bm);
            }
        }

        // Open the book's web page.
        private void picSample_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("http://www.csharphelper.com/algorithms.html");
        }
    }
}

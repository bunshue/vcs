using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Drawing.Drawing2D;

namespace howto_zoom_big_bitmap
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // The Bitmap we display.
        private Bitmap Bm = null;

        // The dimensions of the drawing area in world coordinates.
        private const int WorldWidth = 100;
        private const int WorldHeight = 100;

        // The scale.
        private float PictureScale = 1.0f;

        // Select normal scale.
        private void Form1_Load(object sender, EventArgs e)
        {
            cboScale.SelectedIndex = 2;
        }

        // Set the selected scale.
        private void cboScale_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (cboScale.SelectedIndex)
            {
                case 0:
                    SetScale(0.25f);
                    break;
                case 1:
                    SetScale(0.5f);
                    break;
                case 2:
                    SetScale(1f);
                    break;
                case 3:
                    SetScale(2f);
                    break;
                case 4:
                    SetScale(4f);
                    break;
                case 5:
                    SetScale(8f);
                    break;
            }
        }

        // Set the scale and redraw.
        private void SetScale(float picture_scale)
        {
            // Set the scale.
            PictureScale = picture_scale;

            // Make a Bitmap of the right size.
            Bm = new Bitmap(
                (int)(PictureScale * WorldWidth),
                (int)(PictureScale * WorldHeight));

            // Make a Graphics object for the Bitmap.
            // (If you need to use this later, you can give it
            // class scope so you don't need to make a new one.)
            using (Graphics gr = Graphics.FromImage(Bm))
            {
                // Use a white background
                // (so you can see where the picture is).
                gr.Clear(Color.White);

                // Draw smoothly.
                gr.SmoothingMode = SmoothingMode.AntiAlias;

                // Scale.
                gr.ScaleTransform(PictureScale, PictureScale);

                // Draw the image.
                DrawImage(gr);
            }

            // Display the result.
            picCanvas.Image = Bm;
        }

        // Draw the image in world coordinates.
        private void DrawImage(Graphics gr)
        {
            Rectangle rect;

            rect = new Rectangle(10, 10, 80, 80);
            gr.FillEllipse(Brushes.LightGreen, rect);
            gr.DrawEllipse(Pens.Green, rect);

            rect = new Rectangle(40, 40, 20, 30);
            gr.FillEllipse(Brushes.LightBlue, rect);
            gr.DrawEllipse(Pens.Blue, rect);

            rect = new Rectangle(25, 30, 50, 50);
            gr.DrawArc(Pens.Red, rect, 20, 140);

            rect = new Rectangle(25, 25, 15, 20);
            gr.FillEllipse(Brushes.White, rect);
            gr.DrawEllipse(Pens.Black, rect);
            rect = new Rectangle(30, 30, 10, 10);
            gr.FillEllipse(Brushes.Black, rect);

            rect = new Rectangle(60, 25, 15, 20);
            gr.FillEllipse(Brushes.White, rect);
            gr.DrawEllipse(Pens.Black, rect);
            rect = new Rectangle(65, 30, 10, 10);
            gr.FillEllipse(Brushes.Black, rect);
        }
    }
}

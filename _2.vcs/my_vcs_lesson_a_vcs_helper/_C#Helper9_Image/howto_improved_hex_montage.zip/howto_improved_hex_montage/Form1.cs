﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.IO;

namespace howto_improved_hex_montage
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // The height of a hexagon.
        private float HexHeight = 50;
        private float BorderThickness = 5;
 
        // Selected hexagons.
        private List<Hexagon> Hexagons = new List<Hexagon>();

        private int NumRows = 1, NumCols = 1;
        private Bitmap GridImage = null;

        // Draw the grid and its images.
        private void DrawGrid(Graphics gr, int xmax, int ymax)
        {
            gr.Clear(picBackgroundColor.BackColor);
            gr.SmoothingMode = SmoothingMode.AntiAlias;

            // Draw the selected hexagons.
            float xmin = BorderThickness / 2f;
            foreach (Hexagon hexagon in Hexagons)
            {
                PointF[] points = Hex.HexToPoints(HexHeight,
                    hexagon.Row, hexagon.Column, xmin, xmin);

                if (points[3].X > xmax) continue;
                if (points[4].Y > ymax) continue;

                Hex.DrawImageInPolygon(gr,
                    Hex.HexToPoints(HexHeight,
                        hexagon.Row, hexagon.Column, xmin, xmin),
                        hexagon.Picture);
            }

            // Draw the grid.
            using (Pen pen = new Pen(picBorderColor.BackColor, BorderThickness))
            {
                Hex.DrawHexGrid(gr, pen,
                    xmin, xmax, xmin, ymax, HexHeight);
            }
        }

        // Display the row and column under the mouse.
        private void picGrid_MouseMove(object sender, MouseEventArgs e)
        {
            int row, col;
            Hex.PointToHex(e.X, e.Y, HexHeight, out row, out col);
            int index = FindHexagon(row, col);
            if (index < 0)
                this.Text = "howto_improved_hex_montage";
            else
            {
                string name = Hexagons[index].FileName;
                int pos = name.IndexOf('.');
                this.Text = name.Substring(0, pos);
            }
        }

        // Add the clicked hexagon to the Hexagons list.
        private void picGrid_MouseClick(object sender, MouseEventArgs e)
        {
            // Get the row and column clicked.
            int row, col;
            Hex.PointToHex(e.X, e.Y, HexHeight, out row, out col);

            // Remove any existing record for this cell.
            RemoveHexagon(row, col);

            // Let the user select a new picture.
            if (ofdFile.ShowDialog() == DialogResult.OK)
            {
                Bitmap bm = LoadBitmapUnlocked(ofdFile.FileName);
                Hexagons.Add(new Hexagon(row, col, bm, ofdFile.FileName));
            }

            // Redraw.
            MakeGrid();
        }

        // Remove the Hexagon at this position if there is one.
        private void RemoveHexagon(int row, int col)
        {
            int index = FindHexagon(row,col);
            if (index >= 0) Hexagons.RemoveAt(index);
        }

        // Find the Hexagon at this position if there is one.
        private int FindHexagon(int row, int col)
        {
            for (int i = Hexagons.Count - 1; i >= 0; i--)
            {
                if ((Hexagons[i].Row == row) &&
                    (Hexagons[i].Column == col))
                        return i;
            }
            return -1;
        }

        private void mnuFileSaveAs_Click(object sender, EventArgs e)
        {
            if (sfdSave.ShowDialog() == DialogResult.OK)
            {
                SaveImage(GridImage, sfdSave.FileName);
            }
        }

        private void mnuFileExit_Click(object sender, EventArgs e)
        {
            Close();
        }

        // A parameter changed. Update the drawing.
        private void txt_TextChanged(object sender, EventArgs e)
        {
            float height, thickness;
            if (!float.TryParse(txtHexHeight.Text, out height) ||
                height < 10)
                return;
            if (!float.TryParse(txtBorderThickness.Text, out thickness))
                return;

            HexHeight = height;
            BorderThickness = thickness;
            picGrid.Refresh();
        }

        // Save the file with the appropriate format.
        public void SaveImage(Image image, string filename)
        {
            string extension = Path.GetExtension(filename);
            switch (extension.ToLower())
            {
                case ".bmp":
                    image.Save(filename, ImageFormat.Bmp);
                    break;
                case ".exif":
                    image.Save(filename, ImageFormat.Exif);
                    break;
                case ".gif":
                    image.Save(filename, ImageFormat.Gif);
                    break;
                case ".jpg":
                case ".jpeg":
                    image.Save(filename, ImageFormat.Jpeg);
                    break;
                case ".png":
                    image.Save(filename, ImageFormat.Png);
                    break;
                case ".tif":
                case ".tiff":
                    image.Save(filename, ImageFormat.Tiff);
                    break;
                default:
                    throw new NotSupportedException(
                        "Unknown file extension " + extension);
            }
        }

        private void picBorderColor_Click(object sender, EventArgs e)
        {
            cdBorderColor.Color = picBorderColor.BackColor;
            if (cdBorderColor.ShowDialog() == DialogResult.OK)
            {
                picBorderColor.BackColor = cdBorderColor.Color;
                picGrid.Refresh();
            }
        }

        private void picBackgroundColor_Click(object sender, EventArgs e)
        {
            cdBorderColor.Color = picBackgroundColor.BackColor;
            if (cdBorderColor.ShowDialog() == DialogResult.OK)
            {
                picBackgroundColor.BackColor = cdBorderColor.Color;
                picGrid.Refresh();
            }
        }

        // See http://csharphelper.com/blog/2014/07/load-images-without-locking-their-files-in-c/
        // Load a bitmap without locking it.
        private Bitmap LoadBitmapUnlocked(string file_name)
        {
            using (Bitmap bm = new Bitmap(file_name))
            {
                return new Bitmap(bm);
            }
        }

        // Get the hexs' largest X and Y coordinates.
        private void FindGridBounds(out float xmax, out float ymax)
        {
            xmax = 0;
            ymax = 0;
            float xmin = BorderThickness / 2f;

            // Check hex (NumRows - 1, NumCols - 1).
            PointF[] points;
            points = Hex.HexToPoints(HexHeight,
                NumRows - 1, NumCols - 1, xmin, xmin);
            if (xmax < points[3].X) xmax = points[3].X;
            if (ymax < points[4].Y) ymax = points[4].Y;

            // Check hex (NumRows - 1, NumCols - 2).
            points = Hex.HexToPoints(HexHeight,
                NumRows - 1, NumCols - 1, xmin, xmin);
            if (xmax < points[3].X) xmax = points[3].X;
            if (ymax < points[4].Y) ymax = points[4].Y;

            // Add room for the border thickness.
            xmax += xmin;
            ymax += xmin;
        }

        // Load the files from a directory.
        private void mnuFileOpenDirectoryFiles_Click(object sender, EventArgs e)
        {
            if (ofdDirectoryFiles.ShowDialog() == DialogResult.OK)
            {
                // Get a list of the files in the directory.
                FileInfo info = new FileInfo(ofdDirectoryFiles.FileName);
                DirectoryInfo dir_info = info.Directory;
                List<FileInfo> file_infos = new List<FileInfo>();
                foreach (FileInfo file_info in dir_info.GetFiles())
                {
                    string ext = file_info.Extension.ToLower().Replace(".", "");
                    if ((ext == "bmp") || (ext == "png") ||
                        (ext == "jpg") || (ext == "jpeg") ||
                        (ext == "gif") || (ext == "tiff"))
                    {
                        file_infos.Add(file_info);
                    }
                }

                // Calculate the number of rows and columns.
                int num_rows = (int)Math.Sqrt(file_infos.Count);
                int num_cols = num_rows;
                if (num_rows * num_cols < file_infos.Count)
                    num_cols++;
                if (num_rows * num_cols < file_infos.Count)
                    num_rows++;

                // Load the files.
                Hexagons = new List<Hexagon>();
                int index = 0;
                for (int row = 0; row < num_rows; row++)
                {
                    for (int col = 0; col < num_cols; col++)
                    {
                        string name = file_infos[index].Name;
                        string full_name = file_infos[index].FullName;
                        Bitmap bm = LoadBitmapUnlocked(full_name);
                        Hexagons.Add(new Hexagon(row, col, bm, name));

                        index++;
                        if (index >= file_infos.Count) break;
                    }
                    if (index >= file_infos.Count) break;
                }

                MakeGrid();
            }
        }

        private void btnCreateGrid_Click(object sender, EventArgs e)
        {
            MakeGrid();
            picGrid.Visible = true;
        }

        // Make and display a new grid.
        private void MakeGrid()
        {
            // Get the number of rows and columns.
            if (!int.TryParse(txtNumRows.Text, out NumRows)) return;
            if (!int.TryParse(txtNumCols.Text, out NumCols)) return;

            // See how big the image must be.
            float xmax, ymax;
            FindGridBounds(out xmax, out ymax);

            // Make the image.
            int wid = (int)xmax + 1;
            int hgt = (int)ymax + 1;
            GridImage = new Bitmap(wid, hgt);

            // Draw the grid.
            using (Graphics gr = Graphics.FromImage(GridImage))
            {
                DrawGrid(gr, wid, hgt);
            }

            // Display the result.
            picGrid.Image = GridImage;
            mnuFileSaveAs.Enabled = true;
        }
    }
}

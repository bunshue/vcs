﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Reflection;

namespace howto_use_system_colors
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // List the system colors.
        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            int y = 10;
            
            // Enumerate the SystemColors class's static Color properties.
            Type type = typeof(SystemColors);
            foreach (PropertyInfo field_info in type.GetProperties())
            {
                DrawColorSample(e.Graphics, ref y,
                    (Color)field_info.GetValue(null, null),
                    field_info.Name);                
            }

            // Size to fit.
            this.ClientSize = new Size(this.ClientSize.Width, y + 10);
        }

        // Display a color sample.
        private void DrawColorSample(Graphics gr, ref int y, Color clr, string clr_name)
        {
            using (SolidBrush br = new SolidBrush(clr))
            {
                gr.FillRectangle(br, 10, y, 90, 10);
            }
            gr.DrawRectangle(Pens.Black, 10, y, 90, 10);
            gr.DrawString(clr_name, this.Font, Brushes.Black, 110, y);
            y += 15;
        }
    }
}

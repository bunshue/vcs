﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_byte_array_to_hex_string
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Convert the string into an array of bytes and display it.
        private void btnToHexString_Click(object sender, EventArgs e)
        {
            // Convert the string into bytes.
            UnicodeEncoding ascii_encoder = new UnicodeEncoding();
            byte[] bytes = ascii_encoder.GetBytes(txtOriginal.Text);

            // Display the result as a string of hexadecimal values.
            txtHexadecimal.Text = bytes.ToHex(' ');
        }

        // Converrt the string of hexadecimal values back into a string.
        private void btnToString_Click(object sender, EventArgs e)
        {
            // Convert the string of hexadecimal values into an array of bytes.
            byte[] bytes = txtHexadecimal.Text.ToBytes();

            // Convert the bytes into a string and display the result.
            UnicodeEncoding ascii_encoder = new UnicodeEncoding();
            txtConvertedBack.Text = ascii_encoder.GetString(bytes);
        }
    }
}

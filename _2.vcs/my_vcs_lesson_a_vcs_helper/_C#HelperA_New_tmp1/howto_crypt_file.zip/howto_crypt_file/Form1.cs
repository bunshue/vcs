﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.IO;
using CryptoStuffNamespace;

namespace howto_crypt_file
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string file_path = Path.Combine(Application.StartupPath, "..\\..");
            file_path = new FileInfo(file_path).FullName;

            txtPlaintextFile.Text = file_path + "\\plaintext.txt";
            txtCiphertextFile.Text = file_path + "\\ciphertext.dat";
            txtDecipheredFile.Text = file_path + "\\deciphered.txt";

            // Display the original file.
            txtPlaintext.Text = File.ReadAllText(txtPlaintextFile.Text);
        }

        // Encrypt the plaintext file.
        private void btnEncrypt_Click(object sender, EventArgs e)
        {
            // Encrypt the file.
            CryptoStuff.EncryptFile(txtPassword.Text, txtPlaintextFile.Text, txtCiphertextFile.Text);

            // Display the result.
            txtCiphertext.Text = File.ReadAllBytes(txtCiphertextFile.Text).ToHex(' ');
        }

        // Decrypt the ciphertext file.
        private void btnDecrypt_Click(object sender, EventArgs e)
        {
            // Decrypt the file.
            CryptoStuff.DecryptFile(txtPassword.Text, txtCiphertextFile.Text, txtDecipheredFile.Text);

            // Display the result.
            txtDeciphered.Text = File.ReadAllText(txtDecipheredFile.Text);
        }
    }
}

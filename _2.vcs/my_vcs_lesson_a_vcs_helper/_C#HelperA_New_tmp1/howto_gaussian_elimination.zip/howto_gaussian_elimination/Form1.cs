using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_gaussian_elimination
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Solve the system of equations.
        private void cmdSolve_Click(object sender, EventArgs e)
        {
            const double tiny = 0.00001;
            string txt = "";

            // Build the augmented matrix.
            // The values num_rows and num_cols are the number of rows
            // and columns in the matrix, not the augmented matrix.
            int num_rows, num_cols;
            double[,] arr = LoadArray(out num_rows, out num_cols);
            double[,] orig_arr = LoadArray(out num_rows, out num_cols);
            
            // Display the initial arrays.
            PrintArray(arr);
            PrintArray(orig_arr);

            // Start solving.
            for (int r = 0; r < num_rows - 1; r++)
            {
                // Zero out all entries in column r after this row.
                // See if this row has a non-zero entry in column r.
                if (Math.Abs(arr[r, r]) < tiny)
                {
                    // Too close to zero. Try to swap with a later row.
                    for (int r2 = r + 1; r2 < num_rows; r2++)
                    {
                        if (Math.Abs(arr[r2, r]) > tiny)
                        {
                            // This row will work. Swap them.
                            for (int c = 0; c <= num_cols; c++)
                            {
                                double tmp = arr[r, c];
                                arr[r, c] = arr[r2, c];
                                arr[r2, c] = tmp;
                            }
                            break;
                        }
                    }
                }

                // If this row has a non-zero entry in column r, use it.
                if (Math.Abs(arr[r, r]) > tiny)
                {
                    // Zero out this column in later rows.
                    for (int r2 = r + 1; r2 < num_rows; r2++)
                    {
                        double factor = -arr[r2, r] / arr[r, r];
                        for (int c = r; c <= num_cols; c++)
                        {
                            arr[r2, c] = arr[r2, c] + factor * arr[r, c];
                        }
                    }
                }
            }

            // Display the upper-triangular array.
            PrintArray(arr);

            // See if we have a solution.
            if (arr[num_rows - 1, num_cols - 1] == 0)
            {
                // We have no solution.
                // See if all of the entries in this row are 0.
                bool all_zeros = true;
                for (int c = 0; c <= num_cols + 1; c++)
                {
                    if (arr[num_rows - 1, c] != 0)
                    {
                        all_zeros = false;
                        break;
                    }
                }
                if (all_zeros)
                {
                    txt = "The solution is not unique";
                }
                else
                {
                    txt = "There is no solution";
                }
            }
            else
            {
                // Backsolve.
                for (int r = num_rows - 1; r >= 0; r--)
                {
                    double tmp = arr[r, num_cols];
                    for (int r2 = r + 1; r2 < num_rows; r2++)
                    {
                        tmp -= arr[r, r2] * arr[r2, num_cols + 1];
                    }
                    arr[r, num_cols + 1] = tmp / arr[r, r];
                }

                // Display the results.
                txt = "       Values:";
                for (int r = 0; r < num_rows; r++)
                {
                    txt += "\r\nx" + r.ToString() + " = " +
                        arr[r, num_cols + 1].ToString();
                }

                // Verify.
                txt += "\r\n    Check:";
                for (int r = 0; r < num_rows; r++)
                {
                    double tmp = 0;
                    for (int c = 0; c < num_cols; c++)
                    {
                        tmp += orig_arr[r, c] * arr[c, num_cols + 1];
                    }
                    txt += "\r\n" + tmp.ToString();
                }

                txt = txt.Substring("\r\n".Length + 1);
            }

            txtResults.Text = txt;
        }

        // Load the augmented array.
        // Column num_cols holds the result values.
        // Column num_cols + 1 will hold the variables' final values after backsolving.
        private double[,] LoadArray(out int num_rows, out int num_cols)
        {
            // Build the augmented matrix.
            string[] value_rows = txtValues.Text.Split(
                new string[] {"\r\n"}, StringSplitOptions.RemoveEmptyEntries);
            string[] coef_rows = txtCoefficients.Text.Split(
                new string[] { "\r\n" }, StringSplitOptions.RemoveEmptyEntries);
            string[] one_row = coef_rows[0].Split(
                new string[] { " " }, StringSplitOptions.RemoveEmptyEntries);
            num_rows = coef_rows.GetUpperBound(0) + 1;
            num_cols = one_row.GetUpperBound(0) + 1;
            double[,] arr = new double[num_rows, num_cols + 2];
            for (int r = 0; r < num_rows; r++)
            {
                one_row = coef_rows[r].Split(
                    new char[] {' '}, StringSplitOptions.RemoveEmptyEntries);
                for (int c = 0; c < num_cols; c++)
                {
                    arr[r, c] = double.Parse(one_row[c]);
                }
                arr[r, num_cols] = double.Parse(value_rows[r]);
            }

            return arr;
        }

        // Display the array's values in the Console window.
        private void PrintArray(double[,] arr)
        {
            for (int r = arr.GetLowerBound(0); r <= arr.GetUpperBound(0); r++)
            {
                for (int c = arr.GetLowerBound(1); c <= arr.GetUpperBound(1); c++)
                {
                    Console.Write(arr[r, c] + "\t");
                }
                Console.WriteLine("");
            }
            Console.WriteLine("");
        }
    }
}

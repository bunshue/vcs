﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_make_ordinal
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Display an initial value.
        private void Form1_Load(object sender, EventArgs e)
        {
            txtNumber.Text = "1337";
        }

        // Display the ordinal version of the number.
        private void txtNumber_TextChanged(object sender, EventArgs e)
        {
            // Parse the value and display its ordinal extension.
            try
            {
                int value = int.Parse(txtNumber.Text,
                    System.Globalization.NumberStyles.Any);
                txtResult.Text = value.ToString("#,##0 ") + value.ToOrdinal();
            }
            catch
            {
                txtResult.Clear();
            }
        }
    }
}

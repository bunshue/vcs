﻿namespace howto_print_grid_data
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.btnPrintPreview = new System.Windows.Forms.Button();
            this.pdocGrid = new System.Drawing.Printing.PrintDocument();
            this.ppdGrid = new System.Windows.Forms.PrintPreviewDialog();
            this.SuspendLayout();
            // 
            // btnPrintPreview
            // 
            this.btnPrintPreview.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnPrintPreview.Location = new System.Drawing.Point(91, 51);
            this.btnPrintPreview.Name = "btnPrintPreview";
            this.btnPrintPreview.Size = new System.Drawing.Size(102, 23);
            this.btnPrintPreview.TabIndex = 0;
            this.btnPrintPreview.Text = "Print Preview";
            this.btnPrintPreview.UseVisualStyleBackColor = true;
            this.btnPrintPreview.Click += new System.EventHandler(this.btnPrintPreview_Click);
            // 
            // pdocGrid
            // 
            this.pdocGrid.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.pdocGrid_PrintPage);
            // 
            // ppdGrid
            // 
            this.ppdGrid.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.ppdGrid.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.ppdGrid.ClientSize = new System.Drawing.Size(400, 300);
            this.ppdGrid.Document = this.pdocGrid;
            this.ppdGrid.Enabled = true;
            this.ppdGrid.Icon = ((System.Drawing.Icon)(resources.GetObject("ppdGrid.Icon")));
            this.ppdGrid.Name = "ppdGrid";
            this.ppdGrid.Visible = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 124);
            this.Controls.Add(this.btnPrintPreview);
            this.Name = "Form1";
            this.Text = "howto_print_grid_data";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnPrintPreview;
        internal System.Drawing.Printing.PrintDocument pdocGrid;
        internal System.Windows.Forms.PrintPreviewDialog ppdGrid;
    }
}


﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Text.RegularExpressions;

namespace howto_show_regular_expression_matches
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Display matches.
        private void btnGo_Click(object sender, EventArgs e)
        {
            try
            {
                Regex reg_exp = new Regex(txtPattern.Text);
                MatchCollection matches = reg_exp.Matches(txtTestString.Text);

                rchResults.Text = txtTestString.Text;
                foreach (Match a_match in matches)
                {
                    rchResults.Select(a_match.Index, a_match.Length);
                    rchResults.SelectionColor = Color.Red;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}

﻿namespace howto_get_screen_image
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnGetScreenImage = new System.Windows.Forms.Button();
            this.sfdScreenImage = new System.Windows.Forms.SaveFileDialog();
            this.SuspendLayout();
            // 
            // btnGetScreenImage
            // 
            this.btnGetScreenImage.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnGetScreenImage.Location = new System.Drawing.Point(107, 40);
            this.btnGetScreenImage.Name = "btnGetScreenImage";
            this.btnGetScreenImage.Size = new System.Drawing.Size(124, 23);
            this.btnGetScreenImage.TabIndex = 0;
            this.btnGetScreenImage.Text = "Get Screen Image";
            this.btnGetScreenImage.UseVisualStyleBackColor = true;
            this.btnGetScreenImage.Click += new System.EventHandler(this.btnGetScreenImage_Click);
            // 
            // sfdScreenImage
            // 
            this.sfdScreenImage.Filter = "Graphic Files|*.bmp;*.gif;*.jpg;*.png|All Files|*.*";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(338, 102);
            this.Controls.Add(this.btnGetScreenImage);
            this.Name = "Form1";
            this.Text = "howto_get_screen_image";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnGetScreenImage;
        private System.Windows.Forms.SaveFileDialog sfdScreenImage;
    }
}


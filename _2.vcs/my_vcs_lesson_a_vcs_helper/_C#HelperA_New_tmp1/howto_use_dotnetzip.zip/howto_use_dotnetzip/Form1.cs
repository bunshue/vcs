﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

// Download and unzip the DotNetZip library at: http://dotnetzip.codeplex.com/
// Add a reference to the Ionic.Zip.dll library.

using System.IO;
using Ionic.Zip;

namespace howto_use_dotnetzip
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Start with an initial file.
        private void Form1_Load(object sender, EventArgs e)
        {
            txtFileName.Text = Path.GetFullPath(
                Path.Combine(Application.StartupPath, "..\\..\\JackOLantern.bmp"));
            txtArchiveName.Text = Path.GetFullPath(
                Path.Combine(Application.StartupPath, "..\\..\\JackOLantern.zip"));
            txtExtractTo.Text = Path.GetFullPath(
                Path.Combine(Application.StartupPath, "..\\..\\ExtractedFiles\\"));
        }

        // Add the file to the archive.
        private void btnAddToArchive_Click(object sender, EventArgs e)
        {
            try
            {
                using (ZipFile zip = new ZipFile(txtArchiveName.Text))
                {
                    // Add the file to the Zip archive's root folder.
                    zip.AddFile(txtFileName.Text, txtPathInArchive.Text);

                    // Save the Zip file.
                    zip.Save();
                }

                // Display the file sizes.
                FileInfo old_fi = new FileInfo(txtFileName.Text);
                lblOriginalSize.Text = old_fi.Length.ToString("#,#");
                FileInfo new_fi = new FileInfo(txtArchiveName.Text);
                lblCompressedSize.Text = new_fi.Length.ToString("#,#");

                MessageBox.Show("Done");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error adding file to archive.\n" + ex.Message);
            }
        }

        // Extract the files from the archive.
        private void btnExtractArchive_Click(object sender, EventArgs e)
        {
            try
            {
                using (ZipFile zip = ZipFile.Read(txtArchiveName.Text))
                {
                    // Loop through the archive's files.
                    foreach (ZipEntry zip_entry in zip)
                    {
                        zip_entry.Extract(txtExtractTo.Text);
                    }
                }

                MessageBox.Show("Done");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error extracting archive.\n" + ex.Message);
            }
        }
    }
}

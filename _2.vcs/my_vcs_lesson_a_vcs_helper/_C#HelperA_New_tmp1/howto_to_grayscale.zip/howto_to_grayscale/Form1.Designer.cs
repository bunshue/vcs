﻿namespace howto_to_grayscale
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.picOriginal = new System.Windows.Forms.PictureBox();
            this.picAverage = new System.Windows.Forms.PictureBox();
            this.picGrayscale = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.picOriginal)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picAverage)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picGrayscale)).BeginInit();
            this.SuspendLayout();
            // 
            // picOriginal
            // 
            this.picOriginal.Image = ((System.Drawing.Image)(resources.GetObject("picOriginal.Image")));
            this.picOriginal.Location = new System.Drawing.Point(12, 12);
            this.picOriginal.Name = "picOriginal";
            this.picOriginal.Size = new System.Drawing.Size(185, 232);
            this.picOriginal.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.picOriginal.TabIndex = 2;
            this.picOriginal.TabStop = false;
            // 
            // picAverage
            // 
            this.picAverage.Image = ((System.Drawing.Image)(resources.GetObject("picAverage.Image")));
            this.picAverage.Location = new System.Drawing.Point(203, 12);
            this.picAverage.Name = "picAverage";
            this.picAverage.Size = new System.Drawing.Size(185, 232);
            this.picAverage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.picAverage.TabIndex = 3;
            this.picAverage.TabStop = false;
            // 
            // picGrayscale
            // 
            this.picGrayscale.Image = ((System.Drawing.Image)(resources.GetObject("picGrayscale.Image")));
            this.picGrayscale.Location = new System.Drawing.Point(394, 12);
            this.picGrayscale.Name = "picGrayscale";
            this.picGrayscale.Size = new System.Drawing.Size(185, 232);
            this.picGrayscale.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.picGrayscale.TabIndex = 4;
            this.picGrayscale.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(591, 256);
            this.Controls.Add(this.picGrayscale);
            this.Controls.Add(this.picAverage);
            this.Controls.Add(this.picOriginal);
            this.Name = "Form1";
            this.Text = "howto_to_grayscale";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.picOriginal)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picAverage)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picGrayscale)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.PictureBox picOriginal;
        internal System.Windows.Forms.PictureBox picAverage;
        internal System.Windows.Forms.PictureBox picGrayscale;
    }
}


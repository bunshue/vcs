﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_partition_branch_and_bound_heuristic
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnPartition_Click(object sender, EventArgs e)
        {
            this.Cursor = Cursors.WaitCursor;
            txtItems1.Clear();
            txtItems2.Clear();
            txtTotal1.Clear();
            txtTotal2.Clear();
            Application.DoEvents();
            DateTime start_time = DateTime.Now;

            // Get the item values.
            string[] strings = txtItemValues.Lines;
            int[] values = new int[strings.Length];
            for (int i = 0; i < strings.Length; i++)
            {
                values[i] = int.Parse(strings[i]);
            }

            // Partition the values.
            bool[] best_assignment = PartitionValues(values);

            // Display the results.
            string result1 = "", result2 = "";
            int total1 = 0, total2 = 0;
            for (int i = 0; i < best_assignment.Length; i++)
            {
                if (best_assignment[i])
                {
                    result1 += "\r\n" + values[i];
                    total1 += values[i];
                }
                else
                {
                    result2 += "\r\n" + values[i];
                    total2 += values[i];
                }
            }
            if (result1.Length > 0) result1 = result1.Substring(2);
            if (result2.Length > 0) result2 = result2.Substring(2);

            txtItems1.Text = result1;
            txtItems2.Text = result2;
            txtTotal1.Text = total1.ToString();
            txtTotal2.Text = total2.ToString();

            DateTime stop_time = DateTime.Now;
            this.Cursor = Cursors.Default;
            TimeSpan elapsed = stop_time - start_time;
            lblElapsed.Text = elapsed.TotalSeconds.ToString("0.00") + " seconds";
        }

        // Partition the values. Return an array with entry i = true if
        // value i belongs in the first set of the partition.
        private bool[] PartitionValues(int[] values)
        {
            // Make variables to track the best solution and a test solution.
            bool[] best_assignment = new bool[values.Length];
            bool[] test_assignment = new bool[values.Length];

            // Get the total of all values.
            int total_value = values.Sum();
            int best_err = total_value;

            // Use a heuristic to get an initial solution.
            PartitionValuesGreedy(values, best_assignment, ref best_err);
    
            // Partition the values starting with index 0.
            PartitionValuesFromIndex(values, 0, total_value, total_value,
                test_assignment, 0, ref best_assignment, ref best_err);

            // Return the result.
            return best_assignment;
        }

        // Partition the values keeping those before index start_index fixed.
        // test_assignment is the test assignment so far.
        // test_value is the total value of the first set in the test assignment.
        // Initially best assignment and its error are in best_assignment and best_err.
        // Update those to reflect any improved solution we find.
        private void PartitionValuesFromIndex(int[] values, int start_index, int total_value,
            int unassigned_value, bool[] test_assignment, int test_value,
            ref bool[] best_assignment, ref int best_err)
        {
            // If start_index is beyond the end of the array,
            // then all entries have been assigned.
            if (start_index >= values.Length)
            {
                // We're done. See if this assignment is better than what we have so far.
                int test_err = Math.Abs(2 * test_value - total_value);
                if (test_err < best_err)
                {
                    // This is an improvement. Save it.
                    best_err = test_err;
                    best_assignment = (bool[])test_assignment.Clone();

                    Console.WriteLine(best_err);
                }
            }
            else
            {
                // See if there's any way we can assign
                // the remaining items to improve the solution.
                int test_err = Math.Abs(2 * test_value - total_value);
                if (test_err - unassigned_value < best_err)
                {
                    // There's a chance we can make an improvement.
                    // We will now assign the next item.
                    unassigned_value -= values[start_index];

                    // Try adding values[start_index] to set 1.
                    test_assignment[start_index] = true;
                    PartitionValuesFromIndex(values, start_index + 1, total_value, unassigned_value,
                        test_assignment, test_value + values[start_index],
                        ref best_assignment, ref best_err);

                    // Try adding values[start_index] to set 2.
                    test_assignment[start_index] = false;
                    PartitionValuesFromIndex(values, start_index + 1, total_value, unassigned_value,
                        test_assignment, test_value,
                        ref best_assignment, ref best_err);
                }
            }
        }

        // Use a greedy heuristic to find an initial solution.
        // Method: Loop through the items adding the next item to
        // whichever set has the smaller total value so far.
        private void PartitionValuesGreedy(int[] values,
            bool[] best_assignment, ref int best_err)
        {
            // Initialize the sets' total values.
            int total1 = 0, total2 = 0;

            // Add the items.
            for (int i = 0; i < best_assignment.Length; i++)
            {
                if (total1 <= total2)
                {
                    // Add item i to set 1.
                    best_assignment[i] = true;
                    total1 += values[i];
                }
                else
                {
                    // Add item i to set 2.
                    //best_assignment[i] = false;
                    total2 += values[i];
                }
            }

            // Set the best error.
            best_err = Math.Abs(total1 - total2);
        }
    }
}

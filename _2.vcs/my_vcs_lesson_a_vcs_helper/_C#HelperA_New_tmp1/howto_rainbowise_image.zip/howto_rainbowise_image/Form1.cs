﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Drawing.Imaging;

namespace howto_rainbowise_image
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Process the image.
        private void Form1_Load(object sender, EventArgs e)
        {
            // Create the output image.
            Image original = picImage.Image;
            int wid = original.Width;
            int hgt = original.Height;
            Bitmap bm = new Bitmap(wid, hgt);
            using (Graphics gr = Graphics.FromImage(bm))
            {
                // Define target colors.
                Color[] color =
                {
                    //Color.Red, Color.Orange, Color.Yellow,
                    //Color.Green, Color.Blue, Color.Indigo,
                    //Color.Violet,

                    Color.Red, Color.OrangeRed, Color.Yellow,
                    Color.Green, Color.Blue, Color.Indigo,
                    Color.Fuchsia,
                };
                const float scale = 2.0f;

                // Draw.
                for (int i = 0; i < color.Length; i++)
                {
                    // Create the ColorMatrix.
                    ColorMatrix cm = new ColorMatrix(new float[][]
                    {
                        new float[] {color[i].R / 255f * scale, 0, 0, 0, 0},
                        new float[] {0, color[i].G / 255f * scale, 0, 0, 0},
                        new float[] {0, 0, color[i].B / 255f * scale, 0, 0},
                        new float[] {0, 0, 0, 1, 0},
                        new float[] {0, 0, 0, 0, 1},
                    });
                    ImageAttributes attr = new ImageAttributes();
                    attr.SetColorMatrix(cm);

                    // Draw the next part of the image.
                    int x = (int)(i * original.Width / color.Length);
                    Point[] points =
                    {
                        new Point(x, 0),
                        new Point(wid, 0),
                        new Point(x, hgt),
                    };
                    Rectangle rect = new Rectangle(x, 0, wid - x, hgt);
                    gr.DrawImage(original, points, rect, GraphicsUnit.Pixel, attr);
                }
            }

            // Display the result.
            picImage.Image = bm;

            // Save the result.
            bm.Save("Rainbow.png", ImageFormat.Png);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Threading;

namespace howto_threaded_graph
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private int Ymid;
        private int YValue;
        private const int GridStep = 40;

        private Thread GraphThread;

        // Get ready.
        private void Form1_Load(object sender, EventArgs e)
        {
            Ymid = picGraph.ClientSize.Height / 2;
            YValue = Ymid;

            // Make the Bitmap and Graphics objects.
            int wid = picGraph.ClientSize.Width;
            int hgt = picGraph.ClientSize.Height;
            Bitmap bm = new Bitmap(wid, hgt);
            Graphics gr = Graphics.FromImage(bm);

            // Draw guide lines.
            gr.Clear(Color.Blue);
            for (int i = Ymid; i <= picGraph.ClientSize.Height; i += GridStep)
            {
                gr.DrawLine(Pens.LightBlue, 0, i, wid - 1, i);
            }
            for (int i = Ymid; i >= 0; i -= GridStep)
            {
                gr.DrawLine(Pens.LightBlue, 0, i, wid - 1, i);
            }

            picGraph.Image = bm;
        }

        // Start drawing the graph.
        private void btnGraph_Click(object sender, EventArgs e)
        {
            // Uncomment the following two lines
            // to see what happens without threading.
            //DrawGraph();
            //return;

            if (GraphThread == null)
            {
                // The thread isn't running. Start it.
                AddStatus("Starting thread");

                GraphThread = new Thread(DrawGraph);
                GraphThread.Priority = ThreadPriority.BelowNormal;
                GraphThread.IsBackground = true;
                GraphThread.Start();

                AddStatus("Thread started");

                btnGraph.Text = "Stop";
            }
            else
            {
                // The thread is running. Stop it.
                AddStatus("Stopping thread");

                GraphThread.Abort();
                GraphThread = null;

                AddStatus("Thread stopped");

                btnGraph.Text = "Start";
            }
        }

        // Draw a graph until stopped.
        private void DrawGraph()
        {
            try
            {
                // Generate pseudo-random values.
                int y = YValue;
                for (; ; )
                {
                    // Generate the next value.
                    NewValue();

                    // Plot the new value.
                    PlotValue(y, YValue);
                    y = YValue;
                }
            }
            catch (Exception ex)
            {
                AddStatus("[Thread] " + ex.Message);
            }
        }

        // Generate the next value.
        private Random Rnd = new Random();
        private void NewValue()
        {
            // Delay a bit before calculating the value.
            DateTime stop_time = DateTime.Now.AddMilliseconds(20);
            while (DateTime.Now < stop_time) { };

            // Calculate the next value.
            YValue += Rnd.Next(-4, 5);
            if (YValue < 0) YValue = 0;
            if (YValue >= picGraph.ClientSize.Height - 1)
                YValue = picGraph.ClientSize.Height - 1;
        }

        // Define a delegate type that takes two int parameters.
        private delegate void PlotValueDelegate(int old_y, int new_y);

        // Plot a new value.
        private void PlotValue(int old_y, int new_y)
        {
            // See if we're on the worker thread and thus
            // need to invoke the main UI thread.
            if (this.InvokeRequired)
            {
                // Make arguments for the delegate.
                object[] args = new object[] { old_y, new_y };

                // Make the delegate.
                PlotValueDelegate plot_value_delegate = PlotValue;

                // Invoke the delegate on the main UI thread.
                this.Invoke(plot_value_delegate, args);

                // We're done.
                return;
            }

            // Invoke not required. Go ahead and plot.
            // Make the Bitmap and Graphics objects.
            int wid = picGraph.ClientSize.Width;
            int hgt = picGraph.ClientSize.Height;
            Bitmap bm = new Bitmap(wid, hgt);
            Graphics gr = Graphics.FromImage(bm);

            // Move the old data one pixel to the left.
            gr.DrawImage(picGraph.Image, -1, 0);

            // Erase the right edge and draw guide lines.
            gr.DrawLine(Pens.Blue, wid - 1, 0, wid - 1, hgt - 1);
            for (int i = Ymid; i <= picGraph.ClientSize.Height; i += GridStep)
            {
                gr.DrawLine(Pens.LightBlue, wid - 2, i, wid - 1, i);
            }
            for (int i = Ymid; i >= 0; i -= GridStep)
            {
                gr.DrawLine(Pens.LightBlue, wid - 2, i, wid - 1, i);
            }

            // Plot a new pixel.
            gr.DrawLine(Pens.White, wid - 2, old_y, wid - 1, new_y);

            // Display the result.
            picGraph.Image = bm;
            picGraph.Refresh();

            gr.Dispose();
        }

        // Define a delegate type that takes a string parameter.
        private delegate void AddStatusDelegate(string txt);

        // Add a status string to txtStatus.
        private void AddStatus(string txt)
        {
            // See if we're on the worker thread and thus
            // need to invoke the main UI thread.
            if (this.InvokeRequired)
            {
                // Make arguments for the delegate.
                object[] args = new object[] { txt };

                // Make the delegate.
                AddStatusDelegate add_status_delegate = AddStatus;

                // Invoke the delegate on the main UI thread.
                this.Invoke(add_status_delegate, args);

                // We're done.
                return;
            }

            // No Invoke required. Just display the message.
            txtStatus.AppendText("\r\n" + txt);
            txtStatus.Select(txtStatus.Text.Length, 0);
            txtStatus.ScrollToCaret();
        }

        // Display the current time.
        private void tmrUpdateClock_Tick(object sender, EventArgs e)
        {
            lblTime.Text = DateTime.Now.ToString("T");
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_split_join
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Split the values and then recombine them with Join.
        private void btnSplit_Click(object sender, EventArgs e)
        {
            // Get the string of values.
            string txt = txtValues.Text;

            // Split the values at spaces, removing duplicates.
            string[] values = txt.Split(new char[] { ' ' },
                StringSplitOptions.RemoveEmptyEntries);

            // Rejoin them.
            string result = String.Join(";", values);

            // Display the result.
            txtResult.Text = result;
        }
    }
}

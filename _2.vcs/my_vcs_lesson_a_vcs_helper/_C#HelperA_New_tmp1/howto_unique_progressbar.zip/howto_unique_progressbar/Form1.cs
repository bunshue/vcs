﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Drawing.Drawing2D;

namespace howto_unique_progressbar
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Groups of controls to use as progress bars.
        private Control[] Labels;
        private Control[] ColoredLabels;
        private Control[] SmallLabels;

        // The bitmap displayed for the colors PictureBox.
        private Bitmap ColorsBm;

        // The bitmap displayed for the picture.
        private Bitmap PictureBm;

        private void Form1_Load(object sender, EventArgs e)
        {
            // Initialize the control arrays.
            Labels = new Control[] { label1, label2, label3, label4, label5, label6, label7, label8, label9, label10 };
            ColoredLabels = new Control[] { label11, label12, label13, label14, label15, label16, label17, label18, label19, label20 };
            SmallLabels = new Control[] { label21, label22, label23, label24, label25, label26, label27, label28, label29, label30, label31, label32, label33, label34, label35, label36, label37, label38, label39, label40 };

            // Set ColoredLabels colors.
            for (int i = 0; i < ColoredLabels.Length; i++)
            {
                int g = (int)(255f * i / (ColoredLabels.Length - 1f));
                ColoredLabels[i].BackColor = Color.FromArgb(255, 255, g, 0);
            }

            // Hide the control arrays.
            HideControls(Labels);
            HideControls(ColoredLabels);
            HideControls(SmallLabels);

            // Make the color bitmap.
            ColorsBm = new Bitmap(picColors.ClientSize.Width, picColors.ClientSize.Height);
            picColors.Image = ColorsBm;
            picColors.Visible = false;

            // Make the picture bitmap.
            PictureBm = new Bitmap(picHidden.Image.Width, picHidden.Image.Height);
            picVisible.Image = PictureBm;
        }

        // Start or stop the timer.
        private void btnGo_Click(object sender, EventArgs e)
        {
            // Disable the button and enable the timers.
            btnGo.Enabled = false;
            tmrFinish.Enabled = true;
            tmrLabels.Enabled = true;
            tmrColoredLabels.Enabled = true;
            tmrSmallLabels.Enabled = true;
            tmrColorBar.Enabled = true;
            tmrPicture.Enabled = true;

            // Clear the colorbar.
            using (Graphics gr = Graphics.FromImage(ColorsBm))
            {
                gr.Clear(picColors.BackColor);
            }
            picColors.Visible = true;

            // Display a pale picture.
            using (Graphics gr = Graphics.FromImage(PictureBm))
            {
                Rectangle rect = new Rectangle(0, 0, PictureBm.Width, PictureBm.Height);
                using (TextureBrush br = new TextureBrush(picHidden.Image))
                {
                    gr.FillRectangle(br, rect);
                }
                using (SolidBrush br = new SolidBrush(Color.FromArgb(128, 255, 255, 255)))
                {
                    gr.FillRectangle(br, rect);
                }
            }
            picVisible.Visible = true;
            
            this.Cursor = Cursors.WaitCursor;
        }

        // Show progress by displaying some hidden controls.
        private void ShowProgressWithVisible(float value, float max_value, Control[] controls)
        {
            // Calculate the index of the last visible control.
            int last_visible = (int)(controls.Length * value / max_value);

            // Make sure all controls up to this one are visible.
            for (int i = 0; i <= last_visible; i++)
            {
                if (!controls[i].Visible) controls[i].Visible = true;
            }
        }

        // Hide the progress controls.
        private void HideControls(Control[] controls)
        {
            foreach (Control ctl in controls) ctl.Visible = false;
        }

        // Display progress using labels.
        private int ProgressLabels = -1;
        private void tmrLabels_Tick(object sender, EventArgs e)
        {
            // Increment progress and see if we're done.
            if (++ProgressLabels >= Labels.Length)
            {
                // We're done. Stop the timer.
                ProgressLabels = -1;
                tmrLabels.Enabled = false;
                return;
            }

            // Display the progress.
            ShowProgressWithVisible(ProgressLabels, Labels.Length, Labels);
        }

        // Display progress using colored labels.
        private int ProgressColored = -1;
        private void tmrColoredLabels_Tick(object sender, EventArgs e)
        {
            // Increment progress and see if we're done.
            if (++ProgressColored >= ColoredLabels.Length)
            {
                // We're done. Stop the timer.
                ProgressColored = -1;
                tmrColoredLabels.Enabled = false;
                return;
            }

            // Display the progress.
            ShowProgressWithVisible(ProgressColored, ColoredLabels.Length, ColoredLabels);
        }

        // Display the next small label progress indicator.
        private int ProgressSmall = -1;
        private void tmrSmallLabels_Tick(object sender, EventArgs e)
        {
            // Increment progress and see if we're done.
            if (++ProgressSmall >= SmallLabels.Length)
            {
                // We're done. Stop the timer.
                ProgressSmall = -1;
                tmrSmallLabels.Enabled = false;
                return;
            }

            // Display the next progress control.
            SmallLabels[ProgressSmall].Visible = true;
        }

        // Display progress with a colored bar.
        private int ProgressColorBar = -1;
        private void tmrColorBar_Tick(object sender, EventArgs e)
        {
            const int max_progress = 20;

            // Increment progress and see if we're done.
            if (++ProgressColorBar >= max_progress)
            {
                // We're done. Stop the timer.
                ProgressColorBar = -1;
                tmrColorBar.Enabled = false;
                return;
            }

            // Display the next chunk of colors.
            using (LinearGradientBrush br = new LinearGradientBrush(
                new Point(0, 0), new Point(ColorsBm.Width, 0), Color.Red, Color.Yellow))
            {
                using (Graphics gr = Graphics.FromImage(ColorsBm))
                {
                    float wid = ColorsBm.Width * ProgressColorBar / (max_progress - 1);
                    float hgt = ColorsBm.Height;
                    RectangleF rect = new RectangleF(0, 0, wid, hgt);
                    gr.FillRectangle(br, rect);
                }
            }
            picColors.Refresh();
        }

        // Display progress with a picture.
        private int ProgressPicture = -1;
        private void tmrPicture_Tick(object sender, EventArgs e)
        {
            const int max_progress = 20;

            // Increment progress and see if we're done.
            if (++ProgressPicture >= max_progress)
            {
                // We're done. Stop the timer.
                ProgressPicture = -1;
                tmrPicture.Enabled = false;
                return;
            }

            // Display the next chunk of picture.
            using (TextureBrush br = new TextureBrush(picHidden.Image))
            {
                using (Graphics gr = Graphics.FromImage(PictureBm))
                {
                    float wid = PictureBm.Width * ProgressPicture / (max_progress - 1);
                    float hgt = PictureBm.Height;
                    RectangleF rect = new RectangleF(0, 0, wid, hgt);
                    gr.FillRectangle(br, rect);
                }
            }
            picVisible.Refresh();
        }

        // Hide all of the progress bars.
        private void tmrFinish_Tick(object sender, EventArgs e)
        {
            tmrFinish.Enabled = false;

            HideControls(Labels);
            HideControls(ColoredLabels);
            HideControls(SmallLabels);
            picColors.Visible = false;
            picVisible.Visible = false;

            btnGo.Enabled = true;
            this.Cursor = Cursors.Default;
        }
    }
}

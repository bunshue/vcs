﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_linq_min_max_ave
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Make some random values.
        private void Form1_Load(object sender, EventArgs e)
        {
            const int num_values = 50;
            Random rand = new Random();
            int[] values = new int[num_values];
            for (int i = 0; i < num_values; i++)
            {
                values[i] = rand.Next(0, 10000);
            }

            // Display the values.
            lstValues.DataSource = values;

            // Use LINQ extension methods to get
            // the minimum, maximum, and average values.
            txtMin.Text = values.Min().ToString();
            txtMax.Text = values.Max().ToString();
            txtAve.Text = values.Average().ToString();
        }
    }
}

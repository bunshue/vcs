﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.IO;

namespace howto_strip_wordpress
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Set initial WordPress files.
        private void Form1_Load(object sender, EventArgs e)
        {
            string path = Path.GetFullPath(
                Path.Combine(Application.StartupPath, "..\\..\\"));
            txtInput.Text = path + "Posts.txt";
            txtOutput.Text = path + "PostsTrimmed.txt";
        }

        // Remove the comments.
        private void btnRemoveSections_Click(object sender, EventArgs e)
        {
            lblResults.Text = "";
            Cursor = Cursors.WaitCursor;
            Refresh();

            // See what sections we want to remove.
            string targets = "\n";
            if (chkComment.Checked) targets += "COMMENT:\n";
            if (chkExtendedBody.Checked) targets += "EXTENDED BODY: \n";
            if (chkExcerpt.Checked) targets += "EXCERPT: \n";
            if (chkKeywords.Checked) targets += "KEYWORDS: \n";
            if (chkPing.Checked) targets += "PING:\n";

            // Read the input file.
            string[] input_lines = File.ReadAllLines(txtInput.Text);

            // Build the output.
            int num_removed = 0;
            bool reading_text = true;
            List<string> output_lines = new List<string>();
            foreach (string line in input_lines)
            {
                if (reading_text)
                {
                    // We're reading text. See if we should stop.
                    if (targets.Contains('\n' + line + '\n'))
                    {
                        num_removed++;
                        reading_text = false;
                    }
                    else output_lines.Add(line);
                }
                else
                {
                    // We're not reading text. See if we should start.
                    if (line == "-----") reading_text = true;
                }
            }

            // Save the result.
            File.WriteAllLines(txtOutput.Text, output_lines.ToArray());
            lblResults.Text = "Removed " + num_removed.ToString() +
                " sections";
            Cursor = Cursors.Default;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace CustomerProgram
{
    public partial class RegistrationForm : Form
    {
        public RegistrationForm()
        {
            InitializeComponent();
        }

        // Email the product number.
        private void llnkEmail_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            string cmd = "mailto:" + llnkEmail.Tag.ToString() +
            "?Subject=Product registration+Body=Product Number " +
            txtProductNumber.Text;
            System.Diagnostics.Process.Start(cmd);
        }
    }
}

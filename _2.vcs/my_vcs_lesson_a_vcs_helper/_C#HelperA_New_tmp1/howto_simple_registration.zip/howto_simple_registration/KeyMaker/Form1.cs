﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace KeyMaker
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Make the key for this product number.
        private void btnMakeKey_Click(object sender, EventArgs e)
        {
            try
            {
                UInt32 program_id = UInt32.Parse(txtProgramId.Text);
                UInt32 product_number = UInt32.Parse(txtProductNumber.Text);
                UInt32 product_key = Encrypt(program_id, product_number);
                txtProductKey.Text = product_key.ToString();
            }
            catch (Exception ex)
            {
                txtProductKey.Clear();
                MessageBox.Show(ex.Message);
            }
        }

        // Simple encryption and decryption.
        private UInt32 Encrypt(UInt32 seed, UInt32 value)
        {
            Random rand = new Random((int)seed);
            return (value ^ (UInt32)(UInt32.MaxValue * rand.NextDouble()));
        }
    }
}

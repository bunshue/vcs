﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_force_garbage_collection
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Create a Person.
        private void btnCreatePerson_Click(object sender, EventArgs e)
        {
            Person person = new Person();
        }

        // Force garbage collection.
        private void btnCollect_Click(object sender, EventArgs e)
        {
            GC.Collect();
        }
    }
}

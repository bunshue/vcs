﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Drawing.Drawing2D;

namespace howto_tab_accelerators
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // We will draw the tabs.
            tabMenu.DrawMode = TabDrawMode.OwnerDrawFixed;

            // Look for Alt+B, Alt+L, and Alt+D.
            this.KeyPreview = true;
        }

        // Draw a tab.
        private void tabMenu_DrawItem(object sender, DrawItemEventArgs e)
        {
            // We draw in the TabRect rather than on e.Bounds
            // so the text doesn't move when the tab is selected.
            Rectangle tab_rect = tabMenu.GetTabRect(e.Index);
            tab_rect.Height += 3;

            // Draw the background.
            // Pick an appropriate background color.
            Brush bg_brush;
            if (e.State == DrawItemState.Selected)
            {
                bg_brush = new SolidBrush(Color.White);
            }
            else
            {
                bg_brush = new LinearGradientBrush(
                    tab_rect,
                    Color.White,
                    SystemColors.ControlDark,
                    LinearGradientMode.Vertical);
            }

            // Fill the background.
            e.Graphics.FillRectangle(bg_brush, tab_rect);
            bg_brush.Dispose();

            // If selected, draw the focus rectangle.
            if (e.State == DrawItemState.Selected) e.DrawFocusRectangle();

            // Draw the text.
            // Move the text area a bit.
            tab_rect.X += 3;
            tab_rect.Width -= 3;

            using (StringFormat string_format = new StringFormat())
            {
                // Draw the tab's text.
                string_format.HotkeyPrefix = System.Drawing.Text.HotkeyPrefix.Show;
                string_format.Alignment = StringAlignment.Near;
                string_format.LineAlignment = StringAlignment.Center;
                e.Graphics.DrawString(
                    tabMenu.TabPages[e.Index].Text,
                    tabMenu.Font,
                    Brushes.Black,
                    tab_rect,
                    string_format);
            }

            // Note: Don't Dispose the stock pens and brushes.
        }

        // Look for Alt+B, Alt+L, and Alt+D.
        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Alt)
            {
                switch (e.KeyCode)
                {
                    case Keys.B:
                        tabMenu.Focus();
                        tabMenu.SelectedTab = tabPageBreakfast;
                        e.Handled = true;
                        e.SuppressKeyPress = true;
                        break;
                    case Keys.L:
                        tabMenu.Focus();
                        tabMenu.SelectedTab = tabPageLunch;
                        e.Handled = true;
                        e.SuppressKeyPress = true;
                        break;
                    case Keys.D:
                        tabMenu.Focus();
                        tabMenu.SelectedTab = tabPageDinner;
                        e.Handled = true;
                        e.SuppressKeyPress = true;
                        break;
                }
            }
        }
    }
}

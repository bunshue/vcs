﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace howto_clipboard_objects
{
    [Serializable()]
    class Person
    {
        public string FirstName;
        public string LastName;
    }
}

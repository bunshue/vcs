﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_clipboard_objects
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Copy a Person to the Clipboard.
        private void btnCopy_Click(object sender, EventArgs e)
        {
            Person person = new Person() { FirstName = txtFirstName.Text, LastName = txtLastName.Text };
            Clipboard.SetDataObject(person);
        }

        // Paste the person from the Clipboard.
        private void btnPaste_Click(object sender, EventArgs e)
        {
            IDataObject data_object = Clipboard.GetDataObject();
            if (data_object.GetDataPresent("howto_clipboard_objects.Person"))
            {
                Person person = (Person)data_object.GetData("howto_clipboard_objects.Person");
                txtDropFirstName.Text = person.FirstName;
                txtDropLastName.Text = person.LastName;
            }
            else
            {
                txtDropFirstName.Clear();
                txtDropLastName.Clear();
            }
        }
    }
}

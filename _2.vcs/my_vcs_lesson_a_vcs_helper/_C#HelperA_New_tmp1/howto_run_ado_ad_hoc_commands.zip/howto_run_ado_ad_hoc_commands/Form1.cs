﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Data.OleDb;

namespace howto_run_ado_ad_hoc_commands
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // The connection object.
        private OleDbConnection Conn;

        // Prepare the database connection.
        private void Form1_Load(object sender, EventArgs e)
        {
            // Compose the database file name.
            // This assumes it's in the executable's directory.
            string file_name = Application.StartupPath + "\\Books.accdb";

            // Connect.
            Conn = new OleDbConnection(
                "Provider=Microsoft.ACE.OLEDB.12.0;" +
                "Data Source=" + file_name + ";" +
                "Mode=Share Deny None");

            // Select the first sample command.
            cboSamples.SelectedIndex = 0;
        }

        // Display a sample command.
        private void cboSamples_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (cboSamples.Text)
            {
                case "CREATE TABLE":
                    txtCommand.Text = "CREATE TABLE Employees(\n" +
                        "  FirstName TEXT(50),\n" +
                        "  LastName TEXT(50),\n" +
                        "  EmployeeId INTEGER PRIMARY KEY\n" +
                        ")";
                    break;
                case "INSERT INTO":
                    txtCommand.Text = "INSERT INTO Employees\n" +
                        "  (FirstName, LastName, EmployeeId)\n" +
                        "VALUES\n" +
                        "  ('Alice', 'Archer', 1001)";
                    break;
                case "DROP TABLE":
                    txtCommand.Text = "DROP TABLE Employees";
                    break;
            }
        }

        // Execute the command.
        private void btnExecute_Click(object sender, EventArgs e)
        {
            // Make a command object to represent the command.
            OleDbCommand cmd = new OleDbCommand();
            cmd.Connection = Conn;
            cmd.CommandText = txtCommand.Text;

            // Open the connection and execute the command.
            try
            {
                Conn.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show("Done");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error executing command.\n" + ex.Message);
            }
            finally
            {
                // Be sure to close the connection whether we succeed or fail.
                Conn.Close();
            }
        }
    }
}

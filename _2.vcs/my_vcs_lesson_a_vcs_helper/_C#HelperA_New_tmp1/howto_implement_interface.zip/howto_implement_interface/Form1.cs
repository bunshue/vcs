﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_implement_interface
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Make some people.
        private void Form1_Load(object sender, EventArgs e)
        {
            // Make some people and display them.
            SortablePerson[] unsorted = 
            {
                new SortablePerson() { FirstName = "Sam", LastName = "Cart" },
                new SortablePerson() { FirstName = "Ann", LastName = "Beech" },
                new SortablePerson() { FirstName = "Mark", LastName = "Ash" },
                new SortablePerson() { FirstName = "Chris", LastName = "Beech" },
                new SortablePerson() { FirstName = "Phred", LastName = "Cart" },
            };

            lstUnsorted.DataSource = unsorted;

            // Make some people, sort them, and display them.
            SortablePerson[] sorted = 
            {
                new SortablePerson() { FirstName = "Sam", LastName = "Cart" },
                new SortablePerson() { FirstName = "Ann", LastName = "Beech" },
                new SortablePerson() { FirstName = "Mark", LastName = "Ash" },
                new SortablePerson() { FirstName = "Chris", LastName = "Beech" },
                new SortablePerson() { FirstName = "Phred", LastName = "Cart" },
            };

            Array.Sort(sorted);
            
            lstSorted.DataSource = sorted;
        }
    }
}

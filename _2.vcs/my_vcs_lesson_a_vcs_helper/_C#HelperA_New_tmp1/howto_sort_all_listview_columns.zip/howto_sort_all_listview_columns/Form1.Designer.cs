﻿namespace howto_sort_all_listview_columns
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lvwBooks = new System.Windows.Forms.ListView();
            this.radDescending = new System.Windows.Forms.RadioButton();
            this.radAscending = new System.Windows.Forms.RadioButton();
            this.SuspendLayout();
            // 
            // lvwBooks
            // 
            this.lvwBooks.AllowColumnReorder = true;
            this.lvwBooks.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.lvwBooks.FullRowSelect = true;
            this.lvwBooks.LabelEdit = true;
            this.lvwBooks.Location = new System.Drawing.Point(0, 35);
            this.lvwBooks.Name = "lvwBooks";
            this.lvwBooks.Size = new System.Drawing.Size(297, 311);
            this.lvwBooks.Sorting = System.Windows.Forms.SortOrder.Ascending;
            this.lvwBooks.TabIndex = 2;
            this.lvwBooks.UseCompatibleStateImageBehavior = false;
            this.lvwBooks.View = System.Windows.Forms.View.Details;
            // 
            // radDescending
            // 
            this.radDescending.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.radDescending.AutoSize = true;
            this.radDescending.Location = new System.Drawing.Point(176, 12);
            this.radDescending.Name = "radDescending";
            this.radDescending.Size = new System.Drawing.Size(82, 17);
            this.radDescending.TabIndex = 1;
            this.radDescending.TabStop = true;
            this.radDescending.Text = "Descending";
            this.radDescending.UseVisualStyleBackColor = true;
            this.radDescending.Click += new System.EventHandler(this.radDescending_Click);
            // 
            // radAscending
            // 
            this.radAscending.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.radAscending.AutoSize = true;
            this.radAscending.Location = new System.Drawing.Point(38, 12);
            this.radAscending.Name = "radAscending";
            this.radAscending.Size = new System.Drawing.Size(75, 17);
            this.radAscending.TabIndex = 0;
            this.radAscending.TabStop = true;
            this.radAscending.Text = "Ascending";
            this.radAscending.UseVisualStyleBackColor = true;
            this.radAscending.Click += new System.EventHandler(this.radAscending_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(297, 346);
            this.Controls.Add(this.radAscending);
            this.Controls.Add(this.radDescending);
            this.Controls.Add(this.lvwBooks);
            this.Name = "Form1";
            this.Text = "howto_sort_all_listview_columns";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.ListView lvwBooks;
        private System.Windows.Forms.RadioButton radDescending;
        private System.Windows.Forms.RadioButton radAscending;
    }
}


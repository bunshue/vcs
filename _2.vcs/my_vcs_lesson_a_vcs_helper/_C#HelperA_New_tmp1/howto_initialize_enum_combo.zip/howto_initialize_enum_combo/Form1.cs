﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Reflection;

namespace howto_initialize_enum_combo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // The list of user types.
        private enum UserTypes
        {
            SalesAndShippingClerk,
            ShiftSupervisor,
            StoreManager
        }

        // Initialize the cboUserType ComboBox.
        private void Form1_Load(object sender, EventArgs e)
        {
            foreach (string user_type in Enum.GetNames(typeof(UserTypes)))
            {
                cboUserType.Items.Add(user_type.ToProperCase());
            }
        }

        // Get the selected user type.
        private void cboUserType_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Convert the ComboBox's text into the Pascal cased name.
            string type_name = cboUserType.Text.ToPascalCase();

            // Convert the name into a UserTypes value.
            UserTypes user_type = (UserTypes)Enum.Parse(typeof(UserTypes), type_name);

            // Prove it worked.
            switch (user_type)
            {
                case UserTypes.SalesAndShippingClerk:
                    lblSelectedType.Text = "You selected sales && shipping clerk.";
                    break;
                case UserTypes.ShiftSupervisor:
                    lblSelectedType.Text = "You selected shift supervisor.";
                    break;
                case UserTypes.StoreManager:
                    lblSelectedType.Text = "You selected store manager.";
                    break;
            }
        }
    }
}

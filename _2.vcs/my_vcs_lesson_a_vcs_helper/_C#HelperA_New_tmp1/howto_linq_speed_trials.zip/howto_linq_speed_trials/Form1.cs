﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Diagnostics;

namespace howto_linq_speed_trials
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnGo_Click(object sender, EventArgs e)
        {
            txt2Queries.Clear();
            txt1Query.Clear();
            txtArray.Clear();
            txtLoop.Clear();
            txtForeach.Clear();
            Cursor = Cursors.WaitCursor;
            Refresh();

            // Create the random values.
            int num_items = int.Parse(txtNumItems.Text);
            Point[] points = new Point[num_items];
            Random rand = new Random();
            for (int i = 0; i < num_items; i++)
                points[i] = new Point(
                    rand.Next(int.MinValue, int.MaxValue),
                    rand.Next(int.MinValue, int.MaxValue));

            Stopwatch watch = new Stopwatch();

            // Find the minimum and maximum values in 2 queries.
            watch.Reset();
            watch.Start();
            int xmin = (from Point p in points select p.X).Min();
            int xmax = (from Point p in points select p.X).Max();
            watch.Stop();
            txt2Queries.Text =
                watch.Elapsed.TotalSeconds.ToString("0.00") +
                " sec";
            Refresh();

            // Find the minimum and maximum values in 1 reused query.
            watch.Reset();
            watch.Start();
            var x_query = from Point p in points select p.X;
            xmin = x_query.Min();
            xmax = x_query.Max();
            watch.Stop();
            txt1Query.Text =
                watch.Elapsed.TotalSeconds.ToString("0.00") +
                " sec";
            Refresh();

            // Find the minimum and maximum values with an array.
            watch.Reset();
            watch.Start();
            var arr_query = from Point p in points select p.X;
            int[] xs = arr_query.ToArray();
            xmin = xs.Min();
            xmax = xs.Max();
            watch.Stop();
            txtArray.Text =
                watch.Elapsed.TotalSeconds.ToString("0.00") +
                " sec";
            Refresh();

            // Find the minimum and maximum values with a loop.
            watch.Reset();
            watch.Start();
            xmin = points[0].X;
            xmax = xmin;
            for (int i = 1; i < points.Length; i++)
            {
                if (xmin > points[i].X) xmin = points[i].X;
                if (xmax < points[i].X) xmax = points[i].X;
            }
            watch.Stop();
            txtLoop.Text =
                watch.Elapsed.TotalSeconds.ToString("0.00") +
                " sec";
            Refresh();

            // Find the minimum and maximum values with a foreach loop.
            watch.Reset();
            watch.Start();
            xmin = points[0].X;
            xmax = xmin;
            foreach (Point pt in points)
            {
                if (xmin > pt.X) xmin = pt.X;
                if (xmax < pt.X) xmax = pt.X;
            }
            watch.Stop();
            txtForeach.Text =
                watch.Elapsed.TotalSeconds.ToString("0.00") +
                " sec";
            Refresh();

            Cursor = Cursors.Default;
        }
    }
}

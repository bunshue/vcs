﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Data.OleDb;

namespace howto_run_ado_ad_hoc_queries
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // The connection object.
        private OleDbConnection Conn;

        // Prepare the database connection.
        private void Form1_Load(object sender, EventArgs e)
        {
            // Compose the database file name.
            // This assumes it's in the executable's directory.
            string file_name = Application.StartupPath + "\\Books.accdb";

            // Connect.
            Conn = new OleDbConnection(
                "Provider=Microsoft.ACE.OLEDB.12.0;" +
                "Data Source=" + file_name + ";" +
                "Mode=Share Deny None");

            // Select the first sample command.
            cboSamples.SelectedIndex = 0;
        }

        private void cboSamples_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (cboSamples.Text)
            {
                case "Select":
                    txtQuery.Text = "SELECT * FROM BookInfo";
                    break;
                case "Sort":
                    txtQuery.Text = "SELECT * FROM BookInfo\r\n" +
                        "ORDER BY PubYear";
                    break;
                case "Condition":
                    txtQuery.Text = "SELECT * FROM BookInfo\r\n" +
                        "WHERE PubYear >= 2000\r\n" + 
                        "ORDER BY PubYear DESC";
                    break;
                case "Join":
                    txtQuery.Text = "SELECT FirstName, LastName, TestNumber, Score\r\n" +
                        "FROM Pupils, TestScores\r\n" +
                        "WHERE Pupils.StudentId = TestScores.StudentId\r\n" +
                        "ORDER BY FirstName, LastName, TestNumber";
                    break;
            }
        }

        // Execute the query.
        private void btnExecute_Click(object sender, EventArgs e)
        {
            // Make a command object to represent the command.
            OleDbCommand cmd = new OleDbCommand();
            cmd.Connection = Conn;
            cmd.CommandText = txtQuery.Text;

            // Open the connection and execute the command.
            try
            {
                // Open the connection.
                Conn.Open();

                // Execute the query. The reader gives access to the results.
                OleDbDataReader reader = cmd.ExecuteReader();

                // Prepare the DataGridView.
                dgvResults.Columns.Clear();
                dgvResults.Rows.Clear();
                if (reader.HasRows)
                {
                    // Get field information.
                    DataTable schema = reader.GetSchemaTable();
                    int field_num = 0;
                    foreach (DataRow schema_row in schema.Rows)
                    {
                        // Create the column.
                        int col_num = dgvResults.Columns.Add(
                            "col" + field_num.ToString(),
                            schema_row.Field<string>("ColumnName"));
                        field_num++;
                        
                        // Make the column size to fit its data.
                        dgvResults.Columns[col_num].AutoSizeMode = 
                            DataGridViewAutoSizeColumnMode.AllCells;
                    }

                    // Make room to hold a row's values.
                    object[] values = new object[reader.FieldCount];

                    // Loop while the reader has unread data.
                    while (reader.Read())
                    {
                        // Add this row to the DataGridView.
                        reader.GetValues(values);
                        dgvResults.Rows.Add(values);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error executing command.\n" + ex.Message);
            }
            finally
            {
                // Be sure to close the connection whether we succeed or fail.
                Conn.Close();
            }
        }
    }
}

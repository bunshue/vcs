﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_use_background_worker
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Use the BackgroundWorker to perform a long task.
        private void btnGo_Click(object sender, EventArgs e)
        {
            if (btnGo.Text == "Go")
            {
                // Start the process.
                lblStatus.Text = "Working...";
                btnGo.Text = "Stop";
                prgPercentComplete.Value = 0;
                prgPercentComplete.Visible = true;

                // Start the BackgroundWorker.
                bgwLongTask.RunWorkerAsync();
            }
            else
            {
                // Stop the process.
                bgwLongTask.CancelAsync();
            }
        }

        // Perform the long task.
        private void bgwLongTask_DoWork(object sender, DoWorkEventArgs e)
        {
            // Spend 10 seconds doing nothing.
            for (int i = 1; i <= 10; i++)
            {
                // If we should stop, do so.
                if (bgwLongTask.CancellationPending)
                {
                    // Indicate that the task was canceled.
                    e.Cancel = true;
                    break;
                }

                // Sleep.
                System.Threading.Thread.Sleep(1000);

                // Notify the UI thread of our progress.
                bgwLongTask.ReportProgress(i * 10);
            }
        }

        // Update the progress bar.
        private void bgwLongTask_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            prgPercentComplete.Value = e.ProgressPercentage;
        }

        // The long task is done.
        private void bgwLongTask_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (e.Cancelled)
            {
                lblStatus.Text = "Canceled";
            }
            else
            {
                lblStatus.Text = "Finished";
            }
            btnGo.Text = "Go";
            prgPercentComplete.Visible = false;
        }

        // Display the current time.
        private void tmrClock_Tick(object sender, EventArgs e)
        {
            lblClock.Text = DateTime.Now.ToString("T");
        }
    }
}

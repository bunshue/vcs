﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.IO;

namespace howto_manage_recycle_bin
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // Display the number of items in the recycle bin.
            lblNumItems.Text = Recycler.NumberOfFilesInRecycleBin().ToString() +
                " items in wastebasket";

            // Make files we can delete.
            MakeTestFiles();
        }

        // Delete the file.
        private void btnDeleteFile_Click(object sender, EventArgs e)
        {
            Recycler.DeleteFile(
                txtFile.Text,
                chkConfirmDelete.Checked,
                radDeletePermanently.Checked);
        }

        // Delete the directory.
        private void btnDeleteDirectory_Click(object sender, EventArgs e)
        {
            Recycler.DeleteDirectory(
                txtDirectory.Text,
                chkConfirmDelete.Checked,
                radDeletePermanently.Checked);
        }

        // Empty the wastebasket.
        private void btnEmpty_Click(object sender, EventArgs e)
        {
            Recycler.EmptyWastebasket(
                chkProgress.Checked, 
                chkPlaySound.Checked, 
                chkConfirmEmpty.Checked);
        }

        // Display the number of items in the recycle bin.
        private void tmrCheckBin_Tick(object sender, EventArgs e)
        {
            lblNumItems.Text = Recycler.NumberOfFilesInRecycleBin().ToString() +
                " items in wastebasket";
        }

        // Make a file and a directory that we can delete.
        private void MakeTestFiles()
        {
            // Make a file.
            string filename = Application.StartupPath + "\\Test.txt";
            if (!File.Exists(filename))
            {
                File.WriteAllText(filename, "This is a test file.");
            }
            txtFile.Text = filename;

            // Make a directory.
            string dirname = Application.StartupPath + "\\TestFiles";
            if (!Directory.Exists(dirname))
            {
                Directory.CreateDirectory(dirname);
            }
            txtDirectory.Text = dirname;

            filename = dirname + "\\Test2.txt";
            if (!File.Exists(filename))
            {
                File.WriteAllText(filename, "This is another test file.");
            }
        }
    }
}

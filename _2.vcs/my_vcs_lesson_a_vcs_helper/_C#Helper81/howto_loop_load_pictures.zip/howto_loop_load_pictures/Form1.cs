﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.IO;

namespace howto_loop_load_pictures
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string dirname = Path.GetFullPath(
                Path.Combine(Application.StartupPath, @"..\..\"));

            // Make an array holding the PictureBoxes.
            PictureBox[] pics = { PictureBox1, PictureBox2, PictureBox3, PictureBox4 };

            // Load the pictures in a loop.
            for (int i = 0; i < pics.Length; i++)
            {
                string filename = dirname + "pic" + i.ToString() + ".png";
                using (Bitmap bm = new Bitmap(filename))
                {
                    pics[i].Image = (Bitmap)bm.Clone();
                }
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_datagridview_format_columns
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Add some test data.
        private void Form1_Load(object sender, EventArgs e)
        {
            dgvValues.Rows.Add("Notebook", 1.17m, 6m, 1.17m * 6m);
            dgvValues.Rows.Add("Cookies", 3.59m, 12m, 3.59m * 12m);
            dgvValues.Rows.Add("AAA Batteries", 4.99m, 1m, 4.99m * 1m);
            dgvValues.Rows.Add("Pencil sharpener", 19.95m, 1m, 19.95m * 1m);
            dgvValues.Rows.Add("Sticky notes", null, 1m, null);
            dgvValues.Rows.Add("Highlighter pens", 1.95m, null, null);
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            // Create the new row.
            decimal price_each = decimal.Parse(txtPriceEach.Text);
            decimal quantity = decimal.Parse(txtQuantity.Text);
            decimal total = price_each * quantity;
            dgvValues.Rows.Add(txtItem.Text, price_each, quantity, total);

            // Get ready for the next entry.
            txtItem.Clear();
            txtPriceEach.Clear();
            txtQuantity.Clear();
            txtItem.Focus();
        }
    }
}

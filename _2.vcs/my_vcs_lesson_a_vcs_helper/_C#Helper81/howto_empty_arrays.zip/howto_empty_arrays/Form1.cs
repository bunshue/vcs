﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_empty_arrays
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Declare an array and try to use its properties.
        private void btnDeclare_Click(object sender, EventArgs e)
        {
            int[] values = null;
            try
            {
                // This fails.
                for (int i = 0; i < values.Length; i++)
                {
                    MessageBox.Show("Value[" + i + "]: " + values[i]);
                }
                MessageBox.Show("Done");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        // Declare an array and initialize it to an empty array.
        private void btnDeclareAndInitialize_Click(object sender, EventArgs e)
        {
            int[] values = new int[0];
            try
            {
                for (int i = 0; i < values.Length; i++)
                {
                    MessageBox.Show("Value[" + i + "]: " + values[i]);
                }
                MessageBox.Show("Done");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}

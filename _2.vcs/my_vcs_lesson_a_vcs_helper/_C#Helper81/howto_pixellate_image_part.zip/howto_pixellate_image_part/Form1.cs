using System;
using System.Drawing;
using System.Windows.Forms;

using System.Drawing.Imaging;
using System.IO;

namespace howto_pixellate_image_part
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // The current image without the rubberband rectangle.
        private Bitmap CurrentBitmap = null;

        // Open a file.
        private void mnuFileOpen_Click(object sender, EventArgs e)
        {
            try
            {
                if (ofdImage.ShowDialog() == DialogResult.OK)
                {
                    using (Bitmap bm = new Bitmap(ofdImage.FileName))
                    {
                        CurrentBitmap = bm.Clone() as Bitmap;
                        picImage.Image = bm.Clone() as Image;
                    }
                    ClientSize = new Size(
                        picImage.Right + picImage.Left,
                        picImage.Bottom + picImage.Left);
                    picImage.Visible = true;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        // Save the image into a file.
        private void mnuFileSaveAs_Click(object sender, EventArgs e)
        {
            if (sfdImage.ShowDialog() == DialogResult.OK)
            {
                Bitmap bm = (Bitmap)picImage.Image;
                SaveBitmapUsingExtension(bm, sfdImage.FileName);
            }
        }

        // Save the file with the appropriate format.
        // Throw a NotSupportedException if the file
        // has an unknown extension.
        public void SaveBitmapUsingExtension(Bitmap bm, string filename)
        {
            string extension = Path.GetExtension(filename);
            switch (extension.ToLower())
            {
                case ".bmp":
                    bm.Save(filename, ImageFormat.Bmp);
                    break;
                case ".exif":
                    bm.Save(filename, ImageFormat.Exif);
                    break;
                case ".gif":
                    bm.Save(filename, ImageFormat.Gif);
                    break;
                case ".jpg":
                case ".jpeg":
                    bm.Save(filename, ImageFormat.Jpeg);
                    break;
                case ".png":
                    bm.Save(filename, ImageFormat.Png);
                    break;
                case ".tif":
                case ".tiff":
                    bm.Save(filename, ImageFormat.Tiff);
                    break;
                default:
                    throw new NotSupportedException(
                        "Unknown file extension " + extension);
            }
        }

        private void mnuFileExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        // Select an area.
        private int StartX = -1, StartY = -1;
        private Bitmap BoxBitmap = null;
        private Graphics BoxGraphics = null;
        private void picImage_MouseDown(object sender, MouseEventArgs e)
        {
            if (CurrentBitmap == null) return;
            StartX = e.X;
            StartY = e.Y;

            // Make the selected image.
            BoxBitmap = new Bitmap(CurrentBitmap);
            BoxGraphics = Graphics.FromImage(BoxBitmap);
            picImage.Image = BoxBitmap;
        }

        // Continue selecting the area.
        private void picImage_MouseMove(object sender, MouseEventArgs e)
        {
            if (StartX < 0) return;

            // Restore the current image.
            BoxGraphics.DrawImage(CurrentBitmap, 0, 0);

            // Draw the selection rectangle.
            using (Pen select_pen = new Pen(Color.Red))
            {
                select_pen.DashStyle = System.Drawing.Drawing2D.DashStyle.Dash;
                Rectangle rect = MakeRectangle(StartX, StartY, e.X, e.Y);
                BoxGraphics.DrawRectangle(select_pen, rect);
            }
            picImage.Refresh();
        }

        // Return a Rectangle with these points as corners.
        private Rectangle MakeRectangle(int x0, int y0, int x1, int y1)
        {
            return new Rectangle(
                Math.Min(x0, x1),
                Math.Min(y0, y1),
                Math.Abs(x0 - x1),
                Math.Abs(y0 - y1));
        }

        // Pixellate the selected area and save the result.
        private void picImage_MouseUp(object sender, MouseEventArgs e)
        {
            if (StartX < 0) return;

            PixellateRectangle(MakeRectangle(StartX, StartY, e.X, e.Y));

            // Remember we're not selecting any more.
            StartX = -1;
            StartY = -1;
            BoxGraphics.Dispose();
            BoxGraphics = null;
            BoxBitmap.Dispose();
            BoxBitmap = null;
        }

        // Pixellate the indicated rectangle.
        private void PixellateRectangle(Rectangle rect)
        {
            // Restrict the rectangle to fit on the image.
            int bm_wid = CurrentBitmap.Width;
            int bm_hgt = CurrentBitmap.Height;
            rect = Rectangle.Intersect(rect,
                new Rectangle(0, 0, bm_wid, bm_hgt));

            // Process the rectangle.
            const int box_wid = 8;
            using (Graphics gr = Graphics.FromImage(CurrentBitmap))
            {
                int start_y = box_wid * (int)(rect.Top / box_wid);
                int start_x = box_wid * (int)(rect.Left / box_wid);
                for (int y = start_y; y <= rect.Bottom; y += box_wid)
                {
                    for (int x = start_x; x <= rect.Right; x += box_wid)
                    {
                        // Pixellate the area with upper left corner (x, y).

                        // Get the average of the pixels' color component values.
                        int total_r = 0, total_g = 0, total_b = 0, num_pixels = 0;
                        for (int dy = 0; dy < box_wid; dy++)
                        {
                            if (y + dy >= bm_hgt) break;
                            for (int dx = 0; dx < box_wid; dx++)
                            {
                                if (x + dx >= bm_wid) break;
                                Color pixel_color = 
                                    CurrentBitmap.GetPixel(x + dx, y + dy);
                                total_r += pixel_color.R;
                                total_g += pixel_color.G;
                                total_b += pixel_color.B;
                                num_pixels++;
                            }
                        }
                        byte r = (byte)(total_r / num_pixels);
                        byte g = (byte)(total_g / num_pixels);
                        byte b = (byte)(total_b / num_pixels);
                        Color new_color = Color.FromArgb(255, r, g, b);

                        // Give all pixels in the box this color.
                        using (Brush br = new SolidBrush(new_color))
                        {
                            gr.FillRectangle(br, x, y, box_wid, box_wid);
                        }
                    }
                }

                // Refresh to show the new image.
                picImage.Image = CurrentBitmap;
                picImage.Refresh();
            }
        }
    }
}

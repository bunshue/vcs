﻿namespace howto_big_head
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.picBigHead = new System.Windows.Forms.PictureBox();
            this.picHead = new System.Windows.Forms.PictureBox();
            this.picBody = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.picBigHead)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picHead)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBody)).BeginInit();
            this.SuspendLayout();
            // 
            // picBigHead
            // 
            this.picBigHead.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picBigHead.Location = new System.Drawing.Point(12, 12);
            this.picBigHead.Name = "picBigHead";
            this.picBigHead.Size = new System.Drawing.Size(183, 270);
            this.picBigHead.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.picBigHead.TabIndex = 5;
            this.picBigHead.TabStop = false;
            // 
            // picHead
            // 
            this.picHead.Image = global::howto_big_head.Properties.Resources.Donald_Trump_Head;
            this.picHead.Location = new System.Drawing.Point(201, 12);
            this.picHead.Name = "picHead";
            this.picHead.Size = new System.Drawing.Size(161, 202);
            this.picHead.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.picHead.TabIndex = 4;
            this.picHead.TabStop = false;
            this.picHead.Visible = false;
            // 
            // picBody
            // 
            this.picBody.Image = global::howto_big_head.Properties.Resources.Donald_Trump_Body;
            this.picBody.Location = new System.Drawing.Point(92, 25);
            this.picBody.Name = "picBody";
            this.picBody.Size = new System.Drawing.Size(517, 600);
            this.picBody.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picBody.TabIndex = 3;
            this.picBody.TabStop = false;
            this.picBody.Visible = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 261);
            this.Controls.Add(this.picBigHead);
            this.Controls.Add(this.picHead);
            this.Controls.Add(this.picBody);
            this.Name = "Form1";
            this.Text = "howto_big_head";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.picBigHead)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picHead)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBody)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox picBigHead;
        private System.Windows.Forms.PictureBox picHead;
        private System.Windows.Forms.PictureBox picBody;
    }
}


﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Drawing.Drawing2D;

namespace howto_pixel_offset_mode
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            cboMode.SelectedIndex = 0;
        }

        // Use the selected mode.
        private void cboMode_SelectedIndexChanged(object sender, EventArgs e)
        {
            PixelOffsetMode mode = PixelOffsetMode.Default;
            switch (cboMode.Text)
            {
                case "Half":
                    mode = PixelOffsetMode.Half;
                    break;
                case "HighQuality":
                    mode = PixelOffsetMode.HighQuality;
                    break;
                case "HighSpeed":
                    mode = PixelOffsetMode.HighSpeed;
                    break;
                case "None":
                    mode = PixelOffsetMode.None;
                    break;
            }

            // Make the scaled image.
            picScaled.Image = MakeScaledImage(
                picOriginal.Image, 20, mode);
        }

        // Return a scaled version of the input image.
        private Bitmap MakeScaledImage(Image image,
            int scale, PixelOffsetMode mode)
        {
            int wid = scale * image.Width;
            int hgt = scale * image.Height;
            Bitmap bm = new Bitmap(wid, hgt);
            using (Graphics gr = Graphics.FromImage(bm))
            {
                gr.Clear(Color.Yellow);

                Rectangle src_rect = new Rectangle(0, 0,
                    image.Width, image.Height);
                Rectangle dest_rect = new Rectangle(0, 0,
                    wid, hgt);
                gr.PixelOffsetMode = mode;
                gr.InterpolationMode = InterpolationMode.NearestNeighbor;
                gr.DrawImage(image, dest_rect, src_rect, GraphicsUnit.Pixel);
            }

            return bm;
        }
    }
}

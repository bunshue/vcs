﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using Microsoft.Win32;

namespace howto_get_registered_owner
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            object owner_string = "", company_string = "";
            OperatingSystem os_info = System.Environment.OSVersion;
            if (os_info.Platform == PlatformID.Win32Windows)
            {
                // Windows 98?
                owner_string = RegistryTools.GetRegistryValue(
                    Registry.LocalMachine,
                    @"SOFTWARE\Microsoft\Windows\CurrentVersion\",
                    "RegisteredOwner", "Unknown");
                company_string = RegistryTools.GetRegistryValue(
                    Registry.LocalMachine,
                    @"SOFTWARE\Microsoft\Windows\CurrentVersion\",
                    "RegisteredOrganization", "Unknown");
            }
            else if (os_info.Platform == PlatformID.Win32NT)
            {
                // Windows NT.
                owner_string = RegistryTools.GetRegistryValue(
                    Registry.LocalMachine,
                    @"SOFTWARE\Microsoft\Windows NT\CurrentVersion\",
                    "RegisteredOwner", "Unknown");
                company_string = RegistryTools.GetRegistryValue(
                    Registry.LocalMachine,
                    @"SOFTWARE\Microsoft\Windows NT\CurrentVersion\",
                    "RegisteredOrganization", "Unknown");
            }

            txtOwner.Text = owner_string.ToString();
            txtCompany.Text = company_string.ToString();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Globalization;
using System.Drawing.Drawing2D;

namespace howto_monthly_investment3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // The drawing transformation.
        private Matrix Transform, InverseTransform;

        // The data points.
        private List<PointF> Balance = new List<PointF>();
        private List<PointF> Contributions = new List<PointF>();

        // The X coordinate of the mouse position.
        private int MouseX = -1;

        // Display some initial data.
        private void Form1_Load(object sender, EventArgs e)
        {
            PerformCalculations();
        }

        // Calculate the interest compounded monthly.
        private void btnGo_Click(object sender, EventArgs e)
        {
            PerformCalculations();
        }

        // Perform the calculations.
        private void PerformCalculations()
        {
            // Get the parameters.
            decimal monthly_contribution = decimal.Parse(
                txtMonthlyContribution.Text, NumberStyles.Any);
            int num_months = int.Parse(txtNumMonths.Text);
            decimal interest_rate = decimal.Parse(
                txtInterestRate.Text.Replace("%", "")) / 100;
            interest_rate /= 12;

            // Start at 0.
            Balance = new List<PointF>();
            Contributions = new List<PointF>();
            decimal contributions = 0;
            decimal interest = 0;
            decimal balance = 0;

            // Calculate.
            for (int i = 0; i <= num_months; i++)
            {
                // Save the contributions and balance.
                Contributions.Add(new PointF(i, (float)contributions));
                Balance.Add(new PointF(i, (float)balance));

                // Calculate the values for next month.
                contributions += monthly_contribution;
                decimal new_interest = balance * interest_rate;
                interest += new_interest;
                balance += monthly_contribution + new_interest;
            }

            // Add points to close the polygons.
            Contributions.Add(new PointF(num_months, 0));
            Balance.Add(new PointF(num_months, 0));

            // Redraw.
            picGraph.Refresh();
        }

        // Draw the graph.
        private void picGraph_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.Clear(picGraph.BackColor);
            if (Balance.Count < 2) return;

            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;

            // Scale to make the data fit.
            float xmin = -1;
            float xmax = Contributions.Count + 1;
            float ymax = Balance.Max(pt => pt.Y);
            float ymin = -ymax * 0.05f;
            RectangleF rect = new RectangleF(xmin, ymin, xmax - xmin, ymax - ymin);
            PointF[] pts =
            {
                new PointF(0, picGraph.ClientSize.Height),
                new PointF(picGraph.ClientSize.Width, picGraph.ClientSize.Height),
                new PointF(0, 0),
            };
            Transform = new Matrix(rect, pts);
            e.Graphics.Transform = Transform;
            InverseTransform = Transform.Clone();
            InverseTransform.Invert();

            // Draw the curves.
            e.Graphics.FillPolygon(Brushes.Pink, Balance.ToArray());
            e.Graphics.FillPolygon(Brushes.LightGreen, Contributions.ToArray());
            e.Graphics.DrawPolygon(Pens.Red, Balance.ToArray());
            e.Graphics.DrawPolygon(Pens.Green, Contributions.ToArray());

            // Draw the mouse's X position.
            if (MouseX >= 0)
            {
                e.Graphics.ResetTransform();
                e.Graphics.DrawLine(Pens.Blue,
                    MouseX, 0,
                    MouseX, picGraph.ClientSize.Height);
            }
        }

        // Display the nearest month's values.
        private void picGraph_MouseMove(object sender, MouseEventArgs e)
        {
            if (Transform == null) return;
            if (Balance.Count < 3) return;

            // Find the month closest to the mouse.
            PointF[] points = { new PointF(e.X, 0) };
            InverseTransform.TransformPoints(points);
            int month = (int)Math.Round(points[0].X);

            string tip = "";
            if ((month >= 0) && (month < Balance.Count - 1))
            {
                float interest = Balance[month].Y - Contributions[month].Y;
                tip = "Month: " + month.ToString() +
                    "\nContributions: " + Contributions[month].Y.ToString("C") +
                    "\nInterest: " + interest.ToString("C") +
                    "\nTotal: " + Balance[month].Y.ToString("C");
                MouseX = e.X;
            }
            else
            {
                MouseX = -1;
            }

            // Display the new tool tip.
            if (tip != tipAmount.GetToolTip(picGraph))
            {
                tipAmount.SetToolTip(picGraph, tip);
                Console.WriteLine("[" + tip + "]");
                picGraph.Refresh();
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.IO;
using System.Drawing.Imaging;
using System.Drawing.Drawing2D;
using System.Runtime.InteropServices;

// Set the "Copy to Output Directory" property for
// the image files to "Copy if Newer."

namespace howto_metafile_records
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Keep the metafile loaded.
        private Metafile TheMetafile;

        // A Graphics object used to draw on the current bitmap.
        private Graphics TheGraphics;

        // The index of the last record we drew.
        private int LastRecord;

        private void Form1_Load(object sender, EventArgs e)
        {
            clbRecords.CheckOnClick = true;
            picResult.SizeMode = PictureBoxSizeMode.Zoom;

            // Load the metafile.
            TheMetafile = (Metafile)Metafile.FromFile("Volleyball.wmf");
            
            // Use any Graphics object to enumerate the metafile records.
            using (Graphics gr = this.CreateGraphics())
            {
                gr.EnumerateMetafile(TheMetafile, new PointF(0, 0), ListRecordCallback);
            }

            // Initially check all records.
            for (int i = 0; i < clbRecords.Items.Count; i++)
                clbRecords.SetItemChecked(i, true);

            // Display the initial result.
            DisplayRecords();
        }

        // Add a record to the metafile record ListBox.
        private bool ListRecordCallback(EmfPlusRecordType record_type, int flags,
            int data_size, IntPtr data, PlayRecordCallback callback_data)
        {
            clbRecords.Items.Add(record_type.ToString());
            return true;
        }

        // Redisplay the metafile's currently selected records.
        private void clbRecords_SelectedIndexChanged(object sender, EventArgs e)
        {
            DisplayRecords();
        }

        private void btnCheckAll_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < clbRecords.Items.Count; i++)
                clbRecords.SetItemChecked(i, true);
            DisplayRecords();
        }

        private void btnUncheckAll_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < clbRecords.Items.Count; i++)
                clbRecords.SetItemChecked(i, false);
            DisplayRecords();
        }

        // Draw the checked metafile records.
        private void DisplayRecords()
        {
            // Make a bitmap to hold the result.
            int wid = TheMetafile.Width;
            int hgt = TheMetafile.Height;
            Bitmap bm = new Bitmap(wid, hgt);

            // Start at the first record.
            LastRecord = -1;

            // Draw the selected records on the bitmap.
            using (TheGraphics = Graphics.FromImage(bm))
            {
                Rectangle dest = new Rectangle(0, 0, wid, hgt);
                TheGraphics.EnumerateMetafile(
                    TheMetafile, dest, DrawRecordCallback);
            }

            // Display the result.
            picResult.Image = bm;
        }

        // Draw a record on TheGraphics.
        private bool DrawRecordCallback(EmfPlusRecordType record_type, int flags,
            int data_size, IntPtr data, PlayRecordCallback callback_data)
        {
            // Consider the next record.
            LastRecord++;

            // If this record is not selected, skip it.
            if (!clbRecords.GetItemChecked(LastRecord))
            {
                Console.WriteLine("Skipping " + LastRecord +
                    ": " + record_type.ToString());
                return true;
            }

            // Display this record.
            byte[] data_array = null;
            if (!data.Equals(IntPtr.Zero))
            {
                // Copy the unmanaged record data into a managed
                // byte buffer that we can pass to PlayRecord.
                data_array = new byte[data_size];
                Marshal.Copy(data, data_array, 0, data_size);
            }

            // Play the record.
            TheMetafile.PlayRecord(record_type, flags, data_size, data_array);

            // Continue the enumeration.
            return true;
        }
    }
}

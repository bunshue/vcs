﻿//#define DRAW_POINTS
//#define DRAW_LEVEL_MINUS_1

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

// http://en.wikipedia.org/wiki/Dragon_curve
// http://en.wikipedia.org/wiki/Heighway_dragon
// http://ecademy.agnesscott.edu/~lriddle/ifs/heighway/heighway.htm

namespace howto_four_heighway_dragons
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // The direction the curve should turn next.
        private enum Direction
        {
            Left,
            Right
        }

        // Redraw.
        private void Form1_Load(object sender, EventArgs e)
        {
            MakeImage();
        }
        private void btnDraw_Click(object sender, EventArgs e)
        {
            MakeImage();
        }
        private void picDragon_SizeChanged(object sender, EventArgs e)
        {
            MakeImage();
        }

        // Draw the dragon.
        private void MakeImage()
        {
            Cursor = Cursors.WaitCursor;

            Bitmap bm = new Bitmap(picDragon.ClientSize.Width, picDragon.ClientSize.Height);
            using (Graphics gr = Graphics.FromImage(bm))
            {
                gr.Clear(picDragon.BackColor);

                // Find the first control point.
                const int margin = 5;
                float dx = Math.Min(
                    (picDragon.ClientSize.Width - 2 * margin) / (14 / 6f),
                    (picDragon.ClientSize.Height - 2 * margin) / (14 / 6f));

                // Center it.
                float x0 = picDragon.ClientSize.Width / 2;
                float y0 = picDragon.ClientSize.Height / 2;

                // Recursively draw the lines.
                int level = (int)nudLevel.Value;
                if (DrawLastColor != Color.Red)
                    DrawDragonLine(gr, Pens.Red, level, Direction.Right, x0, y0, dx, 0);
                if (DrawLastColor != Color.Green)
                    DrawDragonLine(gr, Pens.Green, level, Direction.Right, x0, y0, 0, dx);
                if (DrawLastColor != Color.Blue)
                    DrawDragonLine(gr, Pens.Blue, level, Direction.Right, x0, y0, -dx, 0);
                if (DrawLastColor != Color.Black)
                    DrawDragonLine(gr, Pens.Black, level, Direction.Right, x0, y0, 0, -dx);

                // Redraw the one we should draw last.
                if (DrawLastColor == Color.Red)
                    DrawDragonLine(gr, Pens.Red, level, Direction.Right, x0, y0, dx, 0);
                else if (DrawLastColor == Color.Green)
                    DrawDragonLine(gr, Pens.Green, level, Direction.Right, x0, y0, 0, dx);
                else if (DrawLastColor == Color.Blue)
                    DrawDragonLine(gr, Pens.Blue, level, Direction.Right, x0, y0, -dx, 0);
                else if (DrawLastColor == Color.Black)
                    DrawDragonLine(gr, Pens.Black, level, Direction.Right, x0, y0, 0, -dx);
            }

            // Display the result.
            picDragon.Image = bm;

            Cursor = Cursors.Default;
        }

        // Recursively draw the dragon curve between the two points.
        private void DrawDragonLine(Graphics gr, Pen pen, int level, Direction turn_towards, float x1, float y1, float dx, float dy)
        {
            if (level <= 0)
            {
                gr.DrawLine(pen, x1, y1, x1 + dx, y1 + dy);

#if DRAW_POINTS
                gr.DrawEllipse(Pens.Blue, x1 - 2, y1 - 2, 4, 4);
                gr.DrawEllipse(Pens.Blue, x1 + dx - 2, y1 + dy - 2, 4, 4);
#endif
            }
            else
            {
#if DRAW_LEVEL_MINUS_1
                if (level == 1)
                {
                    gr.DrawLine(Pens.Silver, x1, y1, x1 + dx, y1 + dy);
                }
#endif
                float nx = (float)(dx / 2);
                float ny = (float)(dy / 2);
                float dx2 = -ny + nx;
                float dy2 = nx + ny;
                if (turn_towards == Direction.Right)
                {
                    // Turn to the right.
                    DrawDragonLine(gr, pen, level - 1, Direction.Right, x1, y1, dx2, dy2);
                    float x2 = x1 + dx2;
                    float y2 = y1 + dy2;
                    DrawDragonLine(gr, pen, level - 1, Direction.Left, x2, y2, dy2, -dx2);
                }
                else
                {
                    // Turn to the left.
                    DrawDragonLine(gr, pen, level - 1, Direction.Right, x1, y1, dy2, -dx2);
                    float x2 = x1 + dy2;
                    float y2 = y1 - dx2;
                    DrawDragonLine(gr, pen, level - 1, Direction.Left, x2, y2, dx2, dy2);
                }
            }
        }

        // Select the clicked color as the one to draw last.
        private Color DrawLastColor = Color.Black;
        private void picDragon_MouseClick(object sender, MouseEventArgs e)
        {
            // See which color was clicked.
            using (Bitmap bm = new Bitmap(picDragon.Image))
            {
                Color clr = bm.GetPixel(e.X, e.Y);
                if (clr == Color.FromArgb(255, 255, 0, 0))
                    DrawLastColor = Color.Red;
                else if (clr == Color.FromArgb(255, 0, 255, 0))
                    DrawLastColor = Color.Green;
                else if (clr == Color.FromArgb(255, 0, 0, 255))
                    DrawLastColor = Color.Blue;
                else if (clr == Color.FromArgb(255, 0, 0, 0))
                    DrawLastColor = Color.Black;
            }

            // Redraw.
            MakeImage();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.IO;

namespace howto_set_file_times
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Start with the executable file selected.
        private void Form1_Load(object sender, EventArgs e)
        {
            txtFile.Text = Application.ExecutablePath;
        }

        // Let the user pick a file.
        private void btnPickFile_Click(object sender, EventArgs e)
        {
            ofdFile.FileName = txtFile.Text;
            if (ofdFile.ShowDialog() == DialogResult.OK)
            {
                txtFile.Text = ofdFile.FileName;
            }
        }

        // Get the file's times.
        private void btnGetTimes_Click(object sender, EventArgs e)
        {
            txtCreationTime.Text = File.GetCreationTime(txtFile.Text).ToString();
            txtModifiedTime.Text = File.GetLastWriteTime(txtFile.Text).ToString();
            txtAccessTime.Text = File.GetLastAccessTime(txtFile.Text).ToString();
        }

        // Set the file's times.
        private void btnSetTimes_Click(object sender, EventArgs e)
        {
            File.SetCreationTime(txtFile.Text, DateTime.Parse(txtCreationTime.Text));
            File.SetLastWriteTime(txtFile.Text, DateTime.Parse(txtModifiedTime.Text));
            File.SetLastAccessTime(txtFile.Text, DateTime.Parse(txtAccessTime.Text));
        }
    }
}

﻿using System;
using System.Windows.Forms;

using System.Globalization;

namespace howto_get_first_day_of_week_name
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            lblResult.Text = "The first day of the week is " +
                CultureInfo.CurrentCulture.DateTimeFormat.DayNames[0];
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_nonzero_lower_bound
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // Make an array data[2000..2009, 1..4].
            Array data = Array.CreateInstance(typeof(int),
                new int[] { 10, 4 },
                new int[] { 2000, 1});

            // Initialize the data randomly.
            Random rand = new Random();
            for (int year = 2000; year <= 2009; year++)
            {
                for (int quarter = 1; quarter <= 4; quarter++)
                {
                    data.SetValue(rand.Next(10, 99), year, quarter);
                }
            }

            // Display the data.
            string txt = "Year\tQ1\tQ2\tQ3\tQ4";
            for (int year = data.GetLowerBound(0); year <= data.GetUpperBound(0); year++)
            {
                txt += "\r\n" + year.ToString();
                for (int quarter = data.GetLowerBound(1); quarter <= data.GetUpperBound(1); quarter++)
                {
                    txt += string.Format("\t{0}", data.GetValue(year, quarter));
                }
            }
            txtData.Text = txt;
            txtData.Select(0, 0);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Diagnostics;

namespace howto_nonzero_lower_bounds_class
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // Make a three-dimensional array data[11..12, 21..23, 31..35].
            BoundsArray<int> data = new BoundsArray<int>(11, 12, 21, 23, 31, 35);

            // Make some data.
            for (int d = 11; d <= 12; d++)
            {
                for (int r = 21; r <= 23; r++)
                {
                    for (int c = 31; c <= 35; c++)
                    {
                        data[d, r, c] = d * 10000 + r * 100 + c;
                    }
                }
            }

            // Get the data back.
            string txt = "";
            for (int d = 11; d <= 12; d++)
            {
                for (int r = 21; r <= 23; r++)
                {
                    for (int c = 31; c <= 35; c++)
                    {
                        // Display the value.
                        txt += string.Format("{0,-2}{1,-2}{2,-2}: {3,-6}\r\n",
                            d, r, c, data[d, r, c]);

                        // Check the value.
                        Debug.Assert(data[d, r, c] == d * 10000 + r * 100 + c);
                    }
                }
            }
            txtData.Text = txt;
            txtData.Select(0, 0);
        }

        // Compare the BoundsArray and Array classes.
        private void btnGo_Click(object sender, EventArgs e)
        {
            int num_trials = int.Parse(txtNumTrials.Text);
            DateTime start_time, stop_time;
            TimeSpan elapsed;
            lblArray.Text = "";
            lblBoundsArray.Text = "";
            lblPlain.Text = "";
            this.Cursor = Cursors.WaitCursor;
            Application.DoEvents();

            // Array size constants.
            const int xmin = 1001, num_x = 50, xmax = xmin + num_x - 1;
            const int ymin = 2001, num_y = 50, ymax = ymin + num_y - 1;
            const int zmin = 2001, num_z = 50, zmax = zmin + num_z - 1;

            // Use the Array class.
            Array array_class = Array.CreateInstance(
                typeof(int),
                new int[] { num_x, num_y, num_z },
                new int[] { xmin, ymin, zmin });
            start_time = DateTime.Now;
            for (int trial = 0; trial < num_trials; trial++)
            {
                for (int x = xmin; x <= xmax; x++)
                {
                    for (int y = ymin; y <= ymax; y++)
                    {
                        for (int z = zmin; z <= zmax; z++)
                        {
                            int value = x + y + z;
                            array_class.SetValue(value, x, y, z);
                            value = (int)array_class.GetValue(x, y, z);
                        }
                    }
                }
            }
            stop_time = DateTime.Now;
            elapsed = stop_time - start_time;
            lblArray.Text = elapsed.TotalSeconds.ToString("0.00") + " seconds";
            lblArray.Refresh();

            // Use the BoundsArray class.
            BoundsArray<int> bounds_array = 
                new BoundsArray<int>(xmin, xmax, ymin, ymax, zmin, zmax);
            start_time = DateTime.Now;
            for (int trial = 0; trial < num_trials; trial++)
            {
                for (int x = xmin; x <= xmax; x++)
                {
                    for (int y = ymin; y <= ymax; y++)
                    {
                        for (int z = zmin; z <= zmax; z++)
                        {
                            int value = x + y + z;
                            bounds_array[x, y, z] = value;
                            value = bounds_array[x, y, z];
                        }
                    }
                }
            }
            stop_time = DateTime.Now;
            elapsed = stop_time - start_time;
            lblBoundsArray.Text = elapsed.TotalSeconds.ToString("0.00") + " seconds";
            lblBoundsArray.Refresh();

            // Plain array.
            int[, ,] plain_array = new int[num_x, num_y, num_z];
            start_time = DateTime.Now;
            for (int trial = 0; trial < num_trials; trial++)
            {
                for (int x = 0; x < num_x; x++)
                {
                    for (int y = 0; y < num_y; y++)
                    {
                        for (int z = 0; z < num_z; z++)
                        {
                            int value = x + y + z;
                            plain_array[x, y, z] = value;
                            value = plain_array[x, y, z];
                        }
                    }
                }
            }
            stop_time = DateTime.Now;
            elapsed = stop_time - start_time;
            lblPlain.Text = elapsed.TotalSeconds.ToString("0.00") + " seconds";
            lblPlain.Refresh();

            this.Cursor = Cursors.Default;
        }
    }
}

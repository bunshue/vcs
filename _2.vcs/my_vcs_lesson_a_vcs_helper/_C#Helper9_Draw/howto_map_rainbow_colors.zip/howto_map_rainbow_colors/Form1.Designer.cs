﻿namespace howto_map_rainbow_colors
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtValue = new System.Windows.Forms.TextBox();
            this.picSample = new System.Windows.Forms.PictureBox();
            this.picRainbow = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.picSample)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picRainbow)).BeginInit();
            this.SuspendLayout();
            // 
            // txtValue
            // 
            this.txtValue.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txtValue.Location = new System.Drawing.Point(111, 99);
            this.txtValue.Name = "txtValue";
            this.txtValue.Size = new System.Drawing.Size(100, 20);
            this.txtValue.TabIndex = 5;
            this.txtValue.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtValue.TextChanged += new System.EventHandler(this.txtValue_TextChanged);
            // 
            // picSample
            // 
            this.picSample.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.picSample.Location = new System.Drawing.Point(111, 43);
            this.picSample.Name = "picSample";
            this.picSample.Size = new System.Drawing.Size(100, 50);
            this.picSample.TabIndex = 4;
            this.picSample.TabStop = false;
            this.picSample.Resize += new System.EventHandler(this.picSample_Resize);
            this.picSample.Paint += new System.Windows.Forms.PaintEventHandler(this.picSample_Paint);
            // 
            // picRainbow
            // 
            this.picRainbow.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.picRainbow.Location = new System.Drawing.Point(12, 12);
            this.picRainbow.Name = "picRainbow";
            this.picRainbow.Size = new System.Drawing.Size(299, 25);
            this.picRainbow.TabIndex = 3;
            this.picRainbow.TabStop = false;
            this.picRainbow.MouseMove += new System.Windows.Forms.MouseEventHandler(this.picRainbow_MouseMove);
            this.picRainbow.Resize += new System.EventHandler(this.picRainbow_Resize);
            this.picRainbow.Paint += new System.Windows.Forms.PaintEventHandler(this.picRainbow_Paint);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(323, 130);
            this.Controls.Add(this.txtValue);
            this.Controls.Add(this.picSample);
            this.Controls.Add(this.picRainbow);
            this.Name = "Form1";
            this.Text = "howto_map_rainbow_colors";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.picSample)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picRainbow)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtValue;
        private System.Windows.Forms.PictureBox picSample;
        private System.Windows.Forms.PictureBox picRainbow;
    }
}


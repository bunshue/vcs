﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_map_rainbow_colors
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // The currently selected color and its number.
        private Color SelectedColor;
        private float SelectedRainbowNumber;

        // Start with red selected.
        private void Form1_Load(object sender, EventArgs e)
        {
            SelectedColor = Color.Red;
            SelectedRainbowNumber = 0;
        }

        // Select this color.
        private void picRainbow_MouseMove(object sender, MouseEventArgs e)
        {
            MouseMoving = true;

            // Get the mouse position as a fraction
            // of the width of the PictureBox.
            float rainbow_color = e.X / (float)picRainbow.ClientSize.Width;

            // Convert into the corresponding color.
            SelectedColor = Rainbow.RainbowNumberToColor(rainbow_color);

            // Convert back into the corresponding number.
            SelectedRainbowNumber = Rainbow.ColorToRainbowNumber(SelectedColor);
            txtValue.Text = SelectedRainbowNumber.ToString("0.00");

            // Redraw.
            picRainbow.Refresh();
            picSample.Refresh();

            MouseMoving = false;
        }

        // Redraw the controls.
        private void picRainbow_Resize(object sender, EventArgs e)
        {
            picRainbow.Refresh();
        }
        private void picSample_Resize(object sender, EventArgs e)
        {
            picSample.Refresh();
        }

        // Draw the rainbow and the selected number.
        private void picRainbow_Paint(object sender, PaintEventArgs e)
        {
            // Draw the rainbow.
            using (Brush rainbow_brush = Rainbow.RainbowBrush(
                new Point(0, 0),
                new Point(picRainbow.ClientSize.Width, picRainbow.ClientSize.Height)))
            {
                e.Graphics.FillRectangle(rainbow_brush, picRainbow.ClientRectangle);
            }

            // Get and draw the selected location.
            int x = (int)(SelectedRainbowNumber * picRainbow.ClientSize.Width);
            Point[] pts =
            {
                new Point(x - 5, 0),
                new Point(x, 5),
                new Point(x + 5, 0)
            };
            e.Graphics.FillPolygon(Brushes.Black, pts);
        }

        // Draw the sample color.
        private void picSample_Paint(object sender, PaintEventArgs e)
        {
            picSample.BackColor = SelectedColor;
        }

        // True if we are updating the color already.
        private bool MouseMoving = false;
        private void txtValue_TextChanged(object sender, EventArgs e)
        {
            if (MouseMoving) return;

            // Try to get the value as a fraction between 0 and 1.
            try
            {
                // Get the value from the text box.
                SelectedRainbowNumber = float.Parse(txtValue.Text);

                // Convert into the corresponding color.
                SelectedColor = Rainbow.RainbowNumberToColor(SelectedRainbowNumber);

                // Redraw.
                picRainbow.Refresh();
                picSample.Refresh();
            }
            catch
            {
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Drawing.Text;
using System.Drawing.Drawing2D;

namespace howto_draw_smoothly
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Draw text, shapes, and pictures smoothly and not smoothly.
        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            using (Font the_font = new Font("Times New Roman", 16))
            {
                // Draw without smoothing.
                int x = 10, y = 10;
                e.Graphics.TextRenderingHint =
                    TextRenderingHint.SingleBitPerPixelGridFit;
                e.Graphics.DrawString("Without Smoothing",
                    the_font, Brushes.Blue, x, y);
                y += 25;
                e.Graphics.DrawImage(Properties.Resources.Smiley100x100,
                    x, y, 50, 50);
                y += 60;
                e.Graphics.DrawEllipse(Pens.Red, x, y, 100, 50);

                // Draw with smoothing.
                e.Graphics.SmoothingMode =
                    SmoothingMode.AntiAlias;
                e.Graphics.TextRenderingHint =
                    TextRenderingHint.AntiAliasGridFit;
                e.Graphics.InterpolationMode =
                    InterpolationMode.High;

                x = 200;
                y = 10;
                e.Graphics.DrawString("With Smoothing", the_font, Brushes.Blue, x, y);
                y += 25;
                e.Graphics.DrawImage(Properties.Resources.Smiley100x100,
                    x, y, 50, 50);
                y += 60;
                e.Graphics.DrawEllipse(Pens.Red, x, y, 100, 50);
            }
        }
    }
}

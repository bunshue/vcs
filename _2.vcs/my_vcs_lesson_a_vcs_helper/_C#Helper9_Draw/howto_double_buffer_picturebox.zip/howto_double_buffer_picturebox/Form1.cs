﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_double_buffer_picturebox
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private const int period = 24;
        private Color[] Colors;

        // Initialize the colors.
        private void Form1_Load(object sender, EventArgs e)
        {
            // Redraw when resized.
            this.ResizeRedraw = true;

            Colors = new Color[] 
            {
                Color.Pink,
                Color.Red,
                Color.Orange,
                Color.Yellow,
                Color.Lime,
                Color.Cyan,
                Color.Blue,
                Color.Violet,
                Color.Pink,
                Color.Red,
                Color.Orange,
                Color.Yellow,
                Color.Lime,
                Color.Cyan,
                Color.Blue,
                Color.Violet,
                Color.Pink,
                Color.Red,
                Color.Orange,
                Color.Yellow,
                Color.Lime,
                Color.Cyan,
                Color.Blue,
                Color.Violet
            };

            // Draw the initial curves.
            DrawCurves();
        }

        // Redraw the butterfly curve.
        private void btnRedraw_Click(object sender, EventArgs e)
        {
            DrawCurves();
        }

        // Draw butterfly curves on both PictureBoxes.
        private void DrawCurves()
        {
            // Clear both images.
            picCanvas1.Image = null;
            picCanvas2.Refresh();
            picCanvas1.Refresh();

            int wid = picCanvas2.ClientSize.Width;
            int hgt = picCanvas2.ClientSize.Height;

            // Draw with double-buffering.
            Bitmap bm = new Bitmap(wid, hgt);
            using (Graphics gr = Graphics.FromImage(bm))
            {
                DrawButterfly(gr, wid, hgt);
            }
            picCanvas1.Image = bm;
            picCanvas1.Refresh();

            // Draw without double-buffering.
            DrawButterfly(picCanvas2.CreateGraphics(), wid, hgt);
        }

        // Draw the butterfly curve on this Graphics object.
        private void DrawButterfly(Graphics gr, int wid, int hgt)
        {
            gr.SmoothingMode =
                System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            gr.Clear(Color.Black);

            // Scale and translate.
            RectangleF world_rect =
                new RectangleF(-4.0f, -4.4f, 8.0f, 7.3f);
            float cx = (world_rect.Left + world_rect.Right) / 2;
            float cy = (world_rect.Top + world_rect.Bottom) / 2;

            // Center the world coordinates at origin.
            gr.TranslateTransform(-cx, -cy);

            // Scale to fill the form.
            float scale = Math.Min(
                wid / world_rect.Width,
                hgt / world_rect.Height);
            gr.ScaleTransform(scale, scale,
                System.Drawing.Drawing2D.MatrixOrder.Append);

            // Move the result to center on the form.
            gr.TranslateTransform(
                wid / 2,
                hgt / 2,
                System.Drawing.Drawing2D.MatrixOrder.Append);

            // Generate the points.
            PointF pt0, pt1;
            double t = 0;
            double expr =
                Math.Exp(Math.Cos(t))
                - 2 * Math.Cos(4 * t)
                - Math.Pow(Math.Sin(t / 12), 5);
            pt1 = new PointF(
                (float)(Math.Sin(t) * expr),
                (float)(-Math.Cos(t) * expr));
            using (Pen the_pen = new Pen(Color.Blue, 0))
            {
                const long num_lines = 5000;
                for (long i = 0; i < num_lines; i++)
                {
                    t = i * period * Math.PI / num_lines;
                    expr =
                        Math.Exp(Math.Cos(t))
                        - 2 * Math.Cos(4 * t)
                        - Math.Pow(Math.Sin(t / 12), 5);
                    pt0 = pt1;
                    pt1 = new PointF(
                        (float)(Math.Sin(t) * expr),
                        (float)(-Math.Cos(t) * expr));
                    the_pen.Color = GetColor(t);
                    gr.DrawLine(the_pen, pt0, pt1);
                }
            }
        }

        // Redraw the non-buffered butterfly curve.
        private void picCanvas2_Paint(object sender, PaintEventArgs e)
        {
            DrawButterfly(e.Graphics,
                picCanvas2.ClientSize.Width,
                picCanvas2.ClientSize.Height);
        }

        // Return an appropriate color for this segment.
        private Color GetColor(double t)
        {
            return Colors[(int)(t / Math.PI)];
        }
    }
}

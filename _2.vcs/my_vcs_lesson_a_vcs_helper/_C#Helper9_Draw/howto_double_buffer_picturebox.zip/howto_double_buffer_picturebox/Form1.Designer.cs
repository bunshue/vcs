﻿namespace howto_double_buffer_picturebox
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.picCanvas2 = new System.Windows.Forms.PictureBox();
            this.btnRedraw = new System.Windows.Forms.Button();
            this.picCanvas1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.picCanvas2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCanvas1)).BeginInit();
            this.SuspendLayout();
            // 
            // picCanvas2
            // 
            this.picCanvas2.Location = new System.Drawing.Point(229, 41);
            this.picCanvas2.Name = "picCanvas2";
            this.picCanvas2.Size = new System.Drawing.Size(211, 211);
            this.picCanvas2.TabIndex = 0;
            this.picCanvas2.TabStop = false;
            this.picCanvas2.Paint += new System.Windows.Forms.PaintEventHandler(this.picCanvas2_Paint);
            // 
            // btnRedraw
            // 
            this.btnRedraw.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.btnRedraw.Location = new System.Drawing.Point(189, 12);
            this.btnRedraw.Name = "btnRedraw";
            this.btnRedraw.Size = new System.Drawing.Size(75, 23);
            this.btnRedraw.TabIndex = 1;
            this.btnRedraw.Text = "Redraw";
            this.btnRedraw.UseVisualStyleBackColor = true;
            this.btnRedraw.Click += new System.EventHandler(this.btnRedraw_Click);
            // 
            // picCanvas1
            // 
            this.picCanvas1.Location = new System.Drawing.Point(12, 41);
            this.picCanvas1.Name = "picCanvas1";
            this.picCanvas1.Size = new System.Drawing.Size(211, 211);
            this.picCanvas1.TabIndex = 2;
            this.picCanvas1.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(452, 264);
            this.Controls.Add(this.picCanvas1);
            this.Controls.Add(this.btnRedraw);
            this.Controls.Add(this.picCanvas2);
            this.Name = "Form1";
            this.Text = "howto_double_buffer_picturebox";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.picCanvas2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCanvas1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox picCanvas2;
        private System.Windows.Forms.Button btnRedraw;
        private System.Windows.Forms.PictureBox picCanvas1;
    }
}


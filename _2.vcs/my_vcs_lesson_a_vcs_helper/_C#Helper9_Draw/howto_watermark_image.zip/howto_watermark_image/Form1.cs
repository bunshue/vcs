﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Drawing.Imaging;

namespace howto_watermark_image
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Bitmap result_bm = new Bitmap(picImage.Image);

            using (Bitmap watermark_bm = new Bitmap(picWatermark.Image))
            {
                int x = (result_bm.Width - watermark_bm.Width) / 2;
                int y = (result_bm.Height - watermark_bm.Height) / 2;
                DrawWatermark(watermark_bm, result_bm, x, y);
            }

            picImage.Image = result_bm;
        }

        // Copy the watermark image over the result image.
        private void DrawWatermark(Bitmap watermark_bm, Bitmap result_bm, int x, int y)
        {
            const byte ALPHA = 128;
            // Set the watermark's pixels' Alpha components.
            Color clr;
            for (int py = 0; py < watermark_bm.Height; py++)
            {
                for (int px = 0; px < watermark_bm.Width; px++)
                {
                    clr = watermark_bm.GetPixel(px, py);
                    watermark_bm.SetPixel(px, py, Color.FromArgb(ALPHA, clr.R, clr.G, clr.B));
                }
            }

            // Set the watermark's transparent color.
            watermark_bm.MakeTransparent(watermark_bm.GetPixel(0, 0));

            // Copy onto the result image.
            using (Graphics gr = Graphics.FromImage(result_bm))
            {
                gr.DrawImage(watermark_bm, x, y);
            }
        }
    }
}

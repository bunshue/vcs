﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.IO;
using System.Drawing.Imaging;
using System.Drawing.Drawing2D;

namespace howto_primes_fractal2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Draw the fractal.
        private void btnDraw_Click(object sender, EventArgs e)
        {
            Cursor = Cursors.WaitCursor;
            Refresh();

            // Generate the points.
            int num_points = int.Parse(txtNumPoints.Text);
            Point[] points = new Point[num_points];
            Point current_point = new Point(0, 0);
            int prime = 7;
            for (long i = 0; i < num_points; i++)
            {
                // Find the next prime.
                while (!IsPrime(prime)) prime += 2;

                // Use this prime.
                switch (prime % 5)
                {
                    case 1:
                        current_point.Y--;
                        break;
                    case 2:
                        current_point.X++;
                        break;
                    case 3:
                        current_point.Y++;
                        break;
                    case 4:
                        current_point.X--;
                        break;
                }
                points[i] = current_point;

                // Move to the next possible prime.
                prime += 2;
            }

            // Draw the points.
            const int width = 500;
            Bitmap bm = new Bitmap(width, width);
            using (Graphics gr = Graphics.FromImage(bm))
            {
                gr.Clear(Color.Black);

                // Get the largest and smallest coordinates.
                var x_query =
                    from Point point in points
                    select point.X;
                int[] xs = x_query.ToArray();
                int xmin = xs.Min();
                int xmax = xs.Max();
                int wid = xmax - xmin;

                var y_query =
                    from Point point in points
                    select point.Y;
                int[] ys = y_query.ToArray();
                int ymin = ys.Min();
                int ymax = ys.Max();
                int hgt = ymax - ymin;

                float scale = width / Math.Max(wid, hgt);

                // Scale and translate.
                gr.TranslateTransform(-xmin, -ymin);
                gr.ScaleTransform(scale, scale, MatrixOrder.Append);

                using (Pen thin_pen = new Pen(Color.Red, 0))
                {
                    // Draw the lines.
                    gr.DrawLines(thin_pen, points);

                    // Draw the axes.
                    thin_pen.Color = Color.Blue;
                    gr.DrawLine(thin_pen, xmin, 0, xmax, 0);
                    gr.DrawLine(thin_pen, 0, ymin, 0, ymax);
                }
            }

            picFractal.Image = bm;
            picFractal.Visible = true;

            Cursor = Cursors.Default;
        }

        // Return true if the value is prime.
        // For speed, asssume value > 2 and value is odd.
        private bool IsPrime(long value)
        {
            long stop_at = (long)Math.Sqrt(value);
            for (long factor = 3; factor <= stop_at; factor += 2)
            {
                if (value % factor == 0) return false;
            }
            return true;
        }

        // Save the file.
        private void mnuFileSave_Click(object sender, EventArgs e)
        {
            if (sfdFractal.ShowDialog() == DialogResult.OK)
            {
                SaveImage(picFractal.Image, sfdFractal.FileName);
            }
        }

        // Save the file with the appropriate format.
        public void SaveImage(Image image, string filename)
        {
            string extension = Path.GetExtension(filename);
            switch (extension.ToLower())
            {
                case ".bmp":
                    image.Save(filename, ImageFormat.Bmp);
                    break;
                case ".exif":
                    image.Save(filename, ImageFormat.Exif);
                    break;
                case ".gif":
                    image.Save(filename, ImageFormat.Gif);
                    break;
                case ".jpg":
                case ".jpeg":
                    image.Save(filename, ImageFormat.Jpeg);
                    break;
                case ".png":
                    image.Save(filename, ImageFormat.Png);
                    break;
                case ".tif":
                case ".tiff":
                    image.Save(filename, ImageFormat.Tiff);
                    break;
                default:
                    throw new NotSupportedException(
                        "Unknown file extension " + extension);
            }
        }
    }
}

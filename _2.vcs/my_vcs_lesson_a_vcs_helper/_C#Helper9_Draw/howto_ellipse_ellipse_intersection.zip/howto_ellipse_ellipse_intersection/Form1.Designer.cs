﻿namespace howto_ellipse_ellipse_intersection
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.lstParameters1 = new System.Windows.Forms.ListBox();
            this.lstParameters2 = new System.Windows.Forms.ListBox();
            this.picCanvas = new System.Windows.Forms.PictureBox();
            this.picEquation = new System.Windows.Forms.PictureBox();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picCanvas)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picEquation)).BeginInit();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.lstParameters1, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.lstParameters2, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.picCanvas, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.picEquation, 0, 2);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(12, 12);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 3;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 90F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(337, 402);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // lstParameters1
            // 
            this.lstParameters1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lstParameters1.FormattingEnabled = true;
            this.lstParameters1.Items.AddRange(new object[] {
            "A =",
            "B =",
            "C =",
            "D =",
            "E =",
            "F ="});
            this.lstParameters1.Location = new System.Drawing.Point(3, 159);
            this.lstParameters1.Name = "lstParameters1";
            this.lstParameters1.Size = new System.Drawing.Size(162, 82);
            this.lstParameters1.TabIndex = 0;
            // 
            // lstParameters2
            // 
            this.lstParameters2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lstParameters2.FormattingEnabled = true;
            this.lstParameters2.Items.AddRange(new object[] {
            "A =",
            "B =",
            "C =",
            "D =",
            "E =",
            "F ="});
            this.lstParameters2.Location = new System.Drawing.Point(171, 159);
            this.lstParameters2.Name = "lstParameters2";
            this.lstParameters2.Size = new System.Drawing.Size(163, 82);
            this.lstParameters2.TabIndex = 1;
            // 
            // picCanvas
            // 
            this.picCanvas.BackColor = System.Drawing.Color.White;
            this.picCanvas.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.tableLayoutPanel1.SetColumnSpan(this.picCanvas, 2);
            this.picCanvas.Dock = System.Windows.Forms.DockStyle.Fill;
            this.picCanvas.Location = new System.Drawing.Point(3, 3);
            this.picCanvas.Name = "picCanvas";
            this.picCanvas.Size = new System.Drawing.Size(331, 150);
            this.picCanvas.TabIndex = 2;
            this.picCanvas.TabStop = false;
            this.picCanvas.MouseMove += new System.Windows.Forms.MouseEventHandler(this.picCanvas_MouseMove);
            this.picCanvas.Resize += new System.EventHandler(this.picCanvas_Resize);
            this.picCanvas.MouseDown += new System.Windows.Forms.MouseEventHandler(this.picCanvas_MouseDown);
            this.picCanvas.Paint += new System.Windows.Forms.PaintEventHandler(this.picCanvas_Paint);
            this.picCanvas.MouseUp += new System.Windows.Forms.MouseEventHandler(this.picCanvas_MouseUp);
            // 
            // picEquation
            // 
            this.picEquation.BackColor = System.Drawing.SystemColors.Control;
            this.picEquation.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.tableLayoutPanel1.SetColumnSpan(this.picEquation, 2);
            this.picEquation.Dock = System.Windows.Forms.DockStyle.Fill;
            this.picEquation.Location = new System.Drawing.Point(3, 249);
            this.picEquation.Name = "picEquation";
            this.picEquation.Size = new System.Drawing.Size(331, 150);
            this.picEquation.TabIndex = 3;
            this.picEquation.TabStop = false;
            this.picEquation.Resize += new System.EventHandler(this.picEquation_Resize);
            this.picEquation.MouseClick += new System.Windows.Forms.MouseEventHandler(this.picEquation_MouseClick);
            this.picEquation.Paint += new System.Windows.Forms.PaintEventHandler(this.picEquation_Paint);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(361, 426);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "Form1";
            this.Text = "howto_ellipse_ellipse_intersection";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.picCanvas)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picEquation)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.ListBox lstParameters2;
        private System.Windows.Forms.ListBox lstParameters1;
        private System.Windows.Forms.PictureBox picCanvas;
        private System.Windows.Forms.PictureBox picEquation;
    }
}


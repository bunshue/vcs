﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Drawing.Drawing2D;

namespace howto_polygon_pathgradientbrush
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Redraw on resize.
        private void Form1_Load(object sender, EventArgs e)
        {
            this.ResizeRedraw = true;
        }

        // Fill a polygon with a PathGradientBrush.
        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            // Make the points for a hexagon.
            PointF[] pts = new PointF[6];
            int cx = (int)(this.ClientSize.Width / 2);
            int cy = (int)(this.ClientSize.Height / 2);
            double theta = 0;
            double dtheta = 2 * Math.PI / 6;
            for (int i = 0; i < pts.Length; i++)
            {
                pts[i].X = (int)(cx + cx * Math.Cos(theta));
                pts[i].Y = (int)(cy + cy * Math.Sin(theta));
                theta += dtheta;
            }

            // Make a path gradient brush.
            using (PathGradientBrush path_brush = new PathGradientBrush(pts))
            {
                // Define the center and surround colors.
                path_brush.CenterColor = Color.White;
                path_brush.SurroundColors = new Color[] {
                    Color.Red, Color.Yellow, Color.Lime,
                    Color.Cyan, Color.Blue, Color.Magenta
                };
                    
                // Fill the hexagon.
                e.Graphics.FillPolygon(path_brush, pts);
            }


            // Outline the hexagon.
            e.Graphics.DrawPolygon(Pens.Black, pts);
        }
    }
}

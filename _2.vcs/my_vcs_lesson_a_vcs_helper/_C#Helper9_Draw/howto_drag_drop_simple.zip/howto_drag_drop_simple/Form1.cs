﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_drag_drop_simple
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Start a drag that copies text.
        private void lblDragSource_MouseDown(object sender, MouseEventArgs e)
        {
            // Start the drag if it's the right mouse button.
            if (e.Button == MouseButtons.Right)
            {
                lblDragSource.DoDragDrop("Here's some text!", DragDropEffects.Copy);
            }
        }

        // Indicate that we can accept a copy of text.
        private void lblDropTarget_DragEnter(object sender, DragEventArgs e)
        {
            // See if this is a copy and the data includes text.
            if (e.Data.GetDataPresent(DataFormats.Text) &&
                (e.AllowedEffect & DragDropEffects.Copy) != 0)
            {
                // Allow this.
                e.Effect = DragDropEffects.Copy;
            }
            else
            {
                // Don't allow any other drop.
                e.Effect = DragDropEffects.None;
            }
        }

        // Accept the drop.
        private void lblDropTarget_DragDrop(object sender, DragEventArgs e)
        {
            lblDropTarget.Text = (string)e.Data.GetData(DataFormats.Text);
        }
    }
}

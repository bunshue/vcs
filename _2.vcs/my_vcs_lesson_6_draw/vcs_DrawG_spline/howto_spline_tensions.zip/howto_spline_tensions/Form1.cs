﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Drawing.Drawing2D;

namespace howto_spline_tensions
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // The points selected by the user.
        private List<Point> Points = new List<Point>();

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;

            // Draw the points.
            foreach (Point point in Points)
                e.Graphics.FillEllipse(Brushes.Black,
                    point.X - 3, point.Y - 3, 5, 5);
            if (Points.Count < 2) return;

            // Draw the curve.
            using (Pen pen = new Pen(Color.Red))
            {
                for (int t = 0; t <= 20; t += 2)
                {
                    pen.Color = Color.FromArgb(255 * t / 20, 0, 255 - 255 * t / 20);
                    e.Graphics.DrawCurve(pen, Points.ToArray(), t / 10f);
                }
            }
        }

        // Select a point.
        private void Form1_MouseClick(object sender, MouseEventArgs e)
        {
            Points.Add(e.Location);
            Refresh();
        }

        // Start a new point list.
        private void mnuSplineNew_Click(object sender, EventArgs e)
        {
            Points = new List<Point>();
            Refresh();
        }
    }
}

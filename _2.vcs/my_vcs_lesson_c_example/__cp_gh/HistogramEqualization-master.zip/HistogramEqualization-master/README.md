# HistogramEqualization
A quick and dirty application to visual common histogram equalization image stretches

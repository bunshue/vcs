﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        Graphics g;
        Pen pen;
        Font font;
        Brush brush;

        public Form1()
        {
            InitializeComponent();

            g = this.CreateGraphics();
            pen = new Pen(Color.Black, 3);
            font = new Font("標楷體", 16);
            brush = new SolidBrush(Color.Black);
        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            g.DrawLine(pen, new Point(1, 1), new Point(300, 100));
            g.DrawLine(pen, new Point(100, 1), new Point(300, 100));
            g.DrawRectangle(pen, new Rectangle(50, 50, 100, 100));
             
            g.DrawString("Hello! 你好！", font, brush, new PointF(150.0F, 150.0F));


            Image image = Image.FromFile("../../ccc.jpg");
            g.DrawImage(image, new Point(200, 200));
        }
    }
}

﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// 有關程序集的常規訊息透過下列屬性集
// 控制。修改這些屬性值可修改
// 與程序集相關的訊息。
[assembly: AssemblyTitle("獲得硬盤序列號")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("獲得硬盤序列號")]
[assembly: AssemblyCopyright("Copyright c  2009")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// 將 ComVisible 設定為 false 使此程序集中的類型
// 對 COM 組件不可見。如果需要從 COM 存取此程序集中的類型，
// 則將該類型上的 ComVisible 屬性設定為 true。
[assembly: ComVisible(false)]

// 如果此項目向 COM 公開，則下列 GUID 用於類型庫的 ID
[assembly: Guid("0f81a174-7730-45c2-a40b-9302b37fbe8a")]

// 程序集的版本訊息由下面四個值組成:
//
//      主版本
//      次版本 
//      內部版本號
//      修訂號
//
// 可以指定所有這些值，也可以使用「內部版本號」和「修訂號」的預設值，
// 方法是按如下所示使用「*」:
// [assembly: AssemblyVersion("1.0.*")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]

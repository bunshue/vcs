﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            thread1 obj = new thread1("花旗銀行");
            Thread t = new Thread(obj.runMe);
            t.Start();
        }
    }
}

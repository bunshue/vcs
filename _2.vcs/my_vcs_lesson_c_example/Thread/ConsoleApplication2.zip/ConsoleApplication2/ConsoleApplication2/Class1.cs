﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class thread1
    {
        private String title;
        public thread1(String title)
        {
            this.title = title;
        }
        public void runMe()
        {
            while(true)
            {
                Console.Write(title+"\r\n");
                System.Threading.Thread.Sleep(1000);
            }
        }
    }
}

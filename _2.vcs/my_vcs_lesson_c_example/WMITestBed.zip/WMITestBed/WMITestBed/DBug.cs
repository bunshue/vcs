using System;
using System.Collections.Generic;
using System.Text;

namespace Utilities.Debug
{
    class DBug
    {
        //declaring the event handler delegate
        public delegate void DebugEventHandler(object source, string debugMessage);

        //declaring the event
        public static event DebugEventHandler debugMessageEvent;

        public static void print(string message)
        {
            if (debugMessageEvent != null) debugMessageEvent(null, DateTime.Now.Hour.ToString().PadLeft(2, '0') + ":" +
                                                                    DateTime.Now.Minute.ToString().PadLeft(2, '0') + ":" +
                                                                    DateTime.Now.Second.ToString().PadLeft(2, '0') + ":" +
                                                                    " |   " + message);
        }

        public static void message(string message)
        {
            if (debugMessageEvent != null) debugMessageEvent(null, message);
        }

        public static void WriteLine(string message)
        {
            if (debugMessageEvent != null) debugMessageEvent(null, message);
        }
    }
}

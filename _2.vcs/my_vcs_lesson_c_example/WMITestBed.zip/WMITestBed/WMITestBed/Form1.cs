using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

using System.Management;    //used to perform WMI queries

//useful tool to find WMI properties and generate code (WMI Code Creator v1.0) 
//http://www.microsoft.com/downloads/details.aspx?familyid=2CC30A64-EA15-4661-8DA4-55BBC145C30E&displaylang=en

using Utilities.Debug;      //used to print my debug messages from any class to this form

namespace WMITestBed
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            DBug.debugMessageEvent += new DBug.DebugEventHandler(DBug_debugMessageEvent);
        }

        void DBug_debugMessageEvent(object source, string debugMessage)
        {
            if (InvokeRequired)
            {
                try
                {
                    Invoke(new DBug.DebugEventHandler(DBug_debugMessageEvent), new object[] { source, debugMessage });
                }
                catch (ObjectDisposedException eventDispatcherClosed)
                {
                    Console.WriteLine("There's no object associated with the DBug event any more: " + eventDispatcherClosed.Message);
                    DBug.debugMessageEvent -= new DBug.DebugEventHandler(DBug_debugMessageEvent);
                }
            }
            else
            {
                //debugList.Items.Insert(0, debugMessage);
                debugList.Items.Add(debugMessage);
            }
        }

        private void demoOneBtn_Click(object sender, EventArgs args)
        {
            //Below is code pasted from WMICodeCreator
            try
            {
                ManagementObjectSearcher searcher =
                    new ManagementObjectSearcher("root\\WMI",
                    "SELECT * FROM MSSerial_PortName");

                foreach (ManagementObject queryObj in searcher.Get())
                {
                    Console.WriteLine("-----------------------------------");
                    Console.WriteLine("MSSerial_PortName instance");
                    Console.WriteLine("-----------------------------------");
                    Console.WriteLine("InstanceName: {0}", queryObj["InstanceName"]);

                    Console.WriteLine("-----------------------------------");
                    Console.WriteLine("MSSerial_PortName instance");
                    Console.WriteLine("-----------------------------------");
                    Console.WriteLine("PortName: {0}", queryObj["PortName"]);


                    //If the serial port's instance name contains USB it must be a USB to serial device
                    if (queryObj["InstanceName"].ToString().Contains("USB"))
                    {
                        Console.WriteLine(queryObj["PortName"] + " is a USB to SERIAL adapter/converter");
                    }
                }
            }
            catch (ManagementException e)
            {
                MessageBox.Show("An error occurred while querying for WMI data: " + e.Message);
            }
        }

    }


    /// <summary>
    /// Just to override the Console class which means easy copy paste from WMICodeCreator
    /// -ignore this class its nothing important just means DBug will output all Console.WriteLine()
    /// </summary>
    internal class Console
    {
        public static void WriteLine(string message)
        {
            DBug.print(message);
        }

        public static void WriteLine(string message, object info)
        {
            DBug.print(String.Format(message, info));
        }
    }
}
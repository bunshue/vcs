namespace WMITestBed
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.demoOneBtn = new System.Windows.Forms.Button();
            this.debugList = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // demoOneBtn
            // 
            this.demoOneBtn.Location = new System.Drawing.Point(12, 12);
            this.demoOneBtn.Name = "demoOneBtn";
            this.demoOneBtn.Size = new System.Drawing.Size(534, 23);
            this.demoOneBtn.TabIndex = 0;
            this.demoOneBtn.Text = "Find USB-Serial converters using WMI";
            this.demoOneBtn.UseVisualStyleBackColor = true;
            this.demoOneBtn.Click += new System.EventHandler(this.demoOneBtn_Click);
            // 
            // debugList
            // 
            this.debugList.FormattingEnabled = true;
            this.debugList.Location = new System.Drawing.Point(12, 48);
            this.debugList.Name = "debugList";
            this.debugList.Size = new System.Drawing.Size(534, 342);
            this.debugList.TabIndex = 1;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(558, 408);
            this.Controls.Add(this.debugList);
            this.Controls.Add(this.demoOneBtn);
            this.Name = "Form1";
            this.Text = "WMI Test";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button demoOneBtn;
        private System.Windows.Forms.ListBox debugList;
    }
}


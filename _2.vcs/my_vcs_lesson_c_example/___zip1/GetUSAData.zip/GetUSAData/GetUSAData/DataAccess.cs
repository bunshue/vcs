﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.Common;
using System.ComponentModel;
using System.Configuration;
using System.Collections;
using System.Diagnostics;

namespace GetUSAData
{
    public partial class DataAccess
    {
        /// <summary>
        /// 数据类型枚举
        /// </summary>
        public enum ThsDBType { SQL, Oracle, Ole };
        /// <summary>
        /// 
        /// </summary>
        public ThsDBType _ThsDBtype = ThsDBType.SQL;
        /// <summary>
        /// Webconfig配置连接字符串

        /// </summary>
        private string _confirString = "ConnectionString";
        /// <summary>
        /// 连接字符串

        /// </summary>
        private string _ConnectionString = "";

        private string _ProviderName = "System.Data.SqlClient";
        #region 构造

        public DataAccess()
        {
            _ProviderName = GetProviderName();
            _ConnectionString = GetConnectionString();
            SetDBType();
        }

        private void SetDBType()
        {
            if (_ProviderName == "System.Data.SqlClient")
            {
                TDBType = ThsDBType.SQL;
            }
            else if (_ProviderName == "System.Data.OleDb")
            {
                TDBType = ThsDBType.Ole;
            }
            else
            {
                TDBType = ThsDBType.Oracle;
            }
        }
        private string ProviderName
        {
            get
            {
                if (_ProviderName == "")
                {
                    _ProviderName = GetProviderName();
                    _ConnectionString = GetConnectionString();
                }
                return _ProviderName;
            }
        }
        /// <summary>
        /// 数据工厂类
        /// </summary>
        /// <param name="configString">web.config 关键字</param>
        public DataAccess(string configString)
        {
            _confirString = configString;
            _ProviderName = ConfigurationManager.ConnectionStrings[configString].ProviderName.ToString();
            _ConnectionString = ConfigurationManager.ConnectionStrings[configString].ToString();
            SetDBType();
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="connectionString">连接字符串</param>
        /// <param name="_thsDbType">数据库类型</param>
        public DataAccess(string connectionString, ThsDBType _thsDbType)
        {
            _ConnectionString = connectionString;
            _ConnectionString = connectionString;
            if (_thsDbType.ToString().ToLower() == "oracle")
            {
                _ProviderName = "System.Data.OracleClient";
            }

            if (_thsDbType.ToString().ToLower() == "sql")
            {
                _ProviderName = "System.Data.SqlClient";
            }
        }
        #endregion
        [Bindable(true),
        Category("自定义属性"),
        Description("confing中配置字符串")]
        public string ConfigString
        {
            get
            {
                if (_confirString != "")
                {
                    _ProviderName = GetProviderName();
                    _ConnectionString = GetConnectionString();
                }
                return _confirString;
            }
            set
            {
                _confirString = value;
                _ProviderName = GetProviderName();
                _ConnectionString = GetConnectionString();
            }
        }

        [Bindable(true),
        Category("自定义属性"),
        Description("连接字符串")]
        public string ConnectionString
        {
            get
            {
                return _ConnectionString;
            }
            set
            {
                _ConnectionString = value;
            }
        }
        [Bindable(true),
        Category("自定义属性"),
        Description("连接数据库类型")]
        public ThsDBType TDBType
        {
            get
            {
                return _ThsDBtype;
            }
            set
            {
                _ThsDBtype = value;
                if (_ThsDBtype == ThsDBType.SQL)
                {
                    _ProviderName = "System.Data.SqlClient";
                }
                else if (_ThsDBtype == ThsDBType.Ole)
                {
                    _ProviderName = "System.Data.OleDb";
                }
                else if (_ThsDBtype == ThsDBType.Oracle)
                {
                    _ProviderName = "System.Data.OracleClient";
                }
            }
        }

        #region private string GetProviderName()
        /// <summary>
        /// 返回数据提供者

        /// </summary>
        /// <returns>返回数据提供者</returns>
        private string GetProviderName()
        {

            ConnectionStringSettingsCollection ConfigStringCollention = ConfigurationManager.ConnectionStrings;
            if (ConfigStringCollention == null || ConfigStringCollention.Count <= 0)
            {
                throw new Exception("web.config 中无连接字符串!");
            }
            ConnectionStringSettings StringSettings = null;
            if (_confirString == string.Empty)
            {
                StringSettings = ConfigurationManager.ConnectionStrings["ConnectionString"];
            }
            else
            {
                StringSettings = ConfigurationManager.ConnectionStrings[_confirString];
            }
            return StringSettings.ProviderName;
        }
        #endregion

        #region private string GetConnectionString()
        /// <summary>
        /// 获得连接字符串

        /// </summary>
        /// <returns></returns>
        private string GetConnectionString()
        {
            ConnectionStringSettingsCollection ConfigStringCollention = ConfigurationManager.ConnectionStrings;
            if (ConfigStringCollention == null || ConfigStringCollention.Count <= 0)
            {
                throw new Exception("web.config 中无连接字符串!");
            }
            ConnectionStringSettings StringSettings = null;
            if (_confirString == string.Empty)
            {
                StringSettings = ConfigurationManager.ConnectionStrings["ConnectionString"];
            }
            else
            {
                StringSettings = ConfigurationManager.ConnectionStrings[_confirString];
            }
            return StringSettings.ConnectionString;
        }
        #endregion

        //==============================================GetDbproviderFactory=========================

        #region 返回数据工厂  public DbProviderFactory GetDbProviderFactory()
        /// <summary>
        /// 返回数据工厂
        /// </summary>
        /// <returns></returns>
        public DbProviderFactory GetDbProviderFactory()
        {
            return DbProviderFactories.GetFactory(ProviderName);
        }
        #endregion

        //==============================================CreateConnection=============================

        #region 创建数据库连接 public DbConnection CreateConnection()
        /// <summary>
        /// 创建数据库连接

        /// </summary>
        /// <returns></returns>
        public DbConnection CreateConnection()
        {
            DbConnection con = GetDbProviderFactory().CreateConnection();
            con.ConnectionString = ConnectionString;
            return con;

        }
        #endregion

        //==============================================CreateCommand================================

        #region public DbCommand CreateCommand(string sql, CommandType cmdType, DbParameter[] parameters)
        /// <summary>
        /// 创建执行命令对象
        /// </summary>
        /// <param name="sql"></param>
        /// <param name="cmdType"></param>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public DbCommand CreateCommand(string sql, CommandType cmdType, params DbParameter[] parameters)
        {
            DbCommand _command = GetDbProviderFactory().CreateCommand();
            _command.Connection = CreateConnection();
            _command.CommandText = sql;
            _command.CommandType = cmdType;
            _command.CommandTimeout = 200;
            if (parameters != null && parameters.Length > 0)
            {
                try
                {
                    foreach (DbParameter param in parameters)
                    {
                        DbParameter p = param;
                        if (p.Value == null || p.Value.ToString() == "")
                        {
                            p.Value = DBNull.Value;
                        }
                        _command.Parameters.Add(p);
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(sql);
                    Console.WriteLine(ex.Message);
                    throw;
                }
            }
            return _command;
        }
        #endregion

        #region public DbCommand CreateCommand(string sql)
        /// <summary>
        /// 创建执行命令对象
        /// </summary>
        /// <param name="sql">SQL语句</param>
        /// <returns>执行命令对象实例</returns>
        public DbCommand CreateCommand(string sql)
        {
            DbParameter[] parameters = new DbParameter[0];
            return CreateCommand(sql, CommandType.Text, parameters);
        }
        #endregion

        #region public DbCommand CreateCommand(string sql, CommandType cmdtype)
        /// <summary>
        /// 创建执行命令对象
        /// </summary>
        /// <param name="sql">SQL语句</param>
        /// <returns>执行命令对象实例</returns>
        public DbCommand CreateCommand(string sql, CommandType cmdtype)
        {
            DbParameter[] parameters = new DbParameter[0];
            return CreateCommand(sql, cmdtype, parameters);
        }
        #endregion

        #region public DbCommand CreateCommand(string sql, DbParameter[] parameters)
        /// <summary>
        /// 创建执行命令对象
        /// </summary>
        /// <param name="sql">ＳＱＬ语句</param>
        /// <param name="parameters">参数</param>
        /// <returns>执行命令对象实例</returns>
        public DbCommand CreateCommand(string sql, params DbParameter[] parameters)
        {
            return CreateCommand(sql, CommandType.Text, parameters);
        }
        #endregion

        //=========================================CreateAdapter()==============================================

        #region         public DbDataAdapter CreateAdapter(string sql)
        /// <summary>
        /// 创建数据适配器

        /// </summary>
        /// <param name="sql">SQL,语句</param>
        /// <returns>数据适配器实例</returns>
        public DbDataAdapter CreateAdapter(string sql)
        {
            DbParameter[] parameters = new DbParameter[0];
            return CreateAdapter(sql, CommandType.Text, parameters);
        }
        #endregion

        #region public DbDataAdapter CreateAdapter(string sql, CommandType cmdtype)
        /// <summary>
        /// 创建数据适配器

        /// </summary>
        /// <param name="sql">SQL语句</param>
        /// <param name="cmdtype">命令类型</param>
        /// <returns>数据适配器实例</returns>
        public DbDataAdapter CreateAdapter(string sql, CommandType cmdtype)
        {
            DbParameter[] parameters = new DbParameter[0];
            return CreateAdapter(sql, cmdtype, parameters);
        }
        #endregion

        #region         public DbDataAdapter CreateAdapter(string sql, CommandType cmdtype, DbParameter[] parameters)
        /// <summary>
        /// 创建数据适配器
        public DbParameter[] CloneParemeters(DbParameter[] sp)
        {
            DbParameter[] clonedParameters = new DbParameter[sp.Length];
            for (int i = 0, j = sp.Length; i < j; i++)
            {
                clonedParameters[i] = (DbParameter)((ICloneable)sp[i]).Clone();
            }
            return clonedParameters;
        }
        /// </summary>
        /// <param name="connectionString">数据库连接字符串</param>
        /// <param name="sql">SQL语句</param>
        /// <param name="cmdtype">命令类型</param>
        /// <param name="parameters">参数</param>
        /// <returns>数据适配器实例</returns>
        public DbDataAdapter CreateAdapter(string sql, CommandType cmdtype, params DbParameter[] _parameters)
        {
            DbParameter[] parameters = CloneParemeters(_parameters);
            DbConnection _connection = CreateConnection();
            DbCommand _command = GetDbProviderFactory().CreateCommand();
            _command.Connection = _connection;
            _command.CommandText = sql;
            _command.CommandType = cmdtype;
            if (parameters != null && parameters.Length > 0)
            {
                foreach (DbParameter _param in parameters)
                {
                    _command.Parameters.Add(_param);
                }
            }
            DbDataAdapter da = GetDbProviderFactory().CreateDataAdapter();
            da.SelectCommand = _command;

            return da;
        }
        #endregion

        //=========================================CreateParameter===================================

        #region public override SqlParameter CreateParameter(string field, string dbtype, string value)
        /// <summary>
        /// 创建参数
        /// </summary>
        /// <param name="field">参数字段</param>
        /// <param name="dbtype">参数类型</param>
        /// <param name="value">参数值</param>
        /// <returns></returns>
        public DbParameter CreateParameter(string field, string dbtype, string value)
        {
            DbParameter p = GetDbProviderFactory().CreateParameter();
            p.ParameterName = field;
            p.Value = value;
            return p;
        }
        /// <summary>
        /// 创建参数
        /// </summary>
        /// <param name="field">参数字段</param>
        /// <param name="dbtype">参数类型</param>
        /// <param name="value">参数值</param>
        /// <returns></returns>
        public DbParameter CreateParameter(string field, string value)
        {
            DbParameter p = GetDbProviderFactory().CreateParameter();
            p.ParameterName = field;
            p.Value = value;
            return p;
        }
        #endregion

        //======================================================ExecuteCommand()============================================

        #region public int ExecuteCommand(string sql)
        /// <summary>
        /// 执行非查询语句,并返回受影响的记录行数

        /// </summary>
        /// <param name="sql">SQL语句</param>
        /// <returns>受影响记录行数</returns>
        public int ExecuteCommand(string sql)
        {
            DbParameter[] parameters = new DbParameter[0];
            return ExecuteCommand(sql, CommandType.Text, parameters);
        }
        #endregion

        #region public int ExecuteCommand(string sql, CommandType cmdtype)
        /// <summary>
        /// 执行非查询语句,并返回受影响的记录行数

        /// </summary>
        /// <param name="sql">SQL语句</param>
        /// <param name="cmdtype">命令类型</param>
        /// <returns>受影响记录行数</returns>
        public int ExecuteCommand(string sql, CommandType cmdtype)
        {
            DbParameter[] parameters = new DbParameter[0];
            return ExecuteCommand(sql, CommandType.Text, parameters);
        }
        #endregion

        #region public int ExecuteCommand(string sql, DbParameter[] parameters)
        /// <summary>
        /// 执行非查询语句,并返回受影响的记录行数

        /// </summary>
        /// <param name="sql">SQL语句</param>
        /// <param name="parameters">参数</param>
        /// <returns>受影响记录行数</returns>
        public int ExecuteCommand(string sql, params DbParameter[] parameters)
        {
            return ExecuteCommand(sql, CommandType.Text, parameters);
        }
        #endregion

        public int ExecuteSql(string sql, DbParameter[] parameters)
        {
            return ExecuteCommand(sql, parameters);
        }

        #region public bool ExecuteCommand(ArrayList SqlList)
        /// <summary>
        ///批量执行SQL语句 
        /// </summary>
        /// <param name="SqlList">SQL列表</param>
        /// <returns></returns>
        public bool ExecuteCommand(ArrayList SqlList)
        {
            DbConnection con = CreateConnection();
            con.Open();
            bool iserror = false;
            string strerror = "";
            DbTransaction SqlTran = con.BeginTransaction();
            try
            {
                for (int i = 0; i < SqlList.Count; i++)
                {

                    DbCommand _command = GetDbProviderFactory().CreateCommand();
                    _command.Connection = con;
                    _command.CommandText = SqlList[i].ToString();
                    _command.Transaction = SqlTran;
                    _command.ExecuteNonQuery();
                    _command.Dispose();
                }

            }
            catch (Exception ex)
            {
                iserror = true;
                strerror = ex.Message;

            }
            finally
            {

                if (iserror)
                {
                    SqlTran.Rollback();
                    throw new Exception(strerror);
                }
                else
                {
                    SqlTran.Commit();
                }
                con.Close();
            }
            if (iserror)
            {
                return false;
            }
            else
            {
                return true;
            }
        }

        public int ExecuteCommand(ArrayList SqlList, List<System.Data.Common.DbParameter[]> paramlist)
        {
            DbConnection con = CreateConnection();
            con.Open();
            bool iserror = false;
            string strerror = "";
            int count = 0;
            DbTransaction SqlTran = con.BeginTransaction();
            string s = "";
            try
            {
                for (int i = 0; i < SqlList.Count; i++)
                {
                    DbCommand _command = GetDbProviderFactory().CreateCommand();
                    _command.Connection = con;
                    _command.CommandText = SqlList[i].ToString();
                    s = SqlList[i].ToString();
                    for (int n = 0; n < paramlist[i].Length; n++)
                    {
                        DbParameter p = paramlist[i][n];
                        if (p.Value == null || p.Value == "")
                        {
                            p.Value = DBNull.Value;
                        }
                        _command.Parameters.Add(p);
                    }
                    _command.Transaction = SqlTran;
                    count += _command.ExecuteNonQuery();
                    _command.Dispose();
                }

            }
            catch (Exception ex)
            {
                iserror = true;
                strerror = ex.Message;
                count = 0;
            }
            finally
            {

                if (iserror)
                {
                    SqlTran.Rollback();
                    throw new Exception(strerror);
                }
                else
                {
                    SqlTran.Commit();
                }
                con.Close();
            }
            return count;
        }

        #endregion

        #region public int ExecuteCommand(string sql, CommandType cmdtype, DbParameter[] parameters)
        /// <summary>
        /// 执行非查询语句,并返回受影响的记录行数

        /// </summary>
        /// <param name="sql">SQL语句</param>
        /// <param name="cmdtype">命令类型</param>
        /// <param name="parameters">参数</param>
        /// <returns>受影响记录行数</returns>
        public int ExecuteCommand(string sql, CommandType cmdtype, params DbParameter[] parameters)
        {
            int _result = 0;
            DbCommand _command = CreateCommand(sql, cmdtype, parameters);
            try
            {
                _command.Connection.Open();
                _result = _command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                _command.Connection.Close();
            }
            return _result;
        }
        #endregion

        /*-----------------------------------------------------ExecuteScalar------------------------------*/

        #region         public object ExecuteScalar(string sql)
        /// <summary>
        /// 执行非查询语句,并返回首行首列的值

        /// </summary>
        /// <param name="sql">SQL语句</param>
        /// <returns>Object</returns>
        public object ExecuteScalar(string sql)
        {
            DbParameter[] parameters = new DbParameter[0];
            return ExecuteScalar(sql, CommandType.Text, parameters);
        }
        #endregion

        public bool Exists(string sql, DbParameter[] parameters)
        {
            DataTable dt = GetDataTable(sql, parameters);
            if (dt.Rows.Count <= 0)
            {
                return false;
            }
            else
            {
                object obj = dt.Rows[0][0];
                if (obj == null || obj.ToString() == "0" || obj.ToString() == "False")
                {
                    return false;
                }
            }
            return true;
        }

        #region public object ExecuteScalar(string sql, CommandType cmdtype)
        /// <summary>
        /// 执行非查询语句,并返回首行首列的值

        /// </summary>
        /// <param name="sql">SQL语句</param>
        /// <param name="cmdtype">命令类型</param>
        /// <returns>Object</returns>
        public object ExecuteScalar(string sql, CommandType cmdtype)
        {
            DbParameter[] parameters = new DbParameter[0];
            return ExecuteScalar(sql, CommandType.Text, parameters);
        }
        #endregion

        #region public object ExecuteScalar(string sql, DbParameter[] parameters)
        /// <summary>
        /// 执行非查询语句,并返回首行首列的值

        /// </summary>
        /// <param name="sql">SQL语句</param>
        /// <param name="parameters">参数</param>
        /// <returns>Object</returns>
        public object ExecuteScalar(string sql, params DbParameter[] parameters)
        {
            return ExecuteScalar(sql, CommandType.Text, parameters);
        }
        #endregion

        #region public object ExecuteScalar(string sql, CommandType cmdtype, DbParameter[] parameters)
        /// <summary>
        /// 执行非查询语句,并返回首行首列的值

        /// </summary>
        /// <param name="sql">SQL语句</param>
        /// <param name="cmdtype">命令类型</param>
        /// <param name="parameters">参数</param>
        /// <returns>Object</returns>
        public object ExecuteScalar(string sql, CommandType cmdtype, params DbParameter[] parameters)
        {
            object _result = null;
            DbCommand _command = CreateCommand(sql, cmdtype, parameters);
            try
            {
                _command.Connection.Open();
                _result = _command.ExecuteScalar();
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }
            finally
            {
                _command.Connection.Close();
            }
            return _result;
        }
        #endregion

        /*--------------------------------------ExecuteReader--------------------------------------------*/

        #region public DbDataReader ExecuteReader(string sql)
        /// <summary>
        /// 执行查询，并以DataReader返回结果集

        /// </summary>
        /// <param name="sql">SQL语句</param>
        /// <returns>IDataReader</returns>
        public DbDataReader ExecuteReader(string sql)
        {
            DbParameter[] parameters = new DbParameter[0];
            return ExecuteReader(sql, CommandType.Text, parameters);
        }
        #endregion

        #region public DbDataReader ExecuteReader(string sql, CommandType cmdtype)
        /// <summary>
        /// 执行查询，并以DataReader返回结果集

        /// </summary>
        /// <param name="sql">SQL语句</param>
        /// <param name="cmdtype">命令类型</param>
        /// <returns>IDataReader</returns>
        public DbDataReader ExecuteReader(string sql, CommandType cmdtype)
        {
            DbParameter[] parameters = new DbParameter[0];
            return ExecuteReader(sql, CommandType.Text, parameters);
        }
        #endregion

        #region public DbDataReader ExecuteReader(string sql, DbParameter[] parameters)
        /// <summary>
        /// 执行查询，并以DataReader返回结果集

        /// </summary>
        /// <param name="sql">SQL语句</param>
        /// <param name="parameters">参数</param>
        /// <returns>IDataReader</returns>
        public DbDataReader ExecuteReader(string sql, params DbParameter[] parameters)
        {
            return ExecuteReader(sql, CommandType.Text, parameters);
        }
        #endregion

        #region public DbDataReader ExecuteReader(string sql, CommandType cmdtype, DbParameter[] parameters)
        /// <summary>
        /// 执行查询，并以DataReader返回结果集

        /// </summary>
        /// <param name="sql">SQL语句</param>
        /// <param name="cmdtype">命令类型</param>
        /// <param name="parameters">参数</param>
        /// <returns>IDataReader</returns>
        public DbDataReader ExecuteReader(string sql, CommandType cmdtype, params DbParameter[] parameters)
        {
            DbDataReader _result;
            DbCommand _command = CreateCommand(sql, cmdtype, parameters);
            try
            {
                _command.Connection.Open();
                _result = _command.ExecuteReader(CommandBehavior.CloseConnection);
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }
            finally
            {

            }
            return _result;
        }
        #endregion

        /*---------------------------------------------GetDataSet()--------------------------------------------------------------*/

        public DataSet Query(string sql, DbParameter[] parameters)
        {
            return GetDataSet(sql, parameters);
        }
        public DataSet Query(string sql)
        {
            return GetDataSet(sql);
        }

        #region         public DataSet GetDataSet(string sql)
        /// <summary>
        /// 执行查询，并以DataSet返回结果集

        /// </summary>
        /// <param name="sql">SQL语句</param>
        /// <returns>DataSet</returns>
        public DataSet GetDataSet(string sql)
        {
            DbParameter[] parameters = new DbParameter[0];
            return GetDataSet(sql, CommandType.Text, parameters);
        }
        #endregion

        #region         public virtual DataSet GetDataSet(string sql, CommandType cmdtype)
        /// <summary>
        /// 执行查询，并以DataSet返回结果集

        /// </summary>
        /// <param name="sql">SQL语句</param>
        /// <param name="cmdtype">命令类型</param>
        /// <returns>DataSet</returns>
        public virtual DataSet GetDataSet(string sql, CommandType cmdtype)
        {
            DbParameter[] parameters = new DbParameter[0];
            return GetDataSet(sql, CommandType.Text, parameters);
        }
        #endregion

        #region         public virtual DataSet GetDataSet(string sql, DbParameter[] parameters)
        /// <summary>
        /// 执行查询，并以DataSet返回结果集

        /// </summary>
        /// <param name="sql">SQL语句</param>
        /// <param name="parameters">参数</param>
        /// <returns>DataSet</returns>
        public virtual DataSet GetDataSet(string sql, params DbParameter[] parameters)
        {
            return GetDataSet(sql, CommandType.Text, parameters);
        }
        #endregion

        #region        public virtual DataSet GetDataSet(string sql, CommandType cmdtype, DbParameter[] parameters)
        /// <summary>
        /// 执行查询，并以DataSet返回结果集

        /// </summary>
        /// <param name="sql">SQL语句</param>
        /// <param name="cmdtype">命令类型</param>
        /// <param name="parameters">参数</param>
        /// <returns>DataSet</returns>
        public virtual DataSet GetDataSet(string sql, CommandType cmdtype, params DbParameter[] parameters)
        {
            DataSet _result = new DataSet();
            IDataAdapter _dataAdapter = CreateAdapter(sql, cmdtype, parameters);
            try
            {
                _dataAdapter.Fill(_result);
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }
            finally
            {
            }
            return _result;
        }
        #endregion

        #region     public virtual DataSet GetDataSet(string sql, int StartIndex, int RecordCount)
        /// <summary>
        /// 执行查询,并以DataSet返回指定记录的结果集
        /// </summary>
        /// <param name="sql">SQL语句</param>
        /// <param name="StartIndex">开始索引</param>
        /// <param name="RecordCount">显示记录</param>
        /// <returns>DataSet</returns>
        public virtual DataSet GetDataSet(string sql, int StartIndex, int RecordCount)
        {
            DataSet _result = new DataSet();
            IDataAdapter _dataAdapter = CreateAdapter(sql);
            try
            {
                if (TDBType == ThsDBType.SQL)
                {
                    System.Data.SqlClient.SqlDataAdapter da = (System.Data.SqlClient.SqlDataAdapter)_dataAdapter;
                    da.Fill(_result, StartIndex, RecordCount, "aaa");
                }
                //else if (TDBType == ThsDBType.Oracle)
                //{
                //    System.Data.OracleClient.OracleDataAdapter da = (System.Data.OracleClient.OracleDataAdapter)_dataAdapter;
                //    da.Fill(_result, StartIndex, RecordCount, "aaa");
                //}
                else
                {
                    System.Data.OleDb.OleDbDataAdapter da = (System.Data.OleDb.OleDbDataAdapter)_dataAdapter;
                    da.Fill(_result, StartIndex, RecordCount, "aaa");
                }
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }
            finally
            {
            }
            return _result;
        }
        #endregion

        /*-----------------------------------------GetDataView()-----------------------------------------------*/

        #region         public DataView GetDataView(string sql)

        /// <summary>
        /// 执行查询，并以DataView返回结果集

        /// </summary>
        /// <param name="sql">SQL语句</param>
        /// <param name="cmdtype">命令类型</param>
        /// <param name="parameters">参数</param>
        /// <returns>DataView</returns>
        public DataView GetDataView(string sql)
        {
            DbParameter[] parameters = new DbParameter[0];
            DataView dv = GetDataSet(sql, CommandType.Text, parameters).Tables[0].DefaultView;
            return dv;
        }
        #endregion

        #region         public DataView GetDataView(string sql, CommandType cmdtype)
        /// <summary>
        /// 执行查询，并以DataView返回结果集

        /// </summary>
        /// <param name="sql">SQL语句</param>
        /// <param name="cmdtype">命令类型</param>
        /// <param name="parameters">参数</param>
        /// <returns>DataView</returns>
        public DataView GetDataView(string sql, CommandType cmdtype)
        {
            DbParameter[] parameters = new DbParameter[0];
            DataView dv = GetDataSet(sql, cmdtype, parameters).Tables[0].DefaultView;
            return dv;
        }
        #endregion

        #region public DataView GetDataView(string sql, DbParameter[] parameters)
        /// <summary>
        /// 执行查询，并以DataView返回结果集

        /// </summary>
        /// <param name="sql">SQL语句</param>
        /// <param name="cmdtype">命令类型</param>
        /// <param name="parameters">参数</param>
        /// <returns>DataView</returns>
        public DataView GetDataView(string sql, params DbParameter[] parameters)
        {

            DataView dv = GetDataSet(sql, CommandType.Text, parameters).Tables[0].DefaultView;
            return dv;
        }
        #endregion

        #region public DataView GetDataView(string sql, CommandType cmdtype, DbParameter[] parameters)
        /// <summary>
        /// 执行查询，并以DataView返回结果集

        /// </summary>
        /// <param name="sql">SQL语句</param>
        /// <param name="cmdtype">命令类型</param>
        /// <param name="parameters">参数</param>
        /// <returns>DataView</returns>
        public DataView GetDataView(string sql, CommandType cmdtype, params DbParameter[] parameters)
        {
            DataView dv = GetDataSet(sql, cmdtype, parameters).Tables[0].DefaultView;
            return dv;
        }
        #endregion

        #region public DataView GetDataView(string sql, int StartIndex, int RecordCount)
        /// <summary>
        /// 执行查询,并以DataView返回指定记录的结果集
        /// </summary>
        /// <param name="sql">SQL语句</param>
        /// <param name="StartIndex">开始索引</param>
        /// <param name="RecordCount">显示记录</param>
        /// <returns>DataView</returns>
        public DataView GetDataView(string sql, int StartIndex, int RecordCount)
        {
            return GetDataSet(sql, StartIndex, RecordCount).Tables[0].DefaultView;
        }
        #endregion

        /*---------------------------------------GetTable()-------------------------------*/

        #region public DataTable GetDataTable(string sql)

        /// <summary>
        /// 执行查询，并以DataTable返回结果集

        /// </summary>
        /// <param name="sql">SQL语句</param>
        /// <param name="cmdtype">命令类型</param>
        /// <param name="parameters">参数</param>
        /// <returns>DataTable</returns>
        public DataTable GetDataTable(string sql)
        {
            DbParameter[] parameters = new DbParameter[0];
            DataTable dt = GetDataSet(sql, CommandType.Text, parameters).Tables[0];
            return dt;
        }
        #endregion

        #region public DataTable GetDataTable(string sql, CommandType cmdtype)
        /// <summary>
        /// 执行查询，并以DataTable返回结果集

        /// </summary>
        /// <param name="sql">SQL语句</param>
        /// <param name="cmdtype">命令类型</param>
        /// <param name="parameters">参数</param>
        /// <returns>DataTable</returns>
        public DataTable GetDataTable(string sql, CommandType cmdtype)
        {
            DbParameter[] parameters = new DbParameter[0];
            DataTable dt = GetDataSet(sql, cmdtype, parameters).Tables[0];
            return dt;
        }
        #endregion

        #region public DataTable GetDataTable(string sql, DbParameter[] parameters)
        /// <summary>
        /// 执行查询，并以DataTable返回结果集

        /// </summary>
        /// <param name="sql">SQL语句</param>
        /// <param name="cmdtype">命令类型</param>
        /// <param name="parameters">参数</param>
        /// <returns>DataTable</returns>
        public DataTable GetDataTable(string sql, params DbParameter[] parameters)
        {
            DataTable dt = GetDataSet(sql, CommandType.Text, parameters).Tables[0];
            return dt;
        }
        #endregion

        #region public DataTable GetDataTable(string sql, CommandType cmdtype, DbParameter[] parameters)
        /// <summary>
        /// 执行查询，并以DataTable返回结果集

        /// </summary>
        /// <param name="sql">SQL语句</param>
        /// <param name="cmdtype">命令类型</param>
        /// <param name="parameters">参数</param>
        /// <returns>DataTable</returns>
        public DataTable GetDataTable(string sql, CommandType cmdtype, params DbParameter[] parameters)
        {
            DataTable dt = GetDataSet(sql, cmdtype, parameters).Tables[0];
            return dt;
        }
        #endregion

        #region public DataTable GetDataTable(string sql, int StartIndex, int RecordCount)
        /// <summary>
        /// 执行查询,并以DataTable返回指定记录的结果集
        /// </summary>
        /// <param name="sql">SQL语句</param>
        /// <param name="StartIndex">开始索引</param>
        /// <param name="RecordCount">显示记录</param>
        /// <returns>DataTable</returns>
        public DataTable GetDataTable(string sql, int StartIndex, int RecordCount)
        {
            return GetDataSet(sql, StartIndex, RecordCount).Tables[0];
        }
        #endregion

        #region public DataTable GetDataTable(string sql, int SizeCount)
        /// <summary>
        /// 执行查询,返回以空行填充的指定条数记录集

        /// </summary>
        /// <param name="sql">SQL语句</param>
        /// <param name="SizeCount">显示记录条数</param>
        /// <returns>DataTable</returns>
        public DataTable GetDataTable(string sql, int SizeCount)
        {
            DataTable dt = GetDataSet(sql).Tables[0];
            int b = SizeCount - dt.Rows.Count;
            if (dt.Rows.Count < SizeCount)
            {
                for (int i = 0; i < b; i++)
                {
                    DataRow dr = dt.NewRow();
                    dt.Rows.Add(dr);
                }
            }
            return dt;
        }
        #endregion
    }
}

Linq To Excel Demo
===============
[![Build status](https://ci.appveyor.com/api/projects/status/l0juxcd6qe4sdfiu?svg=true)](https://ci.appveyor.com/project/larrynung/linqtoexceldemo)

Introduce how to use [Linq to Excel](https://code.google.com/p/linqtoexcel/)

Reference
---------
* [Linq To Excel - Level Up- 點部落](http://www.dotblogs.com.tw/larrynung/archive/2010/12/02/19868.aspx)

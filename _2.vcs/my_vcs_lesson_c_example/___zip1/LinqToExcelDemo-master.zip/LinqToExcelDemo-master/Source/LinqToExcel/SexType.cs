﻿
namespace ConsoleApplication1
{
    enum SexType
    {
        Boy,
        Girl
    }
}

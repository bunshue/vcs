﻿namespace WebClient
{
    partial class WebClient
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.web_browser = new System.Windows.Forms.WebBrowser();
            this.notify_Icon = new System.Windows.Forms.NotifyIcon(this.components);
            this.contextMenuStrip = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.Show_ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.Hide_ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.Exit_ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.contextMenuStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // web_browser
            // 
            this.web_browser.Dock = System.Windows.Forms.DockStyle.Fill;
            this.web_browser.Location = new System.Drawing.Point(0, 0);
            this.web_browser.MinimumSize = new System.Drawing.Size(20, 20);
            this.web_browser.Name = "web_browser";
            this.web_browser.Size = new System.Drawing.Size(1146, 667);
            this.web_browser.TabIndex = 0;
            this.web_browser.Navigated += new System.Windows.Forms.WebBrowserNavigatedEventHandler(this.web_browser_Navigated);
            // 
            // notify_Icon
            // 
            this.notify_Icon.ContextMenuStrip = this.contextMenuStrip;
            this.notify_Icon.Visible = true;
            this.notify_Icon.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.notify_Icon_MouseDoubleClick);
            // 
            // contextMenuStrip
            // 
            this.contextMenuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Show_ToolStripMenuItem,
            this.Hide_ToolStripMenuItem,
            this.toolStripMenuItem1,
            this.Exit_ToolStripMenuItem});
            this.contextMenuStrip.Name = "contextMenuStrip";
            this.contextMenuStrip.Size = new System.Drawing.Size(101, 76);
            // 
            // Show_ToolStripMenuItem
            // 
            this.Show_ToolStripMenuItem.Name = "Show_ToolStripMenuItem";
            this.Show_ToolStripMenuItem.Size = new System.Drawing.Size(100, 22);
            this.Show_ToolStripMenuItem.Text = "展示";
            this.Show_ToolStripMenuItem.Click += new System.EventHandler(this.Show_ToolStripMenuItem_Click);
            // 
            // Hide_ToolStripMenuItem
            // 
            this.Hide_ToolStripMenuItem.Name = "Hide_ToolStripMenuItem";
            this.Hide_ToolStripMenuItem.Size = new System.Drawing.Size(100, 22);
            this.Hide_ToolStripMenuItem.Text = "隐藏";
            this.Hide_ToolStripMenuItem.Click += new System.EventHandler(this.Hide_ToolStripMenuItem_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(97, 6);
            // 
            // Exit_ToolStripMenuItem
            // 
            this.Exit_ToolStripMenuItem.Name = "Exit_ToolStripMenuItem";
            this.Exit_ToolStripMenuItem.Size = new System.Drawing.Size(100, 22);
            this.Exit_ToolStripMenuItem.Text = "退出";
            this.Exit_ToolStripMenuItem.Click += new System.EventHandler(this.Exit_ToolStripMenuItem_Click);
            // 
            // WebClient
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1146, 667);
            this.Controls.Add(this.web_browser);
            this.Name = "WebClient";
            this.Text = "WebClient";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.WebClient_FormClosing);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.WebClient_FormClosed);
            this.Load += new System.EventHandler(this.WebClient_Load);
            this.contextMenuStrip.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.WebBrowser web_browser;
        private System.Windows.Forms.NotifyIcon notify_Icon;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip;
        private System.Windows.Forms.ToolStripMenuItem Show_ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem Hide_ToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem Exit_ToolStripMenuItem;
    }
}


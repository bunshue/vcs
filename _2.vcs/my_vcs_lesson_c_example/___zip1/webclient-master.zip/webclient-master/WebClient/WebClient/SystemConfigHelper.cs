﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace WebClient
{
    public class SystemConfigHelper
    {
        private SystemConfigHelper() { }

        private static SystemConfigHelper _SystemConfigHelper = new SystemConfigHelper();

        public static SystemConfigHelper GetInstance()
        {
            return _SystemConfigHelper;
        }

        private string GetFormatKey(string key = null)
        {
            if (string.IsNullOrEmpty(key))
                return "/SystemSetting";
            else
                return string.Format("/SystemSetting/{0}", key);
        }

        private const string FilePath = "SystemConfig.xml";

        /// <summary>
        /// 获取设置的Xml文件
        /// </summary>
        /// <returns></returns>
        private XmlDocument GetXmlDocument()
        {
            XmlDocument doc = new XmlDocument();


            if (File.Exists(FilePath))
            {
                doc.Load(FilePath);
            }
            else
            {
                var desc = doc.CreateXmlDeclaration("1.0", "UTF-8", null);
                doc.AppendChild(desc);

                var system_setting = doc.CreateElement("SystemSetting");
                doc.AppendChild(system_setting);
            }

            return doc;
        }

        /// <summary>
        /// 保存相关的Xml文件
        /// </summary>
        /// <param name="doc"></param>
        private void SaveXmlDocument(XmlDocument doc)
        {
            doc.Save(FilePath);
        }

        /// <summary>
        /// 获取设置
        /// </summary>
        /// <param name="key"></param>
        /// <returns></returns>
        public Dictionary<string, string> GetSetting(string key)
        {
            string format_key = GetFormatKey(key);
            Dictionary<string, string> dic = new Dictionary<string, string>();

            var doc = GetXmlDocument();
            var setting_node = doc.SelectSingleNode(format_key);
            if (setting_node != null)
            {
                foreach (XmlNode item in setting_node)
                {
                    dic.Add(item.Name, item.InnerText);
                }
            }

            return dic;
        }

        /// <summary>
        /// 保存设置
        /// </summary>
        /// <param name="key"></param>
        /// <param name="dic"></param>
        public void SetSetting(string key, Dictionary<string, string> dic)
        {
            string format_key = GetFormatKey(key);
            var doc = GetXmlDocument();
            var setting_node = doc.SelectSingleNode(format_key);
            if (setting_node == null)
            {
                setting_node = doc.CreateElement(key);
                var parent = doc.SelectSingleNode(GetFormatKey());
                parent.AppendChild(setting_node);
            }

            setting_node.RemoveAll();
            foreach (var item in dic)
            {
                var xml_node = doc.CreateElement(item.Key);
                xml_node.InnerText = item.Value;
                setting_node.AppendChild(xml_node);
            }

            SaveXmlDocument(doc);
        }
    }
}

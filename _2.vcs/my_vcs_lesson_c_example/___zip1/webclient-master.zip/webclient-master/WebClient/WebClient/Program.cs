﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WebClient
{
    static class Program
    {
        /// <summary>
        /// 应用程序的主入口点。
        /// </summary>
        [STAThread]
        static void Main()
        {
            bool create_new = true;
            using (Mutex mutex = new Mutex(true, Application.ProductName, out create_new))
            {
                if (create_new)
                {
                    Application.EnableVisualStyles();
                    Application.SetCompatibleTextRenderingDefault(false);
                    Application.Run(new WebClient());
                }
                else 
                {
                    // 展示原来的应用
                    Thread.Sleep(500);
                    System.Environment.Exit(1);
                }
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WebClient
{
    public partial class WebClient : Form
    {
        FormSerialize form_serialize = null;

        public Uri WebUri
        {
            get { return web_browser.Url; }
            set { web_browser.Url = value; }
        }

        public Size FormSize
        {
            get { return Size; }
            set { Size = value; }
        }

        public Point FormLocation
        {
            get { return Location; }
            set
            {
                if (SystemInformation.WorkingArea.Contains(value))
                    Location = value;
            }
        }

        public FormWindowState FormWindowState
        {
            get { return WindowState; }
            set
            {
                if (value != System.Windows.Forms.FormWindowState.Minimized)
                    WindowState = value;
            }
        }

        public string IconPath
        {
            set
            {
                if (File.Exists(value))
                {
                    Icon = new Icon(value);
                    notify_Icon.Icon = new Icon(value);
                }
            }
        }

        public bool ShowNotifyIcon
        {
            set
            {
                notify_Icon.Visible = value;
            }
        }

        public string NotifyIconText
        {
            set { notify_Icon.Text = value; }
        }

        private FormWindowState LastWindowState = FormWindowState.Normal;

        public new FormWindowState WindowState
        {
            get { return base.WindowState; }
            set
            {
                LastWindowState = base.WindowState;
                base.WindowState = value;
                ShowInTaskbar = WindowState != System.Windows.Forms.FormWindowState.Minimized;
            }
        }

        /// <summary>
        /// 将Web标题设置为客户端Text
        /// </summary>
        public bool SetClientTextWebTitle { get; set; }

        private bool _MinimizeWhenClosing = false;
        private bool _HaveCloseConfig = false;

        /// <summary>
        /// 关闭时最小化
        /// </summary>
        public bool MinimizeWhenClosing
        {
            get { return _MinimizeWhenClosing; }
            set
            {
                _MinimizeWhenClosing = value;
                _HaveCloseConfig = true;
            }
        }

        private FormWindowState GetWindowState() 
        {
            return System.Windows.Forms.FormWindowState.Maximized;
        }

        public WebClient()
        {
            InitializeComponent();

            form_serialize = new FormSerialize(this);
        }

        private void WebClient_Load(object sender, EventArgs e)
        {
            // 将相关配置反序列化
            form_serialize.DeSerialize();
        }

        private void WebClient_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (!_HaveCloseConfig)
            {
                var dr = MessageBox.Show("关闭时最小化软件", "系统提示", MessageBoxButtons.YesNo);
                MinimizeWhenClosing = dr == System.Windows.Forms.DialogResult.Yes;
                var web_setting = SystemConfigHelper.GetInstance().GetSetting("Web");
                web_setting["MinimizeWhenClosing"] = MinimizeWhenClosing.ToString();
                SystemConfigHelper.GetInstance().SetSetting("Web", web_setting);
            }

            // 关闭时最小化
            if (MinimizeWhenClosing)
            {
                WindowState = System.Windows.Forms.FormWindowState.Minimized;
                e.Cancel = true;
            }
        }

        private void web_browser_Navigated(object sender, WebBrowserNavigatedEventArgs e)
        {
            if (SetClientTextWebTitle)
                Text = web_browser.DocumentTitle;
        }

        private void notify_Icon_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            var TargetWindowState = WindowState == System.Windows.Forms.FormWindowState.Minimized ? GetWindowState() : System.Windows.Forms.FormWindowState.Minimized;
            WindowState = TargetWindowState;

            if (WindowState != System.Windows.Forms.FormWindowState.Minimized)
                Activate();
        }

        private void WebClient_FormClosed(object sender, FormClosedEventArgs e)
        {
            form_serialize.Serialize();
        }

        private void Show_ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            WindowState = System.Windows.Forms.FormWindowState.Maximized;
        }

        private void Hide_ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            WindowState = System.Windows.Forms.FormWindowState.Minimized;
        }

        private void Exit_ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}

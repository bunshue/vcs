// Camara Vision
//
// Copyright � Andrew Kirillov, 2005-2006
// andrew.kirillov@gmail.com
//

namespace stream
{
	using System;

	/// <summary>
	/// StreamConfiguration
	/// </summary>
	public class StreamConfiguration
	{
		public string	source;
	}
}

// Camara Vision
//
// Copyright � Andrew Kirillov, 2005-2006
// andrew.kirillov@gmail.com
//

namespace local
{
	using System;

	/// <summary>
	/// StreamConfiguration
	/// </summary>
	public class LocalConfiguration
	{
		public string	source;
	}
}

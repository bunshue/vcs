package com.gordon.regionSpider.constants;

/**
 * Created by wwz on 2016/2/18.
 */
public enum ContentType {
    FETCHEDPAGETYPE_HTML(0), FETCHEDPAGETYPE_JSON(1);
    ContentType(int i){
    }
}

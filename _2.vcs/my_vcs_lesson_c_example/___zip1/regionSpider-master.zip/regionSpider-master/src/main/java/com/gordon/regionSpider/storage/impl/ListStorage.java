package com.gordon.regionSpider.storage.impl;

import com.gordon.regionSpider.model.RegionTreeNode;
import com.gordon.regionSpider.storage.DataStorage;
import org.apache.log4j.Logger;

import java.util.ArrayList;
import java.util.List;


public class ListStorage implements DataStorage {

    public void store(List<RegionTreeNode> regionTreeNodeList) {

    }
}

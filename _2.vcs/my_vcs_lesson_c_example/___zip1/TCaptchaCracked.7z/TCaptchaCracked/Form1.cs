﻿/*
 * 專案: 圖形驗證碼破解測試
 * 作者: Arvin Hsieh
 * 部落格: http://www.dotblogs.com.tw/joysdw12
 * 日期: 2013/06/08
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using mshtml;

namespace TCaptchaCracked
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnGO_Click(object sender, EventArgs e)
        {
            webBrowser1.Navigate(txtUrl.Text);
        }

        private void webBrowser1_DocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
        {
            WebBrowser wb = sender as WebBrowser;
            var doc = wb.Document.DomDocument as HTMLDocument;
            HTMLBody body = doc.body as HTMLBody;
            IHTMLControlRange range = body.createControlRange();
            // 取得網頁上驗證碼圖片
            IHTMLControlElement imgElement =
                wb.Document.GetElementById("Image1").DomElement as IHTMLControlElement;
            range.add(imgElement);
            range.execCommand("copy", false, Type.Missing);
            Image img = Clipboard.GetImage();
            Clipboard.Clear();
            picBox1.Image = img;
            // 轉換成 Bitmap 物件進行破解
            CaptchaCracked(new Bitmap(img));
            // 將驗證碼寫入文字框
            //wb.Document.GetElementById("txtCaptchaCode").SetAttribute("value", txtCode.Text);

            //foreach (HtmlElement elem in wb.Document.Images)
            //{
            //    if (elem.GetAttribute("src").ToLower().IndexOf("captchahandler.ashx") >= 0)
              
            //    {
            //        // 取得網頁上驗證碼圖片
            //        var doc = wb.Document.DomDocument as HTMLDocument;
            //        HTMLBody body = doc.body as HTMLBody;
            //        IHTMLControlRange range = body.createControlRange();
            //        IHTMLControlElement imgElement = elem.DomElement as IHTMLControlElement;
            //        range.add(imgElement);
            //        range.execCommand("copy", false, Type.Missing);
            //        Image img = Clipboard.GetImage();
            //        Clipboard.Clear();
            //        picBox1.Image = img;
            //        // 轉換成 Bitmap 物件進行破解
            //        CaptchaCracked(new Bitmap(img));
            //        wb.Document.GetElementById("txtCaptchaCode").SetAttribute("value", txtCode.Text);
            //    }
            //}
        }

        private void CaptchaCracked(Bitmap pBmpImg)
        {
            CaptchaCrackedHelper.DecCodeList decCodeList =
                   new CaptchaCrackedHelper.DecCodeList();
            decCodeList.List.Add(new CaptchaCrackedHelper.DecCodes()    // 0
            {   
                Code = new string[] { 
                    "001110001001000100110010011001001100100110010011001001000011000",
                    "0111100010010001001100100110010011001001100110010010010000111000110000",
                    "0111000100100010011001001100100010010011001101100100100001110100100000"}
            });
            decCodeList.List.Add(new CaptchaCrackedHelper.DecCodes()    // 1
            {
                Code = new string[] { 
                    "011100000010000001000000100000010000001000000100000010000111100",
                    "011100000010000011000001100000010000011000001100000110000111110",
                    "0001100000010000001000000100000011000011000000100000010000001100000000",
                    "0000000000110000001000000100000110000001000001100000010000001000001110"}
            });
            decCodeList.List.Add(new CaptchaCrackedHelper.DecCodes()    // 2
            {
                Code = new string[] { 
                    "001100001111000000100000010000000000001000001000000111100111100",
                    "0001100001111001000100000010000000000001000001000001111100111100000000",
                    "001110001111001001100000010000000000001000001001000111101111100"}
            });
            decCodeList.List.Add(new CaptchaCrackedHelper.DecCodes()    // 3
            {
                Code = new string[] { 
                    "001110001111000000100000110000111000000100000011011001000111000",
                    "0011110011110000001000001100001110000001100000100110010001110000000000",
                    ""}
            });
            decCodeList.List.Add(new CaptchaCrackedHelper.DecCodes()    // 4
            {
                Code = new string[] { 
                    "000010000011000001100000110000001000001100011111000001000000100",
                    "000010000001000001100001110000011000000100011111000011000000100",
                    "0001000000100000110000001000000101000110000111100000100000010000000000",
                    "0000000000001000001100000110000001000000100000110001111100000100000010"}
            });
            decCodeList.List.Add(new CaptchaCrackedHelper.DecCodes()    // 5
            {
                Code = new string[] { 
                    "001111000111100100000011100001111000000110000001001000000111100",
                    "0011110001101000000000111000011011000001100001010010000001111100001000",
                    ""}
            });
            decCodeList.List.Add(new CaptchaCrackedHelper.DecCodes()    // 6
            {
                Code = new string[] { 
                    "000011000110000010000011110001001100100110010011001101100011100",
                    "0000100001100000100000111100010011001001100100110011011000111000000000",
                    ""}
            });
            decCodeList.List.Add(new CaptchaCrackedHelper.DecCodes()    // 7
            {
                Code = new string[] { 
                    "011111001111100000000000010000001000000000000100000010000000000",
                    "1111110011011000000000000100000010000000000011000000100000000000000000",
                    ""}
            });
            decCodeList.List.Add(new CaptchaCrackedHelper.DecCodes()    // 8
            {
                Code = new string[] { 
                    "001110001000100110010011110000111000100110010011001001100111100",
                    "1111000100010011001001111000011000010001001001100100110001110000000000",
                    "0000000000111000100100011001001111000011100110011011000100100110001110",
                    "0001000000101000100010011101001111000011110010011001001000100110001010"}
            });
            decCodeList.List.Add(new CaptchaCrackedHelper.DecCodes()    // 9
            {
                Code = new string[] { 
                    "001110001001000100110010011001100100011100000010000110000110000",
                    "001110001101100100110110011001101100111110000010000111000110000",
                    "001110001001000100110010011001101100111110000010000000000000000",
                    "0000000101110011001010100110010011001100100011110000010000110000010000"}
            });

            CaptchaCrackedHelper cracked = new CaptchaCrackedHelper(pBmpImg, 128, 6, decCodeList);

            // Step1 灰階化
            cracked.ConvertGrayByPixels();
            // Step2 其他處理
            if (comboBox1.SelectedIndex == 1)
                cracked.RemoteNoiseLineByPixels();
            else if (comboBox1.SelectedIndex == 2)
            {
                cracked.ClearPictureBorder(2);
                cracked.RemoteNoisePointByPixels();
            }
            picBox2.Image = cracked.BmpSource;

            // Step2 改變圖片範圍
            cracked.ConvertBmpValidRange(4);
            picBox3.Image = cracked.BmpSource;

            // Step3 切割圖片範圍
            Bitmap[] bitmap = cracked.GetSplitPicChars(4, 1);
            picBoxP1.Image = bitmap[0];
            picBoxP2.Image = bitmap[1];
            picBoxP3.Image = bitmap[2];
            picBoxP4.Image = bitmap[3];
            //picBoxP5.Image = bitmap[4];

            txtCodeStr.Text = string.Empty;
            txtCode.Text = string.Empty;
            foreach (Bitmap bmp in bitmap)
            {
                string result = cracked.GetSingleBmpCode(bmp);
                txtCodeStr.Text += result + "@";
                txtCode.Text += cracked.GetDecChar(result);
            }

        }

        private string QueryCharDictionary(string pCharCode)
        {
            if (pCharCode != string.Empty)
            {
                string[] charDictionary = {"001110001001000100110010011001001100100110010011001001000011000",
                                       "011100000010000001000000100000010000001000000100000010000111100",
                                       "001100001111000000100000010000000000001000001000000111100111100",
                                       "001110001111000000100000110000111000000100000011011001000111000",
                                       "000010000011000001100000110000001000001100011111000001000000100",
                                       "001111000111100100000011100001111000000110000001001000000111100",
                                       "000011000110000010000011110001001100100110010011001101100011100",
                                       "011111001111100000000000010000001000000000000100000010000000000",
                                       "001110001000100110010011110000111000100110010011001001100111100",
                                       "001110001001000100110010011001100100011100000010000110000110000"};

                char[] codeChar = pCharCode.ToCharArray();
                int diffCharCount = 0;
                for (int i = 0; i < charDictionary.Length; i++)
                {
                    char[] dicChar = charDictionary[i].ToCharArray();
                    if (codeChar.Length == dicChar.Length)
                    {
                        for (int j = 0; j < codeChar.Length; j++)
                            if (codeChar[j] != dicChar[j])
                                diffCharCount++;
                        if (diffCharCount < 5)
                            return i.ToString();
                        else
                            diffCharCount = 0;
                    }
                    else
                        return "X";
                }
            }
            return "X";
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex == 1)
                txtUrl.Text = "http://localhost:16587/Default.aspx?mode=2";
            else if (comboBox1.SelectedIndex == 2)
                txtUrl.Text = "http://localhost:16587/Default.aspx?mode=3";
            else
                txtUrl.Text = "http://localhost:16587/Default.aspx?mode=1";
        }
    }
}

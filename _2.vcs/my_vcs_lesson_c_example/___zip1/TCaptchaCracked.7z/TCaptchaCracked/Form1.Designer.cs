﻿namespace TCaptchaCracked
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器
        /// 修改這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.webBrowser1 = new System.Windows.Forms.WebBrowser();
            this.btnGO = new System.Windows.Forms.Button();
            this.txtUrl = new System.Windows.Forms.TextBox();
            this.picBox1 = new System.Windows.Forms.PictureBox();
            this.picBox2 = new System.Windows.Forms.PictureBox();
            this.picBox3 = new System.Windows.Forms.PictureBox();
            this.picBoxP1 = new System.Windows.Forms.PictureBox();
            this.picBoxP2 = new System.Windows.Forms.PictureBox();
            this.picBoxP3 = new System.Windows.Forms.PictureBox();
            this.picBoxP4 = new System.Windows.Forms.PictureBox();
            this.picBoxP5 = new System.Windows.Forms.PictureBox();
            this.txtCodeStr = new System.Windows.Forms.TextBox();
            this.txtCode = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.picBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxP1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxP2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxP3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxP4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxP5)).BeginInit();
            this.SuspendLayout();
            // 
            // webBrowser1
            // 
            this.webBrowser1.Location = new System.Drawing.Point(12, 54);
            this.webBrowser1.MinimumSize = new System.Drawing.Size(20, 20);
            this.webBrowser1.Name = "webBrowser1";
            this.webBrowser1.Size = new System.Drawing.Size(376, 199);
            this.webBrowser1.TabIndex = 0;
            this.webBrowser1.DocumentCompleted += new System.Windows.Forms.WebBrowserDocumentCompletedEventHandler(this.webBrowser1_DocumentCompleted);
            // 
            // btnGO
            // 
            this.btnGO.Location = new System.Drawing.Point(394, 12);
            this.btnGO.Name = "btnGO";
            this.btnGO.Size = new System.Drawing.Size(75, 22);
            this.btnGO.TabIndex = 1;
            this.btnGO.Text = "進入";
            this.btnGO.UseVisualStyleBackColor = true;
            this.btnGO.Click += new System.EventHandler(this.btnGO_Click);
            // 
            // txtUrl
            // 
            this.txtUrl.Location = new System.Drawing.Point(12, 12);
            this.txtUrl.Name = "txtUrl";
            this.txtUrl.Size = new System.Drawing.Size(376, 22);
            this.txtUrl.TabIndex = 2;
            this.txtUrl.Text = "http://localhost:28094/TestPostback.aspx";
            // 
            // picBox1
            // 
            this.picBox1.Location = new System.Drawing.Point(394, 69);
            this.picBox1.Name = "picBox1";
            this.picBox1.Size = new System.Drawing.Size(75, 30);
            this.picBox1.TabIndex = 3;
            this.picBox1.TabStop = false;
            // 
            // picBox2
            // 
            this.picBox2.Location = new System.Drawing.Point(394, 117);
            this.picBox2.Name = "picBox2";
            this.picBox2.Size = new System.Drawing.Size(75, 30);
            this.picBox2.TabIndex = 4;
            this.picBox2.TabStop = false;
            // 
            // picBox3
            // 
            this.picBox3.Location = new System.Drawing.Point(396, 165);
            this.picBox3.Name = "picBox3";
            this.picBox3.Size = new System.Drawing.Size(73, 30);
            this.picBox3.TabIndex = 5;
            this.picBox3.TabStop = false;
            // 
            // picBoxP1
            // 
            this.picBoxP1.Location = new System.Drawing.Point(394, 213);
            this.picBoxP1.Name = "picBoxP1";
            this.picBoxP1.Size = new System.Drawing.Size(21, 30);
            this.picBoxP1.TabIndex = 6;
            this.picBoxP1.TabStop = false;
            // 
            // picBoxP2
            // 
            this.picBoxP2.Location = new System.Drawing.Point(421, 213);
            this.picBoxP2.Name = "picBoxP2";
            this.picBoxP2.Size = new System.Drawing.Size(21, 30);
            this.picBoxP2.TabIndex = 7;
            this.picBoxP2.TabStop = false;
            // 
            // picBoxP3
            // 
            this.picBoxP3.Location = new System.Drawing.Point(448, 213);
            this.picBoxP3.Name = "picBoxP3";
            this.picBoxP3.Size = new System.Drawing.Size(21, 30);
            this.picBoxP3.TabIndex = 8;
            this.picBoxP3.TabStop = false;
            // 
            // picBoxP4
            // 
            this.picBoxP4.Location = new System.Drawing.Point(475, 213);
            this.picBoxP4.Name = "picBoxP4";
            this.picBoxP4.Size = new System.Drawing.Size(21, 30);
            this.picBoxP4.TabIndex = 9;
            this.picBoxP4.TabStop = false;
            // 
            // picBoxP5
            // 
            this.picBoxP5.Location = new System.Drawing.Point(502, 213);
            this.picBoxP5.Name = "picBoxP5";
            this.picBoxP5.Size = new System.Drawing.Size(21, 30);
            this.picBoxP5.TabIndex = 10;
            this.picBoxP5.TabStop = false;
            // 
            // txtCodeStr
            // 
            this.txtCodeStr.Location = new System.Drawing.Point(12, 259);
            this.txtCodeStr.Name = "txtCodeStr";
            this.txtCodeStr.Size = new System.Drawing.Size(511, 22);
            this.txtCodeStr.TabIndex = 11;
            // 
            // txtCode
            // 
            this.txtCode.Location = new System.Drawing.Point(12, 287);
            this.txtCode.Name = "txtCode";
            this.txtCode.Size = new System.Drawing.Size(129, 22);
            this.txtCode.TabIndex = 12;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(394, 54);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 12);
            this.label1.TabIndex = 13;
            this.label1.Text = "原始圖";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(394, 102);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(41, 12);
            this.label2.TabIndex = 14;
            this.label2.Text = "灰階化";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(394, 150);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(65, 12);
            this.label3.TabIndex = 15;
            this.label3.Text = "取可用範圍";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(394, 198);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(41, 12);
            this.label4.TabIndex = 16;
            this.label4.Text = "拆解後";
            // 
            // comboBox1
            // 
            this.comboBox1.AutoCompleteCustomSource.AddRange(new string[] {
            "無干擾",
            "含噪音線",
            "含雜訊"});
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "無干擾",
            "含噪音線",
            "含雜訊"});
            this.comboBox1.Location = new System.Drawing.Point(475, 69);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(75, 20);
            this.comboBox1.TabIndex = 18;
            this.comboBox1.Text = "無干擾";
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(473, 54);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(65, 12);
            this.label5.TabIndex = 19;
            this.label5.Text = "驗證碼樣式";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(561, 317);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtCode);
            this.Controls.Add(this.txtCodeStr);
            this.Controls.Add(this.picBoxP5);
            this.Controls.Add(this.picBoxP4);
            this.Controls.Add(this.picBoxP3);
            this.Controls.Add(this.picBoxP2);
            this.Controls.Add(this.picBoxP1);
            this.Controls.Add(this.picBox3);
            this.Controls.Add(this.picBox2);
            this.Controls.Add(this.picBox1);
            this.Controls.Add(this.txtUrl);
            this.Controls.Add(this.btnGO);
            this.Controls.Add(this.webBrowser1);
            this.Name = "Form1";
            this.Text = "CaptchaCracked";
            ((System.ComponentModel.ISupportInitialize)(this.picBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxP1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxP2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxP3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxP4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxP5)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.WebBrowser webBrowser1;
        private System.Windows.Forms.Button btnGO;
        private System.Windows.Forms.TextBox txtUrl;
        private System.Windows.Forms.PictureBox picBox1;
        private System.Windows.Forms.PictureBox picBox2;
        private System.Windows.Forms.PictureBox picBox3;
        private System.Windows.Forms.PictureBox picBoxP1;
        private System.Windows.Forms.PictureBox picBoxP2;
        private System.Windows.Forms.PictureBox picBoxP3;
        private System.Windows.Forms.PictureBox picBoxP4;
        private System.Windows.Forms.PictureBox picBoxP5;
        private System.Windows.Forms.TextBox txtCodeStr;
        private System.Windows.Forms.TextBox txtCode;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label5;
    }
}


﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Files_Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //Response.Write(Page.ResolveUrl("~/Images/") + "<BR>");
        //Response.Write(Page.ResolveUrl("../Images/") + "<BR>");
        //Response.Write(Page.ResolveUrl(@"~\Images\") + "<BR>");
        //Response.Write(Page.ResolveUrl("Images/") + "<BR>");
        //Response.Write(Page.ResolveUrl("/Images/") + "<BR>");
        //Response.Write(VirtualPathUtility.ToAbsolute("~/Images/") + "<BR>");
        ////Response.Write(VirtualPathUtility.ToAbsolute("../Images/") + "<BR>");
        ////Response.Write(VirtualPathUtility.ToAbsolute("Images/") + "<BR>");
        //Response.Write(VirtualPathUtility.ToAbsolute("/Images/") + "<BR>");
        //Response.Write(VirtualPathUtility.ToAbsolute("~") + "<BR>");

        Response.Write(Page.ResolveUrl("~/Images/logo.png") + "<BR>");
        Response.Write(Page.ResolveUrl("Images/logo.png") + "<BR>");
        Response.Write(VirtualPathUtility.ToAbsolute("~/Images/logo.png"));
        //Response.Write(VirtualPathUtility.ToAbsolute("Images/logo.png"));
        // 目錄位置:
        // /Pages/Default.aspx
        // /Images/logo.png
        // 於 Default.aspx 顯示結果:
        Page.ResolveUrl("~/Images/logo.png"); // 傳入虛擬路徑返回根目錄相對路徑: /Images/logo.png
        Page.ResolveUrl("Images/logo.png"); // 傳入相對路徑返回使用頁面的相對路徑: /Pages/Images/logo.png
        VirtualPathUtility.ToAbsolute("~/Images/logo.png"); // 傳入虛擬路徑返回應用程式絕對路徑: /Images/logo.png
        VirtualPathUtility.ToAbsolute("Images/logo.png"); // 傳入相對路徑將發生錯誤，不接受使用相對路徑
    }
}
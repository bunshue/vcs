﻿/*
 * 專案: 圖形驗證碼破解測試
 * 作者: Arvin Hsieh
 * 部落格: http://www.dotblogs.com.tw/joysdw12
 * 日期: 2013/06/08
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Request.QueryString["mode"] == "2")
            imgCaptcha.ImageUrl = "~/CaptchaHandler.ashx?mode=2";
        else if (Request.QueryString["mode"] == "3")
            imgCaptcha.ImageUrl = "~/CaptchaHandler.ashx?mode=3";
        else
            imgCaptcha.ImageUrl = "~/CaptchaHandler.ashx?mode=1";
        Response.Write(ResolveUrl("~/Images/w7-1.png"));
    }
}
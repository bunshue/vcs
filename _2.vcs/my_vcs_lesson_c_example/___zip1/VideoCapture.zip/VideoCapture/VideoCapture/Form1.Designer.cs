﻿namespace VideoCapture
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openVideoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.recordVideoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.Video_CNTRL = new System.Windows.Forms.TrackBar();
            this.play_pause_BTN = new System.Windows.Forms.Panel();
            this.Video_Image = new System.Windows.Forms.PictureBox();
            this.Time_Label = new System.Windows.Forms.Label();
            this.Frame_lbl = new System.Windows.Forms.Label();
            this.Codec_lbl = new System.Windows.Forms.Label();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Video_CNTRL)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Video_Image)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(761, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.openVideoToolStripMenuItem,
            this.recordVideoToolStripMenuItem,
            this.toolStripSeparator1,
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "&File";
            // 
            // openVideoToolStripMenuItem
            // 
            this.openVideoToolStripMenuItem.Name = "openVideoToolStripMenuItem";
            this.openVideoToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.openVideoToolStripMenuItem.Text = "Open Video";
            this.openVideoToolStripMenuItem.Click += new System.EventHandler(this.openVideoToolStripMenuItem_Click);
            // 
            // recordVideoToolStripMenuItem
            // 
            this.recordVideoToolStripMenuItem.Name = "recordVideoToolStripMenuItem";
            this.recordVideoToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.recordVideoToolStripMenuItem.Text = "Record Video";
            this.recordVideoToolStripMenuItem.Click += new System.EventHandler(this.recordVideoToolStripMenuItem_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(149, 6);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // Video_CNTRL
            // 
            this.Video_CNTRL.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Video_CNTRL.Location = new System.Drawing.Point(12, 518);
            this.Video_CNTRL.Name = "Video_CNTRL";
            this.Video_CNTRL.Size = new System.Drawing.Size(737, 45);
            this.Video_CNTRL.TabIndex = 2;
            this.Video_CNTRL.TickStyle = System.Windows.Forms.TickStyle.None;
            this.Video_CNTRL.MouseCaptureChanged += new System.EventHandler(this.Video_CNTRL_MouseCaptureChanged);
            // 
            // play_pause_BTN
            // 
            this.play_pause_BTN.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.play_pause_BTN.BackgroundImage = global::VideoCapture.Properties.Resources.Play;
            this.play_pause_BTN.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.play_pause_BTN.Location = new System.Drawing.Point(344, 546);
            this.play_pause_BTN.Name = "play_pause_BTN";
            this.play_pause_BTN.Size = new System.Drawing.Size(50, 50);
            this.play_pause_BTN.TabIndex = 3;
            this.play_pause_BTN.MouseUp += new System.Windows.Forms.MouseEventHandler(this.play_pause_BTN_MouseUp);
            // 
            // Video_Image
            // 
            this.Video_Image.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Video_Image.Location = new System.Drawing.Point(12, 27);
            this.Video_Image.Name = "Video_Image";
            this.Video_Image.Size = new System.Drawing.Size(737, 485);
            this.Video_Image.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Video_Image.TabIndex = 1;
            this.Video_Image.TabStop = false;
            // 
            // Time_Label
            // 
            this.Time_Label.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.Time_Label.AutoSize = true;
            this.Time_Label.Location = new System.Drawing.Point(588, 546);
            this.Time_Label.Name = "Time_Label";
            this.Time_Label.Size = new System.Drawing.Size(33, 13);
            this.Time_Label.TabIndex = 4;
            this.Time_Label.Text = "Time:";
            // 
            // Frame_lbl
            // 
            this.Frame_lbl.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.Frame_lbl.AutoSize = true;
            this.Frame_lbl.Location = new System.Drawing.Point(588, 566);
            this.Frame_lbl.Name = "Frame_lbl";
            this.Frame_lbl.Size = new System.Drawing.Size(39, 13);
            this.Frame_lbl.TabIndex = 5;
            this.Frame_lbl.Text = "Frame:";
            // 
            // Codec_lbl
            // 
            this.Codec_lbl.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.Codec_lbl.AutoSize = true;
            this.Codec_lbl.Location = new System.Drawing.Point(588, 586);
            this.Codec_lbl.Name = "Codec_lbl";
            this.Codec_lbl.Size = new System.Drawing.Size(41, 13);
            this.Codec_lbl.TabIndex = 6;
            this.Codec_lbl.Text = "Codec:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(761, 616);
            this.Controls.Add(this.Codec_lbl);
            this.Controls.Add(this.Frame_lbl);
            this.Controls.Add(this.Time_Label);
            this.Controls.Add(this.play_pause_BTN);
            this.Controls.Add(this.Video_CNTRL);
            this.Controls.Add(this.Video_Image);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Video_CNTRL)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Video_Image)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.PictureBox Video_Image;
        private System.Windows.Forms.TrackBar Video_CNTRL;
        private System.Windows.Forms.Panel play_pause_BTN;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem openVideoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem recordVideoToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.Label Time_Label;
        private System.Windows.Forms.Label Frame_lbl;
        private System.Windows.Forms.Label Codec_lbl;
    }
}


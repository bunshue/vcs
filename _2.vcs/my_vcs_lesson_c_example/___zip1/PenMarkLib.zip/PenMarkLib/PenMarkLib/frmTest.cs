using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace PenMarkLib
{
	/// <summary>
	/// Form1 ��ժҪ˵����
	/// </summary>
	public class frmTest : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.Button button2;
		private PenMarkControl penMarkControl1;
		private System.Windows.Forms.Button button3;
		private System.Windows.Forms.Button button4;
		private System.Windows.Forms.Button cmdSaveImage;
		/// <summary>
		/// ����������������
		/// </summary>
		private System.ComponentModel.Container components = null;

		public frmTest()
		{
			//
			// Windows ���������֧���������
			//
			InitializeComponent();

			//
			// TODO: �� InitializeComponent ���ú������κι��캯������
			//
		}

		/// <summary>
		/// ������������ʹ�õ���Դ��
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows ������������ɵĴ���
		/// <summary>
		/// �����֧������ķ��� - ��Ҫʹ�ô���༭���޸�
		/// �˷��������ݡ�
		/// </summary>
		private void InitializeComponent()
		{
			this.button1 = new System.Windows.Forms.Button();
			this.button2 = new System.Windows.Forms.Button();
			this.penMarkControl1 = new PenMarkLib.PenMarkControl();
			this.button3 = new System.Windows.Forms.Button();
			this.button4 = new System.Windows.Forms.Button();
			this.cmdSaveImage = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(184, 8);
			this.button1.Name = "button1";
			this.button1.TabIndex = 0;
			this.button1.Text = "��ʼǩ��";
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// button2
			// 
			this.button2.Location = new System.Drawing.Point(272, 8);
			this.button2.Name = "button2";
			this.button2.TabIndex = 1;
			this.button2.Text = "����ǩ��";
			this.button2.Click += new System.EventHandler(this.button2_Click);
			// 
			// penMarkControl1
			// 
			this.penMarkControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.penMarkControl1.AutoScroll = true;
			this.penMarkControl1.AutoScrollMinSize = new System.Drawing.Size(1000, 1000);
			this.penMarkControl1.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(224)), ((System.Byte)(224)), ((System.Byte)(224)));
			this.penMarkControl1.Location = new System.Drawing.Point(8, 40);
			this.penMarkControl1.Name = "penMarkControl1";
			this.penMarkControl1.Size = new System.Drawing.Size(664, 472);
			this.penMarkControl1.TabIndex = 2;
			// 
			// button3
			// 
			this.button3.Location = new System.Drawing.Point(96, 8);
			this.button3.Name = "button3";
			this.button3.TabIndex = 3;
			this.button3.Text = "����";
			this.button3.Click += new System.EventHandler(this.button3_Click);
			// 
			// button4
			// 
			this.button4.Location = new System.Drawing.Point(8, 8);
			this.button4.Name = "button4";
			this.button4.TabIndex = 4;
			this.button4.Text = "����";
			this.button4.Click += new System.EventHandler(this.button4_Click);
			// 
			// cmdSaveImage
			// 
			this.cmdSaveImage.Location = new System.Drawing.Point(360, 8);
			this.cmdSaveImage.Name = "cmdSaveImage";
			this.cmdSaveImage.Size = new System.Drawing.Size(104, 23);
			this.cmdSaveImage.TabIndex = 5;
			this.cmdSaveImage.Text = "����ǩ��ͼƬ";
			this.cmdSaveImage.Click += new System.EventHandler(this.cmdSaveImage_Click);
			// 
			// frmTest
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(6, 14);
			this.ClientSize = new System.Drawing.Size(680, 517);
			this.Controls.Add(this.cmdSaveImage);
			this.Controls.Add(this.button4);
			this.Controls.Add(this.button3);
			this.Controls.Add(this.penMarkControl1);
			this.Controls.Add(this.button2);
			this.Controls.Add(this.button1);
			this.Name = "frmTest";
			this.Text = "Form1";
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// Ӧ�ó��������ڵ㡣
		/// </summary>
		[STAThread]
		static void Main() 
		{
			try
			{
				Application.Run(new frmTest());
			}
			catch( Exception ext )
			{
				MessageBox.Show( ext.ToString());
			}
		}

		private void button1_Click(object sender, System.EventArgs e)
		{
			this.penMarkControl1.BeginMark("aaaaaaa" , 3 );
		}

		private void button2_Click(object sender, System.EventArgs e)
		{
			this.penMarkControl1.EndMark();
		}

		private void button3_Click(object sender, System.EventArgs e)
		{
			using( SaveFileDialog dlg = new SaveFileDialog())
			{
				dlg.Filter = "XML|*.xml";
				dlg.CheckPathExists = true ;
				if( dlg.ShowDialog( this ) == DialogResult.OK )
				{
					this.penMarkControl1.SaveMarks( dlg.FileName );
				}
			}
		}

		private void button4_Click(object sender, System.EventArgs e)
		{
			using( OpenFileDialog dlg = new OpenFileDialog())
			{
				dlg.Filter = "XML|*.xml";
				dlg.CheckFileExists = true ;
				if( dlg.ShowDialog( this ) == DialogResult.OK )
				{
					this.penMarkControl1.LoadMarks( dlg.FileName );
				}
			}
		}

		private void cmdSaveImage_Click(object sender, System.EventArgs e)
		{
			if( this.penMarkControl1.CurrentInfo != null )
			{
				using( SaveFileDialog dlg = new SaveFileDialog())
				{
					dlg.Filter = "BMPͼƬ�ļ�|*.bmp";
					dlg.CheckPathExists = true ;
					dlg.OverwritePrompt = true ;
					if( dlg.ShowDialog( this ) == DialogResult.OK )
					{
						using( System.Drawing.Bitmap bmp = this.penMarkControl1.CurrentInfo.CreateBitmap())
						{
							bmp.Save( dlg.FileName );
						}
					}
				}
			}
		}
	}
}

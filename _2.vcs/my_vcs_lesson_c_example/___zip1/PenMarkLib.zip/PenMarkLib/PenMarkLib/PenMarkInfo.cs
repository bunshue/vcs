using System;
using System.Collections ;
using System.Drawing ;

namespace PenMarkLib
{
	 
	/// <summary>
	/// ǩ����Ϣ����
	/// </summary>
	/// <remarks>���� Ԭ���� 2007-12-27</remarks>
	[System.Serializable()]
	public class PenMarkInfo
	{
		private string strCreator = null;
		/// <summary>
		/// ǩ����
		/// </summary>
		public string Creator 
		{
			get{ return strCreator ;}
			set{ strCreator = value;}
		}

		private DateTime dtmCreationTime = DateTime.MinValue ;
		/// <summary>
		/// ǩ������ʱ��
		/// </summary>
		public DateTime CreationTime
		{
			get{ return dtmCreationTime ;}
			set{ dtmCreationTime = value;}
		}
		
		private System.Drawing.Color intColor = System.Drawing.Color.Red ;
		/// <summary>
		/// ǩ����ɫ
		/// </summary>
		public System.Drawing.Color Color
		{
			get
			{
				return intColor ;
			}
//			set
//			{
//				intColor = value;
//			}
		}

		private int intLineWidth = 3 ;
		/// <summary>
		/// ǩ����������
		/// </summary>
		[System.ComponentModel.DefaultValue( 3 )]
		public int LineWidth
		{
			get{ return intLineWidth ;}
			set{ intLineWidth = value;}
		}

		private ArrayList myLines = new ArrayList() ;
		/// <summary>
		/// ǩ���Ĺ켣��������,���б�Ԫ�������� PointArrayList
		/// </summary>
		[System.Xml.Serialization.XmlArrayItem( typeof( PointArrayList ) , ElementName = "Line")]
		public ArrayList Lines
		{
			get{ return myLines ;}
		}

		/// <summary>
		/// ���ǩ���켣���о���
		/// </summary>
		public System.Drawing.Rectangle Bounds
		{
			get
			{
				System.Drawing.Rectangle rect = System.Drawing.Rectangle.Empty ;
				foreach( PointArrayList line in myLines )
				{
					if( rect.IsEmpty )
						rect = line.Bounds ;
					else
						rect = System.Drawing.Rectangle.Union( rect , line.Bounds );
				}
				rect.Inflate( this.intLineWidth , this.intLineWidth );
				return rect ;
			}
		}
		

/// <summary>
/// ����ǩ��ͼ��
/// </summary>
/// <param name="g">ͼ�λ��ƶ���</param>
/// <param name="ClipRectangle">ǰ�о���</param>
public void Draw( Graphics g , Rectangle ClipRectangle )
{
	using( Pen pen = new Pen( this.Color , this.LineWidth ))
	{
		foreach( PointArrayList line in myLines )
		{
			if( ClipRectangle.IntersectsWith( line.Bounds ))
			{
				g.DrawLines( pen , line.ToArray());
			}
		}
	}
}

/// <summary>
/// ��������ǩ��ͼ�ε�ͼƬ����
/// </summary>
/// <returns>������ͼƬ����</returns>
public Bitmap CreateBitmap()
{
	Rectangle bounds = this.Bounds ;
	Bitmap bmp = new Bitmap( bounds.Width , bounds.Height );
	using( Graphics g = Graphics.FromImage( bmp ))
	{
		g.TranslateTransform( -bounds.Left , -bounds.Top );
		Draw( g , bounds );
	}
	return bmp ;
}
	}//public class MarkInfo
}

﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Windows.Forms;
using 股基.Properties;

namespace 股基
{
    public partial class Form1 : Form
    {
        private readonly WebClient _client = new WebClient();
        private readonly List<Fund> _funds = new List<Fund>();
        private readonly Timer _timer = new Timer();
        private bool _tip;

        public Form1()
        {
            InitializeComponent();
            _client.BaseAddress = Resources.UrlSina;
            InitFunds();
        }

        /// <summary>
        ///     用配置文件信息初始化表
        /// </summary>
        private void InitFunds()
        {
            string[] funds = ConfigurationManager.AppSettings["Funds"].Split(';');

            foreach (string fund in funds)
            {
                InitFund(fund.Split(','));
            }

            dgvFund.DataSource = _funds;
            dgvFund.DataBindingComplete += dgvFund_DataBindingComplete;
        }

        /// <summary>
        ///     初始化单个基金信息
        /// </summary>
        /// <param name="args"></param>
        private void InitFund(string[] args)
        {
            var fund = new Fund
            {
                基金编号 = args[0],
                基金名 = args[1]
            };

            if (args.Length > 2)
            {
                fund.总额 = Convert.ToDouble(args[2]);
                fund.持有份额 = Convert.ToDouble(args[3]);
                fund.起始日期 = Convert.ToDateTime(args[4]);
            }

            _funds.Add(fund);
            InitOldFund(fund);
            UpdateFund(fund);
        }

        /// <summary>
        ///     更新基金预估信息
        /// </summary>
        private void UpdateFunds()
        {
            _funds.ForEach(UpdateFund);
            dgvFund.Refresh();
            AlterCellColor();

            #region 下午2点半后预估有股基大跌时提醒是否购买

            if (DateTime.Now.Hour == 14 && DateTime.Now.Minute >= 30 && !_tip && _funds.Exists(o => o.预估升率 < -2))
            {
                _tip = true;
                Activate();
                MessageBox.Show(Resources.RemindBuy);
            }

            #endregion
        }

        /// <summary>
        ///     更新单个基金信息
        /// </summary>
        /// <param name="fund">基金信息</param>
        private void UpdateFund(Fund fund)
        {
            string data = _client.DownloadString(Resources.UrlSinaFund + fund.基金编号);
            string[] datas = data.Split(',');
            fund.更新时间 = datas[1];
            fund.今日估值 = Convert.ToDouble(datas[2]);
            //fund.最新净值 = Convert.ToDouble(datas[3]);
            fund.预估升率 = Convert.ToDouble(datas[6]);
            fund.预估收益 = fund.持有份额 * (fund.今日估值 - fund.最新净值);
        }

        //private void InitOldFunds()
        //{
        //    _funds.ForEach(InitOldFund);
        //}

        /// <summary>
        ///     初始化基金前两次的净值信息
        /// </summary>
        /// <param name="fund"></param>
        private void InitOldFund(Fund fund)
        {
            string data = _client.DownloadString(Resources.UrlSinaOldFund + fund.基金编号);
            string[] datas = data.Split(',');
            fund.最新净值 = Convert.ToDouble(datas[1]);
            fund.昨日净值 = Convert.ToDouble(datas[3]);
            fund.最新升率 = (fund.最新净值 - fund.昨日净值) * 100 / fund.昨日净值;
            if (fund.总额 <= 0) return;
            double money = fund.最新净值 * fund.持有份额 - fund.总额;
            fund.历史收益 = money;
            fund.昨日收益 = fund.持有份额 * (fund.最新净值 - fund.昨日净值);
            var days = (int) DateTime.Now.Subtract(fund.起始日期).TotalDays;

            if (days > 0)
            {
                fund.日均万份收益 = money*10000/days/fund.总额;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            UpdateFunds();
        }

        private void _timer_Tick(object sender, EventArgs e)
        {
            UpdateFunds();
        }

        private void dgvFund_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex == -1)
            {
                return;
            }

            switch (e.ColumnIndex)
            {
                case 0:
                    Process.Start(string.Format(Resources.UrlGoSina, _funds[e.RowIndex].基金编号));
                    break;
                case 1:
                    Process.Start(string.Format(Resources.UrlGoHexun, _funds[e.RowIndex].基金编号));
                    break;
            }
        }

        private void dgvFund_DataBindingComplete(object sender, DataGridViewBindingCompleteEventArgs e)
        {
            AlterOldCellColor();
            AlterCellColor();
            dgvFund.Columns[1].Width = 120;
        }

        /// <summary>
        ///     更新“最新升率”列颜色
        /// </summary>
        private void AlterOldCellColor()
        {
            for (int i = 0; i < _funds.Count; i++)
            {
                Color color;

                if (_funds[i].最新升率 > 0)
                {
                    color = Color.Red;
                }
                else if (_funds[i].最新升率 < 0)
                {
                    color = Color.Green;
                }
                else
                {
                    color = Color.Gray;
                }

                dgvFund.Rows[i].Cells[7].Style.BackColor = color;
            }
        }

        /// <summary>
        ///     更新“预估升率”列颜色
        /// </summary>
        private void AlterCellColor()
        {
            for (int i = 0; i < _funds.Count; i++)
            {
                Color color;

                if (_funds[i].预估升率 > 0)
                {
                    color = Color.Red;
                }
                else if (_funds[i].预估升率 < 0)
                {
                    color = Color.Green;
                }
                else
                {
                    color = Color.Gray;
                }

                dgvFund.Rows[i].Cells[3].Style.BackColor = color;
            }
        }

        private void btnYesterdayEarn_Click(object sender, EventArgs e)
        {
            MessageBox.Show(string.Format("昨日总收益{0}元", _funds.Sum(o => o.昨日收益).ToString("F")));
        }

        private void btnTodayEarn_Click(object sender, EventArgs e)
        {
            MessageBox.Show(string.Format("预测今日总收益{0}元", _funds.Sum(o => o.预估收益).ToString("F")));
        }

        private void btnTotalEarn_Click(object sender, EventArgs e)
        {
            MessageBox.Show(string.Format("历史总收益{0}元", _funds.Sum(o => o.历史收益).ToString("F")));
        }

        protected override void OnLoad(EventArgs e)
        {
            _timer.Interval = Convert.ToInt32(ConfigurationManager.AppSettings["RefreshTime"]);
            _timer.Tick += _timer_Tick;
            _timer.Start();
            dgvFund.CellClick += dgvFund_CellClick;
            base.OnLoad(e);
        }
    }
}
﻿using System;

namespace 股基
{
    public class Fund
    {
        public string 基金编号 { get; set; }

        public string 基金名 { get; set; }

        public double 今日估值 { get; set; }

        public double 预估升率 { get; set; }

        public double 预估收益 { get; set; }

        public double 日均万份收益 { get; set; }

        public double 最新净值 { get; set; }

        public double 最新升率 { get; set; }

        public double 昨日净值 { get; set; }

        //public double 购买净值 { get; set; }

        public double 总额 { get; set; }

        //public double 手续费 { get; set; }

        //public double 赎回费 { get; set; }

        //public double 管理费 { get; set; }

        public double 昨日收益 { get; set; }

        public double 历史收益 { get; set; }

        //public double 总升率 { get; set; }

        public string 更新时间 { get; set; }

        public DateTime 起始日期 { get; set; }

        public double 持有份额 { get; set; }

        //public double 预估误差 { get; set; }
    }
}
﻿namespace 股基
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgvFund = new System.Windows.Forms.DataGridView();
            this.btnRefresh = new System.Windows.Forms.Button();
            this.btnTodayEarn = new System.Windows.Forms.Button();
            this.btnYesterdayEarn = new System.Windows.Forms.Button();
            this.btnTotalEarn = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvFund)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvFund
            // 
            this.dgvFund.AllowUserToAddRows = false;
            this.dgvFund.AllowUserToDeleteRows = false;
            this.dgvFund.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvFund.CausesValidation = false;
            this.dgvFund.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableAlwaysIncludeHeaderText;
            this.dgvFund.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvFund.Location = new System.Drawing.Point(12, 12);
            this.dgvFund.Name = "dgvFund";
            this.dgvFund.ReadOnly = true;
            this.dgvFund.RowTemplate.Height = 23;
            this.dgvFund.ShowCellErrors = false;
            this.dgvFund.ShowCellToolTips = false;
            this.dgvFund.ShowEditingIcon = false;
            this.dgvFund.ShowRowErrors = false;
            this.dgvFund.Size = new System.Drawing.Size(1033, 358);
            this.dgvFund.TabIndex = 0;
            // 
            // btnRefresh
            // 
            this.btnRefresh.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnRefresh.Location = new System.Drawing.Point(964, 376);
            this.btnRefresh.Name = "btnRefresh";
            this.btnRefresh.Size = new System.Drawing.Size(81, 33);
            this.btnRefresh.TabIndex = 1;
            this.btnRefresh.Text = "刷新";
            this.btnRefresh.UseVisualStyleBackColor = true;
            this.btnRefresh.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnTodayEarn
            // 
            this.btnTodayEarn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnTodayEarn.Location = new System.Drawing.Point(99, 376);
            this.btnTodayEarn.Name = "btnTodayEarn";
            this.btnTodayEarn.Size = new System.Drawing.Size(99, 33);
            this.btnTodayEarn.TabIndex = 2;
            this.btnTodayEarn.Text = "预测今日总收益";
            this.btnTodayEarn.UseVisualStyleBackColor = true;
            this.btnTodayEarn.Click += new System.EventHandler(this.btnTodayEarn_Click);
            // 
            // btnYesterdayEarn
            // 
            this.btnYesterdayEarn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnYesterdayEarn.Location = new System.Drawing.Point(12, 376);
            this.btnYesterdayEarn.Name = "btnYesterdayEarn";
            this.btnYesterdayEarn.Size = new System.Drawing.Size(81, 33);
            this.btnYesterdayEarn.TabIndex = 3;
            this.btnYesterdayEarn.Text = "昨日总收益";
            this.btnYesterdayEarn.UseVisualStyleBackColor = true;
            this.btnYesterdayEarn.Click += new System.EventHandler(this.btnYesterdayEarn_Click);
            // 
            // btnTotalEarn
            // 
            this.btnTotalEarn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnTotalEarn.Location = new System.Drawing.Point(204, 376);
            this.btnTotalEarn.Name = "btnTotalEarn";
            this.btnTotalEarn.Size = new System.Drawing.Size(81, 33);
            this.btnTotalEarn.TabIndex = 4;
            this.btnTotalEarn.Text = "历史总收益";
            this.btnTotalEarn.UseVisualStyleBackColor = true;
            this.btnTotalEarn.Click += new System.EventHandler(this.btnTotalEarn_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoValidate = System.Windows.Forms.AutoValidate.Disable;
            this.CausesValidation = false;
            this.ClientSize = new System.Drawing.Size(1057, 421);
            this.Controls.Add(this.btnTotalEarn);
            this.Controls.Add(this.btnYesterdayEarn);
            this.Controls.Add(this.btnTodayEarn);
            this.Controls.Add(this.btnRefresh);
            this.Controls.Add(this.dgvFund);
            this.Name = "Form1";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "股基小助手";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            ((System.ComponentModel.ISupportInitialize)(this.dgvFund)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvFund;
        private System.Windows.Forms.Button btnRefresh;
        private System.Windows.Forms.Button btnTodayEarn;
        private System.Windows.Forms.Button btnYesterdayEarn;
        private System.Windows.Forms.Button btnTotalEarn;
    }
}


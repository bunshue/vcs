﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using GMap.NET.WindowsPresentation;

namespace GMapWPFDemo
{
    class MapControl : GMapControl
    {
    }
}

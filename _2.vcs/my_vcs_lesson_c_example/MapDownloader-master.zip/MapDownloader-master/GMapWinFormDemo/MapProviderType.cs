﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GMapWinFormDemo
{
    public enum MapProviderType
    {
        google,
        amap,
        tengxun,
        bing,
        baidu
    }

    public enum MapType
    {
        Common,
        Satellite
    }
}

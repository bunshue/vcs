﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RabbitMQClient
{
    public static class CfgFaced
    {
        public static RabbitMqCfg RabbitMqCfg { set; get; }
    }
}

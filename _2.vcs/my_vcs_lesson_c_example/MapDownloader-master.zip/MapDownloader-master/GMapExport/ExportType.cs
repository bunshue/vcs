﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GMapExport
{
    public enum ExportType
    {
        DefaultXYTile,
        DefaultYXTile,
        ArcGISTile,
        TMSTile,
        BaiduTile
    }
}

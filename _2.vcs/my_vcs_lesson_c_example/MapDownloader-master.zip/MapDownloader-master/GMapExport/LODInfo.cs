﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GMapExport
{
    public class LODInfo
    {
        // Methods
        public LODInfo()
        {
        }

        // Properties
        public int LevelID { get; set; }

        public double Resolution { get; set; }

        public double Scale { get; set; }
    }

 

}

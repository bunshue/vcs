﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GMapHeat
{
    public class HeatPoint
    {
        public float X;
        public float Y;
        public float W;
    }
}

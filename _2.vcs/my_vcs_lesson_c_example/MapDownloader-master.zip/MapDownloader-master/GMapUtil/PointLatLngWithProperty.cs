﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using GMap.NET;

namespace GMapUtil
{
    public class PointLatLngWithProperty
    {
        // Fields
        public PointLatLng Point;
        public Dictionary<string, string> Properties;

        // Methods
        public PointLatLngWithProperty()
        {
        }
    }
}

public enum HullColors {
	Red,
	White
}


using System;


public enum ShipState {
	Normal,
	Dying, 
	Dead,
	Hyper,
	HyperCharge,
};



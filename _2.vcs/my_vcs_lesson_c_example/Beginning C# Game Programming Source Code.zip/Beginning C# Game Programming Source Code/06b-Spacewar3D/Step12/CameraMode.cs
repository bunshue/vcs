using System;


public enum CameraMode {
	ChaseMode,
	CockpitMode,
	Fixed
};


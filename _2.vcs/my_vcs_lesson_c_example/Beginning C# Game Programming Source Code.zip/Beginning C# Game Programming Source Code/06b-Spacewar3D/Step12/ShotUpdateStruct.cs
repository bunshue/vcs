using System;
using Microsoft.DirectX;


public struct ShotUpdate {
	public Vector3[] ShotPosition;
	public float[] ShotAge;
	public bool [] ShotAlive;
}

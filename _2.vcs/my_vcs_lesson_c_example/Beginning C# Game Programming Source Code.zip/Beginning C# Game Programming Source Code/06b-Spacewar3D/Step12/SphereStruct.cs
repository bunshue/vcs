using Microsoft.DirectX;

public struct Sphere {
	public Vector3 CenterPoint;
	public float Radius;
};
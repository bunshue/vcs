namespace SpaceDonuts {
	/// <summary>
	/// Summary description for PyramidSprite.
	/// </summary>
	public class PyramidSprite : BasicSprite {
		public PyramidSprite(TileSet ts) : base(ts) {}
	}
}
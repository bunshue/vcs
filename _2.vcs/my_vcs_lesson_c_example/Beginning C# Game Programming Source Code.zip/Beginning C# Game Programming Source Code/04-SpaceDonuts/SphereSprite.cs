namespace SpaceDonuts {
	/// <summary>
	/// Summary description for SphereSprite.
	/// </summary>
	public class SphereSprite : BasicSprite {
		public SphereSprite(TileSet ts) : base(ts) {}
	}
}
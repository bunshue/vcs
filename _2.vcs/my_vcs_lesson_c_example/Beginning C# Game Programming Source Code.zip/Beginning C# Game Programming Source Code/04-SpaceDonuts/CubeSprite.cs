namespace SpaceDonuts {
	/// <summary>
	/// Summary description for CubeSprite.
	/// </summary>
	public class CubeSprite : BasicSprite {
		public CubeSprite(TileSet ts) : base(ts) {}
	}
}
namespace SpaceDonuts {
	/// <summary>
	/// Summary description for DonutSprite.
	/// </summary>
	public class DonutSprite : BasicSprite {
		public DonutSprite(TileSet ts) : base(ts) {}
	}
}
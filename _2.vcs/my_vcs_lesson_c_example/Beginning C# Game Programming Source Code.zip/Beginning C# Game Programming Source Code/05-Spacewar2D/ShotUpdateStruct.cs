using System;
using Microsoft.DirectX;


public struct ShotUpdate {
	public Vector2[] ShotPosition;
	public int[] ShotAge;
}

using System;

public struct LocalPlayer {
	public int ID;
	public string Name;
	public LocalPlayer(int id, string n) {
		  ID = id; Name = n; }
}       

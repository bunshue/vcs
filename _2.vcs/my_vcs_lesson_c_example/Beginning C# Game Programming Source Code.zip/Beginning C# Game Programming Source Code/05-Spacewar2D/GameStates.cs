using System;

public enum GameStates {
	Loading,
	Running,
	Config,
	Paused,
	HelpScreen,
	Exiting
}
		
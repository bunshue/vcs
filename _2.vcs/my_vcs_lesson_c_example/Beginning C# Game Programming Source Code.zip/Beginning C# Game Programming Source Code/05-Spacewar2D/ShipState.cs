using System;

namespace SpaceWar {
	public enum ShipState {
		Normal,
		Dying, 
		Dead,
		Hyper,
		HyperCharge,
	};

}

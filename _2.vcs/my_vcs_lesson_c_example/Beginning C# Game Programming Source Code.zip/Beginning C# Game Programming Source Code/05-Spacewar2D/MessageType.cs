using System;

public enum MessageType {
	PlayerUpdateID,
	GameParamUpdateID,
	GamePaused,
	GameRunning,
	Add1ToScore,
	Add2ToScore
}
using System;
using System.Reflection;
using System.Security;
using System.Security.Permissions;
using System.Runtime.InteropServices;

[assembly:CLSCompliant(false)]
[assembly: AssemblyVersionAttribute("1.0.14.1")]
[assembly:FileIOPermission(SecurityAction.RequestMinimum)]
[assembly:ComVisible(false)]


﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CSharp_DrawLine
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //----textbox事件----
            foreach (Control ctrl in Controls)
            {
                if (ctrl.GetType().Name == "TextBox")
                {
                    ctrl.Enter += TextBox_Enter;
                    ctrl.MouseClick += TextBox_Enter;
                }
            }
        }
        //----選到textbox時，選取全部文字
        private void TextBox_Enter(object sender, EventArgs e)
        {
            TextBox tb = sender as TextBox;
            tb.SelectAll();
        }

        float x0, x1, y0, y1;
        float ratio_x, ratio_y;
        float wid, hei;
        Bitmap bmp;
        Graphics g;
        Pen pen;
        SolidBrush brush;

        private void draw_btn_Click(object sender, EventArgs e)
        {
            try
            {
                //----畫筆顏色----
                pen = new Pen(Color.Black);
                brush = new SolidBrush(pen.Color);
                //----取得picturebox寬度與高度----
                wid = pictureBox1.Width;
                hei = pictureBox1.Height;
                //----是否有上一次的圖片，如果有就清除----
                if (pictureBox1.Image != null)
                    pictureBox1.Image = null;
                if (bmp != null)
                    bmp.Dispose();
                //----轉換使用者輸入的資料----
                x0 = float.Parse(x0_tb.Text);
                y0 = float.Parse(y0_tb.Text);
                x1 = float.Parse(x1_tb.Text);
                y1 = float.Parse(y1_tb.Text);
                //----計算放大倍率----
                ratio_x = (wid - 50) / 20;
                ratio_y = (hei - 50) / 20;
                //----開新的Bitmap----
                bmp = new Bitmap((int)wid, (int)hei);
                //----使用上面的Bitmap畫圖----
                g = Graphics.FromImage(bmp);
                //----清除Bitmap為某顏色----
                g.Clear(Color.White);
                //----更改原點位置----
                g.TranslateTransform(pictureBox1.Width / 2, pictureBox1.Height / 2);
                //----畫坐標軸----
                g.DrawLine(pen, -1000, 0, 1000, 0);//x軸
                g.DrawLine(pen, 0, -1000, 0, 1000);//y軸
                g.DrawString("X", this.Font, brush, wid / 2 - 20, 20);
                g.DrawString("Y", this.Font, brush, 20, -hei / 2);
                g.DrawLine(pen, wid / 2, 0, wid / 2 - 10, 5);//x軸箭頭
                g.DrawLine(pen, wid / 2, 0, wid / 2 - 10, -5);
                g.DrawLine(pen, 0, -hei / 2, 5, -hei / 2 + 10);//y軸箭頭
                g.DrawLine(pen, 0, -hei / 2, -5, -hei / 2 + 10);
                for (int i = -10; i <= 10; i++)//畫X Y軸座標位置
                {
                    g.DrawLine(pen, i * ratio_x, -5, i * ratio_x, 5);
                    g.DrawString(i.ToString().PadLeft(2, ' '), this.Font, brush, i * ratio_x - 9, 10);
                    g.DrawLine(pen, -5, i * ratio_y, 5, i * ratio_y);
                    if (i != 0)
                        g.DrawString(i.ToString(), this.Font, brush, 15, i * ratio_y - 8);
                }
                //----換顏色----
                pen = new Pen(Color.Red);
                brush = new SolidBrush(pen.Color);
                //----畫線----
                g.DrawLine(pen, x0 * ratio_x, -y0 * ratio_y, x1 * ratio_x, -y1 * ratio_y);
                //----畫兩點----
                g.FillEllipse(brush, new RectangleF(x0 * ratio_x - 2.5f, -y0 * ratio_y - 2.5f, 5, 5));
                g.FillEllipse(brush, new RectangleF(x1 * ratio_x - 2.5f, -y1 * ratio_y - 2.5f, 5, 5));
                //----釋放Graphics資源----
                g.Dispose();
                //----將Bitmap顯示在Picture上
                pictureBox1.Image = bmp;
            }
            catch (Exception x)
            {
                MessageBox.Show(x.Message);//錯誤視窗
            }
            finally
            {
                GC.Collect();//清除垃圾
            }
        }
    }
}

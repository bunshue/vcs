﻿namespace CSharp_DrawLine
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.x0_tb = new System.Windows.Forms.TextBox();
            this.y0_tb = new System.Windows.Forms.TextBox();
            this.x1_tb = new System.Windows.Forms.TextBox();
            this.y1_tb = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.draw_btn = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(12, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(623, 623);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // x0_tb
            // 
            this.x0_tb.Location = new System.Drawing.Point(672, 12);
            this.x0_tb.Name = "x0_tb";
            this.x0_tb.Size = new System.Drawing.Size(100, 22);
            this.x0_tb.TabIndex = 1;
            // 
            // y0_tb
            // 
            this.y0_tb.Location = new System.Drawing.Point(672, 40);
            this.y0_tb.Name = "y0_tb";
            this.y0_tb.Size = new System.Drawing.Size(100, 22);
            this.y0_tb.TabIndex = 2;
            // 
            // x1_tb
            // 
            this.x1_tb.Location = new System.Drawing.Point(672, 68);
            this.x1_tb.Name = "x1_tb";
            this.x1_tb.Size = new System.Drawing.Size(100, 22);
            this.x1_tb.TabIndex = 3;
            // 
            // y1_tb
            // 
            this.y1_tb.Location = new System.Drawing.Point(672, 96);
            this.y1_tb.Name = "y1_tb";
            this.y1_tb.Size = new System.Drawing.Size(100, 22);
            this.y1_tb.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(641, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(25, 12);
            this.label1.TabIndex = 5;
            this.label1.Text = "X0=";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(641, 78);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(25, 12);
            this.label2.TabIndex = 6;
            this.label2.Text = "X1=";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(641, 50);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(25, 12);
            this.label3.TabIndex = 7;
            this.label3.Text = "Y0=";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(641, 106);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(25, 12);
            this.label4.TabIndex = 8;
            this.label4.Text = "Y1=";
            // 
            // draw_btn
            // 
            this.draw_btn.Location = new System.Drawing.Point(643, 136);
            this.draw_btn.Name = "draw_btn";
            this.draw_btn.Size = new System.Drawing.Size(129, 23);
            this.draw_btn.TabIndex = 9;
            this.draw_btn.Text = "DraeLine";
            this.draw_btn.UseVisualStyleBackColor = true;
            this.draw_btn.Click += new System.EventHandler(this.draw_btn_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(649, 121);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(118, 12);
            this.label5.TabIndex = 10;
            this.label5.Text = "X,Y顯示範圍為-10~10";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(784, 648);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.draw_btn);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.y1_tb);
            this.Controls.Add(this.x1_tb);
            this.Controls.Add(this.y0_tb);
            this.Controls.Add(this.x0_tb);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox x0_tb;
        private System.Windows.Forms.TextBox y0_tb;
        private System.Windows.Forms.TextBox x1_tb;
        private System.Windows.Forms.TextBox y1_tb;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button draw_btn;
        private System.Windows.Forms.Label label5;
    }
}


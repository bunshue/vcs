﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Dynamic;

namespace Ivony.Web.Html.Dynamic
{
  public class ElementDynamic : DynamicObject
  {
  }
}

namespace MessageBoxApplication
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.DefaultButton2 = new System.Windows.Forms.RadioButton();
            this.Button3 = new System.Windows.Forms.RadioButton();
            this.DefaultButton1 = new System.Windows.Forms.RadioButton();
            this.grpDefaultButton = new System.Windows.Forms.GroupBox();
            this.DefaultButton3 = new System.Windows.Forms.RadioButton();
            this.txtCaption = new System.Windows.Forms.TextBox();
            this.Button2 = new System.Windows.Forms.RadioButton();
            this.Label2 = new System.Windows.Forms.Label();
            this.Button1 = new System.Windows.Forms.RadioButton();
            this.btnShow = new System.Windows.Forms.Button();
            this.txtMsg = new System.Windows.Forms.TextBox();
            this.Label1 = new System.Windows.Forms.Label();
            this.GroupBox2 = new System.Windows.Forms.GroupBox();
            this.Button6 = new System.Windows.Forms.RadioButton();
            this.Button5 = new System.Windows.Forms.RadioButton();
            this.Button4 = new System.Windows.Forms.RadioButton();
            this.lblResult = new System.Windows.Forms.Label();
            this.GroupBox1 = new System.Windows.Forms.GroupBox();
            this.Icon8 = new System.Windows.Forms.RadioButton();
            this.Icon7 = new System.Windows.Forms.RadioButton();
            this.Icon6 = new System.Windows.Forms.RadioButton();
            this.Icon5 = new System.Windows.Forms.RadioButton();
            this.Icon4 = new System.Windows.Forms.RadioButton();
            this.Icon3 = new System.Windows.Forms.RadioButton();
            this.Icon2 = new System.Windows.Forms.RadioButton();
            this.Icon1 = new System.Windows.Forms.RadioButton();
            this.txtResult = new System.Windows.Forms.TextBox();
            this.grpDefaultButton.SuspendLayout();
            this.GroupBox2.SuspendLayout();
            this.GroupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // DefaultButton2
            // 
            this.DefaultButton2.Location = new System.Drawing.Point(12, 44);
            this.DefaultButton2.Name = "DefaultButton2";
            this.DefaultButton2.Size = new System.Drawing.Size(100, 20);
            this.DefaultButton2.TabIndex = 1;
            this.DefaultButton2.Text = "DefaultButton2";
            // 
            // Button3
            // 
            this.Button3.Location = new System.Drawing.Point(12, 65);
            this.Button3.Name = "Button3";
            this.Button3.Size = new System.Drawing.Size(100, 18);
            this.Button3.TabIndex = 2;
            this.Button3.Text = "OKCancel";
            // 
            // DefaultButton1
            // 
            this.DefaultButton1.Checked = true;
            this.DefaultButton1.Location = new System.Drawing.Point(12, 20);
            this.DefaultButton1.Name = "DefaultButton1";
            this.DefaultButton1.Size = new System.Drawing.Size(100, 20);
            this.DefaultButton1.TabIndex = 0;
            this.DefaultButton1.TabStop = true;
            this.DefaultButton1.Text = "DefaultButton1";
            // 
            // grpDefaultButton
            // 
            this.grpDefaultButton.Controls.Add(this.DefaultButton3);
            this.grpDefaultButton.Controls.Add(this.DefaultButton2);
            this.grpDefaultButton.Controls.Add(this.DefaultButton1);
            this.grpDefaultButton.Location = new System.Drawing.Point(205, 74);
            this.grpDefaultButton.Name = "grpDefaultButton";
            this.grpDefaultButton.Size = new System.Drawing.Size(144, 124);
            this.grpDefaultButton.TabIndex = 33;
            this.grpDefaultButton.TabStop = false;
            this.grpDefaultButton.Text = "Default Button";
            // 
            // DefaultButton3
            // 
            this.DefaultButton3.Location = new System.Drawing.Point(12, 68);
            this.DefaultButton3.Name = "DefaultButton3";
            this.DefaultButton3.Size = new System.Drawing.Size(100, 20);
            this.DefaultButton3.TabIndex = 2;
            this.DefaultButton3.Text = "DefaultButton3";
            // 
            // txtCaption
            // 
            this.txtCaption.Location = new System.Drawing.Point(65, 38);
            this.txtCaption.Name = "txtCaption";
            this.txtCaption.Size = new System.Drawing.Size(200, 22);
            this.txtCaption.TabIndex = 30;
            // 
            // Button2
            // 
            this.Button2.Location = new System.Drawing.Point(12, 43);
            this.Button2.Name = "Button2";
            this.Button2.Size = new System.Drawing.Size(100, 19);
            this.Button2.TabIndex = 1;
            this.Button2.Text = "OK";
            // 
            // Label2
            // 
            this.Label2.Location = new System.Drawing.Point(9, 42);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(60, 16);
            this.Label2.TabIndex = 36;
            this.Label2.Text = "Caption:";
            // 
            // Button1
            // 
            this.Button1.Location = new System.Drawing.Point(12, 20);
            this.Button1.Name = "Button1";
            this.Button1.Size = new System.Drawing.Size(112, 20);
            this.Button1.TabIndex = 0;
            this.Button1.Text = "AbortRetryIgnore";
            // 
            // btnShow
            // 
            this.btnShow.Location = new System.Drawing.Point(277, 10);
            this.btnShow.Name = "btnShow";
            this.btnShow.Size = new System.Drawing.Size(76, 24);
            this.btnShow.TabIndex = 34;
            this.btnShow.Text = "Show";
            this.btnShow.Click += new System.EventHandler(this.btnShow_Click);
            // 
            // txtMsg
            // 
            this.txtMsg.Location = new System.Drawing.Point(65, 10);
            this.txtMsg.Name = "txtMsg";
            this.txtMsg.Size = new System.Drawing.Size(200, 22);
            this.txtMsg.TabIndex = 29;
            // 
            // Label1
            // 
            this.Label1.Location = new System.Drawing.Point(9, 14);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(60, 16);
            this.Label1.TabIndex = 35;
            this.Label1.Text = "Message:";
            // 
            // GroupBox2
            // 
            this.GroupBox2.Controls.Add(this.Button6);
            this.GroupBox2.Controls.Add(this.Button5);
            this.GroupBox2.Controls.Add(this.Button4);
            this.GroupBox2.Controls.Add(this.Button3);
            this.GroupBox2.Controls.Add(this.Button2);
            this.GroupBox2.Controls.Add(this.Button1);
            this.GroupBox2.Location = new System.Drawing.Point(9, 202);
            this.GroupBox2.Name = "GroupBox2";
            this.GroupBox2.Size = new System.Drawing.Size(188, 160);
            this.GroupBox2.TabIndex = 32;
            this.GroupBox2.TabStop = false;
            this.GroupBox2.Text = "Buttons";
            // 
            // Button6
            // 
            this.Button6.Location = new System.Drawing.Point(12, 133);
            this.Button6.Name = "Button6";
            this.Button6.Size = new System.Drawing.Size(100, 19);
            this.Button6.TabIndex = 5;
            this.Button6.Text = "YesNoCancel";
            // 
            // Button5
            // 
            this.Button5.Checked = true;
            this.Button5.Location = new System.Drawing.Point(12, 110);
            this.Button5.Name = "Button5";
            this.Button5.Size = new System.Drawing.Size(100, 20);
            this.Button5.TabIndex = 4;
            this.Button5.TabStop = true;
            this.Button5.Text = "YesNo";
            // 
            // Button4
            // 
            this.Button4.Location = new System.Drawing.Point(12, 86);
            this.Button4.Name = "Button4";
            this.Button4.Size = new System.Drawing.Size(100, 21);
            this.Button4.TabIndex = 3;
            this.Button4.Text = "RetryCancel";
            // 
            // lblResult
            // 
            this.lblResult.Location = new System.Drawing.Point(209, 210);
            this.lblResult.Name = "lblResult";
            this.lblResult.Size = new System.Drawing.Size(56, 20);
            this.lblResult.TabIndex = 37;
            this.lblResult.Text = "Result";
            // 
            // GroupBox1
            // 
            this.GroupBox1.Controls.Add(this.Icon8);
            this.GroupBox1.Controls.Add(this.Icon7);
            this.GroupBox1.Controls.Add(this.Icon6);
            this.GroupBox1.Controls.Add(this.Icon5);
            this.GroupBox1.Controls.Add(this.Icon4);
            this.GroupBox1.Controls.Add(this.Icon3);
            this.GroupBox1.Controls.Add(this.Icon2);
            this.GroupBox1.Controls.Add(this.Icon1);
            this.GroupBox1.Location = new System.Drawing.Point(9, 74);
            this.GroupBox1.Name = "GroupBox1";
            this.GroupBox1.Size = new System.Drawing.Size(188, 124);
            this.GroupBox1.TabIndex = 31;
            this.GroupBox1.TabStop = false;
            this.GroupBox1.Text = "Icon";
            // 
            // Icon8
            // 
            this.Icon8.Location = new System.Drawing.Point(100, 92);
            this.Icon8.Name = "Icon8";
            this.Icon8.Size = new System.Drawing.Size(64, 20);
            this.Icon8.TabIndex = 7;
            this.Icon8.Text = "Warning";
            // 
            // Icon7
            // 
            this.Icon7.Location = new System.Drawing.Point(12, 92);
            this.Icon7.Name = "Icon7";
            this.Icon7.Size = new System.Drawing.Size(84, 20);
            this.Icon7.TabIndex = 6;
            this.Icon7.Text = "Stop";
            // 
            // Icon6
            // 
            this.Icon6.Location = new System.Drawing.Point(100, 68);
            this.Icon6.Name = "Icon6";
            this.Icon6.Size = new System.Drawing.Size(64, 20);
            this.Icon6.TabIndex = 5;
            this.Icon6.Text = "Question";
            // 
            // Icon5
            // 
            this.Icon5.Checked = true;
            this.Icon5.Location = new System.Drawing.Point(12, 68);
            this.Icon5.Name = "Icon5";
            this.Icon5.Size = new System.Drawing.Size(84, 20);
            this.Icon5.TabIndex = 4;
            this.Icon5.TabStop = true;
            this.Icon5.Text = "Information";
            // 
            // Icon4
            // 
            this.Icon4.Location = new System.Drawing.Point(100, 44);
            this.Icon4.Name = "Icon4";
            this.Icon4.Size = new System.Drawing.Size(64, 20);
            this.Icon4.TabIndex = 3;
            this.Icon4.Text = "Hand";
            // 
            // Icon3
            // 
            this.Icon3.Location = new System.Drawing.Point(12, 44);
            this.Icon3.Name = "Icon3";
            this.Icon3.Size = new System.Drawing.Size(84, 20);
            this.Icon3.TabIndex = 2;
            this.Icon3.Text = "Exclamation";
            // 
            // Icon2
            // 
            this.Icon2.Location = new System.Drawing.Point(100, 20);
            this.Icon2.Name = "Icon2";
            this.Icon2.Size = new System.Drawing.Size(64, 20);
            this.Icon2.TabIndex = 1;
            this.Icon2.Text = "Error";
            // 
            // Icon1
            // 
            this.Icon1.Location = new System.Drawing.Point(12, 20);
            this.Icon1.Name = "Icon1";
            this.Icon1.Size = new System.Drawing.Size(84, 20);
            this.Icon1.TabIndex = 0;
            this.Icon1.Text = "Asterisk";
            // 
            // txtResult
            // 
            this.txtResult.Enabled = false;
            this.txtResult.Location = new System.Drawing.Point(209, 234);
            this.txtResult.Name = "txtResult";
            this.txtResult.Size = new System.Drawing.Size(136, 22);
            this.txtResult.TabIndex = 38;
            // 
            // Form1
            // 
            this.AcceptButton = this.btnShow;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(362, 373);
            this.Controls.Add(this.grpDefaultButton);
            this.Controls.Add(this.txtCaption);
            this.Controls.Add(this.Label2);
            this.Controls.Add(this.btnShow);
            this.Controls.Add(this.txtMsg);
            this.Controls.Add(this.Label1);
            this.Controls.Add(this.GroupBox2);
            this.Controls.Add(this.lblResult);
            this.Controls.Add(this.GroupBox1);
            this.Controls.Add(this.txtResult);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "MessageBox Application";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.grpDefaultButton.ResumeLayout(false);
            this.GroupBox2.ResumeLayout(false);
            this.GroupBox1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.RadioButton DefaultButton2;
        internal System.Windows.Forms.RadioButton Button3;
        internal System.Windows.Forms.RadioButton DefaultButton1;
        internal System.Windows.Forms.GroupBox grpDefaultButton;
        internal System.Windows.Forms.RadioButton DefaultButton3;
        internal System.Windows.Forms.TextBox txtCaption;
        internal System.Windows.Forms.RadioButton Button2;
        internal System.Windows.Forms.Label Label2;
        internal System.Windows.Forms.RadioButton Button1;
        internal System.Windows.Forms.Button btnShow;
        internal System.Windows.Forms.TextBox txtMsg;
        internal System.Windows.Forms.Label Label1;
        internal System.Windows.Forms.GroupBox GroupBox2;
        internal System.Windows.Forms.RadioButton Button6;
        internal System.Windows.Forms.RadioButton Button5;
        internal System.Windows.Forms.RadioButton Button4;
        internal System.Windows.Forms.Label lblResult;
        internal System.Windows.Forms.GroupBox GroupBox1;
        internal System.Windows.Forms.RadioButton Icon8;
        internal System.Windows.Forms.RadioButton Icon7;
        internal System.Windows.Forms.RadioButton Icon6;
        internal System.Windows.Forms.RadioButton Icon5;
        internal System.Windows.Forms.RadioButton Icon4;
        internal System.Windows.Forms.RadioButton Icon3;
        internal System.Windows.Forms.RadioButton Icon2;
        internal System.Windows.Forms.RadioButton Icon1;
        internal System.Windows.Forms.TextBox txtResult;
    }
}


﻿using System;

class Program
{
    public static void Main()
    {
        int[] array = new int[] { 1, 0, 3, 4, 0 };
        for (int i = 0; i < 5; i++)
            Console.WriteLine(array[i]);
        Console.Read();
    }
}


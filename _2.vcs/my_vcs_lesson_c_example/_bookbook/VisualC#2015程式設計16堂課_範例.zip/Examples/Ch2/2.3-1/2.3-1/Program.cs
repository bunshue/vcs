﻿class Program
{
    public static void Main()
    {
        System.Console.WriteLine("我的第一個C#程式");
        System.Console.Read();
    }
}


﻿class Program
{
    public static void Main()
    {
        int i, j = 10;
        j++;
        i = 0;
        i++;
        System.Console.WriteLine("我的第一個C#程式");
        System.Console.Read();
    }
}


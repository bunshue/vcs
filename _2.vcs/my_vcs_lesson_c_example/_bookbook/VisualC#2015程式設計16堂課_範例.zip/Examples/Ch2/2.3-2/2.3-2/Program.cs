﻿using System;

namespace MyLib
{
    class Program
    {
        public static void Main()
        {
            Console.WriteLine("我的第一個C#程式");
            Console.Read();
        }
    }
}

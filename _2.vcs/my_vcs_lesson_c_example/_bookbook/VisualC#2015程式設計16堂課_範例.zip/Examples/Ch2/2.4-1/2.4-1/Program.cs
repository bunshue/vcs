﻿using System;

namespace MyLib
{
    class Program
    {
        public static void Main()
        {
            Console.Write("這是");
            Console.Write("Write");
            Console.Write("的用法\n");
            Console.WriteLine("這是");
            Console.WriteLine("WriteLine");
            Console.WriteLine("的用法");
            Console.Read();
        }
    }
}


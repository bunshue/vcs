﻿using System;
class Program
{
    public static void Main()
    {
        int i;
        for (i = 0; i < 10; i++)
        {
            Console.WriteLine(i);
        }
        Console.Read();
    }
}


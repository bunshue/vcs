﻿namespace WinCusSkin
{
    partial class Frm_Main 
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel_Top = new System.Windows.Forms.Panel();
            this.panel_Left = new System.Windows.Forms.Panel();
            this.panelLeftCornu = new System.Windows.Forms.Panel();
            this.panel_Bottom = new System.Windows.Forms.Panel();
            this.panel_Right = new System.Windows.Forms.Panel();
            this.文件ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.设置皮肤ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.普通ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.深蓝经典ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.魔幻天堂ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.设置背景ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.编辑ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.工具ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.项目ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.生成ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.调试ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.数据ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.格式ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.picClose = new System.Windows.Forms.PictureBox();
            this.picMinimize = new System.Windows.Forms.PictureBox();
            this.picMaximize = new System.Windows.Forms.PictureBox();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.换皮肤ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menItemSkin1 = new System.Windows.Forms.ToolStripMenuItem();
            this.menItemSkin2 = new System.Windows.Forms.ToolStripMenuItem();
            this.menItemSkin3 = new System.Windows.Forms.ToolStripMenuItem();
            this.退出ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.文件ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.编辑ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.视图ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.工具ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.窗口ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.帮助ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panelRightCornu = new System.Windows.Forms.Panel();
            this.panel_Left.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picClose)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picMinimize)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picMaximize)).BeginInit();
            this.contextMenuStrip1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel_Top
            // 
            this.panel_Top.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.panel_Top.BackColor = System.Drawing.Color.Transparent;
            this.panel_Top.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel_Top.Location = new System.Drawing.Point(0, 0);
            this.panel_Top.Name = "panel_Top";
            this.panel_Top.Size = new System.Drawing.Size(447, 29);
            this.panel_Top.TabIndex = 4;
            this.panel_Top.DoubleClick += new System.EventHandler(this.panel_Top_DoubleClick);
            this.panel_Top.MouseMove += new System.Windows.Forms.MouseEventHandler(this.panel_Top_MouseMove);
            this.panel_Top.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panel_Top_MouseDown);
            this.panel_Top.MouseUp += new System.Windows.Forms.MouseEventHandler(this.panel_Top_MouseUp);
            // 
            // panel_Left
            // 
            this.panel_Left.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)));
            this.panel_Left.BackColor = System.Drawing.Color.Transparent;
            this.panel_Left.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel_Left.Controls.Add(this.panelLeftCornu);
            this.panel_Left.Cursor = System.Windows.Forms.Cursors.SizeWE;
            this.panel_Left.Location = new System.Drawing.Point(0, 29);
            this.panel_Left.Name = "panel_Left";
            this.panel_Left.Size = new System.Drawing.Size(8, 379);
            this.panel_Left.TabIndex = 5;
            this.panel_Left.MouseMove += new System.Windows.Forms.MouseEventHandler(this.panel_Left_MouseMove);
            this.panel_Left.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panel_Left_MouseDown);
            this.panel_Left.MouseUp += new System.Windows.Forms.MouseEventHandler(this.panel_Left_MouseUp);
            // 
            // panelLeftCornu
            // 
            this.panelLeftCornu.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.panelLeftCornu.BackColor = System.Drawing.Color.Transparent;
            this.panelLeftCornu.Cursor = System.Windows.Forms.Cursors.SizeNESW;
            this.panelLeftCornu.Location = new System.Drawing.Point(0, 372);
            this.panelLeftCornu.Name = "panelLeftCornu";
            this.panelLeftCornu.Size = new System.Drawing.Size(8, 8);
            this.panelLeftCornu.TabIndex = 9;
            this.panelLeftCornu.MouseMove += new System.Windows.Forms.MouseEventHandler(this.panelLeftCornu_MouseMove);
            this.panelLeftCornu.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panelLeftCornu_MouseDown);
            this.panelLeftCornu.MouseUp += new System.Windows.Forms.MouseEventHandler(this.panelLeftCornu_MouseUp);
            // 
            // panel_Bottom
            // 
            this.panel_Bottom.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.panel_Bottom.BackColor = System.Drawing.Color.Transparent;
            this.panel_Bottom.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel_Bottom.Cursor = System.Windows.Forms.Cursors.SizeNS;
            this.panel_Bottom.Location = new System.Drawing.Point(8, 400);
            this.panel_Bottom.Name = "panel_Bottom";
            this.panel_Bottom.Size = new System.Drawing.Size(515, 8);
            this.panel_Bottom.TabIndex = 6;
            this.panel_Bottom.MouseMove += new System.Windows.Forms.MouseEventHandler(this.panel_Bottom_MouseMove);
            this.panel_Bottom.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panel_Bottom_MouseDown);
            this.panel_Bottom.MouseUp += new System.Windows.Forms.MouseEventHandler(this.panel_Bottom_MouseUp);
            // 
            // panel_Right
            // 
            this.panel_Right.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.panel_Right.BackColor = System.Drawing.Color.Transparent;
            this.panel_Right.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel_Right.Cursor = System.Windows.Forms.Cursors.SizeWE;
            this.panel_Right.Location = new System.Drawing.Point(523, 29);
            this.panel_Right.Name = "panel_Right";
            this.panel_Right.Size = new System.Drawing.Size(8, 378);
            this.panel_Right.TabIndex = 7;
            this.panel_Right.MouseMove += new System.Windows.Forms.MouseEventHandler(this.panel_Right_MouseMove);
            this.panel_Right.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panel_Right_MouseDown);
            this.panel_Right.MouseUp += new System.Windows.Forms.MouseEventHandler(this.panel_Right_MouseUp);
            // 
            // 文件ToolStripMenuItem
            // 
            this.文件ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.设置皮肤ToolStripMenuItem,
            this.设置背景ToolStripMenuItem});
            this.文件ToolStripMenuItem.Name = "文件ToolStripMenuItem";
            this.文件ToolStripMenuItem.Size = new System.Drawing.Size(41, 20);
            this.文件ToolStripMenuItem.Text = "文件";
            // 
            // 设置皮肤ToolStripMenuItem
            // 
            this.设置皮肤ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.普通ToolStripMenuItem,
            this.深蓝经典ToolStripMenuItem,
            this.魔幻天堂ToolStripMenuItem});
            this.设置皮肤ToolStripMenuItem.Name = "设置皮肤ToolStripMenuItem";
            this.设置皮肤ToolStripMenuItem.Size = new System.Drawing.Size(124, 22);
            this.设置皮肤ToolStripMenuItem.Text = "设置皮肤";
            // 
            // 普通ToolStripMenuItem
            // 
            this.普通ToolStripMenuItem.Name = "普通ToolStripMenuItem";
            this.普通ToolStripMenuItem.Size = new System.Drawing.Size(124, 22);
            this.普通ToolStripMenuItem.Text = "普通";
            // 
            // 深蓝经典ToolStripMenuItem
            // 
            this.深蓝经典ToolStripMenuItem.Name = "深蓝经典ToolStripMenuItem";
            this.深蓝经典ToolStripMenuItem.Size = new System.Drawing.Size(124, 22);
            this.深蓝经典ToolStripMenuItem.Text = "深蓝经典";
            // 
            // 魔幻天堂ToolStripMenuItem
            // 
            this.魔幻天堂ToolStripMenuItem.Name = "魔幻天堂ToolStripMenuItem";
            this.魔幻天堂ToolStripMenuItem.Size = new System.Drawing.Size(124, 22);
            this.魔幻天堂ToolStripMenuItem.Text = "魔幻天堂";
            // 
            // 设置背景ToolStripMenuItem
            // 
            this.设置背景ToolStripMenuItem.Name = "设置背景ToolStripMenuItem";
            this.设置背景ToolStripMenuItem.Size = new System.Drawing.Size(124, 22);
            this.设置背景ToolStripMenuItem.Text = "设置背景";
            // 
            // 编辑ToolStripMenuItem
            // 
            this.编辑ToolStripMenuItem.Name = "编辑ToolStripMenuItem";
            this.编辑ToolStripMenuItem.Size = new System.Drawing.Size(41, 20);
            this.编辑ToolStripMenuItem.Text = "编辑";
            // 
            // 工具ToolStripMenuItem
            // 
            this.工具ToolStripMenuItem.Name = "工具ToolStripMenuItem";
            this.工具ToolStripMenuItem.Size = new System.Drawing.Size(41, 20);
            this.工具ToolStripMenuItem.Text = "视图";
            // 
            // 项目ToolStripMenuItem
            // 
            this.项目ToolStripMenuItem.Name = "项目ToolStripMenuItem";
            this.项目ToolStripMenuItem.Size = new System.Drawing.Size(41, 20);
            this.项目ToolStripMenuItem.Text = "项目";
            // 
            // 生成ToolStripMenuItem
            // 
            this.生成ToolStripMenuItem.Name = "生成ToolStripMenuItem";
            this.生成ToolStripMenuItem.Size = new System.Drawing.Size(41, 20);
            this.生成ToolStripMenuItem.Text = "生成";
            // 
            // 调试ToolStripMenuItem
            // 
            this.调试ToolStripMenuItem.Name = "调试ToolStripMenuItem";
            this.调试ToolStripMenuItem.Size = new System.Drawing.Size(41, 20);
            this.调试ToolStripMenuItem.Text = "调试";
            // 
            // 数据ToolStripMenuItem
            // 
            this.数据ToolStripMenuItem.Name = "数据ToolStripMenuItem";
            this.数据ToolStripMenuItem.Size = new System.Drawing.Size(41, 20);
            this.数据ToolStripMenuItem.Text = "数据";
            // 
            // 格式ToolStripMenuItem
            // 
            this.格式ToolStripMenuItem.Name = "格式ToolStripMenuItem";
            this.格式ToolStripMenuItem.Size = new System.Drawing.Size(41, 20);
            this.格式ToolStripMenuItem.Text = "格式";
            // 
            // picClose
            // 
            this.picClose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.picClose.BackColor = System.Drawing.Color.Transparent;
            this.picClose.Location = new System.Drawing.Point(502, 0);
            this.picClose.Name = "picClose";
            this.picClose.Size = new System.Drawing.Size(29, 29);
            this.picClose.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picClose.TabIndex = 3;
            this.picClose.TabStop = false;
            this.picClose.Click += new System.EventHandler(this.picClose_Click);
            // 
            // picMinimize
            // 
            this.picMinimize.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.picMinimize.BackColor = System.Drawing.Color.Transparent;
            this.picMinimize.Location = new System.Drawing.Point(446, 0);
            this.picMinimize.Name = "picMinimize";
            this.picMinimize.Size = new System.Drawing.Size(29, 29);
            this.picMinimize.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picMinimize.TabIndex = 2;
            this.picMinimize.TabStop = false;
            this.picMinimize.Click += new System.EventHandler(this.picMinimize_Click);
            // 
            // picMaximize
            // 
            this.picMaximize.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.picMaximize.BackColor = System.Drawing.Color.Transparent;
            this.picMaximize.Location = new System.Drawing.Point(474, 0);
            this.picMaximize.Name = "picMaximize";
            this.picMaximize.Size = new System.Drawing.Size(29, 29);
            this.picMaximize.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picMaximize.TabIndex = 1;
            this.picMaximize.TabStop = false;
            this.picMaximize.Click += new System.EventHandler(this.picMaximize_Click);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.换皮肤ToolStripMenuItem,
            this.退出ToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(113, 48);
            // 
            // 换皮肤ToolStripMenuItem
            // 
            this.换皮肤ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menItemSkin1,
            this.menItemSkin2,
            this.menItemSkin3});
            this.换皮肤ToolStripMenuItem.Name = "换皮肤ToolStripMenuItem";
            this.换皮肤ToolStripMenuItem.Size = new System.Drawing.Size(112, 22);
            this.换皮肤ToolStripMenuItem.Text = "换皮肤";
            // 
            // menItemSkin1
            // 
            this.menItemSkin1.Name = "menItemSkin1";
            this.menItemSkin1.Size = new System.Drawing.Size(124, 22);
            this.menItemSkin1.Text = "紫色小花";
            this.menItemSkin1.Click += new System.EventHandler(this.menItemSkin1_Click);
            // 
            // menItemSkin2
            // 
            this.menItemSkin2.Name = "menItemSkin2";
            this.menItemSkin2.Size = new System.Drawing.Size(124, 22);
            this.menItemSkin2.Text = "蓝色经典";
            this.menItemSkin2.Click += new System.EventHandler(this.menItemSkin2_Click);
            // 
            // menItemSkin3
            // 
            this.menItemSkin3.Name = "menItemSkin3";
            this.menItemSkin3.Size = new System.Drawing.Size(124, 22);
            this.menItemSkin3.Text = "绿色家园";
            this.menItemSkin3.Click += new System.EventHandler(this.menItemSkin3_Click);
            // 
            // 退出ToolStripMenuItem
            // 
            this.退出ToolStripMenuItem.Name = "退出ToolStripMenuItem";
            this.退出ToolStripMenuItem.Size = new System.Drawing.Size(112, 22);
            this.退出ToolStripMenuItem.Text = "退  出";
            this.退出ToolStripMenuItem.Click += new System.EventHandler(this.退出ToolStripMenuItem_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.menuStrip1.AutoSize = false;
            this.menuStrip1.BackColor = System.Drawing.Color.Transparent;
            this.menuStrip1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.menuStrip1.Dock = System.Windows.Forms.DockStyle.None;
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.文件ToolStripMenuItem1,
            this.编辑ToolStripMenuItem1,
            this.视图ToolStripMenuItem,
            this.工具ToolStripMenuItem1,
            this.窗口ToolStripMenuItem,
            this.帮助ToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(8, 29);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(514, 24);
            this.menuStrip1.TabIndex = 10;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // 文件ToolStripMenuItem1
            // 
            this.文件ToolStripMenuItem1.Name = "文件ToolStripMenuItem1";
            this.文件ToolStripMenuItem1.ShortcutKeyDisplayString = "";
            this.文件ToolStripMenuItem1.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.F)));
            this.文件ToolStripMenuItem1.Size = new System.Drawing.Size(58, 20);
            this.文件ToolStripMenuItem1.Text = "文件(&F)";
            // 
            // 编辑ToolStripMenuItem1
            // 
            this.编辑ToolStripMenuItem1.Name = "编辑ToolStripMenuItem1";
            this.编辑ToolStripMenuItem1.Size = new System.Drawing.Size(59, 20);
            this.编辑ToolStripMenuItem1.Text = "编辑(&E)";
            // 
            // 视图ToolStripMenuItem
            // 
            this.视图ToolStripMenuItem.Name = "视图ToolStripMenuItem";
            this.视图ToolStripMenuItem.Size = new System.Drawing.Size(60, 20);
            this.视图ToolStripMenuItem.Text = "视图(&V)";
            // 
            // 工具ToolStripMenuItem1
            // 
            this.工具ToolStripMenuItem1.Name = "工具ToolStripMenuItem1";
            this.工具ToolStripMenuItem1.Size = new System.Drawing.Size(59, 20);
            this.工具ToolStripMenuItem1.Text = "工具(&T)";
            // 
            // 窗口ToolStripMenuItem
            // 
            this.窗口ToolStripMenuItem.Name = "窗口ToolStripMenuItem";
            this.窗口ToolStripMenuItem.Size = new System.Drawing.Size(64, 20);
            this.窗口ToolStripMenuItem.Text = "窗口(&W)";
            // 
            // 帮助ToolStripMenuItem
            // 
            this.帮助ToolStripMenuItem.Name = "帮助ToolStripMenuItem";
            this.帮助ToolStripMenuItem.Size = new System.Drawing.Size(61, 20);
            this.帮助ToolStripMenuItem.Text = "帮助(&H)";
            // 
            // panelRightCornu
            // 
            this.panelRightCornu.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.panelRightCornu.BackColor = System.Drawing.Color.Transparent;
            this.panelRightCornu.Cursor = System.Windows.Forms.Cursors.SizeNWSE;
            this.panelRightCornu.Location = new System.Drawing.Point(523, 400);
            this.panelRightCornu.Name = "panelRightCornu";
            this.panelRightCornu.Size = new System.Drawing.Size(8, 8);
            this.panelRightCornu.TabIndex = 8;
            this.panelRightCornu.MouseMove += new System.Windows.Forms.MouseEventHandler(this.panelRightCornu_MouseMove);
            this.panelRightCornu.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panelRightCornu_MouseDown);
            this.panelRightCornu.MouseUp += new System.Windows.Forms.MouseEventHandler(this.panelRightCornu_MouseUp);
            // 
            // Frm_Main
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(6, 14);
            this.ClientSize = new System.Drawing.Size(531, 408);
            this.ContextMenuStrip = this.contextMenuStrip1;
            this.Controls.Add(this.panel_Left);
            this.Controls.Add(this.panel_Right);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.picClose);
            this.Controls.Add(this.panel_Top);
            this.Controls.Add(this.picMaximize);
            this.Controls.Add(this.picMinimize);
            this.Controls.Add(this.panelRightCornu);
            this.Controls.Add(this.panel_Bottom);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Frm_Main";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "窗体换肤程序";
            this.Load += new System.EventHandler(this.FormCusSkin_Load);
            this.Activated += new System.EventHandler(this.FormCusSkin_Activated);
            this.panel_Left.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.picClose)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picMinimize)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picMaximize)).EndInit();
            this.contextMenuStrip1.ResumeLayout(false);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox picMaximize;
        private System.Windows.Forms.PictureBox picClose;
        private System.Windows.Forms.PictureBox picMinimize;
        private System.Windows.Forms.Panel panel_Top;
        private System.Windows.Forms.Panel panel_Left;
        private System.Windows.Forms.Panel panel_Bottom;
        private System.Windows.Forms.Panel panel_Right;
        private System.Windows.Forms.ToolStripMenuItem 文件ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 编辑ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 工具ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 设置皮肤ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 普通ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 深蓝经典ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 魔幻天堂ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 设置背景ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 项目ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 生成ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 调试ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 数据ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 格式ToolStripMenuItem;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem 换皮肤ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem menItemSkin1;
        private System.Windows.Forms.ToolStripMenuItem menItemSkin2;
        private System.Windows.Forms.ToolStripMenuItem menItemSkin3;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem 文件ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem 编辑ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem 视图ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 工具ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem 窗口ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 帮助ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 退出ToolStripMenuItem;
        private System.Windows.Forms.Panel panelLeftCornu;
        private System.Windows.Forms.Panel panelRightCornu;
    }
}


﻿namespace CreateMenu
{
    partial class Frm_Main
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.编辑ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.查找和替换ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.在文件中查找ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.在文件中替换ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.视图ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.其他窗口ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.书签窗口ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.命令窗口ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.起始页ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.打开JPGToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.打开BMPToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.编辑ToolStripMenuItem,
            this.视图ToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(287, 25);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // 编辑ToolStripMenuItem
            // 
            this.编辑ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.查找和替换ToolStripMenuItem});
            this.编辑ToolStripMenuItem.Name = "编辑ToolStripMenuItem";
            this.编辑ToolStripMenuItem.Size = new System.Drawing.Size(44, 21);
            this.编辑ToolStripMenuItem.Text = "文件";
            // 
            // 查找和替换ToolStripMenuItem
            // 
            this.查找和替换ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.在文件中查找ToolStripMenuItem,
            this.在文件中替换ToolStripMenuItem,
            this.打开JPGToolStripMenuItem,
            this.打开BMPToolStripMenuItem});
            this.查找和替换ToolStripMenuItem.Name = "查找和替换ToolStripMenuItem";
            this.查找和替换ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.查找和替换ToolStripMenuItem.Text = "打开";
            // 
            // 在文件中查找ToolStripMenuItem
            // 
            this.在文件中查找ToolStripMenuItem.Name = "在文件中查找ToolStripMenuItem";
            this.在文件中查找ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.在文件中查找ToolStripMenuItem.Text = "打开文本文件";
            // 
            // 在文件中替换ToolStripMenuItem
            // 
            this.在文件中替换ToolStripMenuItem.Name = "在文件中替换ToolStripMenuItem";
            this.在文件中替换ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.在文件中替换ToolStripMenuItem.Text = "打开XML文件";
            // 
            // 视图ToolStripMenuItem
            // 
            this.视图ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.其他窗口ToolStripMenuItem});
            this.视图ToolStripMenuItem.Name = "视图ToolStripMenuItem";
            this.视图ToolStripMenuItem.Size = new System.Drawing.Size(44, 21);
            this.视图ToolStripMenuItem.Text = "视图";
            // 
            // 其他窗口ToolStripMenuItem
            // 
            this.其他窗口ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.书签窗口ToolStripMenuItem,
            this.命令窗口ToolStripMenuItem,
            this.起始页ToolStripMenuItem});
            this.其他窗口ToolStripMenuItem.Name = "其他窗口ToolStripMenuItem";
            this.其他窗口ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.其他窗口ToolStripMenuItem.Text = "其他窗口";
            // 
            // 书签窗口ToolStripMenuItem
            // 
            this.书签窗口ToolStripMenuItem.Name = "书签窗口ToolStripMenuItem";
            this.书签窗口ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.书签窗口ToolStripMenuItem.Text = "书签窗口";
            // 
            // 命令窗口ToolStripMenuItem
            // 
            this.命令窗口ToolStripMenuItem.Name = "命令窗口ToolStripMenuItem";
            this.命令窗口ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.命令窗口ToolStripMenuItem.Text = "命令窗口";
            // 
            // 起始页ToolStripMenuItem
            // 
            this.起始页ToolStripMenuItem.Name = "起始页ToolStripMenuItem";
            this.起始页ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.起始页ToolStripMenuItem.Text = "起始页";
            // 
            // 打开JPGToolStripMenuItem
            // 
            this.打开JPGToolStripMenuItem.Name = "打开JPGToolStripMenuItem";
            this.打开JPGToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.打开JPGToolStripMenuItem.Text = "打开JPG文件";
            // 
            // 打开BMPToolStripMenuItem
            // 
            this.打开BMPToolStripMenuItem.Name = "打开BMPToolStripMenuItem";
            this.打开BMPToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.打开BMPToolStripMenuItem.Text = "打开BMP文件";
            // 
            // Frm_Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(287, 197);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Frm_Main";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "创建级联菜单";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem 编辑ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 查找和替换ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 在文件中查找ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 在文件中替换ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 视图ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 其他窗口ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 书签窗口ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 命令窗口ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 起始页ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 打开JPGToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 打开BMPToolStripMenuItem;
    }
}


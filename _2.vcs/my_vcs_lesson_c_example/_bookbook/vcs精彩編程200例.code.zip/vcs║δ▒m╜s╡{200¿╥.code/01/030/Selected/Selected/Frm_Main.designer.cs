﻿namespace Selected
{
    partial class Frm_Main
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label6 = new System.Windows.Forms.Label();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.radWoman = new System.Windows.Forms.RadioButton();
            this.radMan = new System.Windows.Forms.RadioButton();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.ckInfo = new System.Windows.Forms.CheckBox();
            this.cklMange = new System.Windows.Forms.CheckedListBox();
            this.cklSell = new System.Windows.Forms.CheckedListBox();
            this.cklShop = new System.Windows.Forms.CheckedListBox();
            this.ckLinfo = new System.Windows.Forms.CheckedListBox();
            this.ckMange = new System.Windows.Forms.CheckBox();
            this.ckSell = new System.Windows.Forms.CheckBox();
            this.ckShop = new System.Windows.Forms.CheckBox();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.textBox5);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.textBox4);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.textBox3);
            this.groupBox1.Controls.Add(this.textBox2);
            this.groupBox1.Controls.Add(this.textBox1);
            this.groupBox1.Controls.Add(this.button2);
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.radWoman);
            this.groupBox1.Controls.Add(this.radMan);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(13, 2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(158, 271);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "用户注册";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(7, 203);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(41, 12);
            this.label6.TabIndex = 14;
            this.label6.Text = "性别：";
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(52, 171);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(100, 21);
            this.textBox5.TabIndex = 13;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(7, 174);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(41, 12);
            this.label5.TabIndex = 12;
            this.label5.Text = "地址：";
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(52, 135);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(100, 21);
            this.textBox4.TabIndex = 11;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(9, 138);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(41, 12);
            this.label4.TabIndex = 10;
            this.label4.Text = "邮箱：";
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(52, 106);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(100, 21);
            this.textBox3.TabIndex = 9;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(52, 71);
            this.textBox2.Name = "textBox2";
            this.textBox2.PasswordChar = '×';
            this.textBox2.Size = new System.Drawing.Size(100, 21);
            this.textBox2.TabIndex = 8;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(54, 34);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 21);
            this.textBox1.TabIndex = 7;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(83, 238);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 6;
            this.button2.Text = "取消(&E)";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(6, 238);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 5;
            this.button1.Text = "确定(&D)";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // radWoman
            // 
            this.radWoman.AutoSize = true;
            this.radWoman.Checked = true;
            this.radWoman.Location = new System.Drawing.Point(105, 201);
            this.radWoman.Name = "radWoman";
            this.radWoman.Size = new System.Drawing.Size(35, 16);
            this.radWoman.TabIndex = 4;
            this.radWoman.TabStop = true;
            this.radWoman.Text = "女";
            this.radWoman.UseVisualStyleBackColor = true;
            // 
            // radMan
            // 
            this.radMan.AutoSize = true;
            this.radMan.CausesValidation = false;
            this.radMan.Location = new System.Drawing.Point(52, 200);
            this.radMan.Name = "radMan";
            this.radMan.Size = new System.Drawing.Size(35, 16);
            this.radMan.TabIndex = 3;
            this.radMan.Text = "男";
            this.radMan.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(9, 109);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 12);
            this.label3.TabIndex = 2;
            this.label3.Text = "电话：";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(9, 74);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(41, 12);
            this.label2.TabIndex = 1;
            this.label2.Text = "密码：";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(7, 37);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "姓名：";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.ckInfo);
            this.groupBox2.Controls.Add(this.cklMange);
            this.groupBox2.Controls.Add(this.cklSell);
            this.groupBox2.Controls.Add(this.cklShop);
            this.groupBox2.Controls.Add(this.ckLinfo);
            this.groupBox2.Controls.Add(this.ckMange);
            this.groupBox2.Controls.Add(this.ckSell);
            this.groupBox2.Controls.Add(this.ckShop);
            this.groupBox2.Controls.Add(this.checkBox3);
            this.groupBox2.Location = new System.Drawing.Point(177, 2);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(140, 272);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "用户权限";
            // 
            // ckInfo
            // 
            this.ckInfo.AutoSize = true;
            this.ckInfo.Location = new System.Drawing.Point(29, 16);
            this.ckInfo.Name = "ckInfo";
            this.ckInfo.Size = new System.Drawing.Size(72, 16);
            this.ckInfo.TabIndex = 26;
            this.ckInfo.Text = "基本档案";
            this.ckInfo.UseVisualStyleBackColor = true;
            this.ckInfo.CheckedChanged += new System.EventHandler(this.ckInfo_CheckedChanged);
            // 
            // cklMange
            // 
            this.cklMange.FormattingEnabled = true;
            this.cklMange.Items.AddRange(new object[] {
            "库存调配",
            "库存警报"});
            this.cklMange.Location = new System.Drawing.Point(42, 238);
            this.cklMange.Name = "cklMange";
            this.cklMange.Size = new System.Drawing.Size(85, 36);
            this.cklMange.TabIndex = 25;
            this.cklMange.Visible = false;
            // 
            // cklSell
            // 
            this.cklSell.FormattingEnabled = true;
            this.cklSell.Items.AddRange(new object[] {
            "商品销售",
            "客户退货"});
            this.cklSell.Location = new System.Drawing.Point(42, 173);
            this.cklSell.Name = "cklSell";
            this.cklSell.Size = new System.Drawing.Size(85, 36);
            this.cklSell.TabIndex = 24;
            this.cklSell.Visible = false;
            // 
            // cklShop
            // 
            this.cklShop.FormattingEnabled = true;
            this.cklShop.Items.AddRange(new object[] {
            "采购进货",
            "采购退货"});
            this.cklShop.Location = new System.Drawing.Point(42, 110);
            this.cklShop.Name = "cklShop";
            this.cklShop.Size = new System.Drawing.Size(85, 36);
            this.cklShop.TabIndex = 23;
            this.cklShop.Visible = false;
            // 
            // ckLinfo
            // 
            this.ckLinfo.FormattingEnabled = true;
            this.ckLinfo.Items.AddRange(new object[] {
            "员工信息",
            "往来单位",
            "客户档案"});
            this.ckLinfo.Location = new System.Drawing.Point(42, 38);
            this.ckLinfo.Name = "ckLinfo";
            this.ckLinfo.Size = new System.Drawing.Size(85, 52);
            this.ckLinfo.TabIndex = 22;
            this.ckLinfo.Visible = false;
            // 
            // ckMange
            // 
            this.ckMange.AutoSize = true;
            this.ckMange.Location = new System.Drawing.Point(29, 215);
            this.ckMange.Name = "ckMange";
            this.ckMange.Size = new System.Drawing.Size(72, 16);
            this.ckMange.TabIndex = 21;
            this.ckMange.Text = "库存管理";
            this.ckMange.UseVisualStyleBackColor = true;
            this.ckMange.CheckedChanged += new System.EventHandler(this.ckMange_CheckedChanged);
            // 
            // ckSell
            // 
            this.ckSell.AutoSize = true;
            this.ckSell.Location = new System.Drawing.Point(29, 152);
            this.ckSell.Name = "ckSell";
            this.ckSell.Size = new System.Drawing.Size(72, 16);
            this.ckSell.TabIndex = 20;
            this.ckSell.Text = "销售管理";
            this.ckSell.UseVisualStyleBackColor = true;
            this.ckSell.CheckedChanged += new System.EventHandler(this.ckSell_CheckedChanged);
            // 
            // ckShop
            // 
            this.ckShop.AutoSize = true;
            this.ckShop.Location = new System.Drawing.Point(29, 89);
            this.ckShop.Name = "ckShop";
            this.ckShop.Size = new System.Drawing.Size(72, 16);
            this.ckShop.TabIndex = 19;
            this.ckShop.Text = "进货管理";
            this.ckShop.UseVisualStyleBackColor = true;
            this.ckShop.CheckedChanged += new System.EventHandler(this.ckShop_CheckedChanged);
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.Location = new System.Drawing.Point(18, -43);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(72, 16);
            this.checkBox3.TabIndex = 18;
            this.checkBox3.Text = "基本档案";
            this.checkBox3.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(328, 278);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "利用选择控件实现权限设置";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton radMan;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.RadioButton radWoman;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.CheckedListBox cklMange;
        private System.Windows.Forms.CheckedListBox cklSell;
        private System.Windows.Forms.CheckedListBox cklShop;
        private System.Windows.Forms.CheckedListBox ckLinfo;
        private System.Windows.Forms.CheckBox ckMange;
        private System.Windows.Forms.CheckBox ckSell;
        private System.Windows.Forms.CheckBox ckShop;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.CheckBox ckInfo;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label label4;
    }
}


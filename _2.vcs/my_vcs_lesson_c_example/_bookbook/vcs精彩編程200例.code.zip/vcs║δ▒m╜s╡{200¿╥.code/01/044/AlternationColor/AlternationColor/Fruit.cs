﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AlternationColor
{
    class Fruit
    {
        public string Name { get; set; }
        public float Price { get; set; }
    }
}

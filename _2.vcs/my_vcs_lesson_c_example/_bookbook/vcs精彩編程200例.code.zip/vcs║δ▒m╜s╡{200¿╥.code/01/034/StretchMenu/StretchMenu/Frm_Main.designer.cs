﻿namespace StretchMenu
{
    partial class Frm_Main
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.操作ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.商品销售ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.商品入库ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.商品调拨ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.商品保存ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.商品定价ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.员工录入ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.添加用户ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.设置密码ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.修改密码ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.忘记密码ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.操作ToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(297, 25);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // 操作ToolStripMenuItem
            // 
            this.操作ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.商品销售ToolStripMenuItem,
            this.商品入库ToolStripMenuItem,
            this.商品调拨ToolStripMenuItem,
            this.商品保存ToolStripMenuItem,
            this.商品定价ToolStripMenuItem,
            this.toolStripMenuItem1,
            this.员工录入ToolStripMenuItem,
            this.添加用户ToolStripMenuItem,
            this.设置密码ToolStripMenuItem,
            this.修改密码ToolStripMenuItem,
            this.忘记密码ToolStripMenuItem});
            this.操作ToolStripMenuItem.Name = "操作ToolStripMenuItem";
            this.操作ToolStripMenuItem.Size = new System.Drawing.Size(44, 21);
            this.操作ToolStripMenuItem.Text = "操作";
            // 
            // 商品销售ToolStripMenuItem
            // 
            this.商品销售ToolStripMenuItem.Name = "商品销售ToolStripMenuItem";
            this.商品销售ToolStripMenuItem.Size = new System.Drawing.Size(168, 22);
            this.商品销售ToolStripMenuItem.Text = "商品销售";
            // 
            // 商品入库ToolStripMenuItem
            // 
            this.商品入库ToolStripMenuItem.Name = "商品入库ToolStripMenuItem";
            this.商品入库ToolStripMenuItem.Size = new System.Drawing.Size(168, 22);
            this.商品入库ToolStripMenuItem.Text = "商品入库";
            // 
            // 商品调拨ToolStripMenuItem
            // 
            this.商品调拨ToolStripMenuItem.Name = "商品调拨ToolStripMenuItem";
            this.商品调拨ToolStripMenuItem.Size = new System.Drawing.Size(168, 22);
            this.商品调拨ToolStripMenuItem.Text = "商品调拨";
            // 
            // 商品保存ToolStripMenuItem
            // 
            this.商品保存ToolStripMenuItem.Name = "商品保存ToolStripMenuItem";
            this.商品保存ToolStripMenuItem.Size = new System.Drawing.Size(168, 22);
            this.商品保存ToolStripMenuItem.Text = "商品保存";
            // 
            // 商品定价ToolStripMenuItem
            // 
            this.商品定价ToolStripMenuItem.Name = "商品定价ToolStripMenuItem";
            this.商品定价ToolStripMenuItem.Size = new System.Drawing.Size(168, 22);
            this.商品定价ToolStripMenuItem.Text = "商品定价";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(168, 22);
            this.toolStripMenuItem1.Text = "展开(关闭)其他项";
            this.toolStripMenuItem1.Click += new System.EventHandler(this.toolStripMenuItem1_Click);
            // 
            // 员工录入ToolStripMenuItem
            // 
            this.员工录入ToolStripMenuItem.Name = "员工录入ToolStripMenuItem";
            this.员工录入ToolStripMenuItem.Size = new System.Drawing.Size(168, 22);
            this.员工录入ToolStripMenuItem.Text = "员工录入";
            // 
            // 添加用户ToolStripMenuItem
            // 
            this.添加用户ToolStripMenuItem.Name = "添加用户ToolStripMenuItem";
            this.添加用户ToolStripMenuItem.Size = new System.Drawing.Size(168, 22);
            this.添加用户ToolStripMenuItem.Text = "添加用户";
            // 
            // 设置密码ToolStripMenuItem
            // 
            this.设置密码ToolStripMenuItem.Name = "设置密码ToolStripMenuItem";
            this.设置密码ToolStripMenuItem.Size = new System.Drawing.Size(168, 22);
            this.设置密码ToolStripMenuItem.Text = "设置密码";
            // 
            // 修改密码ToolStripMenuItem
            // 
            this.修改密码ToolStripMenuItem.Name = "修改密码ToolStripMenuItem";
            this.修改密码ToolStripMenuItem.Size = new System.Drawing.Size(168, 22);
            this.修改密码ToolStripMenuItem.Text = "修改密码";
            // 
            // 忘记密码ToolStripMenuItem
            // 
            this.忘记密码ToolStripMenuItem.Name = "忘记密码ToolStripMenuItem";
            this.忘记密码ToolStripMenuItem.Size = new System.Drawing.Size(168, 22);
            this.忘记密码ToolStripMenuItem.Text = "忘记密码";
            // 
            // Frm_Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(297, 236);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Frm_Main";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "可以拉伸的菜单";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem 操作ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 商品销售ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 商品入库ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 商品调拨ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 商品保存ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 商品定价ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 员工录入ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 添加用户ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 设置密码ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 修改密码ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 忘记密码ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
    }
}


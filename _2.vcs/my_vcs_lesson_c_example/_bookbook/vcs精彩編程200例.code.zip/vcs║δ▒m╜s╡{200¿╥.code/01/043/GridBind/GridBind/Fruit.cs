﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GridBind
{
    class Fruit
    {
        public string Name { get; set; }
        public float Price { get; set; }
    }
}

﻿namespace AmalgamateMenu
{
    partial class Form2
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.contextMenuStrip2 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.menu1ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menu1ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.menu1ToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.menu1ToolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.menu1ToolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.menu1ToolStripMenuItem5 = new System.Windows.Forms.ToolStripMenuItem();
            this.menu1ToolStripMenuItem6 = new System.Windows.Forms.ToolStripMenuItem();
            this.contextMenuStrip2.SuspendLayout();
            this.SuspendLayout();
            // 
            // contextMenuStrip2
            // 
            this.contextMenuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menu1ToolStripMenuItem,
            this.menu1ToolStripMenuItem1,
            this.menu1ToolStripMenuItem2,
            this.menu1ToolStripMenuItem3,
            this.menu1ToolStripMenuItem4,
            this.menu1ToolStripMenuItem5,
            this.menu1ToolStripMenuItem6});
            this.contextMenuStrip2.Name = "contextMenuStrip1";
            this.contextMenuStrip2.Size = new System.Drawing.Size(119, 158);
            // 
            // menu1ToolStripMenuItem
            // 
            this.menu1ToolStripMenuItem.Name = "menu1ToolStripMenuItem";
            this.menu1ToolStripMenuItem.Size = new System.Drawing.Size(118, 22);
            this.menu1ToolStripMenuItem.Text = "仓库管理";
            // 
            // menu1ToolStripMenuItem1
            // 
            this.menu1ToolStripMenuItem1.Name = "menu1ToolStripMenuItem1";
            this.menu1ToolStripMenuItem1.Size = new System.Drawing.Size(118, 22);
            this.menu1ToolStripMenuItem1.Text = "库存盘点";
            // 
            // menu1ToolStripMenuItem2
            // 
            this.menu1ToolStripMenuItem2.Name = "menu1ToolStripMenuItem2";
            this.menu1ToolStripMenuItem2.Size = new System.Drawing.Size(118, 22);
            this.menu1ToolStripMenuItem2.Text = "仓库调拨";
            // 
            // menu1ToolStripMenuItem3
            // 
            this.menu1ToolStripMenuItem3.Name = "menu1ToolStripMenuItem3";
            this.menu1ToolStripMenuItem3.Size = new System.Drawing.Size(118, 22);
            this.menu1ToolStripMenuItem3.Text = "仓库报损";
            // 
            // menu1ToolStripMenuItem4
            // 
            this.menu1ToolStripMenuItem4.Name = "menu1ToolStripMenuItem4";
            this.menu1ToolStripMenuItem4.Size = new System.Drawing.Size(118, 22);
            this.menu1ToolStripMenuItem4.Text = "入库管理";
            // 
            // menu1ToolStripMenuItem5
            // 
            this.menu1ToolStripMenuItem5.Name = "menu1ToolStripMenuItem5";
            this.menu1ToolStripMenuItem5.Size = new System.Drawing.Size(118, 22);
            this.menu1ToolStripMenuItem5.Text = "出库管理";
            // 
            // menu1ToolStripMenuItem6
            // 
            this.menu1ToolStripMenuItem6.Name = "menu1ToolStripMenuItem6";
            this.menu1ToolStripMenuItem6.Size = new System.Drawing.Size(118, 22);
            this.menu1ToolStripMenuItem6.Text = "退货管理";
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(334, 293);
            this.ContextMenuStrip = this.contextMenuStrip2;
            this.Name = "Form2";
            this.Text = "子窗体";
            this.contextMenuStrip2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        public  System.Windows.Forms.ContextMenuStrip contextMenuStrip2;
        private System.Windows.Forms.ToolStripMenuItem menu1ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem menu1ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem menu1ToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem menu1ToolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem menu1ToolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem menu1ToolStripMenuItem5;
        private System.Windows.Forms.ToolStripMenuItem menu1ToolStripMenuItem6;
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bottom_Control
{
    //==============================================================
    //  作者：BAtoDA
    //  时间：2021/2/17 21:54:45 
    //  文件名：DAPLC_Time 
    //  版本：V1.0.1  
    //  说明： 实现PLC底层通讯定时刷新
    //  修改者：***
    //  修改说明： 
    //==============================================================
    class DAPLC_Time
    {
    }

}

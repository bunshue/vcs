﻿
namespace Bottom_Control.基本控件
{
    partial class DADataGridView_TO_PLCE
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel1 = new System.Windows.Forms.Panel();
            this.daDataGridView_TO_PLC2 = new Bottom_Control.基本控件.DADataGridView_TO_PLC();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.daDataGridView_TO_PLC2)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.Controls.Add(this.daDataGridView_TO_PLC2);
            this.panel1.Location = new System.Drawing.Point(3, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(193, 317);
            this.panel1.TabIndex = 0;
            // 
            // daDataGridView_TO_PLC2
            // 
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(246)))), ((int)(((byte)(253)))));
            this.daDataGridView_TO_PLC2.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.daDataGridView_TO_PLC2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.daDataGridView_TO_PLC2.BackgroundColor = System.Drawing.SystemColors.Window;
            this.daDataGridView_TO_PLC2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.daDataGridView_TO_PLC2.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(246)))), ((int)(((byte)(239)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.daDataGridView_TO_PLC2.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.daDataGridView_TO_PLC2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.daDataGridView_TO_PLC2.Control_Text = "";
            this.daDataGridView_TO_PLC2.DataGridView_Name = new string[] {
        null,
        null,
        null,
        null,
        null,
        null,
        null,
        null,
        null,
        null};
            this.daDataGridView_TO_PLC2.DataGridView_numerical = new Bottom_Control.numerical_format[] {
        Bottom_Control.numerical_format.BCD_16_Bit,
        Bottom_Control.numerical_format.BCD_16_Bit,
        Bottom_Control.numerical_format.BCD_16_Bit,
        Bottom_Control.numerical_format.BCD_16_Bit,
        Bottom_Control.numerical_format.BCD_16_Bit,
        Bottom_Control.numerical_format.BCD_16_Bit,
        Bottom_Control.numerical_format.BCD_16_Bit,
        Bottom_Control.numerical_format.BCD_16_Bit,
        Bottom_Control.numerical_format.BCD_16_Bit,
        Bottom_Control.numerical_format.BCD_16_Bit};
            this.daDataGridView_TO_PLC2.DataGridViewPLC_Time = false;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(59)))), ((int)(((byte)(188)))), ((int)(((byte)(240)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.daDataGridView_TO_PLC2.DefaultCellStyle = dataGridViewCellStyle3;
            this.daDataGridView_TO_PLC2.EnableHeadersVisualStyles = false;
            this.daDataGridView_TO_PLC2.GridColor = System.Drawing.SystemColors.GradientActiveCaption;

            this.daDataGridView_TO_PLC2.Location = new System.Drawing.Point(3, 0);
            this.daDataGridView_TO_PLC2.Name = "daDataGridView_TO_PLC2";
            this.daDataGridView_TO_PLC2.numerical = Bottom_Control.numerical_format.Signed_16_Bit;
            this.daDataGridView_TO_PLC2.PLC_address = new string[] {
        "0",
        "0",
        "0",
        "0",
        "0",
        "0",
        "0",
        "0",
        "0",
        "0"};
            this.daDataGridView_TO_PLC2.PLC_Address = "0";
            this.daDataGridView_TO_PLC2.PLC_Contact = "D";
            this.daDataGridView_TO_PLC2.PLC_Enable = false;
            this.daDataGridView_TO_PLC2.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.daDataGridView_TO_PLC2.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            this.daDataGridView_TO_PLC2.RowsDefaultCellStyle = dataGridViewCellStyle4;
            this.daDataGridView_TO_PLC2.RowTemplate.Height = 23;
            this.daDataGridView_TO_PLC2.Size = new System.Drawing.Size(187, 314);
            this.daDataGridView_TO_PLC2.TabIndex = 0;

            // 
            // DADataGridView_TO_PLCE
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.panel1);
            this.Name = "DADataGridView_TO_PLCE";
            this.Size = new System.Drawing.Size(197, 317);
            this.Load += new System.EventHandler(this.DADataGridView_TO_PLC1_Load);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.daDataGridView_TO_PLC2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Panel panel1;
        private DADataGridView_TO_PLC daDataGridView_TO_PLC2;
    }
}

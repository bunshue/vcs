﻿namespace 自定义Uppercomputer_20200727
{
    partial class keyboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(keyboard));
            this.skinLabel1 = new CCWin.SkinControl.SkinLabel();
            this.skinTextBox1 = new CCWin.SkinControl.SkinTextBox();
            this.skinTextBox2 = new CCWin.SkinControl.SkinTextBox();
            this.skinLabel2 = new CCWin.SkinControl.SkinLabel();
            this.skinButton1 = new CCWin.SkinControl.SkinButton();
            this.skinButton2 = new CCWin.SkinControl.SkinButton();
            this.skinTextBox3 = new CCWin.SkinControl.SkinTextBox();
            this.skinButton3 = new CCWin.SkinControl.SkinButton();
            this.skinButton4 = new CCWin.SkinControl.SkinButton();
            this.skinButton5 = new CCWin.SkinControl.SkinButton();
            this.skinButton6 = new CCWin.SkinControl.SkinButton();
            this.skinButton7 = new CCWin.SkinControl.SkinButton();
            this.skinButton8 = new CCWin.SkinControl.SkinButton();
            this.skinButton9 = new CCWin.SkinControl.SkinButton();
            this.skinButton10 = new CCWin.SkinControl.SkinButton();
            this.skinButton11 = new CCWin.SkinControl.SkinButton();
            this.skinButton12 = new CCWin.SkinControl.SkinButton();
            this.skinButton13 = new CCWin.SkinControl.SkinButton();
            this.skinButton14 = new CCWin.SkinControl.SkinButton();
            this.skinButton15 = new CCWin.SkinControl.SkinButton();
            this.skinButton16 = new CCWin.SkinControl.SkinButton();
            this.skinButton18 = new CCWin.SkinControl.SkinButton();
            this.skinButton19 = new CCWin.SkinControl.SkinButton();
            this.skinButton20 = new CCWin.SkinControl.SkinButton();
            this.SuspendLayout();
            // 
            // skinLabel1
            // 
            this.skinLabel1.AutoSize = true;
            this.skinLabel1.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel1.BorderColor = System.Drawing.Color.White;
            this.skinLabel1.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel1.Location = new System.Drawing.Point(10, 49);
            this.skinLabel1.Name = "skinLabel1";
            this.skinLabel1.Size = new System.Drawing.Size(47, 21);
            this.skinLabel1.TabIndex = 0;
            this.skinLabel1.Text = "Max:";
            // 
            // skinTextBox1
            // 
            this.skinTextBox1.BackColor = System.Drawing.Color.Transparent;
            this.skinTextBox1.DownBack = null;
            this.skinTextBox1.Icon = null;
            this.skinTextBox1.IconIsButton = false;
            this.skinTextBox1.IconMouseState = CCWin.SkinClass.ControlState.Normal;
            this.skinTextBox1.IsPasswordChat = '\0';
            this.skinTextBox1.IsSystemPasswordChar = false;
            this.skinTextBox1.Lines = new string[] {
        "999999999"};
            this.skinTextBox1.Location = new System.Drawing.Point(58, 47);
            this.skinTextBox1.Margin = new System.Windows.Forms.Padding(0);
            this.skinTextBox1.MaxLength = 32767;
            this.skinTextBox1.MinimumSize = new System.Drawing.Size(28, 28);
            this.skinTextBox1.MouseBack = null;
            this.skinTextBox1.MouseState = CCWin.SkinClass.ControlState.Normal;
            this.skinTextBox1.Multiline = false;
            this.skinTextBox1.Name = "skinTextBox1";
            this.skinTextBox1.NormlBack = null;
            this.skinTextBox1.Padding = new System.Windows.Forms.Padding(5);
            this.skinTextBox1.ReadOnly = true;
            this.skinTextBox1.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.skinTextBox1.Size = new System.Drawing.Size(95, 28);
            // 
            // 
            // 
            this.skinTextBox1.SkinTxt.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.skinTextBox1.SkinTxt.Dock = System.Windows.Forms.DockStyle.Fill;
            this.skinTextBox1.SkinTxt.Font = new System.Drawing.Font("微软雅黑", 9.75F);
            this.skinTextBox1.SkinTxt.Location = new System.Drawing.Point(5, 5);
            this.skinTextBox1.SkinTxt.Name = "BaseText";
            this.skinTextBox1.SkinTxt.ReadOnly = true;
            this.skinTextBox1.SkinTxt.Size = new System.Drawing.Size(85, 18);
            this.skinTextBox1.SkinTxt.TabIndex = 0;
            this.skinTextBox1.SkinTxt.Text = "999999999";
            this.skinTextBox1.SkinTxt.WaterColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(127)))), ((int)(((byte)(127)))));
            this.skinTextBox1.SkinTxt.WaterText = "";
            this.skinTextBox1.TabIndex = 1;
            this.skinTextBox1.Text = "999999999";
            this.skinTextBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.skinTextBox1.WaterColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(127)))), ((int)(((byte)(127)))));
            this.skinTextBox1.WaterText = "";
            this.skinTextBox1.WordWrap = true;
            // 
            // skinTextBox2
            // 
            this.skinTextBox2.BackColor = System.Drawing.Color.Transparent;
            this.skinTextBox2.DownBack = null;
            this.skinTextBox2.Icon = null;
            this.skinTextBox2.IconIsButton = false;
            this.skinTextBox2.IconMouseState = CCWin.SkinClass.ControlState.Normal;
            this.skinTextBox2.IsPasswordChat = '\0';
            this.skinTextBox2.IsSystemPasswordChar = false;
            this.skinTextBox2.Lines = new string[] {
        "0"};
            this.skinTextBox2.Location = new System.Drawing.Point(224, 47);
            this.skinTextBox2.Margin = new System.Windows.Forms.Padding(0);
            this.skinTextBox2.MaxLength = 32767;
            this.skinTextBox2.MinimumSize = new System.Drawing.Size(28, 28);
            this.skinTextBox2.MouseBack = null;
            this.skinTextBox2.MouseState = CCWin.SkinClass.ControlState.Normal;
            this.skinTextBox2.Multiline = false;
            this.skinTextBox2.Name = "skinTextBox2";
            this.skinTextBox2.NormlBack = null;
            this.skinTextBox2.Padding = new System.Windows.Forms.Padding(5);
            this.skinTextBox2.ReadOnly = true;
            this.skinTextBox2.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.skinTextBox2.Size = new System.Drawing.Size(95, 28);
            // 
            // 
            // 
            this.skinTextBox2.SkinTxt.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.skinTextBox2.SkinTxt.Dock = System.Windows.Forms.DockStyle.Fill;
            this.skinTextBox2.SkinTxt.Font = new System.Drawing.Font("微软雅黑", 9.75F);
            this.skinTextBox2.SkinTxt.Location = new System.Drawing.Point(5, 5);
            this.skinTextBox2.SkinTxt.Name = "BaseText";
            this.skinTextBox2.SkinTxt.ReadOnly = true;
            this.skinTextBox2.SkinTxt.Size = new System.Drawing.Size(85, 18);
            this.skinTextBox2.SkinTxt.TabIndex = 0;
            this.skinTextBox2.SkinTxt.Text = "0";
            this.skinTextBox2.SkinTxt.WaterColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(127)))), ((int)(((byte)(127)))));
            this.skinTextBox2.SkinTxt.WaterText = "";
            this.skinTextBox2.TabIndex = 3;
            this.skinTextBox2.Text = "0";
            this.skinTextBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.skinTextBox2.WaterColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(127)))), ((int)(((byte)(127)))));
            this.skinTextBox2.WaterText = "";
            this.skinTextBox2.WordWrap = true;
            // 
            // skinLabel2
            // 
            this.skinLabel2.AutoSize = true;
            this.skinLabel2.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel2.BorderColor = System.Drawing.Color.White;
            this.skinLabel2.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel2.Location = new System.Drawing.Point(176, 51);
            this.skinLabel2.Name = "skinLabel2";
            this.skinLabel2.Size = new System.Drawing.Size(44, 21);
            this.skinLabel2.TabIndex = 2;
            this.skinLabel2.Text = "Min:";
            // 
            // skinButton1
            // 
            this.skinButton1.BackColor = System.Drawing.Color.Transparent;
            this.skinButton1.BaseColor = System.Drawing.Color.DarkGray;
            this.skinButton1.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.skinButton1.DownBack = null;
            this.skinButton1.DownBaseColor = System.Drawing.Color.DarkGray;
            this.skinButton1.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold);
            this.skinButton1.Location = new System.Drawing.Point(11, 146);
            this.skinButton1.MouseBack = null;
            this.skinButton1.Name = "skinButton1";
            this.skinButton1.NormlBack = null;
            this.skinButton1.Size = new System.Drawing.Size(47, 43);
            this.skinButton1.TabIndex = 4;
            this.skinButton1.Text = "7";
            this.skinButton1.UseVisualStyleBackColor = false;
            // 
            // skinButton2
            // 
            this.skinButton2.BackColor = System.Drawing.Color.Transparent;
            this.skinButton2.BaseColor = System.Drawing.Color.DarkGray;
            this.skinButton2.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.skinButton2.DownBack = null;
            this.skinButton2.DownBaseColor = System.Drawing.Color.DarkGray;
            this.skinButton2.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold);
            this.skinButton2.Location = new System.Drawing.Point(11, 201);
            this.skinButton2.MouseBack = null;
            this.skinButton2.Name = "skinButton2";
            this.skinButton2.NormlBack = null;
            this.skinButton2.Size = new System.Drawing.Size(47, 43);
            this.skinButton2.TabIndex = 5;
            this.skinButton2.Text = "4";
            this.skinButton2.UseVisualStyleBackColor = false;
            // 
            // skinTextBox3
            // 
            this.skinTextBox3.BackColor = System.Drawing.Color.Transparent;
            this.skinTextBox3.DownBack = null;
            this.skinTextBox3.Icon = null;
            this.skinTextBox3.IconIsButton = false;
            this.skinTextBox3.IconMouseState = CCWin.SkinClass.ControlState.Normal;
            this.skinTextBox3.IsPasswordChat = '\0';
            this.skinTextBox3.IsSystemPasswordChar = false;
            this.skinTextBox3.Lines = new string[] {
        "skinTextBox3"};
            this.skinTextBox3.Location = new System.Drawing.Point(14, 92);
            this.skinTextBox3.Margin = new System.Windows.Forms.Padding(0);
            this.skinTextBox3.MaxLength = 32767;
            this.skinTextBox3.MinimumSize = new System.Drawing.Size(28, 28);
            this.skinTextBox3.MouseBack = null;
            this.skinTextBox3.MouseState = CCWin.SkinClass.ControlState.Normal;
            this.skinTextBox3.Multiline = false;
            this.skinTextBox3.Name = "skinTextBox3";
            this.skinTextBox3.NormlBack = null;
            this.skinTextBox3.Padding = new System.Windows.Forms.Padding(5);
            this.skinTextBox3.ReadOnly = true;
            this.skinTextBox3.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.skinTextBox3.Size = new System.Drawing.Size(305, 28);
            // 
            // 
            // 
            this.skinTextBox3.SkinTxt.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.skinTextBox3.SkinTxt.Dock = System.Windows.Forms.DockStyle.Fill;
            this.skinTextBox3.SkinTxt.Font = new System.Drawing.Font("微软雅黑", 9.75F);
            this.skinTextBox3.SkinTxt.Location = new System.Drawing.Point(5, 5);
            this.skinTextBox3.SkinTxt.Name = "BaseText";
            this.skinTextBox3.SkinTxt.ReadOnly = true;
            this.skinTextBox3.SkinTxt.Size = new System.Drawing.Size(295, 18);
            this.skinTextBox3.SkinTxt.TabIndex = 0;
            this.skinTextBox3.SkinTxt.Text = "skinTextBox3";
            this.skinTextBox3.SkinTxt.WaterColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(127)))), ((int)(((byte)(127)))));
            this.skinTextBox3.SkinTxt.WaterText = "";
            this.skinTextBox3.TabIndex = 6;
            this.skinTextBox3.Text = "skinTextBox3";
            this.skinTextBox3.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.skinTextBox3.WaterColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(127)))), ((int)(((byte)(127)))));
            this.skinTextBox3.WaterText = "";
            this.skinTextBox3.WordWrap = true;
            // 
            // skinButton3
            // 
            this.skinButton3.BackColor = System.Drawing.Color.Transparent;
            this.skinButton3.BaseColor = System.Drawing.Color.DarkGray;
            this.skinButton3.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.skinButton3.DownBack = null;
            this.skinButton3.DownBaseColor = System.Drawing.Color.DarkGray;
            this.skinButton3.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold);
            this.skinButton3.Location = new System.Drawing.Point(10, 255);
            this.skinButton3.MouseBack = null;
            this.skinButton3.Name = "skinButton3";
            this.skinButton3.NormlBack = null;
            this.skinButton3.Size = new System.Drawing.Size(47, 43);
            this.skinButton3.TabIndex = 7;
            this.skinButton3.Text = "1";
            this.skinButton3.UseVisualStyleBackColor = false;
            // 
            // skinButton4
            // 
            this.skinButton4.BackColor = System.Drawing.Color.Transparent;
            this.skinButton4.BaseColor = System.Drawing.Color.DarkGray;
            this.skinButton4.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.skinButton4.DownBack = null;
            this.skinButton4.DownBaseColor = System.Drawing.Color.DarkGray;
            this.skinButton4.Enabled = false;
            this.skinButton4.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinButton4.Location = new System.Drawing.Point(10, 313);
            this.skinButton4.MouseBack = null;
            this.skinButton4.Name = "skinButton4";
            this.skinButton4.NormlBack = null;
            this.skinButton4.Size = new System.Drawing.Size(47, 43);
            this.skinButton4.TabIndex = 8;
            this.skinButton4.Text = ".";
            this.skinButton4.UseVisualStyleBackColor = false;
            // 
            // skinButton5
            // 
            this.skinButton5.BackColor = System.Drawing.Color.Transparent;
            this.skinButton5.BaseColor = System.Drawing.Color.DarkGray;
            this.skinButton5.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.skinButton5.DownBack = null;
            this.skinButton5.DownBaseColor = System.Drawing.Color.DarkGray;
            this.skinButton5.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold);
            this.skinButton5.Location = new System.Drawing.Point(76, 313);
            this.skinButton5.MouseBack = null;
            this.skinButton5.Name = "skinButton5";
            this.skinButton5.NormlBack = null;
            this.skinButton5.Size = new System.Drawing.Size(47, 43);
            this.skinButton5.TabIndex = 12;
            this.skinButton5.Text = "0";
            this.skinButton5.UseVisualStyleBackColor = false;
            // 
            // skinButton6
            // 
            this.skinButton6.BackColor = System.Drawing.Color.Transparent;
            this.skinButton6.BaseColor = System.Drawing.Color.DarkGray;
            this.skinButton6.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.skinButton6.DownBack = null;
            this.skinButton6.DownBaseColor = System.Drawing.Color.DarkGray;
            this.skinButton6.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold);
            this.skinButton6.Location = new System.Drawing.Point(76, 255);
            this.skinButton6.MouseBack = null;
            this.skinButton6.Name = "skinButton6";
            this.skinButton6.NormlBack = null;
            this.skinButton6.Size = new System.Drawing.Size(47, 43);
            this.skinButton6.TabIndex = 11;
            this.skinButton6.Text = "2";
            this.skinButton6.UseVisualStyleBackColor = false;
            // 
            // skinButton7
            // 
            this.skinButton7.BackColor = System.Drawing.Color.Transparent;
            this.skinButton7.BaseColor = System.Drawing.Color.DarkGray;
            this.skinButton7.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.skinButton7.DownBack = null;
            this.skinButton7.DownBaseColor = System.Drawing.Color.DarkGray;
            this.skinButton7.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold);
            this.skinButton7.Location = new System.Drawing.Point(77, 201);
            this.skinButton7.MouseBack = null;
            this.skinButton7.Name = "skinButton7";
            this.skinButton7.NormlBack = null;
            this.skinButton7.Size = new System.Drawing.Size(47, 43);
            this.skinButton7.TabIndex = 10;
            this.skinButton7.Text = "5";
            this.skinButton7.UseVisualStyleBackColor = false;
            // 
            // skinButton8
            // 
            this.skinButton8.BackColor = System.Drawing.Color.Transparent;
            this.skinButton8.BaseColor = System.Drawing.Color.DarkGray;
            this.skinButton8.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.skinButton8.DownBack = null;
            this.skinButton8.DownBaseColor = System.Drawing.Color.DarkGray;
            this.skinButton8.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold);
            this.skinButton8.Location = new System.Drawing.Point(77, 146);
            this.skinButton8.MouseBack = null;
            this.skinButton8.Name = "skinButton8";
            this.skinButton8.NormlBack = null;
            this.skinButton8.Size = new System.Drawing.Size(47, 43);
            this.skinButton8.TabIndex = 9;
            this.skinButton8.Text = "8";
            this.skinButton8.UseVisualStyleBackColor = false;
            // 
            // skinButton9
            // 
            this.skinButton9.BackColor = System.Drawing.Color.Transparent;
            this.skinButton9.BaseColor = System.Drawing.Color.DarkGray;
            this.skinButton9.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.skinButton9.DownBack = null;
            this.skinButton9.DownBaseColor = System.Drawing.Color.DarkGray;
            this.skinButton9.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold);
            this.skinButton9.Location = new System.Drawing.Point(140, 313);
            this.skinButton9.MouseBack = null;
            this.skinButton9.Name = "skinButton9";
            this.skinButton9.NormlBack = null;
            this.skinButton9.Size = new System.Drawing.Size(47, 43);
            this.skinButton9.TabIndex = 16;
            this.skinButton9.Text = "-";
            this.skinButton9.UseVisualStyleBackColor = false;
            // 
            // skinButton10
            // 
            this.skinButton10.BackColor = System.Drawing.Color.Transparent;
            this.skinButton10.BaseColor = System.Drawing.Color.DarkGray;
            this.skinButton10.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.skinButton10.DownBack = null;
            this.skinButton10.DownBaseColor = System.Drawing.Color.DarkGray;
            this.skinButton10.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold);
            this.skinButton10.Location = new System.Drawing.Point(140, 255);
            this.skinButton10.MouseBack = null;
            this.skinButton10.Name = "skinButton10";
            this.skinButton10.NormlBack = null;
            this.skinButton10.Size = new System.Drawing.Size(47, 43);
            this.skinButton10.TabIndex = 15;
            this.skinButton10.Text = "3";
            this.skinButton10.UseVisualStyleBackColor = false;
            // 
            // skinButton11
            // 
            this.skinButton11.BackColor = System.Drawing.Color.Transparent;
            this.skinButton11.BaseColor = System.Drawing.Color.DarkGray;
            this.skinButton11.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.skinButton11.DownBack = null;
            this.skinButton11.DownBaseColor = System.Drawing.Color.DarkGray;
            this.skinButton11.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold);
            this.skinButton11.Location = new System.Drawing.Point(141, 201);
            this.skinButton11.MouseBack = null;
            this.skinButton11.Name = "skinButton11";
            this.skinButton11.NormlBack = null;
            this.skinButton11.Size = new System.Drawing.Size(47, 43);
            this.skinButton11.TabIndex = 14;
            this.skinButton11.Text = "6";
            this.skinButton11.UseVisualStyleBackColor = false;
            // 
            // skinButton12
            // 
            this.skinButton12.BackColor = System.Drawing.Color.Transparent;
            this.skinButton12.BaseColor = System.Drawing.Color.DarkGray;
            this.skinButton12.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.skinButton12.DownBack = null;
            this.skinButton12.DownBaseColor = System.Drawing.Color.DarkGray;
            this.skinButton12.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold);
            this.skinButton12.Location = new System.Drawing.Point(141, 146);
            this.skinButton12.MouseBack = null;
            this.skinButton12.Name = "skinButton12";
            this.skinButton12.NormlBack = null;
            this.skinButton12.Size = new System.Drawing.Size(47, 43);
            this.skinButton12.TabIndex = 13;
            this.skinButton12.Text = "9";
            this.skinButton12.UseVisualStyleBackColor = false;
            // 
            // skinButton13
            // 
            this.skinButton13.BackColor = System.Drawing.Color.Transparent;
            this.skinButton13.BaseColor = System.Drawing.Color.DarkGray;
            this.skinButton13.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.skinButton13.DownBack = null;
            this.skinButton13.DownBaseColor = System.Drawing.Color.DarkGray;
            this.skinButton13.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold);
            this.skinButton13.Location = new System.Drawing.Point(205, 313);
            this.skinButton13.MouseBack = null;
            this.skinButton13.Name = "skinButton13";
            this.skinButton13.NormlBack = null;
            this.skinButton13.Size = new System.Drawing.Size(113, 43);
            this.skinButton13.TabIndex = 20;
            this.skinButton13.Text = "Enter";
            this.skinButton13.UseVisualStyleBackColor = false;
            // 
            // skinButton14
            // 
            this.skinButton14.BackColor = System.Drawing.Color.Transparent;
            this.skinButton14.BaseColor = System.Drawing.Color.DarkGray;
            this.skinButton14.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.skinButton14.DownBack = null;
            this.skinButton14.DownBaseColor = System.Drawing.Color.DarkGray;
            this.skinButton14.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold);
            this.skinButton14.Location = new System.Drawing.Point(205, 255);
            this.skinButton14.MouseBack = null;
            this.skinButton14.Name = "skinButton14";
            this.skinButton14.NormlBack = null;
            this.skinButton14.Size = new System.Drawing.Size(47, 43);
            this.skinButton14.TabIndex = 19;
            this.skinButton14.Text = "<";
            this.skinButton14.UseVisualStyleBackColor = false;
            // 
            // skinButton15
            // 
            this.skinButton15.BackColor = System.Drawing.Color.Transparent;
            this.skinButton15.BaseColor = System.Drawing.Color.DarkGray;
            this.skinButton15.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.skinButton15.DownBack = null;
            this.skinButton15.DownBaseColor = System.Drawing.Color.DarkGray;
            this.skinButton15.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold);
            this.skinButton15.Location = new System.Drawing.Point(206, 201);
            this.skinButton15.MouseBack = null;
            this.skinButton15.Name = "skinButton15";
            this.skinButton15.NormlBack = null;
            this.skinButton15.Size = new System.Drawing.Size(47, 43);
            this.skinButton15.TabIndex = 18;
            this.skinButton15.Text = "Bs";
            this.skinButton15.UseVisualStyleBackColor = false;
            // 
            // skinButton16
            // 
            this.skinButton16.BackColor = System.Drawing.Color.Transparent;
            this.skinButton16.BaseColor = System.Drawing.Color.DarkGray;
            this.skinButton16.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.skinButton16.DownBack = null;
            this.skinButton16.DownBaseColor = System.Drawing.Color.DarkGray;
            this.skinButton16.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold);
            this.skinButton16.Location = new System.Drawing.Point(206, 146);
            this.skinButton16.MouseBack = null;
            this.skinButton16.Name = "skinButton16";
            this.skinButton16.NormlBack = null;
            this.skinButton16.Size = new System.Drawing.Size(47, 43);
            this.skinButton16.TabIndex = 17;
            this.skinButton16.Text = "Clr";
            this.skinButton16.UseVisualStyleBackColor = false;
            // 
            // skinButton18
            // 
            this.skinButton18.BackColor = System.Drawing.Color.Transparent;
            this.skinButton18.BaseColor = System.Drawing.Color.DarkGray;
            this.skinButton18.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.skinButton18.DownBack = null;
            this.skinButton18.DownBaseColor = System.Drawing.Color.DarkGray;
            this.skinButton18.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold);
            this.skinButton18.Location = new System.Drawing.Point(271, 255);
            this.skinButton18.MouseBack = null;
            this.skinButton18.Name = "skinButton18";
            this.skinButton18.NormlBack = null;
            this.skinButton18.Size = new System.Drawing.Size(47, 43);
            this.skinButton18.TabIndex = 23;
            this.skinButton18.Text = ">";
            this.skinButton18.UseVisualStyleBackColor = false;
            // 
            // skinButton19
            // 
            this.skinButton19.BackColor = System.Drawing.Color.Transparent;
            this.skinButton19.BaseColor = System.Drawing.Color.DarkGray;
            this.skinButton19.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.skinButton19.DownBack = null;
            this.skinButton19.DownBaseColor = System.Drawing.Color.DarkGray;
            this.skinButton19.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold);
            this.skinButton19.Location = new System.Drawing.Point(272, 201);
            this.skinButton19.MouseBack = null;
            this.skinButton19.Name = "skinButton19";
            this.skinButton19.NormlBack = null;
            this.skinButton19.Size = new System.Drawing.Size(47, 43);
            this.skinButton19.TabIndex = 22;
            this.skinButton19.Text = "Del";
            this.skinButton19.UseVisualStyleBackColor = false;
            // 
            // skinButton20
            // 
            this.skinButton20.BackColor = System.Drawing.Color.Transparent;
            this.skinButton20.BaseColor = System.Drawing.Color.DarkGray;
            this.skinButton20.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.skinButton20.DownBack = null;
            this.skinButton20.DownBaseColor = System.Drawing.Color.DarkGray;
            this.skinButton20.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold);
            this.skinButton20.Location = new System.Drawing.Point(272, 146);
            this.skinButton20.MouseBack = null;
            this.skinButton20.Name = "skinButton20";
            this.skinButton20.NormlBack = null;
            this.skinButton20.Size = new System.Drawing.Size(47, 43);
            this.skinButton20.TabIndex = 21;
            this.skinButton20.Text = "Esc";
            this.skinButton20.UseVisualStyleBackColor = false;
            // 
            // keyboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(329, 368);
            this.Controls.Add(this.skinButton18);
            this.Controls.Add(this.skinButton19);
            this.Controls.Add(this.skinButton20);
            this.Controls.Add(this.skinButton13);
            this.Controls.Add(this.skinButton14);
            this.Controls.Add(this.skinButton15);
            this.Controls.Add(this.skinButton16);
            this.Controls.Add(this.skinButton9);
            this.Controls.Add(this.skinButton10);
            this.Controls.Add(this.skinButton11);
            this.Controls.Add(this.skinButton12);
            this.Controls.Add(this.skinButton5);
            this.Controls.Add(this.skinButton6);
            this.Controls.Add(this.skinButton7);
            this.Controls.Add(this.skinButton8);
            this.Controls.Add(this.skinButton4);
            this.Controls.Add(this.skinButton3);
            this.Controls.Add(this.skinTextBox3);
            this.Controls.Add(this.skinButton2);
            this.Controls.Add(this.skinButton1);
            this.Controls.Add(this.skinTextBox2);
            this.Controls.Add(this.skinLabel2);
            this.Controls.Add(this.skinTextBox1);
            this.Controls.Add(this.skinLabel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "keyboard";
            this.Text = "                         ·";
            this.Shown += new System.EventHandler(this.keyboard_Shown);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private CCWin.SkinControl.SkinLabel skinLabel1;
        private CCWin.SkinControl.SkinTextBox skinTextBox1;
        private CCWin.SkinControl.SkinTextBox skinTextBox2;
        private CCWin.SkinControl.SkinLabel skinLabel2;
        private CCWin.SkinControl.SkinButton skinButton1;
        private CCWin.SkinControl.SkinButton skinButton2;
        private CCWin.SkinControl.SkinTextBox skinTextBox3;
        private CCWin.SkinControl.SkinButton skinButton3;
        private CCWin.SkinControl.SkinButton skinButton4;
        private CCWin.SkinControl.SkinButton skinButton5;
        private CCWin.SkinControl.SkinButton skinButton6;
        private CCWin.SkinControl.SkinButton skinButton7;
        private CCWin.SkinControl.SkinButton skinButton8;
        private CCWin.SkinControl.SkinButton skinButton9;
        private CCWin.SkinControl.SkinButton skinButton10;
        private CCWin.SkinControl.SkinButton skinButton11;
        private CCWin.SkinControl.SkinButton skinButton12;
        private CCWin.SkinControl.SkinButton skinButton13;
        private CCWin.SkinControl.SkinButton skinButton14;
        private CCWin.SkinControl.SkinButton skinButton15;
        private CCWin.SkinControl.SkinButton skinButton16;
        private CCWin.SkinControl.SkinButton skinButton18;
        private CCWin.SkinControl.SkinButton skinButton19;
        private CCWin.SkinControl.SkinButton skinButton20;
    }
}
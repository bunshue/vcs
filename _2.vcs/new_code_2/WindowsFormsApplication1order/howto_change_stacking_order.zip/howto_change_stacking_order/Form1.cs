﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace howto_change_stacking_order
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnToTop_Click(object sender, EventArgs e)
        {
            Button btn = sender as Button;
            btn.BringToFront();
        }

        private void btnToBottom_Click(object sender, EventArgs e)
        {
            Button btn = sender as Button;
            btn.SendToBack();
        }

        private void btnSecondToTop_Click(object sender, EventArgs e)
        {
            Button btn = sender as Button;
            btn.Parent.Controls.SetChildIndex(btn, 1);
        }
    }
}

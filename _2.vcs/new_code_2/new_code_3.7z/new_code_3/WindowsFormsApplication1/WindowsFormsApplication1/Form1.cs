﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            richTextBox1.Text += "string.PadLeft 字串統一長度或補字元\n";
            int a = 15;
            string s1 = a.ToString().PadLeft(10, '-');
            richTextBox1.Text += s1 + "\n";

            string s2 = string.Format("{0:00000}", Convert.ToInt16(a));
            richTextBox1.Text += s2 + "\n";


        }

        private void button2_Click(object sender, EventArgs e)
        {
            //System.Text.StringBuilder("")
            //字元串相加，（+號是不是也一樣？）
            System.Text.StringBuilder sb = new System.Text.StringBuilder("");
            sb.Append("AB");
            sb.Append("CD");
            sb.Append("EFG");

            richTextBox1.Text += sb + "\n";


        }


    }
}

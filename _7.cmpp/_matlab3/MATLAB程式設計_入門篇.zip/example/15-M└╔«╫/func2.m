function average = func(vector)
% FUNC2 A simple function with a single help line.
%
%	Usage of this function:
%	output = func2(input)
%	"output" is the average of the input vector "input".

%	Roger Jang, 19991123.

average = sum(vector)/length(vector);	% �p�⥭����
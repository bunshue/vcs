[X, map]=imread('sbtree.gif');
image(X);
colormap(map);
colorbar;

%X = imread('ngc6543a.jpg');
X = imread('annie19980405.jpg');
image(X)
size(X)


RGB = imread('simulinkteam.jpg');
image(RGB);
class(RGB)

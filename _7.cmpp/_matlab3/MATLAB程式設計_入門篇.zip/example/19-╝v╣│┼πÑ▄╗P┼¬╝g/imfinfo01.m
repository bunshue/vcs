info1=imfinfo('simulinkteam.jpg')
info2=imfinfo('sbtree.gif')
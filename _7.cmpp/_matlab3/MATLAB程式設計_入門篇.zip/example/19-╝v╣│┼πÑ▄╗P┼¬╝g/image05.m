load mandrill.mat
image(X);
colormap(map);
colorbar;
axis image

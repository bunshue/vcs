load clown
newmap = rand(size(map));
image(X);
colormap(newmap);
colorbar;
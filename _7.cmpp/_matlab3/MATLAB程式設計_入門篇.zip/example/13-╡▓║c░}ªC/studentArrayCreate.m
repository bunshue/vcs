clear student;

student(1).name = 'Thomas Wang';
student(1).score = [72 71 75 81 80 86]';
student(2).name = 'Brian Chung';
student(2).score = [99 95 98 96 99 99]';
student(3).name = 'Alexander S.-H. Huang';
student(3).score = [90 85 87 90 88 92]';
student(4).name = 'Simon Lin';
student(4).score = [65 63 70 63 62 61]';

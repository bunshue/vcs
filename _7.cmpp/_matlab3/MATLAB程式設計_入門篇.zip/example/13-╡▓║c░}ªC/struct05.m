student = struct('name', {'�i�x��', '�i�x�w'}, 'scores', {[50 60], [60 70]});
student(2).course(1).title = 'Web Programming';
student(2).course(1).credits = 2;
student(2).course(2).title = 'Numerical Method';
student(2).course(2).credits = 3;
student(2).course
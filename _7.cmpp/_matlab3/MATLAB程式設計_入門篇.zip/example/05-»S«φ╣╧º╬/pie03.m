x = [2 3 5 4];
explode = [1 1 0 0];
pie(x, explode);
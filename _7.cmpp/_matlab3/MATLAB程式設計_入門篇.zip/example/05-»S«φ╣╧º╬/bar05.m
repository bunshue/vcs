x = [2 3 4 5 7; 1 2 3 2 1];
bar3(x, 'group')
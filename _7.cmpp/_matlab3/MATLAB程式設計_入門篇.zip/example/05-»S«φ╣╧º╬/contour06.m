[x, y, z] = peaks;
meshc(x, y, z);
axis tight
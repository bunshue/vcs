z = peaks;
contour(z,[0 2 5]);
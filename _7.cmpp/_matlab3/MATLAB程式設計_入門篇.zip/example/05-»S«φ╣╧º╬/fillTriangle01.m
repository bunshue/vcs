X = [0 0 1];
Y = [0 1 0];
Z = [0 1 1];
C = [0 0.5 1]';
fill3(X, Y, Z, C);
colorbar;
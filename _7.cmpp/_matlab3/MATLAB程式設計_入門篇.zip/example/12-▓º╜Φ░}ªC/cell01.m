A(1,1) = {'This is the first cell.'};
A(1,2) = {[5+j*6 , 4+j*5]};
A(2,1) = {[1 2 3; 4 5 6; 7 8 9]};
A(2,2) = {{'Tim'; 'Chris'}}
S = struct('name',{'Tim','Annie'},'age', {8,5});  
[sCell{1:length(S)}] = deal(S.name)
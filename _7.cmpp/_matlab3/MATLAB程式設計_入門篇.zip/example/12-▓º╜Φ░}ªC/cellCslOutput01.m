[D{1:2}] = max(rand(5));
celldisp(D);
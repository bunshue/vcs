C = {[1,2,3]; 'This is a test.'};
iscell(C)
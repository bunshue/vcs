function out = logSum(x)

logValue = log(x);
out = sum(logValue);

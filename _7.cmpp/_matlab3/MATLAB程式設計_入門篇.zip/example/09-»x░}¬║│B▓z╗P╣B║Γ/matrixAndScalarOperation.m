A=[1 3 5];
fprintf('A = '); disp(A);
fprintf('A+5 = '); disp(A+5);
fprintf('A-3 = '); disp(A-3);
fprintf('2*A = '); disp(2*A);
fprintf('A/3 = '); disp(A/3);

A = magic(3);
B = A^2
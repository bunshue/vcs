str = '2 4.7 5.2';
mat = sscanf(str, '%f')
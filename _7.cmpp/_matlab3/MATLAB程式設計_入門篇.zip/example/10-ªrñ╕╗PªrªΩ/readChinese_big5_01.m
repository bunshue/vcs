file='big5.txt';
fid=fopen(file, 'r');
line=fgets(fid);
disp(line);

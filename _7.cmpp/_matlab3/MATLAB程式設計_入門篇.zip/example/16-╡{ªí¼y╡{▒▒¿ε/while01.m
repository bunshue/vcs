x = zeros(1,6);
i = 1;
while i<=6
	x(i) = 1/i;
	i = i+1;
end
x			% ��� x
x = 0/0;
if isnan(x)
	disp('Warning: NaN detected!');
end
fid = fopen('test2.txt', 'r');
myData = fread(fid, 4)		% �uŪ 4 �Ӧ줸��
fclose(fid);
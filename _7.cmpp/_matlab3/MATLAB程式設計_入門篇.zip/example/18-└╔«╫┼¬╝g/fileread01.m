out = fileread('data2.txt');
class(out)
size(out)
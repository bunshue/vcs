x=0:0.5:4*pi;
opt.marker='o';
opt.markerSize=15;
opt.linewidth=5;
opt.linestyle=':';
opt.markerEdgeColor='g';
opt.markerFaceColor='y';
plot(x, sin(x), opt);
t = linspace(0, 4*pi);
x = sin(t);
y = 1-cos(t)+t/10;
plot(x, y, '-o');
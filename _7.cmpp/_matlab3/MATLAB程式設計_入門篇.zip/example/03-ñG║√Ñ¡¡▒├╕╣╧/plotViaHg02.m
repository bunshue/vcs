x=0:0.5:4*pi;
plot(x, sin(x), 'marker', 'o', 'markerSize', 15, 'lineWidth', 5, 'lineStyle', ':', 'markerEdgeColor', 'g', 'markerFaceColor', 'y');
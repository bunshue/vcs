cm=colormap;
size(cm)
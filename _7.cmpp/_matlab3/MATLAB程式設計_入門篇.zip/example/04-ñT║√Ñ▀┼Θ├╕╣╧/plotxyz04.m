[x, y, z] = peaks;
waterfall(x,y,z);
axis tight;
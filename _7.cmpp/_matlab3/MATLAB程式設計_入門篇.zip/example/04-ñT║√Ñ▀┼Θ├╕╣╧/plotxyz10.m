[x,y,z] = peaks;
mesh(x,y,z);
hidden off 
axis tight
[x, y, z] = peaks;  
meshz(x,y,z);  
axis tight;
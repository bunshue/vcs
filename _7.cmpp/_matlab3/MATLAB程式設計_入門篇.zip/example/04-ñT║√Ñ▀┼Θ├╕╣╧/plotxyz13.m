peaks;
colormap(rand(64,3));
colorbar;
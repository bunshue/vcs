peaks;
colormap jet;
colorbar;
shading interp;
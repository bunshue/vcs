peaks;
colorbar;
subplot(1,3,1);
sphere(20); axis image
subplot(1,3,2);
cylinder(1); axis image
subplot(1,3,3);
ellipsoid(0, 0, 0, 8, 1, 3); axis image
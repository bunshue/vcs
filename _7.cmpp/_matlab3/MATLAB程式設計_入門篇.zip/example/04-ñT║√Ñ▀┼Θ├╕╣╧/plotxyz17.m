colormap copper
subplot(3, 1, 1); rgbplot(colormap);
brighten(colormap, 0.5)
subplot(3, 1, 2); rgbplot(colormap);
brighten(colormap, -0.8)
subplot(3, 1, 3); rgbplot(colormap);
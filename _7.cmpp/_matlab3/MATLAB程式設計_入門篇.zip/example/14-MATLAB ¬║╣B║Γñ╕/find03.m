x = magic(5);
x(find(7<x & x<11))
a = [0 1 2 3];
result1 = all(a)
retult2 = any(a)
result3 = any(a<0)

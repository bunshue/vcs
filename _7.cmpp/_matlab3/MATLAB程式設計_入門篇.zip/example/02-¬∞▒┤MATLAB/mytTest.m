% myTest: my first test M-file.
% Roger Jang, March 3, 1997
fprintf('Start of myTest.m!\n');
for i = 1:3
	fprintf('i = %d ---> i^3 = %d\n', i, i^3);
end
fprintf('End of myTest.m!\n');
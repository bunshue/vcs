function y = myFun(x)
y = 0.5*exp(x/3)-x.*x.*sin(x);
﻿namespace USUI_serial
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器
        /// 修改這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.labMouse = new System.Windows.Forms.Label();
            this.meaChk = new System.Windows.Forms.CheckBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.ledCRCLab = new System.Windows.Forms.Label();
            this.ledTXT1 = new System.Windows.Forms.TextBox();
            this.ledTXT2 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.ledBtn = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.keyCRCLab = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.keyBtn = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.sensCRCLab = new System.Windows.Forms.Label();
            this.sensTXT = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.sensBtn = new System.Windows.Forms.Button();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.comBtn = new System.Windows.Forms.Button();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.label19 = new System.Windows.Forms.Label();
            this.comboBaud = new System.Windows.Forms.ComboBox();
            this.comboCom = new System.Windows.Forms.ComboBox();
            this.label18 = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.hHelpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.testBtn = new System.Windows.Forms.Button();
            this.clnBtn = new System.Windows.Forms.Button();
            this.BtnAns = new System.Windows.Forms.Button();
            this.LabAns = new System.Windows.Forms.Label();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.SuspendLayout();
            // 
            // labMouse
            // 
            this.labMouse.AutoSize = true;
            this.labMouse.BackColor = System.Drawing.Color.Gainsboro;
            this.labMouse.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labMouse.Location = new System.Drawing.Point(11, 33);
            this.labMouse.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labMouse.Name = "labMouse";
            this.labMouse.Size = new System.Drawing.Size(12, 16);
            this.labMouse.TabIndex = 18;
            this.labMouse.Text = " ";
            this.labMouse.Visible = false;
            // 
            // meaChk
            // 
            this.meaChk.AutoSize = true;
            this.meaChk.Location = new System.Drawing.Point(0, 52);
            this.meaChk.Name = "meaChk";
            this.meaChk.Size = new System.Drawing.Size(63, 16);
            this.meaChk.TabIndex = 19;
            this.meaChk.Text = "Measure";
            this.meaChk.UseVisualStyleBackColor = true;
            this.meaChk.Visible = false;
            this.meaChk.CheckedChanged += new System.EventHandler(this.meaChk_CheckedChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.ledCRCLab);
            this.groupBox1.Controls.Add(this.ledTXT1);
            this.groupBox1.Controls.Add(this.ledTXT2);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.ledBtn);
            this.groupBox1.Location = new System.Drawing.Point(18, 14);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(378, 57);
            this.groupBox1.TabIndex = 20;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "LED";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(181, 26);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(17, 12);
            this.label5.TabIndex = 15;
            this.label5.Text = "0x";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(130, 26);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(17, 12);
            this.label4.TabIndex = 14;
            this.label4.Text = "0x";
            // 
            // ledCRCLab
            // 
            this.ledCRCLab.AutoSize = true;
            this.ledCRCLab.Location = new System.Drawing.Point(271, 24);
            this.ledCRCLab.Name = "ledCRCLab";
            this.ledCRCLab.Size = new System.Drawing.Size(33, 12);
            this.ledCRCLab.TabIndex = 6;
            this.ledCRCLab.Text = "0xXX";
            // 
            // ledTXT1
            // 
            this.ledTXT1.Location = new System.Drawing.Point(199, 21);
            this.ledTXT1.Name = "ledTXT1";
            this.ledTXT1.Size = new System.Drawing.Size(29, 22);
            this.ledTXT1.TabIndex = 5;
            // 
            // ledTXT2
            // 
            this.ledTXT2.Location = new System.Drawing.Point(147, 21);
            this.ledTXT2.Name = "ledTXT2";
            this.ledTXT2.Size = new System.Drawing.Size(28, 22);
            this.ledTXT2.TabIndex = 4;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(94, 26);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(30, 12);
            this.label3.TabIndex = 3;
            this.label3.Text = "0xE3";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(59, 25);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(29, 12);
            this.label2.TabIndex = 2;
            this.label2.Text = "0x02";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(24, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(29, 12);
            this.label1.TabIndex = 1;
            this.label1.Text = "0x06";
            // 
            // ledBtn
            // 
            this.ledBtn.Location = new System.Drawing.Point(325, 13);
            this.ledBtn.Name = "ledBtn";
            this.ledBtn.Size = new System.Drawing.Size(47, 38);
            this.ledBtn.TabIndex = 0;
            this.ledBtn.Text = "Send LED";
            this.ledBtn.UseVisualStyleBackColor = true;
            this.ledBtn.Click += new System.EventHandler(this.ledBtn_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.keyCRCLab);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.keyBtn);
            this.groupBox2.Location = new System.Drawing.Point(18, 91);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(378, 57);
            this.groupBox2.TabIndex = 21;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "KEY query";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(165, 25);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(29, 12);
            this.label11.TabIndex = 16;
            this.label11.Text = "0x00";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(130, 25);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(29, 12);
            this.label9.TabIndex = 13;
            this.label9.Text = "0x00";
            // 
            // keyCRCLab
            // 
            this.keyCRCLab.AutoSize = true;
            this.keyCRCLab.Location = new System.Drawing.Point(271, 26);
            this.keyCRCLab.Name = "keyCRCLab";
            this.keyCRCLab.Size = new System.Drawing.Size(33, 12);
            this.keyCRCLab.TabIndex = 12;
            this.keyCRCLab.Text = "0xXX";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(94, 25);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(29, 12);
            this.label6.TabIndex = 9;
            this.label6.Text = "0x62";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(59, 25);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(29, 12);
            this.label7.TabIndex = 8;
            this.label7.Text = "0x02";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(24, 25);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(29, 12);
            this.label8.TabIndex = 7;
            this.label8.Text = "0x06";
            // 
            // keyBtn
            // 
            this.keyBtn.Location = new System.Drawing.Point(325, 13);
            this.keyBtn.Name = "keyBtn";
            this.keyBtn.Size = new System.Drawing.Size(47, 38);
            this.keyBtn.TabIndex = 1;
            this.keyBtn.Text = "Send KEY";
            this.keyBtn.UseVisualStyleBackColor = true;
            this.keyBtn.Click += new System.EventHandler(this.keyBtn_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label15);
            this.groupBox3.Controls.Add(this.label10);
            this.groupBox3.Controls.Add(this.sensCRCLab);
            this.groupBox3.Controls.Add(this.sensTXT);
            this.groupBox3.Controls.Add(this.label12);
            this.groupBox3.Controls.Add(this.label13);
            this.groupBox3.Controls.Add(this.label14);
            this.groupBox3.Controls.Add(this.sensBtn);
            this.groupBox3.Location = new System.Drawing.Point(18, 170);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(378, 57);
            this.groupBox3.TabIndex = 21;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Sensitivity ";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(181, 26);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(17, 12);
            this.label15.TabIndex = 17;
            this.label15.Text = "0x";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(130, 26);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(29, 12);
            this.label10.TabIndex = 19;
            this.label10.Text = "0x00";
            // 
            // sensCRCLab
            // 
            this.sensCRCLab.AutoSize = true;
            this.sensCRCLab.Location = new System.Drawing.Point(271, 27);
            this.sensCRCLab.Name = "sensCRCLab";
            this.sensCRCLab.Size = new System.Drawing.Size(33, 12);
            this.sensCRCLab.TabIndex = 18;
            this.sensCRCLab.Text = "0xXX";
            // 
            // sensTXT
            // 
            this.sensTXT.Location = new System.Drawing.Point(199, 21);
            this.sensTXT.Name = "sensTXT";
            this.sensTXT.Size = new System.Drawing.Size(29, 22);
            this.sensTXT.TabIndex = 17;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(94, 26);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(29, 12);
            this.label12.TabIndex = 16;
            this.label12.Text = "0x64";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(59, 26);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(29, 12);
            this.label13.TabIndex = 15;
            this.label13.Text = "0x02";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(24, 26);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(29, 12);
            this.label14.TabIndex = 14;
            this.label14.Text = "0x06";
            // 
            // sensBtn
            // 
            this.sensBtn.Location = new System.Drawing.Point(325, 13);
            this.sensBtn.Name = "sensBtn";
            this.sensBtn.Size = new System.Drawing.Size(47, 38);
            this.sensBtn.TabIndex = 2;
            this.sensBtn.Text = "Send Sens";
            this.sensBtn.UseVisualStyleBackColor = true;
            this.sensBtn.Click += new System.EventHandler(this.sensBtn_Click);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.groupBox3);
            this.groupBox4.Controls.Add(this.groupBox2);
            this.groupBox4.Controls.Add(this.groupBox1);
            this.groupBox4.Location = new System.Drawing.Point(372, 38);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(409, 241);
            this.groupBox4.TabIndex = 22;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "TX";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(83, 24);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(21, 12);
            this.label16.TabIndex = 20;
            this.label16.Text = "RX";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Courier New", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(6, 24);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(50, 16);
            this.label17.TabIndex = 24;
            this.label17.Text = "Port :";
            // 
            // comBtn
            // 
            this.comBtn.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comBtn.Location = new System.Drawing.Point(204, 18);
            this.comBtn.Name = "comBtn";
            this.comBtn.Size = new System.Drawing.Size(70, 48);
            this.comBtn.TabIndex = 25;
            this.comBtn.Text = "Open";
            this.comBtn.UseVisualStyleBackColor = true;
            this.comBtn.Click += new System.EventHandler(this.comBtn_Click);
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.label19);
            this.groupBox5.Controls.Add(this.comboBaud);
            this.groupBox5.Controls.Add(this.comboCom);
            this.groupBox5.Controls.Add(this.comBtn);
            this.groupBox5.Controls.Add(this.label17);
            this.groupBox5.Location = new System.Drawing.Point(374, 296);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(280, 85);
            this.groupBox5.TabIndex = 26;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Serial Port setting";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Courier New", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(6, 50);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(85, 16);
            this.label19.TabIndex = 29;
            this.label19.Text = "Baud Rate :";
            // 
            // comboBaud
            // 
            this.comboBaud.FormattingEnabled = true;
            this.comboBaud.Location = new System.Drawing.Point(97, 46);
            this.comboBaud.Name = "comboBaud";
            this.comboBaud.Size = new System.Drawing.Size(78, 20);
            this.comboBaud.TabIndex = 28;
            // 
            // comboCom
            // 
            this.comboCom.FormattingEnabled = true;
            this.comboCom.Location = new System.Drawing.Point(97, 20);
            this.comboCom.Name = "comboCom";
            this.comboCom.Size = new System.Drawing.Size(78, 20);
            this.comboCom.TabIndex = 27;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(127, 24);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(117, 12);
            this.label18.TabIndex = 27;
            this.label18.Text = "HEX DATA::Checksum";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.hHelpToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(995, 24);
            this.menuStrip1.TabIndex = 28;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // hHelpToolStripMenuItem
            // 
            this.hHelpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aboutToolStripMenuItem1});
            this.hHelpToolStripMenuItem.Name = "hHelpToolStripMenuItem";
            this.hHelpToolStripMenuItem.Size = new System.Drawing.Size(39, 20);
            this.hHelpToolStripMenuItem.Text = "Help";
            // 
            // aboutToolStripMenuItem1
            // 
            this.aboutToolStripMenuItem1.Name = "aboutToolStripMenuItem1";
            this.aboutToolStripMenuItem1.Size = new System.Drawing.Size(99, 22);
            this.aboutToolStripMenuItem1.Text = "About";
            this.aboutToolStripMenuItem1.Click += new System.EventHandler(this.aboutToolStripMenuItem1_Click);
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(46, 20);
            this.aboutToolStripMenuItem.Text = "About";
            // 
            // testBtn
            // 
            this.testBtn.Location = new System.Drawing.Point(715, 285);
            this.testBtn.Name = "testBtn";
            this.testBtn.Size = new System.Drawing.Size(66, 38);
            this.testBtn.TabIndex = 29;
            this.testBtn.Text = "TestBTN";
            this.testBtn.UseVisualStyleBackColor = true;
            this.testBtn.Click += new System.EventHandler(this.testBtn_Click);
            // 
            // clnBtn
            // 
            this.clnBtn.Location = new System.Drawing.Point(374, 402);
            this.clnBtn.Name = "clnBtn";
            this.clnBtn.Size = new System.Drawing.Size(69, 27);
            this.clnBtn.TabIndex = 30;
            this.clnBtn.Text = "Clean Text";
            this.clnBtn.UseVisualStyleBackColor = true;
            this.clnBtn.Click += new System.EventHandler(this.clnBtn_Click);
            // 
            // BtnAns
            // 
            this.BtnAns.Location = new System.Drawing.Point(715, 332);
            this.BtnAns.Name = "BtnAns";
            this.BtnAns.Size = new System.Drawing.Size(66, 38);
            this.BtnAns.TabIndex = 31;
            this.BtnAns.Text = "TestAns";
            this.BtnAns.UseVisualStyleBackColor = true;
            this.BtnAns.Click += new System.EventHandler(this.BtnAns_Click);
            // 
            // LabAns
            // 
            this.LabAns.AutoSize = true;
            this.LabAns.Location = new System.Drawing.Point(13, 13);
            this.LabAns.Name = "LabAns";
            this.LabAns.Size = new System.Drawing.Size(29, 12);
            this.LabAns.TabIndex = 32;
            this.LabAns.Text = "Ans: ";
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.LabAns);
            this.groupBox6.Location = new System.Drawing.Point(485, 387);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(296, 41);
            this.groupBox6.TabIndex = 33;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Ans Data";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(995, 464);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.BtnAns);
            this.Controls.Add(this.clnBtn);
            this.Controls.Add(this.testBtn);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.meaChk);
            this.Controls.Add(this.labMouse);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Form1";
            this.Text = "Sampo TKM Tester";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.MouseUp += new System.Windows.Forms.MouseEventHandler(this.Form1_MouseUp);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Form1_MouseDown);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.Resize += new System.EventHandler(this.Form1_Resize);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Form1_MouseMove);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labMouse;
        private System.Windows.Forms.CheckBox meaChk;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button ledBtn;
        private System.Windows.Forms.Button keyBtn;
        private System.Windows.Forms.Button sensBtn;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label ledCRCLab;
        private System.Windows.Forms.TextBox ledTXT1;
        private System.Windows.Forms.TextBox ledTXT2;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label keyCRCLab;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label sensCRCLab;
        private System.Windows.Forms.TextBox sensTXT;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Button comBtn;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.ComboBox comboCom;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem hHelpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem1;
        private System.Windows.Forms.ComboBox comboBaud;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Button testBtn;
        private System.Windows.Forms.Button clnBtn;
        private System.Windows.Forms.Button BtnAns;
        private System.Windows.Forms.Label LabAns;
        private System.Windows.Forms.GroupBox groupBox6;
    }
}


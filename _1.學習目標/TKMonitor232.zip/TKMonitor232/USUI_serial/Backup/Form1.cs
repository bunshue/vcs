﻿// Author : JC Chen

#define MOUSE_GESTURE
#define RINGQ


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
// 
using Microsoft.Win32.SafeHandles;
// For serial port
using System.IO.Ports;
// For multithread
using System.Threading;
// For Timer
//using System.Timers;
using System.Runtime.InteropServices;


namespace USUI_serial
{
    public partial class Form1 : Form
    {

        bool wrFlag = false;
        bool floatFlag = false;

        bool pageFlag = false;



        bool mouseDnFlag = false;


        bool oneFlag = false;
        int x1 = 0;
        int y1 = 0;
        // Must to set very clearly, because System.Threading.Timer to clash.
        System.Windows.Forms.Timer timer01;

        private TextBox logBox;
        Button ClrScrBtn;

        delegate void SetTextCallback(string text);

        static bool _continue;
        SerialPort _serialPort;

        // serial port read thread
        Thread readThread;
        bool fOpenOK = false;
        string[] comPortList;
        string[] baudRateList = { "300", "1200", "2400", "4800", "9600", "19200", "38400", "57600", "115200" };
        //
        Pen myPen;

        // For write file
        string[] comBuf;
        bool fWrFile = false;
        Int32 iPathFileName = 0;
        string sFolderName = " ";
        int iFileSet = 100;
        //
        public struct ActiveZone
        {
            public int x, y, width, height;

            public ActiveZone(int p1, int p2, int wd, int hi)
            {
                x = p1;
                y = p2;
                width = wd;
                height = hi;
            }
        }



        //========
        // Kalman filter - Simple version
        //[StructLayout(LayoutKind.Sequential)]
        public struct kalman_state
        {
            public double q; //process noise covariance
            public double r; //measurement noise covariance
            public double x; //value
            public double p; //estimation error covariance
            public double k; //kalman gain
        }

        public kalman_state kalman_init(double q, double r, double p, double intial_value)
        {
            kalman_state result = new kalman_state();
            result.q = q;
            result.r = r;
            result.p = p;
            result.x = intial_value;
            return result;
        }

        public void kalman_update(ref kalman_state StateTmp, double measurement)
        {
            //prediction update
            //omit x = x
            StateTmp.p = StateTmp.p + StateTmp.q;
            //measurement update
            StateTmp.k = StateTmp.p / (StateTmp.p + StateTmp.r);
            StateTmp.x = StateTmp.x + StateTmp.k * (measurement - StateTmp.x);
            StateTmp.p = (1 - StateTmp.k) * StateTmp.p;

        }
        //kalman_state kX1, kY1, kX2, kY2;
        //
        //int kmD1, kmD2;
        //========        



        //
        string hexOutput, message, srtRes;
        int intRes;
        int chkSumRec;
        //

        public Form1()
        {
            InitializeComponent();


            timer01 = new System.Windows.Forms.Timer();
            timer01.Interval = 50;
            timer01.Start();
            timer01.Tick += new EventHandler(timer01_Tick);


            // UDP socket
            logBox = new TextBox();
            logBox.Size = new Size(240, 400);
            logBox.Multiline = true;
            logBox.ScrollBars = ScrollBars.Vertical;
            logBox.ReadOnly = true;
            logBox.Location = new Point(80, 40);
            //logBox.Location = new Point(5, 250);
            //
            logBox.Visible = true;
            //
            this.Controls.Add(logBox);


            // 

            // ClrScrBtn            
            // 
            ClrScrBtn = new Button();
            ClrScrBtn.BackColor = System.Drawing.Color.Gray;
            ClrScrBtn.Margin = new System.Windows.Forms.Padding(2);
            ClrScrBtn.Name = "ClrScrBtn";
            ClrScrBtn.Size = new System.Drawing.Size(160, 160);
            ClrScrBtn.TabIndex = 19;
            ClrScrBtn.Text = "清除畫面";
            ClrScrBtn.UseVisualStyleBackColor = true;
            ClrScrBtn.Visible = true;
            ClrScrBtn.Click += new System.EventHandler(this.ClrScrBtn_Click);
            //this.Controls.Add(ClrScrBtn);
            //

            // Create a new SerialPort object with default settings.
            //_serialPort = new SerialPort("COM2", 9600, Parity.None, 8, StopBits.One);



            //_serialPort.Open();
            //_serialPort.Close();
            //_serialPort.Open();

            try
            {
                comPortList = SerialPort.GetPortNames();
                foreach (string port in comPortList)
                {
                    comboCom.Items.Add(port);

                }
                comboCom.SelectedIndex = 0;

                foreach (string baud in baudRateList)
                {
                    comboBaud.Items.Add(baud);
                }
                comboBaud.SelectedIndex = 2;
            }
            catch
            {
                comBtn.Enabled = false;
                MessageBox.Show("No Com Port", "Warning!");
            }

            //
            ledBtn.Enabled = false;
            keyBtn.Enabled = false;
            sensBtn.Enabled = false;
            testBtn.Enabled = false;
            //

            comBuf = new string[64000];

            _continue = true;

            Thread.Sleep(200);
            this.Form1_Resize(null, null);

            // Start the Thread
            //readThread = new Thread(Read);
            //readThread.IsBackground = true;
            //readThread.Start();


        }

        //================
        byte[] readBuf = new byte[256];
        byte[] procBuf = new byte[6];
        int procInc = 0;
        bool timerAct = false;
        int swInc = 0;
        int bufInc = 0;
        int cmdSatatus = 0;
        bool recMod = false;
        bool AnsKey = false;
        bool AnsLed = false;
        int ansInt = 1;

        void serialPort_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            //String data = _serialPort.ReadLine();
            //SetText(data);

            //
            try
            {

                if (_serialPort.BytesToRead > 0)
                //if (true)
                {
                    //dataIn = false;

                    //int byteNum = _serialPort.BytesToRead;
                    //if (byteNum > 256) byteNum = 256;

                    //_serialPort.Read(readBuf, 0, byteNum);
                    //message = System.Text.Encoding.Default.GetString(readBuf);
                    chkSumRec = 0;
                    try
                    {
                        switch (bufInc)
                        {
                            case 0:

                                _serialPort.Read(readBuf, bufInc, 1);

                                if (readBuf[bufInc] == 0x06)
                                {
                                    //hexOutput = null;
                                    bufInc = 1;
                                }
                                break;

                            case 1:

                                _serialPort.Read(readBuf, bufInc, 1);

                                if (readBuf[bufInc] == 0x02)
                                {
                                    bufInc = 2;
                                }
                                break;

                            case 2:

                                _serialPort.Read(readBuf, bufInc, 1);

                                if (readBuf[bufInc] == 0x62)
                                {
                                    cmdSatatus = 1;
                                }
                                if (readBuf[bufInc] == 0xE3)
                                {
                                    cmdSatatus = 2;
                                }
                                if (readBuf[bufInc] == 0x64)
                                {
                                    cmdSatatus = 3;
                                }
                                bufInc = 3;
                                break;

                            case 3:

                                _serialPort.Read(readBuf, bufInc, 1);

                                bufInc = 4;
                                break;

                            case 4:

                                _serialPort.Read(readBuf, bufInc, 1);

                                bufInc = 5;
                                break;

                            case 5:

                                _serialPort.Read(readBuf, bufInc, 1);

                                //
                                for (bufInc = 0; bufInc < 6; bufInc++)
                                {

                                    intRes = Convert.ToInt32(readBuf[bufInc]);
                                    hexOutput = hexOutput + " " +
                                        String.Format("{0:X}", intRes).PadLeft(2, '0');
                                    if (bufInc < 5)
                                    {
                                        chkSumRec = chkSumRec ^ intRes;
                                    }

                                }

                                hexOutput = hexOutput + "::" +
                                    String.Format("{0:X}", chkSumRec).PadLeft(2, '0') + "\r\n";

                                //
                                if (recMod)
                                {
                                    switch (cmdSatatus)
                                    {
                                        case 1: // 0x62                                        
                                            sendBuf[0] = 0x06;
                                            sendBuf[1] = 0x02;
                                            sendBuf[2] = 0x62;
                                            sendBuf[3] = readBuf[3];
                                            //sendBuf[3] = 0x00;
                                            sendBuf[4] = (byte)ansInt;
                                            chkSumSed = 0x06 ^ 0x02 ^ 0x62 ^
                                                Convert.ToInt16(sendBuf[3]) ^ Convert.ToInt16(sendBuf[4]);
                                            sendBuf[5] = Convert.ToByte(chkSumSed);

                                            _serialPort.Write(sendBuf, 0, 6);

                                            //
                                            AnsKey = true;
                                            //
                                            break;

                                        case 2: // 0xE3
                                            sendBuf[0] = 0x06;
                                            sendBuf[1] = 0x02;
                                            sendBuf[2] = 0xE3;
                                            sendBuf[3] = readBuf[3];
                                            sendBuf[4] = readBuf[4];
                                            chkSumSed = 0x06 ^ 0x02 ^ 0xE3 ^
                                                Convert.ToInt16(sendBuf[3]) ^ Convert.ToInt16(sendBuf[4]);
                                            sendBuf[5] = Convert.ToByte(chkSumSed);

                                            _serialPort.Write(sendBuf, 0, 6);

                                            //
                                            AnsLed = true;
                                            //
                                            break;

                                        case 3: // 0x64
                                            break;

                                        default:
                                            break;
                                    }
                                    cmdSatatus = 0;
                                }
                                //
                                timerAct = true;
                                //                           

                                bufInc = 0;
                                break;

                            default:
                                break;
                        }

                    }
                    catch { }



                    //bufTmp = System.Text.Encoding.Default.GetBytes(message);                            
                    //System.Text.ASCIIEncoding encode = new System.Text.ASCIIEncoding();
                    //comBuf[cntBuf] = encode.GetString(bufTmp);  

                    //SetText(hexOutput);

                    //SetText("\r\n");
                    //hexOutput = null;


                }
            }
            catch (TimeoutException) { }
            //
        }
        //================


        private void meaChk_CheckedChanged(object sender, EventArgs e)
        {

        }
        //================

        private void Read()
        {
            //MessageBox.Show("Enter", "Test");
            //SetText("enter thread\r\n");

            while (_continue)
            {
                //Thread.Sleep(4);
                Thread.Sleep(42);
                if (fOpenOK)
                //if (true)
                //if (_continue)
                {
                    //SetText("enter rs232\r\n");
                    try
                    {

                        if (_serialPort.BytesToRead > 0)
                        //if (true)
                        {
                            //dataIn = false;
                            byte[] readBuf = new byte[256];
                            int byteNum = _serialPort.BytesToRead;
                            if (byteNum > 256) byteNum = 256;

                            _serialPort.Read(readBuf, 0, 6);
                            message = System.Text.Encoding.Default.GetString(readBuf);
                            chkSumRec = 0;
                            for (int i = 0; i < byteNum; i++)
                            {
                                intRes = Convert.ToInt32(readBuf[i]);
                                hexOutput = hexOutput + " " + String.Format("{0:X}", intRes).PadLeft(2, '0');

                                if ((readBuf[0] == 0x06) && (readBuf[1] == 0x02) && (i < 5))
                                {
                                    chkSumRec = chkSumRec ^ intRes;
                                }
                            }

                            //bufTmp = System.Text.Encoding.Default.GetBytes(message);                            
                            //System.Text.ASCIIEncoding encode = new System.Text.ASCIIEncoding();
                            //comBuf[cntBuf] = encode.GetString(bufTmp);  

                            SetText(String.Format("{0:X}", chkSumRec).PadLeft(2, '0') +
                                " :: " + hexOutput + " :: " + message);
                            SetText("\r\n");
                            hexOutput = null;
                        }
                    }
                    catch (TimeoutException) { }
                }
            }
        }

        //
        byte[] sendBuf = new byte[6];
        int chkSumSed = 0;
        //
        private void testBtn_Click(object sender, EventArgs e)
        {
            testBtn.Enabled = false;
            int i = 0;
            for (i = 0; i < 255; i++)
            {
                sendBuf[0] = 0x06;
                sendBuf[1] = 0x02;
                sendBuf[2] = 0xE3;
                // Jack Test
                //sendBuf[0] = 0xFF;
                //sendBuf[1] = 0xFF;
                //sendBuf[2] = 0xFF;  
                //

                try
                {
                    sendBuf[3] = Convert.ToByte(Convert.ToInt32(ledTXT2.Text, 16));
                }
                catch { sendBuf[3] = 0; }
                if (sendBuf[3] > 255) sendBuf[3] = 0;
                //try
                //{
                //    sendBuf[4] = Convert.ToByte(Convert.ToInt32(ledTXT1.Text, 16));
                //}
                //catch { sendBuf[4] = 0; }
                //if (sendBuf[4] > 255) sendBuf[4] = 0;
                sendBuf[4] = (byte)(i % 255);
                chkSumSed = 0x06 ^ 0x02 ^ 0xE3 ^
                    Convert.ToInt16(sendBuf[3]) ^ Convert.ToInt16(sendBuf[4]);
                sendBuf[5] = Convert.ToByte(chkSumSed);
                ledCRCLab.Text = "0x" + String.Format("{0:X}", sendBuf[5]).PadLeft(2, '0');
                _serialPort.Write(sendBuf, 0, 6);
                //Thread.Sleep(45); // about 45ms
                Thread.Sleep(60); // about 60ms
            }
            testBtn.Enabled = true;
        }
        //
        private void ledBtn_Click(object sender, EventArgs e)
        {
            ledBtn.Enabled = false;
            int i = 0;
            //for ( i = 0; i < 500; i++ )
            //{
            sendBuf[0] = 0x06;
            sendBuf[1] = 0x02;
            sendBuf[2] = 0xE3;
            // Jack Test
            //sendBuf[0] = 0xFF;
            //sendBuf[1] = 0xFF;
            //sendBuf[2] = 0xFF;  
            //

            try
            {
                sendBuf[3] = Convert.ToByte(Convert.ToInt32(ledTXT2.Text, 16));
            }
            catch { sendBuf[3] = 0; }
            if (sendBuf[3] > 255) sendBuf[3] = 0;
            try
            {
                sendBuf[4] = Convert.ToByte(Convert.ToInt32(ledTXT1.Text, 16));
            }
            catch { sendBuf[4] = 0; }
            if (sendBuf[4] > 255) sendBuf[4] = 0;
            //sendBuf[4] = (byte)(i%255);
            chkSumSed = 0x06 ^ 0x02 ^ 0xE3 ^
                Convert.ToInt16(sendBuf[3]) ^ Convert.ToInt16(sendBuf[4]);
            sendBuf[5] = Convert.ToByte(chkSumSed);
            ledCRCLab.Text = "0x" + String.Format("{0:X}", sendBuf[5]).PadLeft(2, '0');
            try
            {
                _serialPort.Write(sendBuf, 0, 6);
            }
            catch { }
            Thread.Sleep(65);
            //}
            ledBtn.Enabled = true;
        }


        private void keyBtn_Click(object sender, EventArgs e)
        {
            keyBtn.Enabled = false;

            sendBuf[0] = 0x06;
            sendBuf[1] = 0x02;
            sendBuf[2] = 0x62;
            sendBuf[3] = 0x00;
            sendBuf[4] = 0x00;
            chkSumSed = 0x06 ^ 0x02 ^ 0x62 ^ 0x00 ^ 0x00;
            sendBuf[5] = Convert.ToByte(chkSumSed);
            keyCRCLab.Text = "0x" + String.Format("{0:X}", sendBuf[5]).PadLeft(2, '0');
            try
            {
                _serialPort.Write(sendBuf, 0, 6);
            }
            catch { }
            Thread.Sleep(40);
            keyBtn.Enabled = true;
        }

        private void sensBtn_Click(object sender, EventArgs e)
        {
            sensBtn.Enabled = false;

            sendBuf[0] = 0x06;
            sendBuf[1] = 0x02;
            sendBuf[2] = 0x64;
            // Jack Test
            sendBuf[3] = 0x00;
            //sendBuf[3] = 0xFF;
            //

            try
            {
                sendBuf[4] = Convert.ToByte(Convert.ToInt32(sensTXT.Text, 16));
            }
            catch { sendBuf[4] = 0; }
            if (sendBuf[4] > 255) sendBuf[3] = 0;
            chkSumSed = 0x06 ^ 0x02 ^ 0x64 ^ 0x00 ^
                Convert.ToInt16(sendBuf[4]);
            sendBuf[5] = Convert.ToByte(chkSumSed);
            sensCRCLab.Text = "0x" + String.Format("{0:X}", sendBuf[5]).PadLeft(2, '0');
            try
            {
                _serialPort.Write(sendBuf, 0, 6);
            }
            catch { }
            Thread.Sleep(40);
            sensBtn.Enabled = true;
        }

        //
        private void clnBtn_Click(object sender, EventArgs e)
        {
            logBox.Clear();
            logBox.SelectionStart = 0;
            hexOutput = null;
        }
        //
        //
        private void BtnAns_Click(object sender, EventArgs e)
        {
            recMod = !recMod;
            if (recMod)
            {
                BtnAns.Text = "TestAns" + "\r\n" + "On";
            }
            else
            {
                BtnAns.Text = "TestAns" + "\r\n" + "Off";
                LabAns.Text = "Ans: ";
            }
        }
        //
        //
        private void timer01_Tick(object sender, EventArgs eArgs)
        {
            //
            if (AnsKey)
            {
                AnsKey = false;

                //

                LabAns.Text = "Ans: " + " " + String.Format("{0:X}", sendBuf[0]).PadLeft(2, '0') +
                    " " + String.Format("{0:X}", sendBuf[1]).PadLeft(2, '0') +
                    " " + String.Format("{0:X}", sendBuf[2]).PadLeft(2, '0') +
                    " " + String.Format("{0:X}", sendBuf[3]).PadLeft(2, '0') +
                    " " + String.Format("{0:X}", sendBuf[4]).PadLeft(2, '0') +
                    " " + String.Format("{0:X}", sendBuf[5]).PadLeft(2, '0');
                ansInt = ansInt * 2;
                if (ansInt > 8) ansInt = 1;
                //

            }
            //
            //
            if (AnsLed)
            {
                AnsLed = false;

                //

                LabAns.Text = "Ans: " + " " + String.Format("{0:X}", sendBuf[0]).PadLeft(2, '0') +
                    " " + String.Format("{0:X}", sendBuf[1]).PadLeft(2, '0') +
                    " " + String.Format("{0:X}", sendBuf[2]).PadLeft(2, '0') +
                    " " + String.Format("{0:X}", sendBuf[3]).PadLeft(2, '0') +
                    " " + String.Format("{0:X}", sendBuf[4]).PadLeft(2, '0') +
                    " " + String.Format("{0:X}", sendBuf[5]).PadLeft(2, '0');
                //

            }
            //
            //
            if (timerAct)
            {
                timerAct = false;
                //cmdSatatus = 0;

                this.logBox.Text = hexOutput;
                if (logBox.Lines.Length >= 31)
                {
                    //logBox.Clear();
                    logBox.SelectionStart = logBox.Text.Length;
                    logBox.ScrollToCaret();
                }

            }
            //SetText("test\r\n");
            //

            /*
            if (fWrFile)
            {
                if (iPathFileName % iFileSet == 0)
                {
                    sFolderName = @"D:\USdata-" + (iPathFileName / iFileSet).ToString().PadLeft(4, '0');
                    System.IO.Directory.CreateDirectory(sFolderName);
                }

                string sFileName = "pic32adc-" + (iPathFileName % iFileSet).ToString().PadLeft(4, '0') + ".txt";
                System.IO.File.WriteAllLines(
                    System.IO.Path.Combine(sFolderName, sFileName), comBuf);
                iPathFileName++;
                if (iPathFileName >= 50000) iPathFileName = 0;
                fWrFile = false;
            }
            */
        }
        //
        //
        bool bComPort = false;
        private void comBtn_Click(object sender, EventArgs e)
        {
            //_serialPort.Close();
            string comPortName = comboCom.SelectedItem.ToString();
            //_serialPort.PortName = SetPortName(comPortName);
            string sBaudRate = comboBaud.SelectedItem.ToString();
            //_serialPort.BaudRate = SetPortBaudRate(int.Parse(sBaudRate));
            //_serialPort.Parity = SetPortParity(_serialPort.Parity);
            //_serialPort.DataBits = SetPortDataBits(_serialPort.DataBits);
            //_serialPort.StopBits = SetPortStopBits(_serialPort.StopBits);
            //_serialPort.Handshake = SetPortHandshake(_serialPort.Handshake);
            //_serialPort.ReadTimeout = 500;
            //_serialPort.WriteTimeout = 500;
            if (!fOpenOK)
            {
                try
                {
                    _serialPort = new SerialPort(comPortName, int.Parse(sBaudRate),
                        Parity.None, 8, StopBits.Two);
                    //
                    _serialPort.DataReceived +=
                        new SerialDataReceivedEventHandler(serialPort_DataReceived);
                    //
                    //_serialPort.RtsEnable = true;
                    //
                    _serialPort.ReadTimeout = 20;
                    _serialPort.WriteTimeout = 20;
                    _serialPort.Close();
                    _serialPort.Open();

                    Thread.Sleep(100);
                    if (_serialPort.IsOpen)
                    {
                        fOpenOK = true;
                        SetText(comPortName + ", ");
                        SetText(sBaudRate + ", ");
                        SetText("Com Port is open.\r\n");
                        //_serialPort.Close();


                        //_serialPort.RtsEnable = true;

                        // Set the read/write timeouts


                        //_serialPort.Open();
                    }
                    else
                    {
                        fOpenOK = false;
                        SetText("Com Port can't Open!\r\n");
                    }
                }
                catch { SetText("Com Port already been used!\r\n"); }
            }

            if (fOpenOK)
            {
                if (bComPort == false)
                {
                    //_serialPort.Open();
                    bComPort = true;
                    comBtn.Text = "Close";
                    Thread.Sleep(200);
                    ledBtn.Enabled = true;
                    keyBtn.Enabled = true;
                    sensBtn.Enabled = true;
                    testBtn.Enabled = true;
                }
                else
                {
                    ledBtn.Enabled = false;
                    keyBtn.Enabled = false;
                    sensBtn.Enabled = false;
                    testBtn.Enabled = false;
                    fOpenOK = false;
                    bComPort = false;
                    comBtn.Text = "Open";
                    _serialPort.Close();
                    _serialPort.Dispose();
                    Thread.Sleep(200);

                }

            }

        }
        //


        private void ClrScrBtn_Click(object sender, EventArgs e)
        {

        }

        private static string SetPortName(string defaultPortName)
        {
            //string portName;

            string portName = "COM1";
            //string portName = "COM2";
            //string portName = "COM3";
            //string portName = "COM4";
            //string portName = "COM5";
            //string portName = "COM6";
            //string portName = "COM7";

            //Console.WriteLine("Available Ports:");
            foreach (string s in SerialPort.GetPortNames())
            {
                //Console.WriteLine("   {0}", s);
            }

            //Console.Write("COM port({0}): ", defaultPortName);
            //portName = Console.ReadLine();

            if (portName == "")
            {
                portName = defaultPortName;
            }
            return portName;
        }

        private static int SetPortBaudRate(int defaultPortBaudRate)
        {
            string baudRate;

            //Console.Write("Baud Rate({0}): ", defaultPortBaudRate);
            //baudRate = Console.ReadLine();
            //baudRate = "19200";
            //baudRate = "115200";
            baudRate = "2400";

            if (baudRate == "")
            {
                baudRate = defaultPortBaudRate.ToString();
            }

            return int.Parse(baudRate);
        }

        private static Parity SetPortParity(Parity defaultPortParity)
        {
            string parity;

            //Console.WriteLine("Available Parity options:");
            foreach (string s in Enum.GetNames(typeof(Parity)))
            {
                //Console.WriteLine("   {0}", s);
            }

            //Console.Write("Parity({0}):", defaultPortParity.ToString());
            //parity = Console.ReadLine();
            parity = "None";

            if (parity == "")
            {
                parity = defaultPortParity.ToString();
            }

            return (Parity)Enum.Parse(typeof(Parity), parity);
        }

        private static int SetPortDataBits(int defaultPortDataBits)
        {
            string dataBits;

            //Console.Write("Data Bits({0}): ", defaultPortDataBits);
            //dataBits = Console.ReadLine();
            dataBits = "8";

            if (dataBits == "")
            {
                dataBits = defaultPortDataBits.ToString();
            }

            return int.Parse(dataBits);
        }

        private static StopBits SetPortStopBits(StopBits defaultPortStopBits)
        {
            string stopBits;

            //Console.WriteLine("Available Stop Bits options:");
            foreach (string s in Enum.GetNames(typeof(StopBits)))
            {
                //Console.WriteLine("   {0}", s);
            }

            //Console.Write("Stop Bits({0}):", defaultPortStopBits.ToString());
            //stopBits = Console.ReadLine();
            stopBits = "One";

            if (stopBits == "")
            {
                stopBits = defaultPortStopBits.ToString();
            }

            return (StopBits)Enum.Parse(typeof(StopBits), stopBits);
        }

        private static Handshake SetPortHandshake(Handshake defaultPortHandshake)
        {
            string handshake;

            //Console.WriteLine("Available Handshake options:");
            foreach (string s in Enum.GetNames(typeof(Handshake)))
            {
                //Console.WriteLine("   {0}", s);
            }

            //Console.Write("Handshake({0}):", defaultPortHandshake.ToString());
            //handshake = Console.ReadLine();
            //None = 0,
            //XOnXOff = 1,        
            //RequestToSend = 2,        
            //RequestToSendXOnXOff = 3,
            handshake = "None";
            //handshake = "XOnXOff";
            //handshake = "RequestToSend";
            //handshake = "RequestToSendXOnXOff";

            if (handshake == "")
            {
                handshake = defaultPortHandshake.ToString();
            }

            return (Handshake)Enum.Parse(typeof(Handshake), handshake);
        }


        //================

        private void SetText(string text)
        {
            // InvokeRequired required compares the thread ID of the
            // calling thread to the thread ID of the creating thread.
            // If these threads are different, it returns true.
            if (this.logBox.InvokeRequired)
            {
                SetTextCallback d = new SetTextCallback(SetText);
                this.Invoke(d, new object[] { text });
            }
            else
            {
                this.logBox.Text += text;
                if (logBox.Lines.Length >= 31) logBox.Clear();
            }

        }

        //========
        private void Form1_Load(object sender, EventArgs e)
        {
            //this.WindowState = FormWindowState.Maximized;
            this.Size = new System.Drawing.Size(800, 520);
            //
            myPen = new Pen(Brushes.LightGreen, 1);
            // Width = 1280, Height = 1024   
            Graphics g = this.CreateGraphics();

            this.Cursor = Cursors.Hand;

            Thread.Sleep(400);
        }



        private void Form1_Resize(object sender, EventArgs e)
        {
            myPen = new Pen(Brushes.LightGreen, 1);



        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            //startClient.Abort();
            //readThread.Abort();
            try
            {
                _serialPort.Close();
            }
            catch { }


        }
        //========        

        private void clrBtn_Click(object sender, EventArgs e)
        {
            oneFlag = false;
            wrFlag = false;
            pageFlag = false;
        }

        private void pageBtn_Click(object sender, EventArgs e)
        {

            pageFlag = !pageFlag;
            wrFlag = false;


        }

        private void wrBtn_Click(object sender, EventArgs e)
        {
            wrFlag = !wrFlag;
            pageFlag = false;

        }

        private void floatBtn_Click(object sender, EventArgs e)
        {
            floatFlag = !floatFlag;
            wrFlag = false;
            pageFlag = false;

        }

        private void Form1_MouseMove(object sender, MouseEventArgs e)
        {
            if (wrFlag && mouseDnFlag)
            {
                Graphics g = this.CreateGraphics();
                using (Pen p = new Pen(Brushes.Red, 5))
                {
                    if (oneFlag)
                        g.DrawLine(p, x1, y1, e.X, e.Y);
                }
                x1 = e.X;
                y1 = e.Y;
                oneFlag = true;
            }
            //labMouse.Text = "X=" + e.X.ToString() + ", Y=" + e.Y.ToString();

        }

        // Note: Mousedown and button click event to clash, to save this problem, use timer.
        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            mouseDnFlag = true;
            x1 = e.X;
            y1 = e.Y;
        }

        private void Form1_MouseUp(object sender, MouseEventArgs e)
        {
            mouseDnFlag = false;
        }





        private void btnLeft_Click(object sender, EventArgs e)
        {

        }

        private void btnRight_Click(object sender, EventArgs e)
        {

        }



        private void aboutToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            string messageBoxText =
                "Sampo TKM Tester, Jack Chen, MYSON CENTURY INC.\r\n  V1.00   20140529";
            string caption = "Sampo TKM Tester";
            MessageBoxButtons button = MessageBoxButtons.OK;
            MessageBoxIcon icon = MessageBoxIcon.Information;

            MessageBox.Show(messageBoxText, caption, button, icon);
        }







    }
}

static public class Mouse
{
    [DllImport("user32.dll", SetLastError = true)]
    public static extern Int32 SendInput(Int32 cInputs, ref INPUT pInputs, Int32 cbSize);

    [StructLayout(LayoutKind.Explicit, Pack = 1, Size = 28)]
    public struct INPUT
    {
        [FieldOffset(0)]
        public INPUTTYPE dwType;
        [FieldOffset(4)]
        public MOUSEINPUT mi;
        [FieldOffset(4)]
        public KEYBOARDINPUT ki;
        [FieldOffset(4)]
        public HARDWAREINPUT hi;
    }

    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public struct MOUSEINPUT
    {
        public Int32 dx;
        public Int32 dy;
        public Int32 mouseData;
        public MOUSEFLAG dwFlags;
        public Int32 time;
        public IntPtr dwExtraInfo;
    }

    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public struct KEYBOARDINPUT
    {
        public Int16 wVk;
        public Int16 wScan;
        public KEYBOARDFLAG dwFlags;
        public Int32 time;
        public IntPtr dwExtraInfo;
    }

    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public struct HARDWAREINPUT
    {
        public Int32 uMsg;
        public Int16 wParamL;
        public Int16 wParamH;
    }

    public enum INPUTTYPE : int
    {
        Mouse = 0,
        Keyboard = 1,
        Hardware = 2
    }

    [Flags()]
    public enum MOUSEFLAG : int
    {
        MOVE = 0x1,
        LEFTDOWN = 0x2,
        LEFTUP = 0x4,
        RIGHTDOWN = 0x8,
        RIGHTUP = 0x10,
        MIDDLEDOWN = 0x20,
        MIDDLEUP = 0x40,
        XDOWN = 0x80,
        XUP = 0x100,
        VIRTUALDESK = 0x400,
        WHEEL = 0x800,
        ABSOLUTE = 0x8000
    }

    [Flags()]
    public enum KEYBOARDFLAG : int
    {
        EXTENDEDKEY = 1,
        KEYUP = 2,
        UNICODE = 4,
        SCANCODE = 8
    }

    static public void RightDown()
    {
        INPUT rightdown = new INPUT();

        rightdown.dwType = 0;
        rightdown.mi = new MOUSEINPUT();
        rightdown.mi.dwExtraInfo = IntPtr.Zero;
        rightdown.mi.dx = 0;
        rightdown.mi.dy = 0;
        rightdown.mi.time = 0;
        rightdown.mi.mouseData = 0;
        rightdown.mi.dwFlags = MOUSEFLAG.RIGHTDOWN;

        SendInput(1, ref rightdown, Marshal.SizeOf(typeof(INPUT)));
    }

    static public void RightUp()
    {
        INPUT rightup = new INPUT();

        rightup.dwType = 0;
        rightup.mi = new MOUSEINPUT();
        rightup.mi.dwExtraInfo = IntPtr.Zero;
        rightup.mi.dx = 0;
        rightup.mi.dy = 0;
        rightup.mi.time = 0;
        rightup.mi.mouseData = 0;
        rightup.mi.dwFlags = MOUSEFLAG.RIGHTUP;

        SendInput(1, ref rightup, Marshal.SizeOf(typeof(INPUT)));
    }

    static public void LeftDown()
    {
        INPUT leftdown = new INPUT();

        leftdown.dwType = 0;
        leftdown.mi = new MOUSEINPUT();
        leftdown.mi.dwExtraInfo = IntPtr.Zero;
        leftdown.mi.dx = 0;
        leftdown.mi.dy = 0;
        leftdown.mi.time = 0;
        leftdown.mi.mouseData = 0;
        leftdown.mi.dwFlags = MOUSEFLAG.LEFTDOWN;

        SendInput(1, ref leftdown, Marshal.SizeOf(typeof(INPUT)));
    }

    static public void LeftUp()
    {
        INPUT leftup = new INPUT();

        leftup.dwType = 0;
        leftup.mi = new MOUSEINPUT();
        leftup.mi.dwExtraInfo = IntPtr.Zero;
        leftup.mi.dx = 0;
        leftup.mi.dy = 0;
        leftup.mi.time = 0;
        leftup.mi.mouseData = 0;
        leftup.mi.dwFlags = MOUSEFLAG.LEFTUP;

        SendInput(1, ref leftup, Marshal.SizeOf(typeof(INPUT)));
    }

    // JC Chen 2012.10.11
    static public void WheelScroll(int mouseScroll)
    {
        int iScrollUnit = 70;

        INPUT wheelscroll = new INPUT();

        wheelscroll.dwType = 0;
        wheelscroll.mi = new MOUSEINPUT();
        wheelscroll.mi.dwExtraInfo = IntPtr.Zero;
        wheelscroll.mi.dx = 0;
        wheelscroll.mi.dy = 0;
        wheelscroll.mi.time = 0;
        wheelscroll.mi.mouseData = mouseScroll * iScrollUnit;
        wheelscroll.mi.dwFlags = MOUSEFLAG.WHEEL;

        SendInput(1, ref wheelscroll, Marshal.SizeOf(typeof(INPUT)));
    }

    static public void WheelScrollUp()
    {
        int iPScrollStep = 8;
        WheelScroll(iPScrollStep);
    }

    static public void WheelScrollDown()
    {
        int iMScrollStep = -8;
        WheelScroll(iMScrollStep);
    }

    //

    static public void LeftClick()
    {
        LeftDown();
        //Thread.Sleep(20);
        Thread.Sleep(20);
        LeftUp();
    }

    static public void RightClick()
    {
        RightDown();
        //Thread.Sleep(20);
        Thread.Sleep(20);
        RightUp();
    }

    static public void LeftDoubleClick()
    {
        LeftClick();
        //Thread.Sleep(50);
        Thread.Sleep(50);
        LeftClick();
    }

    static public void RightDoubleClick()
    {
        RightClick();
        //Thread.Sleep(50);
        Thread.Sleep(50);
        RightClick();
    }

    static public void DragTo(string sor_X, string sor_Y, string des_X, string des_Y)
    {
        MoveTo(sor_X, sor_Y);
        LeftDown();
        Thread.Sleep(200);
        MoveTo(des_X, des_Y);
        LeftUp();
    }

    static public void MoveTo(string tx, string ty)
    {
        int x, y;
        int.TryParse(tx, out x);
        int.TryParse(ty, out y);

        // This is a problem.
        //Cursor.Position = new Point(x, y);
        Cursor.Position = new Point(x, y + 22);
    }
}
